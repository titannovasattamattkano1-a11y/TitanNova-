import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig, loadEnv} from 'vite';

export default defineConfig(({mode}) => {
  const env = loadEnv(mode, '.', '');
  return {
    plugins: [react(), tailwindcss()],
    define: {
      'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY || ''),
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: {
        ignored: [
          '**/whatsapp_auth/**',
          '**/data/**',
          '**/logs/**',
          '**/tmp/**',
          '**/*.json',
          '**/*.mp4',
          '**/*.mp3',
          '**/*.wav',
          '**/*.pcm',
          '**/active_schedules.json',
          '**/ledger_snapshot.json',
          '**/sent_messages.json',
          '**/audit_queue.json',
          '**/predictions_history.json',
          '**/app_state.db*'
        ]
      }
    },
  };
});
