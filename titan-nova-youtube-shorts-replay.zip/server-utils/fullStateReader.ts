import fs from 'node:fs';
const immutableViews=new WeakSet<object>();
export const isImmutableFullStateView=(value:unknown):value is object=>Boolean(value&&typeof value==='object'&&immutableViews.has(value));
/** Cache only persisted file reads; chart/history calculations are never cached here.
 * File identity includes inode and nanosecond mtime/ctime so atomic restores invalidate it.
 */
export class FullStateReader {
 private signature='';private json='';private state:any=null;private viewState:any=null;private memoryAhead=false;
 constructor(private readonly file:string){}
 private load(strict:boolean):boolean {
  try{
   const stat=fs.statSync(this.file,{bigint:true});
   const signature=[stat.dev,stat.ino,stat.size,stat.mtimeNs,stat.ctimeNs].join(':');
   if(signature===this.signature)return true;
   const json=fs.readFileSync(this.file,'utf8'),raw=JSON.parse(json),state=raw?.state||raw;
   if(!state||typeof state!=='object'||!state.profiles||typeof state.profiles!=='object'||Array.isArray(state.profiles))throw Error('Invalid stored app state');
   this.signature=signature;this.json=json;this.state=state;this.viewState=null;return true;
  }catch(error:any){
   this.signature='';this.json='';this.state=null;this.viewState=null;
   if(error?.code==='ENOENT')return false;
   if(strict)throw Error('Stored app state could not be read. Restore a valid backup before saving.');
   return false;
  }
 }
 /** Validate persistence without freezing the entire archive on every write. */
 validate(strict=true):boolean {
  if(this.memoryAhead&&this.viewState)return true;
  return this.load(strict);
 }
 /** Prime the reader cache immediately after an atomic disk write to avoid redundant disk re-reads. */
 prime(rawJson:string,parsedState?:any):void {
  this.memoryAhead=false;
  try{
   const stat=fs.statSync(this.file,{bigint:true});
   this.signature=[stat.dev,stat.ino,stat.size,stat.mtimeNs,stat.ctimeNs].join(':');
   this.json=rawJson;this.state=null;
   if(parsedState&&typeof parsedState==='object'&&parsedState.profiles){
    this.viewState=parsedState;
    Object.freeze(this.viewState);
    if(typeof this.viewState.profiles==='object')Object.freeze(this.viewState.profiles);
    immutableViews.add(this.viewState);
   }else{
    this.viewState=null;
   }
  }catch(_){this.signature='';this.json='';this.state=null;this.viewState=null;}
 }
 /** Prime in-memory state immediately while background async disk flush completes. */
 primeMemory(rawJson:string,parsedState?:any):void {
  this.memoryAhead=true;
  this.json=rawJson;
  this.state=null;
  if(parsedState&&typeof parsedState==='object'&&parsedState.profiles){
   this.viewState=parsedState;
   Object.freeze(this.viewState);
   if(typeof this.viewState.profiles==='object')Object.freeze(this.viewState.profiles);
   immutableViews.add(this.viewState);
  }else{
   this.viewState=null;
  }
 }
 /** Mark disk signature in sync after async background flush finishes. */
 markDiskSynced():void {
  this.memoryAhead=false;
  try{
   const stat=fs.statSync(this.file,{bigint:true});
   this.signature=[stat.dev,stat.ino,stat.size,stat.mtimeNs,stat.ctimeNs].join(':');
  }catch(_){this.signature='';}
 }
 /** Read-only consumers share a validated immutable view of the exact current file without O(N) deep recursive freeze. */
 view(strict=false):any|null {
  if(this.memoryAhead&&this.viewState)return this.viewState;
  if(!this.load(strict))return null;
  if(!this.viewState){
   if(this.state){
    this.viewState=this.state;
    this.state=null;
   }else{
    const raw=JSON.parse(this.json);
    this.viewState=raw?.state||raw;
   }
   if(this.viewState&&typeof this.viewState==='object'){
    Object.freeze(this.viewState);
    if(this.viewState.profiles&&typeof this.viewState.profiles==='object')Object.freeze(this.viewState.profiles);
    immutableViews.add(this.viewState);
   }
  }
  return this.viewState;
 }
 /** Existing mutation paths retain independently owned objects. */
 read(strict=false):any|null {
  if(this.memoryAhead&&this.json){const raw=JSON.parse(this.json);return raw?.state||raw;}
  if(!this.load(strict))return null;
  if(this.state){const owned=this.state;this.state=null;return owned;}
  const raw=JSON.parse(this.json);return raw?.state||raw;
 }
}
