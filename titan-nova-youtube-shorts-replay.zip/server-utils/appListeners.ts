/** Both HTTP listeners use one Express app, runtime, session registry and data store. */
export function startAppListeners(
  app: {listen(port:number,host:string,callback:()=>void):{on(event:string,callback:(error:any)=>void):unknown}},
  primaryPort:number,
  localPort:number,
  log:(message:string)=>void=console.log,
  warn:(message:string)=>void=console.error,
){
  const tuneTimeouts=(srv:any)=>{if(srv&&typeof srv==='object'){srv.keepAliveTimeout=65000;srv.headersTimeout=66000;}};
  const primary=app.listen(primaryPort,'0.0.0.0',()=>log(`Titan Nova AI Server running on http://localhost:${primaryPort}`));
  tuneTimeouts(primary);
  // Same port already serves localhost. Never attempt to bind it a second time.
  if(localPort!==primaryPort){
    const local=app.listen(localPort,'127.0.0.1',()=>log(`Titan Nova local access: http://127.0.0.1:${localPort} (same backend)`));
    tuneTimeouts(local);
    local.on('error',(error:any)=>warn(`Titan local port ${localPort} unavailable (${error?.code||'listen error'}). Existing port ${primaryPort} remains active. Free port ${localPort} and restart titan-nova-web.`));
  }
  return primary;
}
