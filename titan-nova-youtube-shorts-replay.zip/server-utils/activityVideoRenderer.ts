import * as PImage from 'pureimage';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import WebSocket from 'ws';
import type { ActivityTimelineEvent } from './activityRecorder';

const execFileAsync = promisify(execFile);

const WIDTH = 540;
const HEIGHT = 960;
const SAMPLE_RATE = 22050;

export type VideoStyleTheme = 'cyber_neon' | 'gold_royal' | 'emerald_matrix';
export type VideoVoiceLang = 'hinglish' | 'hindi' | 'english';
export type VideoMusicStyle = 'cinematic_bass' | 'lofi_chill' | 'upbeat_synth' | 'off';
export type ViralHookStyle = 'auto_viral' | 'hook_a' | 'hook_b' | 'hook_c' | 'hook_d' | 'hook_e';
export type VoicePackId = 'swara_hi' | 'madhur_hi' | 'andrew_pro' | 'brian_hype' | 'ava_studio' | 'emma_reels' | 'gemini_flash_tts' | 'minimax' | 'elevenlabs' | 'xai_grok' | 'heygen';

export interface VoiceCueItem {
  startSec: number;
  endSec: number;
  text: string;
}

export interface StepStoryEvent extends ActivityTimelineEvent {
  cardSlot?: number;
  stepPhase?: 1 | 2 | 3;
  prevRate?: string;
  baseRate?: string;
  rateDiff?: number;
  prevStatus?: string;
  nextMarket?: string;
  nextRate?: string;
  ttsHindi?: string;
  isSmartStakeOn?: boolean;
  strongDigits?: string;
  supportDigits?: string;
  strongRate?: number;
  supportRate?: number;
  isProfitCarryOn?: boolean;
  prevLoss?: number;
  carriedProfit?: number;
  baseTargetProfit?: number;
  targetWithLoss?: number;
  isCloseZeroOn?: boolean;
  isCloseZeroSkip?: boolean;
  isSkippedCard?: boolean;
  skipReason?: string;
  isFourWaveOn?: boolean;
  waveId?: string;
  sameMarketMode?: boolean;
  isLastCard?: boolean;
  hasPendingAfter?: boolean;
}

export interface DailyReportSummary {
  totalCards: number;
  totalPass: number;
  totalFail: number;
  totalInvest: number;
  maxConsecutiveFails: number;
  maxRiskExposure: number;
  finalNetPl: number;
}

export interface VideoStudioOptions {
  period?: 'day' | 'week';
  dateRangeLabel?: string;
  profileName?: string;
  style?: VideoStyleTheme;
  hookStyle?: ViralHookStyle;
  durationSec?: 20 | 30 | 45 | 60 | 75;
  videoMode?: 'trailer_status' | 'full_breakdown' | 'unboxing_reveal';
  socialPlatform?: string;
  voiceLang?: VideoVoiceLang;
  voiceGender?: 'male' | 'female';
  voicePack?: VoicePackId;
  voiceEnabled?: boolean;
  voicePitchShift?: number;
  voiceSpeed?: number;
  voiceSampleBase64?: string;
  musicStyle?: VideoMusicStyle;
  showSubtitles?: boolean;
  customTitle?: string;
  customCta?: string;
  secondsPerStep?: number;
  pendingMarkets?: string[];
  dailyReportSummary?: DailyReportSummary;
}

const ttsPcmCache = new Map<string, Int16Array>();
function setCachedPcm(key: string, pcm: Int16Array) {
  if (ttsPcmCache.size > 200) {
    const firstKey = ttsPcmCache.keys().next().value;
    if (firstKey) ttsPcmCache.delete(firstKey);
  }
  ttsPcmCache.set(key, pcm);
}

function bufferToInt16Array(raw: Buffer): Int16Array {
  const sampleCount = Math.floor(raw.byteLength / 2);
  const out = new Int16Array(sampleCount);
  for (let i = 0; i < sampleCount; i++) {
    out[i] = raw.readInt16LE(i * 2);
  }
  return out;
}

let renderQueuePromise: Promise<any> = Promise.resolve();

let fontReady: Promise<void> | undefined;
function loadFont() {
  return (fontReady ??= (async () => {
    const fontPath = path.resolve(process.env.TITAN_APP_ROOT || process.cwd(), 'assets/fonts/TitanCard.ttf');
    if (fs.existsSync(fontPath)) {
      await PImage.registerFont(fontPath, 'TitanCard').load();
    }
  })());
}

export async function isFfmpegAvailable(): Promise<boolean> {
  try {
    await execFileAsync('ffmpeg', ['-version'], { timeout: 3000 });
    return true;
  } catch {
    return false;
  }
}

function parseHexColor(hex: string): [number, number, number] {
  const clean = String(hex || '#000000').replace('#', '').trim();
  if (clean.length === 6) {
    return [
      parseInt(clean.slice(0, 2), 16) || 0,
      parseInt(clean.slice(2, 4), 16) || 0,
      parseInt(clean.slice(4, 6), 16) || 0,
    ];
  }
  return [16, 26, 40];
}

function wrapText(ctx: any, text: string, maxWidth: number, maxLines = 3): string[] {
  const words = String(text || '').split(/\s+/).filter(Boolean);
  if (!words.length) return [''];
  const lines: string[] = [];
  let current = words[0];
  for (let i = 1; i < words.length; i++) {
    const next = `${current} ${words[i]}`;
    if (ctx.measureText(next).width <= maxWidth) {
      current = next;
    } else {
      lines.push(current);
      current = words[i];
      if (lines.length >= maxLines - 1) {
        let trimmed = [current, ...words.slice(i + 1)].join(' ');
        while (ctx.measureText(trimmed).width > maxWidth && trimmed.length > 4) {
          trimmed = `${trimmed.slice(0, -4)}...`;
        }
        lines.push(trimmed);
        return lines;
      }
    }
  }
  lines.push(current);
  return lines;
}

function makeSprite(w: number, h: number) {
  const image = PImage.make(w, h);
  const ctx = image.getContext('2d');
  const buf = image.data as Uint8Array;

  const fastBox = (x: number, y: number, bw: number, bh: number, fillHex?: string, borderHex?: string, borderW = 2) => {
    const x0 = Math.max(0, Math.round(x));
    const y0 = Math.max(0, Math.round(y));
    const x1 = Math.min(w, Math.round(x + bw));
    const y1 = Math.min(h, Math.round(y + bh));
    if (x1 <= x0 || y1 <= y0) return;

    const [fr, fg, fb] = fillHex ? parseHexColor(fillHex) : [0, 0, 0];
    const [br, bg, bb] = borderHex ? parseHexColor(borderHex) : [0, 0, 0];
    const hasFill = Boolean(fillHex);
    const hasBorder = Boolean(borderHex && borderW > 0);

    for (let py = y0; py < y1; py++) {
      const isTopOrBottom = hasBorder && (py < y0 + borderW || py >= y1 - borderW);
      let idx = (py * w + x0) * 4;
      for (let px = x0; px < x1; px++) {
        const isBorder = isTopOrBottom || (hasBorder && (px < x0 + borderW || px >= x1 - borderW));
        if (isBorder) {
          buf[idx] = br; buf[idx + 1] = bg; buf[idx + 2] = bb; buf[idx + 3] = 255;
        } else if (hasFill) {
          buf[idx] = fr; buf[idx + 1] = fg; buf[idx + 2] = fb; buf[idx + 3] = 255;
        }
        idx += 4;
      }
    }
  };

  const drawText = (val: string, x: number, y: number, size: number, color = '#EEF7FF', maxW = w - 24, align: 'left' | 'center' | 'right' = 'left') => {
    const clean = String(val || '').replace(/[^\x20-\x7E]/g, ' ').replace(/\s+/g, ' ').trim();
    if (!clean) return;
    let font = size;
    ctx.font = `${font}pt TitanCard`;
    while (ctx.measureText(clean).width > maxW && font > 8) {
      font -= 1;
      ctx.font = `${font}pt TitanCard`;
    }
    const tw = ctx.measureText(clean).width;
    const drawX = Math.round(align === 'center' ? x - tw / 2 : align === 'right' ? x - tw : x);
    ctx.fillStyle = color;
    ctx.fillText(clean, drawX, Math.round(y));
  };

  return { image, ctx, buf, fastBox, drawText };
}

function blitSprite(
  dest: Uint8Array,
  destW: number,
  destH: number,
  src: Uint8Array,
  srcW: number,
  srcH: number,
  dx: number,
  dy: number,
  clipTop = 0,
  clipBottom = destH
) {
  const ix = Math.round(dx);
  const iy = Math.round(dy);
  const startY = Math.max(clipTop, iy, 0);
  const endY = Math.min(clipBottom, iy + srcH, destH);
  const startX = Math.max(0, ix);
  const endX = Math.min(destW, ix + srcW);
  if (endY <= startY || endX <= startX) return;

  const rowBytes = (endX - startX) * 4;
  for (let y = startY; y < endY; y++) {
    const sy = y - iy;
    const sx = startX - ix;
    const srcOffset = (sy * srcW + sx) * 4;
    const destOffset = (y * destW + startX) * 4;
    dest.set(src.subarray(srcOffset, srcOffset + rowBytes), destOffset);
  }
}

function getCurrentBusinessDateIST(): string {
  const istNow = new Date(Date.now() + 5.5 * 60 * 60 * 1000);
  if (istNow.getUTCHours() < 3) {
    istNow.setUTCDate(istNow.getUTCDate() - 1);
  }
  return istNow.toISOString().slice(0, 10);
}

export function formatDateAndDayForVideo(dateStr: string): {
  visualBadge: string;
  dayContextTag: string;
  shortDayEn: string;
  fullDayEn: string;
  fullDayHi: string;
  dayRelationHi: string;
  dayRelationEn: string;
  isPastDay: boolean;
  isToday: boolean;
  isWeekRange: boolean;
  subPrefix: string;
  ttsPrefixHi: string;
  ttsPrefixEn: string;
} {
  const daysEn = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const daysShortEn = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
  const daysHi = ['रविवार', 'सोमवार', 'मंगलवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार'];
  const monthsEn = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const monthsShortEn = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
  const monthsHi = ['जनवरी', 'फ़रवरी', 'मार्च', 'अप्रैल', 'मई', 'जून', 'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'];

  const todayIST = getCurrentBusinessDateIST();
  const yestDate = new Date(`${todayIST}T00:00:00Z`);
  yestDate.setUTCDate(yestDate.getUTCDate() - 1);
  const yesterdayIST = yestDate.toISOString().slice(0, 10);

  const clean = String(dateStr || '').trim();
  const rangeMatch = clean.match(/^(\d{4})-(\d{2})-(\d{2})\s+to\s+(\d{4})-(\d{2})-(\d{2})$/i);
  if (rangeMatch) {
    const d1 = new Date(`${rangeMatch[1]}-${rangeMatch[2]}-${rangeMatch[3]}T00:00:00Z`);
    const d2 = new Date(`${rangeMatch[4]}-${rangeMatch[5]}-${rangeMatch[6]}T00:00:00Z`);
    if (!Number.isNaN(d1.getTime()) && !Number.isNaN(d2.getTime())) {
      const day1 = d1.getUTCDate();
      const mon1 = d1.getUTCMonth();
      const dow1 = d1.getUTCDay();
      const day2 = d2.getUTCDate();
      const mon2 = d2.getUTCMonth();
      const yr2 = d2.getUTCFullYear();
      const dow2 = d2.getUTCDay();
      const endStr = `${rangeMatch[4]}-${rangeMatch[5]}-${rangeMatch[6]}`;
      const isPastWeek = endStr < todayIST;
      return {
        visualBadge: `${day1} ${monthsShortEn[mon1]} (${daysShortEn[dow1]}) - ${day2} ${monthsShortEn[mon2]} ${yr2} (${daysShortEn[dow2]})`,
        dayContextTag: isPastWeek ? 'PAST WEEK RECORD' : 'THIS WEEK LIVE REPORT',
        shortDayEn: `${daysShortEn[dow1]}-${daysShortEn[dow2]}`,
        fullDayEn: `${daysEn[dow1]} to ${daysEn[dow2]}`,
        fullDayHi: `${daysHi[dow1]} से ${daysHi[dow2]}`,
        dayRelationHi: isPastWeek ? 'पिछले हफ्ते' : 'इस हफ्ते',
        dayRelationEn: isPastWeek ? 'last week' : 'this week',
        isPastDay: isPastWeek,
        isToday: !isPastWeek,
        isWeekRange: true,
        subPrefix: `📅 ${isPastWeek ? 'Pichhle Hafte' : 'Is Hafte'} (${day1} ${monthsShortEn[mon1]} - ${day2} ${monthsShortEn[mon2]} ${yr2}) — `,
        ttsPrefixHi: `${isPastWeek ? 'पिछले हफ्ते' : 'इस हफ्ते'}, ${day1} ${monthsHi[mon1]} ${daysHi[dow1]} से ${day2} ${monthsHi[mon2]} ${daysHi[dow2]} तक की पूरी रिपोर्ट! `,
        ttsPrefixEn: `${isPastWeek ? 'Last week' : 'This week'}, from ${daysEn[dow1]} ${day1} ${monthsEn[mon1]} to ${daysEn[dow2]} ${day2} ${monthsEn[mon2]}! `,
      };
    }
  }

  const singleMatch = clean.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (singleMatch) {
    const dt = new Date(`${singleMatch[1]}-${singleMatch[2]}-${singleMatch[3]}T00:00:00Z`);
    if (!Number.isNaN(dt.getTime())) {
      const dayNum = dt.getUTCDate();
      const monIdx = dt.getUTCMonth();
      const yrNum = dt.getUTCFullYear();
      const dowIdx = dt.getUTCDay();
      const isToday = clean === todayIST;
      const isYesterday = clean === yesterdayIST;
      const isPastDay = clean < todayIST;
      const relHi = isToday ? 'आज' : isYesterday ? 'कल (पिछले दिन)' : 'पिछले दिन';
      const relEn = isToday ? 'today' : isYesterday ? 'yesterday' : 'on that past day';
      const tag = isToday ? 'AAJ KA LIVE UPDATE' : isYesterday ? 'KAL KA FULL RECORD' : 'PAST DAY RECORD';
      return {
        visualBadge: `${tag} · ${dayNum} ${monthsShortEn[monIdx]} ${yrNum} (${daysShortEn[dowIdx]})`,
        dayContextTag: tag,
        shortDayEn: daysShortEn[dowIdx],
        fullDayEn: daysEn[dowIdx],
        fullDayHi: daysHi[dowIdx],
        dayRelationHi: relHi,
        dayRelationEn: relEn,
        isPastDay,
        isToday,
        isWeekRange: false,
        subPrefix: `📅 ${isToday ? 'Aaj' : isYesterday ? 'Kal' : 'Pichhla Din'}: ${dayNum} ${monthsShortEn[monIdx]} ${yrNum} (${daysEn[dowIdx]}) — `,
        ttsPrefixHi: `${relHi}, तारीख ${dayNum} ${monthsHi[monIdx]} ${yrNum}, दिन ${daysHi[dowIdx]}! `,
        ttsPrefixEn: `${isToday ? 'Today' : isYesterday ? 'Yesterday' : 'On'} ${daysEn[dowIdx]}, ${dayNum} ${monthsEn[monIdx]} ${yrNum}! `,
      };
    }
  }

  return {
    visualBadge: clean || 'LIVE TODAY',
    dayContextTag: 'LIVE UPDATE',
    shortDayEn: 'TODAY',
    fullDayEn: 'Today',
    fullDayHi: 'आज',
    dayRelationHi: 'आज',
    dayRelationEn: 'today',
    isPastDay: false,
    isToday: true,
    isWeekRange: false,
    subPrefix: clean ? `📅 Date: ${clean} — ` : '',
    ttsPrefixHi: clean ? `तारीख ${clean}! ` : '',
    ttsPrefixEn: clean ? `Date ${clean}! ` : '',
  };
}

export function buildViralIntroHook(
  hookStyle: ViralHookStyle,
  lang: VideoVoiceLang,
  dateStr: string,
  totalCards: number,
  totalPass: number,
  finalNetPl: number,
  bestMarket: string,
  activeModesBanner: string
): {
  resolvedHook: Exclude<ViralHookStyle, 'auto_viral'>;
  topAlertBanner: string;
  hookHeadline1: string;
  hookHeadline2: string;
  curiosityTitle: string;
  curiosityDetail: string;
  subText: string;
  ttsText: string;
} {
  let chosen: Exclude<ViralHookStyle, 'auto_viral'> = 'hook_e';
  if (hookStyle && hookStyle !== 'auto_viral') {
    chosen = hookStyle;
  } else {
    const dateSeed = Array.from(dateStr || '2026').reduce((acc, ch) => acc + ch.charCodeAt(0), 0);
    const pool: Array<Exclude<ViralHookStyle, 'auto_viral'>> = ['hook_a', 'hook_b', 'hook_c', 'hook_d', 'hook_e'];
    chosen = pool[(dateSeed + totalPass + Math.max(0, Math.round(finalNetPl))) % pool.length];
  }

  const netStr = `${finalNetPl >= 0 ? '+' : '-'}Rs ${Math.abs(Math.round(finalNetPl))}`;
  const highlightMkt = bestMarket || 'LIVE MARKET';
  const dInfo = formatDateAndDayForVideo(dateStr);

  if (chosen === 'hook_a') {
    return {
      resolvedHook: 'hook_a',
      topAlertBanner: `📅 ${dInfo.visualBadge}`,
      hookHeadline1: 'COMPLETE ACTIVITY',
      hookHeadline2: `${totalPass} PASS HITS  |  ${netStr}`,
      curiosityTitle: `HIGHLIGHT: ${highlightMkt} LIVE BREAKDOWN`,
      curiosityDetail: `Har update, har game aur har result ka step-by-step sach!`,
      subText: `${dInfo.subPrefix}Ek minute! Aaj ki complete activity (${totalCards} Cards, ${totalPass} PASS) miss mat karna! Welcome to TITAN NOVA!`,
      ttsText: lang === 'english'
        ? `${dInfo.ttsPrefixEn}Wait a minute! Do not miss today's complete activity! Full breakdown of all ${totalCards} cards and ${totalPass} pass results. Welcome to TITAN NOVA!`
        : `${dInfo.ttsPrefixHi}एक मिनट! आज की कंप्लीट एक्टिविटी मिस मत करना! हर अपडेट, हर गेम और सभी ${totalCards} कार्ड्स के रिजल्ट का पूरा हिसाब। वेलकम टू टाइटन नोवा!`,
    };
  }

  if (chosen === 'hook_b') {
    return {
      resolvedHook: 'hook_b',
      topAlertBanner: `📅 ${dInfo.visualBadge}`,
      hookHeadline1: 'LIVE PERFORMANCE',
      hookHeadline2: `${totalCards} CARDS  |  ${totalPass} WON`,
      curiosityTitle: `ACTIVE STRATEGY: ${activeModesBanner}`,
      curiosityDetail: `Chaliye dekhte hain aaj ki har important update aur actual results!`,
      subText: `${dInfo.subPrefix}What's happening today? Chaliye dekhte hain aaj ke sabhi ${totalCards} cards aur actual results! This is TITAN NOVA!`,
      ttsText: lang === 'english'
        ? `${dInfo.ttsPrefixEn}What's happening today? Let us discover every important update, complete activity, and today's actual results. This is TITAN NOVA!`
        : `${dInfo.ttsPrefixHi}व्हाट्स हैपनिंग टुडे? चलिए देखते हैं आज की हर इम्पोर्टेन्ट अपडेट, सभी ${totalCards} कार्ड्स की एक्टिविटी और एक्चुअल रिजल्ट्स! दिस इज़ टाइटन नोवा!`,
    };
  }

  if (chosen === 'hook_c') {
    return {
      resolvedHook: 'hook_c',
      topAlertBanner: `📅 ${dInfo.visualBadge}`,
      hookHeadline1: 'OFFICIAL COMMUNITY',
      hookHeadline2: `TELEGRAM & WHATSAPP PROOF`,
      curiosityTitle: `AAJ KA SCORE: ${totalPass} PASS (${netStr})`,
      curiosityDetail: `Aaj ka complete replay dekhne ke liye video end tak dekhiye!`,
      subText: `${dInfo.subPrefix}Result se pehle updates kahan milte hain? Titan Nova ke official Telegram aur WhatsApp par! End tak dekhiye.`,
      ttsText: lang === 'english'
        ? `${dInfo.ttsPrefixEn}Where do you get updates before the result? On Titan Nova's official Telegram and WhatsApp community! Watch till the end for the complete replay.`
        : `${dInfo.ttsPrefixHi}रिजल्ट से पहले अपडेट्स कहाँ मिलते हैं? टाइटन नोवा के ऑफिशियल टेलीग्राम और व्हाट्सएप कम्युनिटी पर! आज का पूरा रिप्ले देखने के लिए वीडियो एंड तक देखिए।`,
    };
  }

  if (chosen === 'hook_d') {
    return {
      resolvedHook: 'hook_d',
      topAlertBanner: `📅 ${dInfo.visualBadge}`,
      hookHeadline1: 'EVERY RESULT MATTERS',
      hookHeadline2: `${totalPass} PASS  |  NET ${netStr}`,
      curiosityTitle: `RECORDED PROOF: ${dInfo.visualBadge}`,
      curiosityDetail: `Every Activity Has a Record. Welcome to TITAN NOVA. Let's Begin!`,
      subText: `${dInfo.subPrefix}Every Game Has a Story. Every Activity Has a Record. Every Result Matters. Welcome to TITAN NOVA!`,
      ttsText: lang === 'english'
        ? `${dInfo.ttsPrefixEn}Every game has a story. Every activity has a record. Every result matters. Welcome to TITAN NOVA. Let's begin!`
        : `${dInfo.ttsPrefixHi}हर गेम की एक कहानी है, हर एक्टिविटी का लाइव रिकॉर्ड है, और हर रिजल्ट मायने रखता है! वेलकम टू टाइटन नोवा, चलिए शुरू करते हैं!`,
    };
  }

  return {
    resolvedHook: 'hook_e',
    topAlertBanner: `⚡ ${dInfo.visualBadge} · LIVE PROOF!`,
    hookHeadline1: "TITAN NOVA TRICK",
    hookHeadline2: `${totalPass} DHAMAKEDAR PASS | ${netStr}`,
    curiosityTitle: `TITAN NOVA GUESSING TRICK SE LIVE REPLAY`,
    curiosityDetail: `${dInfo.visualBadge} | ${totalCards} Cards | ${totalPass} PASS`,
    subText: `${dInfo.subPrefix}Rukiye! Scroll mat karna! Aaj Titan Nova Guessing Trick Se market me kya dhamaka hua hai—ye live proof apni aankhon se dekhiye!`,
    ttsText: lang === 'english'
      ? `${dInfo.ttsPrefixEn}Stop scrolling right now! Watch how Titan Nova Guessing Trick dominated the market today with ${totalPass} explosive pass hits and ${netStr} profit!`
      : `${dInfo.ttsPrefixHi}रुकिए! स्क्रॉल मत करना! आज टाइटन नोवा गेसिंग ट्रिक से मार्केट में क्या बवाल हुआ है और कैसे ${totalPass} गेम पास हुए—ये लाइव प्रूफ अपनी आँखों से देखिए!`,
  };
}

function formatSpokenDigits(digits?: string): string {
  const tokens = String(digits || '').split(/[,|\s]+/).filter(Boolean);
  if (!tokens.length) return '';
  return tokens.join(', ');
}

function toHindiMarketName(mkt?: string): string {
  let s = String(mkt || 'मार्केट').trim().toUpperCase();
  const map: Array<[RegExp, string]> = [
    [/\bSRIDEVI\b/g, 'श्रीदेवी'],
    [/\bSHRIDEVI\b/g, 'श्रीदेवी'],
    [/\bTIME\s+BAZAR\b/g, 'टाइम बाज़ार'],
    [/\bMAIN\s+BAZAR\b/g, 'मेन बाज़ार'],
    [/\bMADHUR\b/g, 'मधुर'],
    [/\bMILAN\b/g, 'मिलन'],
    [/\bRAJDHANI\b/g, 'राजधानी'],
    [/\bSUPREME\b/g, 'सुप्रीम'],
    [/\bKALYAN\b/g, 'कल्याण'],
    [/\bMORNING\b/g, 'मॉर्निंग'],
    [/\bDAY\b/g, 'डे'],
    [/\bNIGHT\b/g, 'नाइट'],
    [/\bOPEN\b/g, 'ओपन'],
    [/\bCLOSE\b/g, 'क्लोज़'],
  ];
  for (const [rx, hi] of map) {
    s = s.replace(rx, hi);
  }
  return s;
}

function formatTrickNameForSpeech(_mode?: string, _trick?: string): string {
  return 'टाइटन नोवा गेसिंग ट्रिक';
}

export function buildStepNarration(
  ev: StepStoryEvent,
  lang: VideoVoiceLang = 'hinglish'
): { subtitle: string; ttsText: string } {
  const mkt = ev.market || 'MARKET';
  const mktHi = toHindiMarketName(mkt);
  const baseMkt = mkt.replace(/\s+(OPEN|CLOSE)$/i, '').trim();
  const baseMktHi = toHindiMarketName(baseMkt);
  const isOpenMkt = /\s+OPEN$/i.test(mkt);
  const digSpoken = formatSpokenDigits(ev.digits);
  const rateNum = Number(ev.rate || 0);
  const prevRateNum = Number(ev.prevRate || ev.baseRate || rateNum);
  const baseRateNum = Number(ev.baseRate || prevRateNum || rateNum);
  const rateDiff = ev.rateDiff !== undefined ? ev.rateDiff : Math.max(0, rateNum - prevRateNum);
  const investNum = Math.round(Number(ev.invest || 0));
  const plNum = Math.round(Number(ev.pl || 0));
  const prevLoss = Math.round(Number(ev.prevLoss || 0));
  const carriedProfit = Math.round(Number(ev.carriedProfit || 0));
  const baseTarget = Math.round(Number(ev.baseTargetProfit || 100));
  const phase = ev.stepPhase || (ev.status === 'PASS' || ev.status === 'FAIL' ? 3 : ev.action === 'CARD_SENT' ? 2 : 1);
  const slotNum = Number(ev.cardSlot || 0);
  const isLastCard = Boolean(ev.isLastCard || !ev.nextMarket);
  const hasPendingAfter = Boolean(ev.hasPendingAfter);

  const endOfCardsTtsHi = isLastCard
    ? (hasPendingAfter
        ? 'यहाँ तक के सेटल्ड कार्ड्स पूरे हुए, अभी आगे के मार्केट्स बाकी हैं!'
        : 'आज का खेल यहीं पूरा हुआ, अब कल फिर नई रणनीति के साथ खेलेंगे!')
    : '';
  const endOfCardsTtsEn = isLastCard
    ? (hasPendingAfter
        ? 'Settled cards complete so far, upcoming markets are still pending!'
        : "Today's game is complete here, tomorrow we will play with a fresh strategy!")
    : '';
  const endOfCardsSub = isLastCard
    ? (hasPendingAfter
        ? 'Settled cards poore huye — abhi aage ke markets baki hain!'
        : 'Aaj ka khel yahin complete hua — ab kal nayi strategy ke sath play karenge!')
    : '';

  if (ev.action === 'CARD_SKIPPED') {
    const rawReason = String(ev.skipReason || '').trim();
    if (isUnboxingCard) {
    sec2Sp.drawText("2. SATHIK PROBABILITY & MEMBERSHIP LOCK:", 14, 23, 12, "#FFC107", 432, "left");
    sec2Sp.drawText("Play rate membership lene ke baad hi bataya jata hai!", 14, 102, 11, "#80DEEA", 432, "left");

    bLeft.fastBox(0, 0, 140, 48, "#0D3324", "#00E676", 2);
    bLeft.drawText("PROBABILITY", 70, 17, 9, "#00E676", 128, "center");
    bLeft.drawText(`${unboxProbPct}% SATHIK`, 70, 39, 15, "#FFFFFF", 128, "center");

    bMid.fastBox(0, 0, 140, 48, "#2E2208", "#FFC107", 2);
    bMid.drawText("PLAY RATE", 70, 17, 9, "#FFC107", 128, "center");
    bMid.drawText("VIP ONLY", 70, 39, 16, "#FFFFFF", 128, "center");

    bRight.fastBox(0, 0, 134, 48, "#142638", "#20DCE9", 2);
    bRight.drawText("MEMBERSHIP", 67, 17, 9, "#20DCE9", 122, "center");
    bRight.drawText("DAY / WK / MO", 67, 39, 13, "#FFFFFF", 122, "center");
  } else if (ev.isCloseZeroSkip) {
      const subtitle = `⏭️ SKIPPED [${mkt}]: ${baseMkt} OPEN PASS hone se Close Zero Rule lagu — Rs 0 Invest karke Profit Safe Lock! ${isLastCard ? endOfCardsSub : 'Agle card par chalte hain.'}`;
      const ttsText = lang === 'english'
        ? `${mkt} skipped! Because ${baseMkt} Open passed, Close Zero locked profit at zero rupees. ${isLastCard ? endOfCardsTtsEn : 'Moving to the next card!'}`
        : `${mktHi} स्किप किया गया, क्योंकि ${baseMktHi} ओपन पहले ही पास था! क्लोज़ ज़ीरो से ज़ीरो रुपये लगाकर प्रॉफिट सेफ रखा। ${isLastCard ? endOfCardsTtsHi : 'अब चलते हैं अगले कार्ड पर!'}`;
      return { subtitle, ttsText };
    }
    const reasonText = rawReason || 'Safety / Stop Logic Rule';
    const subtitle = `⏭️ SKIPPED [${mkt}]: Reason — ${reasonText} (Rs 0 Risk). ${isLastCard ? endOfCardsSub : 'Ab agle card par chalte hain!'}`;
    const ttsText = lang === 'english'
      ? `${mkt} skipped due to ${reasonText}, with zero risk. ${isLastCard ? endOfCardsTtsEn : 'Moving to the next card!'}`
      : `${mktHi} को लॉजिक नियम के कारण ज़ीरो रिस्क पर स्किप किया गया। ${isLastCard ? endOfCardsTtsHi : 'अब चलते हैं अगले कार्ड पर!'}`;
    return { subtitle, ttsText };
  }

  if (ev.action === 'UNBOXING_REVEAL') {
    const tokenCnt = String(ev.digits || '').split(/[,|\s]+/).filter(Boolean).length || 5;
    const probPct = Math.min(92, Math.max(68, Math.round(tokenCnt * 10 + (ev.isSmartStakeOn ? 18 : 14))));
    const nextCardHi = ev.nextMarket ? ` अब चलते हैं अगले कार्ड ${toHindiMarketName(ev.nextMarket)} पर!` : ' यह आज का लास्ट रिवील कार्ड था!';
    const nextCardEn = ev.nextMarket ? ` Moving to the next card: ${ev.nextMarket}!` : ' That was the final reveal card!';
    if (ev.isSmartStakeOn && ev.strongDigits) {
      const strongSp = formatSpokenDigits(ev.strongDigits);
      const suppSp = formatSpokenDigits(ev.supportDigits);
      const subtitle = `🎁 ${mkt}: Aaj ke Guessing [${digSpoken}] · ${probPct}% Sathik | Strong [${strongSp}] · Support [${suppSp}] · Rate After Membership!`;
      const ttsText = lang === 'english'
        ? `${mkt}! Today's guessing numbers are ${digSpoken}, with ${probPct} percent accuracy probability! Play rate is shared after taking membership.${nextCardEn}`
        : `${mktHi}! आज के गेसिंग नंबर हैं: ${digSpoken}! इस गेम की सटीक प्रोबेबिलिटी ${probPct} प्रतिशत है, और प्ले रेट मेंबरशिप लेने के बाद बताया जाता है!${nextCardHi}`;
      return { subtitle, ttsText };
    }
    const subtitle = `🎁 ${mkt}: Aaj ke Guessing [${digSpoken}] · ${probPct}% Sathik Probability | Rate: Membership Only!`;
    const ttsText = lang === 'english'
      ? `${mkt}! Today's guessing numbers are ${digSpoken}, with ${probPct} percent accuracy probability! Play rate is shared after taking membership.${nextCardEn}`
      : `${mktHi}! आज के गेसिंग नंबर हैं: ${digSpoken}! इस गेम की सटीक प्रोबेबिलिटी ${probPct} प्रतिशत है, और प्ले रेट मेंबरशिप लेने के बाद बताया जाता है!${nextCardHi}`;
    return { subtitle, ttsText };
  }

  if (ev.action === 'TRAILER_HIGHLIGHT') {
    if (ev.isCloseZeroSkip) {
      const subtitle = `🛡️ ${mkt}: OPEN PASS -> Close Zero ON se Rs 0 Invest (Profit Safe Lock!)`;
      const ttsText = lang === 'english'
        ? `${mkt}: Open passed, so Close Zero skipped at zero rupees to lock profit!${isLastCard ? ` ${endOfCardsTtsEn}` : ''}`
        : `${mktHi} में ओपन पास था, इसलिए क्लोज़ ज़ीरो नियम से ज़ीरो रुपये लगाकर प्रॉफिट सेफ लॉक!${isLastCard ? ` ${endOfCardsTtsHi}` : ''}`;
      return { subtitle, ttsText };
    }
    if (ev.status === 'PASS') {
      const smartTag = ev.isSmartStakeOn ? 'Smart Stake ' : '';
      const recTag = prevLoss > 0 ? ` (Loss Rs ${prevLoss} Recover!)` : '';
      const subtitle = `💥 ${mkt}: [${digSpoken}] ➔ [${ev.actual}] PASS! +Rs ${Math.abs(plNum)}${recTag}`;
      const ttsText = lang === 'english'
        ? `${mkt}: ${smartTag}hit ${ev.actual} PASS for plus Rs ${Math.abs(plNum)}!${isLastCard ? ` ${endOfCardsTtsEn}` : ''}`
        : prevLoss > 0
        ? `और यहाँ ${mktHi} में बड़ा कमबैक! अंक ${ev.actual} पास, पिछला पूरा लॉस कवर और सीधे ${Math.abs(plNum)} रुपये प्रॉफिट!${isLastCard ? ` ${endOfCardsTtsHi}` : ''}`
        : slotNum === 0
        ? `शुरुआत ही धमाकेदार! ${mktHi} में अंक ${ev.actual} सीधा पास, प्लस ${Math.abs(plNum)} रुपये!${isLastCard ? ` ${endOfCardsTtsHi}` : ''}`
        : `${mktHi} में भी अंक ${ev.actual} सीधा पास, मिले ${Math.abs(plNum)} रुपये!${isLastCard ? ` ${endOfCardsTtsHi}` : ''}`;
      return { subtitle, ttsText };
    }
    const nextPlan = isLastCard
      ? (hasPendingAfter ? 'Aage Markets Baki' : 'Aaj Ka Game Complete')
      : (ev.isProfitCarryOn ? 'Loss + Profit Carry' : 'Auto Recovery');
    const subtitle = `⚡ ${mkt}: Result [${ev.actual}] FAIL (-Rs ${Math.abs(plNum)}) ➔ ${nextPlan}!`;
    const ttsText = lang === 'english'
      ? (isLastCard
          ? `${mkt} missed at ${ev.actual}. ${endOfCardsTtsEn}`
          : `${mkt} missed at ${ev.actual}, ${nextPlan} ready next!`)
      : (isLastCard
          ? `${mktHi} में रिज़ल्ट ${ev.actual} मिस हुआ। ${endOfCardsTtsHi}`
          : slotNum === 0
          ? `पहले ${mktHi} में रिज़ल्ट ${ev.actual} मिस हुआ, पर अगले कार्ड में ${ev.isProfitCarryOn ? 'रिकवरी और प्रॉफिट कैरी' : 'ऑटो रिकवरी'} ऑन!`
          : `${mktHi} में रिज़ल्ट ${ev.actual} मिस, अब अगले कार्ड पर रेट बूस्ट!`);
    return { subtitle, ttsText };
  }

  if (ev.isCloseZeroSkip) {
    if (phase === 1) {
      const subtitle = `Step 1 (Close Zero): ${baseMkt} OPEN pehle hi PASS ho chuka hai! Close Zero ON hone se ${mkt} me OPEN ka profit lock hai.`;
      const ttsText = lang === 'english'
        ? `${baseMkt} Open already passed! With Close Zero on, Open profit is safely locked.`
        : `${baseMktHi} ओपन पहले ही पास हो चुका है! क्लोज़ ज़ीरो नियम ऑन होने से, ओपन का प्रॉफिट यहीं लॉक कर लिया गया है।`;
      return { subtitle, ttsText };
    }
    if (phase === 2) {
      const subtitle = `Step 2 (Close Skip Rs 0): Kyunki OPEN pass hua tha, Close Zero rule se ${mkt} me Rs 0 invest (Skip) rakha gaya taaki paisa risk na ho!`;
      const ttsText = lang === 'english'
        ? `Because Open passed, Close Zero sets ${mkt} to Rs 0 investment so zero money is risked.`
        : `क्योंकि ओपन पास था, इसलिए ${mktHi} में ज़ीरो रुपये इन्वेस्ट रखकर कार्ड स्किप किया गया, ताकि कोई रिस्क न रहे।`;
      return { subtitle, ttsText };
    }
    if (ev.status === 'FAIL' && ev.isProfitCarryOn) {
      const subtitle = `Step 3 (Close Zero + Profit Carry): Result [${ev.actual || '--'}] fail raha, par Rs 0 invest se Rs 0 loss hua! ${isLastCard ? endOfCardsSub : `Profit Carry ON hone se +Rs ${baseTarget} target aage carry hua.`}`;
      const ttsText = lang === 'english'
        ? `Close result ${ev.actual} missed with Rs 0 loss. ${isLastCard ? endOfCardsTtsEn : `Profit Carry forwards plus Rs ${baseTarget} target profit.`}`
        : `क्लोज़ रिज़ल्ट ${ev.actual || ''} मिस रहा, पर ज़ीरो इन्वेस्ट होने से ज़ीरो लॉस हुआ! ${isLastCard ? endOfCardsTtsHi : `और प्रॉफिट कैरी से ${baseTarget} रुपये टारगेट आगे जुड़ गया।`}`;
      return { subtitle, ttsText };
    }
    const subtitle = `Step 3 (Close Zero Safe): ${mkt} me Rs 0 invest ki wajah se koi risk nahi laga aur ${baseMkt} OPEN ka profit 100% safe bacha raha! ${isLastCard ? endOfCardsSub : ''}`;
    const ttsText = lang === 'english'
      ? `With Close Zero at Rs 0 investment, your ${baseMkt} Open profit stayed 100 percent safe! ${isLastCard ? endOfCardsTtsEn : ''}`
      : `इस तरह बिना किसी रिस्क के, आपका ${baseMktHi} ओपन का पूरा प्रॉफिट सौ प्रतिशत सेफ बचा रहा! ${isLastCard ? endOfCardsTtsHi : ''}`;
    return { subtitle, ttsText };
  }

  if (phase === 1) {
    if (ev.isSmartStakeOn && ev.strongDigits && ev.supportDigits) {
      const strongSp = formatSpokenDigits(ev.strongDigits);
      const suppSp = formatSpokenDigits(ev.supportDigits);
      const subtitle = `Step 1 (Smart Stake): ${mkt} me Titan Nova Guessing Trick Se Strong digits [${strongSp}] (Booster) aur Support [${suppSp}] (Cover) nikle.`;
      const ttsText = lang === 'english'
        ? `In ${mkt}, Titan Nova Guessing Trick selected Strong digits ${strongSp} and Support digits ${suppSp}.`
        : `अब ${mktHi} में टाइटन नोवा गेसिंग ट्रिक से, स्ट्रॉन्ग अंक ${strongSp} और सपोर्ट अंक ${suppSp} लॉक हुए!`;
      return { subtitle, ttsText };
    }
    if (ev.isFourWaveOn && ev.waveId) {
      const subtitle = `Step 1 (4-Wave ${ev.waveId}): ${mkt} (${ev.waveId} Track) me Titan Nova Guessing Trick Se digits [${digSpoken}] lock kiye gaye.`;
      const ttsText = lang === 'english'
        ? `In ${mkt} on 4-Wave track ${ev.waveId}, Titan Nova Guessing Trick locked digits ${digSpoken}.`
        : `${mktHi} में फोर-वेव ${ev.waveId} ट्रैक पर, टाइटन नोवा गेसिंग ट्रिक से अंक ${digSpoken} लॉक हुए!`;
      return { subtitle, ttsText };
    }
    const subtitle = `Step 1 (Guessing): ${mkt} me Titan Nova Guessing Trick Se guessing digits [${digSpoken}] lock kiye gaye!`;
    const ttsText = lang === 'english'
      ? `In ${mkt}, Titan Nova Guessing Trick locked digits ${digSpoken}.`
      : `अब ${mktHi} में टाइटन नोवा गेसिंग ट्रिक से सटीक अंक ${digSpoken} लॉक किए गए!`;
    return { subtitle, ttsText };
  }

  if (phase === 2) {
    if (ev.isFourWaveOn && ev.waveId) {
      if (prevLoss > 0 || carriedProfit > 0) {
        const pcNote = carriedProfit > 0 ? ` + Profit Carry Rs ${carriedProfit}` : '';
        const subtitle = `Step 2 (4-Wave ${ev.waveId} Recovery): ${ev.waveId} wave ka pichla -Rs ${prevLoss} loss${pcNote} cover karne ke liye rate badha kar Rs ${rateNum} lagaya (Invest Rs ${investNum}).`;
        const ttsText = lang === 'english'
          ? `4-Wave ${ev.waveId} recovery: To recover Rs ${prevLoss} wave loss${carriedProfit > 0 ? ` plus Rs ${carriedProfit} carried profit` : ''}, rate increased to Rs ${rateNum}.`
          : `फोर-वेव ${ev.waveId} का पिछला ${prevLoss} रुपये लॉस${carriedProfit > 0 ? ` और ${carriedProfit} रुपये प्रॉफिट कैरी` : ''} कवर करने के लिए, यहाँ रेट बढ़ा कर ${rateNum} रुपये लगाया गया।`;
        return { subtitle, ttsText };
      }
      const subtitle = `Step 2 (4-Wave ${ev.waveId} Safe Rate): ${ev.waveId} wave me 0 pending loss hai, isliye pichle card ka bojh liye bina safe Base Rate Rs ${rateNum} khela (Invest Rs ${investNum}).`;
      const ttsText = lang === 'english'
        ? `4-Wave ${ev.waveId} has zero debt, so we play at safe Base Rate Rs ${rateNum}.`
        : `फोर-वेव ${ev.waveId} ट्रैक बिल्कुल क्लियर है, इसलिए बिना किसी बोझ के नॉर्मल बेस रेट ${rateNum} रुपये खेला।`;
      return { subtitle, ttsText };
    }

    if (ev.isSmartStakeOn && ev.strongRate && ev.supportRate) {
      const sRate = Math.round(ev.strongRate);
      const supRate = Math.round(ev.supportRate);
      if (prevLoss > 0 || carriedProfit > 0) {
        const pcText = carriedProfit > 0 ? ` + Profit Carry Rs ${carriedProfit}` : '';
        const subtitle = `Step 2 (Smart Stake + Recovery): Pichla -Rs ${prevLoss} loss${pcText} cover karne ke liye Strong @ Rs ${sRate} aur Support @ Rs ${supRate} lagaya (Invest Rs ${investNum}).`;
        const ttsText = lang === 'english'
          ? `Smart Stake recovery: To cover Rs ${prevLoss} loss${carriedProfit > 0 ? ` and Rs ${carriedProfit} profit carry` : ''}, Strong rate is Rs ${sRate} and Support rate is Rs ${supRate}.`
          : `पिछला ${prevLoss} रुपये लॉस${carriedProfit > 0 ? ` और ${carriedProfit} रुपये प्रॉफिट कैरी` : ''} कवर करने के लिए, स्ट्रॉन्ग अंकों पर ${sRate} और सपोर्ट पर ${supRate} रुपये रेट लगाया।`;
        return { subtitle, ttsText };
      }
      const subtitle = `Step 2 (Smart Stake Base): Profit boost ke liye Strong digits @ Rs ${sRate} aur safe cover ke liye Support @ Rs ${supRate} lagaya (Invest Rs ${investNum}).`;
      const ttsText = lang === 'english'
        ? `Smart Stake base play: Strong digits at Rs ${sRate} for profit boost and Support at Rs ${supRate} for cover.`
        : `स्मार्ट स्टेक से प्रॉफिट बूस्ट के लिए स्ट्रॉन्ग पर ${sRate} रुपये, और सेफ कवर के लिए सपोर्ट पर ${supRate} रुपये लगाया।`;
      return { subtitle, ttsText };
    }

    if (prevLoss > 0 || (ev.prevStatus === 'FAIL' && rateDiff > 0)) {
      const lossAmt = prevLoss > 0 ? prevLoss : rateDiff;
      const pcSub = carriedProfit > 0 ? ` aur Profit Carry +Rs ${carriedProfit}` : '';
      const subtitle = `Step 2 (Recovery${carriedProfit > 0 ? ' + Profit Carry' : ''}): Pichla -Rs ${lossAmt} loss${pcSub} cover karne ke liye rate Rs ${prevRateNum} se badha kar Rs ${rateNum} lagaya (Invest Rs ${investNum}).`;
      const ttsText = lang === 'english'
        ? `To recover Rs ${lossAmt} loss${carriedProfit > 0 ? ` plus Rs ${carriedProfit} carried profit` : ''}, rate increased to Rs ${rateNum}.`
        : `पिछला ${lossAmt} रुपये लॉस${carriedProfit > 0 ? ` और ${carriedProfit} रुपये प्रॉफिट कैरी` : ''} कवर करने के लिए, रेट बढ़ा कर ${rateNum} रुपये लगाया।`;
      return { subtitle, ttsText };
    }
    if (carriedProfit > 0) {
      const subtitle = `Step 2 (Profit Carry +Rs ${carriedProfit}): Pichle chhute huye +Rs ${carriedProfit} target profit ko jod kar is card me Rs ${rateNum} rate lagaya (Invest Rs ${investNum}).`;
      const ttsText = lang === 'english'
        ? `Profit Carry added plus Rs ${carriedProfit} target profit, setting rate to Rs ${rateNum}.`
        : `प्रॉफिट कैरी से पिछला ${carriedProfit} रुपये टारगेट जोड़कर, यहाँ ${rateNum} रुपये रेट सेट किया।`;
      return { subtitle, ttsText };
    }
    if (ev.prevStatus === 'PASS') {
      const subtitle = `Step 2 (Base Rate Reset): Pichla card PASS hone ke baad, wapas safe Base Rate Rs ${rateNum} se khela gaya hai (Invest Rs ${investNum}).`;
      const ttsText = lang === 'english'
        ? `After previous PASS, reset back to safe Base Rate Rs ${rateNum}.`
        : `पिछला कार्ड पास होने पर, वापस नॉर्मल बेस रेट ${rateNum} रुपये पर रीसेट किया।`;
      return { subtitle, ttsText };
    }
    const subtitle = `Step 2 (Base Rate): Normal Base Rate Rs ${rateNum} se safe play kiya gaya hai (Total Investment Rs ${investNum}).`;
    const ttsText = lang === 'english'
      ? `Playing at normal Base Rate Rs ${rateNum} with investment Rs ${investNum}.`
      : `नॉर्मल बेस रेट ${rateNum} रुपये से कुल ${investNum} रुपये का सेफ प्ले किया।`;
    return { subtitle, ttsText };
  }

  if (ev.status === 'PASS') {
    if (ev.isCloseZeroOn && isOpenMkt) {
      const subtitle = `Step 3 (OPEN PASS -> Close Zero Trigger!): ${mkt} me [${ev.actual}] PASS (+Rs ${Math.abs(plNum)} Profit)! ${isLastCard ? endOfCardsSub : `Close Zero ON hai, isliye ab ${baseMkt} CLOSE me Rs 0 invest (Skip) rahega!`}`;
      const ttsText = lang === 'english'
        ? `${mkt} hit ${ev.actual} for plus Rs ${Math.abs(plNum)} profit! ${isLastCard ? endOfCardsTtsEn : `Because Close Zero is on, ${baseMkt} Close will now be skipped at Rs 0 investment to lock profit.`}`
        : `रिज़ल्ट ${ev.actual} शानदार पास हुआ और सीधे ${Math.abs(plNum)} रुपये प्रॉफिट मिला! ${isLastCard ? endOfCardsTtsHi : `क्लोज़ ज़ीरो ऑन है, इसलिए अब ${baseMktHi} क्लोज़ में ज़ीरो रुपये रखकर प्रॉफिट लॉक करेंगे!`}`;
      return { subtitle, ttsText };
    }
    if (ev.isFourWaveOn && ev.waveId) {
      const subtitle = `Step 3 (4-Wave ${ev.waveId} PASS!): ${mkt} me [${ev.actual}] PASS (+Rs ${Math.abs(plNum)} Profit)! ${isLastCard ? endOfCardsSub : `${ev.waveId} wave recovery complete, agle ${ev.waveId} card me wapas Base Rate lagega.`}`;
      const ttsText = lang === 'english'
        ? `${mkt} passed on wave ${ev.waveId} with plus Rs ${Math.abs(plNum)} profit! ${isLastCard ? endOfCardsTtsEn : `Wave ${ev.waveId} resets to Base Rate.`}`
        : `रिज़ल्ट ${ev.actual} पास हुआ और ${Math.abs(plNum)} रुपये प्रॉफिट मिला! ${isLastCard ? endOfCardsTtsHi : `वेव ${ev.waveId} की रिकवरी पूरी, अब इसमें वापस बेस रेट लगेगा।`}`;
      return { subtitle, ttsText };
    }
    const nextSub = isLastCard
      ? endOfCardsSub
      : `Ab agle card (${ev.nextMarket}) me wapas Base Rate Rs ${ev.nextRate || baseRateNum} se khelenge!`;
    const subtitle = `Step 3 (Result PASS): ${mkt} me result [${ev.actual}] PASS ho gaya! (+Rs ${Math.abs(plNum)} Profit). ${nextSub}`;
    const ttsText = lang === 'english'
      ? `Result ${ev.actual} passed with plus Rs ${Math.abs(plNum)} profit! ${isLastCard ? endOfCardsTtsEn : 'Next we play at normal Base Rate.'}`
      : `रिज़ल्ट ${ev.actual} शानदार पास, मिले ${Math.abs(plNum)} रुपये प्रॉफिट! ${isLastCard ? endOfCardsTtsHi : 'अब अगला कार्ड वापस बेस रेट से चलेगा।'}`;
    return { subtitle, ttsText };
  }

  if (ev.isFourWaveOn && ev.waveId) {
    const pcNote = ev.isProfitCarryOn ? ` + Rs ${baseTarget} Profit Carry` : '';
    const subtitle = `Step 3 (4-Wave ${ev.waveId} FAIL): Result [${ev.actual}] fail raha (-Rs ${Math.abs(plNum)}). ${isLastCard ? endOfCardsSub : `4-Wave ON hai: iska loss${pcNote} sidha agle ${ev.waveId} wave card me recover hoga!`}`;
    const ttsText = lang === 'english'
      ? `Result ${ev.actual} failed on wave ${ev.waveId}. ${isLastCard ? endOfCardsTtsEn : `Under 4-Wave relay, this loss will be recovered on the next ${ev.waveId} wave card.`}`
      : `रिज़ल्ट ${ev.actual} फेल रहा। ${isLastCard ? endOfCardsTtsHi : `फोर-वेव रिले के चलते यह लॉस${ev.isProfitCarryOn ? ' और प्रॉफिट कैरी' : ''} सीधे अगले ${ev.waveId} वेव कार्ड में रिकवर होगा!`}`;
    return { subtitle, ttsText };
  }

  if (ev.isProfitCarryOn) {
    const targetNext = isOpenMkt ? `${baseMkt} CLOSE` : (ev.nextMarket || 'next recovery card');
    const subtitle = `Step 3 (FAIL + Profit Carry ON): Result [${ev.actual}] fail raha (-Rs ${Math.abs(plNum)}). ${isLastCard ? endOfCardsSub : `Ab ${targetNext} me Rs ${Math.abs(plNum)} loss + Rs ${baseTarget} Profit Carry dono jod kar rate badha kar khelenge!`}`;
    const ttsText = lang === 'english'
      ? `Result ${ev.actual} failed. ${isLastCard ? endOfCardsTtsEn : `With Profit Carry on, both the Rs ${Math.abs(plNum)} loss and Rs ${baseTarget} target profit carry to ${targetNext}.`}`
      : `रिज़ल्ट ${ev.actual} फेल रहा। ${isLastCard ? endOfCardsTtsHi : `प्रॉफिट कैरी ऑन है, इसलिए ${Math.abs(plNum)} रुपये लॉस और ${baseTarget} रुपये टारगेट अगले कार्ड में जुड़कर रिकवर होंगे!`}`;
    return { subtitle, ttsText };
  }

  const nextRateVal = Number(ev.nextRate || 0);
  const nextDiff = nextRateVal > rateNum ? nextRateVal - rateNum : 0;
  const nextSub = isLastCard
    ? endOfCardsSub
    : `Ab agle card (${ev.nextMarket}) me rate badha kar${nextRateVal > rateNum ? ` Rs ${nextRateVal} (+Rs ${nextDiff})` : ''} khelenge!`;
  const subtitle = `Step 3 (Result FAIL): ${mkt} me result [${ev.actual}] FAIL raha (-Rs ${Math.abs(plNum)}). ${nextSub}`;
  const ttsText = lang === 'english'
    ? `Result ${ev.actual} failed. ${isLastCard ? endOfCardsTtsEn : 'Next card we increase rate for recovery.'}`
    : `रिज़ल्ट ${ev.actual} फेल रहा। ${isLastCard ? endOfCardsTtsHi : `अगले कार्ड में लॉस रिकवरी के लिए रेट बढ़ा कर${nextRateVal > rateNum ? ` ${nextRateVal} रुपये से` : ''} खेलेंगे।`}`;
  return { subtitle, ttsText };
}

export function buildStorySubtitle(ev: ActivityTimelineEvent, lang: VideoVoiceLang = 'hinglish'): string {
  return buildStepNarration(ev as StepStoryEvent, lang).subtitle;
}

async function analyzeCustomVoiceSample(
  voiceSampleBase64: string,
  tmpDir: string
): Promise<{ samplePcm: Int16Array | null; detectedPitchShift: number }> {
  try {
    const cleanB64 = String(voiceSampleBase64 || '').replace(/^data:[^;]+;base64,/, '').trim();
    if (!cleanB64) return { samplePcm: null, detectedPitchShift: 0.92 };
    const rawBuf = Buffer.from(cleanB64, 'base64');
    if (rawBuf.byteLength < 128 || rawBuf.byteLength > 8 * 1024 * 1024) {
      return { samplePcm: null, detectedPitchShift: 0.92 };
    }
    const inPath = path.join(tmpDir, 'user_voice_sample.bin');
    const pcmPath = path.join(tmpDir, 'user_voice_sample.pcm');
    fs.writeFileSync(inPath, rawBuf);
    await execFileAsync(
      'ffmpeg',
      ['-y', '-i', inPath, '-t', '3.0', '-af', 'volume=1.5', '-f', 's16le', '-acodec', 'pcm_s16le', '-ar', String(SAMPLE_RATE), '-ac', '1', pcmPath],
      { timeout: 3500, maxBuffer: 4 * 1024 * 1024 }
    );
    if (!fs.existsSync(pcmPath)) return { samplePcm: null, detectedPitchShift: 0.92 };
    const pcmBytes = fs.readFileSync(pcmPath);
    if (pcmBytes.byteLength < 4) return { samplePcm: null, detectedPitchShift: 0.92 };
    const pcm = bufferToInt16Array(pcmBytes);

    let zeroCrossings = 0;
    let activeSamples = 0;
    for (let i = 1; i < pcm.length; i++) {
      if (Math.abs(pcm[i]) > 600) {
        activeSamples++;
        if ((pcm[i - 1] >= 0 && pcm[i] < 0) || (pcm[i - 1] < 0 && pcm[i] >= 0)) {
          zeroCrossings++;
        }
      }
    }
    const zcr = activeSamples > 800 ? zeroCrossings / activeSamples : 0.08;
    const detectedPitchShift = Math.max(0.84, Math.min(1.08, Number((0.78 + zcr * 1.4).toFixed(2))));
    return { samplePcm: pcm, detectedPitchShift };
  } catch {
    return { samplePcm: null, detectedPitchShift: 0.92 };
  }
}

/**
 * Primary Real Human Neural AI Voice Generator via Microsoft Edge ReadAloud Neural TTS:
 * - Male Hindi/Hinglish: `hi-IN-MadhurNeural` (100% genuine studio human Indian Male voice)
 * - Female Hindi/Hinglish: `hi-IN-SwaraNeural` (100% genuine studio human Indian Female voice)
 * - Male English: `en-IN-PrabhatNeural`
 * - Female English: `en-IN-NeerjaNeural`
 */
function splitTtsClauses(text: string, maxLen = 120): string[] {
  const cleaned = String(text || "").replace(/\s+/g, " ").trim();
  if (!cleaned) return [];
  if (cleaned.length <= maxLen) return [cleaned];

  const rawParts = cleaned.split(/(?<=[।.!?|,:;])\s+/);
  const chunks: string[] = [];
  let cur = "";
  for (const part of rawParts) {
    if (!cur) {
      cur = part;
    } else if (`${cur} ${part}`.length <= maxLen) {
      cur = `${cur} ${part}`;
    } else {
      chunks.push(cur);
      cur = part;
    }
  }
  if (cur) chunks.push(cur);

  // If any single clause is still > maxLen, split by words safely
  const finalChunks: string[] = [];
  for (const c of chunks) {
    if (c.length <= maxLen) {
      finalChunks.push(c);
    } else {
      const words = c.split(" ");
      let wCur = "";
      for (const w of words) {
        if (!wCur) wCur = w;
        else if (`${wCur} ${w}`.length <= maxLen) wCur = `${wCur} ${w}`;
        else {
          finalChunks.push(wCur);
          wCur = w;
        }
      }
      if (wCur) finalChunks.push(wCur);
    }
  }
  return finalChunks;
}

function generateSecMsGecToken(): string {
  const TRUSTED_CLIENT_TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4";
  const WIN_EPOCH = 11644473600;
  const ticks = Math.floor((Date.now() / 1000 + WIN_EPOCH) / 300) * 300 * 1e7;
  return crypto
    .createHash("sha256")
    .update(`${ticks.toFixed(0)}${TRUSTED_CLIENT_TOKEN}`, "ascii")
    .digest("hex")
    .toUpperCase();
}

function getVoicePackLabel(pack: VoicePackId = "swara_hi"): string {
  switch (pack) {
    case "swara_hi":
      return "SWARA HINDI NEURAL";
    case "madhur_hi":
      return "MADHUR HINDI NEURAL";
    case "andrew_pro":
      return "ANDREW STUDIO NEURAL";
    case "brian_hype":
      return "BRIAN HYPE NEURAL";
    case "ava_studio":
      return "AVA STUDIO NEURAL";
    case "emma_reels":
      return "EMMA REELS NEURAL";
    case "gemini_flash_tts":
      return "SWARA / MADHUR HINDI";
    case "elevenlabs":
      return "ANDREW / AVA STUDIO";
    case "xai_grok":
      return "BRIAN / EMMA HYPE";
    default:
      return "ORIGINAL NEURAL VOICE";
  }
}

/**
 * Direct Google Gemini Native Audio TTS (gemini-3.1-flash-tts / gemini-2.5-flash-preview-tts)
 * when GEMINI_API_KEY is present, returning raw 24kHz 16-bit mono PCM converted to WAV/MP3.
 */
async function fetchGeminiFlashNativePcm24k(
  text: string,
  gender: "male" | "female"
): Promise<Buffer | null> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  const clean = String(text || "").replace(/\s+/g, " ").trim().slice(0, 280);
  if (!clean) return null;
  const voiceName = gender === "male" ? "Puck" : "Kore";
  const models = ["gemini-3.1-flash-tts", "gemini-2.5-flash-preview-tts"];
  for (const model of models) {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 3200);
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`,
        {
          method: "POST",
          signal: ctrl.signal,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: clean }] }],
            generationConfig: {
              responseModalities: ["AUDIO"],
              speechConfig: {
                voiceConfig: {
                  prebuiltVoiceConfig: { voiceName },
                },
              },
            },
          }),
        }
      );
      clearTimeout(timer);
      if (res.ok) {
        const json: any = await res.json();
        const b64 = json?.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (typeof b64 === "string" && b64.length > 200) {
          const rawPcm24k = Buffer.from(b64, "base64");
          // Wrap 24kHz s16le mono PCM in a standard 44-byte WAV header so FFmpeg can process it uniformly
          const wavHeader = Buffer.alloc(44);
          wavHeader.write("RIFF", 0);
          wavHeader.writeUInt32LE(36 + rawPcm24k.byteLength, 4);
          wavHeader.write("WAVEfmt ", 8);
          wavHeader.writeUInt32LE(16, 16);
          wavHeader.writeUInt16LE(1, 20);
          wavHeader.writeUInt16LE(1, 22);
          wavHeader.writeUInt32LE(24000, 24);
          wavHeader.writeUInt32LE(48000, 28);
          wavHeader.writeUInt16LE(2, 32);
          wavHeader.writeUInt16LE(16, 34);
          wavHeader.write("data", 36);
          wavHeader.writeUInt32LE(rawPcm24k.byteLength, 40);
          return Buffer.concat([wavHeader, rawPcm24k]);
        }
      }
    } catch {}
  }
  return null;
}

/**
 * Direct ElevenLabs v3/v4 API support when ELEVENLABS_API_KEY is configured in environment.
 */
async function fetchElevenLabsNativeMp3(
  text: string,
  gender: "male" | "female"
): Promise<Buffer | null> {
  const apiKey = process.env.ELEVENLABS_API_KEY;
  if (!apiKey) return null;
  const clean = String(text || "").replace(/\s+/g, " ").trim().slice(0, 280);
  if (!clean) return null;
  // Adam (male) / Rachel (female) multilingual voices
  const voiceId = gender === "male" ? "pNInz6obpgDQGcFmaJgB" : "21m00Tcm4TlvDq8ikWAM";
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 3200);
    const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
      method: "POST",
      signal: ctrl.signal,
      headers: {
        "xi-api-key": apiKey,
        "Content-Type": "application/json",
        Accept: "audio/mpeg",
      },
      body: JSON.stringify({
        text: clean,
        model_id: "eleven_multilingual_v2",
        voice_settings: { stability: 0.45, similarity_boost: 0.82, style: 0.55, use_speaker_boost: true },
      }),
    });
    clearTimeout(timer);
    if (res.ok) {
      const ab = await res.arrayBuffer();
      if (ab.byteLength > 256) return Buffer.from(ab);
    }
  } catch {}
  return null;
}

async function fetchEdgeNeuralHumanMp3(
  text: string,
  lang: VideoVoiceLang,
  gender: "male" | "female",
  speedRatio: number,
  voicePack: VoicePackId = "gemini_flash_tts"
): Promise<Buffer | null> {
  const fullClean = String(text || "")
    .replace(/[&<>'"]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!fullClean) return null;
  if (fullClean.length > 260) {
    const clauses = splitTtsClauses(fullClean, 240);
    if (clauses.length > 1) {
      const fetchedParts = await Promise.all(
        clauses.map((cl) => fetchEdgeNeuralHumanMp3(cl, lang, gender, speedRatio, voicePack))
      );
      const parts = fetchedParts.filter((b): b is Buffer => Boolean(b));
      return parts.length > 0 ? Buffer.concat(parts) : null;
    }
  }
  const clean = fullClean.slice(0, 290);

  // Use pure original neural speaker prosody (no artificial pitch-shift cloning!)
  const packSpeedBoost = 1.0;
  const packPitchHz = "+0Hz";

  // 6 Genuinely Distinct Real Human Neural Speakers (no duplicate clones):
  const getDistinctNeuralVoice = (): { voiceName: string; xmlLang: string } => {
    if (voicePack === "swara_hi") return { voiceName: "hi-IN-SwaraNeural", xmlLang: "hi-IN" };
    if (voicePack === "madhur_hi") return { voiceName: "hi-IN-MadhurNeural", xmlLang: "hi-IN" };
    if (voicePack === "andrew_pro" || voicePack === "elevenlabs") return { voiceName: "en-US-AndrewMultilingualNeural", xmlLang: "en-US" };
    if (voicePack === "brian_hype" || voicePack === "xai_grok") return { voiceName: "en-US-BrianMultilingualNeural", xmlLang: "en-US" };
    if (voicePack === "ava_studio") return { voiceName: "en-US-AvaMultilingualNeural", xmlLang: "en-US" };
    if (voicePack === "emma_reels") return { voiceName: "en-US-EmmaMultilingualNeural", xmlLang: "en-US" };

    if (lang === "english") {
      return gender === "male"
        ? { voiceName: "en-IN-PrabhatNeural", xmlLang: "en-IN" }
        : { voiceName: "en-IN-NeerjaNeural", xmlLang: "en-IN" };
    }
    return gender === "male"
      ? { voiceName: "hi-IN-MadhurNeural", xmlLang: "hi-IN" }
      : { voiceName: "hi-IN-SwaraNeural", xmlLang: "hi-IN" };
  };
  const { voiceName, xmlLang } = getDistinctNeuralVoice();
  const effRate = speedRatio * packSpeedBoost;
  const clampedPct = Math.max(-35, Math.min(40, Math.round((effRate - 1.0) * 100)));
  const ratePct = `${clampedPct >= 0 ? "+" : ""}${clampedPct}%`;

  const TRUSTED_CLIENT_TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4";
  const secMsGec = generateSecMsGecToken();
  const muid = crypto.randomBytes(16).toString("hex").toUpperCase();
  const wsUrl = `wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1?TrustedClientToken=${TRUSTED_CLIENT_TOKEN}&Sec-MS-GEC=${secMsGec}&Sec-MS-GEC-Version=1-143.0.3650.75`;

  const wsResult = await new Promise<Buffer | null>((resolve) => {
    let settled = false;
    const audioChunks: Buffer[] = [];
    let ws: WebSocket | null = null;

    const finish = (res: Buffer | null) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try {
        ws?.close();
      } catch {}
      resolve(res);
    };

    const timer = setTimeout(() => finish(null), 6500);

    try {
      ws = new WebSocket(wsUrl, {
        headers: {
          Pragma: "no-cache",
          Origin: "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold",
          "Cache-Control": "no-cache",
          Cookie: `muid=${muid};`,
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0",
        },
        handshakeTimeout: 3000,
      });

      ws.on("error", (err) => {
        console.warn(`[TTS] Edge WS (${voiceName}) failed:`, err?.message || err);
        finish(null);
      });
      ws.on("close", () => {
        const full = Buffer.concat(audioChunks);
        finish(full.byteLength > 256 ? full : null);
      });

      ws.on("open", () => {
        const reqId = crypto.randomBytes(16).toString("hex");
        const configMsg =
          `X-Timestamp:${new Date().toISOString()}\r\n` +
          `Content-Type:application/json; charset=utf-8\r\n` +
          `Path:speech.config\r\n\r\n` +
          `{"context":{"synthesis":{"audio":{"metadataoptions":{"sentenceBoundaryEnabled":"false","wordBoundaryEnabled":"false"},"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}`;
        ws?.send(configMsg);

        const ssmlMsg =
          `X-RequestId:${reqId}\r\n` +
          `Content-Type:application/ssml+xml\r\n` +
          `X-Timestamp:${new Date().toISOString()}Z\r\n` +
          `Path:ssml\r\n\r\n` +
          `<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='${xmlLang}'>` +
          `<voice name='${voiceName}'><prosody pitch='${packPitchHz}' rate='${ratePct}'>${clean}</prosody></voice></speak>`;
        ws?.send(ssmlMsg);
      });

      ws.on("message", (data: Buffer, isBinary: boolean) => {
        if (isBinary) {
          const buf = Buffer.isBuffer(data) ? data : Buffer.from(data);
          if (buf.byteLength > 2) {
            const headerLen = buf.readUInt16BE(0);
            if (buf.byteLength > headerLen + 2) {
              audioChunks.push(buf.subarray(headerLen + 2));
            }
          }
        } else {
          const str = data.toString("utf8");
          if (str.includes("Path:turn.end")) {
            const full = Buffer.concat(audioChunks);
            finish(full.byteLength > 256 ? full : null);
          }
        }
      });
    } catch {
      finish(null);
    }
  });

  if (wsResult && wsResult.byteLength > 256) return wsResult;

  // Automatic fallback: if Termux has Python `edge-tts` installed, use it for the exact same neural speaker!
  try {
    const tmpEdgeMp3 = path.join(os.tmpdir(), `titan_edgetts_${crypto.randomBytes(6).toString("hex")}.mp3`);
    await execFileAsync(
      "edge-tts",
      ["--voice", voiceName, "--rate", ratePct, "--text", clean, "--write-media", tmpEdgeMp3],
      { timeout: 6000, maxBuffer: 2 * 1024 * 1024 }
    );
    if (fs.existsSync(tmpEdgeMp3)) {
      const buf = fs.readFileSync(tmpEdgeMp3);
      try { fs.rmSync(tmpEdgeMp3, { force: true }); } catch {}
      if (buf.byteLength > 256) return buf;
    }
  } catch {}

  return null;
}

async function fetchSingleClauseGoogleMp3(clause: string, tl: string): Promise<Buffer | null> {
  const clean = String(clause || "").replace(/\s+/g, " ").trim();
  if (!clean) return null;
  const q = encodeURIComponent(clean);
  const urls = [
    `https://translate.googleapis.com/translate_tts?ie=UTF-8&tl=${tl}&client=gtx&q=${q}`,
    `https://translate.google.com/translate_tts?ie=UTF-8&tl=${tl}&client=tw-ob&q=${q}`,
    `https://translate.google.co.in/translate_tts?ie=UTF-8&tl=${tl}&client=tw-ob&q=${q}`,
    `https://translate.google.com/translate_tts?ie=UTF-8&tl=${tl}&client=dict-chrome-ex&q=${q}`,
  ];
  for (const url of urls) {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 3200);
      const res = await fetch(url, {
        signal: ctrl.signal,
        headers: {
          "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36",
        },
      });
      clearTimeout(timer);
      if (res.ok) {
        const ab = await res.arrayBuffer();
        if (ab.byteLength > 200) return Buffer.from(ab);
      }
    } catch (_) {}
  }
  return null;
}

/**
 * Splits multi-sentence Hindi/English text into <=85 char clauses and fetches + concatenates
 * the MP3 audio buffers so Google TTS NEVER returns HTTP 400 on Devanagari strings!
 */
async function fetchMultiClauseGoogleMp3(text: string, tl: string): Promise<Buffer | null> {
  const clauses = splitTtsClauses(text, 85);
  if (!clauses.length) return null;
  const buffers: Buffer[] = [];
  for (const clause of clauses) {
    const b = await fetchSingleClauseGoogleMp3(clause, tl);
    if (b) buffers.push(b);
  }
  return buffers.length > 0 ? Buffer.concat(buffers) : null;
}

function buildVocalAfFilter(
  isNativeNeural: boolean,
  gender: "male" | "female",
  safePitch: number,
  safeSpeed: number,
  voicePack: VoicePackId = "gemini_flash_tts"
): string {
  // Pack-specific studio EQ & mastering chain so each of the 5 packs has its signature tone
  const packEq =
    voicePack === "elevenlabs"
      ? "bass=g=4.5:f=110,treble=g=3.5:f=4000,volume=2.85"
      : voicePack === "xai_grok"
      ? "bass=g=3.8:f=120,treble=g=4.8:f=3300,volume=2.9"
      : voicePack === "minimax"
      ? "bass=g=3.0:f=125,treble=g=4.2:f=3600,volume=2.8"
      : voicePack === "heygen"
      ? "bass=g=2.2:f=130,treble=g=3.0:f=3800,volume=2.7"
      : "bass=g=3.2:f=120,treble=g=3.6:f=3500,volume=2.75";

  const trimSilence = "silenceremove=start_periods=1:start_duration=0.02:start_threshold=-50dB";
  if (isNativeNeural) {
    return `aresample=${SAMPLE_RATE},${trimSilence},${packEq}`;
  }

  const packPitchMod =
    voicePack === "elevenlabs"
      ? 0.96
      : voicePack === "xai_grok"
      ? 0.98
      : voicePack === "minimax"
      ? 1.02
      : voicePack === "heygen"
      ? 1.01
      : 1.0;

  const packSpeedMod =
    voicePack === "xai_grok"
      ? 1.06
      : voicePack === "minimax"
      ? 1.03
      : 1.0;

  if (gender === "male") {
    const effPitch = Math.max(0.78, Math.min(0.92, Math.min(0.87, safePitch) * packPitchMod));
    const tempoForSpeed = Math.max(0.65, Math.min(1.45, (safeSpeed * packSpeedMod) / effPitch));
    return `asetrate=${Math.round(24000 * effPitch)},aresample=${SAMPLE_RATE},atempo=${tempoForSpeed.toFixed(2)},${trimSilence},${packEq}`;
  }
  const femPitch = Math.max(0.92, Math.min(1.08, safePitch * packPitchMod));
  const femTempo = Math.max(0.65, Math.min(1.45, (safeSpeed * packSpeedMod) / femPitch));
  return `asetrate=${Math.round(24000 * femPitch)},aresample=${SAMPLE_RATE},atempo=${femTempo.toFixed(2)},${trimSilence},${packEq}`;
}

async function decodeSingleMp3ToPcm(
  mp3Path: string,
  pcmPath: string,
  afFilter: string
): Promise<Int16Array | null> {
  try {
    await execFileAsync(
      "ffmpeg",
      [
        "-y",
        "-i", mp3Path,
        "-af", afFilter,
        "-f", "s16le",
        "-acodec", "pcm_s16le",
        "-ar", String(SAMPLE_RATE),
        "-ac", "1",
        pcmPath,
      ],
      { timeout: 6000, maxBuffer: 4 * 1024 * 1024 }
    );
    if (fs.existsSync(pcmPath)) {
      const raw = fs.readFileSync(pcmPath);
      if (raw.byteLength >= 4) return bufferToInt16Array(raw);
    }
  } catch (_) {}
  return null;
}

async function synthesizeAllTtsClipsBatch(
  texts: string[],
  lang: VideoVoiceLang,
  gender: "male" | "female",
  pitchRatio: number,
  speedRatio: number,
  tmpDir: string,
  voicePack: VoicePackId = "gemini_flash_tts"
): Promise<Array<Int16Array | null>> {
  const tl = lang === "english" ? "en" : "hi";
  const safePitch = Math.max(0.80, Math.min(1.15, Number(pitchRatio) || (gender === "male" ? 0.87 : 1.0)));
  const safeSpeed = Math.max(0.75, Math.min(1.25, Number(speedRatio) || 0.92));
  const toneKey = `${voicePack}|${tl}|${gender}|${safePitch.toFixed(2)}|${safeSpeed.toFixed(2)}`;
  const results: Array<Int16Array | null> = new Array(texts.length).fill(null);
  const toFetchIndices: number[] = [];

  for (let i = 0; i < texts.length; i++) {
    const cacheKey = `${toneKey}|${texts[i]}`;
    const cached = ttsPcmCache.get(cacheKey);
    if (cached) {
      results[i] = cached;
    } else {
      toFetchIndices.push(i);
    }
  }

  if (toFetchIndices.length === 0) return results;

  const mp3Map = new Map<number, { path: string; isNativeNeural: boolean }>();
  const firstIdx = toFetchIndices[0];
  const probeNativeBuf =
    voicePack === "gemini_flash_tts"
      ? await fetchGeminiFlashNativePcm24k(texts[firstIdx], gender)
      : voicePack === "elevenlabs"
      ? await fetchElevenLabsNativeMp3(texts[firstIdx], gender)
      : null;
  const probeEdgeBuf = probeNativeBuf || (await fetchEdgeNeuralHumanMp3(texts[firstIdx], lang, gender, safeSpeed, voicePack));
  const edgeAvailable = Boolean(probeEdgeBuf && probeEdgeBuf.byteLength > 256);

  if (edgeAvailable && probeEdgeBuf) {
    const p0 = path.join(tmpDir, `clip_${firstIdx}.mp3`);
    fs.writeFileSync(p0, probeEdgeBuf);
    mp3Map.set(firstIdx, { path: p0, isNativeNeural: true });

    const remaining = toFetchIndices.slice(1);
    const batchSize = 12;
    for (let b = 0; b < remaining.length; b += batchSize) {
      const slice = remaining.slice(b, b + batchSize);
      const fetched = await Promise.all(
        slice.map(async (origIdx) => {
          const natBuf =
            voicePack === "gemini_flash_tts"
              ? await fetchGeminiFlashNativePcm24k(texts[origIdx], gender)
              : voicePack === "elevenlabs"
              ? await fetchElevenLabsNativeMp3(texts[origIdx], gender)
              : null;
          let eBuf = natBuf || (await fetchEdgeNeuralHumanMp3(texts[origIdx], lang, gender, safeSpeed, voicePack));
          if (!eBuf) {
            // Retry once so we NEVER mix two different voices in the same video!
            eBuf = await fetchEdgeNeuralHumanMp3(texts[origIdx], lang, gender, safeSpeed, voicePack);
          }
          if (eBuf) return { origIdx, buf: eBuf, isNativeNeural: true };
          return { origIdx, buf: null as Buffer | null, isNativeNeural: true };
        })
      );
      for (const item of fetched) {
        if (item.buf) {
          const mp3Path = path.join(tmpDir, `clip_${item.origIdx}.mp3`);
          fs.writeFileSync(mp3Path, item.buf);
          mp3Map.set(item.origIdx, { path: mp3Path, isNativeNeural: item.isNativeNeural });
        }
      }
    }
  } else {
    // Reliable batched Google Multi-Clause TTS (6 steps at a time)
    const batchSize = 12;
    for (let b = 0; b < toFetchIndices.length; b += batchSize) {
      const slice = toFetchIndices.slice(b, b + batchSize);
      const fetched = await Promise.all(
        slice.map(async (origIdx) => {
          const buf = await fetchMultiClauseGoogleMp3(texts[origIdx], tl);
          return { origIdx, buf };
        })
      );
      for (const item of fetched) {
        if (item.buf) {
          const mp3Path = path.join(tmpDir, `clip_${item.origIdx}.mp3`);
          fs.writeFileSync(mp3Path, item.buf);
          mp3Map.set(item.origIdx, { path: mp3Path, isNativeNeural: false });
        }
      }
    }
  }

  const validIndices = Array.from(mp3Map.keys());
  if (validIndices.length > 0) {
    for (let c = 0; c < validIndices.length; c += 12) {
      const chunk = validIndices.slice(c, c + 12);
      const args: string[] = ["-y"];
      for (const idx of chunk) {
        args.push("-i", mp3Map.get(idx)!.path);
      }
      for (let m = 0; m < chunk.length; m++) {
        const idx = chunk[m];
        const meta = mp3Map.get(idx)!;
        const pcmPath = path.join(tmpDir, `clip_${idx}.pcm`);
        const afFilter = buildVocalAfFilter(meta.isNativeNeural, gender, safePitch, safeSpeed, voicePack);
        args.push(
          "-map", `${m}:a`,
          "-af", afFilter,
          "-f", "s16le",
          "-acodec", "pcm_s16le",
          "-ar", String(SAMPLE_RATE),
          "-ac", "1",
          pcmPath
        );
      }
      try {
        await execFileAsync("ffmpeg", args, { timeout: 12000, maxBuffer: 4 * 1024 * 1024 });
        for (const idx of chunk) {
          const pcmPath = path.join(tmpDir, `clip_${idx}.pcm`);
          if (fs.existsSync(pcmPath)) {
            const raw = fs.readFileSync(pcmPath);
            if (raw.byteLength >= 4) {
              const copyBuf = bufferToInt16Array(raw);
              results[idx] = copyBuf;
              setCachedPcm(`${toneKey}|${texts[idx]}`, copyBuf);
            }
          }
        }
      } catch (_) {
        // Fallback: decode each MP3 in this chunk individually so no voice clip is ever lost
        for (const idx of chunk) {
          const meta = mp3Map.get(idx)!;
          const pcmPath = path.join(tmpDir, `clip_single_${idx}.pcm`);
          const afFilter = buildVocalAfFilter(meta.isNativeNeural, gender, safePitch, safeSpeed, voicePack);
          const singlePcm = await decodeSingleMp3ToPcm(meta.path, pcmPath, afFilter);
          if (singlePcm) {
            results[idx] = singlePcm;
            setCachedPcm(`${toneKey}|${texts[idx]}`, singlePcm);
          }
        }
      }
    }
  }

  return results;
}

function generateMasterAudioWav(
  wavPath: string,
  durationSec: number,
  musicStyle: VideoMusicStyle,
  stepChimes: Array<{ timeSec: number; phase: number; isPass: boolean; isFail: boolean }>,
  voiceClips: Array<{ startSec: number; pcm: Int16Array | null }>
) {
  const totalSamples = Math.max(1, Math.floor(SAMPLE_RATE * durationSec));
  const dataBytes = totalSamples * 2;
  const header = Buffer.alloc(44);
  header.write('RIFF', 0);
  header.writeUInt32LE(36 + dataBytes, 4);
  header.write('WAVEfmt ', 8);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(1, 22);
  header.writeUInt32LE(SAMPLE_RATE, 24);
  header.writeUInt32LE(SAMPLE_RATE * 2, 28);
  header.writeUInt16LE(2, 32);
  header.writeUInt16LE(16, 34);
  header.write('data', 36);
  header.writeUInt32LE(dataBytes, 40);

  const voiceFloat = new Float32Array(totalSamples);
  const voiceActive = new Uint8Array(totalSamples);
  const sortedClips = voiceClips
    .filter((vc) => vc.pcm && vc.pcm.length > 0)
    .slice()
    .sort((a, b) => a.startSec - b.startSec);

  const fadeSamples = Math.floor(0.03 * SAMPLE_RATE); // 30ms smooth fade-out at clip boundary
  const gapSamples = Math.floor(0.04 * SAMPLE_RATE);  // 40ms clean silence gap before next clip

  for (let cIdx = 0; cIdx < sortedClips.length; cIdx++) {
    const vc = sortedClips[cIdx];
    const pcmData = vc.pcm!;
    const startIdx = Math.max(0, Math.floor(vc.startSec * SAMPLE_RATE));
    const nextClipStart = cIdx + 1 < sortedClips.length
      ? Math.max(startIdx, Math.floor(sortedClips[cIdx + 1].startSec * SAMPLE_RATE) - gapSamples)
      : totalSamples;
    const maxEndIdx = Math.min(totalSamples, nextClipStart);
    const maxLen = Math.max(0, maxEndIdx - startIdx);
    const copyLen = Math.min(pcmData.length, maxLen);

    for (let j = 0; j < copyLen; j++) {
      let env = 1.0;
      if (copyLen < pcmData.length && j >= copyLen - fadeSamples) {
        env = Math.max(0, (copyLen - j) / Math.max(1, fadeSamples));
      }
      voiceFloat[startIdx + j] = (pcmData[j] / 32768) * env;
      voiceActive[startIdx + j] = 1;
    }
  }

  const pcm = Buffer.alloc(dataBytes);
  const baseFreq = musicStyle === 'cinematic_bass' ? 110 : musicStyle === 'lofi_chill' ? 130.81 : 146.83;

  for (let i = 0; i < totalSamples; i++) {
    const t = i / SAMPLE_RATE;
    let musicSample = 0;

    if (musicStyle !== 'off') {
      const beat = (t * 2.0) % 1.0;
      const env = Math.exp(-beat * 3.5);
      const bass = Math.sin(2 * Math.PI * baseFreq * t) * 0.08 * env;
      const fifth = Math.sin(2 * Math.PI * (baseFreq * 1.5) * t) * 0.035;
      const octave = Math.sin(2 * Math.PI * (baseFreq * 2) * t + Math.sin(t * 1.5)) * 0.025;
      musicSample += bass + fifth + octave;
      if (voiceActive[i]) {
        musicSample *= 0.12;
      }
    }

    let sfxSample = 0;
    if (t < 1.1) {
      const impact = Math.sin(2 * Math.PI * (95 - t * 35) * t) * Math.exp(-t * 3.8) * 0.24;
      const riser = Math.sin(2 * Math.PI * (220 + t * 420) * t) * Math.exp(-t * 2.5) * 0.14;
      sfxSample += impact + riser;
    }

    for (const st of stepChimes) {
      const dt = t - st.timeSec;
      if (dt >= 0 && dt < 0.5) {
        if (st.isPass) {
          const f = dt < 0.15 ? 523.25 : dt < 0.3 ? 659.25 : 783.99;
          sfxSample += Math.sin(2 * Math.PI * f * dt) * Math.exp(-dt * 5.0) * 0.15;
        } else if (st.isFail) {
          sfxSample += Math.sin(2 * Math.PI * 220 * dt) * Math.exp(-dt * 6.5) * 0.11;
        } else if (st.phase === 2) {
          sfxSample += Math.sin(2 * Math.PI * 587.33 * dt) * Math.exp(-dt * 12.0) * 0.09;
        } else {
          sfxSample += Math.sin(2 * Math.PI * 440 * dt) * Math.exp(-dt * 14.0) * 0.09;
        }
      }
    }

    const combined = musicSample + sfxSample + voiceFloat[i];
    const clamped = Math.max(-0.97, Math.min(0.97, combined));
    pcm.writeInt16LE(Math.round(clamped * 32767), i * 2);
  }

  fs.writeFileSync(wavPath, Buffer.concat([header, pcm]));
}

// ============================================================================
// TRUE 3D MOTION GRAPHICS, FLYING-PIECE ASSEMBLY & LASER NAME-WRITING ENGINE
// ============================================================================

function easeOutBack(t: number): number {
  const c = Math.max(0, Math.min(1, t));
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(c - 1, 3) + c1 * Math.pow(c - 1, 2);
}

function easeOutCubic(t: number): number {
  const c = Math.max(0, Math.min(1, t));
  return 1 - Math.pow(1 - c, 3);
}

/**
 * 3D Perspective & Scale Blitter:
 * Renders a modular transparent sprite at (centerX, centerY) with 3D Z-depth scale
 * (scaleX, scaleY), 3D pitch keystone (tiltX), and 3D yaw skew (tiltY).
 */
function blitSprite3D(
  dest: Uint8Array,
  destW: number,
  destH: number,
  src: Uint8Array,
  srcW: number,
  srcH: number,
  centerX: number,
  centerY: number,
  scaleX = 1.0,
  scaleY = 1.0,
  tiltX = 0.0,
  tiltY = 0.0,
  clipTop = 0,
  clipBottom = destH
) {
  const outW = Math.max(2, Math.round(srcW * scaleX));
  const outH = Math.max(2, Math.round(srcH * scaleY));
  const topY = Math.round(centerY - outH / 2);

  for (let oy = 0; oy < outH; oy++) {
    const sy = Math.min(srcH - 1, Math.max(0, Math.floor((oy * srcH) / outH)));
    const normY = oy / outH - 0.5;
    const perspFactor = Math.max(0.22, 1 + normY * tiltX);
    const rowW = Math.max(2, Math.round(outW * perspFactor));
    const rowLeftX = Math.round(centerX - rowW / 2);
    const syRowOffset = sy * srcW;

    for (let ox = 0; ox < rowW; ox++) {
      const dx = rowLeftX + ox;
      if (dx < 0 || dx >= destW) continue;
      const normX = ox / rowW - 0.5;
      const skewY = tiltY !== 0 ? Math.round(normX * tiltY * 34) : 0;
      const dy = topY + oy + skewY;
      if (dy < clipTop || dy >= clipBottom || dy < 0 || dy >= destH) continue;

      const sx = Math.min(srcW - 1, Math.max(0, Math.floor((ox * srcW) / rowW)));
      const sOff = (syRowOffset + sx) * 4;
      if (src[sOff + 3] > 80) {
        const dOff = (dy * destW + dx) * 4;
        dest[dOff] = src[sOff];
        dest[dOff + 1] = src[sOff + 1];
        dest[dOff + 2] = src[sOff + 2];
        dest[dOff + 3] = 255;
      }
    }
  }
}

function drawCometTrail(
  workFrame: ReturnType<typeof makeSprite>,
  fromX: number,
  fromY: number,
  curX: number,
  curY: number,
  col1: string,
  col2: string
) {
  for (let k = 1; k <= 7; k++) {
    const ratio = k / 8;
    const tx = Math.round(curX + (fromX - curX) * ratio * 0.35);
    const ty = Math.round(curY + (fromY - curY) * ratio * 0.35);
    const sz = Math.max(3, 14 - k * 2);
    workFrame.fastBox(tx - Math.floor(sz / 2), ty - Math.floor(sz / 2), sz, sz, k % 2 === 0 ? col1 : col2);
  }
}

function drawShockwaveAndSparks(
  workFrame: ReturnType<typeof makeSprite>,
  cx: number,
  cy: number,
  prog: number,
  col1: string,
  col2: string,
  maxRadius = 180
) {
  if (prog <= 0 || prog >= 1) return;
  const r = prog * maxRadius;
  const ringThick = Math.max(2, Math.round((1 - prog) * 7));
  const numPts = 24;
  for (let i = 0; i < numPts; i++) {
    const ang = (i / numPts) * Math.PI * 2 + prog * 1.8;
    const rx = Math.round(cx + Math.cos(ang) * r);
    const ry = Math.round(cy + Math.sin(ang) * (r * 0.65));
    workFrame.fastBox(rx - ringThick, ry - ringThick, ringThick * 2, ringThick * 2, i % 2 === 0 ? col1 : col2);

    // High-velocity sparks flying further out
    const sparkR = r * 1.25 + (i % 3) * 14;
    const sx = Math.round(cx + Math.cos(ang + 0.15) * sparkR);
    const sy = Math.round(cy + Math.sin(ang + 0.15) * (sparkR * 0.7));
    workFrame.fastBox(sx - 2, sy - 2, 5, 5, "#FFFFFF");
  }
}

function drawLaserBeam(
  workFrame: ReturnType<typeof makeSprite>,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  coreHex: string,
  glowHex: string,
  frameNum: number
) {
  const steps = 28;
  for (let s = 0; s <= steps; s++) {
    const t = s / steps;
    const lx = Math.round(x1 + (x2 - x1) * t);
    const ly = Math.round(y1 + (y2 - y1) * t);
    workFrame.fastBox(lx - 4, ly - 4, 8, 8, glowHex);
    workFrame.fastBox(lx - 2, ly - 2, 4, 4, coreHex);
  }
  // Blazing laser head & welding sparks at target (x2, y2)
  workFrame.fastBox(Math.round(x2) - 12, Math.round(y2) - 12, 24, 24, glowHex);
  workFrame.fastBox(Math.round(x2) - 7, Math.round(y2) - 7, 14, 14, "#FFFFFF");
  for (let sp = 0; sp < 14; sp++) {
    const a = (sp / 14) * Math.PI * 2 + frameNum * 0.7;
    const dist = 10 + ((frameNum * 17 + sp * 13) % 46);
    const sx = Math.round(x2 + Math.cos(a) * dist);
    const sy = Math.round(y2 + Math.sin(a) * dist);
    workFrame.fastBox(sx - 2, sy - 2, 5, 5, sp % 2 === 0 ? "#FFC107" : "#FFFFFF");
  }
}

/**
 * Renders a 3D Perspective Cyber Tunnel & Radial Warp Starfield Background
 * on every frame so the background itself is a true 3D moving space.
 */
const cyberBgLoopCache = new Map<string, Uint8Array[]>();
function getCachedCyberTunnelFrame(frameNum: number, primaryColor: string, bgHex = "#060C16"): Uint8Array {
  const key = `${primaryColor}|${bgHex}`;
  let frames = cyberBgLoopCache.get(key);
  if (!frames) {
    frames = [];
    for (let f = 0; f < 16; f++) {
      const sp = makeSprite(WIDTH, HEIGHT);
      draw3DCyberTunnelBg(sp, f, primaryColor, bgHex);
      frames.push(new Uint8Array(sp.buf));
    }
    cyberBgLoopCache.set(key, frames);
  }
  return frames[frameNum % frames.length];
}

function draw3DCyberTunnelBg(
  workFrame: ReturnType<typeof makeSprite>,
  frameNum: number,
  primaryColor: string,
  bgHex = "#060C16"
) {
  workFrame.fastBox(0, 0, WIDTH, HEIGHT, bgHex);
  const vanishX = 270;
  const vanishY = 470;

  // Moving 3D depth rings expanding from vanishing point
  for (let ring = 0; ring < 6; ring++) {
    const zProg = ((frameNum * 0.045 + ring / 6) % 1.0);
    const persp = zProg * zProg;
    const rw = Math.round(80 + persp * 520);
    const rh = Math.round(120 + persp * 880);
    const rx = Math.round(vanishX - rw / 2);
    const ry = Math.round(vanishY - rh / 2);
    const ringCol = ring % 2 === 0 ? "#0E2034" : "#122840";
    workFrame.fastBox(rx, ry, rw, rh, undefined, ringCol, 1);
  }

  // 36 Radial 3D Warp Stars rushing past camera
  for (let s = 0; s < 36; s++) {
    const angle = (s * 2.39996) % (Math.PI * 2);
    const z = 1.0 - (((frameNum * (0.035 + (s % 4) * 0.008)) + s * 0.17) % 0.96);
    const proj = 1.0 / Math.max(0.06, z);
    const sx = Math.round(vanishX + Math.cos(angle) * 42 * proj);
    const sy = Math.round(vanishY + Math.sin(angle) * 68 * proj);
    if (sx >= 4 && sx < WIDTH - 4 && sy >= 4 && sy < HEIGHT - 4) {
      const sz = z < 0.28 ? 6 : z < 0.55 ? 4 : 2;
      const col = s % 3 === 0 ? primaryColor : s % 3 === 1 ? "#FFC107" : "#64B5F6";
      workFrame.fastBox(sx, sy, sz, sz, col);
      if (z < 0.45) {
        const tailX = Math.round(vanishX + Math.cos(angle) * 42 * (proj * 0.88));
        const tailY = Math.round(vanishY + Math.sin(angle) * 68 * (proj * 0.88));
        workFrame.fastBox(tailX, tailY, Math.max(2, sz - 2), Math.max(2, sz - 2), "#1D3B58");
      }
    }
  }
}

/**
 * Helper to fly a 3D piece from (fromX, fromY, fromScale, fromTiltX, fromTiltY)
 * to (toX, toY, 1.0, 0, 0) during normalized window [startT .. endT],
 * with comet trails while flying, shockwave on assembly impact, and 3D hover afterwards.
 */
function flyAndAssemble3DPiece(
  workFrame: ReturnType<typeof makeSprite>,
  spBuf: Uint8Array,
  spW: number,
  spH: number,
  sceneT: number,
  startT: number,
  endT: number,
  fromX: number,
  fromY: number,
  toX: number,
  toY: number,
  fromScale: number,
  fromTiltX: number,
  fromTiltY: number,
  trailCol1: string,
  trailCol2: string,
  frameNum: number,
  hoverSeed = 0,
  clipTop = 0,
  clipBottom = HEIGHT
) {
  if (sceneT < startT) return;
  const rawP = (sceneT - startT) / Math.max(0.01, endT - startT);
  if (rawP < 1.0) {
    const ePos = easeOutBack(rawP);
    const eRot = easeOutCubic(rawP);
    const curX = fromX + (toX - fromX) * ePos;
    const curY = fromY + (toY - fromY) * ePos;
    const curScale = fromScale + (1.0 - fromScale) * eRot;
    const curTiltX = fromTiltX * (1 - eRot);
    const curTiltY = fromTiltY * (1 - eRot);

    drawCometTrail(workFrame, fromX, fromY, curX, curY, trailCol1, trailCol2);
    blitSprite3D(
      workFrame.buf,
      WIDTH,
      HEIGHT,
      spBuf,
      spW,
      spH,
      curX,
      curY,
      curScale,
      curScale,
      curTiltX,
      curTiltY,
      clipTop,
      clipBottom
    );
    if (rawP > 0.78) {
      const impactP = (rawP - 0.78) / 0.22;
      drawShockwaveAndSparks(workFrame, toX, toY, impactP, trailCol1, trailCol2, Math.max(spW, spH) * 0.65);
    }
  } else {
    // Continuous 3D floating & perspective breathing after assembly so it NEVER looks like a static image
    const hoverY = toY + Math.sin(frameNum * 0.26 + hoverSeed) * 2.5;
    const hoverTiltY = Math.sin(frameNum * 0.22 + hoverSeed) * 0.06;
    const hoverScale = 1.0 + Math.sin(frameNum * 0.3 + hoverSeed) * 0.015;
    blitSprite3D(
      workFrame.buf,
      WIDTH,
      HEIGHT,
      spBuf,
      spW,
      spH,
      toX,
      hoverY,
      hoverScale,
      hoverScale,
      0,
      hoverTiltY,
      clipTop,
      clipBottom
    );
  }
}

interface DigitTile3D {
  tok: string;
  normalBuf: Uint8Array;
  winBuf: Uint8Array;
  w: number;
  h: number;
  targetCenterX: number;
  targetCenterY: number;
  fromX: number;
  fromY: number;
  isWinner: boolean;
}

interface CardVisualGroup {
  cardSlot: number;
  market: string;
  status: string;
  actual: string;
  borderColPassFail: string;
  // Modular 3D pieces for this card:
  chassisBuf: Uint8Array;      // 492 x 490
  headerBuf: Uint8Array;       // 468 x 88
  sec1BoxBuf: Uint8Array;      // 460 x 124 (Trick banner & empty slot bed)
  digitTiles: DigitTile3D[];   // Individual flying 3D digit tiles
  sec2BoxBuf: Uint8Array;      // 460 x 112 (Rate logic frame)
  sec2BadgeLeft: Uint8Array;   // 140 x 48
  sec2BadgeMid: Uint8Array;    // 140 x 48
  sec2BadgeRight: Uint8Array;  // 134 x 48
  sec3BoxBuf: Uint8Array;      // 460 x 112 (Result frame & next card plan)
  stamp3DBuf: Uint8Array;      // 296 x 54 (Giant 3D SLAM stamp)
  cardTtsText: string;
}

function buildCard3DPieces(
  ev: StepStoryEvent,
  cardNumber: number,
  totalCards: number,
  primaryColor: string
): Omit<CardVisualGroup, "cardSlot" | "cardTtsText"> {
  const rateNum = Number(ev.rate || 0);
  const prevRateNum = Number(ev.prevRate || ev.baseRate || rateNum);
  const baseRateNum = Number(ev.baseRate || prevRateNum || rateNum);
  const rateDiff = ev.rateDiff !== undefined ? ev.rateDiff : Math.max(0, rateNum - prevRateNum);
  const investNum = Math.round(Number(ev.invest || 0));
  const prevLoss = Math.round(Number(ev.prevLoss || 0));
  const carriedProfit = Math.round(Number(ev.carriedProfit || 0));
  const baseTarget = Math.round(Number(ev.baseTargetProfit || 100));
  const isUnboxingCard = ev.action === "UNBOXING_REVEAL";
  const isPass = ev.status === "PASS";
  const isFail = ev.status === "FAIL";
  const isOpenMkt = /\s+OPEN$/i.test(ev.market || "");
  const baseMktName = String(ev.market || "").replace(/\s+(OPEN|CLOSE)$/i, "").trim();
  const trickTag = "TITAN NOVA TRICK";

  const borderColPassFail = isUnboxingCard
    ? "#FFC107"
    : ev.isCloseZeroSkip
    ? "#00E5FF"
    : isPass
    ? "#00E676"
    : isFail
    ? "#FF5252"
    : primaryColor;

  // 1. 3D Card Chassis (492 x 490)
  const chassisSp = makeSprite(492, 490);
  chassisSp.fastBox(0, 0, 492, 490, "#0C1624", primaryColor, 4);
  chassisSp.fastBox(8, 8, 476, 474, "#0F1B2B", "#1E344E", 2);
  // Corner 3D cyber brackets
  chassisSp.fastBox(0, 0, 36, 8, "#FFC107");
  chassisSp.fastBox(0, 0, 8, 36, "#FFC107");
  chassisSp.fastBox(456, 0, 36, 8, "#FFC107");
  chassisSp.fastBox(484, 0, 8, 36, "#FFC107");
  chassisSp.fastBox(0, 482, 36, 8, "#FFC107");
  chassisSp.fastBox(0, 454, 8, 36, "#FFC107");
  chassisSp.fastBox(456, 482, 36, 8, "#FFC107");
  chassisSp.fastBox(484, 454, 8, 36, "#FFC107");

  const unboxDigitCnt = String(ev.digits || "--").split(/[,|\s]+/).filter(Boolean).slice(0, 8).length || 5;
  const unboxProbPct = Math.min(92, Math.max(68, Math.round(unboxDigitCnt * 10 + (ev.isSmartStakeOn ? 18 : 14))));

  // 2. Flying Market Header (468 x 88)
  const headerSp = makeSprite(468, 88);
  headerSp.fastBox(0, 0, 468, 52, "#16283E", primaryColor, 2);
  headerSp.fastBox(10, 9, 118, 34, "#0A131F", "#FFC107", 2);
  headerSp.drawText(`CARD #${cardNumber}/${totalCards}`, 69, 31, 13, "#FFC107", 108, "center");
  headerSp.drawText(ev.market || "MARKET", 140, 34, 21, "#FFFFFF", 218, "left");

  if (ev.isCloseZeroSkip) {
    headerSp.fastBox(356, 9, 102, 34, "#08323D", "#00E5FF", 2);
    headerSp.drawText("CLOSE ZERO", 407, 31, 11, "#00E5FF", 92, "center");
  } else if (ev.isFourWaveOn && ev.waveId) {
    headerSp.fastBox(366, 9, 92, 34, "#241538", "#B85CFF", 2);
    headerSp.drawText(`WAVE ${ev.waveId}`, 412, 31, 12, "#E0B0FF", 82, "center");
  } else if (ev.isSmartStakeOn) {
    headerSp.fastBox(356, 9, 102, 34, "#0E2E22", "#00E676", 2);
    headerSp.drawText("SMART STAKE", 407, 31, 10, "#00E676", 94, "center");
  } else {
    headerSp.fastBox(366, 9, 92, 34, "#102030", primaryColor, 1);
    headerSp.drawText(ev.date?.slice(5) || "LIVE", 412, 31, 12, "#8DA6C0", 80, "center");
  }

  headerSp.fastBox(0, 56, 150, 30, "#0C2D42", "#20DCE9", 2);
  headerSp.drawText(isUnboxingCard ? "1. AAJ KA GUESSING" : "STEP 1: TRICK", 75, 76, 11, "#20DCE9", 140, "center");
  headerSp.fastBox(159, 56, 150, 30, "#332609", "#FFC107", 2);
  headerSp.drawText(isUnboxingCard ? `2. ${unboxProbPct}% SATHIK` : "STEP 2: RATE LOGIC", 234, 76, 11, "#FFC107", 140, "center");
  headerSp.fastBox(318, 56, 150, 30, isUnboxingCard ? "#2E2107" : isPass ? "#0B3321" : "#36131A", borderColPassFail, 2);
  headerSp.drawText(isUnboxingCard ? "3. VIP MEMBERSHIP" : "STEP 3: RESULT", 393, 76, 11, borderColPassFail, 140, "center");

  // 3. Step 1 Trick Container (460 x 124)
  const sec1Sp = makeSprite(460, 124);
  sec1Sp.fastBox(0, 0, 460, 124, "#0C1E30", "#20DCE9", 3);
  sec1Sp.drawText(
    isUnboxingCard
      ? "🎁 AAJ KE LIYE SPECIAL GUESSING NUMBERS:"
      : ev.isSmartStakeOn
      ? "1. TITAN NOVA GUESSING TRICK (SMART STAKE):"
      : "1. TITAN NOVA GUESSING TRICK SE:",
    14,
    24,
    12,
    isUnboxingCard ? "#FFC107" : "#20DCE9",
    305,
    "left"
  );
  sec1Sp.fastBox(322, 7, 128, 24, "#192C42", "#FFC107", 1);
  sec1Sp.drawText(trickTag, 386, 23, 10, "#FFC107", 120, "center");
  sec1Sp.drawText(
    ev.isCloseZeroSkip
      ? `>> ${baseMktName} OPEN PASS -> Close Zero Protection Active!`
      : ev.isSmartStakeOn && ev.strongDigits
      ? `>> Strong [${ev.strongDigits}] (Boost) | Support [${ev.supportDigits || "--"}] (Cover)`
      : `>> Titan Nova Guessing Trick Se top digits 3D lock kiye gaye`,
    14,
    112,
    11,
    "#8DC8FF",
    432,
    "left"
  );

  // 4. Individual 3D Flying Digit Tiles
  const strongSet = new Set(String(ev.strongDigits || "").split(/[,|\s]+/).filter(Boolean));
  const digitTokens = String(ev.digits || "--").split(/[,|\s]+/).filter(Boolean).slice(0, 8);
  const pillCount = Math.max(1, digitTokens.length);
  const totalPillsW = 432;
  const gap = 10;
  const boxW = Math.min(84, Math.floor((totalPillsW - gap * (pillCount - 1)) / pillCount));
  const boxH = 54;
  const startDigitX = 30 + Math.floor((totalPillsW - (boxW * pillCount + gap * (pillCount - 1))) / 2);

  const digitTiles: DigitTile3D[] = digitTokens.map((tok, dIdx) => {
    const isStrongTok = ev.isSmartStakeOn && strongSet.has(tok);
    const isWinner = isPass && Boolean(ev.actual) && String(tok).trim() === String(ev.actual).trim();

    const normSp = makeSprite(boxW, boxH);
    normSp.fastBox(0, 0, boxW, boxH, isStrongTok ? "#0D3324" : "#152C44", isStrongTok ? "#00E676" : "#20DCE9", 3);
    normSp.fastBox(4, 4, boxW - 8, 8, isStrongTok ? "#00E676" : "#20DCE9");
    normSp.drawText(tok, boxW / 2, 40, 22, "#FFFFFF", boxW - 8, "center");

    const winSp = makeSprite(boxW, boxH);
    winSp.fastBox(0, 0, boxW, boxH, "#0B4628", "#00E676", 4);
    winSp.fastBox(4, 4, boxW - 8, 10, "#FFC107");
    winSp.drawText(tok, boxW / 2, 40, 24, "#00E676", boxW - 6, "center");

    const cardLocalX = startDigitX + dIdx * (boxW + gap) + boxW / 2;
    const screenTargetX = 24 + cardLocalX;
    const screenTargetY = 188 + 146 + boxH / 2;

    const directions = [
      [-180, 120],
      [720, 120],
      [-180, 420],
      [720, 420],
      [270, -140],
      [270, 980],
    ];
    const [fx, fy] = directions[dIdx % directions.length];

    return {
      tok,
      normalBuf: normSp.buf,
      winBuf: winSp.buf,
      w: boxW,
      h: boxH,
      targetCenterX: screenTargetX,
      targetCenterY: screenTargetY,
      fromX: fx,
      fromY: fy,
      isWinner,
    };
  });

  // 5. Step 2 Rate Logic Container (460 x 112) + 3 Flying Rate Sub-Badges
  const sec2Sp = makeSprite(460, 112);
  sec2Sp.fastBox(0, 0, 460, 112, "#1C1609", "#FFC107", 3);

  const bLeft = makeSprite(140, 48);
  const bMid = makeSprite(140, 48);
  const bRight = makeSprite(134, 48);

  if (ev.isCloseZeroSkip) {
    sec2Sp.drawText("2. CLOSE ZERO LOGIC (OPEN WON -> CLOSE Rs 0 SKIP):", 14, 23, 12, "#00E5FF", 432, "left");
    sec2Sp.drawText("Open pass hone se Close me Rs 0 invest rakha taaki profit lock rahe!", 14, 102, 11, "#80DEEA", 432, "left");

    bLeft.fastBox(0, 0, 140, 48, "#082E38", "#00E5FF", 2);
    bLeft.drawText("OPEN RESULT", 70, 17, 9, "#00E5FF", 128, "center");
    bLeft.drawText("WON (PASS)", 70, 39, 15, "#FFFFFF", 128, "center");

    bMid.fastBox(0, 0, 140, 48, "#082E38", "#FFC107", 2);
    bMid.drawText("CLOSE RATE", 70, 17, 9, "#FFC107", 128, "center");
    bMid.drawText("Rs 0 (SKIP)", 70, 39, 16, "#FFFFFF", 128, "center");

    bRight.fastBox(0, 0, 134, 48, "#0D2E20", "#00E676", 2);
    bRight.drawText("PROFIT LOCK", 67, 17, 9, "#00E676", 122, "center");
    bRight.drawText("100% SAFE", 67, 39, 15, "#00E676", 122, "center");
  } else if (ev.isSmartStakeOn && ev.strongRate && ev.supportRate) {
    const sRate = Math.round(ev.strongRate);
    const supRate = Math.round(ev.supportRate);
    sec2Sp.drawText(
      prevLoss > 0 || carriedProfit > 0
        ? `2. SMART STAKE RECOVERY (LOSS -Rs ${prevLoss}${carriedProfit > 0 ? ` + CARRY Rs ${carriedProfit}` : ""}):`
        : "2. SMART STAKE DUAL RATE (BOOSTER + COVER):",
      14,
      23,
      11,
      "#00E676",
      432,
      "left"
    );
    sec2Sp.drawText("Strong digits par profit boost + Support digits par loss cover", 14, 102, 11, "#FFE082", 432, "left");

    bLeft.fastBox(0, 0, 140, 48, "#0D3324", "#00E676", 2);
    bLeft.drawText("STRONG RATE", 70, 17, 9, "#00E676", 128, "center");
    bLeft.drawText(`Rs ${sRate}`, 70, 39, 17, "#FFFFFF", 128, "center");

    bMid.fastBox(0, 0, 140, 48, "#142638", "#20DCE9", 2);
    bMid.drawText("SUPPORT RATE", 70, 17, 9, "#20DCE9", 128, "center");
    bMid.drawText(`Rs ${supRate}`, 70, 39, 17, "#FFFFFF", 128, "center");

    bRight.fastBox(0, 0, 134, 48, "#2E2208", "#FFC107", 2);
    bRight.drawText("TOTAL INVEST", 67, 17, 9, "#FFC107", 122, "center");
    bRight.drawText(`Rs ${investNum}`, 67, 39, 16, "#FFFFFF", 122, "center");
  } else if (ev.isFourWaveOn && ev.waveId) {
    sec2Sp.drawText(`2. 4-WAVE RELAY LOGIC (WAVE ${ev.waveId} TRACK):`, 14, 23, 12, "#E0B0FF", 432, "left");
    sec2Sp.drawText(
      prevLoss > 0
        ? `Wave ${ev.waveId} ke pichle fail ka Rs ${prevLoss} loss recover karne rate badhaya`
        : `Wave ${ev.waveId} me 0 debt hai -> Safe Base Rate play!`,
      14,
      102,
      11,
      "#E0B0FF",
      432,
      "left"
    );

    bLeft.fastBox(0, 0, 140, 48, "#241538", "#B85CFF", 2);
    bLeft.drawText(`${ev.waveId} PREV LOSS`, 70, 17, 9, "#E0B0FF", 128, "center");
    bLeft.drawText(`Rs ${prevLoss}`, 70, 39, 16, prevLoss > 0 ? "#FF5252" : "#00E676", 128, "center");

    bMid.fastBox(0, 0, 140, 48, "#2E2208", "#FFC107", 2);
    bMid.drawText(carriedProfit > 0 ? "PROFIT CARRY" : "WAVE PLAY RATE", 70, 17, 9, "#FFC107", 128, "center");
    bMid.drawText(carriedProfit > 0 ? `+Rs ${carriedProfit}` : `Rs ${rateNum}`, 70, 39, 16, "#FFFFFF", 128, "center");

    bRight.fastBox(0, 0, 134, 48, "#122B22", "#00E676", 2);
    bRight.drawText("TOTAL INVEST", 67, 17, 9, "#00E676", 122, "center");
    bRight.drawText(`Rs ${investNum}`, 67, 39, 16, "#FFFFFF", 122, "center");
  } else if (prevLoss > 0 || carriedProfit > 0 || (ev.prevStatus === "FAIL" && rateDiff > 0)) {
    const lossVal = prevLoss > 0 ? prevLoss : rateDiff;
    sec2Sp.drawText(
      carriedProfit > 0
        ? `2. LOSS RECOVERY (-Rs ${lossVal}) + PROFIT CARRY (+Rs ${carriedProfit}):`
        : "2. LOSS RECOVERY RATE PLAN (RATE BADHAYA):",
      14,
      23,
      12,
      "#FFC107",
      432,
      "left"
    );
    sec2Sp.drawText(
      `Loss -Rs ${lossVal}${carriedProfit > 0 ? ` + Carry +Rs ${carriedProfit}` : ""} cover karne Rs ${rateNum} lagaya (Invest Rs ${investNum})`,
      14,
      102,
      11,
      "#FFE082",
      432,
      "left"
    );

    bLeft.fastBox(0, 0, 140, 48, "#301219", "#FF5252", 2);
    bLeft.drawText("PREV LOSS", 70, 17, 9, "#FF8A8A", 128, "center");
    bLeft.drawText(`-Rs ${lossVal}`, 70, 39, 16, "#FFFFFF", 128, "center");

    bMid.fastBox(0, 0, 140, 48, "#332408", "#FFC107", 2);
    bMid.drawText(carriedProfit > 0 ? "PROFIT CARRY" : "RATE BADHAYA", 70, 17, 9, "#FFC107", 128, "center");
    bMid.drawText(carriedProfit > 0 ? `+Rs ${carriedProfit}` : `+Rs ${rateDiff} EXTRA`, 70, 39, 16, "#FFC107", 128, "center");

    bRight.fastBox(0, 0, 134, 48, "#122B22", "#00E676", 2);
    bRight.drawText("NEW PLAY RATE", 67, 17, 9, "#00E676", 122, "center");
    bRight.drawText(`Rs ${rateNum}`, 67, 39, 17, "#FFFFFF", 122, "center");
  } else {
    sec2Sp.drawText("2. NORMAL BASE RATE STRATEGY (SAFE PLAY):", 14, 23, 12, "#00E676", 432, "left");
    sec2Sp.drawText(
      ev.prevStatus === "PASS"
        ? "Pichla card PASS hone ke baad wapas normal Base Rate par reset!"
        : "Normal Base Rate se safe game play start kiya gaya hai",
      14,
      102,
      11,
      "#80CBC4",
      432,
      "left"
    );

    bLeft.fastBox(0, 0, 140, 48, "#0D2E20", "#00E676", 2);
    bLeft.drawText("BASE RATE", 70, 17, 9, "#00E676", 128, "center");
    bLeft.drawText(`Rs ${rateNum}`, 70, 39, 17, "#FFFFFF", 128, "center");

    bMid.fastBox(0, 0, 140, 48, "#142638", "#20DCE9", 2);
    bMid.drawText("RISK MODE", 70, 17, 9, "#20DCE9", 128, "center");
    bMid.drawText("SAFE PLAY", 70, 39, 15, "#FFFFFF", 128, "center");

    bRight.fastBox(0, 0, 134, 48, "#2E2208", "#FFC107", 2);
    bRight.drawText("TOTAL INVEST", 67, 17, 9, "#FFC107", 122, "center");
    bRight.drawText(`Rs ${investNum}`, 67, 39, 16, "#FFFFFF", 122, "center");
  }

  // 6. Step 3 Result Container (460 x 112) + Giant 3D Slam Stamp (296 x 54)
  const resCol = ev.isCloseZeroSkip ? "#00E5FF" : isPass ? "#00E676" : "#FF5252";
  const resBg = ev.isCloseZeroSkip ? "#082A35" : isPass ? "#092B1D" : "#301118";
  const plVal = Math.round(Number(ev.pl || 0));
  const plStr = `${plVal >= 0 ? "+" : "-"}Rs ${Math.abs(plVal)}`;

  const sec3Sp = makeSprite(460, 112);
  sec3Sp.fastBox(0, 0, 460, 112, isUnboxingCard ? "#1E1606" : resBg, resCol, 3);
  sec3Sp.fastBox(14, 12, 130, 52, "#0B131C", resCol, 2);
  sec3Sp.drawText(isUnboxingCard ? "ACCURACY" : "ACTUAL RESULT", 79, 30, 9, "#8DA6C0", 118, "center");
  sec3Sp.drawText(
    isUnboxingCard ? `${unboxProbPct}% SATHIK` : String(ev.actual || (ev.isCloseZeroSkip ? "SKIP" : "--")),
    79,
    56,
    isUnboxingCard ? 15 : 20,
    resCol,
    118,
    "center"
  );

  sec3Sp.fastBox(14, 72, 432, 30, "#091018", isPass || ev.isCloseZeroSkip ? "#00E676" : "#FFC107", 1);
  let nextPlanText = "";
  if (isUnboxingCard) {
    nextPlanText = `🎯 ${unboxProbPct}% SATHIK PROBABILITY · PAID VIP GUESSING REVEAL!`;
  } else if (ev.isCloseZeroSkip) {
    nextPlanText = ev.status === "FAIL" && ev.isProfitCarryOn
      ? `PROFIT CARRY: Rs 0 Loss, +Rs ${baseTarget} Target Profit aage carry hua!`
      : `CLOSE ZERO COMPLETE: ${baseMktName} OPEN ka profit 100% safe raha!`;
  } else if (isPass && ev.isCloseZeroOn && isOpenMkt) {
    nextPlanText = `CLOSE ZERO TRIGGER: Ab ${baseMktName} CLOSE me Rs 0 Invest (Skip) rahega!`;
  } else if (isPass) {
    nextPlanText = ev.isFourWaveOn && ev.waveId
      ? `4-WAVE ${ev.waveId} RESET: Agle ${ev.waveId} card me wapas Base Rate lagega!`
      : (ev.isLastCard || !ev.nextMarket)
      ? (ev.hasPendingAfter ? "SETTLED COMPLETE · ABHI AAGE KE MARKETS BAKI HAIN!" : "AAJ KA GAME COMPLETE · KAL NAYI STRATEGY KE SATH!")
      : `NEXT CARD PLAN: Wapas Normal Base Rate Rs ${ev.nextRate || baseRateNum} se khelenge!`;
  } else if (ev.isFourWaveOn && ev.waveId) {
    nextPlanText = `4-WAVE ${ev.waveId}: Yeh loss sidha agle ${ev.waveId} wave card me recover hoga!`;
  } else if (ev.isProfitCarryOn) {
    nextPlanText = `PROFIT CARRY: Loss -Rs ${Math.abs(plVal)} + Target +Rs ${baseTarget} agle card par carry!`;
  } else {
    const nextRateVal = Number(ev.nextRate || 0);
    const nextDiff = nextRateVal > rateNum ? nextRateVal - rateNum : 0;
    nextPlanText = (ev.isLastCard || !ev.nextMarket)
      ? (ev.hasPendingAfter ? "SETTLED COMPLETE · ABHI AAGE KE MARKETS BAKI HAIN!" : "AAJ KA GAME COMPLETE · KAL NAYI STRATEGY KE SATH!")
      : `NEXT CARD PLAN: Loss cover ke liye Rate badha kar${nextRateVal > rateNum ? ` Rs ${nextRateVal} (+Rs ${nextDiff})` : ""} khelenge!`;
  }
  sec3Sp.drawText(nextPlanText, 230, 92, 11, isPass || ev.isCloseZeroSkip ? "#00E676" : "#FFC107", 420, "center");

  // Giant 3D Metallic Stamp Badge that zooms in from camera (scale 2.9x -> 1.0x) and SLAMS into Step 3!
  const stampSp = makeSprite(296, 54);
  stampSp.fastBox(0, 0, 296, 54, "#071019", resCol, 4);
  stampSp.fastBox(6, 6, 284, 42, resBg, "#FFC107", 1);
  const netVal = Math.round(Number(ev.netDayPl ?? plVal));
  stampSp.drawText(
    isUnboxingCard
      ? `🎯 ${unboxProbPct}% SATHIK REVEAL!`
      : ev.action === "CARD_SKIPPED" && !ev.isCloseZeroSkip
      ? "⏭️ SKIPPED (Rs 0 RISK)"
      : ev.isCloseZeroSkip
      ? "CLOSE ZERO (Rs 0 LOSS)"
      : isPass
      ? `SHANDAAR PASS! (${plStr})`
      : `RESULT FAIL (${plStr})`,
    148,
    25,
    14,
    resCol,
    272,
    "center"
  );
  stampSp.drawText(
    isUnboxingCard
      ? "PAID VIP · RATE AFTER MEMBERSHIP"
      : `Day Net P/L: ${netVal >= 0 ? "+" : "-"}Rs ${Math.abs(netVal)}`,
    148,
    43,
    11,
    "#FFFFFF",
    272,
    "center"
  );

  return {
    market: ev.market || `CARD #${cardNumber}`,
    status: ev.isCloseZeroSkip ? "SKIP" : (ev.status || "WAIT"),
    actual: ev.actual || "",
    borderColPassFail,
    chassisBuf: chassisSp.buf,
    headerBuf: headerSp.buf,
    sec1BoxBuf: sec1Sp.buf,
    digitTiles,
    sec2BoxBuf: sec2Sp.buf,
    sec2BadgeLeft: bLeft.buf,
    sec2BadgeMid: bMid.buf,
    sec2BadgeRight: bRight.buf,
    sec3BoxBuf: sec3Sp.buf,
    stamp3DBuf: stampSp.buf,
  };
}

function renderStepHudSprite(
  dateStr: string,
  profName: string,
  cardIdx: number,
  totalCards: number,
  phase: 1 | 2 | 3,
  passSoFar: number,
  failSoFar: number,
  runningPl: number,
  stepRatio: number,
  cardGroups: CardVisualGroup[],
  headerBg: string,
  primaryColor: string
): Uint8Array {
  const hud = makeSprite(WIDTH, 172);
  hud.fastBox(0, 0, WIDTH, 128, headerBg, primaryColor, 2);
  hud.drawText("TITAN NOVA  |  3D PRO STUDIO", 20, 36, 18, primaryColor, 310, "left");
  hud.drawText(`${dateStr}  |  ${profName.toUpperCase()}`, 20, 62, 12, "#8DA6C0", 310, "left");
  hud.fastBox(344, 14, 176, 36, "#182838", primaryColor, 2);
  hud.drawText(`CARD ${cardIdx + 1}/${totalCards} · STEP ${phase}/3`, 432, 37, 11, "#FFFFFF", 164, "center");

  hud.fastBox(20, 74, 500, 40, "#081018", "#25374A", 1);
  hud.drawText(`PASS: ${passSoFar}`, 36, 100, 14, "#00E676", 120, "left");
  hud.drawText(`FAIL: ${failSoFar}`, 165, 100, 14, "#FF5252", 120, "left");
  const netCol = runningPl >= 0 ? "#00E676" : "#FF5252";
  hud.drawText(`NET: ${runningPl >= 0 ? "+" : "-"}Rs ${Math.abs(Math.round(runningPl))}`, 504, 100, 15, netCol, 210, "right");

  hud.fastBox(0, 124, Math.max(12, Math.round(WIDTH * stepRatio)), 4, primaryColor);

  hud.fastBox(0, 128, WIDTH, 44, "#0D1724", "#1F3147", 1);
  const startChip = Math.max(0, cardIdx - 3);
  const endChip = Math.min(cardGroups.length, startChip + 5);
  let chipX = 16;
  for (let c = startChip; c < endChip; c++) {
    const cg = cardGroups[c];
    const isCur = c === cardIdx;
    const isSettledPast = c < cardIdx || (isCur && phase === 3);
    const chipCol = isCur
      ? primaryColor
      : isSettledPast
      ? (cg.status === "PASS" ? "#00E676" : cg.status === "SKIP" ? "#00E5FF" : "#FF5252")
      : "#4A627A";
    const chipBg = isCur ? "#162C42" : "#0A121C";
    hud.fastBox(chipX, 135, 98, 28, chipBg, chipCol, isCur ? 2 : 1);
    const shortMkt = cg.market.slice(0, 6);
    const statusTag = isSettledPast ? (cg.status === "PASS" ? "P" : cg.status === "SKIP" ? "0" : "F") : "..";
    hud.drawText(`#${c + 1} ${shortMkt}:${statusTag}`, chipX + 49, 154, 9, chipCol, 90, "center");
    chipX += 104;
  }

  return hud.buf;
}

async function renderActivityGifVideoInternal(
  events: ActivityTimelineEvent[],
  options: VideoStudioOptions = {}
): Promise<{
  available: boolean;
  buffer?: Buffer;
  mimeType: string;
  frameCount: number;
  hasEmbeddedVoice: boolean;
  voiceScript: VoiceCueItem[];
}> {
  const hasFfmpeg = await isFfmpegAvailable();
  const lang: VideoVoiceLang = options.voiceLang || "hinglish";
  const gender: "male" | "female" = options.voiceGender || "female";
  const voicePack: VoicePackId = options.voicePack || "gemini_flash_tts";
  const voiceEnabled = options.voiceEnabled !== false;

  const allEvents = (events as StepStoryEvent[]).slice(0, 90);

  if (!hasFfmpeg || allEvents.length === 0) {
    const fallbackCues: VoiceCueItem[] = allEvents.map((ev, idx) => ({
      startSec: idx * 2.5,
      endSec: (idx + 1) * 2.5,
      text: buildStepNarration(ev, lang).subtitle,
    }));
    return {
      available: hasFfmpeg,
      mimeType: "video/mp4",
      frameCount: allEvents.length,
      hasEmbeddedVoice: false,
      voiceScript: fallbackCues,
    };
  }

  await loadFont();

  const style: VideoStyleTheme = options.style || "cyber_neon";
  const primaryColor = style === "gold_royal" ? "#FAC748" : style === "emerald_matrix" ? "#00E676" : "#20DCE9";
  const headerBg = style === "gold_royal" ? "#241B0B" : style === "emerald_matrix" ? "#0B241A" : "#101D2C";

  const profName = options.profileName || allEvents[0]?.profileId || "MASTER ADMIN";
  const dateStr = options.dateRangeLabel || allEvents[0]?.date || "";

  const uniqueCardKeys: string[] = [];
  const cardKeySet = new Set<string>();
  for (let i = 0; i < allEvents.length; i++) {
    const ev = allEvents[i];
    const key = ev.cardSlot !== undefined ? `slot_${ev.cardSlot}` : `${ev.date}_${ev.market}_${i}`;
    if (!cardKeySet.has(key)) {
      cardKeySet.add(key);
      uniqueCardKeys.push(key);
    }
  }
  const totalCardsCount = uniqueCardKeys.length;

  const cardGroups: CardVisualGroup[] = [];
  const cardSlotMap = new Map<string, number>();
  const latestCardEventMap = new Map<number, StepStoryEvent>();
  const cardStepTexts = new Map<number, string[]>();

  for (let i = 0; i < allEvents.length; i++) {
    const ev = allEvents[i];
    const key = ev.cardSlot !== undefined ? `slot_${ev.cardSlot}` : `${ev.date}_${ev.market}_${i}`;
    let groupIdx = cardSlotMap.get(key);
    const stepNarr = buildStepNarration(ev, lang);

    if (groupIdx === undefined) {
      groupIdx = cardGroups.length;
      cardSlotMap.set(key, groupIdx);
      cardStepTexts.set(groupIdx, [stepNarr.ttsText]);
      latestCardEventMap.set(groupIdx, ev);
      const built = buildCard3DPieces(ev, groupIdx + 1, totalCardsCount, primaryColor);
      cardGroups.push({
        cardSlot: groupIdx,
        ...built,
        cardTtsText: stepNarr.ttsText,
      });
    } else {
      cardStepTexts.get(groupIdx)?.push(stepNarr.ttsText);
      const mergedEv: StepStoryEvent = { ...latestCardEventMap.get(groupIdx)!, ...ev };
      latestCardEventMap.set(groupIdx, mergedEv);
      const built = buildCard3DPieces(mergedEv, groupIdx + 1, totalCardsCount, primaryColor);
      cardGroups[groupIdx] = {
        cardSlot: groupIdx,
        ...built,
        cardTtsText: (cardStepTexts.get(groupIdx) || []).join(" "),
      };
    }
  }

  let runningPl = 0;
  let passSoFar = 0;
  let failSoFar = 0;

  const stepMeta = allEvents.map((ev, i) => {
    const key = ev.cardSlot !== undefined ? `slot_${ev.cardSlot}` : `${ev.date}_${ev.market}_${i}`;
    const cardIdx = cardSlotMap.get(key) ?? 0;
    const phase: 1 | 2 | 3 = ev.stepPhase || (ev.status === "PASS" || ev.status === "FAIL" ? 3 : ev.action === "CARD_SENT" ? 2 : 1);
    const narr = buildStepNarration(ev, lang);

    if (phase === 3) {
      if (!ev.isCloseZeroSkip && !ev.isSkippedCard && ev.action !== "CARD_SKIPPED" && ev.status !== "SKIP") {
        if (ev.status === "PASS") passSoFar++;
        else if (ev.status === "FAIL") failSoFar++;
      }
      if (ev.netDayPl !== undefined) runningPl = ev.netDayPl;
      else if (ev.pl !== undefined) runningPl += ev.pl;
    }

    return {
      ev,
      stepIdx: i,
      cardIdx,
      phase,
      subtitle: narr.subtitle,
      ttsText: narr.ttsText,
      passSoFar,
      failSoFar,
      runningPl,
    };
  });

  const totalPass = stepMeta[stepMeta.length - 1]?.passSoFar || 0;
  const totalFail = stepMeta[stepMeta.length - 1]?.failSoFar || 0;
  const finalNetPl = stepMeta[stepMeta.length - 1]?.runningPl || 0;
  const bestPassGroup = cardGroups.find((cg) => cg.status === "PASS") || cardGroups[0];
  const bestMarketStr = bestPassGroup ? `${bestPassGroup.market}${bestPassGroup.actual ? ` [${bestPassGroup.actual}]` : ""}` : "LIVE MARKETS";

  const firstEv = allEvents[0] || ({} as StepStoryEvent);
  const activeModeLabels: string[] = [];
  if (firstEv.isSmartStakeOn) activeModeLabels.push("SMART STAKE");
  if (firstEv.isProfitCarryOn) activeModeLabels.push("PROFIT CARRY");
  if (firstEv.isCloseZeroOn) activeModeLabels.push("CLOSE ZERO");
  if (firstEv.isFourWaveOn) activeModeLabels.push("4-WAVE RELAY");
  const activeModesBanner = activeModeLabels.length > 0 ? activeModeLabels.join("  +  ") : "SMART RECOVERY MODE";

  // Compute fallback dailyReportSummary from events if not explicitly supplied
  const computedSummary: DailyReportSummary = (() => {
    if (options.dailyReportSummary && options.dailyReportSummary.totalCards > 0) {
      return options.dailyReportSummary;
    }
    let sumInvest = 0;
    let curFailStreak = 0;
    let maxFailStreak = 0;
    let curRiskChain = 0;
    let maxRisk = 0;
    const seenCardSlots = new Set<number>();
    for (const s of stepMeta) {
      if (s.phase === 3 && !seenCardSlots.has(s.cardIdx)) {
        seenCardSlots.add(s.cardIdx);
        const inv = Math.max(0, Math.round(Number(s.ev.invest || 0)));
        sumInvest += inv;
        const activeExposure = curRiskChain + inv;
        if (activeExposure > maxRisk) maxRisk = activeExposure;
        if (!s.ev.isCloseZeroSkip) {
          if (s.ev.status === "FAIL") {
            curFailStreak++;
            if (curFailStreak > maxFailStreak) maxFailStreak = curFailStreak;
            curRiskChain += inv;
            if (curRiskChain > maxRisk) maxRisk = curRiskChain;
          } else if (s.ev.status === "PASS") {
            curFailStreak = 0;
            curRiskChain = 0;
          }
        }
      }
    }
    return {
      totalCards: totalCardsCount,
      totalPass,
      totalFail,
      totalInvest: sumInvest,
      maxConsecutiveFails: maxFailStreak,
      maxRiskExposure: maxRisk,
      finalNetPl: Math.round(finalNetPl),
    };
  })();

  const isUnboxingMode = options.videoMode === "unboxing_reveal";
  const isShortReportMode = !isUnboxingMode && (options.videoMode === "trailer_status" || Number(options.durationSec) === 20);
  const isTrailerMode = isUnboxingMode || isShortReportMode;

  const pendingMarketsList = Array.isArray(options.pendingMarkets)
    ? options.pendingMarkets.map((m) => String(m || "").trim()).filter(Boolean)
    : [];
  const introDateInfo = formatDateAndDayForVideo(dateStr);
  const isRunningDayToday = introDateInfo.isToday && pendingMarketsList.length > 0;

  const baseViralHook = buildViralIntroHook(
    options.hookStyle || "auto_viral",
    lang,
    dateStr,
    totalCardsCount,
    totalPass,
    finalNetPl,
    bestMarketStr,
    activeModesBanner
  );
  const netStrHook = `${computedSummary.finalNetPl >= 0 ? "+" : "-"}Rs ${Math.abs(Math.round(computedSummary.finalNetPl))}`;
  const hasProfit = computedSummary.finalNetPl >= 0;
  const dayStatusLabelHi = isRunningDayToday
    ? `${introDateInfo.dayRelationHi} के रनिंग डे`
    : introDateInfo.isToday
    ? `${introDateInfo.dayRelationHi} के लाइव मार्केट`
    : `${introDateInfo.dayRelationHi} के पूरे रिकॉर्ड`;

  const viralHook = isUnboxingMode
    ? {
        ...baseViralHook,
        topAlertBanner: `💎 ${introDateInfo.visualBadge} · PAID VIP REVEAL`,
        hookHeadline1: "AAJ KA GUESSING",
        hookHeadline2: "REVEAL KIYA JA RAHA HE!",
        curiosityTitle: "PAID GAME · DAILY / WEEKLY / MONTHLY MEMBERSHIP",
        curiosityDetail: `${introDateInfo.visualBadge} | LIVE MEMBERSHIP UNLOCK · ${totalCardsCount} CARDS`,
        subText: `${introDateInfo.subPrefix}Aaj ka guessing reveal kiya ja raha hai! Yeh paid game hai—live game paane ke liye aapko Daily, Weekly ya Monthly membership lena hoga!`,
        ttsText: lang === "english"
          ? `${introDateInfo.ttsPrefixEn}Today's guessing is being revealed! This is a paid VIP game — to get live games, you need a Daily, Weekly, or Monthly membership! Watch today's numbers and accuracy!`
          : `${introDateInfo.ttsPrefixHi}आज का गेसिंग रिवील किया जा रहा है! यह पेड गेम है — लाइव गेम पाने के लिए आपको डेली, वीकली या मंथली मेंबरशिप लेना होगा! चलिए देखते हैं आज के नंबर और उनकी सटीक प्रोबेबिलिटी!`,
      }
    : isShortReportMode
    ? {
        ...baseViralHook,
        topAlertBanner: `🔥 ${introDateInfo.visualBadge}`,
        hookHeadline1: hasProfit ? `${netStrHook} LIVE PROFIT!` : `${computedSummary.totalPass} PASS REAL PROOF!`,
        hookHeadline2: `${computedSummary.totalCards} CARDS · ${computedSummary.totalPass} PASS · ${activeModesBanner.split(' + ')[0]}`,
        curiosityTitle: hasProfit
          ? "RUKO! YEH LIVE PROFIT KAISE NIKLA?"
          : "RUKO! FULL TRANSPARENT LIVE REPORT!",
        curiosityDetail: `${introDateInfo.dayContextTag} | WHATSAPP & TELEGRAM PINNED LINK`,
        subText: hasProfit
          ? `${introDateInfo.subPrefix}Ruko! Scroll mat karna! ${isRunningDayToday ? "Abhi tak ke running day me" : introDateInfo.isPastDay ? "Pichhle din ke market me" : "Aaj ke market me"} Titan Nova Guessing Trick Se ${computedSummary.totalPass} card PASS aur ${netStrHook} profit kaise nikla? Dekho poora live proof!`
          : `${introDateInfo.subPrefix}Ruko! Scroll mat karna! ${isRunningDayToday ? "Abhi tak ke running day me" : introDateInfo.isPastDay ? "Pichhle din ke market me" : "Aaj ke market me"} ${computedSummary.totalCards} cards me ${computedSummary.totalPass} PASS aur Max Risk Rs ${computedSummary.maxRiskExposure} ka 100% sach dekho!`,
        ttsText: lang === "english"
          ? (hasProfit
              ? `${introDateInfo.ttsPrefixEn}Wait, do not scroll! ${isRunningDayToday ? "In today's running markets so far" : introDateInfo.isPastDay ? "In that day's completed markets" : "In today's markets"}, Titan Nova hit ${computedSummary.totalPass} pass games for ${netStrHook} profit${computedSummary.maxConsecutiveFails > 0 ? ` even after ${computedSummary.maxConsecutiveFails} consecutive fails` : ""}! Watch how every card played out—and join our WhatsApp or Telegram from the pinned comment!`
              : `${introDateInfo.ttsPrefixEn}Wait, do not scroll! Here is the 100 percent transparent live report of ${computedSummary.totalCards} cards with ${computedSummary.totalPass} pass hits! Join our WhatsApp and Telegram from the pinned comment!`)
          : (hasProfit
              ? `${introDateInfo.ttsPrefixHi}रुको! स्क्रॉल मत करना! ${dayStatusLabelHi} में टाइटन नोवा गेसिंग ट्रिक से ${computedSummary.totalPass} गेम पास करके सीधे ${Math.round(computedSummary.finalNetPl)} रुपये का पक्का प्रॉफिट निकला, वो भी ${computedSummary.maxConsecutiveFails > 0 ? `लगातार ${computedSummary.maxConsecutiveFails} फेल के बाद तगड़ी रिकवरी करके` : "स्मार्ट रिस्क मैनेजमेंट से"}! देखिए हर कार्ड का लाइव प्रूफ, और रिज़ल्ट से पहले गेम के लिए कमेंट में पिन लिंक से व्हाट्सएप और टेलीग्राम चैनल में जुड़िए!`
              : `${introDateInfo.ttsPrefixHi}रुको! स्क्रॉल मत करना! ${dayStatusLabelHi} में कुल ${computedSummary.totalCards} कार्ड्स का सौ प्रतिशत असली लाइव हिसाब देखिए—कोई फेक नहीं! रिज़ल्ट से पहले गेम देखने के लिए कमेंट में पिन लिंक से व्हाट्सएप और टेलीग्राम चैनल में जुड़िए!`),
      }
    : {
        ...baseViralHook,
        topAlertBanner: `🔥 ${introDateInfo.visualBadge}`,
        hookHeadline1: "TITAN NOVA GUESSING",
        hookHeadline2: hasProfit
          ? `${netStrHook} PROFIT · AAP BHI KAMA SAKTE HO!`
          : `${totalPass} PASS · 100% REAL STEP-BY-STEP`,
        curiosityTitle: "WHATSAPP GROUP JOIN KARO — DEMO GAME WAHI MILTA!",
        curiosityDetail: hasProfit
          ? `${introDateInfo.dayContextTag}: +${Math.round(finalNetPl)} Profit Live Proof`
          : `${introDateInfo.dayContextTag}: All Markets Step-by-Step Hisab`,
        subText: hasProfit
          ? `${introDateInfo.subPrefix}Titan Nova Satta Matka Guessing me aapka swagat he! Video skip mat karna—agar aap satta matka khelte hai to yeh video aapke liye hai! Proof aur demo game ke liye WhatsApp group join karo. ${introDateInfo.dayRelationHi} +Rs ${Math.round(finalNetPl)} profit hua—aap bhi daily kama sakte ho! Chaliye all market step-by-step dekhte hain!`
          : `${introDateInfo.subPrefix}Titan Nova Satta Matka Guessing me aapka swagat he! Video skip mat karna—agar aap satta matka khelte hai to yeh video aapke liye hai! Proof aur demo game ke liye WhatsApp group join karo. Chaliye aage dekhte hain all market step-by-step kaise play kiya aur kya hisab hua!`,
        ttsText: lang === "english"
          ? (hasProfit
              ? `Welcome to Titan Nova Satta Matka Guessing! Do not skip if you play Matka—join our WhatsApp group for live proof and demo games! ${introDateInfo.ttsPrefixEn}Profit was Rs ${Math.round(finalNetPl)}, and you can earn daily too! Let us watch how every market played step by step!`
              : `Welcome to Titan Nova Satta Matka Guessing! Do not skip if you play Matka—join our WhatsApp group for live proof and demo games! ${introDateInfo.ttsPrefixEn}Let us watch how all markets played step by step!`)
          : (hasProfit
              ? `टाइटन नोवा सट्टा मटका गेसिंग में आपका स्वागत है! रुको, वीडियो स्किप मत करना! अगर आप सट्टा मटका खेलते हैं तो यह वीडियो आपके लिए ही है, ध्यान से देखो! प्रूफ चाहिए तो मेरे व्हाट्सएप ग्रुप में जुड़ो, डेमो गेम वहीं मिलता है! ${introDateInfo.ttsPrefixHi} सीधा ${Math.round(finalNetPl)} रुपये प्रॉफिट हुआ है—आप भी डेली कमा सकते हो! तो चलिए आगे देखते हैं, सभी मार्केट्स स्टेप बाय स्टेप कैसे प्ले किए गए और कैसे प्रॉफिट बना!`
              : `टाइटन नोवा सट्टा मटका गेसिंग में आपका स्वागत है! रुको, वीडियो स्किप मत करना! अगर आप सट्टा मटका खेलते हैं तो यह वीडियो आपके लिए ही है, ध्यान से देखो! प्रूफ चाहिए तो मेरे व्हाट्सएप ग्रुप में जुड़ो, डेमो गेम वहीं मिलता है! ${introDateInfo.ttsPrefixHi} कुल ${Math.abs(Math.round(finalNetPl))} रुपये लॉस का पूरा सच देखिए। तो चलिए आगे देखते हैं, सभी मार्केट्स स्टेप बाय स्टेप कैसे प्ले किए गए!`),
      };

  const activeStepMeta = stepMeta;
  const hasDailyReviewScene = isShortReportMode;

  const reportReviewTts = hasDailyReviewScene
    ? (lang === "english"
        ? `Quick ${introDateInfo.dayRelationEn} summary: Out of ${computedSummary.totalCards} total cards, ${computedSummary.totalPass} passed and ${computedSummary.totalFail} failed. Total investment was Rs ${computedSummary.totalInvest}, max consecutive fails ${computedSummary.maxConsecutiveFails}, max risk Rs ${computedSummary.maxRiskExposure}, and final net ${computedSummary.finalNetPl >= 0 ? `profit Rs ${Math.round(computedSummary.finalNetPl)}` : `loss Rs ${Math.abs(Math.round(computedSummary.finalNetPl))}`}!`
        : `तो यह था ${introDateInfo.dayRelationHi} का पूरा हिसाब: कुल ${computedSummary.totalCards} कार्ड्स में से ${computedSummary.totalPass} पास और ${computedSummary.totalFail} फेल हुए। कुल इन्वेस्टमेंट ${computedSummary.totalInvest} रुपये, लगातार अधिकतम ${computedSummary.maxConsecutiveFails} फेल, मैक्स रिस्क ${computedSummary.maxRiskExposure} रुपये, और फाइनल नेट ${computedSummary.finalNetPl >= 0 ? `${Math.round(computedSummary.finalNetPl)} रुपये का शानदार प्रॉफिट` : `${Math.abs(Math.round(computedSummary.finalNetPl))} रुपये लॉस`} रहा!`)
    : "";
  const reportReviewSubtitle = hasDailyReviewScene
    ? `📊 ${introDateInfo.dayContextTag}: Kul ${computedSummary.totalCards} Cards | ${computedSummary.totalPass} PASS · ${computedSummary.totalFail} FAIL | Invest Rs ${computedSummary.totalInvest} | Lagataar Fail: ${computedSummary.maxConsecutiveFails} | Max Risk: Rs ${computedSummary.maxRiskExposure} | Final ${computedSummary.finalNetPl >= 0 ? "Profit +Rs " + Math.round(computedSummary.finalNetPl) : "Loss -Rs " + Math.abs(Math.round(computedSummary.finalNetPl))}!`
    : "";

  const hasPendingMarkets = !isShortReportMode && !isUnboxingMode && pendingMarketsList.length > 0;
  const pendingSampleStr = pendingMarketsList.slice(0, 3).join(", ");
  const pendingTts = hasPendingMarkets
    ? (lang === "english"
        ? `Friends, all ${totalCardsCount} settled markets so far are complete with ${totalPass} pass games! But the day is still running — upcoming ${pendingMarketsList.length} markets including ${pendingSampleStr} are still pending. Let us see what happens next!`
        : `दोस्तों, ${introDateInfo.dayRelationHi} यहाँ तक के सभी ${totalCardsCount} सेटल्ड मार्केट्स का लाइव हिसाब पूरा हो चुका है! लेकिन पिक्चर अभी बाकी है — अभी आगे के ${pendingMarketsList.length} मार्केट्स जैसे ${pendingSampleStr} का खेल और रिज़ल्ट आना बाकी है! देखते हैं आगे क्या धमाका होता है!`)
    : "";
  const pendingSubtitle = hasPendingMarkets
    ? (lang === "english"
        ? `Settled ${totalCardsCount} cards complete! Upcoming ${pendingMarketsList.length} markets (${pendingSampleStr}...) are still WAIT/Pending — let's see what happens next!`
        : `यहाँ तक के ${totalCardsCount} सेटल्ड कार्ड्स पूरे हुए! अभी आगे के ${pendingMarketsList.length} मार्केट्स (${pendingSampleStr}...) बाकी हैं — देखते हैं आगे क्या होगा!`)
    : "";

  const firstUnboxEv = activeStepMeta[0]?.ev || firstEv;
  const unboxRateNum = Math.max(0, Math.round(Number(firstUnboxEv?.rate || 0)));
  const unboxStrongRate = Math.max(0, Math.round(Number(firstUnboxEv?.strongRate || 0)));
  const unboxSupportRate = Math.max(0, Math.round(Number(firstUnboxEv?.supportRate || 0)));
  const unboxRateBadge = (firstUnboxEv?.isSmartStakeOn && unboxStrongRate > 0 && unboxSupportRate > 0)
    ? `STRONG Rs ${unboxStrongRate} / SUPPORT Rs ${unboxSupportRate}`
    : `Rs ${unboxRateNum > 0 ? unboxRateNum : 10} RATE`;
  const unboxRateSpeechHi = (firstUnboxEv?.isSmartStakeOn && unboxStrongRate > 0 && unboxSupportRate > 0)
    ? `स्ट्रॉन्ग पर ${unboxStrongRate} और सपोर्ट पर ${unboxSupportRate} रुपये रेट`
    : `${unboxRateNum > 0 ? unboxRateNum : 10} रुपये रेट`;
  const unboxRateSpeechEn = (firstUnboxEv?.isSmartStakeOn && unboxStrongRate > 0 && unboxSupportRate > 0)
    ? `Strong Rs ${unboxStrongRate} and Support Rs ${unboxSupportRate} rate`
    : `Rs ${unboxRateNum > 0 ? unboxRateNum : 10} rate`;

  const outroTts = isUnboxingMode
    ? (lang === "english"
        ? "Get your Daily, Weekly, or Monthly VIP Membership by joining our WhatsApp and Telegram channel! Thank you all!"
        : "डेली, वीकली या मंथली वीआईपी मेंबरशिप लेने के लिए हमारे व्हाट्सएप और टेलीग्राम चैनल से जुड़ें! थैंक यू ऑल!")
    : isShortReportMode
    ? (lang === "english"
        ? `${isRunningDayToday ? `${pendingMarketsList.length} markets are still pending today! ` : ""}This is 100 percent real live proof! To get games before the result or watch live demo, join our WhatsApp and Telegram channel from the pinned comment link. Thank you all, see you in the next video!`
        : `${isRunningDayToday ? `अभी आज के ${pendingMarketsList.length} मार्केट्स आना बाकी हैं! ` : ""}यह सौ प्रतिशत रियल लाइव प्रूफ है, कोई फेक नहीं! रिज़ल्ट से पहले गेम और लाइव डेमो देखने के लिए कमेंट में पिन लिंक से व्हाट्सएप और टेलीग्राम चैनल में जुड़िए। थैंक यू ऑल, मिलते हैं नेक्स्ट वीडियो में!`)
    : (lang === "english"
        ? `That completes our ${introDateInfo.dayRelationEn} live update with ${totalPass} pass games and net ${finalNetPl >= 0 ? `profit Rs ${Math.round(finalNetPl)}` : `loss Rs ${Math.abs(Math.round(finalNetPl))}`}. Subscribe on YouTube, follow on Instagram and Facebook, and join our official Telegram community!`
        : `दोस्तों, यह था टाइटन नोवा गेसिंग ट्रिक से ${introDateInfo.dayRelationHi} के ${totalCardsCount} सेटल्ड कार्ड्स का लाइव प्रूफ, जहाँ ${totalPass} गेम पास हुए और नेट हिसाब ${finalNetPl >= 0 ? `${Math.round(finalNetPl)} रुपये प्रॉफिट` : `${Math.abs(Math.round(finalNetPl))} रुपये लॉस`} रहा! ऐसे ही डेली लाइव अपडेट्स के लिए यूट्यूब पर सब्सक्राइब करें, इंस्टाग्राम और फेसबुक पर फॉलो करें, और हमारे टेलीग्राम चैनल से अभी जुड़ें!`);

  const outroSubtitle = isShortReportMode
    ? `${isRunningDayToday ? `⏳ Abhi ${pendingMarketsList.length} markets baki hain! ` : ""}Yeh 100% real proof he! Result se pehle game ke liye Comment Pinned Link se WhatsApp & Telegram join karein. Thank you all!`
    : outroTts;

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "titan-studio-"));
  try {
    const waIntroExistsForVoice = options.socialPlatform === "whatsapp_status" && !isUnboxingMode;
    const isDefaultSwaraOrEmpty = !options.voicePack || options.voicePack === "swara_hi" || options.voicePack === "gemini_flash_tts";
    const effectiveVoicePack: VoicePackId = (waIntroExistsForVoice && isDefaultSwaraOrEmpty && !options.voiceSampleBase64)
      ? "madhur_hi"
      : voicePack;
    const effectiveGender: "male" | "female" = (waIntroExistsForVoice && isDefaultSwaraOrEmpty && !options.voiceSampleBase64)
      ? "male"
      : gender;
    let pitchRatio = (waIntroExistsForVoice && !options.voiceSampleBase64)
      ? 0.88
      : options.voicePitchShift
      ? Number(options.voicePitchShift)
      : effectiveGender === "male"
      ? 0.92
      : 1.0;

    const durMode = isTrailerMode ? 20 : Number(options.durationSec || 60);
    const defaultVoiceSpeedForMode = isShortReportMode ? 1.02 : durMode === 20 ? 1.04 : durMode === 75 ? 0.96 : durMode === 60 ? 1.06 : durMode === 45 ? 1.08 : 1.12;
    const speedRatio = options.voiceSpeed ? Number(options.voiceSpeed) : defaultVoiceSpeedForMode;
    let userIntroVoicePcm: Int16Array | null = null;

    if (options.voiceSampleBase64) {
      const analyzed = await analyzeCustomVoiceSample(options.voiceSampleBase64, tmpDir);
      if (!options.voicePitchShift) {
        pitchRatio = analyzed.detectedPitchShift;
      }
      userIntroVoicePcm = analyzed.samplePcm;
    }

    const waIntroCandidates = [
      process.env.TITAN_APP_ROOT ? path.resolve(process.env.TITAN_APP_ROOT, "assets/intros/whatsapp_status_intro.mp4") : "",
      path.resolve(process.cwd(), "assets/intros/whatsapp_status_intro.mp4"),
      path.resolve(__dirname, "../assets/intros/whatsapp_status_intro.mp4"),
      path.resolve(__dirname, "assets/intros/whatsapp_status_intro.mp4"),
    ].filter(Boolean);
    const waStatusIntroPath = waIntroCandidates.find((p) => fs.existsSync(p)) || waIntroCandidates[0];
    const useWaStatusVideoIntro = options.socialPlatform === "whatsapp_status" && !isUnboxingMode && Boolean(waStatusIntroPath && fs.existsSync(waStatusIntroPath));
    const hasIntroScene = !useWaStatusVideoIntro;
    const stepLevelTexts: string[] = [
      ...(hasIntroScene ? [viralHook.ttsText] : []),
      ...activeStepMeta.map((s) => s.ttsText),
      ...(hasDailyReviewScene ? [reportReviewTts] : []),
      ...(hasPendingMarkets ? [pendingTts] : []),
      outroTts,
    ];
    const pcmResults = voiceEnabled
      ? await synthesizeAllTtsClipsBatch(stepLevelTexts, lang, effectiveGender, pitchRatio, speedRatio, tmpDir, effectiveVoicePack)
      : new Array(stepLevelTexts.length).fill(null);

    if (hasIntroScene && userIntroVoicePcm && voiceEnabled && !pcmResults[0]) {
      pcmResults[0] = userIntroVoicePcm;
    }

    const hasEmbeddedVoice = pcmResults.some((p) => p !== null && p.length > 0);

    const fps = 8;
    const cardCountForTiming = Math.max(1, activeStepMeta.length);
    const shortMaxPerCardSec = Math.max(1.0, Math.min(2.3, 34 / cardCountForTiming));
    const minSecPerStep = isShortReportMode
      ? Math.min(1.5, shortMaxPerCardSec)
      : durMode === 20
      ? 1.8
      : durMode === 75
      ? 2.6
      : durMode === 60
      ? 1.9
      : durMode === 45
      ? 1.55
      : 1.3;
    const extraHoldSecPerStep = isShortReportMode ? 0.10 : durMode === 20 ? 0.15 : durMode === 75 ? 0.55 : durMode === 60 ? 0.24 : durMode === 45 ? 0.16 : 0.10;

    const introPcm = hasIntroScene ? pcmResults[0] : null;
    const minBookendSec = isShortReportMode ? 2.6 : isTrailerMode ? 2.4 : 2.5;
    const introDurSec = hasIntroScene
      ? (introPcm ? Math.max(1.8, introPcm.length / SAMPLE_RATE + 0.15) : minBookendSec)
      : 0;
    const introFrames = hasIntroScene ? Math.max(fps * 2, Math.round(introDurSec * fps)) : 0;

    let pcmCursor = (hasIntroScene ? 1 : 0) + activeStepMeta.length;
    const reviewPcm = hasDailyReviewScene ? pcmResults[pcmCursor++] : null;
    const reviewDurSec = hasDailyReviewScene
      ? (reviewPcm ? Math.max(3.2, reviewPcm.length / SAMPLE_RATE + 0.28) : 4.8)
      : 0;
    const reviewFrames = hasDailyReviewScene ? Math.max(fps * 3, Math.round(reviewDurSec * fps)) : 0;

    const pendingPcm = hasPendingMarkets ? pcmResults[pcmCursor++] : null;
    const pendingDurSec = hasPendingMarkets
      ? (pendingPcm ? Math.max(2.2, pendingPcm.length / SAMPLE_RATE + 0.18) : 3.2)
      : 0;
    const pendingFrames = hasPendingMarkets ? Math.max(fps * 2, Math.round(pendingDurSec * fps)) : 0;

    const outroPcm = pcmResults[pcmCursor];
    const outroDurSec = outroPcm
      ? Math.max(2.5, outroPcm.length / SAMPLE_RATE + 0.28)
      : minBookendSec;
    const outroFrames = Math.max(fps * 2, Math.round(outroDurSec * fps));

    const stepTimings: Array<{
      startFrame: number;
      endFrame: number;
      startSec: number;
      endSec: number;
    }> = new Array(activeStepMeta.length);

    const cardVoiceClips: Array<{ startSec: number; pcm: Int16Array | null }> = hasIntroScene
      ? [{ startSec: 0.1, pcm: introPcm }]
      : [];

    let curFrame = introFrames;
    const stepPcmOffset = hasIntroScene ? 1 : 0;
    for (let sIdx = 0; sIdx < activeStepMeta.length; sIdx++) {
      const stepPcm = pcmResults[sIdx + stepPcmOffset];
      const stepDurSec = stepPcm
        ? Math.max(isShortReportMode ? 1.45 : 1.1, stepPcm.length / SAMPLE_RATE + (isShortReportMode ? 0.22 : 0.16))
        : minSecPerStep;
      // Never truncate stepDurSec below actual spoken voice length (prevents double-sound overlap)
      const framesForStep = Math.max(11, Math.round(stepDurSec * fps));
      const startFrame = curFrame;
      const endFrame = curFrame + framesForStep;
      stepTimings[sIdx] = {
        startFrame,
        endFrame,
        startSec: startFrame / fps,
        endSec: endFrame / fps,
      };
      cardVoiceClips.push({ startSec: startFrame / fps + 0.04, pcm: stepPcm });
      curFrame = endFrame;
    }

    const reviewStartFrame = curFrame;
    const pendingStartFrame = reviewStartFrame + reviewFrames;
    const outroStartFrame = pendingStartFrame + pendingFrames;

    if (hasDailyReviewScene) {
      cardVoiceClips.push({ startSec: reviewStartFrame / fps + 0.08, pcm: reviewPcm });
    }
    if (hasPendingMarkets) {
      cardVoiceClips.push({ startSec: pendingStartFrame / fps + 0.08, pcm: pendingPcm });
    }
    cardVoiceClips.push({ startSec: outroStartFrame / fps + 0.1, pcm: outroPcm });

    const totalFrames = outroStartFrame + outroFrames;
    const totalDurationSec = totalFrames / fps;

    const voiceScript: VoiceCueItem[] = [
      ...(hasIntroScene ? [{ startSec: 0, endSec: introFrames / fps, text: viralHook.subText }] : []),
      ...activeStepMeta.map((s, idx) => ({
        startSec: stepTimings[idx].startSec,
        endSec: stepTimings[idx].endSec,
        text: s.subtitle,
      })),
      ...(hasDailyReviewScene
        ? [{ startSec: reviewStartFrame / fps, endSec: pendingStartFrame / fps, text: reportReviewSubtitle }]
        : []),
      ...(hasPendingMarkets
        ? [{ startSec: pendingStartFrame / fps, endSec: outroStartFrame / fps, text: pendingSubtitle }]
        : []),
      { startSec: outroStartFrame / fps, endSec: totalDurationSec, text: outroSubtitle },
    ];

    // ========================================================================
    // PRE-RENDER MODULAR 3D PIECES FOR SCENE 1 (VIRAL HOOK), SCENE 2 (3D SHIELD
    // FLYING ASSEMBLY + KHATARNAK LASER NAME WRITING), AND SCENE 4 (OUTRO)
    // ========================================================================

    // Scene 1 Modular Pieces:
    const hookAlertSp = makeSprite(452, 58);
    hookAlertSp.fastBox(0, 0, 452, 58, "#3B1018", "#FF5252", 3);
    hookAlertSp.drawText(viralHook.topAlertBanner, 226, 38, 21, "#FFC107", 430, "center");

    const hookHead1Sp = makeSprite(464, 56);
    hookHead1Sp.fastBox(0, 0, 464, 56, "#0B1626", primaryColor, 2);
    hookHead1Sp.drawText(viralHook.hookHeadline1, 232, 40, 30, "#FFFFFF", 445, "center");

    const hookHead2Sp = makeSprite(464, 52);
    hookHead2Sp.fastBox(0, 0, 464, 52, "#0B281B", "#00E676", 2);
    hookHead2Sp.drawText(viralHook.hookHeadline2, 232, 37, 23, "#00E676", 445, "center");

    const hookScoreSp = makeSprite(452, 185);
    hookScoreSp.fastBox(0, 0, 452, 185, "#091320", "#20DCE9", 3);
    hookScoreSp.drawText("ACTUAL UPDATES  ·  ACTUAL RESULTS", 226, 34, 13, "#20DCE9", 420, "center");
    const bigNumberStr = finalNetPl > 0 ? `+Rs ${Math.round(finalNetPl)}` : `${totalPass} PASS HITS`;
    hookScoreSp.drawText(bigNumberStr, 226, 112, 46, "#00E676", 425, "center");
    hookScoreSp.drawText(`${introDateInfo.visualBadge} · ${totalCardsCount} MARKETS`, 226, 162, 14, "#EEF7FF", 420, "center");

    const hookCuriositySp = makeSprite(452, 140);
    hookCuriositySp.fastBox(0, 0, 452, 140, "#132235", "#FFC107", 3);
    hookCuriositySp.drawText(viralHook.curiosityTitle, 226, 42, 17, "#FFC107", 425, "center");
    hookCuriositySp.drawText(viralHook.curiosityDetail, 226, 82, 13, "#FFFFFF", 425, "center");
    hookCuriositySp.drawText(`ACTIVE LOGIC: ${activeModesBanner}`, 226, 120, 12, "#00E676", 425, "center");

    const hookSubSp = makeSprite(452, 140);
    hookSubSp.fastBox(0, 0, 452, 140, "#081018", "#20DCE9", 2);
    const hookSubLines = wrapText(hookSubSp.ctx, viralHook.subText, 420, 3);
    hookSubLines.forEach((ln, idx) => {
      hookSubSp.drawText(ln, 226, 42 + idx * 30, 14, "#FFFFFF", 425, "center");
    });

    // Scene 2 Modular Pieces: 5 Separate 3D Titan Shield Shards (that fly in & lock together!)
    const shieldShard1Outer = makeSprite(196, 180);
    shieldShard1Outer.fastBox(0, 0, 196, 180, "#0A1626", primaryColor, 4);

    const shieldShard2Core = makeSprite(158, 144);
    shieldShard2Core.fastBox(0, 0, 158, 144, "#132842", "#FFC107", 3);

    const shieldShard3Crown = makeSprite(124, 30);
    shieldShard3Crown.fastBox(0, 0, 124, 30, primaryColor, "#FFFFFF", 2);

    const shieldShard4Blade = makeSprite(34, 112);
    shieldShard4Blade.fastBox(0, 0, 34, 112, primaryColor, "#FFC107", 2);

    const shieldShard5Wings = makeSprite(118, 60);
    shieldShard5Wings.fastBox(0, 0, 32, 60, "#FFC107", "#FFFFFF", 2);
    shieldShard5Wings.fastBox(86, 0, 32, 60, "#FFC107", "#FFFFFF", 2);

    // Individual 3D Beveled Character Sprites for Khatarnak Laser Name Writing!
    const rawBrandTitle = (options.customTitle || "TITAN NOVA").toUpperCase().slice(0, 14);
    const brandChars = rawBrandTitle.split("");
    const charW = Math.min(44, Math.floor(460 / Math.max(1, brandChars.length)));
    const charH = 62;
    const totalTitleW = brandChars.length * charW;
    const titleStartX = Math.round(270 - totalTitleW / 2 + charW / 2);

    const brandCharSprites = brandChars.map((ch, idx) => {
      const sp = makeSprite(charW - 2, charH);
      if (ch !== " ") {
        sp.fastBox(0, 0, charW - 2, charH, "#102338", "#FFC107", 3);
        sp.fastBox(3, 3, charW - 8, 10, primaryColor);
        sp.drawText(ch, (charW - 2) / 2, 46, 26, "#FFFFFF", charW - 4, "center");
      }
      return {
        ch,
        buf: sp.buf,
        w: charW - 2,
        h: charH,
        targetX: titleStartX + idx * charW,
        targetY: 348,
      };
    });

    const brandTaglineSp = makeSprite(452, 38);
    brandTaglineSp.fastBox(0, 0, 452, 38, "#1A1407", "#FFC107", 2);
    brandTaglineSp.drawText(
      isShortReportMode ? "LIVE RESULT & GUESSING  ·  PINNED LINK IN COMMENT" : "THE ACTION  ·  THE STRATEGY  ·  THE RESULTS",
      226, 26, 13, "#FFC107", 435, "center"
    );

    const brandProfileSp = makeSprite(452, 108);
    brandProfileSp.fastBox(0, 0, 452, 108, "#0B1522", "#00E676", 2);
    brandProfileSp.drawText(`${introDateInfo.visualBadge}  |  ${profName.toUpperCase()}`, 226, 34, 14, "#FFC107", 435, "center");
    brandProfileSp.drawText(
      isShortReportMode ? "WHATSAPP CHANNEL · GROUP · TELEGRAM CHANNEL" : `${activeModesBanner}`,
      226, 66, 14, "#00E676", 425, "center"
    );
    brandProfileSp.drawText(`VOICE ENGINE: ${getVoicePackLabel(voicePack)} (${gender.toUpperCase()})`, 226, 94, 12, "#20DCE9", 425, "center");

    const brandFeat1Sp = makeSprite(452, 54);
    brandFeat1Sp.fastBox(0, 0, 452, 54, "#0C1E30", "#20DCE9", 2);
    brandFeat1Sp.drawText(
      isShortReportMode ? "1. Live Result & Game Guessing Daily Updates" : "1. Har Market ka Trick Formula & 3D Flying Digits",
      226, 34, 14, "#FFFFFF", 425, "center"
    );

    const brandFeat2Sp = makeSprite(452, 54);
    brandFeat2Sp.fastBox(0, 0, 452, 54, "#1E190B", "#FFC107", 2);
    brandFeat2Sp.drawText(
      isShortReportMode ? "2. Comment Me Link Pin Hai — Direct Joining!" : "2. Smart Stake / Profit Carry / Close Zero / 4-Wave",
      226, 34, 13, "#FFC107", 425, "center"
    );

    const brandFeat3Sp = makeSprite(452, 54);
    brandFeat3Sp.fastBox(0, 0, 452, 54, "#0B2B1E", "#00E676", 2);
    brandFeat3Sp.drawText(
      isShortReportMode ? "3. Chaliye Aaj Ka Chhota Report Bata Dete Hain!" : "3. Live Result 3D Stamp Slam & Final Scoreboard",
      226, 34, 14, "#00E676", 425, "center"
    );

    // Scene 3.2 (SHORT VIDEO ONLY: "AAJ KA EK CHHOTA REVIEW" — Single Highlight 6-Metric 3D Report Dashboard):
    const finalCol = (isShortReportMode ? computedSummary.finalNetPl : finalNetPl) >= 0 ? "#00E676" : "#FF5252";
    const revHeaderSp = hasDailyReviewScene ? makeSprite(460, 88) : null;
    if (revHeaderSp) {
      revHeaderSp.fastBox(0, 0, 460, 88, "#0B1626", "#FFC107", 3);
      revHeaderSp.drawText("TITAN NOVA  ·  AAJ KA EK CHHOTA REVIEW", 230, 30, 15, "#FFC107", 435, "center");
      revHeaderSp.drawText(`${introDateInfo.visualBadge}`, 230, 66, 20, "#FFFFFF", 435, "center");
    }

    // 6 3D Stat Cards (2x3 Grid) for Short Video Single Highlight:
    // 1. Kitne Card The  2. Kitne Fail & Pass  3. Total Investment  4. Lagataar Fail  5. Max Risk  6. Final Profit/Loss
    const revCard1TotalSp = hasDailyReviewScene ? makeSprite(222, 112) : null;
    if (revCard1TotalSp) {
      revCard1TotalSp.fastBox(0, 0, 222, 112, "#0E1E32", "#20DCE9", 3);
      revCard1TotalSp.drawText("1. KITNE CARD THE", 111, 28, 12, "#20DCE9", 204, "center");
      revCard1TotalSp.drawText(`${computedSummary.totalCards} CARDS`, 111, 74, 28, "#FFFFFF", 204, "center");
      revCard1TotalSp.drawText("AAJ KE TOTAL CARDS", 111, 100, 10, "#8DA6C0", 204, "center");
    }

    const revCard2PassFailSp = hasDailyReviewScene ? makeSprite(222, 112) : null;
    if (revCard2PassFailSp) {
      revCard2PassFailSp.fastBox(0, 0, 222, 112, "#0B281B", "#00E676", 3);
      revCard2PassFailSp.drawText("2. KITNE FAIL / PASS", 111, 28, 12, "#00E676", 204, "center");
      revCard2PassFailSp.drawText(`${computedSummary.totalFail} FAIL · ${computedSummary.totalPass} PASS`, 111, 72, 21, "#FFFFFF", 206, "center");
      revCard2PassFailSp.drawText("AAJ KA RESULT SCORE", 111, 100, 10, "#80CBC4", 204, "center");
    }

    const revCard3InvestSp = hasDailyReviewScene ? makeSprite(222, 112) : null;
    if (revCard3InvestSp) {
      revCard3InvestSp.fastBox(0, 0, 222, 112, "#241B08", "#FFC107", 3);
      revCard3InvestSp.drawText("3. TOTAL INVESTMENT", 111, 28, 12, "#FFC107", 204, "center");
      revCard3InvestSp.drawText(`Rs ${computedSummary.totalInvest}`, 111, 74, 26, "#FFFFFF", 204, "center");
      revCard3InvestSp.drawText("INVESTMENT ME KITNA HUA", 111, 100, 10, "#FFE082", 204, "center");
    }

    const revCard4StreakSp = hasDailyReviewScene ? makeSprite(222, 112) : null;
    if (revCard4StreakSp) {
      revCard4StreakSp.fastBox(0, 0, 222, 112, "#2B1219", "#FF5252", 3);
      revCard4StreakSp.drawText("4. LAGATAAR CARD FAIL", 111, 28, 12, "#FF8A8A", 204, "center");
      revCard4StreakSp.drawText(`${computedSummary.maxConsecutiveFails} CARDS`, 111, 74, 26, "#FF5252", 204, "center");
      revCard4StreakSp.drawText("LAGATAAR KITNE FAIL HUA", 111, 100, 10, "#FF8A8A", 204, "center");
    }

    const revCard5RiskSp = hasDailyReviewScene ? makeSprite(222, 112) : null;
    if (revCard5RiskSp) {
      revCard5RiskSp.fastBox(0, 0, 222, 112, "#221432", "#E040FB", 3);
      revCard5RiskSp.drawText("5. MAX RISK KITNA THA", 111, 28, 12, "#EA80FC", 204, "center");
      revCard5RiskSp.drawText(`Rs ${computedSummary.maxRiskExposure}`, 111, 74, 26, "#FFFFFF", 204, "center");
      revCard5RiskSp.drawText("PEAK RECOVERY RISK", 111, 100, 10, "#EA80FC", 204, "center");
    }

    const revCard6FinalPlSp = hasDailyReviewScene ? makeSprite(222, 112) : null;
    if (revCard6FinalPlSp) {
      revCard6FinalPlSp.fastBox(0, 0, 222, 112, computedSummary.finalNetPl >= 0 ? "#092B1D" : "#301118", finalCol, 4);
      revCard6FinalPlSp.drawText(computedSummary.finalNetPl >= 0 ? "6. FINAL PROFIT HUA" : "6. FINAL LOSS HUA", 111, 28, 12, finalCol, 204, "center");
      revCard6FinalPlSp.drawText(
        `${computedSummary.finalNetPl >= 0 ? "+" : "-"}Rs ${Math.abs(Math.round(computedSummary.finalNetPl))}`,
        111, 74, 26, finalCol, 204, "center"
      );
      revCard6FinalPlSp.drawText("FINAL PROFIT / LOSS HISAB", 111, 100, 10, "#FFFFFF", 204, "center");
    }

    const revSubSp = hasDailyReviewScene ? makeSprite(492, 130) : null;
    if (revSubSp) {
      revSubSp.fastBox(0, 0, 492, 130, "#081018", "#00E676", 2);
      revSubSp.drawText("📊 AAJ KA EK CHHOTA REVIEW  |  SINGLE HIGHLIGHT REPORT", 16, 25, 11, "#00E676", 460, "left");
      const rLines = wrapText(revSubSp.ctx, reportReviewSubtitle, 460, 3);
      rLines.forEach((ln, idx) => {
        revSubSp.drawText(ln, 246, 54 + idx * 24, 13, "#FFFFFF", 460, "center");
      });
    }

    // Scene 4 (Outro) Modular 3D Pieces:
    // - If isShortReportMode: Renders "YEH 100% REAL HE · KOI FAKE NEHI!" + WhatsApp pre-result game posting + "THANK YOU ALL · MILTE HE FER NEXT VIDEO ME!"
    // - If Full Video: Renders exact original Full Video Scoreboard & Social Media Cards!
    const outroHeaderSp = makeSprite(452, 110);
    const outroPassSp = makeSprite(218, 115);
    const outroFailSp = makeSprite(218, 115);
    const outroNetSp = makeSprite(452, 118);
    const outroYtSp = makeSprite(452, 68);
    const outroInstaSp = makeSprite(452, 68);
    const outroTgSp = makeSprite(452, 68);
    const outroCtaSp = makeSprite(452, 44);

    if (isUnboxingMode) {
      outroHeaderSp.fastBox(0, 0, 452, 110, "#1E1606", "#FFC107", 3);
      outroHeaderSp.drawText("TITAN NOVA  ·  AAJ KA LIVE GUESSING", 226, 30, 15, "#FFC107", 430, "center");
      outroHeaderSp.drawText("PRE-RESULT GUESSING UNBOXED!", 226, 66, 21, "#FFFFFF", 430, "center");
      outroHeaderSp.drawText(`${introDateInfo.visualBadge}`, 226, 96, 12, "#20DCE9", 430, "center");

      outroPassSp.fastBox(0, 0, 218, 115, "#0B2B1E", "#00E676", 3);
      outroPassSp.drawText("LIVE PLAY RATE", 109, 32, 13, "#80CBC4", 195, "center");
      outroPassSp.drawText("VIP ONLY", 109, 82, 28, "#00E676", 195, "center");
      outroPassSp.drawText("AFTER MEMBERSHIP", 109, 105, 10, "#FFFFFF", 195, "center");

      outroFailSp.fastBox(0, 0, 218, 115, "#0E1E32", "#20DCE9", 3);
      outroFailSp.drawText("UNBOXED CARDS", 109, 32, 13, "#8DC8FF", 195, "center");
      outroFailSp.drawText(`${totalCardsCount} CARD${totalCardsCount > 1 ? "S" : ""}`, 109, 82, 30, "#20DCE9", 195, "center");
      outroFailSp.drawText("100% PRE-RESULT", 109, 105, 10, "#FFFFFF", 195, "center");

      outroNetSp.fastBox(0, 0, 452, 118, "#091420", "#FFC107", 4);
      outroNetSp.drawText("AAJ KA TITAN NOVA GUESSING GAME", 226, 34, 14, "#20DCE9", 420, "center");
      outroNetSp.drawText("RATE SHARED AFTER MEMBERSHIP", 226, 86, 22, "#FFC107", 425, "center");

      outroYtSp.fastBox(0, 0, 452, 68, "#0B2B1E", "#00E676", 3);
      outroYtSp.drawText("DAILY · WEEKLY · MONTHLY MEMBERSHIP", 226, 28, 14, "#00E676", 425, "center");
      outroYtSp.drawText("Result Se Pehle 100% Live Guessing Proof!", 226, 52, 12, "#FFFFFF", 425, "center");

      outroInstaSp.fastBox(0, 0, 452, 68, "#0B2938", "#20DCE9", 3);
      outroInstaSp.drawText("WHATSAPP & TELEGRAM CHANNEL JOIN KAREIN", 226, 28, 14, "#20DCE9", 425, "center");
      outroInstaSp.drawText("Daily VIP Game & Live Updates Paane Ke Liye!", 226, 52, 12, "#FFFFFF", 425, "center");

      outroTgSp.fastBox(0, 0, 452, 68, "#241907", "#FFC107", 3);
      outroTgSp.drawText("TITAN NOVA GUESSING TRICK SE", 226, 28, 15, "#FFC107", 425, "center");
      outroTgSp.drawText("Safe Play · Smart Recovery · 100% Transparent!", 226, 52, 12, "#FFFFFF", 425, "center");

      outroCtaSp.fastBox(0, 0, 452, 44, "#16283A", "#00E676", 2);
      outroCtaSp.drawText(options.customCta || "THANK YOU ALL  ·  JOIN CHANNEL NOW!", 226, 29, 14, "#00E676", 425, "center");
    } else if (isShortReportMode) {
      outroHeaderSp.fastBox(0, 0, 452, 110, "#0B1522", "#00E676", 3);
      outroHeaderSp.drawText("YEH 100% REAL HE  ·  KOI FAKE NEHI!", 226, 30, 15, "#00E676", 430, "center");
      outroHeaderSp.drawText("RESULT SE PEHLE GAME POSTING!", 226, 66, 22, "#FFFFFF", 430, "center");
      outroHeaderSp.drawText(`${dateStr}  |  ${computedSummary.totalCards} CARDS · ${computedSummary.totalPass} PASS · ${computedSummary.totalFail} FAIL`, 226, 96, 13, "#FFC107", 430, "center");

      outroPassSp.fastBox(0, 0, 218, 115, "#0B2B1E", "#00E676", 3);
      outroPassSp.drawText("PASS / FAIL HISAB", 109, 30, 12, "#80CBC4", 195, "center");
      outroPassSp.drawText(`${computedSummary.totalPass}P / ${computedSummary.totalFail}F`, 109, 76, 30, "#00E676", 195, "center");
      outroPassSp.drawText(`Lagataar Fail: ${computedSummary.maxConsecutiveFails}`, 109, 103, 11, "#FFFFFF", 195, "center");

      outroFailSp.fastBox(0, 0, 218, 115, "#241B08", "#FFC107", 3);
      outroFailSp.drawText("INVEST & MAX RISK", 109, 30, 12, "#FFE082", 195, "center");
      outroFailSp.drawText(`Rs ${computedSummary.totalInvest}`, 109, 76, 28, "#FFC107", 195, "center");
      outroFailSp.drawText(`Max Risk: Rs ${computedSummary.maxRiskExposure}`, 109, 103, 11, "#FFFFFF", 195, "center");

      outroNetSp.fastBox(0, 0, 452, 118, "#091420", finalCol, 4);
      outroNetSp.drawText("FINAL PROFIT / LOSS REPORT", 226, 34, 14, "#8DA6C0", 420, "center");
      outroNetSp.drawText(`${computedSummary.finalNetPl >= 0 ? "+" : "-"}Rs ${Math.abs(Math.round(computedSummary.finalNetPl))}`, 226, 94, 38, finalCol, 420, "center");

      outroYtSp.fastBox(0, 0, 452, 68, "#0B2B1E", "#00E676", 3);
      outroYtSp.drawText("WHATSAPP CHANNEL ME JUD SAKTE HE!", 226, 28, 15, "#00E676", 425, "center");
      outroYtSp.drawText("Kyu Ki Wohi Result Se Pehle Game Posting Hota He!", 226, 52, 12, "#FFFFFF", 425, "center");

      outroInstaSp.fastBox(0, 0, 452, 68, "#241907", "#FFC107", 3);
      outroInstaSp.drawText("GAME CHAHIYE YA LIVE DEMO DEKHNA HE?", 226, 28, 15, "#FFC107", 425, "center");
      outroInstaSp.drawText("Comment Me Link Pin Kiya Hua He — Direct Joining!", 226, 52, 12, "#FFFFFF", 425, "center");

      outroTgSp.fastBox(0, 0, 452, 68, "#0B2938", "#20DCE9", 3);
      outroTgSp.drawText("WHATSAPP GROUP & TELEGRAM CHANNEL", 226, 28, 15, "#20DCE9", 425, "center");
      outroTgSp.drawText("100% Real Live Proof · Koi Fake Nehi!", 226, 52, 12, "#FFFFFF", 425, "center");

      outroCtaSp.fastBox(0, 0, 452, 44, "#16283A", "#00E676", 2);
      outroCtaSp.drawText(options.customCta || "THANK YOU ALL  ·  MILTE HE FER NEXT VIDEO ME!", 226, 29, 14, "#00E676", 425, "center");
    } else {
      // EXACT ORIGINAL FULL VIDEO OUTRO SPRITES
      outroHeaderSp.fastBox(0, 0, 452, 110, "#0B1522", primaryColor, 3);
      outroHeaderSp.drawText("TITAN NOVA  ·  VERIFIED FINAL SCOREBOARD", 226, 30, 13, primaryColor, 420, "center");
      outroHeaderSp.drawText(options.period === "week" ? "WEEKLY FINAL HISAB" : "AAJ KA PURA FINAL HISAB", 226, 68, 25, "#FFFFFF", 430, "center");
      outroHeaderSp.drawText(`${dateStr}  |  ALL ${totalCardsCount} CARDS SUMMARY`, 226, 96, 13, "#8DA6C0", 430, "center");

      outroPassSp.fastBox(0, 0, 218, 115, "#0B2B1E", "#00E676", 3);
      outroPassSp.drawText("TOTAL PASS GAMES", 109, 32, 13, "#80CBC4", 195, "center");
      outroPassSp.drawText(String(totalPass), 109, 92, 38, "#00E676", 195, "center");

      outroFailSp.fastBox(0, 0, 218, 115, "#2E131A", "#FF5252", 3);
      outroFailSp.drawText("TOTAL FAIL GAMES", 109, 32, 13, "#FF8A8A", 195, "center");
      outroFailSp.drawText(String(totalFail), 109, 92, 38, "#FF5252", 195, "center");

      outroNetSp.fastBox(0, 0, 452, 118, "#091420", finalCol, 4);
      outroNetSp.drawText("FINAL NET PROFIT / LOSS", 226, 34, 14, "#8DA6C0", 420, "center");
      outroNetSp.drawText(`${finalNetPl >= 0 ? "+" : "-"}Rs ${Math.abs(Math.round(finalNetPl))}`, 226, 94, 38, finalCol, 420, "center");

      outroYtSp.fastBox(0, 0, 452, 68, "#331016", "#FF5252", 3);
      outroYtSp.drawText("YOUTUBE SHORTS: SUBSCRIBE & BELL ICON", 226, 28, 14, "#FFFFFF", 420, "center");
      outroYtSp.drawText("Rozana Step-by-Step 3D Live Replay Video ke liye!", 226, 52, 11, "#FF8A8A", 420, "center");

      outroInstaSp.fastBox(0, 0, 452, 68, "#2A1233", "#E040FB", 3);
      outroInstaSp.drawText("INSTA REELS & FACEBOOK: LIKE & FOLLOW", 226, 28, 14, "#FFFFFF", 420, "center");
      outroInstaSp.drawText("Double Tap karein aur Dosto ke sath SHARE karein!", 226, 52, 11, "#EA80FC", 420, "center");

      outroTgSp.fastBox(0, 0, 452, 68, "#0B2938", "#20DCE9", 3);
      outroTgSp.drawText("TELEGRAM & WHATSAPP: JOIN LIVE CHANNEL", 226, 28, 14, "#FFFFFF", 420, "center");
      outroTgSp.drawText("Result se pehle sabse fast official updates paayein!", 226, 52, 11, "#80DEEA", 420, "center");

      outroCtaSp.fastBox(0, 0, 452, 44, "#16283A", "#00E676", 2);
      outroCtaSp.drawText(options.customCta || "LIKE  ·  COMMENT  ·  SHARE  ·  FOLLOW", 226, 29, 14, "#00E676", 420, "center");
    }

    // Scene 3.5 (Running Day "Abhi Aage Ka Market Baki Hai" 3D Pieces):
    const pendingAlertSp = hasPendingMarkets ? makeSprite(460, 62) : null;
    if (pendingAlertSp) {
      pendingAlertSp.fastBox(0, 0, 460, 62, "#241907", "#FFC107", 3);
      pendingAlertSp.drawText("RUNNING DAY LIVE UPDATE  ·  PICTURE ABHI BAKI HAI!", 230, 40, 17, "#FFC107", 435, "center");
    }

    const pendingDoneSp = hasPendingMarkets ? makeSprite(460, 82) : null;
    if (pendingDoneSp) {
      pendingDoneSp.fastBox(0, 0, 460, 82, "#0B281B", "#00E676", 3);
      pendingDoneSp.drawText(`SETTLED COMPLETE: ${totalCardsCount} MARKETS (${totalPass} PASS)`, 230, 32, 16, "#00E676", 435, "center");
      pendingDoneSp.drawText(`LIVE NET SO FAR: ${finalNetPl >= 0 ? "+" : "-"}Rs ${Math.abs(Math.round(finalNetPl))}  |  100% VERIFIED`, 230, 62, 14, "#FFFFFF", 435, "center");
    }

    const pendingHeroSp = hasPendingMarkets ? makeSprite(460, 146) : null;
    if (pendingHeroSp) {
      pendingHeroSp.fastBox(0, 0, 460, 146, "#101E33", "#20DCE9", 4);
      pendingHeroSp.drawText(`ABHI AAGE KE ${pendingMarketsList.length} MARKETS BAKI HAIN!`, 230, 46, 22, "#FFFFFF", 435, "center");
      pendingHeroSp.drawText("DEKHTE HAIN AAGE KYA DHAMAKA HOGA!", 230, 90, 19, "#FFC107", 435, "center");
      pendingHeroSp.drawText("NEXT UPCOMING MARKETS IN LIVE QUEUE >>", 230, 126, 13, "#20DCE9", 435, "center");
    }

    const pendingChipSprites = hasPendingMarkets
      ? pendingMarketsList.slice(0, 6).map((mName, idx) => {
          const sp = makeSprite(222, 58);
          sp.fastBox(0, 0, 222, 58, "#132235", idx % 2 === 0 ? "#FFC107" : "#20DCE9", 2);
          sp.drawText(mName.slice(0, 18), 111, 26, 13, "#FFFFFF", 206, "center");
          sp.drawText("⏳ UPCOMING · WAIT", 111, 47, 11, "#FFC107", 206, "center");
          return sp.buf;
        })
      : [];

    const pendingSubSp = hasPendingMarkets ? makeSprite(492, 130) : null;
    if (pendingSubSp) {
      pendingSubSp.fastBox(0, 0, 492, 130, "#081018", "#FFC107", 2);
      pendingSubSp.drawText("⏳ RUNNING DAY STATUS  |  UPCOMING MARKETS REMAINING", 16, 25, 11, "#FFC107", 460, "left");
      const pLines = wrapText(pendingSubSp.ctx, pendingSubtitle, 460, 3);
      pLines.forEach((ln, idx) => {
        pendingSubSp.drawText(ln, 246, 54 + idx * 24, 13, "#FFFFFF", 460, "center");
      });
    }

    // Reusable single-step HUD & Subtitle buffers (saves ~55 MB RAM during video rendering)
    let cachedActiveStepIdx = -1;
    let cachedStepHudBuf: Buffer | null = null;
    let cachedStepSubBuf: Buffer | null = null;

    const wavPath = path.join(tmpDir, "soundtrack.wav");
    const outMp4 = path.join(tmpDir, "studio_shorts.mp4");

    const stepChimes = activeStepMeta.map((s, idx) => ({
      timeSec: stepTimings[idx].startSec,
      phase: s.phase,
      isPass: s.phase === 3 && (s.ev.status === "PASS" || Boolean(s.ev.isCloseZeroSkip)),
      isFail: s.phase === 3 && s.ev.status === "FAIL" && !s.ev.isCloseZeroSkip,
    }));

    generateMasterAudioWav(wavPath, totalDurationSec, options.musicStyle || "cinematic_bass", stepChimes, cardVoiceClips);

    const outScale = "scale=720:1280:flags=fast_bilinear,fps=24,setsar=1,format=yuv420p";

    await new Promise<void>((resolve, reject) => {
      const ff = spawn(
        "ffmpeg",
        [
          "-y",
          "-f", "rawvideo",
          "-pix_fmt", "rgba",
          "-s", `${WIDTH}x${HEIGHT}`,
          "-r", String(fps),
          "-i", "pipe:0",
          "-i", wavPath,
          "-vf", outScale,
          "-c:v", "libx264",
          "-preset", "ultrafast",
          "-tune", "fastdecode",
          "-threads", "0",
          "-crf", "28",
          "-pix_fmt", "yuv420p",
          "-c:a", "aac",
          "-b:a", "96k",
          "-shortest",
          "-movflags", "+faststart",
          outMp4,
        ],
        { stdio: ["pipe", "ignore", "ignore"] }
      );

      let streamClosed = false;
      ff.stdin.on("error", () => {
        streamClosed = true;
      });
      ff.on("error", (err) => {
        streamClosed = true;
        reject(err);
      });
      ff.on("close", (code) => {
        streamClosed = true;
        if (code === 0) resolve();
        else reject(new Error(`FFmpeg render exited with code ${code}`));
      });

      const workFrame = makeSprite(WIDTH, HEIGHT);
      let fIdx = 0;
      const halfIntro = (!isShortReportMode && !isUnboxingMode) ? introFrames : Math.max(1, Math.floor(introFrames * 0.46));

      const writeNext = () => {
        while (fIdx < totalFrames && !streamClosed && ff.stdin.writable) {
          const frameNum = fIdx++;

          // 1. Always render the 3D Cyber Tunnel + Radial Starfield background first
          workFrame.buf.set(getCachedCyberTunnelFrame(frameNum, primaryColor));

          if (frameNum < introFrames) {
            if (frameNum < halfIntro) {
              // ==============================================================
              // SCENE 1: HATKE 3D QUANTUM VORTEX + 8-WAY LIGHTNING STRIKE HOOK!
              // ==============================================================
              const t = frameNum / Math.max(1, halfIntro - 1);
              // Rotating 3D Quantum Portal Diamond & Corner Lightning Strikes
              for (let pRing = 0; pRing < 3; pRing++) {
                const rad = Math.round(70 + pRing * 55 + Math.sin(frameNum * 0.4 + pRing) * 18);
                drawShockwaveAndSparks(workFrame, 270, 390, ((frameNum * 0.08 + pRing * 0.33) % 1.0), "#FFC107", primaryColor, rad);
              }
              if (frameNum % 3 === 0) {
                drawLaserBeam(workFrame, 0, 0, 270, 196, "#FFC107", primaryColor, frameNum);
                drawLaserBeam(workFrame, WIDTH, 0, 270, 196, "#FFC107", "#00E676", frameNum);
              }

              // Piece 1: Alert Banner drops from sky with 3D pitch
              flyAndAssemble3DPiece(
                workFrame, hookAlertSp.buf, 452, 58,
                t, 0.0, 0.28,
                270, -130, 270, 118,
                2.2, 0.55, 0.0,
                "#FF5252", "#FFC107", frameNum, 1
              );

              // Piece 2: Headline 1 shoots in from Far Left
              flyAndAssemble3DPiece(
                workFrame, hookHead1Sp.buf, 464, 56,
                t, 0.08, 0.36,
                -320, 200, 270, 196,
                1.5, 0.0, 0.6,
                primaryColor, "#FFFFFF", frameNum, 2
              );

              // Piece 3: Headline 2 shoots in from Far Right & collides!
              flyAndAssemble3DPiece(
                workFrame, hookHead2Sp.buf, 464, 52,
                t, 0.14, 0.42,
                860, 260, 270, 262,
                1.5, 0.0, -0.6,
                "#00E676", "#FFC107", frameNum, 3
              );

              // Piece 4: Live Scoreboard zooms out from 3D camera foreground (2.6x -> 1.0x)
              flyAndAssemble3DPiece(
                workFrame, hookScoreSp.buf, 452, 185,
                t, 0.22, 0.56,
                270, 405, 270, 405,
                2.5, 0.5, 0.25,
                "#00E676", primaryColor, frameNum, 4
              );

              // Piece 5: Curiosity Box flies up from bottom
              flyAndAssemble3DPiece(
                workFrame, hookCuriositySp.buf, 452, 140,
                t, 0.34, 0.68,
                270, 1080, 270, 592,
                1.6, -0.5, 0.0,
                "#FFC107", "#FF5252", frameNum, 5
              );

              // Piece 6: Subtitle Box unfolds at bottom
              flyAndAssemble3DPiece(
                workFrame, hookSubSp.buf, 452, 140,
                t, 0.42, 0.74,
                270, 1080, 270, 756,
                1.2, -0.35, 0.0,
                primaryColor, "#FFFFFF", frameNum, 6
              );
            } else {
              // ==============================================================
              // SCENE 2: 5-PIECE 3D SHIELD FLYING ASSEMBLY ("UD KE AATA HAI FER
              // JUD JATA HAI") + KHATARNAK LASER & FIRE NAME WRITING!
              // ==============================================================
              const t = (frameNum - halfIntro) / Math.max(1, introFrames - halfIntro - 1);

              // 5 Shield Shards fly in from 5 different directions & SLAM together at (270, 195)!
              flyAndAssemble3DPiece(
                workFrame, shieldShard1Outer.buf, 196, 180,
                t, 0.0, 0.30,
                -220, -160, 270, 195,
                2.2, 0.55, 0.5,
                primaryColor, "#FFFFFF", frameNum, 10
              );
              flyAndAssemble3DPiece(
                workFrame, shieldShard2Core.buf, 158, 144,
                t, 0.04, 0.33,
                760, -160, 270, 195,
                2.2, -0.55, -0.5,
                "#FFC107", primaryColor, frameNum, 10
              );
              flyAndAssemble3DPiece(
                workFrame, shieldShard3Crown.buf, 124, 30,
                t, 0.08, 0.36,
                270, -220, 270, 152,
                2.6, 0.6, 0.0,
                "#FFFFFF", "#FFC107", frameNum, 10
              );
              flyAndAssemble3DPiece(
                workFrame, shieldShard4Blade.buf, 34, 112,
                t, 0.10, 0.38,
                270, 1080, 270, 198,
                2.6, -0.6, 0.0,
                primaryColor, "#00E676", frameNum, 10
              );
              flyAndAssemble3DPiece(
                workFrame, shieldShard5Wings.buf, 118, 60,
                t, 0.12, 0.40,
                -260, 198, 270, 206,
                2.4, 0.0, 0.65,
                "#FFC107", "#FF5252", frameNum, 10
              );

              // Giant shockwave burst when all 5 shield pieces lock together!
              if (t >= 0.32 && t <= 0.52) {
                drawShockwaveAndSparks(workFrame, 270, 195, (t - 0.32) / 0.20, "#FFC107", primaryColor, 240);
              }

              // KHATARNAK LASER & FIRE NAME WRITING ("T I T A N   N O V A")
              // Each character flies in from 3D camera depth while dual laser beams from the
              // assembled 3D shield weld & carve each letter with exploding fire sparks!
              const writeStart = 0.20;
              const writeEnd = 0.74;
              let activeLaserTargetX: number | null = null;
              let activeLaserTargetY: number | null = null;

              for (let c = 0; c < brandCharSprites.length; c++) {
                const chObj = brandCharSprites[c];
                if (chObj.ch === " ") continue;
                const cStart = writeStart + (c / brandCharSprites.length) * (writeEnd - writeStart) * 0.78;
                const cEnd = cStart + 0.16;

                if (t >= cStart && t <= cEnd) {
                  activeLaserTargetX = chObj.targetX;
                  activeLaserTargetY = chObj.targetY;
                }

                flyAndAssemble3DPiece(
                  workFrame, chObj.buf, chObj.w, chObj.h,
                  t, cStart, cEnd,
                  chObj.targetX + (c % 2 === 0 ? -140 : 140),
                  chObj.targetY + 120,
                  chObj.targetX,
                  chObj.targetY,
                  2.8, 0.55, c % 2 === 0 ? 0.6 : -0.6,
                  "#FFC107", primaryColor, frameNum, 20 + c
                );
              }

              // Fire the dual laser welding beams from the 3D Shield to the active letter!
              if (activeLaserTargetX !== null && activeLaserTargetY !== null) {
                drawLaserBeam(workFrame, 250, 255, activeLaserTargetX, activeLaserTargetY, "#FFFFFF", "#FFC107", frameNum);
                drawLaserBeam(workFrame, 290, 255, activeLaserTargetX, activeLaserTargetY, "#FFFFFF", primaryColor, frameNum);
              } else if (t > writeEnd) {
                // High-speed golden light blade sweeping across the completed 3D name
                const sweepProg = ((t - writeEnd) / (1 - writeEnd)) % 1.0;
                const sweepX = Math.round(50 + sweepProg * 440);
                workFrame.fastBox(sweepX - 8, 314, 16, 68, "#FFC107");
                workFrame.fastBox(sweepX - 3, 314, 6, 68, "#FFFFFF");
              }

              // Tagline & 3 Strategy Strips fly in from alternating sides and assemble below!
              flyAndAssemble3DPiece(
                workFrame, brandTaglineSp.buf, 452, 38,
                t, 0.42, 0.66,
                -300, 404, 270, 404,
                1.4, 0.0, 0.5,
                "#FFC107", "#FFFFFF", frameNum, 40
              );
              flyAndAssemble3DPiece(
                workFrame, brandProfileSp.buf, 452, 108,
                t, 0.48, 0.72,
                840, 492, 270, 492,
                1.5, 0.35, -0.5,
                "#00E676", primaryColor, frameNum, 41
              );
              flyAndAssemble3DPiece(
                workFrame, brandFeat1Sp.buf, 452, 54,
                t, 0.56, 0.78,
                -300, 594, 270, 594,
                1.4, 0.0, 0.45,
                "#20DCE9", "#FFFFFF", frameNum, 42
              );
              flyAndAssemble3DPiece(
                workFrame, brandFeat2Sp.buf, 452, 54,
                t, 0.64, 0.84,
                840, 660, 270, 660,
                1.4, 0.0, -0.45,
                "#FFC107", "#FFFFFF", frameNum, 43
              );
              flyAndAssemble3DPiece(
                workFrame, brandFeat3Sp.buf, 452, 54,
                t, 0.70, 0.90,
                270, 1060, 270, 726,
                1.6, -0.45, 0.0,
                "#00E676", "#FFC107", frameNum, 44
              );
            }

            const prog = (frameNum + 1) / introFrames;
            workFrame.fastBox(44, 865, Math.round(452 * prog), 10, "#00E676");
          } else if (hasDailyReviewScene && frameNum >= reviewStartFrame && frameNum < pendingStartFrame) {
            // ================================================================
            // SCENE 3.2: 3D "AAJ KA CHHOTA REVIEW" (6-METRIC DAILY REPORT)!
            // ================================================================
            const t = (frameNum - reviewStartFrame) / Math.max(1, reviewFrames - 1);

            if (revHeaderSp) {
              flyAndAssemble3DPiece(
                workFrame, revHeaderSp.buf, 460, 88,
                t, 0.0, 0.22,
                270, -140, 270, 118,
                2.1, 0.5, 0.0,
                "#FFC107", primaryColor, frameNum, 60
              );
            }

            // 6 3D Stat Cards fly in from Left/Right and lock into a 2x3 3D Grid!
            const revCards = [
              { sp: revCard1TotalSp, col: 0, row: 0, c1: "#20DCE9", c2: "#FFFFFF", start: 0.08 },
              { sp: revCard2PassFailSp, col: 1, row: 0, c1: "#00E676", c2: "#FFFFFF", start: 0.14 },
              { sp: revCard3InvestSp, col: 0, row: 1, c1: "#FFC107", c2: "#FFFFFF", start: 0.20 },
              { sp: revCard4StreakSp, col: 1, row: 1, c1: "#FF5252", c2: "#FFC107", start: 0.26 },
              { sp: revCard5RiskSp, col: 0, row: 2, c1: "#E040FB", c2: "#FFFFFF", start: 0.32 },
              { sp: revCard6FinalPlSp, col: 1, row: 2, c1: finalCol, c2: "#FFC107", start: 0.38 },
            ];

            for (let rcIdx = 0; rcIdx < revCards.length; rcIdx++) {
              const rc = revCards[rcIdx];
              if (!rc.sp) continue;
              const targetX = rc.col === 0 ? 153 : 387;
              const targetY = 252 + rc.row * 132;
              const fromX = rc.col === 0 ? -240 : 780;
              flyAndAssemble3DPiece(
                workFrame, rc.sp.buf, 222, 112,
                t, rc.start, rc.start + 0.24,
                fromX, targetY + 50, targetX, targetY,
                1.9, 0.35, rc.col === 0 ? 0.55 : -0.55,
                rc.c1, rc.c2, frameNum, 61 + rcIdx
              );
            }

            if (t >= 0.44 && t <= 0.70) {
              drawShockwaveAndSparks(workFrame, 270, 384, (t - 0.44) / 0.26, "#00E676", "#FFC107", 240);
            }

            if (options.showSubtitles !== false && revSubSp) {
              blitSprite(workFrame.buf, WIDTH, HEIGHT, revSubSp.buf, 492, 130, 24, 796);
              for (let bar = 0; bar < 28; bar++) {
                const wave = Math.abs(Math.sin(frameNum * 0.85 + bar * 0.55));
                const barH = Math.max(3, Math.round(wave * 16));
                workFrame.fastBox(44 + bar * 16, 948 - barH, 10, barH, "#00E676");
              }
            }
          } else if (hasPendingMarkets && frameNum >= pendingStartFrame && frameNum < outroStartFrame) {
            // ================================================================
            // SCENE 3.5: RUNNING DAY "ABHI AAGE KA MARKET BAKI HAI" 3D SCENE!
            // ================================================================
            const t = (frameNum - pendingStartFrame) / Math.max(1, pendingFrames - 1);

            if (pendingAlertSp) {
              flyAndAssemble3DPiece(
                workFrame, pendingAlertSp.buf, 460, 62,
                t, 0.0, 0.24,
                270, -140, 270, 110,
                2.1, 0.5, 0.0,
                "#FFC107", "#FF5252", frameNum, 70
              );
            }
            if (pendingDoneSp) {
              flyAndAssemble3DPiece(
                workFrame, pendingDoneSp.buf, 460, 82,
                t, 0.08, 0.34,
                -300, 198, 270, 198,
                1.5, 0.0, 0.55,
                "#00E676", "#FFFFFF", frameNum, 71
              );
            }
            if (pendingHeroSp) {
              flyAndAssemble3DPiece(
                workFrame, pendingHeroSp.buf, 460, 146,
                t, 0.16, 0.46,
                270, 332, 270, 332,
                2.7, 0.55, -0.25,
                "#20DCE9", "#FFC107", frameNum, 72
              );
            }
            if (t >= 0.36 && t <= 0.62) {
              drawShockwaveAndSparks(workFrame, 270, 332, (t - 0.36) / 0.26, "#FFC107", "#20DCE9", 220);
            }

            for (let cIdx = 0; cIdx < pendingChipSprites.length; cIdx++) {
              const col = cIdx % 2;
              const row = Math.floor(cIdx / 2);
              const targetX = col === 0 ? 153 : 387;
              const targetY = 462 + row * 72;
              const fromX = col === 0 ? -240 : 780;
              const cStart = 0.26 + cIdx * 0.07;
              const cEnd = cStart + 0.24;
              flyAndAssemble3DPiece(
                workFrame, pendingChipSprites[cIdx], 222, 58,
                t, cStart, cEnd,
                fromX, targetY + 60, targetX, targetY,
                1.8, 0.35, col === 0 ? 0.55 : -0.55,
                "#FFC107", "#20DCE9", frameNum, 75 + cIdx
              );
            }

            if (options.showSubtitles !== false && pendingSubSp) {
              blitSprite(workFrame.buf, WIDTH, HEIGHT, pendingSubSp.buf, 492, 130, 24, 796);
              for (let bar = 0; bar < 28; bar++) {
                const wave = Math.abs(Math.sin(frameNum * 0.85 + bar * 0.55));
                const barH = Math.max(3, Math.round(wave * 16));
                workFrame.fastBox(44 + bar * 16, 948 - barH, 10, barH, "#FFC107");
              }
            }
          } else if (frameNum >= outroStartFrame) {
            // ================================================================
            // SCENE 4 (OUTRO): 3D FLYING SCOREBOARD & SOCIAL MEDIA CARDS!
            // ================================================================
            const t = (frameNum - outroStartFrame) / Math.max(1, outroFrames - 1);

            flyAndAssemble3DPiece(
              workFrame, outroHeaderSp.buf, 452, 110,
              t, 0.0, 0.25,
              270, -140, 270, 128,
              2.0, 0.5, 0.0,
              primaryColor, "#FFFFFF", frameNum, 50
            );
            flyAndAssemble3DPiece(
              workFrame, outroPassSp.buf, 218, 115,
              t, 0.10, 0.36,
              -240, 262, 153, 262,
              1.8, 0.0, 0.55,
              "#00E676", "#FFFFFF", frameNum, 51
            );
            flyAndAssemble3DPiece(
              workFrame, outroFailSp.buf, 218, 115,
              t, 0.14, 0.40,
              780, 262, 387, 262,
              1.8, 0.0, -0.55,
              "#FF5252", "#FFC107", frameNum, 52
            );
            flyAndAssemble3DPiece(
              workFrame, outroNetSp.buf, 452, 118,
              t, 0.22, 0.50,
              270, 398, 270, 398,
              2.6, 0.55, 0.0,
              finalCol, "#FFC107", frameNum, 53
            );
            flyAndAssemble3DPiece(
              workFrame, outroYtSp.buf, 452, 68,
              t, 0.34, 0.60,
              -300, 518, 270, 518,
              1.5, 0.0, 0.5,
              "#FF5252", "#FFFFFF", frameNum, 54
            );
            flyAndAssemble3DPiece(
              workFrame, outroInstaSp.buf, 452, 68,
              t, 0.42, 0.68,
              840, 598, 270, 598,
              1.5, 0.0, -0.5,
              "#E040FB", "#FFC107", frameNum, 55
            );
            flyAndAssemble3DPiece(
              workFrame, outroTgSp.buf, 452, 68,
              t, 0.50, 0.76,
              -300, 678, 270, 678,
              1.5, 0.0, 0.5,
              "#20DCE9", "#FFFFFF", frameNum, 56
            );
            flyAndAssemble3DPiece(
              workFrame, outroCtaSp.buf, 452, 44,
              t, 0.58, 0.84,
              270, 1060, 270, 752,
              2.0, -0.5, 0.0,
              "#00E676", "#FFC107", frameNum, 57
            );
          } else {
            // ================================================================
            // SCENE 3: 3D ANIMATED STEP-BY-STEP CARD ASSEMBLY FOR EVERY CARD!
            // ================================================================
            let activeStepIdx = stepTimings.findIndex((st) => frameNum >= st.startFrame && frameNum < st.endFrame);
            if (activeStepIdx === -1) activeStepIdx = activeStepMeta.length - 1;

            const curStep = activeStepMeta[activeStepIdx];
            const curTiming = stepTimings[activeStepIdx];
            const stepProgress = (frameNum - curTiming.startFrame) / Math.max(1, curTiming.endFrame - curTiming.startFrame);
            const grp = cardGroups[curStep.cardIdx];

            // Camera shake when the 3D Result Stamp slams down in Step 3!
            let camShakeX = 0;
            let camShakeY = 0;
            if (curStep.phase === 3 && stepProgress >= 0.36 && stepProgress <= 0.56) {
              camShakeX = (frameNum % 2 === 0 ? 1 : -1) * 7;
              camShakeY = (frameNum % 3 === 0 ? 1 : -1) * 6;
            }

            const isUnboxStep = curStep.ev.action === "UNBOXING_REVEAL";
            let slideOffsetX = 0;
            let slideTiltY = 0;
            if (isUnboxStep) {
              if (stepProgress < 0.22) {
                const enterT = easeOutCubic(stepProgress / 0.22);
                slideOffsetX = (1 - enterT) * -460;
                slideTiltY = (1 - enterT) * -0.45;
              } else if (stepProgress > 0.88) {
                const exitT = (stepProgress - 0.88) / 0.12;
                slideOffsetX = exitT * exitT * 460;
                slideTiltY = exitT * 0.40;
              }
            }
            const cardCenterX = 270 + camShakeX + slideOffsetX;
            const cardTopY = 186 + camShakeY;

            const isSingleShotCard = curStep.ev.action === "TRAILER_HIGHLIGHT" || curStep.ev.action === "CARD_SKIPPED" || isUnboxStep;
            // 1. 3D Card Chassis unfolds in 3D perspective (or slides Left-to-Right in Unboxing Mode)
            const chassisEntryT = (curStep.phase === 1 || isSingleShotCard) ? Math.min(1, stepProgress / 0.26) : 1.0;
            const chassisScale = isUnboxStep ? (0.94 + 0.06 * easeOutBack(chassisEntryT)) : (0.82 + 0.18 * easeOutBack(chassisEntryT));
            const chassisTiltX = (isUnboxStep ? 0 : (1 - easeOutCubic(chassisEntryT)) * 0.42) + Math.sin(frameNum * 0.22) * 0.03;
            const chassisTiltY = slideTiltY + Math.cos(frameNum * 0.20) * 0.04;
            blitSprite3D(
              workFrame.buf, WIDTH, HEIGHT,
              grp.chassisBuf, 492, 490,
              cardCenterX, cardTopY + 245,
              chassisScale, chassisScale,
              chassisTiltX, chassisTiltY,
              174, 792
            );

            // 2. Market Header flies down from top & snaps into top of card
            flyAndAssemble3DPiece(
              workFrame, grp.headerBuf, 468, 88,
              (curStep.phase === 1 || isSingleShotCard) ? stepProgress : 1.0,
              0.0, 0.25,
              270, -60, cardCenterX, cardTopY + 52,
              1.7, 0.45, 0.0,
              primaryColor, "#FFC107", frameNum, 101, 174, 792
            );

            // 3. Step 1 Trick Formula Box flies in from the left
            flyAndAssemble3DPiece(
              workFrame, grp.sec1BoxBuf, 460, 124,
              (curStep.phase === 1 || isSingleShotCard) ? stepProgress : 1.0,
              0.08, 0.34,
              -250, cardTopY + 170, cardCenterX, cardTopY + 170,
              1.35, 0.0, 0.5,
              "#20DCE9", "#FFFFFF", frameNum, 102, 174, 792
            );

            // 3.5. If this is an UNBOXING_REVEAL card, a 3D Golden Sealed Vault Cover splits & flies open first!
            if (isUnboxStep && stepProgress < 0.36) {
              const sealP = stepProgress / 0.36;
              drawShockwaveAndSparks(workFrame, cardCenterX, cardTopY + 170, sealP, "#FFC107", "#00E5FF", 240);
              drawLaserBeam(workFrame, 40, cardTopY + 110, 500, cardTopY + 220, "#FFFFFF", "#FFC107", frameNum);
              drawLaserBeam(workFrame, 500, cardTopY + 110, 40, cardTopY + 220, "#FFFFFF", "#00E5FF", frameNum);
            }

            // 4. Individual 3D Guessing Digit Tiles fly in one-by-one from all directions (or burst from center box in Unboxing Mode) & lock into Step 1!
            const numDigits = Math.max(1, grp.digitTiles.length);
            for (let dIdx = 0; dIdx < grp.digitTiles.length; dIdx++) {
              const dt = grp.digitTiles[dIdx];
              const dStart = isUnboxStep ? (0.20 + (dIdx / numDigits) * 0.46) : (0.18 + (dIdx / numDigits) * 0.44);
              const dEnd = isUnboxStep ? (dStart + 0.14) : (dStart + 0.22);
              if (isUnboxStep && stepProgress >= dStart && stepProgress <= dEnd + 0.06) {
                drawShockwaveAndSparks(workFrame, dt.targetCenterX + slideOffsetX + camShakeX, dt.targetCenterY + camShakeY, (stepProgress - dStart) / 0.20, "#FFC107", "#00E5FF", 75);
              }
              const isWinHighlight = curStep.phase === 3 && dt.isWinner && stepProgress > 0.38;
              const tileBuf = isWinHighlight ? dt.winBuf : dt.normalBuf;

              flyAndAssemble3DPiece(
                workFrame, tileBuf, dt.w, dt.h,
                (curStep.phase === 1 || isSingleShotCard) ? stepProgress : 1.0,
                dStart, dEnd,
                isUnboxStep ? cardCenterX : dt.fromX,
                isUnboxStep ? cardTopY + 170 : dt.fromY,
                dt.targetCenterX + slideOffsetX + camShakeX,
                dt.targetCenterY + camShakeY,
                2.5, 0.45, dIdx % 2 === 0 ? 0.6 : -0.6,
                "#20DCE9", "#FFC107", frameNum, 110 + dIdx, 174, 792
              );

              if (isWinHighlight) {
                // Winning digit pops forward in 3D scale!
                blitSprite3D(
                  workFrame.buf, WIDTH, HEIGHT,
                  dt.winBuf, dt.w, dt.h,
                  dt.targetCenterX + camShakeX,
                  dt.targetCenterY + camShakeY - 4,
                  1.24, 1.24, 0, Math.sin(frameNum * 0.5) * 0.12,
                  174, 792
                );
              }
            }

            // 5. Step 2 Rate Logic Box & 3 Rate Sub-Badges fly in from Left, Top, Right & assemble ("jud jata he")!
            if (curStep.phase >= 2) {
              const s2T = (curStep.phase === 2 || isSingleShotCard) ? stepProgress : 1.0;
              flyAndAssemble3DPiece(
                workFrame, grp.sec2BoxBuf, 460, 112,
                s2T, 0.0, 0.28,
                820, cardTopY + 298, cardCenterX, cardTopY + 298,
                1.45, 0.0, -0.55,
                "#FFC107", primaryColor, frameNum, 120, 174, 792
              );
              flyAndAssemble3DPiece(
                workFrame, grp.sec2BadgeLeft, 140, 48,
                s2T, 0.14, 0.44,
                -220, cardTopY + 298, cardCenterX - 150, cardTopY + 298,
                2.1, 0.35, 0.55,
                "#00E676", "#FFFFFF", frameNum, 121, 174, 792
              );
              flyAndAssemble3DPiece(
                workFrame, grp.sec2BadgeMid, 140, 48,
                s2T, 0.22, 0.52,
                270, -120, cardCenterX, cardTopY + 298,
                2.3, 0.55, 0.0,
                "#FFC107", "#FFFFFF", frameNum, 122, 174, 792
              );
              flyAndAssemble3DPiece(
                workFrame, grp.sec2BadgeRight, 134, 48,
                s2T, 0.30, 0.60,
                780, cardTopY + 298, cardCenterX + 148, cardTopY + 298,
                2.1, -0.35, -0.55,
                "#00E676", "#FFC107", frameNum, 123, 174, 792
              );
            }

            // 6. Step 3 Live Result Container + Giant 3D Result Stamp SLAM from camera foreground!
            if (curStep.phase === 3) {
              const s3T = stepProgress;
              flyAndAssemble3DPiece(
                workFrame, grp.sec3BoxBuf, 460, 112,
                s3T, 0.0, 0.26,
                270, 990, cardCenterX, cardTopY + 420,
                1.5, -0.5, 0.0,
                grp.borderColPassFail, "#FFFFFF", frameNum, 130, 174, 792
              );

              // Giant 3D Stamp zooms in from camera foreground (scale 3.0 -> 1.0) and SLAMS into Step 3!
              flyAndAssemble3DPiece(
                workFrame, grp.stamp3DBuf, 296, 54,
                s3T, 0.16, 0.46,
                270, 320, cardCenterX + 68, cardTopY + 398,
                3.0, 0.6, -0.35,
                grp.borderColPassFail, "#FFC107", frameNum, 131, 174, 792
              );

              // Massive Shockwave & Firework burst when the 3D Stamp slams down!
              if (s3T >= 0.36 && s3T <= 0.78) {
                const burstP = (s3T - 0.36) / 0.42;
                drawShockwaveAndSparks(
                  workFrame,
                  cardCenterX + 68,
                  cardTopY + 398,
                  burstP,
                  grp.borderColPassFail,
                  "#FFC107",
                  230
                );
              }
            }

            // Active laser progress bar at bottom of current step
            const activeColor = curStep.ev.isCloseZeroSkip
              ? "#00E5FF"
              : curStep.phase === 3
              ? grp.borderColPassFail
              : curStep.phase === 2
              ? "#FFC107"
              : "#20DCE9";
            workFrame.fastBox(40, 682, Math.max(24, Math.round(460 * stepProgress)), 6, activeColor);

            if (cachedActiveStepIdx !== activeStepIdx || !cachedStepHudBuf || !cachedStepSubBuf) {
              cachedActiveStepIdx = activeStepIdx;
              cachedStepHudBuf = renderStepHudSprite(
                dateStr,
                profName,
                curStep.cardIdx,
                totalCardsCount,
                curStep.phase,
                curStep.passSoFar,
                curStep.failSoFar,
                curStep.runningPl,
                (activeStepIdx + 1) / Math.max(1, allEvents.length),
                cardGroups,
                headerBg,
                primaryColor
              );
              const subSp = makeSprite(492, 130);
              const subBorder = curStep.ev.isCloseZeroSkip
                ? "#00E5FF"
                : curStep.phase === 3
                ? (curStep.ev.status === "PASS" ? "#00E676" : "#FF5252")
                : curStep.phase === 2
                ? "#FFC107"
                : primaryColor;
              subSp.fastBox(0, 0, 492, 130, "#081018", subBorder, 2);
              const phaseTitle = curStep.ev.isCloseZeroSkip
                ? "CLOSE ZERO LOGIC: OPEN PASS -> CLOSE Rs 0 SKIP"
                : curStep.phase === 1
                ? "STEP 1: NORMAL CARD & GUESSING TRICK"
                : curStep.phase === 2
                ? "STEP 2: RATE LOGIC (SMART STAKE / CARRY / WAVE)"
                : "STEP 3: LIVE RESULT & NEXT CARD PLAN";
              subSp.drawText(`CARD #${curStep.cardIdx + 1}/${totalCardsCount}  |  ${phaseTitle}`, 16, 25, 11, subBorder, 460, "left");
              const subLines = wrapText(subSp.ctx, curStep.subtitle, 460, 3);
              subLines.forEach((ln, idx) => {
                subSp.drawText(ln, 246, 54 + idx * 24, 13, "#FFFFFF", 460, "center");
              });
              cachedStepSubBuf = subSp.buf;
            }

            // Top HUD
            blitSprite(workFrame.buf, WIDTH, HEIGHT, cachedStepHudBuf, WIDTH, 172, 0, 0);

            // Bottom Subtitle + Live Equalizer
            if (options.showSubtitles !== false) {
              blitSprite(workFrame.buf, WIDTH, HEIGHT, cachedStepSubBuf, 492, 130, 24, 796);
              for (let bar = 0; bar < 28; bar++) {
                const wave = Math.abs(Math.sin(frameNum * 0.85 + bar * 0.55));
                const barH = Math.max(3, Math.round(wave * 16));
                workFrame.fastBox(44 + bar * 16, 948 - barH, 10, barH, activeColor);
              }
            }
          }

          try {
            const canContinue = ff.stdin.write(workFrame.buf);
            if (!canContinue) {
              ff.stdin.once("drain", writeNext);
              return;
            }
          } catch {
            streamClosed = true;
            return;
          }
        }
        if (!streamClosed && ff.stdin.writable) {
          try {
            ff.stdin.end();
          } catch {}
        }
      };

      writeNext();
    });

    let finalOutMp4 = outMp4;
    if (useWaStatusVideoIntro) {
      const mergedMp4 = path.join(tmpDir, "studio_with_wa_intro.mp4");
      const cachedIntroMp4 = path.join(os.tmpdir(), "titan_wa_intro_720x1280_v2.mp4");
      try {
        if (!fs.existsSync(cachedIntroMp4) || fs.statSync(cachedIntroMp4).size < 4096) {
          await execFileAsync(
            "ffmpeg",
            [
              "-y",
              "-i", waStatusIntroPath,
              "-vf", "crop=405:720:420:0,scale=720:1280:flags=fast_bilinear,fps=24,setsar=1,format=yuv420p",
              "-af", "aresample=22050,aformat=sample_fmts=fltp:channel_layouts=mono,volume=1.15",
              "-c:v", "libx264",
              "-preset", "ultrafast",
              "-crf", "26",
              "-c:a", "aac",
              "-b:a", "96k",
              "-ar", "22050",
              "-ac", "1",
              cachedIntroMp4,
            ],
            { timeout: 60000, maxBuffer: 8 * 1024 * 1024 }
          );
        }
        await execFileAsync(
          "ffmpeg",
          [
            "-y",
            "-i", cachedIntroMp4,
            "-i", outMp4,
            "-filter_complex",
            "[0:v]fps=24,setsar=1,format=yuv420p[v0];[1:v]fps=24,setsar=1,format=yuv420p[v1];[0:a]aresample=22050,aformat=sample_fmts=fltp:channel_layouts=mono[a0];[1:a]aresample=22050,aformat=sample_fmts=fltp:channel_layouts=mono[a1];[v0][a0][v1][a1]concat=n=2:v=1:a=1[v][a]",
            "-map", "[v]",
            "-map", "[a]",
            "-c:v", "libx264",
            "-preset", "ultrafast",
            "-tune", "fastdecode",
            "-threads", "0",
            "-crf", "28",
            "-c:a", "aac",
            "-b:a", "96k",
            "-movflags", "+faststart",
            mergedMp4,
          ],
          { timeout: 60000, maxBuffer: 16 * 1024 * 1024 }
        );
        if (fs.existsSync(mergedMp4) && fs.statSync(mergedMp4).size > 4096) {
          finalOutMp4 = mergedMp4;
        }
      } catch (concatErr) {
        console.error("[VideoStudio] WA Status intro concat failed:", concatErr);
      }
    }
    const shiftedVoiceScript = (useWaStatusVideoIntro && finalOutMp4 !== outMp4)
      ? voiceScript.map((c) => ({
          ...c,
          startSec: Number((c.startSec + 4.27).toFixed(2)),
          endSec: Number((c.endSec + 4.27).toFixed(2)),
        }))
      : voiceScript;
    const buffer = fs.readFileSync(finalOutMp4);
    return {
      available: true,
      buffer,
      mimeType: "video/mp4",
      frameCount: totalFrames,
      hasEmbeddedVoice,
      voiceScript: shiftedVoiceScript,
    };
  } finally {
    try {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    } catch {}
  }
}

export async function renderActivityGifVideo(
  events: ActivityTimelineEvent[],
  options: VideoStudioOptions = {}
): Promise<{
  available: boolean;
  buffer?: Buffer;
  mimeType: string;
  frameCount: number;
  hasEmbeddedVoice: boolean;
  voiceScript: VoiceCueItem[];
}> {
  const next = renderQueuePromise.then(
    () => renderActivityGifVideoInternal(events, options),
    () => renderActivityGifVideoInternal(events, options)
  );
  renderQueuePromise = next.catch(() => {});
  return next;
}
