import fs from 'node:fs';
import path from 'node:path';

export type ActivityActionType =
  | 'DIGITS_APPLIED'
  | 'RATE_LOCKED'
  | 'CARD_SENT'
  | 'RESULT_SETTLED'
  | 'PROFIT_MILESTONE';

export interface ActivityTimelineEvent {
  id: string;
  ts: number;
  timeIST: string;
  date: string;
  profileId: string;
  market: string;
  type: 'ank' | 'jodi' | 'pannel' | 'system';
  action: ActivityActionType;
  digits?: string;
  rate?: string;
  invest?: number;
  status?: 'WAIT' | 'PASS' | 'FAIL' | 'SKIP' | 'SENT';
  actual?: string;
  pl?: number;
  netDayPl?: number;
  trick?: string;
  sourceMode?: string;
  subtitle: string;
}

export class ActivityRecorder {
  private readonly dir: string;
  private readonly recentKeys = new Map<string, number>();

  constructor(dataDir: string) {
    this.dir = path.join(dataDir, 'activity_timeline');
    try {
      fs.mkdirSync(this.dir, { recursive: true });
    } catch (_) {}
  }

  private fileForDate(date: string): string {
    const clean = String(date || '').replace(/[^0-9-]/g, '').slice(0, 10);
    return path.join(this.dir, `${clean || 'unknown'}.jsonl`);
  }

  private formatTimeIST(ts: number): string {
    try {
      return new Date(ts).toLocaleTimeString('en-IN', {
        timeZone: 'Asia/Kolkata',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
      });
    } catch {
      return '';
    }
  }

  /** Append a single main business activity event with 5s dedupe for identical events. */
  record(input: Omit<ActivityTimelineEvent, 'id' | 'ts' | 'timeIST'> & { ts?: number }): ActivityTimelineEvent | null {
    try {
      if (!input.date || !/^\d{4}-\d{2}-\d{2}$/.test(input.date)) return null;
      const ts = input.ts || Date.now();
      const dedupeKey = `${input.date}|${input.profileId}|${input.market}|${input.type}|${input.action}|${input.digits || ''}|${input.rate || ''}|${input.status || ''}|${input.actual || ''}`;
      const lastTs = this.recentKeys.get(dedupeKey) || 0;
      if (ts - lastTs < 5000) return null;
      this.recentKeys.set(dedupeKey, ts);
      if (this.recentKeys.size > 500) {
        const cutoff = ts - 60_000;
        for (const [k, v] of this.recentKeys.entries()) {
          if (v < cutoff) this.recentKeys.delete(k);
        }
      }

      const event: ActivityTimelineEvent = {
        id: `act_${ts}_${Math.random().toString(36).slice(2, 7)}`,
        ts,
        timeIST: this.formatTimeIST(ts),
        ...input,
      };

      fs.mkdirSync(this.dir, { recursive: true });
      fs.appendFileSync(this.fileForDate(input.date), `${JSON.stringify(event)}\n`, 'utf8');
      return event;
    } catch {
      return null;
    }
  }

  readDate(date: string, profileId?: string): ActivityTimelineEvent[] {
    try {
      const file = this.fileForDate(date);
      if (!fs.existsSync(file)) return [];
      const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/).filter(Boolean);
      const events: ActivityTimelineEvent[] = [];
      for (const line of lines) {
        try {
          const parsed = JSON.parse(line) as ActivityTimelineEvent;
          if (profileId && parsed.profileId && parsed.profileId !== profileId) continue;
          events.push(parsed);
        } catch (_) {}
      }
      return events;
    } catch {
      return [];
    }
  }

  /** Clean up timeline logs older than maxDays (default 30 days) to keep disk lean. */
  pruneOlderThan(maxDays = 30): number {
    try {
      if (!fs.existsSync(this.dir)) return 0;
      const cutoff = Date.now() - maxDays * 86_400_000;
      let removed = 0;
      for (const entry of fs.readdirSync(this.dir)) {
        if (!entry.endsWith('.jsonl')) continue;
        const datePart = entry.slice(0, 10);
        const parsed = Date.parse(`${datePart}T00:00:00Z`);
        if (Number.isFinite(parsed) && parsed < cutoff) {
          fs.unlinkSync(path.join(this.dir, entry));
          removed++;
        }
      }
      return removed;
    } catch {
      return 0;
    }
  }
}
