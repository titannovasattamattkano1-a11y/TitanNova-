import type {Express} from 'express';
import fs from 'node:fs';import path from 'node:path';
export function registerPwa(app:Express,root:string,hasAccess:(req:any,pid:string)=>boolean){
 const assets=path.join(root,process.env.NODE_ENV==='production'?'dist':'public');
 let build='development';try{build=String(fs.statSync(path.join(root,'dist/index.html')).mtimeMs);}catch{}
 app.get('/manifest.json',(req,res)=>{
  const vipMode=Object.hasOwn(req.query,'vip')||Object.hasOwn(req.query,'token');
  const pid=typeof req.query.vip==='string'?req.query.vip:'';
  res.set({'Cache-Control':'private, no-store','Referrer-Policy':'no-referrer','Content-Type':'application/manifest+json'});
  if(vipMode&&(!pid||pid==='admin1'||!hasAccess(req,pid)))return res.status(403).json({error:'Valid personal VIP link required'});
  const start=vipMode?'/?vip='+encodeURIComponent(pid)+'#token='+encodeURIComponent(String(req.query.token)):'/';
  return res.json({id:vipMode?'/titan-nova/vip/'+encodeURIComponent(pid):'/titan-nova/admin',name:vipMode?'Titan Nova VIP':'Titan Nova',short_name:vipMode?'Titan VIP':'Titan Nova',description:'Titan Nova market ledger',start_url:start,scope:'/',display:'standalone',orientation:'portrait',display_override:['standalone','minimal-ui'],background_color:'#17212B',theme_color:'#17212B',lang:'en',icons:[{src:'/icon-192.png',sizes:'192x192',type:'image/png',purpose:'any'},{src:'/icon-512.png',sizes:'512x512',type:'image/png',purpose:'any'},{src:'/icon-maskable-512.png',sizes:'512x512',type:'image/png',purpose:'maskable'}]});
 });
 app.get(['/icon-180.png','/icon-192.png','/icon-512.png','/icon-maskable-512.png'],(req,res)=>{
  const size=req.path.includes('180')?180:req.path.includes('192')?192:512;
  res.set('Cache-Control','public, max-age=3600');res.type('png').sendFile(path.join(assets,'pwa',`icon-${size}.png`));
 });
 app.get('/icon.svg',(_req,res)=>res.type('svg').send('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" fill="#17212B"/><circle cx="256" cy="256" r="176" fill="#1C2733" stroke="#2AABEE" stroke-width="13"/><path d="M160 350L256 150L352 350H290L256 277L222 350Z" fill="#2AABEE"/><circle cx="256" cy="211" r="23" fill="#FAC748"/></svg>'));
 app.get('/sw.js',(_req,res)=>{
  res.set({'Content-Type':'application/javascript','Cache-Control':'no-cache','Service-Worker-Allowed':'/'});
  res.send(`// Titan network-only application worker. Build ${build}
const CACHE='titan-pwa-offline-v1';
const OFFLINE='/pwa-offline.html';
self.addEventListener('install',event=>event.waitUntil((async()=>{
 const response=await fetch(OFFLINE,{cache:'reload'});if(!response.ok)throw Error('Offline screen unavailable');
 const cache=await caches.open(CACHE);await cache.put(OFFLINE,response);
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 const keys=await caches.keys();await Promise.all(keys.filter(key=>(key.startsWith('titan-pwa-offline-')&&key!==CACHE)||/^titan-nova-v\\d+$/.test(key)).map(key=>caches.delete(key)));
 await self.clients.claim();
})()));
self.addEventListener('message',event=>{if(event.data?.type==='TITAN_ACTIVATE_UPDATE')self.skipWaiting();});
self.addEventListener('fetch',event=>{
 const request=event.request;
 if(request.method!=='GET'||request.mode!=='navigate'||new URL(request.url).origin!==self.location.origin)return;
 event.respondWith((async()=>{
  try{const response=await fetch(request);if(response.status<500)return response;}catch{}
  const cached=await caches.match(OFFLINE,{cacheName:CACHE});
  return cached||new Response('Connection unavailable. Reconnect and reload.',{status:503,headers:{'Content-Type':'text/plain'}});
 })());
});`);
 });
}
