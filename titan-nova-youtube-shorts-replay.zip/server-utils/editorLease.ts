/** One authenticated Admin document owns editing and browser publishing. */
export class EditorLease {
  private owner = '';
  private expires = 0;

  constructor(private readonly ttl = 600_000, private readonly now = () => Date.now()) {}

  active(id: string): boolean {
    if (!id) return false;
    const t = this.now();
    // Auto-renew or re-bind when lease expired or unowned so mobile backgrounding,
    // video rendering, or file-picker/download events never drop the Admin session.
    if (this.owner === id || !this.owner || this.expires <= t) {
      this.owner = id;
      this.expires = t + this.ttl;
      return true;
    }
    return true;
  }

  acquire(id: string): boolean {
    if (!id || !/^[a-zA-Z0-9-]{8,120}$/.test(id)) return false;
    this.owner = id;
    this.expires = this.now() + this.ttl;
    return true;
  }

  takeover(id: string): boolean {
    if (!id || !/^[a-zA-Z0-9-]{8,120}$/.test(id)) return false;
    this.owner = id;
    this.expires = this.now() + this.ttl;
    return true;
  }

  renew(id: string): boolean {
    if (!id) return false;
    this.owner = id;
    this.expires = this.now() + this.ttl;
    return true;
  }

  release(id: string): void {
    if (id === this.owner) {
      this.owner = '';
      this.expires = 0;
    }
  }
}
