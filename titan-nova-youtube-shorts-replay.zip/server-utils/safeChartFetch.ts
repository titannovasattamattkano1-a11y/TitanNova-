import { lookup } from 'node:dns/promises';
import { Agent as HttpAgent } from 'node:http';
import { Agent as HttpsAgent } from 'node:https';
import { isIP } from 'node:net';
import ipaddr from 'ipaddr.js';

export class ChartDestinationError extends Error {}
export function publicChartAddress(address: string, allowLoopback = false): boolean {
  try {
    let parsed = ipaddr.parse(address);
    if (parsed.kind() === 'ipv6' && (parsed as ipaddr.IPv6).isIPv4MappedAddress()) parsed = (parsed as ipaddr.IPv6).toIPv4Address();
    return parsed.range() === 'unicast' || (allowLoopback && parsed.range() === 'loopback');
  } catch { return false; }
}
export function chartUrl(value: string): URL {
  let url: URL;
  try { url = new URL(value); } catch { throw new ChartDestinationError('Valid public HTTP(S) chart URL required'); }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) {
    throw new ChartDestinationError('Only public HTTP(S) chart URLs without credentials are allowed');
  }
  return url;
}
async function abortable<T>(promise: Promise<T>, signal: AbortSignal): Promise<T> {
  if (signal.aborted) throw new Error('Chart request timed out');
  let onAbort: () => void = () => {};
  try {
    return await Promise.race([promise, new Promise<never>((_, reject) => {
      onAbort = () => reject(new Error('Chart request timed out'));
      signal.addEventListener('abort', onAbort, { once: true });
    })]);
  } finally { signal.removeEventListener('abort', onAbort); }
}

/** DNS is validated AND pinned to the connection. Every redirect is revalidated. */
export async function safeChartFetch(value: string, init: { signal: AbortSignal; headers?: Record<string, string> }, allowLoopback = false, resolver?: (hostname:string)=>Promise<Array<{address:string;family:number}>>, allowedHosts?: readonly string[]): Promise<Response> {
  const { default: nodeFetch } = await import('node-fetch');
  let url = chartUrl(value);
  for (let redirects = 0; redirects <= 5; redirects++) {
    if(allowedHosts&&!allowedHosts.includes(url.hostname.toLowerCase()))throw new ChartDestinationError('Chart redirect/provider is not allowed');
    const hostname = url.hostname.replace(/^\[|\]$/g, '');
    const addresses = isIP(hostname)
      ? [{ address: hostname, family: isIP(hostname) }]
      : await abortable(resolver?resolver(hostname):lookup(hostname, { all: true, verbatim: false }), init.signal);
    if (!addresses.length || addresses.some(item => !publicChartAddress(item.address, allowLoopback))) {
      throw new ChartDestinationError('Private, local and reserved network chart destinations are blocked');
    }
    // Prefer IPv4, but a refused/unreachable DNS address must not hide a
    // healthy address for the same publisher. All addresses remain validated.
    const ordered=[...addresses.filter(item=>item.family===4),...addresses.filter(item=>item.family!==4)];
    let raw:any,agent:HttpAgent|HttpsAgent|undefined,lastError:unknown;
    for(let i=0;i<ordered.length;i++){
      if(init.signal.aborted)throw new DOMException('Chart request cancelled','AbortError');
      let connectionError:unknown;
      const selected=ordered[i],controller=new AbortController(),abort=()=>controller.abort();
      init.signal.addEventListener('abort',abort,{once:true});if(init.signal.aborted)abort();
      // Bound a dead connection so other validated addresses get a turn.
      const timer=i<ordered.length-1?setTimeout(abort,2000):undefined;
      const pinnedLookup=(_host:string,options:any,callback:any)=>{
        queueMicrotask(()=>{if(options?.all)callback(null,[selected]);else callback(null,selected.address,selected.family);});
      };
      const Agent=url.protocol==='https:'?HttpsAgent:HttpAgent;
      const candidateAgent=new Agent({lookup:pinnedLookup as any,family:selected.family,autoSelectFamily:false});
      const connect=candidateAgent.createConnection.bind(candidateAgent);
      candidateAgent.createConnection=((options:any,callback:any)=>{
        const socket=connect(options,callback);
        // A connected publisher may legitimately take time to generate HTML;
        // the short address timeout applies only to TCP/TLS connection setup.
        socket?.on('error',(error:Error)=>{connectionError=error;if(!raw)controller.abort();});
        socket?.once(url.protocol==='https:'?'secureConnect':'connect',()=>{if(timer)clearTimeout(timer);});
        return socket;
      }) as typeof candidateAgent.createConnection;
      const cleanup=()=>{if(timer)clearTimeout(timer);init.signal.removeEventListener('abort',abort);candidateAgent.destroy();};
      try{
        raw=await nodeFetch(url,{...init,signal:controller.signal,agent:candidateAgent,redirect:'manual'});
        if(timer)clearTimeout(timer);
        agent=candidateAgent;
        if(raw.body)raw.body.once('close',cleanup);else cleanup();
        break;
      }catch(error){cleanup();lastError=connectionError||error;if(init.signal.aborted)throw error;}
    }
    if(!raw||!agent)throw lastError||new Error('No reachable chart address');
    if ([301, 302, 303, 307, 308].includes(raw.status)) {
      const location = raw.headers.get('location');
      raw.body?.destroy(); agent.destroy();
      if (!location || redirects === 5) throw new ChartDestinationError('Invalid or excessive chart redirects');
      url = chartUrl(new URL(location, url).href);
      continue;
    }
    if(raw.status===204||raw.status===304)raw.body?.destroy();
    // Explicit cancellation guard avoids enqueue-after-cancel races in Node's
    // Readable.toWeb adapter when a rejected HTTP body arrives concurrently.
    let body: ReadableStream<Uint8Array> | null = null;
    if (raw.body && raw.status !== 204 && raw.status !== 304) {
      const source = raw.body;
      const iterator = source[Symbol.asyncIterator]();
      let cancelled = false;
      body = new ReadableStream<Uint8Array>({
        async pull(controller) {
          try {
            const next = await iterator.next();
            if (cancelled) return;
            if (next.done) controller.close(); else controller.enqueue(new Uint8Array(next.value));
          } catch (error) { if (!cancelled) controller.error(error); }
        },
        async cancel() {
          cancelled = true; source.destroy();
          try { await iterator.return?.(); } catch { /* Intentional cancellation. */ }
        },
      });
    }
    const response = new Response(body, {
      status: raw.status, statusText: raw.statusText, headers: Object.fromEntries(raw.headers.entries()),
    });
    Object.defineProperty(response, 'url', { value: url.href });
    return response;
  }
  throw new ChartDestinationError('Too many chart redirects');
}

export async function readChartBody(response: Response, maxBytes: number): Promise<string> {
  if (!response.body) return '';
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  const parts: string[] = [];
  let bytes = 0;
  try {
    while (bytes < maxBytes) {
      const { done, value } = await reader.read();
      if (done) break;
      const take = value.subarray(0, maxBytes - bytes);
      bytes += take.byteLength;
      parts.push(decoder.decode(take, { stream: true }));
    }
    parts.push(decoder.decode());
    return parts.join('');
  } finally {
    // Cancel as soon as enough metadata is available, including compressed bodies.
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}
