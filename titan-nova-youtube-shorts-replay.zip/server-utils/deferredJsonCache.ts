import {writeFile,rename,unlink} from 'node:fs/promises';

/** Noncritical chart cache only: coalesce writes without blocking chart replies. */
export class DeferredJsonCache {
 private timer:ReturnType<typeof setTimeout>|undefined;
 private running:Promise<void>|undefined;
 private revision=0;
 private written=0;
 constructor(private file:string,private snapshot:()=>string,private onError:(error:unknown)=>void,private delayMs=500){}
 schedule(){
  this.revision++;clearTimeout(this.timer);
  this.timer=setTimeout(()=>{void this.flush().catch(this.onError);},this.delayMs);
 }
 async flush():Promise<void>{
  clearTimeout(this.timer);this.timer=undefined;
  if(this.running){await this.running;return this.flush();}
  if(this.written===this.revision)return;
  const revision=this.revision;
  this.running=(async()=>{
   const temp=`${this.file}.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2)}.tmp`;
   try{const json=this.snapshot();await writeFile(temp,json,'utf8');await rename(temp,this.file);this.written=revision;}
   catch(error){await unlink(temp).catch(()=>{});throw error;}
  })().finally(()=>{this.running=undefined;});
  await this.running;
  if(this.written!==this.revision)await this.flush();
 }
}
