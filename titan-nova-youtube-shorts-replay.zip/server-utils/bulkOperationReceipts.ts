import {createHash} from 'node:crypto';

export type BulkReceipt={id:string;kind:'clear'|'undo';profileId:string;date:string;signature:string;at:number;indices?:number[];results?:any[];profileIds?:string[];cards?:number};
/** Small server-owned proofs, committed inside the same archive write as the reset.
 * Only the newest 512 are retained. Clients use these for readback, never POST retries. */
export class BulkOperationReceipts {
  private receipts:BulkReceipt[];
  constructor(saved:unknown){this.receipts=Array.isArray(saved)?saved.filter(r=>r&&typeof r.id==='string'&&['clear','undo'].includes(r.kind)).slice(-512):[];}
  snapshot(){return this.receipts;}
  find(id:string){return this.receipts.find(r=>r.id===id);}
  prepare(body:any,kind:BulkReceipt['kind']):BulkReceipt|undefined {
    if(body?.operationId===undefined)return;
    const id=String(body.operationId);
    if(!/^[a-zA-Z0-9_-]{12,100}$/.test(id))throw Object.assign(Error('Invalid bulk operation ID'),{statusCode:400});
    const signature=createHash('sha256').update(JSON.stringify(body)).digest('hex');
    const prior=this.find(id);
    if(prior&&(prior.signature!==signature||prior.kind!==kind))throw Object.assign(Error('Bulk operation ID belongs to a different command'),{statusCode:409});
    return prior||{id,kind,profileId:String(body.profileId||'admin1'),date:String(body.date||''),signature,at:Date.now()};
  }
  commit(receipt:BulkReceipt|undefined,write:()=>void){
    const before=this.receipts;
    if(receipt)this.receipts=[...before.filter(r=>r.id!==receipt.id),receipt].slice(-512);
    try{write();}catch(error){this.receipts=before;throw error;}
  }
}
