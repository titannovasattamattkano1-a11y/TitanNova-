/** Accept only actual 24-hour times or valid 12-hour AM/PM times.
 * Invalid page fragments (e.g. 99:99) must never become saved market schedules. */
export type ClockTime = {hr:number;min:number};
export function validChartClockTimes(html:string):ClockTime[] {
  const matches=String(html||'').match(/\b\d{1,2}:[0-5]\d(?:\s*[AP]M)?\b/gi)||[];
  const times:ClockTime[]=[];
  for(const text of matches){
    const m=/^(\d{1,2}):([0-5]\d)(?:\s*(AM|PM))?$/i.exec(text.trim());
    if(!m)continue;
    let hr=Number(m[1]);const min=Number(m[2]);const suffix=m[3]?.toUpperCase();
    if(suffix){
      if(hr<1||hr>12)continue;
      hr=(hr%12)+(suffix==='PM'?12:0);
    } else if(hr>23)continue;
    times.push({hr,min});
  }
  return times;
}
