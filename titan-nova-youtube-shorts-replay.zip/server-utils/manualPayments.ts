import {randomUUID} from 'node:crypto';
import type {Express} from 'express';
import {validatePaymentProof,normalizePaymentUtr,extendPaymentExpiry} from '../src/utils/manualPayments';
import {businessDateIST} from '../src/utils/businessDate';
export function registerManualPayments(app:Express,io:{read:()=>any;write:(state:any)=>void;isVip:(req:any)=>boolean;hasAccess:(req:any,pid:string)=>boolean}){
 app.get('/api/app/payments',(req,res)=>{
  try{
   const state=io.read();if(!state)return res.status(404).json({status:'error',message:'State not found'});
   const pid=String(req.query.profileId||'');
   if(io.isVip(req)&&(!pid||!io.hasAccess(req,pid)))return res.status(403).json({status:'error',message:'Own VIP profile required'});
   const payments=(state.payments||[]).filter((p:any)=>!io.isVip(req)||p.userId===pid);
   const profiles=Object.entries(state.profiles).filter(([id])=>!io.isVip(req)||id===pid);
   res.set('Cache-Control','no-store');
   return res.json({status:'success',payments,paymentMethods:state.paymentMethods||{},expiries:Object.fromEntries(profiles.map(([id,p]:any)=>[id,p.expiryDate||'']))});
  }catch(error:any){return res.status(500).json({status:'error',message:error.message});}
 });
 app.post('/api/app/payments/submit',(req,res)=>{
  try{
   const profileId=String(req.body?.profileId||'');
   if(!profileId||profileId==='admin1'||!io.hasAccess(req,profileId))return res.status(403).json({status:'error',message:'Own VIP profile required'});
   const proof=validatePaymentProof(req.body),state=io.read(),profile=state?.profiles?.[profileId];
   if(!profile)return res.status(404).json({status:'error',message:'Profile not found'});
   const payments=Array.isArray(state.payments)?state.payments:[];
   const previous=payments.find((p:any)=>normalizePaymentUtr(p.utr)===proof.utr);
   if(previous){
    if(previous.userId===profileId&&previous.status==='pending'&&previous.amount===proof.amount&&previous.planLabel===proof.planLabel)return res.json({status:'success',payment:previous});
    return res.status(409).json({status:'error',message:'This UTR has already been submitted. Contact Admin for verification.'});
   }
   const payment={...proof,id:randomUUID(),userId:profileId,userName:profile.name,status:'pending',autoFlag:'pending',time:new Date().toISOString(),submittedAt:new Date().toISOString()};
   io.write({...state,payments:[payment,...payments]});
   return res.json({status:'success',payment});
  }catch(error:any){return res.status(error instanceof TypeError?400:/Amount|UTR|Screenshot/.test(error.message)?400:500).json({status:'error',message:error.message||'Payment proof save failed'});}
 });
 app.post('/api/app/payments/settings',(req,res)=>{
  if(io.isVip(req))return res.status(403).json({status:'error',message:'Admin required'});
  try{
   const upi=String(req.body?.upi||'').trim(),phone=String(req.body?.phone||'').trim(),qr=req.body?.qr||'';
   if(!/^[a-zA-Z0-9._-]{2,256}@[a-zA-Z0-9.-]{2,64}$/.test(upi))return res.status(400).json({status:'error',message:'Valid UPI ID required'});
   if(phone&&!/^\+?[0-9 ]{7,20}$/.test(phone))return res.status(400).json({status:'error',message:'Valid contact phone required'});
   validatePaymentProof({amount:500,planLabel:'1 Day - ₹500',utr:'123456789012',image:qr});
   const state=io.read();if(!state)return res.status(404).json({status:'error',message:'State not found'});
   const paymentMethods={upi,phone,qr};io.write({...state,paymentMethods,paymentSettingsManaged:true});
   return res.json({status:'success',paymentMethods});
  }catch(error:any){return res.status(/Screenshot/.test(error.message)?400:500).json({status:'error',message:error.message});}
 });
 app.post('/api/app/payments/review',(req,res)=>{
  if(io.isVip(req))return res.status(403).json({status:'error',message:'Admin verification required'});
  try{
   const {action,items}=req.body||{};
   if(!['approve','reject'].includes(action)||!Array.isArray(items)||!items.length||items.length>500||new Set(items.map((p:any)=>p?.id)).size!==items.length)return res.status(400).json({status:'error',message:'Valid unique payment requests required'});
   const state=io.read();if(!state)return res.status(404).json({status:'error',message:'State not found'});
   const payments=[...(state.payments||[])],profiles={...state.profiles},reviewedAt=new Date().toISOString();
   for(const item of items){
    const index=payments.findIndex((p:any)=>p.id===item?.id),payment=payments[index];
    if(!payment)return res.status(404).json({status:'error',message:'Payment not found'});
    const target=action==='approve'?'approved':'rejected';
    if(payment.status===target)continue; // Retry/double click never extends twice.
    if(payment.status!=='pending')return res.status(409).json({status:'error',message:'Payment already reviewed'});
    const profile=profiles[payment.userId];if(!profile)return res.status(404).json({status:'error',message:'Payment profile not found'});
    if(action==='approve'){
     if(!Number.isInteger(item.days)||item.days<1||item.days>3660)return res.status(400).json({status:'error',message:'Valid access days required'});
     if(payments.some((p:any,i:number)=>i!==index&&normalizePaymentUtr(p.utr)===normalizePaymentUtr(payment.utr)))return res.status(409).json({status:'error',message:'Duplicate UTR must be resolved before approval'});
     profiles[payment.userId]={...profile,expiryDate:extendPaymentExpiry(profile.expiryDate,businessDateIST(),item.days)};
    }
    payments[index]={...payment,status:target,reviewedAt,reviewedBy:'admin1',...(action==='approve'?{accessDays:item.days}:{})};
   }
   io.write({...state,payments,profiles});
   const userIds=[...new Set(items.map((item:any)=>payments.find((p:any)=>p.id===item.id).userId))];
   return res.json({status:'success',payments,expiries:Object.fromEntries(userIds.map((id:any)=>[id,profiles[id].expiryDate||'']))});
  }catch(error:any){return res.status(500).json({status:'error',message:error.message||'Payment review failed'});}
 });
}
