import {isImmutableFullStateView} from './fullStateReader';
import { createHash } from 'node:crypto';

/** Invoke only after authorizing this exact Admin/VIP snapshot. */
export function workspaceSnapshot(state: any, knownHash?: unknown) {
  if (state && typeof knownHash === 'string' && /^[a-f0-9]{64}$/.test(knownHash)) {
    const hash = createHash('sha256').update(JSON.stringify(state)).digest('hex');
    if (hash === knownHash) return { status: 'success', exists: true, unchanged: true, stateHash: hash };
  }
  return { status: 'success', exists: Boolean(state), state };
}

const encodedSnapshots=new WeakMap<object,{json:string;hash?:string}>();

/** Encode the authorized state once, even when the client's old hash misses. */
export function serializeWorkspaceSnapshot(state:any,knownHash?:unknown):string {
  let encoded=isImmutableFullStateView(state)?encodedSnapshots.get(state):undefined;
  if(!encoded){encoded={json:JSON.stringify(state)};if(isImmutableFullStateView(state))encodedSnapshots.set(state,encoded);}
  const json=encoded.json;
  if(state&&typeof knownHash==='string'&&/^[a-f0-9]{64}$/.test(knownHash)){
    const hash=encoded.hash??=createHash('sha256').update(json).digest('hex');
    if(hash===knownHash)return JSON.stringify({status:'success',exists:true,unchanged:true,stateHash:hash});
  }
  return `{"status":"success","exists":${Boolean(state)}${json===undefined?'':`,"state":${json}`}}`;
}
