import * as PImage from 'pureimage';
import path from 'node:path';
import {Writable} from 'node:stream';
import {areSettlementTokensValid,countSettlementTokens} from './src/utils/settlement';
import type {DigitSupport} from './src/utils/digitSupport';
import type {GameType} from './src/types';

export interface ScheduledCardImage {
  marketName:string; type:GameType; digits:string; date:string;
  rateNum:number; investTotal:number; detailedMessage:boolean;
  digitSupport?:Record<string,DigitSupport>;
}
let fontReady:Promise<void>|undefined;
function loadFont(){
  return fontReady??=(async()=>{await PImage.registerFont(path.resolve(process.env.TITAN_APP_ROOT||process.cwd(),'assets/fonts/TitanCard.ttf'),'TitanCard').load();})();
}
export function scheduledCardImage(input:any):ScheduledCardImage{
  const type=input.type==='panel'?'pannel':input.type||input.cardType;
  const digits=String(input.digits||'').trim(),rateNum=Number(input.rateNum??input.invest??0);
  const tokens=digits.split(/[,|\s]+/).filter(Boolean);
  if(!['ank','jodi','pannel'].includes(type)||!areSettlementTokensValid(type,digits)||tokens.length>1000||!Number.isFinite(rateNum)||rateNum<=0)throw new Error('Invalid scheduled card image data');
  const investTotal=Number(input.investTotal??countSettlementTokens(digits,type)*rateNum);
  if(!Number.isFinite(investTotal)||investTotal<=0)throw new Error('Invalid scheduled stake');
  const marketName=String(input.marketName||'').trim();
  if(!marketName||marketName.length>300)throw new Error('Invalid market name');
  const support=input.digitSupport;
  const usedSupport=new Set<string>();
  const digitSupport=support&&typeof support==='object'?Object.fromEntries(tokens.filter(t=>{const label=support[t];if(!['Strong','Support','SupportLow'].includes(label)||usedSupport.has(label))return false;usedSupport.add(label);return true;}).map(t=>[t,support[t] as DigitSupport])):undefined;
  return {...(digitSupport&&Object.keys(digitSupport).length?{digitSupport}:{}),marketName,type,digits,date:String(input.date||'').slice(0,32),rateNum,investTotal,detailedMessage:input.detailedMessage!==false};
}
/** Pure JS rasterization: deterministic actual card data, no Chromium/native dependency. */
export async function renderScheduledCardPng(input:ScheduledCardImage):Promise<Buffer>{
  const data=scheduledCardImage(input);await loadFont();
  const tokens=data.digits.split(/[,|\s]+/).filter(Boolean);
  const columns=tokens.length<=6?3:tokens.length<=20?5:10;
  const rowCount=Math.ceil(tokens.length/columns),rowHeight=tokens.length<=10?150:92;
  const gridTop=370,footerHeight=data.detailedMessage?230:80;
  const height=Math.max(1080,gridTop+rowCount*rowHeight+40+footerHeight),width=1080;
  const gridHeight=height-gridTop-footerHeight;
  const image=PImage.make(width,height),ctx=image.getContext('2d');
  // Low-cost gradient writes the raster directly, rather than allocating a canvas per pixel.
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const i=(y*width+x)*4,t=y/height;
    const qx=Math.abs(x-width/2)-(width/2-62),qy=Math.abs(y-height/2)-(height/2-62);
    const edge=Math.hypot(Math.max(qx,0),Math.max(qy,0))+Math.min(Math.max(qx,qy),0)-32;
    const border=edge<=0&&edge>=-3;
    image.data[i]=border?32:Math.round(12-6*t);image.data[i+1]=border?220:Math.round(41-20*t);image.data[i+2]=border?233:Math.round(66-30*t);image.data[i+3]=255;
  }
  const rounded=(x:number,y:number,w:number,h:number,r:number)=>{
    ctx.beginPath();ctx.moveTo(x+r,y);ctx.lineTo(x+w-r,y);ctx.quadraticCurveTo(x+w,y,x+w,y+r);
    ctx.lineTo(x+w,y+h-r);ctx.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
    ctx.lineTo(x+r,y+h);ctx.quadraticCurveTo(x,y+h,x,y+h-r);
    ctx.lineTo(x,y+r);ctx.quadraticCurveTo(x,y,x+r,y);ctx.closePath();
  };
  const text=(value:string,x:number,y:number,size:number,color='#eef7ff',max=960,align:'left'|'center'|'right'='center')=>{
    let font=size;ctx.font=`${font}pt TitanCard`;
    while(ctx.measureText(value).width>max&&font>10){font--;ctx.font=`${font}pt TitanCard`;}
    const measured=ctx.measureText(value).width;
    ctx.fillStyle=color;ctx.fillText(value,x-(align==='center'?measured/2:align==='right'?measured:0),y);
  };
  const line=(y:number)=>{ctx.fillStyle='#20dce9';ctx.fillRect(70,y,940,2);};
  const dateMatch=/^(\d{4})-(\d{2})-(\d{2})$/.exec(data.date);
  const month=dateMatch?['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'][Number(dateMatch[2])-1]:undefined;
  const dateLabel=dateMatch&&month?`${dateMatch[3]} ${month} ${dateMatch[1]}`:data.date;
  text('TITAN NOVA',540,115,66);text(dateLabel,540,165,24,'#9db8cd');line(195);
  const side=/\s+(OPEN|CLOSE)$/i.exec(data.marketName)?.[1].toUpperCase();
  const market=side?data.marketName.replace(/\s+(OPEN|CLOSE)$/i,'').trim():data.marketName;
  text(market.toUpperCase(),540,278,48);
  ctx.fillStyle='#20dce9';rounded(355,292,370,56,28);ctx.fill();
  text(`${side?side+' · ':''}${data.type==='pannel'?'PANEL':data.type.toUpperCase()}`,540,330,27,'#062034',340);
  ctx.fillStyle='#102f48';rounded(65,gridTop,950,gridHeight,24);ctx.fill();
  const highlightedTokens=new Set<string>();
  tokens.forEach((token,i)=>{
    const row=Math.floor(i/columns),col=i%columns;
    const items=Math.min(columns,tokens.length-row*columns);
    const cellWidth=900/columns,x=540+(col-(items-1)/2)*cellWidth;
    const y=gridTop+(gridHeight-rowCount*rowHeight)/2+row*rowHeight+rowHeight*.74;
    const support=highlightedTokens.has(token)?undefined:data.digitSupport?.[token];
    if(support){
      highlightedTokens.add(token);
      // Solid colours, never translucent numerals. Each selected digit owns a
      // round badge with enough room for its unchanged token and a separate label.
      const radius=Math.min(cellWidth*.36,rowHeight*.35);
      const top=gridTop+(gridHeight-rowCount*rowHeight)/2+row*rowHeight;
      const center=top+rowHeight*.43;
      const fill=support==='Strong'?'#00884f':support==='Support'?'#79ce9d':'#cdedd9';
      ctx.fillStyle=fill;ctx.beginPath();ctx.arc(x,center,radius,0,Math.PI*2);ctx.fill();
      const size=tokens[i].length===1?radius*1.45:radius*.78;
      text(token,x,center+size*.34,size,support==='Strong'?'#ffffff':'#073b20',radius*1.65);
      text(support==='Strong'?'Strong':'Support',x,top+rowHeight*.95,tokens.length<=10?19:13,'#eef7ff',cellWidth-10);
    }else{
      text(token,x,y,data.type==='ank'&&tokens.length<=10?125:tokens.length<=10?65:42,'#ffffff',cellWidth-14);
    }
  });
  if(data.detailedMessage){
    const y=gridTop+gridHeight+35;line(y);
    const money=(n:number)=>`₹${n.toLocaleString('en-IN',{maximumFractionDigits:2})}`;
    text('RATE / DIGIT',75,y+65,26,'#9db8cd',420,'left');text(money(data.rateNum),1005,y+65,36,'#eef7ff',470,'right');
    text('TOTAL STAKE',75,y+132,26,'#9db8cd',420,'left');text(money(data.investTotal),1005,y+132,36,'#eef7ff',470,'right');
  }
  const chunks:Buffer[]=[];
  await PImage.encodePNGToStream(image,new Writable({write(chunk,_encoding,callback){chunks.push(Buffer.from(chunk));callback();}}));
  return Buffer.concat(chunks);
}
