import {Worker} from 'node:worker_threads';
import path from 'node:path';
import {scheduledCardImage,type ScheduledCardImage} from './schedule-card-png';
interface Job {id:number;key:string;data:ScheduledCardImage;resolve:(value:Buffer)=>void;reject:(error:Error)=>void;timer?:ReturnType<typeof setTimeout>}
let worker:Worker|undefined,active:Job|undefined,nextId=0,cacheBytes=0;
const queue:Job[]=[],cache=new Map<string,Buffer>();
const pending=new Map<string,Promise<Buffer>>();
const MAX_CACHE_BYTES=8*1024*1024;
function fail(source:Worker,error:Error){
  if(worker!==source)return;
  worker=undefined;void source.terminate();
  const job=active;active=undefined;if(job){clearTimeout(job.timer);job.reject(error);}
  pump();
}
function pump(){
  if(active||!queue.length)return;
  if(!worker){
    worker=new Worker(path.resolve(process.env.TITAN_APP_ROOT||process.cwd(),'dist/card-png-worker.cjs'));
    const source=worker;source.unref();
    source.on('message',message=>{
      if(worker!==source||!active||message.id!==active.id)return;
      const job=active;active=undefined;clearTimeout(job.timer);
      if(message.error)job.reject(new Error(message.error));
      else{
        const png=Buffer.from(message.png);
        if(png.length<=MAX_CACHE_BYTES){
          while(cache.size&&(cache.size>=8||cacheBytes+png.length>MAX_CACHE_BYTES)){
            const key=cache.keys().next().value!;cacheBytes-=cache.get(key)!.length;cache.delete(key);
          }
          cache.set(job.key,png);cacheBytes+=png.length;
        }
        job.resolve(png);
      }
      pump();
    });
    source.on('error',error=>fail(source,error));
    source.on('exit',()=>fail(source,new Error('Card renderer stopped')));
    source.unref();
  }
  const source=worker;active=queue.shift()!;
  active.timer=setTimeout(()=>fail(source,new Error('Card renderer timed out; retry later')),10000);
  source.postMessage({id:active.id,data:active.data});
}
/** Serial, bounded raster work off the server event loop. Cache only exact immutable snapshots. */
export function renderScheduledCardPngAsync(input:ScheduledCardImage):Promise<Buffer>{
  const data=scheduledCardImage(input),key=JSON.stringify(data),hit=cache.get(key);
  if(hit){cache.delete(key);cache.set(key,hit);return Promise.resolve(hit);}
  const inflight=pending.get(key);if(inflight)return inflight;
  if(queue.length>=8)return Promise.reject(new Error('Card renderer busy; retry later'));
  const promise=new Promise<Buffer>((resolve,reject)=>{queue.push({id:++nextId,key,data,resolve,reject});pump();});
  pending.set(key,promise);void promise.then(()=>pending.delete(key),()=>pending.delete(key));return promise;
}
export async function closeScheduledCardRenderer(){
  const source=worker;worker=undefined;
  if(active){clearTimeout(active.timer);active.reject(new Error('Card renderer closed'));active=undefined;}
  for(const job of queue.splice(0))job.reject(new Error('Card renderer closed'));
  cache.clear();cacheBytes=0;if(source)await source.terminate();
}
