import { createHash } from 'node:crypto';

export function retryDelay(error, attempts) {
  const code = Number(error?.output?.statusCode || error?.statusCode || 0);
  const denied = [401, 403, 404].includes(code) || /not allowed|forbidden|not.authorized|not.a.participant/i.test(String(error?.message || ''));
  const serverWait = Number(error?.retryAfter || 0) * 1000;
  return Math.max(serverWait, denied ? 30 * 60_000 : Math.min(30 * 60_000, 30_000 * 2 ** Math.min(attempts - 1, 6)));
}

/** Serialize and deterministically pace actual sends. No simulated human behaviour. */
export function createSendControl({
  failures = {},
  save = () => {},
  now = Date.now,
  sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms)),
  minIntervalMs = 1000,
} = {}) {
  let tail = Promise.resolve();
  let lastAttemptAt = 0;
  const persist = () => { try { save(failures); } catch (error) { console.warn('Send cooldown persistence failed:', error.message); } };
  return (send) => (jid, content, options) => {
    const key = createHash('sha256').update(JSON.stringify([jid, content])).digest('hex');
    const execute = async () => {
      const previous = failures[key];
      if (previous?.retryAt > now()) {
        const error = new Error(`Send paused until ${new Date(previous.retryAt).toISOString()}`);
        error.code = 'TITAN_SEND_COOLDOWN';
        throw error;
      }
      const remaining = Math.max(0, lastAttemptAt + Math.max(0, minIntervalMs) - now());
      if (lastAttemptAt > 0 && remaining > 0) await sleep(remaining);
      const {titanBeforeSend,...sendOptions}=options||{};
      if(titanBeforeSend)await titanBeforeSend();
      lastAttemptAt = now();
      try {
        const result = await send(jid, content, options?sendOptions:undefined);
        if (failures[key]) { delete failures[key]; persist(); }
        return result;
      } catch (error) {
        const attempts = (previous?.attempts || 0) + 1;
        failures[key] = { attempts, retryAt: now() + retryDelay(error, attempts) };
        persist();
        throw error;
      }
    };
    const pending = tail.then(execute, execute);
    tail = pending.then(() => undefined, () => undefined);
    return pending;
  };
}

/** Keep transport liveness independent from slow serialized delivery work. */
export function startIndependentHeartbeat({ pulse, intervalMs = 10000, timeoutMs = 8000, setIntervalFn = setInterval, clearIntervalFn = clearInterval, setTimeoutFn = setTimeout, clearTimeoutFn = clearTimeout }) {
  let stopped = false;
  let controller = null;
  const tick = async () => {
    if (stopped || controller) return;
    const current = new AbortController();
    controller = current;
    const timeout = setTimeoutFn(() => current.abort(), timeoutMs);
    try { await pulse(current.signal); } catch { /* Next heartbeat retries; delivery is independent. */ }
    finally { clearTimeoutFn(timeout); if (controller === current) controller = null; }
  };
  const timer = setIntervalFn(tick, intervalMs);
  timer?.unref?.();
  void tick();
  return () => { stopped = true; clearIntervalFn(timer); controller?.abort(); };
}
