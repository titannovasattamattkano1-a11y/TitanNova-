import {normalizeBroadcastLink} from './scripts/broadcast-link.mjs';
import {decodeBroadcastPng} from './scripts/broadcast-png.mjs';
import {renderScheduledCardPngAsync} from './schedule-card-renderer';
import {scheduledCardImage} from './schedule-card-png';
import {CustomFile} from 'teleproto/client/uploads';
import fs from 'node:fs';
import path from 'node:path';
import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import type { Express } from 'express';
import { TelegramClient, Api, utils } from 'teleproto';
import { StringSession } from 'teleproto/sessions';
import { NewMessage } from 'teleproto/events';
import bigInt from 'big-integer';
import { isTelegramTarget } from './src/utils/targetNormalization';
import { telegramResultSignal } from './src/utils/telegramResultSignal';

type Chat = { jid: string; name: string; kind: 'group' | 'channel' | 'user' };
type Dependencies = {
  dataDir: string;
  port: number;
  sources: () => string[];
  monitoring: () => boolean;
  autoSend: () => boolean;
  selection: (field: 'resultReadGroups' | 'targetGroups', values: string[]) => void;
  clientFactory?: (session: StringSession, apiId: number, apiHash: string) => TelegramClient;
  pollIntervalMs?: number;
  canSwitchAccount?: () => boolean;
  // Test-only tuning hooks. Production defaults stay conservative.
  restoreInitialDelayMs?: number;
  restoreRetryBaseMs?: number;
  restoreRetryMaxMs?: number;
  runtimeDisconnectGraceMs?: number;
  connectionWatchIntervalMs?: number;
  targetFailureBackoffMs?: number;
  deliveryMinIntervalMs?: number;
  targetMinIntervalMs?: number;
  targetMaxPerHour?: number;
  contentReplayWindowMs?: number;
  runtimeState?: (state: { online: boolean; sessionId: string; startedAt: number }) => void;
};

/** Account adapter only. Calculation, eligibility and settlement stay in server.ts. */
export function installTelegramGateway(app: Express, deps: Dependencies) {
  const configPath = path.join(deps.dataDir, 'titan_telegram_session.json');
  const tokenPath = path.join(deps.dataDir, 'titan_telegram_control_token');
  const sentPath = path.join(deps.dataDir, 'titan_telegram_delivery.json');
  const incomingPath = path.join(deps.dataDir, 'titan_telegram_incoming.json');
  const safetyPath = path.join(deps.dataDir, 'titan_telegram_delivery_safety.json');
  // V14.06: WhatsApp and Telegram both perform expensive full chat discovery.
  // Serialize only that discovery work across PM2 processes; message delivery,
  // schedules, incoming monitoring and reconnects remain independent.
  const discoveryLockPath = path.join(deps.dataDir, 'titan_gateway_discovery.lock');
  const discoveryOwner = `telegram:${process.pid}`;
  const acquireDiscoveryLock = (): (() => void) | undefined => {
    const tryAcquire = (): (() => void) | undefined => {
      try {
        const fd = fs.openSync(discoveryLockPath, 'wx', 0o600);
        fs.writeFileSync(fd, JSON.stringify({ owner: discoveryOwner, at: Date.now() }));
        return () => {
          try { fs.closeSync(fd); } catch {}
          try {
            const current = JSON.parse(fs.readFileSync(discoveryLockPath, 'utf8'));
            if (current?.owner === discoveryOwner) fs.rmSync(discoveryLockPath, { force: true });
          } catch { try { fs.rmSync(discoveryLockPath, { force: true }); } catch {} }
        };
      } catch { return undefined; }
    };
    let release = tryAcquire();
    if (release) return release;
    try {
      const current = JSON.parse(fs.readFileSync(discoveryLockPath, 'utf8'));
      if (Date.now() - Number(current?.at || 0) > 3 * 60_000) {
        fs.rmSync(discoveryLockPath, { force: true });
        release = tryAcquire();
      }
    } catch {}
    return release;
  };
  const secureWrite = (file: string, value: unknown) => {
    const temp = file + '.tmp';
    fs.writeFileSync(temp, JSON.stringify(value), { mode: 0o600 });
    fs.chmodSync(temp, 0o600);
    fs.renameSync(temp, file);
  };
  const read = (file: string, fallback: any) => {
    try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
  };
  let controlToken: string;
  if (fs.existsSync(tokenPath)) controlToken = fs.readFileSync(tokenPath, 'utf8').trim();
  else {
    controlToken = randomBytes(24).toString('hex');
    fs.writeFileSync(tokenPath, controlToken, { mode: 0o600 });
  }
  let saved = read(configPath, {});
  let delivered: Record<string, { id: number; at: number }> = read(sentPath, {});
  type DeliverySafety = { sentAt: number[]; content: Record<string, { at: number; id: number }> };
  let deliverySafety: Record<string, DeliverySafety> = read(safetyPath, {});
  const incoming: Record<string, { source: string; text: string; at: number }> = read(incomingPath, {});
  let client: TelegramClient | undefined;
  let chats: Chat[] = [];
  let peers = new Map<string, any>();
  let phase = 'offline';
  let runtimeSessionId = '';
  let runtimeSessionStartedAt = 0;
  const publishRuntimeState = (online: boolean) => deps.runtimeState?.({ online, sessionId: runtimeSessionId, startedAt: runtimeSessionStartedAt });
  let account = '';
  let accountId = '';
  let error = '';
  let lastSync = 0;
  let authRunning = false;
  let syncing = false;
  let working = false;
  let retryAt = 0;
  // V14.19: proactive per-account pacing for every actual Telegram message RPC.
  // This is deterministic load control, not human-like/random anti-spam evasion.
  let lastDeliveryAttemptAt = 0;
  // Contact discovery has its own Telegram rate limit. It must never pause
  // VIP/profile deliveries, pending broadcasts, schedules, or incoming handling.
  let contactsRetryAt = 0;
  let warning = '';
  let connectionWarning = '';
  let deliveryWarning = '';
  // Conservative account-wide delivery stop. Only an explicit Telegram RPC
  // account restriction triggers this; target-specific permission failures stay isolated.
  // Persist it with the saved Telegram account so a PM2/app restart cannot silently
  // resume delivery while Telegram still considers that account restricted.
  let accountDeliveryBlockCode = saved.deliveryBlock?.accountId === saved.accountId ? String(saved.deliveryBlock?.code || '') : '';
  let accountDeliveryBlocked = !!accountDeliveryBlockCode;
  let runtimeDisconnectedAt = 0;
  let runtimeRecoveryRunning = false;
  const targetFailures = new Map<string, { until: number; reason: string }>();
  const transientSendFailures = new Map<string, number>();
  let generation = 0;
  let restoreRetryTimer: ReturnType<typeof setTimeout> | undefined;
  let restoreRetryAttempt = 0;
  let restoreRetryAt = 0;
  let challenge: { resolve: (value: string) => void; reject: (reason: Error) => void; timer: ReturnType<typeof setTimeout> } | undefined;
  const logs: { time: string; message: string }[] = [];
  const log = (message: string) => {
    logs.unshift({ time: new Date().toISOString(), message });
    logs.splice(50);
  };
  const errorText = (err: any) => String(err?.errorMessage || err?.message || 'Telegram request failed').slice(0, 200);
  const floodWaitSeconds = (err: any) => {
    const explicit = Number(err?.seconds || 0);
    if (explicit > 0) return explicit;
    const match = errorText(err).match(/FLOOD(?:_PREMIUM)?_WAIT_?(\d+)/i);
    return match ? Number(match[1]) : 0;
  };
  const slowModeWaitSeconds = (err: any) => {
    const match = errorText(err).match(/SLOWMODE_WAIT_?(\d+)/i);
    return match ? Number(match[1]) : 0;
  };
  const disconnectedFailure = (err: any) => /(?:cannot send requests while disconnected|could not reconnect to dc|connection (?:closed|failed|reset)|not connected|socket (?:closed|hang up))/i.test(errorText(err));
  const accountRestrictionCode = (err: any) => {
    const value = errorText(err).toUpperCase();
    // USER_RESTRICTED is Telegram's explicit account-level RPC restriction.
    // Do not infer an account restriction from generic/target permission errors.
    return value.includes('USER_RESTRICTED') ? 'USER_RESTRICTED' : '';
  };
  const targetFailureCode = (err: any) => {
    const value = errorText(err).toUpperCase();
    if (value.includes('DESTINATION NOT IN SYNCED TELEGRAM CHATS')) return 'DESTINATION_NOT_SYNCED';
    if (value.includes('TARGET_RATE_GUARD')) return 'TARGET_RATE_GUARD';
    if (value.includes('TARGET_HOURLY_GUARD')) return 'TARGET_HOURLY_GUARD';
    if (/SLOWMODE_WAIT_?\d+/.test(value)) return 'SLOWMODE_WAIT';
    const match = value.match(/(?:USER_BANNED_IN_CHANNEL|CHAT_WRITE_FORBIDDEN|CHAT_RESTRICTED|CHAT_SEND_PLAIN_FORBIDDEN|CHAT_GUEST_SEND_FORBIDDEN|CHANNEL_PRIVATE|CHANNEL_INVALID|PEER_ID_INVALID|USER_IS_BLOCKED|YOU_BLOCKED_USER|INPUT_USER_DEACTIVATED|CHAT_ADMIN_REQUIRED|USER_NOT_PARTICIPANT|TOPIC_CLOSED|TOPIC_DELETED)/);
    return match?.[0] || '';
  };
  const failure = (err: any) => {
    // Never log request objects, phone codes, passwords or session strings.
    const message = errorText(err);
    const seconds = floodWaitSeconds(err);
    if (seconds > 0) retryAt = Math.max(retryAt, Date.now() + seconds * 1000);
    const restriction = accountRestrictionCode(err);
    if (restriction) {
      accountDeliveryBlockCode = restriction;
      accountDeliveryBlocked = true;
      // Keep the authenticated session for status/appeal, but do not let new
      // real-time business work bind to a delivery-blocked Telegram runtime.
      publishRuntimeState(false);
      // A delivery restriction is account/session state, not an ephemeral worker flag.
      // Only persist once the authenticated account id is known; delivery errors occur
      // after authorization, so this avoids ever binding a restriction to the wrong account.
      if (accountId) {
        saved = { ...saved, deliveryBlock: { accountId, code: restriction, at: Date.now() } };
        secureWrite(configPath, saved);
      }
      refreshDeliveryWarning();
    }
    // A transport drop is not an authentication failure. Keep it out of the red
    // global error field so the runtime watchdog can recover the saved session.
    if (disconnectedFailure(err) && phase === 'online' && client?.connected !== true) {
      error = '';
      connectionWarning = 'Telegram connection interrupted. Automatic reconnect is in progress.';
      if (!runtimeDisconnectedAt) runtimeDisconnectedAt = Date.now();
      log(message);
      return;
    }
    error = message;
    log(message);
  };
  const restoreInitialDelayMs = Math.max(0, deps.restoreInitialDelayMs ?? 1500);
  const restoreRetryBaseMs = Math.max(1000, deps.restoreRetryBaseMs ?? 15000);
  const restoreRetryMaxMs = Math.max(restoreRetryBaseMs, deps.restoreRetryMaxMs ?? 300000);
  const connectionWatchIntervalMs = Math.max(1000, deps.connectionWatchIntervalMs ?? 5000);
  const runtimeDisconnectGraceMs = Math.max(connectionWatchIntervalMs, deps.runtimeDisconnectGraceMs ?? 30000);
  const targetFailureBackoffMs = Math.max(60000, deps.targetFailureBackoffMs ?? 30 * 60_000);
  // Production default: at most one actual outbound Telegram message attempt every 5s
  // for this account. FLOOD_WAIT and account restrictions remain higher-priority stops.
  const deliveryMinIntervalMs = Math.max(0, deps.deliveryMinIntervalMs ?? 5000);
  const waitForDeliverySlot = async () => {
    const remaining = Math.max(0, (lastDeliveryAttemptAt + deliveryMinIntervalMs) - Date.now());
    if (remaining > 0) await new Promise<void>(resolve => setTimeout(resolve, remaining));
    lastDeliveryAttemptAt = Date.now();
  };
  // V14.20: destination-level safety guards. Telegram does not publish a
  // guaranteed-safe posting rate for user accounts, so these caps are intentionally
  // conservative and deterministic. They prevent accidental repetitive automation
  // without trying to imitate human timing or bypass Telegram moderation.
  const targetMinIntervalMs = Math.max(0, deps.targetMinIntervalMs ?? 2 * 60_000);
  const targetMaxPerHour = Math.max(1, deps.targetMaxPerHour ?? 12);
  const contentReplayWindowMs = Math.max(0, deps.contentReplayWindowMs ?? 2 * 60 * 60_000);
  const safetyRecord = (target: string) => {
    const key = `${accountId}|${target}`;
    const existing = deliverySafety[key];
    const record: DeliverySafety = existing && Array.isArray(existing.sentAt) && existing.content && typeof existing.content === 'object'
      ? existing
      : { sentAt: [], content: {} };
    const now = Date.now();
    record.sentAt = record.sentAt.filter(at => now - Number(at || 0) < 60 * 60_000);
    for (const [hash, item] of Object.entries(record.content || {})) {
      if (now - Number(item?.at || 0) >= Math.max(contentReplayWindowMs, 60 * 60_000)) delete record.content[hash];
    }
    deliverySafety[key] = record;
    return { key, record };
  };
  const contentFingerprint = (message: string, scope = '') => createHash('sha256')
    .update(`${scope}\n${message.replace(/\*([^*\n]+)\*/g, '$1').replace(/\s+/g, ' ').trim()}`)
    .digest('hex');
  const checkTargetDeliveryPolicy = (target: string, message: string, replayScope = '') => {
    const { record } = safetyRecord(target);
    const now = Date.now();
    const fingerprint = contentFingerprint(message, replayScope);
    const duplicate = record.content[fingerprint];
    if (duplicate && contentReplayWindowMs > 0 && now - duplicate.at < contentReplayWindowMs) {
      log(`Skipped recent duplicate Telegram content for ${target}`);
      return { fingerprint, duplicateId: Number(duplicate.id || 0) };
    }
    // V14.25: group/channel broadcast protection only. Private Telegram chats are
    // point-to-point VIP destinations, so the 2-minute/12-per-hour broadcast caps
    // must not delay a legitimate PASS/FAIL -> next-card flow. Account-wide pacing,
    // FLOOD_WAIT/USER_RESTRICTED handling and exact-content replay protection remain.
    const broadcastTarget = target.startsWith('tg:group:') || target.startsWith('tg:channel:');
    // Group/channel anti-burst protection applies to business jobs too. The
    // server keeps their FIFO/result workflow pending until this safe turn;
    // critical status must never become a rate-limit bypass.
    if (broadcastTarget) {
      const lastAt = record.sentAt.length ? Math.max(...record.sentAt) : 0;
      if (targetMinIntervalMs > 0 && lastAt && now < lastAt + targetMinIntervalMs) {
        const err: any = new Error('TARGET_RATE_GUARD');
        err.deferUntil = lastAt + targetMinIntervalMs;
        deferTarget(target, err);
        throw err;
      }
      if (record.sentAt.length >= targetMaxPerHour) {
        const err: any = new Error('TARGET_HOURLY_GUARD');
        err.deferUntil = Math.min(...record.sentAt) + 60 * 60_000;
        deferTarget(target, err);
        throw err;
      }
    }
    return { fingerprint, duplicateId: undefined as number | undefined };
  };
  const recordTargetDelivery = (target: string, fingerprint: string, id: number) => {
    const { key, record } = safetyRecord(target);
    const now = Date.now();
    record.sentAt.push(now);
    record.content[fingerprint] = { at: now, id };
    deliverySafety[key] = record;
    secureWrite(safetyPath, deliverySafety);
  };
  const refreshDeliveryWarning = () => {
    if (accountDeliveryBlocked && accountDeliveryBlockCode) {
      deliveryWarning = `Telegram delivery paused for this account (${accountDeliveryBlockCode}). Reconnect only after Telegram removes the restriction.`;
      return;
    }
    const now = Date.now();
    for (const [target, item] of targetFailures) if (item.until <= now) targetFailures.delete(target);
    const first = targetFailures.entries().next().value as [string, { until: number; reason: string }] | undefined;
    deliveryWarning = first
      ? `Telegram destination ${first[0]} is temporarily paused (${first[1].reason}). Other Telegram destinations remain active.`
      : '';
  };
  const targetDeferred = (target: string) => {
    const item = targetFailures.get(target);
    if (!item) return false;
    if (item.until <= Date.now()) { targetFailures.delete(target); refreshDeliveryWarning(); return false; }
    return true;
  };
  const retryableLiveReason = (reason: string) => ['TARGET_RATE_GUARD', 'TARGET_HOURLY_GUARD', 'SLOWMODE_WAIT', 'TEMPORARY_SEND_FAILURE'].includes(String(reason || ''));
  const deferTransientTarget = (target: string, deliveryKey: string) => {
    const attempts = (transientSendFailures.get(deliveryKey) || 0) + 1;
    transientSendFailures.set(deliveryKey, attempts);
    if (attempts < 3) return false;
    transientSendFailures.delete(deliveryKey);
    targetFailures.set(target, { until: Date.now() + targetFailureBackoffMs, reason: 'TEMPORARY_SEND_FAILURE' });
    refreshDeliveryWarning();
    log(`Telegram destination paused after ${attempts} temporary send failures: ${target}`);
    return true;
  };
  const deferTarget = (target: string, err: any) => {
    const reason = targetFailureCode(err);
    if (!reason) return false;
    const previous = targetFailures.get(target);
    const slowModeSeconds = slowModeWaitSeconds(err);
    const requestedUntil = Math.max(Number(err?.deferUntil || 0), slowModeSeconds > 0 ? Date.now() + slowModeSeconds * 1000 : 0);
    const until = requestedUntil > Date.now() ? requestedUntil : Date.now() + targetFailureBackoffMs;
    targetFailures.set(target, { until, reason });
    refreshDeliveryWarning();
    if (!previous || previous.reason !== reason || previous.until <= Date.now()) {
      log(`Telegram destination paused for ${Math.max(1, Math.ceil((until - Date.now()) / 60000))}m: ${target} (${reason})`);
    }
    return true;
  };
  const hasRestorableSession = () => !!(saved.session && saved.apiId && saved.apiHash);
  const clearRestoreRetry = (resetAttempts = false) => {
    if (restoreRetryTimer) clearTimeout(restoreRetryTimer);
    restoreRetryTimer = undefined;
    restoreRetryAt = 0;
    if (resetAttempts) restoreRetryAttempt = 0;
  };
  const terminalRestoreFailure = (err: any) => /(?:session expired|login was not completed|different telegram account|auth_key_(?:unregistered|invalid|duplicated)|session_(?:revoked|expired)|user_deactivated|api_id_invalid)/i.test(errorText(err));
  const scheduleRestoreRetry = (initial = false) => {
    if (!hasRestorableSession() || phase === 'online' || restoreRetryTimer) return;
    const exponential = restoreRetryBaseMs * (2 ** Math.max(0, restoreRetryAttempt - 1));
    const backoff = initial ? restoreInitialDelayMs : Math.min(restoreRetryMaxMs, exponential);
    const floodDelay = Math.max(0, retryAt - Date.now());
    const delay = Math.max(backoff, floodDelay);
    restoreRetryAt = Date.now() + delay;
    if (!initial) log(`Telegram saved-session restore retry scheduled in ${Math.ceil(delay / 1000)}s (attempt ${restoreRetryAttempt + 1})`);
    restoreRetryTimer = setTimeout(() => {
      restoreRetryTimer = undefined;
      restoreRetryAt = 0;
      if (!hasRestorableSession() || phase === 'online') return;
      // A manual login/logout or delivery operation always wins. Never overlap it.
      if (authRunning || working || syncing) { scheduleRestoreRetry(false); return; }
      void connect(Number(saved.apiId), String(saved.apiHash), String(saved.phone), true);
    }, delay);
    restoreRetryTimer.unref();
  };
  const local = async (route: string, body?: unknown) => {
    const response = await fetch(`http://127.0.0.1:${deps.port}${route}`, {
      method: body === undefined ? 'GET' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      signal: AbortSignal.timeout(15000),
    });
    const result = await response.json();
    if (!response.ok || result.status === 'error') throw new Error(result.message || `HTTP ${response.status}`);
    return result;
  };
  const sync = async () => {
    if (!client || phase !== 'online' || client.connected !== true) throw new Error('Telegram is reconnecting. Retry after connection is restored.');
    if (syncing) return;
    syncing = true;
    let releaseDiscovery: (() => void) | undefined;
    try {
      releaseDiscovery = acquireDiscoveryLock();
      if (!releaseDiscovery) {
        warning = 'Telegram chat discovery deferred while WhatsApp sync is running. Delivery remains active.';
        log('Telegram chat discovery deferred: WhatsApp/other gateway sync in progress');
        return;
      }
      const next: Chat[] = [];
      const nextPeers = new Map<string, any>();
      // No page/100-dialog cap. Iterate both normal and archived dialogs.
      for (const folder of [0, 1]) {
        for await (const dialog of client.iterDialogs({ folder })) {
          if (!dialog.entity || !dialog.inputEntity) continue;
          const kind = dialog.isGroup ? 'group' : dialog.isChannel ? 'channel' : 'user';
          const jid = `tg:${kind}:${utils.getPeerId(dialog.entity)}`;
          if (!isTelegramTarget(jid) || nextPeers.has(jid)) continue;
          next.push({ jid, name: dialog.name || jid, kind });
          nextPeers.set(jid, dialog.inputEntity);
        }
      }
      const preserveKnownContacts = () => {
        for (const old of chats) {
          if (old.kind !== 'user' || nextPeers.has(old.jid)) continue;
          const oldPeer = peers.get(old.jid);
          if (!oldPeer) continue;
          next.push(old);
          nextPeers.set(old.jid, oldPeer);
        }
      };
      warning = '';
      if (Date.now() < contactsRetryAt) {
        preserveKnownContacts();
        const remaining = Math.max(1, Math.ceil((contactsRetryAt - Date.now()) / 1000));
        warning = `Groups/channels synced. Contacts cooling down for ${remaining}s; Telegram delivery remains active.`;
      } else {
        try {
          const contacts: any = await client.invoke(new Api.contacts.GetContacts({ hash: bigInt(0) }));
          contactsRetryAt = 0;
          for (const user of contacts.users || []) {
            const jid = `tg:user:${utils.getPeerId(user)}`;
            if (!isTelegramTarget(jid) || nextPeers.has(jid) || user.deleted) continue;
            next.push({ jid, name: `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.username || jid, kind: 'user' });
            nextPeers.set(jid, utils.getInputPeer(user));
          }
        } catch (err) {
          preserveKnownContacts();
          const contactError = errorText(err);
          const seconds = floodWaitSeconds(err);
          if (seconds > 0) contactsRetryAt = Date.now() + seconds * 1000;
          warning = `Groups/channels synced; contacts: ${contactError}. Telegram delivery remains active.`;
          log(`Contacts sync deferred: ${contactError}; delivery remains active`);
        }
      }
      chats = next;
      peers = nextPeers;
      // A destination can temporarily disappear from the dialog cache (for example
      // after a membership/permission change). If a later sync discovers it again,
      // release only the temporary not-synced pause immediately. Permanent Telegram
      // permission failures keep their own backoff.
      let restoredSyncedTarget = false;
      for (const [target, item] of targetFailures) {
        if (item.reason === 'DESTINATION_NOT_SYNCED' && nextPeers.has(target)) {
          targetFailures.delete(target);
          restoredSyncedTarget = true;
        }
      }
      if (restoredSyncedTarget) refreshDeliveryWarning();
      lastSync = Date.now();
      // A contact-discovery warning is non-fatal and must not poison the global
      // delivery error/retry state.
      error = '';
      log(`Synced ${chats.filter(c => c.kind === 'group').length} groups, ${chats.filter(c => c.kind === 'channel').length} channels, ${chats.filter(c => c.kind === 'user').length} chats`);
    } finally {
      try { releaseDiscovery?.(); } catch {}
      syncing = false;
    }
  };
  const answer = (kind: string) => new Promise<string>((resolve, reject) => {
    phase = kind;
    const timer = setTimeout(() => {
      challenge = undefined;
      reject(new Error('Login expired. Start login again.'));
    }, 180000);
    challenge = { resolve, reject, timer };
  });
  async function connect(apiId: number, apiHash: string, phone: string, restoring = false) {
    if (authRunning || working || syncing) throw new Error('Telegram is busy. Retry shortly.');
    if (!restoring) clearRestoreRetry(true);
    authRunning = true;
    phase = 'connecting';
    error = '';
    const thisGeneration = ++generation;
    try {
      if (client) await client.destroy();
      chats = []; peers.clear(); lastSync = 0;
      const session = new StringSession(restoring ? saved.session || '' : '');
      client = deps.clientFactory ? deps.clientFactory(session, apiId, apiHash) : new TelegramClient(session, apiId, apiHash, {
        connectionRetries: 5, requestRetries: 2, floodSleepThreshold: 0,
      });
      client.setLogLevel('none' as any);
      await client.start({
        phoneNumber: async () => phone,
        phoneCode: () => restoring ? Promise.reject(new Error('Session expired. Login again.')) : answer('code'),
        password: () => restoring ? Promise.reject(new Error('Session expired. Login again.')) : answer('password'),
        emailAddress: () => answer('email'),
        emailVerification: async () => ({ type: 'code' as const, code: await answer('email-code') }),
        onError: async (err: Error) => { failure(err); return true; },
      });
      if (thisGeneration !== generation || !(await client.checkAuthorization())) throw new Error('Login was not completed');
      const me: any = await client.getMe();
      accountId = String(me.id);
      account = me.username ? `@${me.username}` : `${me.firstName || ''} ${me.lastName || ''}`.trim();
      // Never accept an unexpected account mismatch. A deliberate manual logout,
      // however, explicitly authorizes exactly the next manual login to switch accounts.
      // Target JIDs remain safe: sends still require the new account's freshly-synced peer.
      const accountSwitchAuthorized = !restoring && saved.allowAccountSwitch === true;
      if (saved.accountId && saved.accountId !== accountId && !accountSwitchAuthorized && !deps.canSwitchAccount?.()) {
        phase = 'offline';
        await client.invoke(new Api.auth.LogOut());
        await client.destroy();
        throw new Error('Different Telegram account. Logout first before switching accounts.');
      }
      const persistedDeliveryBlock = restoring && saved.deliveryBlock?.accountId === accountId
        ? saved.deliveryBlock
        : undefined;
      saved = {
        apiId, apiHash, phone, accountId, session: client.session.save(),
        ...(persistedDeliveryBlock ? { deliveryBlock: persistedDeliveryBlock } : {}),
      };
      accountDeliveryBlockCode = persistedDeliveryBlock ? String(persistedDeliveryBlock.code || '') : '';
      accountDeliveryBlocked = !!accountDeliveryBlockCode;
      refreshDeliveryWarning();
      secureWrite(configPath, saved);
      phase = 'online';
      runtimeSessionStartedAt = Date.now();
      runtimeSessionId = `tg:${accountId}:${thisGeneration}:${runtimeSessionStartedAt}`;
      publishRuntimeState(true);
      runtimeDisconnectedAt = 0;
      connectionWarning = '';
      clearRestoreRetry(true);
      if (restoring) log('Saved Telegram session restored successfully');
      client.addEventHandler(async (event: any) => {
        try {
          if (phase !== 'online' || !deps.monitoring() || event.message?.out) return;
          const rawPeer = String(event.chatId || '');
          const source = deps.sources().find(jid => isTelegramTarget(jid) && jid.split(':')[2] === rawPeer);
          const text = String(event.message?.message || '').trim();
          if (!source || !telegramResultSignal(text)) return;
          incoming[`${accountId}|${source}|${event.message.id}`] = { source, text, at: Date.now() };
          secureWrite(incomingPath, incoming);
        } catch (err) { failure(err); }
      }, new NewMessage({ incoming: true }));
      await sync().catch(failure);
    } catch (err) {
      failure(err);
      phase = 'offline';
      publishRuntimeState(false);
      if (client) await client.destroy().catch(() => undefined);
      if (restoring) {
        if (terminalRestoreFailure(err)) {
          clearRestoreRetry(false);
          log('Saved Telegram session is no longer reusable. Automatic restore stopped; login again from Telegram Gateway.');
        } else {
          restoreRetryAttempt += 1;
          scheduleRestoreRetry(false);
        }
      }
    } finally {
      if (challenge) clearTimeout(challenge.timer);
      challenge = undefined;
      authRunning = false;
    }
  }

  const send = async (target: string, message: string, key: string, quoteKey?: string, businessCritical = false, card?:any) => {
    if (!client || phase !== 'online' || client.connected !== true) throw new Error('Telegram disconnected');
    if (!isTelegramTarget(target)) throw new Error('Invalid Telegram target');
    const deliveryKey = `${accountId}|${key}|${target}`;
    if (delivered[deliveryKey]) return delivered[deliveryKey].id;
    const peer = peers.get(target);
    if (!peer) {
      const missingPeerError = new Error('Destination not in synced Telegram chats. Refresh Telegram list.');
      deferTarget(target, missingPeerError);
      throw missingPeerError;
    }
    // Quote-linked result follow-ups get an event-specific replay scope so a
    // legitimate later result with the same wording is not mistaken for a promo replay.
    // Business events use their stable job key as replay scope. Two VIPs sharing
    // one destination must never suppress each other's otherwise-identical card.
    const replayScope = businessCritical ? `business:${key}` : (quoteKey ? `reply:${quoteKey}` : card?.broadcastKind==='vip-live-push'&&card?.senderFormat==='png'?`image:${createHash('sha256').update(card.broadcastPng+'\n'+normalizeBroadcastLink(card.broadcastLink)).digest('hex')}`:'');
    const policy = checkTargetDeliveryPolicy(target, message, replayScope);
    if (policy.duplicateId !== undefined) return policy.duplicateId;
    const replyId = quoteKey ? delivered[`${accountId}|${quoteKey}|${target}`]?.id : undefined;
    // Stable per-account/job/target random_id lets Telegram deduplicate a retry
    // even if the process died after Telegram accepted the message.
    const randomId = bigInt(createHash('sha256').update(deliveryKey).digest('hex').slice(0, 15), 16);
    let text = '';
    const entities: Api.MessageEntityBold[] = [];
    let end = 0;
    for (const match of message.matchAll(/\*([^*\n]+)\*/g)) {
      text += message.slice(end, match.index);
      entities.push(new Api.MessageEntityBold({ offset: text.length, length: match[1].length }));
      text += match[1];
      end = match.index! + match[0].length;
    }
    text += message.slice(end);
    let request:Api.messages.SendMessage|Api.messages.SendMedia = new Api.messages.SendMessage({
      peer, message: text, randomId, entities, noWebpage: true,
      ...(replyId ? { replyTo: new Api.InputReplyToMessage({ replyToMsgId: replyId }) } : {}),
    });
    let result: any;
    // Pace only real Telegram RPC attempts. Ledger hits, deferred targets and missing
    // peers return before this point and therefore do not consume a delivery slot.
    try {
      if(card?.senderFormat==='png'){
        const png=card.broadcastKind==='vip-live-push'?decodeBroadcastPng(card.broadcastPng):await renderScheduledCardPngAsync(scheduledCardImage(card));
        const file=await client.uploadFile({file:new CustomFile('Titan-card.png',png.length,'',png),workers:1});
        const caption=card.broadcastKind==='vip-live-push'?normalizeBroadcastLink(card.broadcastLink):'';
        request=new Api.messages.SendMedia({peer,randomId,message:caption,...(caption?{entities:[new Api.MessageEntityUrl({offset:0,length:caption.length})]}:{}),media:new Api.InputMediaUploadedPhoto({file})});
      } else if (card?.senderFormat === 'gif_video' && card?.broadcastVideo) {
        const videoBuf = Buffer.from(String(card.broadcastVideo), 'base64');
        const file = await client.uploadFile({ file: new CustomFile('Titan-Replay.mp4', videoBuf.length, '', videoBuf), workers: 1 });
        request = new Api.messages.SendMedia({
          peer,
          randomId,
          message: text,
          entities,
          media: new Api.InputMediaUploadedDocument({
            file,
            mimeType: 'video/mp4',
            attributes: [
              new Api.DocumentAttributeVideo({ duration: 10, w: 720, h: 1280, supportsStreaming: true, nosound: true }),
              new Api.DocumentAttributeAnimated(),
            ],
          }),
        });
      }
    }catch(err){deferTarget(target,err);throw err;}
    await waitForDeliverySlot();
    try {
      // Pacing/upload can outlive the original card readiness check.
      if(!deps.autoSend()||!client?.connected||phase!=='online')throw new Error('CARD_DELIVERY_PAUSED');
      if(card&&card.broadcastKind!=='vip-live-push'){
        const route=['vip-auto-card','vip-card-copy'].includes(card.broadcastKind)
          ? `/api/bot/schedule_policy?profileId=${encodeURIComponent(card.profileId)}&cardType=${encodeURIComponent(card.cardType||'')}&broadcastId=${encodeURIComponent(card.id)}`
          : `/api/bot/schedule_guard?key=${encodeURIComponent(card.key)}&digits=${encodeURIComponent(card.digits||'')}&rate=${encodeURIComponent(card.rateNum??card.invest??0)}&cardGeneration=${encodeURIComponent(card.cardGeneration||0)}`;
        if(!(await local(route)).allowed)throw new Error('CARD_DELIVERY_CANCELLED');
      }
      result = await client.invoke(request);
    }
    catch (err: any) {
      // A changed business decision is not a failed network attempt or target restriction.
      if(['CARD_DELIVERY_CANCELLED','CARD_DELIVERY_PAUSED'].includes(err?.message))throw err;
      if (err?.errorMessage === 'RANDOM_ID_DUPLICATE') {
        // Telegram already accepted this exact account/job/destination request.
        // Keep an unknown message id rather than resending under a new random id.
        result = { id: 0 };
      } else {
        // Telegram-provided cooldowns, transport recovery and explicit account
        // restrictions are handled globally. Unknown request failures get only
        // three attempts before this destination is cooled down, preventing a
        // 5-second retry storm while leaving other destinations available.
        if (!floodWaitSeconds(err) && !slowModeWaitSeconds(err) && !disconnectedFailure(err) && !accountRestrictionCode(err)) {
          deferTransientTarget(target, deliveryKey);
        }
        deferTarget(target, err);
        throw err;
      }
    }
    const id = Number(result.id || result.updates?.find((u: any) => u.className === 'UpdateMessageID')?.id || result.updates?.find((u: any) => u.message?.id)?.message?.id || 0);
    transientSendFailures.delete(deliveryKey);
    delivered[deliveryKey] = { id, at: Date.now() };
    secureWrite(sentPath, delivered);
    recordTargetDelivery(target, policy.fingerprint, id);
    if (targetFailures.delete(target)) refreshDeliveryWarning();
    log(`Sent to ${target}`);
    return id;
  };

  const tick = async () => {
    if (working || authRunning || phase !== 'online' || !client?.connected || accountDeliveryBlocked || Date.now() < retryAt) return;
    working = true;
    try {
      for (const [id, item] of Object.entries(incoming)) {
        if (Date.now() - item.at > 20 * 60 * 1000 || !deps.sources().includes(item.source)) {
          delete incoming[id]; secureWrite(incomingPath, incoming); continue;
        }
        if (!deps.monitoring()) continue;
        await local('/api/bot/auto_audit_result', { resultText: item.text, sourcePlatform: 'telegram', sourceJid: item.source });
        await local('/api/bot/forward_result', { resultText: item.text, sourceJid: item.source });
        delete incoming[id]; secureWrite(incomingPath, incoming);
        log(`Incoming result queued: ${item.source}`);
      }
      const processScheduledCards = async () => {
        if (accountDeliveryBlocked || !deps.autoSend() || Date.now() < retryAt) return;
        const schedules = await local('/api/bot/schedule?platform=telegram');
        for (const item of schedules.schedules || []) {
          if (!item.shouldSend || !item.message || !item.schTargets?.length) continue;
          try {
            const scheduleGuardUrl = `/api/bot/schedule_guard?key=${encodeURIComponent(item.key)}&digits=${encodeURIComponent(item.digits || '')}&rate=${encodeURIComponent(item.rateNum ?? item.invest ?? 0)}&cardGeneration=${encodeURIComponent(item.cardGeneration || 0)}`;
            const guard = await local(scheduleGuardUrl);
            if (!guard.allowed) continue;
            let deferredTarget = false;
            for (const target of item.schTargets) {
              const latestGuard = await local(scheduleGuardUrl);
              if (!latestGuard.allowed) { deferredTarget = true; break; }
              if (targetDeferred(target)) { deferredTarget = true; continue; }
              try { await send(target, item.message, item.key, undefined, true, item); }
              catch (err) {
                if (targetFailureCode(err)) { deferredTarget = true; continue; }
                throw err;
              }
            }
            if (deferredTarget) continue;
            await local('/api/bot/mark_sent', {
              ...item, scheduleKey: item.key, platform: 'telegram', type: item.type,
              rateNum: Number(item.rateNum || item.invest || 0), details: 'Telegram schedule delivered',
            });
          } catch (err) { failure(err); if (accountDeliveryBlocked || Date.now() < retryAt) break; }
        }
      };
      const backgroundDeadline = Date.now() + 5000;
      const pending = await local(`/api/bot/pending_broadcasts?claimVersion=2&platform=telegram&sessionStartedAt=${runtimeSessionStartedAt}&sessionId=${encodeURIComponent(runtimeSessionId)}`);
      for (const job of pending.broadcasts || []) {
        const businessJob = ['vip-auto-card', 'result-followup'].includes(String(job.broadcastKind || ''));
        if (!businessJob && Date.now() >= backgroundDeadline) break;
        const deliveredTargets: string[] = [];
        try {
          if (job.profileId && (job.cardType || job.broadcastKind === 'profit-milestone')) {
            const guard = await local(`/api/bot/schedule_policy?profileId=${encodeURIComponent(job.profileId)}&cardType=${encodeURIComponent(job.cardType || '')}&broadcastId=${encodeURIComponent(job.id)}`);
            if (guard.allowed === false || guard.enabled === false) {
              await local('/api/bot/ack_broadcast', { id: job.id, claimToken: job.claimToken, status: 'failed', platform: 'telegram', targets: deliveredTargets, details: `Telegram broadcast policy disabled: ${job.id}` });
              continue;
            }
          }
          let retryUntil = 0;
          let deferredTarget = false;
          let vipGameStopped = false;
          for (const target of job.targets || []) {
            if (!businessJob) {
              await processScheduledCards();
              if (Date.now() >= backgroundDeadline) { retryUntil = Date.now() + (deps.pollIntervalMs || 5000); break; }
            }
            if (targetDeferred(target)) {
              const existingDefer = targetFailures.get(target);
              if (retryableLiveReason(String(existingDefer?.reason || ''))) retryUntil = Math.max(retryUntil, Number(existingDefer?.until || 0));
              else deferredTarget = true;
              continue;
            }
            try {
              if (['vip-auto-card','vip-card-copy','profit-milestone'].includes(job.broadcastKind)) {
                const latest = await local(`/api/bot/schedule_policy?profileId=${encodeURIComponent(job.profileId)}&cardType=${encodeURIComponent(job.cardType || '')}&broadcastId=${encodeURIComponent(job.id)}`);
                if (!latest.allowed) { vipGameStopped = true; break; }
              }
              const critical = ['vip-auto-card', 'result-followup', 'profit-milestone'].includes(String(job.broadcastKind || ''));
              await send(
                target,
                job.message,
                job.broadcastKind === 'vip-auto-card' ? job.scheduleKey : job.id,
                job.broadcastKind === 'result-followup' ? job.scheduleKey : undefined,
                critical,
                (['vip-auto-card','vip-card-copy'].includes(job.broadcastKind)||job.broadcastKind==='vip-live-push'&&job.senderFormat==='png')?job:undefined,
              );
              deliveredTargets.push(target);
            } catch (err) {
              const code = targetFailureCode(err);
              if (code) {
                const state = targetFailures.get(target);
                if (retryableLiveReason(code)) retryUntil = Math.max(retryUntil, Number(state?.until || (Date.now() + 15_000)));
                else deferredTarget = true;
                continue;
              }
              throw err;
            }
          }
          if (vipGameStopped) {
            await local('/api/bot/ack_broadcast', { id: job.id, claimToken: job.claimToken, status: 'failed', platform: 'telegram', targets: deliveredTargets,
              attemptedTargets: job.targets, details: `VIP game stopped before remaining targets: ${job.id}` });
            continue;
          }
          if (deferredTarget) {
            const failedAck = {
              id: job.id, claimToken: job.claimToken, status: 'failed', platform: 'telegram', targets: deliveredTargets, attemptedTargets: job.targets,
              details: `Telegram live broadcast closed with permanently unavailable target(s): ${job.id}`,
            };
            await local('/api/bot/ack_broadcast', failedAck);
            continue;
          }
          if (retryUntil > 0) {
            await local('/api/bot/ack_broadcast', {
              id: job.id, claimToken: job.claimToken, status: 'deferred', platform: 'telegram', targets: deliveredTargets, retryAt: retryUntil,
              details: `Telegram live broadcast deferred by safe destination pacing: ${job.id}`,
            });
            continue;
          }
          await local('/api/bot/ack_broadcast', { id: job.id, claimToken: job.claimToken, status: 'sent', platform: 'telegram', targets: deliveredTargets });
        } catch (err) {
          failure(err);
          await local('/api/bot/ack_broadcast', {
            id: job.id, claimToken: job.claimToken, status: 'deferred', platform: 'telegram', targets: deliveredTargets,
            retryAt: Math.max(retryAt, Date.now() + 15_000),
            details: `Telegram live broadcast temporarily deferred: ${String((err as any)?.message || err || 'unknown error')}`.slice(0, 500),
          }).catch(() => undefined);
          if (accountDeliveryBlocked || Date.now() < retryAt) break;
        }
      }
      await processScheduledCards();
    } catch (err) { failure(err); }
    finally { working = false; }
  };

  const recoverRuntimeDisconnect = async () => {
    if (runtimeRecoveryRunning || authRunning || working || syncing || phase !== 'online' || !client || client.connected === true) return;
    if (!runtimeDisconnectedAt) {
      runtimeDisconnectedAt = Date.now();
      connectionWarning = 'Telegram connection interrupted. Automatic reconnect is in progress.';
      log('Telegram transport disconnected; waiting for built-in reconnect');
      return;
    }
    if (Date.now() - runtimeDisconnectedAt < runtimeDisconnectGraceMs) return;
    runtimeRecoveryRunning = true;
    try {
      if (phase !== 'online' || !client) return;
      connectionWarning = 'Telegram transport did not recover. Restarting the saved Telegram session.';
      log('Telegram transport reconnect timed out; restarting saved session');
      phase = 'offline';
      publishRuntimeState(false);
      generation++;
      const staleClient = client;
      client = undefined;
      await staleClient.destroy().catch(() => undefined);
      restoreRetryAttempt += 1;
      scheduleRestoreRetry(false);
    } finally {
      runtimeDisconnectedAt = 0;
      runtimeRecoveryRunning = false;
    }
  };

  app.use('/api/telegram', (req, res, next) => {
    const supplied = String(req.headers['x-titan-telegram-key'] || '');
    if (Buffer.byteLength(supplied) !== Buffer.byteLength(controlToken) || !timingSafeEqual(Buffer.from(supplied), Buffer.from(controlToken))) {
      return res.status(401).json({ status: 'error', message: 'Enter the Telegram control key from your server.' });
    }
    res.setHeader('Cache-Control', 'no-store');
    next();
  });
  app.get('/api/telegram/status', (_req, res) => {
    refreshDeliveryWarning();
    const connected = phase === 'online' && client?.connected === true;
    const effectivePhase = connected ? 'online' : ((phase === 'online' || restoreRetryTimer || runtimeRecoveryRunning) && hasRestorableSession() ? 'reconnecting' : phase);
    const warnings = [connectionWarning, warning, deliveryWarning].filter(Boolean).join(' ');
    res.json({ status: 'success', phase: effectivePhase, connected, account, error, warning: warnings, lastSync, syncing, contactsRetryAt, restoreRetryAt, restoreRetryAttempt, restorePending: !!restoreRetryTimer, blockedTargets: targetFailures.size, logs });
  });
  app.post('/api/telegram/selection', (req, res) => {
    const { field, values } = req.body || {};
    if (!['resultReadGroups', 'targetGroups'].includes(field) || !Array.isArray(values) || values.some(v =>
      !isTelegramTarget(v) || !peers.has(v) || (field === 'resultReadGroups' && String(v).startsWith('tg:user:')))) {
      return res.status(400).json({ status: 'error', message: 'Select valid synced Telegram chats.' });
    }
    try { deps.selection(field, [...new Set(values)] as string[]); res.json({ status: 'success' }); }
    catch (err) { failure(err); res.status(500).json({ status: 'error', message: error }); }
  });
  app.get('/api/telegram/chats', (_req, res) => res.json({ status: 'success', chats: {
    groups: chats.filter(c => c.kind === 'group'), channels: chats.filter(c => c.kind === 'channel'), contacts: chats.filter(c => c.kind === 'user'), lastSync,
  } }));
  app.post('/api/telegram/login', (req, res) => {
    const apiId = Number(req.body.apiId), apiHash = String(req.body.apiHash || ''), phone = String(req.body.phone || '');
    if (!Number.isSafeInteger(apiId) || apiId <= 0 || !/^[a-f\d]{32}$/i.test(apiHash) || !/^\+?[1-9]\d{7,14}$/.test(phone)) return res.status(400).json({ status: 'error', message: 'Valid API ID, API hash and international phone number required.' });
    if (authRunning || working || syncing || phase === 'online') return res.status(409).json({ status: 'error', message: 'Already connected or busy. Logout before starting a new login.' });
    void connect(apiId, apiHash, phone);
    res.json({ status: 'success' });
  });
  app.post('/api/telegram/answer', (req, res) => {
    if (!challenge) return res.status(409).json({ status: 'error', message: 'No login challenge pending.' });
    const value = String(req.body.value || '');
    if (!value || value.length > 256) return res.status(400).json({ status: 'error', message: 'Enter the requested login value.' });
    const pending = challenge; challenge = undefined; clearTimeout(pending.timer);
    phase = 'connecting'; pending.resolve(value);
    res.json({ status: 'success' });
  });
  app.post('/api/telegram/sync', async (_req, res) => {
    try { await sync(); res.json({ status: 'success' }); }
    catch (err) { failure(err); res.status(400).json({ status: 'error', message: error }); }
  });
  app.post('/api/telegram/logout', async (_req, res) => {
    if (working || syncing) return res.status(409).json({ status: 'error', message: 'Delivery/sync in progress. Retry shortly.' });
    try {
      clearRestoreRetry(true);
      if (challenge) { clearTimeout(challenge.timer); challenge.reject(new Error('Login cancelled')); challenge = undefined; }
      if (client && phase === 'online') await client.invoke(new Api.auth.LogOut());
      generation++;
      if (client) await client.destroy();
      phase = 'offline'; publishRuntimeState(false); account = ''; chats = []; peers.clear(); lastSync = 0; warning = ''; connectionWarning = ''; deliveryWarning = ''; targetFailures.clear(); transientSendFailures.clear(); accountDeliveryBlocked = false; runtimeDisconnectedAt = 0; accountDeliveryBlockCode = ''; contactsRetryAt = 0; retryAt = 0;
      saved = { accountId: saved.accountId }; saved.allowAccountSwitch = true;
      secureWrite(configPath, saved);
      // Explicit logout authorizes exactly the next manual login to switch accounts.
      // Successful login rewrites `saved`, consuming this one-shot marker automatically.
      res.json({ status: 'success' });
    } catch (err) { failure(err); res.status(400).json({ status: 'error', message: error }); }
  });
  const workerTimer = setInterval(() => void tick(), deps.pollIntervalMs || 5000);
  workerTimer.unref();
  const syncTimer = setInterval(() => { if (phase === 'online' && client?.connected === true && !working && !syncing) void sync().catch(failure); }, 300000);
  syncTimer.unref();
  const connectionWatchTimer = setInterval(() => {
    if (phase === 'online' && client?.connected !== true) void recoverRuntimeDisconnect();
    else if (phase === 'online' && client?.connected === true && runtimeDisconnectedAt) {
      runtimeDisconnectedAt = 0;
      connectionWarning = '';
      log('Telegram transport reconnected');
    }
  }, connectionWatchIntervalMs);
  connectionWatchTimer.unref();
  if (hasRestorableSession()) scheduleRestoreRetry(true);
  return { close: async () => {
    clearInterval(workerTimer); clearInterval(syncTimer); clearRestoreRetry(true);
    clearInterval(connectionWatchTimer);
    if (challenge) { clearTimeout(challenge.timer); challenge.reject(new Error('Gateway stopped')); challenge = undefined; }
    generation++; phase = 'offline'; publishRuntimeState(false); connectionWarning = ''; runtimeDisconnectedAt = 0; targetFailures.clear(); deliveryWarning = '';
    if (client) await client.destroy();
  } };
}
