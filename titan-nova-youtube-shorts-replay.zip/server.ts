import { evaluateServerFourWaveType } from './src/utils/fourWaveRelay';
import {resolveLoopAccountConfig,evaluateLoopAccounts,stopLoopUnsentCards,accountForCard,deliveredLoopCard,loopAccountKey,type LoopAccountStops} from './src/utils/loopAccounts';
import {reconcileResultControlChanges} from './src/utils/resultControlReplay';
import {DeferredJsonCache} from './server-utils/deferredJsonCache';
import {validChartClockTimes} from './server-utils/chartClockTimes';
import { startAppListeners } from './server-utils/appListeners';
import { adminChanges, applyAdminChanges, sameAdminValue } from './src/utils/adminStatePatch';
import {cutOpenActual,sameMarketOpenActual,restoreOpenCloseInput} from './src/utils/openToCloseCut';
import {selectSmartBehavior} from './src/utils/smartBehavior';
import {analyseSourceWindowHistory} from './src/utils/sourceWindowHistory';
import {sourceTrendBreak} from './src/utils/trendMovement';
import {liveVipRecoveryCards,vipQueuePosition,LiveQueueFreshnessClock,noteRegisteredGatewayPoll} from './src/utils/vipQueue';
import {runtimeRecoveryShareLedger,replayTwoCardRecovery,shareTotal,recoveryCardFrozen} from './src/utils/twoCardRecovery';
import {FullStateReader} from './server-utils/fullStateReader';
import {BulkOperationReceipts,type BulkReceipt} from './server-utils/bulkOperationReceipts';
import {clearedLedgerCard} from './src/utils/clearLedgerCard';
import {cardSenderPresentation,cardSenderFormatForDelivery,cardUsesPng} from './src/utils/cardSenderFormat';
import {selectPannaFollow} from './src/utils/pannaFollow';
import {selectDigitFollow} from './src/utils/digitFollow';
import {isFrequencySourceMode, sourceObservationWindow, selectTenDrawSkipRecentFrequency, selectTenDayComboSkipRecentFrequency} from './src/utils/sourceFrequencySmart';
import {selectPairFollow,selectPairCombo} from './src/utils/pairFollow';
import {selectDynamic4AnkFromChart} from './src/utils/masterFlow';
import {discoverChartInductiveRules} from './src/utils/selfLearningEngine';
import {adminSnapshotPreview,isAdminSnapshotProtected,adminSnapshotMarketEnabled} from './src/utils/adminCopySnapshot';
import {pinRecoverySettings} from './src/utils/archiveRecoverySnapshot';
import {applyCarryResultSix,carryResultSixHistory,carryRuntimeProfile,applyCarryResultSixDay,carryResultSixStatus,findLoopFailStreak,collectCarryTenWindowAnalysis} from './src/utils/carryResultSix';
import {cardDigitSupport, computeSourceSsdFromStream, mergeUniqueMssdDigits} from './src/utils/digitSupport';
import {actualForGame as historyTieActualForGame} from './src/utils/backtestResult';
import {registerPwa} from './server-utils/pwa';
import {normalizeBroadcastLink} from './scripts/broadcast-link.mjs';
import {isStaleWhatsAppHeartbeat} from './wa-heartbeat-order.js';
import {decodeBroadcastPng} from './scripts/broadcast-png.mjs';
import {registerManualPayments} from './server-utils/manualPayments';
import {preserveServerPayments} from './src/utils/manualPayments';
import {queuedPlayBlockReason} from './src/utils/queuedPlayReady';
import {renderScheduledCardPngAsync} from './schedule-card-renderer';
import {scheduleWindowAllowed} from './src/utils/scheduleWindow';
import {scheduledCardImage} from './schedule-card-png';
import compression from 'compression';
import { EditorLease } from './server-utils/editorLease';
import { ActivityRecorder } from './server-utils/activityRecorder';
import { renderActivityGifVideo, isFfmpegAvailable } from './server-utils/activityVideoRenderer';
import { serializeWorkspaceSnapshot } from './server-utils/workspaceSnapshot';
import { safeChartFetch, readChartBody, ChartDestinationError } from './server-utils/safeChartFetch';
import {applyResultParity,createCutResolver} from './src/utils/resultParity';
import {observeLiveCombinedSkip} from './src/utils/liveCombinedCut';
import type {DayMarketRecord} from './src/types';
import { vipResumeCutoffReached, vipResumeExpiredKeys } from './src/utils/vipGameResume';
import { vipLiveMarketEligible } from './src/utils/vipLiveStart';
import { RangeBacktestRunner, validateRangeOptions, planRange, preserveRangeArchive, type RangeJob } from './src/utils/rangeBacktest';
import { carryControlMode, carryControlSettings, autoRemovalInput, confirmedAnkResult, removePreviousResult } from './src/utils/autoRemoveResult';
import { resolveChartSource, isChartProviderUrl, CHART_PROVIDER_HOSTS } from './src/utils/chartSource';
import { normalizeProviderChartHtml } from './src/utils/normalizeProviderChartHtml';
import { chartMatchesMarket } from './src/utils/chartIdentity';
import { projectAdminSource } from './src/utils/adminMirror';
import { clearRestoredDelivery } from './src/utils/cardRestore';
import { applySourceSnapshot } from './src/utils/sourceSnapshot';
import { vipStopReason, vipGameTotals, vipBaselineCards, skipVipUnsentCards, clearVipOrphanedReservations, reconcileVipAutoStopCard, type VipGameRuns } from './src/utils/vipAutoStop';
import { buildSourceIndexHistory } from './src/utils/sourceIndexHistory';
import { runtimeCatalogChanged, remapRuntimeCatalog, remapScheduleIdentity } from './src/utils/marketCatalogMigration';
import { runtimeRecoveryTrack, runtimeFinancialRecoveryTrack, runtimeTarget, runtimeLoop, normalizeDualLoops, dayLoopConfig, loopSettingsForDate, isLoopAssignmentFrozen, dayHasCommittedPlays, hasCommittedInactiveLoop, validLoopDate, type DualLoopConfig, type LoopId } from './src/utils/dualLoops';
import {applyCustomLoopSetup,migrateCustomLoopSettings} from './src/utils/customLoopSetup';
import { isEditableSourceSkip, isStaleModelSnapshot } from './src/utils/marketModelCard';
import { selectAnkDigits } from './src/utils/ankAdaptive';
import { savedDailyLedgerProfiles } from './src/utils/savedDailyLedger';
import { selectStrictPanel30 } from './src/utils/strictPanel30';
import { parseDatedActuals } from './src/utils/backtestResult';
import { chartRowsReader } from './src/utils/chartRowsReader';
import { vipMembershipActive } from './src/utils/vipMembership';
import { CHART_LINKS, getEffectiveMarkets, getEffectiveBaseMarkets } from './src/data/markets';
import { isMarketEnabledForDate } from './src/utils/profileMarketToggle';
import { normalizeManualResult, manualResultMatchesStatus, manualResultStatus } from './src/utils/manualResult';
import { linkedManualResults } from './src/utils/linkedManualResult';
import { automaticResultError } from './src/utils/automaticResultValidation';
import { panelAnkDigit } from './src/utils/panelAnk';
import { getScrapeSource, normalizeScrapeSource, type ScrapeSource } from './src/utils/scrapeProvenance';
import express from "express";
import path from "path";
import fs from "fs";
import dns from "node:dns";
import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { areSettlementTokensValid, calculateRecoveryRate, calculateSmartStakingRates, calculateSettlement, countSettlementTokens, isRecoveryRatePossible, settlementTokenHit } from './src/utils/settlement';
import { selectPreTargetRecentJodis, selectRecentUniqueDigits } from './src/utils/scrapeSelection';
import { parseSmartJodiChart } from './src/utils/smartChart';
import { selectSameWeekdayVerticalDigits, selectSameWeekdayVerticalComboDigits } from './src/utils/weekdayVertical';
import { selectSmartAnkEnsemble } from './src/utils/smartAnkEnsemble';
import { filterPanelsByAnkDigits, normalizeAnkDigits, normalizePanelPatti, selectLowFrequencyPanels } from './src/utils/panelAnk';
import { applyProfileVisibilityUpdates, applyRuntimeVisibilityUpdates, normalizeVisibilityUpdates } from './src/utils/profileVisibility';
import { migrateRecoveryStateForSplitChange } from './src/utils/recoveryMigration';
import { jodiOpenSideStatus, rebuildSettledTrackState } from './src/utils/recoveryLedger';
import { classifyResultStage, extractResultNumbers, resolveAmbiguousMarketByIST, resultMergeKey, resultSignature } from './src/utils/resultMonitoring';
import { authoritativeProfileIds } from './src/utils/profileIsolation';
import { applyProfileMarketToggle, setRuntimeMarketEnabled } from './src/utils/profileMarketToggle';
import { applyProfileCardSenderFormat, applyProfileMessageFormat, preserveAtomicProfilePreferences, protectCustomLoopChanges, acceptedVisibilityPreferences } from './src/utils/profileMessageFormat';
import { businessDateIST } from './src/utils/businessDate';
import { restoreBacktestRecord, restoreBacktestDay, mergeRestoreSources } from './src/utils/backtestRestore';
import { calculateBacktestRecovery } from './src/utils/backtestRecovery';
import { getBaseMarketUnsettledState, getCardSameMarketRecoveryState } from './src/utils/calculator';
import { vipCopiesAdmin } from './src/utils/adminMirror';
import { InFlightRequests } from './src/utils/inFlightRequests';
import { normalizeIncomeSourceList, normalizeTargetJid, normalizeTargetList } from './src/utils/targetNormalization';
import { CARD_SOURCE_MODES, type CardSourceMode } from './src/types';
import { buildMarketBehaviorPrediction } from './src/utils/marketBehavior';
import { buildDynamicAnkPrediction, buildDynamicPanelPrediction } from './src/utils/dynamicPrediction';
import { isTelegramTarget, isGroupTarget, isChannelTarget } from './src/utils/targetNormalization';
import { acknowledgedTargets, transportTargets, allDelivered, type Transport } from './src/utils/transportDelivery';
import { buildPremiumPlayCard, buildPremiumResultCard, formatFullDrawResult } from './src/utils/messageTemplates';
import { buildProfitMilestoneMessage, calculateProfitMilestoneSummary, reachedProfitMilestone, profitMilestoneLedger } from './src/utils/profitMilestone';
import { installTelegramGateway } from './telegram-gateway';

async function startServer() {
  // Android/Termux often resolves an IPv6 address first even when the device
  // has no working IPv6 route. Browser scraping then works while Node fetch
  // fails with ENETUNREACH/timeout. Prefer IPv4 but retain normal DNS fallback.
  try { dns.setDefaultResultOrder('ipv4first'); } catch (_) {}
  const app = express();
  // BUG FIX: Resolve runtime assets from an explicit app root instead of the caller's shell cwd.
  const titanAppRoot = path.resolve(process.env.TITAN_APP_ROOT || process.cwd());
  // Auto-load .env when launched directly outside PM2 (without overriding explicit env vars).
  for (const envCandidate of [path.join(titanAppRoot, '.env'), path.join(process.env.HOME || '', 'Titan', '.env')]) {
    try {
      if (!fs.existsSync(envCandidate)) continue;
      for (const rawLine of fs.readFileSync(envCandidate, 'utf8').split(/\r?\n/)) {
        const line = rawLine.trim();
        if (!line || line.startsWith('#')) continue;
        const eq = line.indexOf('=');
        if (eq <= 0) continue;
        const k = line.slice(0, eq).trim();
        const v = line.slice(eq + 1).trim().replace(/^(['"])(.*)\1$/, '$2');
        if (k && process.env[k] === undefined) process.env[k] = v;
      }
      break;
    } catch (_) {}
  }
  const positiveIntEnv = (name: string, fallback: number, max = Number.MAX_SAFE_INTEGER): number => {
    const parsed = Number(process.env[name]);
    return Number.isInteger(parsed) && parsed > 0 && parsed <= max ? parsed : fallback;
  };
  // OPTIMIZATION: Runtime timing/port values are configurable without editing production source.
  const PORT = positiveIntEnv('PORT', 3000, 65_535);
  // Slow mobile/DNS/TLS starts should not discard a valid chart at 8 seconds.
  // Fast responses still return immediately; explicit deployment limits win.
  const SCRAPE_FETCH_TIMEOUT_MS = positiveIntEnv('SCRAPE_FETCH_TIMEOUT_MS', 15_000, 60_000);
  const SCRAPE_MAX_BYTES = positiveIntEnv('SCRAPE_MAX_BYTES', 8_000_000, 32_000_000);
  const CHART_CACHE_MAX_AGE_MS = positiveIntEnv('CHART_CACHE_MAX_AGE_MS', 72 * 60 * 60 * 1000);
  const SCHEDULE_GRACE_MINUTES = positiveIntEnv('SCHEDULE_GRACE_MINUTES', 20, 180);
  const LIVE_CLAIM_TTL_MS = Math.max(1000, positiveIntEnv('TITAN_LIVE_CLAIM_TTL_MS', 60_000, 300_000));
  // Broadcast delivery is RAM-only and session-bound. A live gateway may finish
  // current safe pacing before picking the next fresh event, but work never
  // survives a gateway session change, server restart, business-date rollover,
  // or this live-session ceiling.
  const LIVE_BROADCAST_MAX_AGE_MS = positiveIntEnv('LIVE_BROADCAST_MAX_AGE_MS', 15 * 60_000, 60 * 60_000);
  const titanDataDir = process.env.TITAN_DATA || process.env.TITAN_DATA_DIR || path.join(process.env.HOME || titanAppRoot, 'titan_data');
  try { fs.mkdirSync(titanDataDir, { recursive: true }); } catch (_) {}
  // Clean up orphaned .tmp files older than 10 minutes and auto-migrate legacy SRIDEVI DAY keys on startup.
  try {
    const nowMs = Date.now();
    const srideviRe = /\b(?:SHRIDEVI|SRIDEVI|SRIDEV)\s+DAY\b/gi;
    const renameSridevi = (val: any): any => {
      if (typeof val === 'string') return val.replace(srideviRe, 'SRIDEVI');
      if (Array.isArray(val)) return val.map(renameSridevi);
      if (val && typeof val === 'object') {
        const out: Record<string, any> = {};
        for (const [k, v] of Object.entries(val)) {
          const nk = k.replace(srideviRe, 'SRIDEVI');
          const nv = renameSridevi(v);
          if (Object.prototype.hasOwnProperty.call(out, nk) && JSON.stringify(out[nk]) !== JSON.stringify(nv)) return val;
          out[nk] = nv;
        }
        return out;
      }
      return val;
    };
    for (const entry of fs.readdirSync(titanDataDir)) {
      const fullPath = path.join(titanDataDir, entry);
      if (entry.endsWith('.tmp')) {
        try {
          const st = fs.statSync(fullPath);
          if (nowMs - st.mtimeMs > 10 * 60_000) fs.unlinkSync(fullPath);
        } catch (_) {}
        continue;
      }
      if (entry.endsWith('.json') && !/cache|receipt|backup/i.test(entry)) {
        try {
          const raw = fs.readFileSync(fullPath, 'utf8');
          if (!srideviRe.test(raw)) { srideviRe.lastIndex = 0; continue; }
          srideviRe.lastIndex = 0;
          const parsed = JSON.parse(raw);
          const migrated = renameSridevi(parsed);
          const nextJson = JSON.stringify(migrated);
          if (nextJson !== raw) {
            const backupDir = path.join(titanDataDir, '.sridevi_rename_backup');
            fs.mkdirSync(backupDir, { recursive: true, mode: 0o700 });
            const backupFile = path.join(backupDir, entry);
            if (!fs.existsSync(backupFile)) fs.copyFileSync(fullPath, backupFile);
            const tmpFile = `${fullPath}.sridevi-${process.pid}.tmp`;
            fs.writeFileSync(tmpFile, nextJson, { mode: 0o600 });
            fs.renameSync(tmpFile, fullPath);
          }
        } catch (_) {}
      }
    }
  } catch (_) {}
  const chartCacheFile = path.join(titanDataDir, 'titan_chart_cache.json');
  type ChartCacheEntry = { html: string; fetchedAt: number; sourceUrl: string };
  type SourceAttempt = { url: string; ok: boolean; detail: string; finalUrl?: string; html?: string; retryAfterMs?: number; resultRow?: ReturnType<typeof parseDatedActuals>[number] | null };
  const chartSourceFetches = new InFlightRequests<{ successfulSource: SourceAttempt | null; sourceAttempts: SourceAttempt[] }>();
  const scrapeBatches=new Map<string,{expiresAt:number;bytes:number;tie:boolean;datedRows:Map<string,ReturnType<typeof parseDatedActuals>>;counted:WeakSet<object>;snapshots:Map<string,any>}>();
  let chartCache: Record<string, ChartCacheEntry> = {};
  try {
    const stored = JSON.parse(fs.readFileSync(chartCacheFile, 'utf-8'));
    if (stored && typeof stored === 'object' && !Array.isArray(stored)) chartCache = stored;
  } catch (_) {}
  // Only the transient HTML cache is pruned. Original market charts, saved
  // digits, index history and financial records are NEVER modified here.
  // Entries older than the already-enforced fallback TTL could not be used for
  // scraping or settlement; keeping them indefinitely only grows Termux RAM
  // and the startup JSON parse after months of provider/URL changes.
  const pruneExpiredChartCache = (now = Date.now()): number => {
    let removed = 0;
    for (const [key, entry] of Object.entries(chartCache)) {
      const age = now - Number(entry?.fetchedAt || 0);
      if (!Number.isFinite(age) || age > CHART_CACHE_MAX_AGE_MS) {
        delete chartCache[key];
        removed++;
      }
    }
    return removed;
  };
  const oldChartCacheRemoved = pruneExpiredChartCache();
  const chartCacheWriter=new DeferredJsonCache(chartCacheFile,()=>JSON.stringify(chartCache),error=>console.error(`[persist:chart-cache] ${chartCacheFile}`,error));
  const saveChartCache=()=>chartCacheWriter.schedule();
  if (oldChartCacheRemoved) saveChartCache();

  // BUG FIX: Critical JSON/text state uses unique-temp atomic replacement and reports write failures.
  const atomicWriteFile = (target: string, contents: string, label: string, throwOnError = false): boolean => {
    const temp = `${target}.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2)}.tmp`;
    try {
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.writeFileSync(temp, contents, 'utf-8');
      fs.renameSync(temp, target);
      return true;
    } catch (error) {
      try { fs.unlinkSync(temp); } catch (_) {}
      console.error(`[persist:${label}] ${target}`, error);
      if (throwOnError) throw error;
      return false;
    }
  };

  const asyncDiskQueues = new Map<string, { pending: string | null; running: boolean }>();
  const atomicWriteFileAsync = (target: string, contents: string, label: string) => {
    let entry = asyncDiskQueues.get(target);
    if (!entry) {
      entry = { pending: null, running: false };
      asyncDiskQueues.set(target, entry);
    }
    entry.pending = contents;
    if (entry.running) return;
    entry.running = true;
    void (async () => {
      try {
        while (entry!.pending !== null) {
          const data = entry!.pending;
          entry!.pending = null;
          const temp = `${target}.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2)}.tmp`;
          try {
            await fs.promises.mkdir(path.dirname(target), { recursive: true });
            await fs.promises.writeFile(temp, data, 'utf-8');
            await fs.promises.rename(temp, target);
          } catch (err) {
            try { await fs.promises.unlink(temp); } catch (_) {}
            console.error(`[persist:${label}-async] ${target}`, err);
          }
        }
      } finally {
        entry!.running = false;
        if (entry!.pending !== null) atomicWriteFileAsync(target, entry!.pending, label);
      }
    })();
  };

  app.use(compression());
  // VIP invitation URLs are sensitive: never send them as navigation referrers or cache API responses.
  app.use((req, res, next) => {
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    if (req.path.startsWith('/api/')) res.setHeader('Cache-Control', 'private, no-store');
    next();
  });

  // Hybrid deployment: allow only the configured Cloudflare Pages origin(s).
  // Keep this unset for same-origin local development. CORS is not a substitute
  // for authentication; sensitive bot/session routes must still be protected.
  const allowedPublicOrigins = new Set(
    String(process.env.PUBLIC_APP_ORIGIN || '')
      .split(',')
      .map((origin) => origin.trim().replace(/\/$/, ''))
      .filter(Boolean),
  );
  app.use((req, res, next) => {
    const origin = String(req.headers.origin || '').replace(/\/$/, '');
    if (origin && allowedPublicOrigins.has(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Vary', 'Origin');
      res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Titan-Admin-Key, X-Titan-Profile-Token, X-Titan-Telegram-Key, X-Titan-Editor-Id');
      res.setHeader('Access-Control-Expose-Headers', 'X-Titan-Workspace-Version, X-Titan-Error-Code, ETag');
    }
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
  });

  // Public access requires an Admin key or a profile-bound VIP token.
  const adminKeyFile = path.join(titanDataDir, 'titan_admin_key.txt');
  let adminKey = String(process.env.TITAN_ADMIN_KEY || '').trim();
  if (!adminKey) {
    for (const candidate of [adminKeyFile, path.join(titanAppRoot, 'titan_data', 'titan_admin_key.txt'), path.join(process.env.HOME || '', 'titan_data', 'titan_admin_key.txt')]) {
      try {
        const val = fs.readFileSync(candidate, 'utf8').trim();
        if (val) { adminKey = val; break; }
      } catch (_) {}
    }
    if (!adminKey) {
      adminKey = randomBytes(32).toString('hex');
    }
    if (!fs.existsSync(adminKeyFile)) {
      try { fs.writeFileSync(adminKeyFile, adminKey, { mode: 0o600 }); } catch (_) {}
    }
  }
  console.log(`Admin access key file: ${adminKeyFile}`);
  const equalSecret = (expected: string, supplied: string) => {
    const a = Buffer.from(expected), b = Buffer.from(supplied);
    return a.length > 0 && a.length === b.length && timingSafeEqual(a, b);
  };
  const trustedLocalClient = (req: express.Request): boolean => {
    // Local Termux bot traffic is trusted only without browser/proxy headers.
    const loopback = ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress || '');
    const localHost = /^(localhost|127\.0\.0\.1|\[::1\])(?::\d+)?$/.test(req.headers.host || '');
    return loopback && localHost && !req.headers.origin && !req.headers.referer
      && !req.headers['sec-fetch-site'] && !Object.keys(req.headers).some(k => k.startsWith('x-forwarded-') || k.startsWith('cf-'));
  };
  // Authenticate full-state uploads before accepting the larger archive body.
  const stateLimitMb = positiveIntEnv('TITAN_STATE_MAX_MB', 64, 256);
  app.use('/api/app/state', (req, res, next) => {
    if (req.method !== 'POST' || trustedLocalClient(req) || equalSecret(adminKey, String(req.headers['x-titan-admin-key'] || ''))) return next();
    return res.status(req.headers['x-titan-profile-token'] ? 403 : 401).json({status:'error',message:'Admin login required for state uploads'});
  }, express.json({limit:`${stateLimitMb}mb`}));
  app.use(express.json({limit:'10mb'}));
  const vipRoutes = new Set([
    '/api/app/payments', '/api/app/payments/submit', '/api/app/state', '/api/app/bulk_operation', '/api/app/profile_market_toggle', '/api/app/archive_recovery_reset', '/api/app/profile_result_parity',
    '/api/app/profile_schedule_policy', '/api/app/profile_delivery_destination', '/api/app/vip_game_run', '/api/app/profile_custom_loops',
    '/api/app/profile_card_sender_format', '/api/app/profile_message_format', '/api/app/profile_visibility', '/api/app/profile_profit_notifications',
    '/api/bot/ledger_snapshot', '/api/bot/ledger_set_card', '/api/bot/ledger_clear_cards', '/api/bot/ledger_copy_admin_snapshot_preview', '/api/bot/ledger_copy_admin_snapshot_batch',
    '/api/bot/sync_ledger', '/api/bot/sync_schedules',
    '/api/scrape_market', '/api/parse_market_url', '/api/smart-scan', '/api/ai/advisor',
  ]);
  app.use('/api', (req, res, next) => {
    if (req.path === '/health' || req.path === '/ai/advisor') return next();
    const token = String(req.headers['x-titan-profile-token'] || req.query.token || req.body?.profileToken || '').trim();
    const internal = trustedLocalClient(req);
    if (equalSecret(adminKey, String(req.headers['x-titan-admin-key'] || '')) || (!token && internal)) return next();
    if (token) {
      // Auth is on the hot path of every API call. Reuse the mtime-aware,
      // validated archive reader instead of parsing the entire JSON per request.
      const profiles: Record<string, any> = readFullAppStateView()?.profiles || {};
      const pid = Object.keys(profiles).find(id => id !== 'admin1' && equalSecret(String(profiles[id]?.vipAccessToken || ''), token));
      if (pid && !vipMembershipActive(profiles[pid]?.expiryDate)) {
        return res.status(403).json({ status: 'error', code: 'VIP_MEMBERSHIP_EXPIRED', message: 'VIP membership expired or has no valid expiry date. Contact Admin to renew.' });
      }
      const route = `/api${req.path}`;
      const requested = String(req.query.profileId || req.body?.profileId || '');
      if (pid && vipRoutes.has(route) && (!requested || requested === pid)
        && !(route === '/api/app/state' && req.method !== 'GET')) {
        // Read-only portals may keep reading. Portal card commands and sync
        // writes obey the edit lock; Admin/backend processing stays independent.
        if (req.method === 'POST' && profiles[pid].vipAccessEnabled === false &&
          ['/api/bot/ledger_set_card', '/api/bot/ledger_clear_cards', '/api/bot/ledger_copy_admin_snapshot_batch',
            '/api/bot/sync_ledger', '/api/bot/sync_schedules'].includes(route)) {
          return res.status(403).json({ status: 'error', message: 'VIP profile is read-only' });
        }
        return next();
      }
      return res.status(403).json({ status: 'error', message: 'VIP access is limited to your own profile' });
    }
    return res.status(401).json({ status: 'error', message: 'Admin login required' });
  });
  const workspaceInstance = randomBytes(12).toString('hex');
  const workspaceVersion = () => `${workspaceInstance}:${fullAppStateRevision}`;
  // Version belongs to the exact snapshot response, not an unrelated API call.
  app.use(['/api/app/state', '/api/app/editor_lease'], (_req, res, next) => {
    const send = res.send.bind(res);
    res.send = ((body: any) => { res.set('X-Titan-Workspace-Version', workspaceVersion()); return send(body); }) as typeof res.send;
    next();
  });
  const editorLease = new EditorLease();
  app.post('/api/app/editor_lease', (req, res) => {
    const id = String(req.headers['x-titan-editor-id'] || '');
    const action = req.body?.action;
    if (action === 'release') { editorLease.release(id); return res.json({status:'success'}); }
    const granted = action === 'takeover' ? editorLease.takeover(id) : action === 'acquire' ? editorLease.acquire(id) : action === 'renew' && editorLease.renew(id);
    if (!granted) return res.set('X-Titan-Error-Code','EDITOR_LEASE_REQUIRED').status(409).json({ status: 'error', code: 'EDITOR_LEASE_REQUIRED' });
    if (req.body?.hydrate === true) {
      try {
        const started=performance.now();
        restoreSavedAdminSchedules();
        const stored = readFullAppStateView(true);
        const merged = stored ? mergeLedgerIntoFullAppState(stored) : null;
        if (merged && merged !== stored) writeFullAppState(merged);
        res.set('Cache-Control', 'no-store');
        const body=serializeWorkspaceSnapshot(merged, req.body?.knownStateHash);
        res.set('Server-Timing',`workspace;dur=${(performance.now()-started).toFixed(1)}`);
        return res.type('json').send(body);
      } catch (error: any) {
        editorLease.release(id);
        return res.status(500).json({ status: 'error', message: error?.message || 'Workspace state unavailable' });
      }
    }
    return res.json({ status: 'success' });
  });
  // Internal bot/test clients remain separate. Every Admin browser mutation needs
  app.use('/api', (req, res, next) => {
    if (req.path === '/ai/advisor') return next();
    const browser = Boolean(req.headers['sec-fetch-site'] || req.headers.origin || req.headers.referer || req.headers['x-titan-editor-id']);
    const vip = Boolean(req.headers['x-titan-profile-token'] || req.query.token || req.body?.profileToken);
    if (browser && !vip && !['GET','HEAD','OPTIONS'].includes(req.method) && !editorLease.active(String(req.headers['x-titan-editor-id'] || ''))) {
      return res.set('X-Titan-Error-Code','EDITOR_LEASE_REQUIRED').status(409).json({status:'error',code:'EDITOR_LEASE_REQUIRED',message:'Admin session unavailable. Reconnect to the saved workspace.'});
    }
    next();
  });
  // The exclusive Admin owner is already the only browser publisher.
  app.get('/api/app/workspace_revision', (_req,res) => res.json({version:workspaceVersion()}));
  app.post('/api/app/runtime_claim', (req,res) => {
    const id=String(req.headers['x-titan-editor-id']||'');
    if(!editorLease.active(id))return res.set('X-Titan-Error-Code','EDITOR_LEASE_REQUIRED').status(409).json({status:'error',code:'EDITOR_LEASE_REQUIRED'});
    // Compatibility for an already-open older bundle. New clients make no claim request.
    return res.json({status:'success',publisher:true,claim:'single-admin'});
  });
  app.get('/api/access', (_req, res) => res.json({ status: 'success' }));

  // API Health Check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", app: "Titan Nova AI" });
  });

  // AI Smart Text Scanner powered by Gemini
  app.post("/api/smart-scan", async (req, res) => {
    try {
      const { text, image, gameType } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;

      if (!apiKey) {
        return res.status(400).json({
          status: "error",
          message: "GEMINI_API_KEY environment variable is not configured."
        });
      }

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
      const prompt = `You are Titan Nova AI, a Matka & Number Ledger Extractor. 
Extract market predictions from the following text/image into structured JSON.
Markets available: Sridevi, Time Bazar, Madhur Day, Milan Day, Rajdhani Day, Supreme Day, Kalyan, Sridevi Night, Madhur Night, Supreme Night, Milan Night, Kalyan Night, Rajdhani Night, Main Bazar.
Game Type target: ${gameType || 'ank'} (ank = single digits 0-9, jodi = 2-digit pairs 00-99, pannel = 3-digit panels).
Format output STRICTLY as JSON with array of items:
[
  {
    "market": "KALYAN",
    "phase": "OPEN", // or "CLOSE"
    "digits": ["1", "2", "3"],
    "rate": 100
  }
]
Input content:
${text || 'Extract predictions'}`;

      let response;
      if (image && typeof image === 'string' && image.startsWith('data:image')) {
        const base64Data = image.split(',')[1];
        const mimeType = image.split(';')[0].split(':')[1];
        response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: [
            {
              role: 'user',
              parts: [
                { inlineData: { mimeType, data: base64Data } },
                { text: prompt }
              ]
            }
          ]
        });
      } else {
        response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt
        });
      }

      const rawText = response.text || '';
      // Clean JSON fence if present
      const cleanedText = rawText.replace(/```json/g, '').replace(/```/g, '').trim();
      let parsedJson = [];
      try {
        parsedJson = JSON.parse(cleanedText);
      } catch {
        parsedJson = [];
      }

      res.json({ status: "success", data: parsedJson, raw: rawText });
    } catch (err: any) {
      console.error("Gemini API Error:", err);
      res.status(500).json({ status: "error", message: err.message || "Failed to scan text with Gemini AI" });
    }
  });

  // Intelligent Local Strategic Advisor Engine (zero-latency fallback when GEMINI_API_KEY is not configured or rate-limited)
  const generateLocalAdvisorResponse = (prompt: string, context: any): string => {
    const rawLower = (prompt || '').toLowerCase();
    const marketCards = Array.isArray(context?.marketCards) ? context.marketCards : [];

    // Check if user is asking for market results
    const isAskingResult = rawLower.includes('result') || rawLower.includes('aaj ka') || rawLower.includes('kya aaya') || rawLower.includes('score') || rawLower.includes('declare');

    // Known market alias mapping
    const knownMarketTokens = [
      { name: 'SRIDEVI NIGHT', tokens: ['sridevi night', 'shridevi night'] },
      { name: 'SRIDEVI', tokens: ['sridevi', 'shridevi'] },
      { name: 'TIME BAZAR', tokens: ['time bazar', 'time'] },
      { name: 'MADHUR DAY', tokens: ['madhur day', 'madhur'] },
      { name: 'MADHUR NIGHT', tokens: ['madhur night'] },
      { name: 'MILAN DAY', tokens: ['milan day'] },
      { name: 'MILAN NIGHT', tokens: ['milan night'] },
      { name: 'RAJDHANI DAY', tokens: ['rajdhani day'] },
      { name: 'RAJDHANI NIGHT', tokens: ['rajdhani night'] },
      { name: 'SUPREME DAY', tokens: ['supreme day'] },
      { name: 'SUPREME NIGHT', tokens: ['supreme night'] },
      { name: 'KALYAN NIGHT', tokens: ['kalyan night'] },
      { name: 'KALYAN', tokens: ['kalyan'] },
      { name: 'MAIN BAZAR', tokens: ['main bazar', 'main bombay'] },
    ];

    let targetMarketCard: any = null;
    let targetMarketName: string = '';

    for (const km of knownMarketTokens) {
      if (km.tokens.some(t => rawLower.includes(t))) {
        targetMarketName = km.name;
        targetMarketCard = marketCards.find((c: any) => {
          const cName = String(c.market || '').toUpperCase();
          return cName.includes(km.name) || km.name.includes(cName.replace(/\s+(OPEN|CLOSE)$/, ''));
        });
        break;
      }
    }

    if (!targetMarketCard && context?.selectedMarketFocus && context.selectedMarketFocus !== 'ALL') {
      targetMarketName = context.selectedMarketFocus;
      targetMarketCard = marketCards.find((c: any) => String(c.market || '').toUpperCase().includes(targetMarketName.toUpperCase()));
    }

    // 0. Inductive Example-to-Rule & New Input Prediction ("Examples se Rule Niklega aur Naye Input pe Predict Karega")
    if (context?.discoveredRule && (rawLower.includes('example') || rawLower.includes('rule') || rawLower.includes('->') || rawLower.includes('=>') || rawLower.includes('predict') || rawLower.includes('naya input'))) {
      const dr = context.discoveredRule;
      const recMarket = targetMarketName || (marketCards[0]?.market ? marketCards[0].market : 'KALYAN OPEN');
      const stepsList = Array.isArray(dr.verifications)
        ? dr.verifications.map((v: any) => `• \`${v.stepExplanation}\` ${v.matched ? '✅' : '❌'}`).join('\n')
        : '';

      return `🧬 **Examples Se Extracted Rule & New Input Prediction**:

- **🔍 Discovered Rule**: **${dr.ruleName}**
- **📐 Formula**: \`${dr.formulaDescription}\`
- **🎯 Rule Accuracy on Examples**: **${dr.accuracy}%** (${dr.matchedCount}/${dr.totalExamples} Examples Matched)

**✅ Step-by-Step Verification on Examples**:
${stepsList}

**🚀 Naye Input [\`${dr.newInput}\`] Pe Prediction**:
- **Direct Rule Output (Single Ank)**: **\`${dr.predictedSingleAnk}\`**
- **Balanced 4-Ank Set (Main + Mirror + Step)**: **\`${dr.recommended4Ank}\`**
- **Calculation**: ${dr.predictionExplanation}

>>> RECOMMENDATION: Market: "${recMarket}" | Digits: "${dr.recommended4Ank}" | Strategy: "Rule: ${dr.ruleName}" <<<

*(⚡ Titan Inductive Rule Engine — Aap **🧠 Self-Learn AI** button daba kar **🧬 Examples → Rule & Predict** studio me bhi examples customize kar sakte hain)*`;
    }

    // 1. Result queries
    if (isAskingResult || (targetMarketCard && (rawLower.includes('batao') || rawLower.includes('kya')))) {
      if (targetMarketCard) {
        const declared = targetMarketCard.actualResult && targetMarketCard.actualResult !== 'Pending' && targetMarketCard.actualResult !== 'None' ? targetMarketCard.actualResult : null;
        const status = targetMarketCard.status || 'PENDING';
        const digits = targetMarketCard.currentDigits || 'None';
        const isShield = targetMarketCard.isShield ? '🛡️ Active (Double-Loss Protected)' : 'Standard Flow';

        if (declared) {
          return `📊 **${targetMarketCard.market} — Today's Result**:

- **Declared Result**: \`${declared}\`
- **Card Status**: **${status}** ${status === 'PASS' ? '✅' : status === 'FAIL' ? '❌' : '⏳'}
- **Current Digits on Card**: \`${digits}\`
- **Protection Mode**: ${isShield}

${status === 'PASS' ? '🎉 Great! Yeh card **PASS** ho chuka hai.' : status === 'FAIL' ? '⚠️ Yeh card pass nahi hua. Close side me **OTC Mirror Hedge** use karein recovery ke liye.' : 'Result board par sync ho chuka hai.'}

*(⚡ Titan Local Strategic Engine — Gemini API Key configure karne ke liye AI Studio ke **Settings > Secrets** me \`GEMINI_API_KEY\` set karein)*`;
        } else {
          return `⏳ **${targetMarketCard.market} — Result Status**:

- **Current Status**: **PENDING** (Result abhi live announce nahi hua hai)
- **Active Digits on Card**: \`${digits}\`
- **Protection Mode**: ${isShield}

Result declare hote hi **Test Result** dabayein ya live scraper automatic update karega.

*(⚡ Titan Local Strategic Engine — Gemini API Key configure karne ke liye AI Studio ke **Settings > Secrets** me \`GEMINI_API_KEY\` set karein)*`;
        }
      }

      // If no specific market was matched, list all declared results today
      const declaredList = marketCards.filter((c: any) => c.actualResult && c.actualResult !== 'Pending' && c.actualResult !== 'None');
      if (declaredList.length > 0) {
        const rows = declaredList.map((c: any) => `• **${c.market}**: Result \`${c.actualResult}\` (${c.status})`).join('\n');
        return `📊 **Today's Declared Results (${context?.currentDate || 'Today'})**:\n\n${rows}\n\nBaki markets ke result aane par **Test Result** dabayein. Kisi specific market ka result dekhne ke liye uska naam puchein (jaise *"Sridevi Night ka result"*).\n\n*(⚡ Titan Local Strategic Engine)*`;
      } else {
        return `⏳ **Today's Results Status (${context?.currentDate || 'Today'})**:\n\nAaj ke sabhi markets abhi **PENDING** hain ya results declare hona shuru nahi hue hain.\n\nAap kisi specific market ka naam likh kar status check kar sakte hain, jaise *"Kalyan result"* ya *"Sridevi Night result"*.\n\n*(⚡ Titan Local Strategic Engine)*`;
      }
    }

    // 2. Drawdown & Shield queries
    if (rawLower.includes('shield') || rawLower.includes('drawdown') || rawLower.includes('loss') || rawLower.includes('risk')) {
      const shieldCount = context?.activeShieldCount || 0;
      const conservativeCount = context?.conservativeFallbackCount || 0;
      const winRate = context?.selfLearningWinRate ? (context.selfLearningWinRate * 100).toFixed(1) : '38.8';
      return `🛡️ **Titan Anti-Drawdown & Risk Shield Audit**:

- **Anti-Drawdown Shields Active**: **${shieldCount} cards**
- **Conservative Fallback Safe-Mode**: **${conservativeCount} cards**
- **Bayesian Portfolio Win Rate**: **${winRate}%**

**Mathematical Protection Rules**:
1. **OTC Mirror Cut Law**: Agar Open side fail hoti hai, Close side me Open digit aur uska mirror cut \`[O, O+5, O+1, O+6]\` cover kiya jata hai to protect against continuous 7L+ drawdowns.
2. **Conservative Fallback**: Agar confidence score < 75% ho jata hai, AI volatile chart spikes chod kar Golden Date Root & Weekday Lord anchor use karta hai.

*(⚡ Titan Local Strategic Engine)*`;
    }

    // 3. Explain weights / self learning
    if (rawLower.includes('weight') || rawLower.includes('self learning') || rawLower.includes('learning') || rawLower.includes('bandit')) {
      const winRate = context?.selfLearningWinRate ? (context.selfLearningWinRate * 100).toFixed(1) : '38.8';
      const weights = context?.digitWeights || {};
      const sortedDigits = Object.entries(weights)
        .sort((a: any, b: any) => Number(b[1]) - Number(a[1]))
        .slice(0, 4)
        .map(([d, w]) => `**${d}** (${Number(w).toFixed(2)})`)
        .join(', ');

      return `📊 **Titan Self-Learning Engine Weights Summary**:

- **Model Accuracy (Win Rate)**: **${winRate}%** (4-Ank expected baseline: 40%)
- **Top Affinity Digits Today**: ${sortedDigits || '0, 4, 5, 1'}
- **Core Strategy Allocations**:
  • **Trend & Momentum (Hot Digits)**: 2.5x Weight
  • **Satta Mirror Cut (X ↔ X+5)**: 2.5x Weight
  • **Cold & Gap Recovery (Overdue)**: 2.5x Weight
  • **Markov Transition (Day Shift)**: 1.0x Weight

Weights har roz actual result aane par multi-armed bandit algorithm ke zariye automatic optimize hote hain.

*(⚡ Titan Local Strategic Engine)*`;
    }

    // 4. Recommendation / Guessing queries
    const targetName = targetMarketName || (marketCards[0]?.market ? marketCards[0].market.replace(/\s+(OPEN|CLOSE)$/, '') : 'KALYAN');
    const dateNum = parseInt((context?.currentDate || '2026-11-10').replace(/-/g, '').slice(-2), 10) || 10;
    const anchor1 = dateNum % 10;
    const cut1 = (anchor1 + 5) % 10;
    const anchor2 = (anchor1 + 3) % 10;
    const cut2 = (anchor2 + 5) % 10;
    const tetrad = Array.from(new Set([anchor1, cut1, anchor2, cut2])).sort((a,b)=>a-b).join(', ');

    return `👑 **Balanced 4-Ank Recommendation for ${targetName}**:

>>> RECOMMENDATION: Market: "${targetName}" | Digits: "${tetrad}" | Strategy: "Balanced Satta Mirror Tetrad Law" <<<

**Mathematical Rationale**:
- **Mirror Pair 1**: \`${anchor1} ↔ ${cut1}\` (Cosmic Date Root Anchor)
- **Mirror Pair 2**: \`${anchor2} ↔ ${cut2}\` (Harmonic Shift Anchor)
- **Tetrad Law**: Satta Matka me 45%+ draws mirror family me settle hote hain. Two balanced cut pairs lagane se single-side blind spots neutralize ho jate hain.
- **1-Click Apply**: Niche diye gaye **Apply to Card** button par click karke digits direct card me load kar sakte hain.

*(⚡ Titan Local Strategic Engine — Full AI chat ke liye Settings > Secrets me \`GEMINI_API_KEY\` add karein)*`;
  };

  // AI Advisor & Strategic Helper Endpoint powered by Gemini 3.8 Flash (with Local Intelligence Fallback)
  app.post("/api/ai/advisor", async (req, res) => {
    const { prompt, context, history } = req.body;
    const apiKey = process.env.GEMINI_API_KEY;

    // If Gemini API Key is configured, attempt Gemini 3.8 Flash with fallback to 3.1 Flash Lite
    if (apiKey) {
      try {
        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: {
            headers: {
              'User-Agent': 'aistudio-build',
            }
          }
        });

        const systemInstruction = `You are Titan Nova AI Guru — an elite mathematical strategist and advisor for the Indian Matka & Number Ledger management platform.
You respond in natural, friendly, expert Hinglish (Hindi + English) or clear English.

Core Mathematical Rules of Titan Nova:
1. Balanced 4-Ank Tetrad Law: Every valid 4-Ank recommendation MUST consist of two balanced cut/mirror pairs [A, A+5, B, B+5] (e.g. 1-6-4-9 or 2-7-3-8). Single-side bets without mirror coverage fail on 45% of Satta draws.
2. Open-to-Close (OTC) Recovery Shield: When an OPEN market declares digit O (e.g., Kalyan Open result = 5), the CLOSE market must link to Open's mirror cut family: [O, O+5, (O+1)%10, ((O+1)+5)%10]. This prevents double-loss drawdowns (protecting against 7L+ risk drawdowns).
3. Jodi Sum & Diff Harmonic: Yesterday's settled Jodi (Open + Close) gives the Jodi Sum and Jodi Diff. Their mirror cuts form the primary mathematical anchors.
4. Cosmic Date Root & Weekday Lord: Calendar day sum (DayOfMonth % 10) and Weekday Lord are foundational conservative anchors.
5. Conservative Fallback: When market confidence is below 75% or has consecutive losses, advise shifting to the conservative Golden Date Root & Lord anchor rather than chasing volatile chart swings.

User Context:
You will receive real-time portfolio context including active markets, declared open/close results, fail streaks, current card digits, and self-learning weights.

Formatting Guidelines:
- Give crisp, actionable, bulleted advice.
- If you recommend digits for a market, use this exact syntax so the user can 1-click apply them:
  >>> RECOMMENDATION: Market: "<MARKET_NAME>" | Digits: "<D1, D2, D3, D4>" | Strategy: "<STRATEGY_NAME>" <<<
- Keep answers encouraging, structured, and easy to read on mobile.`;

        const contents: any[] = [];
        if (Array.isArray(history)) {
          for (const item of history.slice(-6)) {
            if (item && item.role && item.text) {
              contents.push({
                role: item.role === 'model' || item.role === 'assistant' ? 'model' : 'user',
                parts: [{ text: String(item.text) }]
              });
            }
          }
        }

        let userPrompt = prompt || 'Please analyze today\'s markets and advise on best strategy.';
        if (context && typeof context === 'object') {
          userPrompt += `\n\n[Active Portfolio Context]:\n${JSON.stringify(context, null, 2)}`;
        }

        contents.push({
          role: 'user',
          parts: [{ text: userPrompt }]
        });

        const candidateModels = ['gemini-3.8-flash', 'gemini-3.1-flash-lite'];
        let reply = '';

        const timeoutPromise = new Promise<string>((_, reject) =>
          setTimeout(() => reject(new Error('GEMINI_TIMEOUT')), 6000)
        );

        for (const modelName of candidateModels) {
          try {
            const callPromise = ai.models.generateContent({
              model: modelName,
              contents,
              config: {
                systemInstruction,
              }
            }).then(r => r.text || '');

            reply = await Promise.race([callPromise, timeoutPromise]);
            if (reply) break;
          } catch (modelErr: any) {
            console.warn(`[AI Advisor] Model ${modelName} error:`, modelErr?.message);
            continue;
          }
        }

        if (reply) {
          return res.json({ status: "success", reply, source: "gemini" });
        }
      } catch (geminiErr: any) {
        console.warn("[AI Advisor] Gemini call failed, falling back to local engine:", geminiErr?.message);
      }
    }

    // High-performance Local Engine fallback: guarantees instant, 100% reliable response
    try {
      const localReply = generateLocalAdvisorResponse(prompt, context);
      return res.json({ status: "success", reply: localReply, source: "local-engine" });
    } catch (fallbackErr: any) {
      console.error("[AI Advisor Fallback Error]:", fallbackErr);
      return res.json({
        status: "success",
        reply: "Namaste! Mai aapka Titan Nova AI Advisor hoon. Aap kisi bhi market ka result ya 4-Ank recommendation pooch sakte hain (jaise: 'Sridevi Night result' ya 'Kalyan guessing').",
        source: "local-default"
      });
    }
  });

  // Live & Algorithmic Market Scraper Endpoint according to Python chart parser specifications
  const scrapeMarketHandler = async (req: any, res: any) => {
    try {
      const { market, type, isCombo, scrapeUrl, ankDigits, smartMode, selectionMode, targetDate } = req.body;
      const marketName = String(market || '').toUpperCase().trim();
      const gameType = String(type || 'ank').toLowerCase();
      const comboMode = Boolean(isCombo) || (gameType === 'ank' && selectionMode === 'same_weekday_vertical_combo');
      const isPanelGame = gameType === 'pannel' || gameType === 'panel';
      const panelAnkDigits = normalizeAnkDigits(ankDigits);
      const safeBacktest = req.body.backtest === true || req.body.resultOnly === true;
      const backtestDate = String(targetDate || '').trim();
      if(req.body.historyTie===true&&(!safeBacktest||gameType!=='ank'||!/^history_[a-zA-Z0-9_-]{8,90}$/.test(String(req.body.scrapeBatchId||''))))return res.status(400).json({status:'error',message:'History Tie requires a private run batch and past-date ANK request'});
      if (safeBacktest && (!/^\d{4}-\d{2}-\d{2}$/.test(backtestDate) || !Number.isFinite(Date.parse(backtestDate)) || new Date(backtestDate).toISOString().slice(0,10)!==backtestDate || backtestDate > businessDateIST(new Date()) || (backtestDate === businessDateIST(new Date()) && req.body.resultOnly !== true && req.body.todayBacktest !== true))) {
        return res.status(400).json({ status:'error', message:'Auto backtest sirf valid past date ke liye hai; live date unchanged rahegi' });
      }
      if(req.body.historyRelease===true){
        if(req.body.historyTie!==true)return res.status(400).json({status:'error',message:'Private history run required'});
        const id=String(req.body.scrapeBatchId||'');
        if(scrapeBatches.get(id)?.tie)scrapeBatches.delete(id);
        return res.json({status:'success',targetDate:backtestDate,historyReleased:true});
      }
      if(req.body.historyTieDates!==undefined){
        const dates=req.body.historyTieDates;
        if(req.body.historyTie!==true||req.body.historyDatesOnly===true||!Array.isArray(dates)||!dates.length||dates.length>8||new Set(dates).size!==dates.length||dates.some((d:any)=>typeof d!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(d)||!Number.isFinite(Date.parse(d))||new Date(d).toISOString().slice(0,10)!==d||d>=businessDateIST()))return res.status(400).json({status:'error',message:'Valid bounded past history dates required'});
        const replies=[];
        for(const date of dates){
          if(req.aborted||res.destroyed)return;
          let reply:any;
          const response:any={status:()=>response,json:(value:any)=>{reply=value;return response;}};
          await scrapeMarketHandler({body:{...req.body,targetDate:date,historyTieDates:undefined}},response);
          replies.push({...reply,targetDate:reply?.targetDate||date});
          await new Promise<void>(resolve=>setImmediate(resolve));
        }
        return res.json({status:'success',market:marketName,gameType,targetDate:backtestDate,historyReplies:replies});
      }
      if (isPanelGame && panelAnkDigits.length === 0) {
        return res.status(400).json({
          status: 'error',
          message: 'Panel scraping ke liye same market ka ANK digit required hai',
        });
      }

      // Base market extraction (e.g. "KALYAN OPEN" -> "KALYAN")
      let baseName = marketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim();

      // Find URL
      const targetUrl = resolveChartSource(marketName, scrapeUrl, CHART_LINKS);

      if (!targetUrl) {
        return res.status(400).json({ status: 'error', message: `PlayMatka chart URL required for market: ${marketName}` });
      }

      // A direct Test Result click may reuse a recently *successfully fetched*,
      // market-verified chart, not an offline/stale fallback. Keep this window
      // deliberately tiny: an older chart must go back to the one provider.
      if (req.body.resultOnly === true && req.body.fastResult === true) {
        const key = `playmatka-only-v1|${baseName.toUpperCase()}|${String(targetUrl)}`;
        const recent = chartCache[key];
        const age = Date.now() - Number(recent?.fetchedAt || 0);
        if (recent?.html && age >= 0 && age <= 15_000 && chartMatchesMarket(recent.html, baseName)) {
          const result = parseDatedActuals(recent.html).find(row => row.date === backtestDate);
          // Reuse only fully published, date-matched draws; never settle with
          // incomplete or missing values from a potentially updating chart.
          if (result?.open && result?.jodi && result?.close) {
            return res.json({status:'success', targetDate:backtestDate,actual:result,
              market:marketName,gameType,sourceUrl:recent.sourceUrl,
              staleCache:false,sourceFreshAgeMs:age,fastResultSource:'recent-verified-chart'});
          }
        }
      }

      // Frequency + recency weighted ranking (recent results weigh more)
      const rankByFrequencyRecency = (items: string[], limit = 10): string[] => {
        const scores = new Map<string, number>();
        const n = items.length;
        items.forEach((item, idx) => {
          // idx 0 = oldest in this array if we pass oldest-first; we pass recent-first below
          const recencyWeight = 1 + (n - idx) / Math.max(n, 1); // newer = higher
          scores.set(item, (scores.get(item) || 0) + recencyWeight);
        });
        return Array.from(scores.entries())
          .sort((a, b) => b[1] - a[1])
          .slice(0, limit)
          .map(([k]) => k);
      };

      const getCombinedDigitsRecentToOld = (jodiArr: string[]) => {
        const seen = new Set<string>();
        const result: string[] = [];
        const recentToOld = [...jodiArr].reverse();
        for (const j of recentToOld) {
          const clean = j.replace(/-/g, '').trim();
          if (clean.length === 2 && /^\d{2}$/.test(clean)) {
            // CLOSE is the latest result of each day; then OPEN, then the previous day.
            for (const d of [clean[1], clean[0]]) {
              if (!seen.has(d)) {
                seen.add(d);
                result.push(d);
              }
              if (result.length >= 10) return result.join(', ');
            }
          }
        }
        return result.join(', ');
      };

      // Stock charts use the selected provider only; no legacy mirror fallback.
      const configuredUrls = [String(targetUrl)];
      const candidateUrls = [...new Set(configuredUrls.filter((url) => url.startsWith('http://') || url.startsWith('https://')))];
      if (!candidateUrls.length) {
        return res.status(400).json({ status: 'error', message: 'Valid http(s) chart URL nahi mila' });
      }

      const readBoundedBody = async (fetchRes: Response, maxBytes = SCRAPE_MAX_BYTES) => {
        if (!fetchRes.body) return '';
        const reader = fetchRes.body.getReader();
        const decoder = new TextDecoder();
        const chunks: string[] = [];
        let received = 0;
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          received += value.byteLength;
          if(received>maxBytes){
            try{await reader.cancel('chart body limit exceeded');}catch{}
            throw new Error(`Chart body exceeds ${maxBytes} bytes; incomplete source rejected`);
          }
          chunks.push(decoder.decode(value,{stream:true}));
        }
        chunks.push(decoder.decode());
        return chunks.join('');
      };

      const looksLikeChart = (body: string) => {
        const plain = body.replace(/<[^>]+>/g, ' ');
        const hasDate = /\d{1,2}\s*[/-]\s*\d{1,2}\s*[/-]\s*\d{2,4}/i.test(plain);
        const hasFullResult = /\b\d{3}\s*[-:–—/]\s*\d{1,2}\s*[-:–—/]\s*\d{3}\b/.test(plain);
        const hasEnoughCells = (body.match(/<t[dh]\b/gi) || []).length >= 8;
        return (hasDate || hasFullResult) && (/<table\b/i.test(body) || hasFullResult || hasEnoughCells);
      };

      const requestedTimeout=Number(req.body.requestTimeoutMs);
      const fetchTimeout=Number.isInteger(requestedTimeout)&&requestedTimeout>=3000&&requestedTimeout<=90000?Math.min(SCRAPE_FETCH_TIMEOUT_MS,requestedTimeout-2000):SCRAPE_FETCH_TIMEOUT_MS;
      const activeFetchControllers = new Set<AbortController>();
      const fetchCandidate = async (candidateUrl: string): Promise<SourceAttempt> => {
        const controller = new AbortController();
        activeFetchControllers.add(controller);
        let timedOut = false;
        const timeoutId = setTimeout(() => {
          timedOut = true;
          controller.abort();
        }, fetchTimeout);
        try {
          const fetchRes = await safeChartFetch(candidateUrl, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.144 Mobile Safari/537.36',
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
              'Accept-Language': 'en-IN,en;q=0.9,hi;q=0.8',
              'Referer': 'https://www.google.com/',
            },
            signal: controller.signal,
          }, process.env.TITAN_TEST_ALLOW_LOOPBACK === '1', undefined, process.env.TITAN_TEST_ALLOW_LOOPBACK === '1' ? undefined : CHART_PROVIDER_HOSTS);
          if (!fetchRes.ok) {
            await fetchRes.body?.cancel();
            const after=fetchRes.headers.get('Retry-After'),seconds=after?Number(after):NaN;
            const retryAfterMs=after?(Number.isFinite(seconds)?seconds*1000:Date.parse(after)-Date.now()):undefined;
            return { url: candidateUrl, ok: false, detail: `HTTP ${fetchRes.status}`, finalUrl: fetchRes.url, ...(retryAfterMs!==undefined&&Number.isFinite(retryAfterMs)?{retryAfterMs:Math.max(0,retryAfterMs)}:{}) };
          }
          const candidateHtml = normalizeProviderChartHtml(await readBoundedBody(fetchRes));
          // HTTP 200 is not enough: verify this is the requested market's chart.
          // Never let a generic results/maintenance page overwrite card digits.
          if (!chartMatchesMarket(candidateHtml, baseName)) {
            return { url: candidateUrl, ok: false, detail: `Chart heading does not match ${baseName}; card unchanged`, finalUrl: fetchRes.url };
          }
          if (looksLikeChart(candidateHtml)) {
            if (req.body.resultOnly === true) {
              const actual=parseDatedActuals(candidateHtml).find(row=>row.date===backtestDate) || null;
              if (!actual?.open || !actual?.jodi || !actual?.close) {
                return {url:candidateUrl,ok:false,detail:actual ? 'Requested date has partial actual; checking other mirrors' : 'Requested date actual missing',finalUrl:fetchRes.url,html:candidateHtml,resultRow:actual};
              }
              return {url:candidateUrl,ok:true,detail:`${candidateHtml.length} chars`,finalUrl:fetchRes.url,html:candidateHtml,resultRow:actual};
            }
            return { url: candidateUrl, ok: true, detail: `${candidateHtml.length} chars`, finalUrl: fetchRes.url, html: candidateHtml };
          }
          return { url: candidateUrl, ok: false, detail: `HTML received (${candidateHtml.length} chars), chart signature missing`, finalUrl: fetchRes.url };
        } catch (fetchErr: any) {
          return {
            url: candidateUrl,
            ok: false,
            detail: fetchErr?.name === 'AbortError'
              ? (timedOut ? `${fetchTimeout/1000}s timeout` : 'cancelled after faster mirror won')
              : String(fetchErr?.cause?.code || fetchErr?.code || fetchErr?.message || 'fetch failed'),
          };
        } finally {
          clearTimeout(timeoutId);
          activeFetchControllers.delete(controller);
        }
      };

      // Start every mirror together, but return as soon as the first valid chart
      // arrives. Promise.all used to keep a successful request waiting for the
      // slowest dead mirror's full timeout.
      // Only overlapping fetches share raw HTML. Complete-result mirror selection
      // has a separate key per target date; every card parses its own mode/cutoff.
      const sharedFetchKey = JSON.stringify([baseName.toUpperCase(), candidateUrls, req.body.resultOnly === true ? backtestDate : null,fetchTimeout]);
      const fetchChart = () => chartSourceFetches.run(sharedFetchKey, async () => {
        const sourceAttempts: SourceAttempt[] = [];
        let successfulSource = await new Promise<SourceAttempt | null>((resolve) => {
          let pending = candidateUrls.length;
          let settled = false;
          for (const candidateUrl of candidateUrls) {
            void fetchCandidate(candidateUrl).then((attempt) => {
              sourceAttempts.push(attempt);
              pending -= 1;
              if (!settled && attempt.ok && attempt.html) {
                settled = true;
                for (const controller of activeFetchControllers) controller.abort();
                resolve(attempt);
              } else if (!settled && pending === 0) {
                settled = true;
                resolve(null);
              }
            });
          }
        });
        if (!successfulSource && req.body.resultOnly === true) {
          // A legitimate partial draw can still settle its known side after all
          // mirrors have been checked for a complete actual.
          const partial=sourceAttempts.filter(attempt=>attempt.html).map(attempt=>({attempt,row:attempt.resultRow}))
            .filter(item=>item.row).sort((a,b)=>Number(Boolean(b.row?.open))+Number(Boolean(b.row?.jodi))+Number(Boolean(b.row?.close))-Number(Boolean(a.row?.open))-Number(Boolean(a.row?.jodi))-Number(Boolean(a.row?.close)))[0];
          if (partial) successfulSource={...partial.attempt,ok:true,resultRow:partial.row};
          else {
            // All mirrors were checked. A readable chart without this date is
            // a missing result, not an outage; don't hide it behind old cache.
            const readable = sourceAttempts.find(attempt => attempt.html);
            if (readable) successfulSource = { ...readable, ok: true };
          }
        }
        return { successfulSource, sourceAttempts };
      });
      let memo: Map<string, any> | undefined = req.rangeChartSnapshots;
      const batchId=String(req.body.scrapeBatchId||'');
      if(!memo&&/^[a-zA-Z0-9_-]{16,100}$/.test(batchId)){
        const now=Date.now();
        for(const [key,batch] of scrapeBatches)if(batch.expiresAt<=now)scrapeBatches.delete(key);
        let batch=scrapeBatches.get(batchId);
        if(req.body.historyTie===true&&req.body.historyDatesOnly!==true&&!batch)return res.status(409).json({status:'error',message:'History snapshot expired or busy; retry Apply'});
        if(req.body.historyTie===true&&batch)batch.expiresAt=now+90000;
        if(!batch){
          if(req.body.historyTie===true){
            if([...scrapeBatches.values()].filter(b=>b.tie).length>=128)return res.status(503).json({status:'error',message:'History snapshot capacity busy; retry Apply'});
          }else{
            const ordinary=[...scrapeBatches].filter(([,b])=>!b.tie);
            while(ordinary.length>=4)scrapeBatches.delete(ordinary.shift()![0]);
          }
          batch={expiresAt:now+90000,bytes:0,tie:req.body.historyTie===true,datedRows:new Map(),counted:new WeakSet(),snapshots:new Map()};scrapeBatches.set(batchId,batch);
        }
        memo=batch.snapshots;
      }
      // Range jobs reuse a frozen raw chart across dates. Result lookup may
      // reuse it only when that exact date has a complete, validated actual.
      if (memo && req.body.resultOnly === true && !memo.has(sharedFetchKey)) {
        const raw = memo.get(JSON.stringify([baseName.toUpperCase(), candidateUrls, null,fetchTimeout]));
        if (raw) {
          const snapshot = await raw;
          const snapshotHtml = snapshot.successfulSource?.html;
          const rows = snapshotHtml ? req.rangeDatedRows?.get(snapshotHtml) || parseDatedActuals(snapshotHtml) : [];
          const actual = rows.find((row: any) => row.date === backtestDate);
          if (actual?.open && actual?.jodi && actual?.close) memo.set(sharedFetchKey, raw);
        }
      }
      const cacheKey = `playmatka-only-v1|${baseName.toUpperCase()}|${String(targetUrl)}`;
      const recentFresh = chartCache[cacheKey];
      const recentFreshAge = Date.now() - Number(recentFresh?.fetchedAt || 0);
      const canUseRecentFresh = Boolean(
        !memo && (selectionMode === 'source_frequency' || selectionMode === 'trend_break' || selectionMode === 'mssd' || selectionMode === 'dynamic_4ank' || selectionMode === 'master_flow_4ank') &&
        recentFresh?.html && recentFreshAge >= 0 && recentFreshAge <= 60_000 &&
        chartMatchesMarket(recentFresh.html, baseName)
      );

      const fetched = canUseRecentFresh
        ? Promise.resolve({
            successfulSource: { html: recentFresh!.html, url: recentFresh!.sourceUrl, finalUrl: recentFresh!.sourceUrl, status: 200 },
            sourceAttempts: [{ ok: true, url: recentFresh!.sourceUrl, finalUrl: recentFresh!.sourceUrl, status: 200, durationMs: 0, detail: 'recent-fresh-cache' }]
          } as any)
        : (memo?.get(sharedFetchKey) || fetchChart());
      if (memo && !memo.has(sharedFetchKey)) memo.set(sharedFetchKey, fetched);
      const { successfulSource, sourceAttempts } = await fetched;
      const batch=scrapeBatches.get(batchId);
      if(batch&&batch.snapshots===memo&&!batch.counted.has(fetched)){
        batch.counted.add(fetched);batch.bytes+=(successfulSource?.html?.length||0)*2;
        while([...scrapeBatches.values()].reduce((sum,item)=>sum+item.bytes,0)>32*1024*1024){
          const disposable=[...scrapeBatches].find(([key,item])=>!item.tie&&key!==batchId);
          if(disposable)scrapeBatches.delete(disposable[0]);
          else{scrapeBatches.delete(batchId);return res.status(503).json({status:'error',message:'History snapshot memory capacity busy; card unchanged'});}
        }
      }
      if (memo?.get(sharedFetchKey)===fetched && !successfulSource) memo.delete(sharedFetchKey);
      // New namespace prevents a previous provider/redirect cache from being reused.
      let html = successfulSource?.html || '';
      let cachedSource: ChartCacheEntry | null = null;
      if (html && successfulSource) {
        if (!fetched.rangeCacheSaved) {
        chartCache[cacheKey] = {
          html,
          fetchedAt: Date.now(),
          sourceUrl: successfulSource.finalUrl || successfulSource.url,
        };
        // O(number of provider URLs), never O(number of saved historical days).
        pruneExpiredChartCache();
        saveChartCache();
        }
        fetched.rangeCacheSaved = true;
      } else {
        const cached = chartCache[cacheKey];
        // Chart history is still useful during a short host outage. Never keep
        // an unlimited stale fallback: after 72 hours report the real failure.
        if (cached?.html && Date.now() - Number(cached.fetchedAt || 0) <= CHART_CACHE_MAX_AGE_MS) {
          html = cached.html;
          cachedSource = cached;
        }
      }
      const lastFailure = [...sourceAttempts].reverse().find((attempt) => !attempt.ok);
      const lastFetchError = lastFailure ? `${lastFailure.url}: ${lastFailure.detail}` : 'No usable source response';

      if (!html) {
        return res.status(502).json({
          status: 'error',
          message: `Chart fetch failed for ${baseName || marketName}. ${lastFetchError || 'No usable source response'}`,
          sourceAttempts,
          retryAfterMs:Math.max(0,...sourceAttempts.map(attempt=>attempt.retryAfterMs||0)),
        });
      }

      const datedRows: Map<string, ReturnType<typeof parseDatedActuals>> | undefined = req.rangeDatedRows || scrapeBatches.get(batchId)?.datedRows;
      const readDatedRows = chartRowsReader(html, datedRows);

      if (isPanelGame && selectionMode === 'recent30_ank5') {
        const date = String(targetDate || businessDateIST(new Date())).trim();
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(Date.parse(date)) || new Date(date).toISOString().slice(0,10) !== date || date > businessDateIST(new Date())) {
          return res.status(400).json({status:'error',message:'Strict SP30: valid current/past target date required'});
        }
        if (panelAnkDigits.length !== 6 || !/\s+(OPEN|CLOSE)$/.test(marketName)) return res.status(400).json({status:'error',message:'Strict SP30 requires exactly 6 ANK and an OPEN/CLOSE market'});
        if (cachedSource) return res.status(422).json({status:'error',staleCache:true,message:'Strict SP30 requires fresh chart; retry when source is available'});
        const side = /CLOSE$/.test(marketName) ? 'close' : 'open';
        const draws = readDatedRows().flatMap(row=>row[side] ? [{date:row.date,panel:row[side]!}] : []);
        const strictPanel30 = selectStrictPanel30(draws, panelAnkDigits, date, side);
        return res.json({status:'success',digits:strictPanel30.panels.join(', '),pannel:strictPanel30.panels.join(', '),strictPanel30,
          sourceMode:'SP_SKIP30',staleCache:false,source:{url:successfulSource?.finalUrl || successfulSource?.url},targetDate:date});
      }

      // Result Test's fetch candidate already parsed the requested exact date.
      // Avoid parsing the entire multi-year chart a second time on this path.
      const backtestRows = safeBacktest && req.body.resultOnly !== true ? readDatedRows() : [];
      if(req.body.historyTie===true&&req.body.historyDatesOnly===true){
        const dates=backtestRows.filter(row=>row.date<=backtestDate&&historyTieActualForGame(row,'ank',marketName)!==undefined).map(row=>row.date);
        return res.json({status:'success',targetDate:backtestDate,market:marketName,gameType,historyDates:dates,historyBatchSize:8,historyRelease:true,staleCache:Boolean(cachedSource)});
      }
      if (req.body.resultOnly === true) {
        // Settlement requires a successfully fetched, market-verified chart.
        // A cached HTML fallback is for browsing only; never mark PASS/FAIL
        // from an offline publisher's stale snapshot.
        if (cachedSource) return res.status(422).json({
          status:'error',staleCache:true,targetDate:backtestDate,
          message:'Fresh exact-date chart unavailable; cached chart cannot settle Result Test. Card unchanged.',
          cacheAgeMinutes:Math.max(0,Math.round((Date.now()-cachedSource.fetchedAt)/60000))
        });
        return res.json({status:'success', actual: successfulSource?.resultRow !== undefined
            ? successfulSource.resultRow : readDatedRows().find(row=>row.date===backtestDate) || null,
          targetDate:backtestDate, sourceUrl:successfulSource?.finalUrl || cachedSource?.sourceUrl,
          staleCache:Boolean(cachedSource),fastResultSource:'direct-chart'});
      }

      if(selectionMode==='source_history_apply'){
        const date=String(targetDate||businessDateIST()).trim(),mode=req.body.frequencySourceMode;
        if(gameType!=='ank'||!/\s+(OPEN|CLOSE)$/.test(marketName)||!isFrequencySourceMode(mode))return res.status(400).json({status:'error',message:'History Apply requires a supported ANK source and OPEN/CLOSE market'});
        if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date||date>businessDateIST())return res.status(400).json({status:'error',message:'History Apply requires a valid current/past date'});
        if(cachedSource)return res.status(422).json({status:'error',staleCache:true,message:'History Apply requires fresh chart; card unchanged'});
        try{
          const sourceHistory=await analyseSourceWindowHistory(safeBacktest?backtestRows:readDatedRows(),date,marketName,mode,String(req.body.expectedSourceDigits||''),async()=>{
            await new Promise<void>(resolve=>setImmediate(resolve));
            if(req.aborted||res.destroyed)throw Error('History Apply cancelled');
          });
          return res.json({status:'success',targetDate:date,sourceHistory,staleCache:false});
        }catch(error:any){return res.status(422).json({status:'error',message:error.message});}
      }

      if(selectionMode==='trend_break'){
        const date=String(targetDate||businessDateIST()).trim(),mode=req.body.frequencySourceMode;
        if(gameType!=='ank'||!/\s+(OPEN|CLOSE)$/.test(marketName)||!isFrequencySourceMode(mode))return res.status(400).json({status:'error',message:'Trend Break: supported ANK source and OPEN/CLOSE required'});
        if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date||date>businessDateIST())return res.status(400).json({status:'error',message:'Trend Break: valid current/past date required'});
        if(cachedSource)return res.status(422).json({status:'error',staleCache:true,message:'Trend Break: fresh history unavailable; card unchanged'});
        try{
          const trendBreak=sourceTrendBreak(safeBacktest?backtestRows:readDatedRows(),date,/CLOSE$/.test(marketName)?'close':'open',mode,String(req.body.currentDigits||''),String(req.body.expectedSourceDigits||''));
          return res.json({status:'success',digits:trendBreak.digits,sourceMode:mode,sourceDigits:{[mode]:trendBreak.sourceDigits},trendBreak,...((trendBreak as any).smartSelection?{smartSelection:(trendBreak as any).smartSelection}:{}),staleCache:false});
        }catch(error:any){return res.status(422).json({status:'error',message:error.message});}
      }

      if (selectionMode === 'source_frequency') {
        const date=String(targetDate||businessDateIST()).trim();
        const mode=req.body.frequencySourceMode;
        if(gameType!=='ank'||!/\s+(OPEN|CLOSE)$/.test(marketName)||!isFrequencySourceMode(mode))return res.status(400).json({status:'error',message:'Smart: supported selected ANK source and OPEN/CLOSE market required'});
        if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date||date>businessDateIST())return res.status(400).json({status:'error',message:'Smart: valid current/past date required'});
        if(cachedSource)return res.status(422).json({status:'error',staleCache:true,message:'Smart: fresh source history unavailable; card unchanged'});
        try{
          const frequencySmart=await selectSmartBehavior(safeBacktest?backtestRows:readDatedRows(),date,/CLOSE$/.test(marketName)?'close':'open',mode,String(req.body.expectedSourceDigits||''),async()=>{
            await new Promise<void>(resolve=>setImmediate(resolve));if(req.aborted||res.destroyed)throw Error('Smart cancelled');
          });
          const smartSelection={decision:frequencySmart.decision,date,digits:frequencySmart.digits,sourceDigits:frequencySmart.sourceDigits,samples:frequencySmart.samples,topHits:frequencySmart.topHits,reverseHits:frequencySmart.reverseHits,digitCount:frequencySmart.digitCount,strongDigits:frequencySmart.strongDigits,supportDigits:frequencySmart.supportDigits,recommendedFilter:frequencySmart.recommendedFilter};
          return res.json({status:'success',market:marketName,gameType,targetDate:date,digits:frequencySmart.digits,smartDigits:frequencySmart.digits,sourceMode:mode,sourceDigits:{[mode]:frequencySmart.sourceDigits},frequencySmart,smartSelection,staleCache:false});
        }catch(error:any){return res.status(422).json({status:'error',...(String(error.message).includes('source differs')?{code:'SMART_SOURCE_CHANGED'}:{}),message:error.message});}
      }

      if(selectionMode==='digit_follow'){
        const date=String(targetDate||businessDateIST()).trim();
        if(gameType!=='ank'||!/\s+(OPEN|CLOSE)$/.test(marketName))return res.status(400).json({status:'error',message:'Digit Follow requires an ANK OPEN/CLOSE market'});
        if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date||date>businessDateIST())return res.status(400).json({status:'error',message:'Digit Follow requires a valid current/past date'});
        if(cachedSource)return res.status(422).json({status:'error',staleCache:true,message:'Digit Follow requires fresh chart; card unchanged'});
        let digitFollow:ReturnType<typeof selectDigitFollow>;
        try{digitFollow=selectDigitFollow(safeBacktest?backtestRows:readDatedRows(),date,/CLOSE$/.test(marketName)?'close':'open');}
        catch(error:any){return res.status(422).json({status:'error',message:error.message});}
        if(!digitFollow.digits)return res.status(422).json({status:'error',message:`Digit Follow: ${digitFollow.reference} ke known next digits nahi mile; card unchanged`,digitFollow});
        return res.json({status:'success',market:marketName,gameType,targetDate:date,digits:digitFollow.digits,sourceMode:'DIGIT_FOLLOW',sourceDigits:{DIGIT_FOLLOW:digitFollow.digits},digitFollow,staleCache:false});
      }

      if(selectionMode==='panna_follow'){
        const date=String(targetDate||businessDateIST()).trim();
        if(gameType!=='ank'||!/\s+(OPEN|CLOSE)$/.test(marketName))return res.status(400).json({status:'error',message:'Panna Follow requires an ANK OPEN/CLOSE market'});
        if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date||date>businessDateIST())return res.status(400).json({status:'error',message:'Panna Follow requires a valid current/past date'});
        if(cachedSource)return res.status(422).json({status:'error',staleCache:true,message:'Panna Follow requires fresh chart; card unchanged'});
        let pannaFollow:ReturnType<typeof selectPannaFollow>;
        try{pannaFollow=selectPannaFollow(safeBacktest?backtestRows:readDatedRows(),date,/CLOSE$/.test(marketName)?'close':'open');}
        catch(error:any){return res.status(422).json({status:'error',message:error.message});}
        if(!pannaFollow.digits)return res.status(422).json({status:'error',message:`Panna Follow: ${pannaFollow.reference} ke known next digits nahi mile; card unchanged`,pannaFollow});
        return res.json({status:'success',market:marketName,gameType,targetDate:date,digits:pannaFollow.digits,sourceMode:'PANNA_FOLLOW',sourceDigits:{PANNA_FOLLOW:pannaFollow.digits},pannaFollow,staleCache:false});
      }

      if (selectionMode === 'pair_follow') {
        const date = String(targetDate || businessDateIST()).trim();
        if (gameType !== 'ank' || !/\s+(OPEN|CLOSE)$/.test(marketName)) return res.status(400).json({status:'error',message:'Pair Follow requires an ANK OPEN/CLOSE market'});
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(Date.parse(date)) || new Date(date).toISOString().slice(0,10)!==date || date>businessDateIST()) return res.status(400).json({status:'error',message:'Pair Follow requires a valid current/past date'});
        if (cachedSource) return res.status(422).json({status:'error',staleCache:true,message:'Pair Follow requires fresh chart; card unchanged'});
        let pairFollow: ReturnType<typeof selectPairFollow>;
        try { pairFollow = selectPairFollow(safeBacktest ? backtestRows : readDatedRows(),date,/CLOSE$/.test(marketName)?'close':'open'); }
        catch (error:any) { return res.status(422).json({status:'error',message:error.message}); }
        if (!pairFollow.digits) return res.status(422).json({status:'error',message:`Pair Follow: ${pairFollow.basePair} ke historical next-draw digits nahi mile; card unchanged`,pairFollow});
        return res.json({status:'success',market:marketName,gameType,targetDate:date,digits:pairFollow.digits,sourceMode:'PAIR_FOLLOW',sourceDigits:{PAIR_FOLLOW:pairFollow.digits},pairFollow,staleCache:false});
      }

      if (selectionMode === 'pair_combo') {
        const date = String(targetDate || businessDateIST()).trim();
        if (gameType !== 'ank' || !/\s+(OPEN|CLOSE)$/.test(marketName)) return res.status(400).json({status:'error',message:'Pair Combo requires an ANK OPEN/CLOSE market'});
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(Date.parse(date)) || new Date(date).toISOString().slice(0,10)!==date || date>businessDateIST()) return res.status(400).json({status:'error',message:'Pair Combo requires a valid current/past date'});
        if (cachedSource) return res.status(422).json({status:'error',staleCache:true,message:'Pair Combo requires fresh chart; card unchanged'});
        let pairCombo: ReturnType<typeof selectPairCombo>;
        try { pairCombo = selectPairCombo(safeBacktest ? backtestRows : readDatedRows(),date,/CLOSE$/.test(marketName)?'close':'open'); }
        catch (error:any) { return res.status(422).json({status:'error',message:error.message}); }
        if (!pairCombo.digits) return res.status(422).json({status:'error',message:`Pair Combo: ${pairCombo.basePair} ke historical next-draw combo digits nahi mile; card unchanged`,pairCombo});
        return res.json({status:'success',market:marketName,gameType,targetDate:date,digits:pairCombo.digits,sourceMode:'PAIR_COMBO',sourceDigits:{PAIR_COMBO:pairCombo.digits},pairCombo,staleCache:false});
      }

      /**
       * Panel chart table format:
       *   date | openPanna | jodi | closePanna | openPanna | jodi | closePanna | ...
       * Panna can be "335" OR spaced "2 6 7" (→ 267). Jodi is "54" / "00". "***" = missing.
       */
      const toPanna = (cell: string): string | null => {
        const s = String(cell || '').replace(/\*/g, '').trim();
        if (!s || /^-+$/.test(s)) return null;
        // "2 6 7" or "2-6-7" → 267
        const spaced = s.match(/^(\d)\s*[-\s]\s*(\d)\s*[-\s]\s*(\d)$/);
        if (spaced) return `${spaced[1]}${spaced[2]}${spaced[3]}`;
        const digits = s.replace(/\D/g, '');
        if (/^\d{3}$/.test(digits)) return digits;
        return null;
      };
      const toJodi = (cell: string): string | null => {
        const s = String(cell || '').replace(/\*/g, '').trim();
        if (!s) return null;
        const digits = s.replace(/\D/g, '');
        if (/^\d{2}$/.test(digits)) return digits;
        if (/^\d$/.test(digits)) return digits.padStart(2, '0');
        return null;
      };

      const jodis: string[] = [];
      const pannels: string[] = [];
      const openPanelsOnly: string[] = [];
      const closePanelsOnly: string[] = [];
      const rawParsed=fetched.tieRawParsed?.html===html?fetched.tieRawParsed:undefined;
      if(rawParsed){
        jodis.push(...rawParsed.jodis);pannels.push(...rawParsed.pannels);
        openPanelsOnly.push(...rawParsed.open);closePanelsOnly.push(...rawParsed.close);
      }else{
      const replaceParsedIfBetter = (candidateJodis: string[], candidateOpen: string[], candidateClose: string[]) => {
        if (candidateJodis.length <= jodis.length || candidateOpen.length + candidateClose.length < candidateJodis.length * 2) return;
        jodis.splice(0, jodis.length, ...candidateJodis);
        openPanelsOnly.splice(0, openPanelsOnly.length, ...candidateOpen);
        closePanelsOnly.splice(0, closePanelsOnly.length, ...candidateClose);
        pannels.splice(0, pannels.length, ...candidateOpen.flatMap((open, index) => {
          const close = candidateClose[index];
          return close ? [open, close] : [open];
        }));
      };

      // 1) Primary: parse the chart as a flat cell stream segmented by date.
      // Several live chart pages have malformed/unclosed <tr>/<th> markup.
      // A <tr>-based parser then swallows multiple weeks into one row and
      // starts treating date labels as open/jodi/close cells, which returns
      // stale or shifted scraping results. Date boundaries are stable, so use
      // them as the authoritative row delimiters instead.
      const pchartMatch = html.match(/<table\b[^>]*class=["'][^"']*\bpchart\b[^"']*["'][^>]*>[\s\S]*?<\/table>/i);
      const chartHtml = pchartMatch ? pchartMatch[0] : html;
      const chartCells = [...chartHtml.matchAll(/<t[dh]\b[^>]*>([\s\S]*?)<\/t[dh]>/gi)].map((m) =>
        m[1]
          .replace(/<br\s*\/?>(?=\s|$)/gi, ' ')
          .replace(/<[^>]+>/g, ' ')
          .replace(/\s+/g, ' ')
          .trim()
      );
      const isDateRangeCell = (cell: string) =>
        /\d{1,2}\s*[\/\-]\s*\d{1,2}\s*[\/\-]\s*\d{2,4}\s*(?:to|[-–—])\s*\d{1,2}\s*[\/\-]\s*\d{1,2}\s*[\/\-]\s*\d{2,4}/i.test(cell);
      const dateIndexes = chartCells
        .map((cell, index) => isDateRangeCell(cell) ? index : -1)
        .filter((index) => index >= 0);
      for (let d = 0; d < dateIndexes.length; d++) {
        const start = dateIndexes[d] + 1;
        const end = d + 1 < dateIndexes.length ? dateIndexes[d + 1] : chartCells.length;
        const rowCells = chartCells.slice(start, end);
        // Each chart week is Date + repeated Open Panna / Jodi / Close Panna.
        for (let i = 0; i + 2 < rowCells.length; i += 3) {
          const openP = toPanna(rowCells[i]);
          const j = toJodi(rowCells[i + 1]);
          const closeP = toPanna(rowCells[i + 2]);
          if (openP) {
            pannels.push(openP);
            openPanelsOnly.push(openP);
          }
          if (j) jodis.push(j);
          if (closeP) {
            pannels.push(closeP);
            closePanelsOnly.push(closeP);
          }
        }
      }

      // Layout fallback: some mirrors changed date-range rows to individual
      // dates while retaining Open Panna / Jodi / Close Panna cells. Scan each
      // real table row for a valid consecutive result triple instead of
      // rejecting the whole page because the date label format changed.
      if (jodis.length < 5 || pannels.length < 5) {
        const rowJodis: string[] = [];
        const rowOpen: string[] = [];
        const rowClose: string[] = [];
        const rows = [...chartHtml.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)];
        for (const row of rows) {
          const cells = [...row[1].matchAll(/<t[dh]\b[^>]*>([\s\S]*?)<\/t[dh]>/gi)].map((m) =>
            m[1].replace(/<br\s*\/?\s*>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;|&#160;/gi, ' ').replace(/\s+/g, ' ').trim()
          );
          for (let i = 0; i + 2 < cells.length; i++) {
            const openP = toPanna(cells[i]);
            const j = toJodi(cells[i + 1]);
            const closeP = toPanna(cells[i + 2]);
            if (!openP || !j || !closeP) continue;
            rowOpen.push(openP);
            rowClose.push(closeP);
            rowJodis.push(j);
            i += 2;
          }
        }
        replaceParsedIfBetter(rowJodis, rowOpen, rowClose);
      }

      // 2) Fallback: classic 123-45-678 in stripped text
      const clean = html.replace(/<br\s*\/?\s*>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;|&#160;/gi, ' ').replace(/\s+/g, ' ');
      if (jodis.length < 5 || pannels.length < 5) {
        const textJodis: string[] = [];
        const textOpen: string[] = [];
        const textClose: string[] = [];
        const fullRe =
          /\*{0,2}(\d{3})\*{0,2}\s*[-:–—/]\s*\*{0,2}(\d{1,2})\*{0,2}\s*[-:–—/]\s*\*{0,2}(\d{3})\*{0,2}/g;
        let mFull: RegExpExecArray | null;
        while ((mFull = fullRe.exec(clean)) !== null) {
          textJodis.push(mFull[2].padStart(2, '0'));
          textOpen.push(mFull[1]);
          textClose.push(mFull[3]);
        }
        // Spaced panna triplets embedded: "2 6 7 54 3 4 5"
        const spacedTrip = /(\d)\s+(\d)\s+(\d)\s+(\d{2})\s+(\d)\s+(\d)\s+(\d)/g;
        while ((mFull = spacedTrip.exec(clean)) !== null) {
          const op = `${mFull[1]}${mFull[2]}${mFull[3]}`;
          const jd = mFull[4];
          const cp = `${mFull[5]}${mFull[6]}${mFull[7]}`;
          textOpen.push(op);
          textClose.push(cp);
          textJodis.push(jd);
        }
        replaceParsedIfBetter(textJodis, textOpen, textClose);
      }

      if (jodis.length === 0 && pannels.length === 0) {
        return res.status(400).json({
          status: 'error',
          message: 'Page pe koi jodi/panel data nahi mila',
        });
      }

        fetched.tieRawParsed={html,jodis:[...jodis],pannels:[...pannels],open:[...openPanelsOnly],close:[...closePanelsOnly]};
      }

      if (safeBacktest) {
        const history = backtestRows.filter(row=>row.date < backtestDate);
        jodis.splice(0,jodis.length,...history.flatMap(row=>row.jodi ? [row.jodi] : []));
        openPanelsOnly.splice(0,openPanelsOnly.length,...history.flatMap(row=>row.open ? [row.open] : []));
        closePanelsOnly.splice(0,closePanelsOnly.length,...history.flatMap(row=>row.close ? [row.close] : []));
        pannels.splice(0,pannels.length,...history.flatMap(row=>[row.open,row.close].filter((v):v is string=>Boolean(v))));
        if (!jodis.length && !pannels.length) return res.status(422).json({status:'error',...(req.body.historyTie===true?{code:'HISTORY_NO_PRIOR_DATA',targetDate:backtestDate}:{}),message:'Chosen date se pehle trustworthy dated history nahi mili'});
      }
      // latest first
      const recentToOld = [...jodis].reverse();
      const isCloseMkt = /CLOSE/i.test(marketName);
      const isOpenMkt = /OPEN/i.test(marketName);
      const isAnkGame = !isPanelGame && gameType !== 'jodi';
      const dayComboMode = isAnkGame && selectionMode === 'same_weekday_vertical_combo';
      const mssdMode = isAnkGame && selectionMode === 'mssd';
      const freq10SkipRecentMode = isAnkGame && selectionMode === 'freq_10_skip_recent';
      const freq10ComboSkipRecentMode = isAnkGame && selectionMode === 'freq_10_combo_skip_recent';
      const selfLearningInductiveMode = isAnkGame && (selectionMode === 'self_learning_inductive' || req.body.mode === 'SELF_LEARNING');
      const dynamic4AnkMode = isAnkGame && (selectionMode === 'dynamic_4ank' || selectionMode === 'master_flow_4ank');
      const weekdayVerticalMode = isAnkGame && (selectionMode === 'same_weekday_vertical' || dayComboMode || mssdMode);
      const preTargetRecentMode = isAnkGame && (selectionMode === 'pre_target_recent' || freq10SkipRecentMode || freq10ComboSkipRecentMode || selfLearningInductiveMode);
      const carry6Mode = isAnkGame && selectionMode === 'carry6';
      const marketBehaviorMode = isAnkGame && selectionMode === 'market_behavior';
      // Cached history may omit new outcomes. Never present it as a fresh Model selection.
      // Other scraper modes keep their existing outage fallback.
      if ((marketBehaviorMode || carry6Mode) && cachedSource) {
        return res.status(422).json({ status: 'error', staleCache: true,
          message: `${carry6Mode ? 'Carry6' : 'Market Model'}: fresh chart fetch failed; cached chart se prediction apply nahi hua. Existing card unchanged rahega.`,
          cacheAgeMinutes: Math.max(0, Math.round((Date.now() - cachedSource.fetchedAt) / 60_000)) });
      }
      const dateCutoffMode = weekdayVerticalMode || preTargetRecentMode || marketBehaviorMode || carry6Mode || mssdMode || dynamic4AnkMode;
      const liveBusinessDate = businessDateIST(new Date());
      const requestedCutoffDate = String(targetDate || liveBusinessDate).trim();
      const requestedDateValue = new Date(`${requestedCutoffDate}T00:00:00Z`);
      const validRequestedDate = /^\d{4}-\d{2}-\d{2}$/.test(requestedCutoffDate)
        && !Number.isNaN(requestedDateValue.getTime())
        && requestedDateValue.toISOString().slice(0, 10) === requestedCutoffDate;
      if (dateCutoffMode && (!validRequestedDate || requestedCutoffDate > liveBusinessDate)) {
        return res.status(400).json({
          status: 'error',
          message: !validRequestedDate
            ? 'Backtest target date invalid hai'
            : `Future date ${requestedCutoffDate} ka backtest allowed nahi hai`,
        });
      }

      // Historical Recent→Old/Combo uses exactly the same anti-leak boundary as
      // the Day-column backtest: selected date itself and future rows are hidden.
      // Live/current-date requests never enter this branch, preserving business flow.
      const cutoffChart = dateCutoffMode ? (safeBacktest ? {
        draws:backtestRows.flatMap((row,order)=>row.jodi ? [{date:row.date,jodi:row.jodi,order}] : []),
      } : parseSmartJodiChart(html, requestedCutoffDate, preTargetRecentMode || carry6Mode || mssdMode || dynamic4AnkMode)) : null;
      let preTargetRecentJodis = preTargetRecentMode
        ? selectPreTargetRecentJodis(cutoffChart?.draws || [], requestedCutoffDate)
        : [];
      if (
        preTargetRecentJodis.length === 0 &&
        (freq10SkipRecentMode || freq10ComboSkipRecentMode || selfLearningInductiveMode) &&
        !safeBacktest &&
        requestedCutoffDate === liveBusinessDate &&
        recentToOld.length > 0
      ) {
        preTargetRecentJodis = recentToOld;
      }
      if (preTargetRecentMode && preTargetRecentJodis.length === 0 && !selfLearningInductiveMode) {
        return res.status(422).json({
          status: 'error',
          message: `${requestedCutoffDate} se pehle dated Jodi history nahi mili`,
        });
      }
      const ankRecentToOld = preTargetRecentMode && preTargetRecentJodis.length > 0 ? preTargetRecentJodis : recentToOld;
      const ankChronologicalJodis = preTargetRecentMode && preTargetRecentJodis.length > 0 ? [...preTargetRecentJodis].reverse() : jodis;
      const fullOpenAnkHistory = ankRecentToOld.map((jodi) => jodi[0]).filter(Boolean);
      const fullCloseAnkHistory = ankRecentToOld.map((jodi) => jodi[1]).filter(Boolean);
      // A Jodi is declared OPEN then CLOSE; in newest-first history CLOSE must
      // precede OPEN or Markov learns the transition direction backwards.
      const fullCombinedAnkHistory = ankRecentToOld.flatMap((jodi) => [jodi[1], jodi[0]]).filter(Boolean);
      const ankHistory = comboMode
        ? fullCombinedAnkHistory
        : isCloseMkt ? fullCloseAnkHistory : fullOpenAnkHistory;
      const weekdayVerticalDate = weekdayVerticalMode ? requestedCutoffDate : liveBusinessDate;
      const weekdayVerticalSide = dayComboMode ? 'combo' : isCloseMkt ? 'close' : 'open';
      const weekdayVertical = weekdayVerticalMode
        ? dayComboMode
          ? selectSameWeekdayVerticalComboDigits(cutoffChart?.draws || [], weekdayVerticalDate,60,req.body.historyTie!==true)
          : selectSameWeekdayVerticalDigits(
            cutoffChart?.draws || [],
            weekdayVerticalDate,
            isCloseMkt ? 'close' : 'open',60,req.body.historyTie!==true,
          )
        : null;
      if (weekdayVerticalMode && !weekdayVertical) {
        const weekdayName = new Date(`${weekdayVerticalDate}T00:00:00Z`).toLocaleDateString('en-US', { weekday: 'long', timeZone: 'UTC' });
        return res.status(422).json({
          status: 'error',
          ...(req.body.historyTie===true?{code:'HISTORY_SOURCE_INCOMPLETE',targetDate:backtestDate}:{}),
          message: `${weekdayVerticalSide.toUpperCase()} ${weekdayName} column me eligible historical digits nahi mile`,
        });
      }
      // Tie consumes only this source's ten ordered digits and exact actual.
      // Do not run unrelated adaptive strategy backtests for every historical date.
      if(req.body.historyTie===true&&smartMode!==true&&isAnkGame&&(preTargetRecentMode||weekdayVerticalMode)){
        const mode=dayComboMode?'DAY_COMBO':weekdayVerticalMode?'WEEKDAY':comboMode?'COMBO':'AUTO';
        const digits=weekdayVertical?weekdayVertical.digits.join(', '):comboMode?getCombinedDigitsRecentToOld(ankChronologicalJodis):selectRecentUniqueDigits(isCloseMkt?fullCloseAnkHistory:fullOpenAnkHistory).join(', ');
        if(digits.split(/[,|\s]+/).filter(Boolean).length!==10)return res.status(422).json({status:'error',code:'HISTORY_SOURCE_INCOMPLETE',targetDate:backtestDate,message:`${backtestDate}: chosen date se pehle source digits nahi mile; card unchanged`,availableDigits:digits});
        return res.json({status:'success',market:marketName,gameType,isCombo:comboMode,targetDate:backtestDate,actual:backtestRows.find(row=>row.date===backtestDate)||null,digits,sourceMode:mode,sourceDigits:{[mode]:digits},staleCache:Boolean(cachedSource)});
      }
      if (selfLearningInductiveMode) {
        const sameDayOpenRaw = req.body.sameDayOpenActual;
        const batchUsed = Array.isArray(req.body.usedBatchTetrads)
          ? new Set<string>(req.body.usedBatchTetrads.map(String))
          : new Set<string>();
        const auto10Digits = selectRecentUniqueDigits(isCloseMkt ? fullCloseAnkHistory : fullOpenAnkHistory).join(', ');
        const recentDatedDraws = (cutoffChart?.draws || [])
          .filter(row => row.date && row.date < requestedCutoffDate && /^\d{2}$/.test(String(row.jodi || '')))
          .slice(-15)
          .map(row => ({ date: row.date, jodi: String(row.jodi) }));
        const inductive = discoverChartInductiveRules({
          marketName,
          chronologicalJodis: ankChronologicalJodis,
          sameDayOpenActual: sameDayOpenRaw !== undefined ? sameDayOpenRaw : null,
          date: requestedCutoffDate,
          existingBatchPredictions: batchUsed,
        });
        return res.json({
          status: 'success',
          market: marketName,
          gameType,
          targetDate: requestedCutoffDate,
          digits: auto10Digits || inductive.recommended4Ank,
          sourceMode: 'SELF_LEARNING',
          sourceDigits: {
            AUTO: auto10Digits,
            SELF_LEARNING: auto10Digits || inductive.recommended4Ank,
          },
          recentDatedDraws,
          actual: safeBacktest ? backtestRows.find(row => row.date === backtestDate) || null : undefined,
          inductiveLearning: inductive,
          total: ankChronologicalJodis.length,
          staleCache: Boolean(cachedSource),
        });
      }
      if (freq10ComboSkipRecentMode) {
        try {
          const freq10Combo = selectTenDayComboSkipRecentFrequency(ankRecentToOld, 6, marketName);
          return res.json({
            status: 'success',
            market: marketName,
            gameType,
            targetDate: requestedCutoffDate,
            digits: freq10Combo.digits,
            sourceMode: 'FREQ_10_COMBO',
            sourceDigits: { FREQ_10_COMBO: freq10Combo.rankedDigits },
            freq10: freq10Combo,
            actual: safeBacktest ? backtestRows.find(row => row.date === backtestDate) || null : undefined,
            staleCache: Boolean(cachedSource),
          });
        } catch (error: any) {
          return res.status(422).json({ status: 'error', message: error?.message || '10-Day Combo Freq unavailable' });
        }
      }
      if (freq10SkipRecentMode) {
        const sideStream = isCloseMkt ? fullCloseAnkHistory : fullOpenAnkHistory;
        try {
          const freq10 = selectTenDrawSkipRecentFrequency(sideStream, 6);
          return res.json({
            status: 'success',
            market: marketName,
            gameType,
            targetDate: requestedCutoffDate,
            digits: freq10.digits,
            sourceMode: 'FREQ_10',
            sourceDigits: { FREQ_10: freq10.rankedDigits },
            freq10,
            actual: safeBacktest ? backtestRows.find(row => row.date === backtestDate) || null : undefined,
            staleCache: Boolean(cachedSource),
          });
        } catch (error: any) {
          return res.status(422).json({ status: 'error', message: error?.message || '10-Draw Freq unavailable' });
        }
      }
      if (carry6Mode) {
        const draws = cutoffChart?.draws || [];
        const recent = selectPreTargetRecentJodis(draws, requestedCutoffDate);
        const sourceDigits = {
          AUTO: selectRecentUniqueDigits(recent.map(j => j[isCloseMkt ? 1 : 0])).join(', '),
          WEEKDAY: selectSameWeekdayVerticalDigits(draws, requestedCutoffDate, isCloseMkt ? 'close' : 'open')?.digits.join(', ') || '',
          COMBO: getCombinedDigitsRecentToOld([...recent].reverse()),
          DAY_COMBO: selectSameWeekdayVerticalComboDigits(draws, requestedCutoffDate)?.digits.join(', ') || '',
        };
        if (Object.values(sourceDigits).some(value => new Set(value.split(/[,|\s]+/).filter(Boolean)).size !== 10)) {
          return res.status(422).json({status:'error',message:'Carry6: all four original ten-digit sources unavailable; card unchanged'});
        }
        return res.json({status:'success',market:marketName,gameType,targetDate:requestedCutoffDate,sourceDigits,staleCache:false,...(safeBacktest?{actual:backtestRows.find(row=>row.date===backtestDate)||null}:{})});
      }
      const marketBehaviorChart = marketBehaviorMode ? parseSmartJodiChart(html, requestedCutoffDate) : null;
      const marketModel = marketBehaviorMode
        ? buildMarketBehaviorPrediction(marketBehaviorChart?.draws || [], marketName, isCloseMkt ? 'close' : 'open', requestedCutoffDate)
        : null;
      if (marketBehaviorMode && !marketModel) {
        return res.status(422).json({ status: 'error', message: 'Market Model: target date se pehle minimum 30 valid dated results chahiye. Existing card unchanged rahega.' });
      }
      if (marketBehaviorMode && marketModel!.freshness.calendarGapDays > 7) {
        return res.status(422).json({ status: 'error',
          message: `Market Model: latest valid result ${marketModel!.lastTrainingDate} hai (${marketModel!.freshness.calendarGapDays} days before target). Latest chart verify karein; existing card unchanged rahega.` });
      }
      // Opt-in ordinary source response. Legacy/Smart/Panel/Jodi callers retain full aliases.
      if(req.body.sourceOnly===true&&isAnkGame&&smartMode!==true&&!req.body.resultOnly&&!req.body.historyTie&&
        (!selectionMode||preTargetRecentMode||weekdayVerticalMode)){
        const open=selectRecentUniqueDigits(fullOpenAnkHistory).join(', ');
        const close=selectRecentUniqueDigits(fullCloseAnkHistory).join(', ');
        const combined=getCombinedDigitsRecentToOld(ankChronologicalJodis);
        const digits=weekdayVertical?weekdayVertical.digits.join(', '):comboMode?combined:isCloseMkt?close:open;
        if((preTargetRecentMode||weekdayVerticalMode)&&!digits)return res.status(422).json({status:'error',message:`${requestedCutoffDate}: chosen date se pehle source digits nahi mile; card unchanged`,availableDigits:digits});
        const recentDatedDraws = (cutoffChart?.draws || backtestRows || [])
          .filter((row: any) => row?.date && row.date < requestedCutoffDate && /^\d{2}$/.test(String(row.jodi || '')))
          .slice(-15)
          .map((row: any) => ({ date: String(row.date), jodi: String(row.jodi) }));
        return res.json({status:'success',market:marketName,gameType,isCombo:comboMode,digits,open,close,combined,lastJodi:ankRecentToOld[0]||null,lastOpenPanel:openPanelsOnly[openPanelsOnly.length-1]||null,lastClosePanel:closePanelsOnly[closePanelsOnly.length-1]||null,
          actual:safeBacktest?backtestRows.find(row=>row.date===backtestDate)||null:undefined,
          targetDate:safeBacktest?backtestDate:undefined,
          recentDatedDraws,
          sourceDigits:{AUTO:digits,SELF_LEARNING:digits,WEEKDAY:!dayComboMode?weekdayVertical?.digits.join(', '):undefined,
            DAY_COMBO:dayComboMode?weekdayVertical?.digits.join(', '):undefined,COMBO:combined},
          weekdayVertical:weekdayVertical||undefined,total:jodis.length,
          source:cachedSource?{url:cachedSource.sourceUrl,ok:true,detail:'cached chart fallback',cached:true,fetchedAt:cachedSource.fetchedAt}:
            successfulSource?{url:successfulSource.url,ok:true,detail:successfulSource.detail,finalUrl:successfulSource.finalUrl}:null,
          staleCache:Boolean(cachedSource),cacheAgeMinutes:cachedSource?Math.max(0,Math.round((Date.now()-cachedSource.fetchedAt)/60000)):0});
      }
      const ankStrategy = isAnkGame ? buildDynamicAnkPrediction(ankHistory) : null;
      const adaptiveAnkDigits = ankStrategy?.digits.join(', ') || '';
      let smartWeekday = null;
      if (smartMode === true && isAnkGame) {
        const today = new Intl.DateTimeFormat('en-GB', {
          timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit',
        }).formatToParts(new Date());
        const datePart = (part: string) => today.find((item) => item.type === part)?.value || '';
        const businessToday = `${datePart('year')}-${datePart('month')}-${datePart('day')}`;
        const chart = parseSmartJodiChart(html, businessToday);
        const requestedSide = isCloseMkt ? 'close' : 'open';
        const selection = selectSmartAnkEnsemble(safeBacktest ? jodis : chart.jodis, requestedSide);
        if (!selection) {
          return res.status(422).json({ status: 'error', message: `Smart SKIP: ${requestedSide.toUpperCase()} recent 10/20/30 me 2-method convergence nahi mili (jodi ${chart.jodis.length}, max window 30)` });
        }
        smartWeekday = { ...selection, open: requestedSide === 'open' ? selection.digits : [],
          close: requestedSide === 'close' ? selection.digits : [], chartJodis: chart.jodis.length, datedJodis: chart.draws.length,
          skippedDateRows: chart.skippedDateRows, duplicateRows: chart.duplicateRows };
      }

      // Use last ~60 results for ranking (enough signal, not too noisy)
      const windowJodis = (isAnkGame ? ankRecentToOld : recentToOld).slice(0, 60);

      const openDigitsRecent = windowJodis.map((j) => j[0]);
      const closeDigitsRecent = windowJodis.map((j) => j[1]);
      const allAnkRecent = windowJodis.flatMap((j) => [j[0], j[1]]);

      // Frequency+recency ranked (smart auto)
      const rankedOpen = rankByFrequencyRecency(openDigitsRecent, 10);
      const rankedClose = rankByFrequencyRecency(closeDigitsRecent, 10);
      const rankedAnk = rankByFrequencyRecency(allAnkRecent, 10);
      const rankedJodi = rankByFrequencyRecency(windowJodis, 10);

      // Legacy sequential unique (backward compatible)
      // Normal Scrape contract: recent-to-old, first-seen unique digits only.
      // Do not use frequency or Markov ranking for this path.
      const seqOpen = selectRecentUniqueDigits(fullOpenAnkHistory).join(', ');
      const seqClose = selectRecentUniqueDigits(fullCloseAnkHistory).join(', ');

      const seenJ = new Set<string>();
      const recentJodis: string[] = [];
      for (const j of recentToOld) {
        if (!seenJ.has(j)) {
          seenJ.add(j);
          recentJodis.push(j);
        }
        if (recentJodis.length === 30) break; // 30 unique jodi pairs
      }
      const seqJodi = recentJodis.join(', ');
      const seqCombined = getCombinedDigitsRecentToOld(ankChronologicalJodis);

      // Panel source: OPEN card → open panna only; CLOSE → close panna; else both
      let panelSource = pannels;
      if (isCloseMkt) panelSource = closePanelsOnly;
      else if (isOpenMkt) panelSource = openPanelsOnly;

      const recentPanelsToOld = [...panelSource].reverse(); // chart rows newest→oldest
      const normalizedPanelHistory = recentPanelsToOld
        .map((p) => normalizePanelPatti(p))
        .filter((p): p is string => Boolean(p));
      const isLowPanelMode = isPanelGame && selectionMode === 'low_frequency_30';
      // OPEN/CLOSE Panel arrays are parsed in the same chronological order as
      // their Jodi cells. This lets LOW PANEL use the same weekday + latest-Jodi
      // successor evidence as Smart ANK while ranking only the low side.
      const sidePanelsChronological = isCloseMkt ? closePanelsOnly : openPanelsOnly;
      const lowBusinessDate = safeBacktest ? backtestDate : businessDateIST(new Date());
      const lowWeekday = new Date(`${lowBusinessDate}T00:00:00Z`).getUTCDay();
      const lowChart = isLowPanelMode ? parseSmartJodiChart(html, lowBusinessDate) : null;
      const weekdayPanelHistory = isLowPanelMode
        ? sidePanelsChronological.filter((_, index) => lowChart?.draws[index]?.weekday === lowWeekday)
        : [];
      const latestJodi = jodis[jodis.length - 1] || '';
      const successorPanelHistory: string[] = [];
      if (isLowPanelMode && latestJodi) {
        for (let index = 0; index + 1 < jodis.length; index++) {
          if (jodis[index] === latestJodi && sidePanelsChronological[index + 1]) {
            successorPanelHistory.push(sidePanelsChronological[index + 1]);
          }
        }
      }
      const lowPanelSelection = isLowPanelMode
        ? selectLowFrequencyPanels(normalizedPanelHistory, panelAnkDigits, {
            weekdayHistory: weekdayPanelHistory,
            successorHistory: successorPanelHistory,
            limit: 30,
          })
        : null;
      if (lowPanelSelection && !lowPanelSelection.complete) {
        return res.status(422).json({
          status: 'error',
          message: `LOW PANEL 30 ke liye minimum 3 distinct ANK chahiye (${lowPanelSelection.panels.length}/30 valid Patti available)`,
          lowPanelSelection,
        });
      }
      const panelPrediction = isLowPanelMode
        ? null
        : isPanelGame ? buildDynamicPanelPrediction(normalizedPanelHistory, panelAnkDigits) : null;
      const panelStrategy = panelPrediction?.strategy || null;
      // Single Panel selection authority. All Panel response aliases below use
      // this exact list; Smart/Markov/Rare cannot produce competing Pattis.
      const authoritativePanels = lowPanelSelection?.panels || panelPrediction?.panels || [];
      const panelDigits = authoritativePanels.join(', ');

      // Preserve the existing Jodi response alias for non-Smart callers.
      const rankedJodi30 = rankByFrequencyRecency(windowJodis, 30);
      const smartJodi = rankedJodi30.slice(0, 30).join(', ');

      /**
       * First-order Markov ranking.
       * score(next) = P(next|last)*2 + visit-weighted transition mass + light freq prior
       * Returns up to `limit` unique states, filled from frequency if chain is sparse.
       */
      const markovRank = (sequence: string[], limit: number): string[] => {
        if (!sequence.length) return [];
        const counts = new Map<string, Map<string, number>>(); // from -> (to -> n)
        const visit = new Map<string, number>();
        for (let i = 0; i < sequence.length - 1; i++) {
          const a = sequence[i];
          const b = sequence[i + 1];
          if (!a || !b) continue;
          visit.set(a, (visit.get(a) || 0) + 1);
          if (!counts.has(a)) counts.set(a, new Map());
          const row = counts.get(a)!;
          row.set(b, (row.get(b) || 0) + 1);
        }
        // last state also counts as visit
        const last = sequence[0]; // recent-first array
        if (sequence[sequence.length - 1]) {
          const oldest = sequence[sequence.length - 1];
          visit.set(oldest, (visit.get(oldest) || 0) + 0); // no-op keep types
        }
        visit.set(last, (visit.get(last) || 0) + 1);

        const score = new Map<string, number>();
        const add = (k: string, v: number) => score.set(k, (score.get(k) || 0) + v);

        // From last observed (most recent) state
        const lastRow = counts.get(last);
        if (lastRow) {
          let rowSum = 0;
          lastRow.forEach((n) => { rowSum += n; });
          if (rowSum > 0) {
            lastRow.forEach((n, to) => add(to, (n / rowSum) * 3));
          }
        }

        // Visit-weighted transitions (stationary-ish signal)
        counts.forEach((row, from) => {
          let rowSum = 0;
          row.forEach((n) => { rowSum += n; });
          if (rowSum === 0) return;
          const w = visit.get(from) || 1;
          row.forEach((n, to) => add(to, (n / rowSum) * (w / sequence.length)));
        });

        // Frequency prior so we always fill limit
        const freq = new Map<string, number>();
        sequence.forEach((s, idx) => {
          const recency = 1 + (sequence.length - idx) / sequence.length;
          freq.set(s, (freq.get(s) || 0) + recency);
        });
        freq.forEach((v, k) => add(k, v * 0.15));

        // Exclude staying forever on last only if we have alternatives — keep last if strong
        const ranked = Array.from(score.entries())
          .sort((a, b) => b[1] - a[1])
          .map(([k]) => k);

        // Fill from pure frequency if short
        for (const s of sequence) {
          if (ranked.length >= limit) break;
          if (!ranked.includes(s)) ranked.push(s);
        }
        return ranked.slice(0, limit);
      };

      // Sequences are recent-first already (windowJodis)
      const jodiSeq = windowJodis;

      // Jodi retains its independent pair-transition selector. ANK and Panel
      // each have one adaptive authority above.
      const markovJodi = markovRank(jodiSeq, 36).join(', ');

      // Strict by game type — Panel must NEVER fall back to 2-digit jodi
      let targetDigits = seqOpen;
      let smartDigits = adaptiveAnkDigits;
      let markovDigits = adaptiveAnkDigits;
      if (gameType === 'jodi') {
        targetDigits = seqJodi;
        smartDigits = smartJodi;
        markovDigits = markovJodi;
      } else if (gameType === 'pannel' || gameType === 'panel') {
        targetDigits = panelDigits;
        // Keep stable response fields for old clients, but never calculate a
        // second Panel list: every alias points to the one authority.
        smartDigits = panelDigits;
        markovDigits = panelDigits;
        if (!targetDigits) {
          return res.status(400).json({
            status: 'error',
            message: 'Panel chart se 3-digit panna nahi mila (2-digit jodi return nahi karenge)',
          });
        }
      } else {
        // Explicit ANK contracts:
        // - Normal Auto Scrape keeps recent-to-old unique chart digits (up to 10).
        // - Smart/Markov aliases use the adaptive six-digit backend selection.
        targetDigits = weekdayVertical
          ? weekdayVertical.digits.join(', ')
          : comboMode
            ? seqCombined
            : isCloseMkt ? seqClose : seqOpen;
        smartDigits = adaptiveAnkDigits;
        markovDigits = adaptiveAnkDigits;
        if (smartWeekday) smartDigits = (/CLOSE/i.test(marketName) ? smartWeekday.close : smartWeekday.open).join(', ');
      }

      // Safety filter by type
      const filterTokens = (s: string, pred: (x: string) => boolean) =>
        String(s || '')
          .split(/[, ]+/)
          .map((x) => x.trim())
          .filter(pred)
          .join(', ');
      if (gameType === 'jodi') {
        targetDigits = filterTokens(targetDigits, (x) => /^\d{2}$/.test(x));
        smartDigits = filterTokens(smartDigits, (x) => /^\d{2}$/.test(x));
        markovDigits = filterTokens(markovDigits, (x) => /^\d{2}$/.test(x));
      } else if (gameType === 'pannel' || gameType === 'panel') {
        targetDigits = filterPanelsByAnkDigits(targetDigits, panelAnkDigits);
        smartDigits = filterPanelsByAnkDigits(smartDigits, panelAnkDigits);
        markovDigits = filterPanelsByAnkDigits(markovDigits, panelAnkDigits);
        if (!targetDigits && !smartDigits && !markovDigits) {
          return res.status(422).json({
            status: 'error',
            message: `Chart me selected ANK (${panelAnkDigits.join(',')}) ke sum wali Patti nahi mili`,
          });
        }
      } else {
        targetDigits = filterTokens(targetDigits, (x) => /^\d$/.test(x));
        smartDigits = filterTokens(smartDigits, (x) => /^\d$/.test(x));
        markovDigits = filterTokens(markovDigits, (x) => /^\d$/.test(x));
      }

      if (isAnkGame && smartMode !== true && !marketBehaviorMode && (preTargetRecentMode || weekdayVerticalMode) && targetDigits.split(/[,|\s]+/).filter(Boolean).length === 0) {
        return res.status(422).json({status:'error',...(req.body.historyTie===true?{code:'HISTORY_SOURCE_INCOMPLETE',targetDate:backtestDate}:{}),message:`${requestedCutoffDate}: chosen date se pehle source digits nahi mile; card unchanged`,availableDigits:targetDigits});
      }

      if (dynamic4AnkMode) {
        const rawDated = safeBacktest ? backtestRows : readDatedRows();
        const smartDated = (cutoffChart?.draws || []).map(d => ({
          date: d.date,
          jodi: d.jodi,
          open: d.jodi?.[0],
          close: d.jodi?.[1],
        }));
        const validRaw = rawDated.filter(r => r.date && r.date < requestedCutoffDate);
        const validSmart = smartDated.filter(r => r.date && r.date < requestedCutoffDate);
        const mergedRows = validRaw.length >= 5
          ? rawDated
          : validSmart.length >= 5
            ? smartDated
            : ankChronologicalJodis.map((j, idx) => ({
                date: new Date(Date.parse(`${requestedCutoffDate}T00:00:00Z`) - (ankChronologicalJodis.length - idx) * 86400000).toISOString().slice(0, 10),
                jodi: j,
                open: j[0],
                close: j[1],
              }));
        let dynamic4: ReturnType<typeof selectDynamic4AnkFromChart>;
        try {
          dynamic4 = selectDynamic4AnkFromChart(
            mergedRows,
            requestedCutoffDate,
            isCloseMkt ? 'close' : 'open',
            req.body.sameDayOpenDigit,
          );
        } catch (error: any) {
          return res.status(422).json({ status: 'error', message: error.message });
        }
        return res.json({
          status: 'success',
          market: marketName,
          gameType,
          targetDate: safeBacktest ? backtestDate : requestedCutoffDate,
          digits: dynamic4.digits,
          open: isCloseMkt ? undefined : dynamic4.digits,
          close: isCloseMkt ? dynamic4.digits : undefined,
          sourceMode: 'FLOW_3_1',
          sourceDigits: {
            FLOW_3_1: dynamic4.digits,
            AUTO: isCloseMkt ? seqClose : seqOpen,
            WEEKDAY: weekdayVertical?.digits.join(', ') || '',
            COMBO: seqCombined,
          },
          masterFlow: dynamic4,
          actual: (safeBacktest || requestedCutoffDate < liveBusinessDate) ? (rawDated.find(row => row.date === (safeBacktest ? backtestDate : requestedCutoffDate)) || null) : undefined,
          staleCache: Boolean(cachedSource),
        });
      }

      if (mssdMode) {
        const draws = cutoffChart?.draws || [];
        const recent = selectPreTargetRecentJodis(draws, requestedCutoffDate);
        const side: 'open' | 'close' = isCloseMkt ? 'close' : 'open';
        const autoSrc = (recent.length ? selectRecentUniqueDigits(recent.map(j => j[isCloseMkt ? 1 : 0])).join(', ') : '') || (isCloseMkt ? seqClose : seqOpen);
        const daySrc = selectSameWeekdayVerticalDigits(draws, requestedCutoffDate, side, 60, true)?.digits.join(', ') || weekdayVertical?.digits.join(', ') || '';
        const comboSrc = (recent.length ? getCombinedDigitsRecentToOld([...recent].reverse()) : '') || seqCombined;
        const dayComboSrc = selectSameWeekdayVerticalComboDigits(draws, requestedCutoffDate, 60, true)?.digits.join(', ') || '';

        const safeStream = (mode: 'AUTO' | 'WEEKDAY' | 'COMBO' | 'DAY_COMBO') => {
          try { return sourceObservationWindow(draws, requestedCutoffDate, side, mode); }
          catch { return []; }
        };
        const autoSsd = computeSourceSsdFromStream(safeStream('AUTO'), autoSrc);
        const daySsd = computeSourceSsdFromStream(safeStream('WEEKDAY'), daySrc);
        const comboSsd = computeSourceSsdFromStream(safeStream('COMBO'), comboSrc);
        const dayComboSsd = computeSourceSsdFromStream(safeStream('DAY_COMBO'), dayComboSrc);

        const stage1List = mergeUniqueMssdDigits(autoSsd);
        const stage2List = mergeUniqueMssdDigits(stage1List, daySsd);
        const stage3List = mergeUniqueMssdDigits(stage2List, comboSsd);
        const stage4List = mergeUniqueMssdDigits(stage3List, dayComboSsd);
        const stageDigits = {
          1: stage1List.join(', '),
          2: stage2List.join(', '),
          3: stage3List.join(', '),
          4: stage4List.join(', '),
        };
        const requestedStage = [1, 2, 3, 4].includes(Number(req.body.mssdStage))
          ? (Number(req.body.mssdStage) as 1 | 2 | 3 | 4)
          : 1;
        const mssdDigits = stageDigits[requestedStage];
        const mssdTokens = mssdDigits.split(/[,|\s]+/).filter(Boolean);
        return res.json({
          status: 'success',
          market: marketName,
          gameType,
          targetDate: safeBacktest ? backtestDate : requestedCutoffDate,
          digits: mssdDigits,
          sourceMode: 'MSSD',
          sourceDigits: {
            MSSD: mssdDigits,
            AUTO: autoSrc,
            WEEKDAY: daySrc,
            COMBO: comboSrc,
            DAY_COMBO: dayComboSrc,
          },
          mssd: {
            stage: requestedStage,
            autoSsd,
            daySsd,
            comboSsd,
            dayComboSsd,
            ssdByMode: {
              AUTO: autoSsd,
              WEEKDAY: daySsd,
              COMBO: comboSsd,
              DAY_COMBO: dayComboSsd,
            },
            stageDigits,
            digits: mssdDigits,
            count: mssdTokens.length,
          },
          staleCache: Boolean(cachedSource),
        });
      }

      res.json({
        status: "success",
        market: marketName,
        actual: safeBacktest ? backtestRows.find(row => row.date === backtestDate) || null : undefined,
        targetDate: safeBacktest ? backtestDate : undefined,
        recentDatedDraws: isAnkGame
          ? ((cutoffChart?.draws || (safeBacktest ? backtestRows : parseSmartJodiChart(html, requestedCutoffDate, true).draws) || []) as any[])
              .filter(row => row?.date && row.date < requestedCutoffDate && /^\d{2}$/.test(String(row.jodi || '')))
              .slice(-15)
              .map(row => ({ date: String(row.date), jodi: String(row.jodi) }))
          : undefined,
        gameType,
        isCombo: comboMode,
        digits: marketBehaviorMode ? marketModel!.digits.join(', ') : targetDigits,
        sourceDigits: isAnkGame ? {
          AUTO: targetDigits,
          SELF_LEARNING: targetDigits,
          WEEKDAY: !dayComboMode ? weekdayVertical?.digits.join(', ') : undefined,
          DAY_COMBO: dayComboMode ? weekdayVertical?.digits.join(', ') : undefined,
          COMBO: seqCombined,
          SMART: smartWeekday?.sourceDigits.join(', ') || (ankStrategy ? selectAnkDigits(ankHistory, ankStrategy.mode, 10).join(', ') : undefined),
          MARKOV: ankStrategy ? selectAnkDigits(ankHistory, ankStrategy.mode, 10).join(', ') : undefined,
          MARKET_MODEL: marketModel?.sourceDigits.join(', '),
        } : undefined,
        modelDigits: marketModel?.digits.join(', '),
        marketModel: marketModel || undefined,
        smartDigits,
        smartWeekday: smartWeekday || undefined,
        markovDigits,
        open: seqOpen,
        close: seqClose,
        combined: seqCombined,
        jodi: seqJodi,
        pannel: panelDigits,
        panelSelectionMode: isLowPanelMode ? 'single_patti_low_frequency_30' : isPanelGame ? 'single_patti_gap_rotation' : undefined,
        panelCooldown: isPanelGame && !isLowPanelMode ? 10 : undefined,
        lowPanelSelection: lowPanelSelection || undefined,
        panelStrategy: panelStrategy || undefined,
        dynamicPrediction: isPanelGame ? panelPrediction || undefined : ankStrategy || undefined,
        weekdayVertical: weekdayVertical || undefined,
        ankStrategy: ankStrategy || undefined,
        ranked: {
          open: rankedOpen,
          close: rankedClose,
          ank: rankedAnk,
          jodi: rankedJodi,
          panel: authoritativePanels,
        },
        markovMeta: {
          ankCount: 6,
          jodiCount: 36,
          panelCount: authoritativePanels.length,
          lastOpen: fullOpenAnkHistory[0] || null,
          lastClose: fullCloseAnkHistory[0] || null,
          lastJodi: jodiSeq[0] || null,
        },
        total: jodis.length,
        lastJodi: jodiSeq[0] || null,
        lastOpenPanel: openPanelsOnly[openPanelsOnly.length - 1] || null,
        lastClosePanel: closePanelsOnly[closePanelsOnly.length - 1] || null,
        source: cachedSource
          ? { url: cachedSource.sourceUrl, ok: true, detail: 'cached chart fallback', cached: true, fetchedAt: cachedSource.fetchedAt }
          : successfulSource
            ? {
                url: successfulSource.url,
                ok: true,
                detail: successfulSource.detail,
                finalUrl: successfulSource.finalUrl,
              }
            : null,
        staleCache: Boolean(cachedSource),
        cacheAgeMinutes: cachedSource ? Math.max(0, Math.round((Date.now() - cachedSource.fetchedAt) / 60_000)) : 0,
      });
    } catch (err: any) {
      res.status(500).json({ status: "error", message: `Error: ${err.message || 'Scraping failed'}` });
    }
  };
  app.post("/api/scrape_market", scrapeMarketHandler);

  // Auto Parse Market from Chart / WebScraper URL
  app.post("/api/parse_market_url", async (req, res) => {
    try {
      const { url } = req.body;
      if (!url || typeof url !== 'string') {
        return res.status(400).json({ status: 'error', message: 'Valid URL is required' });
      }

      let cleanUrl = url.trim();
      if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
        cleanUrl = 'https://' + cleanUrl;
      }

      if(!isChartProviderUrl(cleanUrl))return res.status(400).json({status:'error',message:'Use a playmatka.live panel-chart URL. Other providers are disabled.'});
      // SRIDEVI DAY is a different publisher chart and must never be added
      // as SRIDEVI through URL auto-detection.
      if (new URL(cleanUrl).pathname.replace(/\/+$/, '').toLowerCase() === '/panel-chart/sridevi-day') {
        return res.status(400).json({ status: 'error', message: 'Use /panel-chart/sridevi for SRIDEVI, not the separate SRIDEVI DAY chart.' });
      }
      // Home pages are not market charts. Never create a fake CUSTOM MARKET from one.
      if(new URL(cleanUrl).pathname.replace(/\/+$/,'') === '')return res.status(400).json({status:'error',message:'Paste a specific market chart page, not the website home page.'});

      let extractedTitle = '';
      let extractedBody = '';

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);
      try {
        const fetchRes = await safeChartFetch(cleanUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          },
          signal: controller.signal,
        }, process.env.TITAN_TEST_ALLOW_LOOPBACK === '1', undefined, process.env.TITAN_TEST_ALLOW_LOOPBACK === '1' ? undefined : CHART_PROVIDER_HOSTS);

        if (fetchRes.ok) {
          const html = await readChartBody(fetchRes, 64 * 1024);
          const titleMatch = html.match(/<title>(.*?)<\/title>/i);
          if (titleMatch) extractedTitle = titleMatch[1];
          const h1Match = html.match(/<h1[^>]*>(.*?)<\/h1>/i);
          if (h1Match) extractedTitle += ' ' + h1Match[1];
          extractedBody = html.substring(0, 5000);
        } else await fetchRes.body?.cancel();
      } catch (e) {
        if (e instanceof ChartDestinationError) return res.status(400).json({ status: 'error', message: e.message });
        // Network failures retain the existing URL-name fallback.
      } finally { clearTimeout(timeoutId); }

      let rawText = (extractedTitle + ' ' + cleanUrl).toUpperCase();
      rawText = rawText
        .replace(/RECORD|PANEL|PENAL|CHART|SATTA|MATKA|PLAYMATKA|DPBOSS|MOBi|COM|NET|ORG|HTTPS|HTTP|WWW|PHP|HTML|\.PHP|\.HTML/gi, ' ')
        .replace(/[-_/\.]+/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();

      const commonMarkets = [
        "SRIDEVI NIGHT", "SRIDEVI", "TIME BAZAR", "MADHUR DAY", "MILAN DAY", "RAJDHANI DAY",
        "SUPREME DAY", "KALYAN NIGHT", "KALYAN", "MADHUR NIGHT", "SUPREME NIGHT",
        "MILAN NIGHT", "RAJDHANI NIGHT", "MAIN BAZAR", "GALI", "DISAWAR", "STARLINE"
      ]; // Check longer NIGHT names before short DAY names to prevent cross-market matches

      let detectedBaseName = "";
      for (const m of commonMarkets) {
        if (rawText.includes(m)) {
          detectedBaseName = m;
          break;
        }
      }

      if (!detectedBaseName) {
        try {
          const parsedObj = new URL(cleanUrl);
          let pathSlug = parsedObj.pathname.split('/').pop() || '';
          pathSlug = pathSlug.replace(/penal|panel|chart|record|\.php|\.html/gi, '').replace(/[-_]/g, ' ').trim().toUpperCase();
          detectedBaseName = pathSlug || "CUSTOM MARKET";
        } catch {
          detectedBaseName = "CUSTOM MARKET";
        }
      }

      let openHr = 15;
      let openMin = 0;
      let closeHr = 17;
      let closeMin = 0;

      // Free-form HTML includes timestamps and malformed fragments. Never persist
      // an out-of-range schedule after an auto-detect button click.
      const timeMatches = validChartClockTimes(extractedBody);
      if (timeMatches.length >= 2) {
        openHr = timeMatches[0].hr;
        openMin = timeMatches[0].min;
        closeHr = timeMatches[1].hr;
        closeMin = timeMatches[1].min;
      } else {
        if (detectedBaseName.includes("NIGHT") || detectedBaseName.includes("MAIN")) {
          openHr = 21; openMin = 30;
          closeHr = 23; closeMin = 35;
        } else if (detectedBaseName.includes("DAY") || detectedBaseName.includes("BAZAR")) {
          openHr = 13; openMin = 15;
          closeHr = 15; closeMin = 15;
        } else {
          openHr = 15; openMin = 50;
          closeHr = 17; closeMin = 50;
        }
      }

      res.json({
        status: "success",
        url: cleanUrl,
        baseName: detectedBaseName,
        openMarket: {
          n: `${detectedBaseName} OPEN`,
          hr: openHr,
          min: openMin,
          scrapeUrl: cleanUrl,
          isCustom: true
        },
        closeMarket: {
          n: `${detectedBaseName} CLOSE`,
          hr: closeHr,
          min: closeMin,
          scrapeUrl: cleanUrl,
          isCustom: true
        }
      });
    } catch (err: any) {
      res.status(500).json({ status: "error", message: err.message || "Parsing URL failed" });
    }
  });

  // --- TERMUX BAILEYS WHATSAPP BOT API ENDPOINTS ---
  let botState = {
    autoSendEnabled: true,
    autoResultForwardEnabled: true,
    profitMilestoneNotificationsEnabled: false,
    loginMethod: 'pairing', // 'pairing' | 'qr'
    loginPhone: '',
    botPhone: '',
    status: 'offline', // 'online' | 'offline' | 'pairing'
    logoutRequested: false,
    /** Bot should wipe session and pair with current loginPhone */
    forceRelogin: false,
    lastHeartbeat: null as string | null,
    targetGroups: [] as string[],
    resultReadGroups: [] as string[], // Selected Group/Channel sources to read incoming results from
    syncedGroups: [] as Array<{ jid: string; name: string; size?: number }>,
    syncedChannels: [] as Array<{ jid: string; name: string }>,
    syncedContacts: [] as Array<{ jid: string; name: string; phone?: string }>,
    pendingChannelInvites: [] as Array<{ id: string; invite: string }>,
    lastSyncTime: null as string | null,
    /** Current per-profile card-type auto-broadcast policy from dashboard. */
    schedulePolicy: {} as Record<string, { ank?: boolean; jodi?: boolean; pannel?: boolean }>,
    activeSchedules: [] as Array<{
      cardGeneration?: number;
      key: string;
      marketName: string;
      type: string;
      schTime: string;
      schTargets: string[];
      message: string;
      digits: string;
      sourceMode?: CardSourceMode;
      scrapeSource?: ScrapeSource;
      sentScrapeSource?: ScrapeSource;
      scrapeResultDigit?: string;
      manualResult?: string;
      trick?: 'T1' | 'T2' | 'T3';
      invest: string;
      date: string;
      profileId?: string;
      index?: number;
      rateNum?: number;
      investTotal?: number;
      recoveryWaitSince?: number;
    }>,
    prefix: '.',
    customHeader: '🚀 TITAN NOVA AUTOMATED INTEL',
    pairingCode: '',
    qrCodeData: '',
    logs: [
      { id: '1', time: new Date().toLocaleTimeString(), msg: 'Server bot endpoints initialized. Awaiting Termux connection...', type: 'info' }
    ],
    sentSchedules: {} as Record<string, boolean>, // stable: date_type_idx_HH:mm
    scheduleClaims: {} as Record<string, number>, // soft mutex while bot is sending
    pendingAuditResults: [] as Array<{
      id: string;
      text: string;
      time: string;
      processed: boolean;
      stage?: 'OPEN_ONLY' | 'FULL' | 'CLOSE_ONLY' | 'UNKNOWN';
      mergeKey?: string;
      signature?: string;
      awaitingFull?: boolean;
      partialText?: string;
      fullText?: string;
      serverMarked?: boolean;
      serverMarkedCount?: number;
      /** Only these original delivery attempts may resume after their ACK. */
      deferredCards?: Record<string, { marketName: string; digits: string; dispatchKey: string }>;
    }>,
    pendingBroadcasts: [] as Array<{
      cardGeneration?: number;
      id: string;
      message: string;
      broadcastLink?: string;
      broadcastPng?: string;
      broadcastDesign?: number;
      senderFormat?: string;
      senderFormats?: {whatsapp:'text'|'png';telegram:'text'|'png'};
      digitSupport?: Record<string,'Strong'|'Support'|'SupportLow'>;
      targets: string[];
      createdAt: string;
      status: 'pending' | 'sent' | 'failed';
      scheduleKey?: string;
      dedupeKey?: string;
      profileId?: string;
      cardType?: string;
      broadcastKind?: string;
      profitDate?: string;
      profitMilestone?: number;
      index?: number;
      digits?: string;
      sourceMode?: CardSourceMode;
      scrapeSource?: ScrapeSource;
      sentScrapeSource?: ScrapeSource;
      scrapeResultDigit?: string;
      manualResult?: string;
      trick?: 'T1' | 'T2' | 'T3';
      rateNum?: number;
      investTotal?: number;
      schTime?: string;
      schTargets?: string[];
      marketName?: string;
      resultDigit?: string | null;
      fullResult?: string;
      priority?: number;
      /** Runtime-only live transport session binding. Never persisted. */
      platformSessions?: Partial<Record<Transport, string>>;
      /** Runtime-only transport retry gate inside the same live session. */
      platformNotBefore?: Partial<Record<Transport, number>>;
      targetNotBefore?: Record<string, number>;
      /** Runtime-only in-flight claim. Cleared on ack/defer. */
      claimedPlatforms?: Partial<Record<Transport, number>>;
      claimTokens?: Partial<Record<Transport, string>>;
      /** Exact target batch handed to each transport claim. */
      claimedTargets?: Partial<Record<Transport, string[]>>;
      /** Targets permanently unavailable inside this live delivery attempt. */
      failedTargets?: string[];
    }>,
    /** `${scheduleKey}||${jid}` → Baileys message key for quote-reply */
    scheduleMsgKeys: {} as Record<string, any>,
    /**
     * Compact ledger snapshot from dashboard (so PASS/FAIL + WA reply work even when browser closed).
     * Synced via POST /api/bot/sync_ledger
     */
    ledgerState: {
      date: '' as string,
      updatedAt: 0 as number,
      profiles: {} as Record<
        string,
        {
          name: string;
          phone: string;
          deliveryMode?: 'private' | 'group' | 'channel';
          deliveryTargets?: string[];
          deliveryTargetName?: string;
          vipAutoMode?: boolean;
          vipGameRuns?: VipGameRuns;
          schedulePolicy?: { ank?: boolean; jodi?: boolean; pannel?: boolean };
          detailedMessage?: boolean;
          targetProfit?: { ank?: number; jodi?: number; pannel?: number };
          splitMode?: { ank?: boolean; pannel?: boolean };
          twoCardRecoveryVersion?: 2;
          twoCardRecoveryLegacySplit?: {ank:boolean;pannel:boolean};
          loopConfig?: DualLoopConfig;
          loopAccountStops?: LoopAccountStops;
          openToCloseCut?: boolean;
          autoCarryResultSix?: boolean;
          autoResultParity?: boolean;
          liveThreeFailReset?: boolean;
          /** Server-owned recovery debt keyed by e.g. ank:OPEN, ank:CLOSE, ank:ALL, jodi:ALL. */
          recoveryState?: Record<string, { debt: number; pendingProfit?: number; fromCardKey?: string; fromIndex?: number; updatedAt?: number; consecutiveFails?:number; cyclesClosed?:number; lastResetCardKey?:string; lastResetDebt?:number }>;
          markets: Array<{ n: string; type: string; index: number; enabled?: boolean; hr?: number; min?: number }>;
          cards: Record<
            string,
            {
              s: import('./src/types').MarketStatus;
              smartStaking?: any;
              sourceEditedAt?: number;
              twoCardRecoveryShares?: import('./src/utils/twoCardRecovery').RecoveryShare[];
              twoCardRecoveryStrategy?: 'TWO'|'ALL';
              vipAutoStopSkipped?: boolean;
              vipAutoStopResumeEligible?: boolean;
              d: string;
              r: string;
              /** Original digit source before Trick 1/2/3 transformation. */
              od?: string;
              /** Active Trick tag for the current digit source. */
              trick?: 'T1' | 'T2' | 'T3';
              weekdaySelectedDigits?: string;
              weekdayHitPosition?: number;
              /** Persisted selection logic for next-day guidance. */
              sourceMode?: CardSourceMode;
              loopId?: LoopId;
              sentLoopId?: LoopId;
              liveCombinedCut?:DayMarketRecord['liveCombinedCut'];
              scrapeSource?: ScrapeSource;
              sentScrapeSource?: ScrapeSource;
              scrapeResultDigit?: string;
      manualResult?: string;
              mirroredFromAdmin?: boolean;
              marketName?: string;
              sentRate?: string;
              sentInvest?: number;
              sentDigits?: string;
              sentSourceMode?: CardSourceMode;
              sentTrick?: 'T1' | 'T2' | 'T3';
              /** Targets that actually received this play; used for partial-delivery result follow-up. */
              sentTargets?: string[];
              recRate?: string;
              deliveryRestoredAt?: number;
              cardGeneration?: number;
              manualStatus?: boolean;
              manualPanelResult?: string;
              manualResultSources?: string[];
              manualRate?: boolean;
              manualOverrideAt?: number;
              prevLoss?: number;
              targetProfitWithLoss?: number;
              schTime?: string;
              schTargets?: string[];
              dispatchState?: 'QUEUED' | 'SENT' | 'SENT_PARTIAL' | 'SETTLED';
              dispatchKey?: string;
              queuedAt?: number;
              sentAt?: number;
              settledAt?: number;
              /** JODI recovery is decided as soon as its OPEN ank is published. */
              jodiOpenStatus?: 'PASS' | 'FAIL';
              jodiOpenResult?: string;
              jodiOpenSettledAt?: number;
              /** Card was not fully delivered to its real-time live targets. */
              deliveryMissedAt?: number;
              deliveryMissedReason?: string;
              deliveryPartial?: boolean;
              rateFinalizedFrom?: string;
              rateFinalizedAt?: number;
            }
          >; // key = `${type}_${index}`
        }
      >,
    },
    /** Dedupe result follow-up broadcasts server-side (persisted — survives restart / dashboard reopen) */
    resultFollowUpSent: {} as Record<string, boolean>,
    activeProfileIds: [] as string[],
    deletedProfileIds: [] as string[],
    explicitlyDeletedProfileIds: [] as string[],
  };

  // Single source of truth for card-type broadcast policy. Missing policy keys default to ON
  // for backward compatibility; an explicit false is the only OFF state.
  const isCardTypeEnabled = (profileId: string, cardType: string): boolean => {
    if (isDeletedProfile(profileId)) return false;
    const t = String(cardType || '').toLowerCase();
    if (!['ank', 'jodi', 'pannel'].includes(t)) return true;
    // BUG FIX: Persisted per-profile ledger policy wins over volatile legacy memory.
    const policy = botState.ledgerState?.profiles?.[String(profileId || '')]?.schedulePolicy
      || botState.schedulePolicy[String(profileId || '')];
    return !policy || (policy as any)[t] !== false;
  };

  // Open Pass -> Close Zero schedule hold:
  // When openPassCloseZero toggle is ON for a profile (Admin or VIP), any CLOSE card
  // (ank / pannel) must be HELD while its matching OPEN card is still WAIT/SENT
  // (waiting for OPEN result) OR if its matching OPEN card already PASSED (skip CLOSE).
  // Once OPEN settles as FAIL or SKIP, the CLOSE card releases and runs normally.
  // All other normal cards (OPEN, JODI, or non-matching markets) continue unaffected.
  const isCloseBlockedByOpenPassZero = (
    profileId: string,
    cardType: string,
    marketName: string,
    savedProfile?: any
  ): boolean => {
    const t = String(cardType || '').toLowerCase();
    if (t !== 'ank' && t !== 'pannel') return false;
    const mUpper = String(marketName || '').trim().toUpperCase();
    if (!/\s+CLOSE$/i.test(mUpper)) return false;

    const pid = String(profileId || 'admin1');
    const runtimeProf = botState.ledgerState?.profiles?.[pid];
    const savedProf = savedProfile || readFullAppStateView()?.profiles?.[pid];
    const isToggleOn = Boolean(
      runtimeProf?.openPassCloseZero === true ||
      runtimeProf?.config?.openPassCloseZero === true ||
      savedProf?.openPassCloseZero === true ||
      savedProf?.config?.openPassCloseZero === true
    );
    if (!isToggleOn) return false;

    const baseMarket = mUpper.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
    const openName = `${baseMarket} OPEN`;
    const marketsList = Array.isArray(runtimeProf?.markets) ? runtimeProf.markets : [];
    const cardsMap = runtimeProf?.cards || {};

    const openMarket = marketsList.find(
      (m: any) => String(m?.type || '').toLowerCase() === t && String(m?.n || '').trim().toUpperCase() === openName
    );
    const todayDate = String(botState.ledgerState?.date || calculateBusinessDateIST());
    const dictName = t === 'ank' ? 'data' : 'pannelData';
    const savedDict = savedProf?.dayRecords?.[todayDate]?.[dictName] || {};
    const openCard = (openMarket
      ? cardsMap[`${t}_${openMarket.index}`]
      : Object.entries(cardsMap).find(([k, c]: [string, any]) =>
          k.startsWith(`${t}_`) && String(c?.marketName || '').trim().toUpperCase() === openName
        )?.[1])
      || (openMarket ? savedDict[openMarket.index] : Object.values(savedDict).find((c: any) => String(c?.marketName || '').trim().toUpperCase() === openName));

    if (!openCard) return false;
    const openStatus = String(openCard.s || 'WAIT').toUpperCase();
    // Hold/Skip CLOSE if OPEN is PASS, or still WAIT/SENT (not yet FAIL/SKIP)
    return openStatus !== 'FAIL' && openStatus !== 'SKIP';
  };

  // All runtime JSON under titan_data/ so Vite never watches them (prevents auto page reload)
  const resultFollowUpFile = path.join(titanDataDir, 'titan_result_followups.json');
  const ledgerSnapshotFile = path.join(titanDataDir, 'titan_ledger_snapshot.json');
  const fullAppStateFile = path.join(titanDataDir, 'titan_app_state.json');
  const deletedProfilesFile = path.join(titanDataDir, 'titan_deleted_profiles.json');
  const explicitlyDeletedProfilesFile = path.join(titanDataDir, 'titan_explicitly_deleted_profiles.json');
  const pendingBroadcastsFile = path.join(titanDataDir, 'titan_pending_broadcasts.json');
  const expiredBroadcastKeysFile = path.join(titanDataDir, 'titan_expired_broadcast_keys.json');
  const profitMilestonesFile = path.join(titanDataDir, 'titan_profit_milestones.json');
  const receiptsFile = path.join(titanDataDir, 'titan_transport_receipts.json');
  const knownChannelsFile = path.join(titanDataDir, 'titan_known_channels.json');
  try {
    if (fs.existsSync(knownChannelsFile)) {
      const rawChannels = JSON.parse(fs.readFileSync(knownChannelsFile, 'utf-8'));
      if (Array.isArray(rawChannels)) {
        botState.syncedChannels = rawChannels
          .map((ch: any) => {
            const jid = normalizeTargetJid(ch?.jid, 'channel');
            return jid ? { jid, name: String(ch?.name || jid) } : null;
          })
          .filter((ch: any): ch is { jid: string; name: string } => Boolean(ch));
      }
    }
  } catch (_) {}
  const persistKnownChannels = () => {
    try {
      atomicWriteFile(knownChannelsFile, JSON.stringify(botState.syncedChannels || []), 'known-channels');
    } catch (_) {}
  };
  let expiredBroadcastKeys: Record<string, boolean> = {};
  let profitMilestones: Record<string, number> = {};
  let transportReceipts: Record<string, string[]> = {};
  try { transportReceipts = JSON.parse(fs.readFileSync(receiptsFile, 'utf8')); } catch (_) {}
  const requestPlatform = (req: any): Transport => req.query?.platform === 'telegram' || req.body?.platform === 'telegram' ? 'telegram' : 'whatsapp';
  type LiveTransportState = { online: boolean; sessionId: string; startedAt: number; lastSeen: number };
  const liveTransports: Record<Transport, LiveTransportState> = {
    whatsapp: { online: false, sessionId: '', startedAt: 0, lastSeen: 0 },
    telegram: { online: false, sessionId: '', startedAt: 0, lastSeen: 0 },
  };
  const liveQueueClock=new LiveQueueFreshnessClock();
  // Scope only synchronous work. Async handlers release this frame at their
  // first await; interval-driven audit/queue passes establish their own frame.
  app.use((_req,_res,next)=>{liveQueueClock.run(()=>next());});
  const liveTransportUsable = (platform: Transport): boolean => {
    const state = liveTransports[platform];
    if (!state.online || !state.sessionId || !state.startedAt) return false;
    if (platform === 'whatsapp' && liveQueueClock.current() - state.lastSeen > 45_000) return false;
    return true;
  };
  const bindLiveBroadcastTargets = (targets: unknown): { targets: string[]; sessions: Partial<Record<Transport, string>> } => {
    const normalized = normalizeTargetList(targets);
    const sessions: Partial<Record<Transport, string>> = {};
    const live: string[] = [];
    for (const platform of ['whatsapp', 'telegram'] as Transport[]) {
      if (!liveTransportUsable(platform)) continue;
      const platformTargets = transportTargets(normalized, platform);
      if (!platformTargets.length) continue;
      live.push(...platformTargets);
      sessions[platform] = liveTransports[platform].sessionId;
    }
    return { targets: [...new Set(live)], sessions };
  };
  const remainingTargets = (key: string, targets: string[], platform: Transport) => transportTargets(targets, platform)
    .filter(t => !(transportReceipts[key] || []).includes(t));
  const recordDelivery = (key: string, targets: string[], expected: string[]) => {
    transportReceipts[key] = [...new Set([...(transportReceipts[key] || []), ...normalizeTargetList(targets)])];
    atomicWriteFile(receiptsFile, JSON.stringify(transportReceipts), 'transport-receipts', true);
    return allDelivered(expected, transportReceipts[key]);
  };

  /**
   * Full dashboard state shared by localhost + Cloudflare.
   * Browser localStorage is only a cache; this file is the cross-origin source of truth.
   */
  const activityRecorder = new ActivityRecorder(titanDataDir);
  activityRecorder.pruneOlderThan(30);
  const fullStateReader=new FullStateReader(fullAppStateFile);
  const readFullAppState=(strict=false):any|null=>fullStateReader.read(strict);
  const readFullAppStateView=(strict=false):any|null=>fullStateReader.view(strict);
  const bulkOperationReceipts=new BulkOperationReceipts(readFullAppState()?.bulkOperationReceipts);
  let fullAppStateRevision = 0;
  let pendingAppStateDiskJson: string | null = null;
  let appStateDiskFlushRunning = false;
  const flushAppStateToDiskAsync = async () => {
    if (appStateDiskFlushRunning) return;
    appStateDiskFlushRunning = true;
    try {
      while (pendingAppStateDiskJson !== null) {
        const jsonToWrite = pendingAppStateDiskJson;
        pendingAppStateDiskJson = null;
        const temp = `${fullAppStateFile}.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2)}.tmp`;
        try {
          await fs.promises.mkdir(path.dirname(fullAppStateFile), { recursive: true });
          await fs.promises.writeFile(temp, jsonToWrite, 'utf-8');
          await fs.promises.rename(temp, fullAppStateFile);
          if (pendingAppStateDiskJson === null) fullStateReader.markDiskSynced();
        } catch (err) {
          try { await fs.promises.unlink(temp); } catch (_) {}
          console.error('[persist:app-state-async]', err);
        }
      }
    } finally {
      appStateDiskFlushRunning = false;
      if (pendingAppStateDiskJson !== null) void flushAppStateToDiskAsync();
    }
  };
  const writeFullAppState = (state: any, asyncDisk = true) => {
    if (!state || typeof state !== 'object' || !state.profiles) {
      throw new Error('invalid app state');
    }
    // Do not replace an unreadable existing archive with defaults or stale cache.
    fullStateReader.validate(true);
    const nextState = {...state,bulkOperationReceipts:bulkOperationReceipts.snapshot()};
    const payloadJson = JSON.stringify({ updatedAt: Date.now(), state: nextState });
    if (asyncDisk) {
      fullStateReader.primeMemory(payloadJson, nextState);
      pendingAppStateDiskJson = payloadJson;
      void flushAppStateToDiskAsync();
    } else if (atomicWriteFile(fullAppStateFile, payloadJson, 'app-state', true)) {
      pendingAppStateDiskJson = null;
      fullStateReader.prime(payloadJson, nextState);
    }
    fullAppStateRevision++;
  };
  // Upgrade saved custom ON/OFF intent before serving the first browser read.
  // This does not modify cards, outcomes, stakes or daily financial stops.
  const priorCustomState=readFullAppState();
  if(priorCustomState?.profiles){
    const profiles={...priorCustomState.profiles};let changed=false;
    for(const [pid,profile] of Object.entries(profiles) as [string,any][]){
      if(!profile?.config||!profile?.dayRecords)continue;
      const migrated=migrateCustomLoopSettings(profile);
      if(migrated!==profile){profiles[pid]=migrated;changed=true;}
    }
    if(changed)writeFullAppState({...priorCustomState,profiles});
  }
  const suppliedProfileToken = (req: any): string => String(
    req.headers?.['x-titan-profile-token'] || req.query?.token || req.body?.profileToken || '',
  ).trim();
  const isVipPortalRequest = (req: any): boolean => {
    if (equalSecret(adminKey, String(req.headers?.['x-titan-admin-key'] || ''))) return false;
    if (suppliedProfileToken(req)) return true;
    const referer = String(req.headers?.referer || '');
    try {
      return Boolean(referer && new URL(referer).searchParams.get('vip'));
    } catch (_) {
      return /[?&]vip=/.test(referer);
    }
  };
  const hasProfileAccess = (req: any, profileId: string): boolean => {
    if (!profileId) return false;
    const isAdminReq = Boolean(
      equalSecret(adminKey, String(req.headers?.['x-titan-admin-key'] || '')) ||
      (!suppliedProfileToken(req) && trustedLocalClient(req))
    );
    // A request carrying/referencing a VIP identity can never use the Admin
    // shortcut, even if it changes profileId in its body/query.
    if (profileId === 'admin1') return !isVipPortalRequest(req);
    if (isDeletedProfile(profileId)) return false;
    const portalProfile = readFullAppStateView()?.profiles?.[profileId];
    if (isAdminReq) return Boolean(portalProfile);
    if (!vipMembershipActive(portalProfile?.expiryDate)) return false;
    const expected = String(portalProfile?.vipAccessToken || '');
    const supplied = suppliedProfileToken(req);
    if (!expected || !supplied || expected.length !== supplied.length) return false;
    try {
      return timingSafeEqual(Buffer.from(expected), Buffer.from(supplied));
    } catch (_) {
      return false;
    }
  };
  registerPwa(app,titanAppRoot,hasProfileAccess);
  const rejectProfileAccess = (res: any, profileId: string) => res.status(
    isDeletedProfile(profileId) ? 410 : 403,
  ).json({
    status: 'error',
    message: isDeletedProfile(profileId) ? 'VIP profile was deleted' : 'Invalid or missing VIP access token',
  });
  const mergeLedgerIntoFullAppState = (input: any): any => {
    if (!input?.profiles || !botState.ledgerState?.profiles) return input;
    const date = String(botState.ledgerState.date || '');
    if (!date) return input;
    let changed = false;
    const state = { ...input, profiles: { ...input.profiles } };
    for (const [pid, remote] of Object.entries(botState.ledgerState.profiles as Record<string, any>)) {
      const local = state.profiles[pid];
      if (!local || !(remote as any)?.cards) continue;
      // An explicitly edited archive owns its rates; a stale single-day live
      // cache must not overwrite it after the business date advances.
      if(date<businessDateIST()&&local.dayRecords?.[date]?.recoveryConfigSnapshot&&Number(local.dayRecords[date].backtestRevision||0)>0)continue;
      const profile = { ...local, dayRecords: { ...(local.dayRecords || {}) } };
      const dayStore: any = { ...(profile.dayRecords[date] || {}), ...(remote.loopAccountStops?{loopAccountStops:remote.loopAccountStops}:{}) };
      const cachedAnkMarkets = getEffectiveMarkets(profile.config);
      const cachedJodiMarkets = getEffectiveBaseMarkets(profile.config);
      let profileChanged = Boolean(remote.loopAccountStops&&!sameAdminValue(profile.dayRecords[date]?.loopAccountStops,remote.loopAccountStops));
      if (pid !== 'admin1' && remote.vipGameRuns && !sameAdminValue(profile.vipGameRuns,remote.vipGameRuns)) {
        profile.vipGameRuns = structuredClone(remote.vipGameRuns); profileChanged = true;
      }
      if ((remote as any).loopConfig && (!dayStore.loopConfig || Number((remote as any).loopConfig.revision||0)>Number(dayStore.loopConfig.revision||0))) {dayStore.loopConfig=(remote as any).loopConfig;profileChanged=true;}
      for (const [cardKey, card] of Object.entries((remote as any).cards || {}) as Array<[string, any]>) {
        if (!card) continue;
        const terminal = card.s === 'PASS' || card.s === 'FAIL' || card.s === 'SKIP';
        const hasServerRecovery = card.recRate !== undefined || Boolean(card.rateFinalizedAt) || Number(card.prevLoss || 0) > 0 || card.targetProfitWithLoss !== undefined || Boolean(card.sentRate || card.sentDigits || card.deliveryMissedAt);
        if (!terminal && !card.sourceEditedAt && !card.manualStatus && !card.manualRate && !hasServerRecovery) continue;
        const [type, idxRaw] = String(cardKey).split('_');
        let idx = Number(idxRaw);
        if (!Number.isFinite(idx)) continue;
        const dictName = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : type === 'pannel' ? 'pannelData' : '';
        if (!dictName) continue;
        const dict = { ...(dayStore[dictName] || {}) };
        const identity=String(card.marketName || remote.markets?.find((m:any)=>m.type===type&&Number(m.index)===idx)?.n || '').trim().toUpperCase();
        if(identity){
          const markets=type==='jodi'?cachedJodiMarkets:cachedAnkMarkets;
          const activeIndex=markets.findIndex(m=>String(m.n).trim().toUpperCase()===identity);
          const archivedIndex=Object.entries(dict).find(([,r]:any)=>String(r?.marketName||'').trim().toUpperCase()===identity)?.[0];
          if(activeIndex>=0)idx=activeIndex;else if(archivedIndex!==undefined)idx=Number(archivedIndex);else continue;
        }
        const rec: any = { ...(dict[idx] || { s: 'WAIT', d: '', r: '' }) };
        if(date<businessDateIST()&&(rec.manualRate||rec.manualStatus)&&Number(rec.manualOverrideAt||0)>Number(card.manualOverrideAt||0))continue;
        if (card.vipAutoStopResumeEligible) rec.vipAutoStopResumeEligible = true;
        else delete rec.vipAutoStopResumeEligible;
        if (card.vipAutoStopSkipped) rec.vipAutoStopSkipped = true;
        else delete rec.vipAutoStopSkipped;
        if (card.closeZeroAutoSkipped) rec.closeZeroAutoSkipped = true;
        else delete rec.closeZeroAutoSkipped;
        if (isStaleModelSnapshot(rec, card)) continue;
        const nextStatus = isEditableSourceSkip(card)?'SKIP':card.manualStatus ? String(card.s || 'WAIT') : (terminal ? String(card.s) : rec.s);
        // Server-side recovery rate is authoritative too. This is what makes the
        // next suggested rate survive while the dashboard/browser is closed.
        // V4 SSOT reconciliation: a terminal card's historical rate is the
        // immutable rate actually delivered on WhatsApp. This repairs older
        // browser-corrupted r values (e.g. sent 60 but UI later rewrote r=220).
        const frozenTerminalRate = terminal && card.sentRate && parseFloat(String(card.sentRate)) > 0
          ? String(card.sentRate)
          : '';
        const nextRate = frozenTerminalRate || (card.r !== undefined && card.r !== null && String(card.r) !== '' ? String(card.r) : String(rec.r || ''));
        const nextRec: any = {
          ...rec,
          s: nextStatus,
          d: isEditableSourceSkip(card) ? '' : card.d || (card.sourceEditedAt && card.d !== undefined) ? String(card.d) : rec.d,
          marketModel: card.sourceEditedAt || card.marketModel ? card.marketModel : rec.marketModel,
          smartSelection: card.sourceEditedAt || card.smartSelection ? card.smartSelection : rec.smartSelection,
          strictPanel30: card.sourceEditedAt || card.strictPanel30 ? card.strictPanel30 : rec.strictPanel30,
          liveCombinedCut: card.sourceEditedAt ? card.liveCombinedCut : rec.liveCombinedCut,
          sourceEditedAt: card.sourceEditedAt || rec.sourceEditedAt,
          od: card.od || rec.od,
          trick: card.trick || rec.trick,
          sourceMode: card.sourceMode || rec.sourceMode,
          loopId: card.loopId || rec.loopId,
          sentLoopId: card.sentLoopId || rec.sentLoopId,
          scrapeSource: card.scrapeSource || rec.scrapeSource,
          sentScrapeSource: card.sentScrapeSource || rec.sentScrapeSource,
          autoResultParity: card.autoResultParity,
          autoRemovedResult: card.autoRemovedResult,
          openCloseCut:card.openCloseCut,
          carryResultSix: card.carryResultSix,
          ...((card.carryResultSix||rec.carryResultSix)?{od:card.od,trick:card.trick,positionRule:card.positionRule,scrapeSource:card.scrapeSource,sourceMode:card.sourceMode}:{}),
          firstDigitMirrorCut: card.firstDigitMirrorCut,
          triCut: card.triCut,
          sniperOne: card.sniperOne,
          tesla369: card.tesla369,
          mssdState: card.sourceEditedAt || card.mssdState ? card.mssdState : rec.mssdState,
          masterFlow: card.sourceEditedAt || card.masterFlow ? card.masterFlow : rec.masterFlow,
          scrapeResultDigit: card.scrapeResultDigit || undefined,
          manualResult: card.manualResult || undefined,
          manualPanelResult: card.manualPanelResult || undefined,
          manualResultSources: card.manualResultSources || undefined,
          weekdaySelectedDigits: card.weekdaySelectedDigits || rec.weekdaySelectedDigits,
          weekdayHitPosition: card.weekdayHitPosition !== undefined ? card.weekdayHitPosition : rec.weekdayHitPosition,
          marketName: card.marketName || rec.marketName,
          r: nextRate,
          recRate: card.recRate !== undefined ? card.recRate : rec.recRate,
          twoCardRecoveryShares: card.twoCardRecoveryShares ?? rec.twoCardRecoveryShares,
          twoCardRecoveryStrategy: card.twoCardRecoveryStrategy ?? rec.twoCardRecoveryStrategy,
          smartStaking: card.smartStaking !== undefined ? card.smartStaking : rec.smartStaking,
          prevLoss: card.prevLoss !== undefined ? card.prevLoss : rec.prevLoss,
          targetProfitWithLoss: card.targetProfitWithLoss !== undefined ? card.targetProfitWithLoss : rec.targetProfitWithLoss,
          sentRate: card.sentRate || rec.sentRate,
          sentInvest: card.sentInvest !== undefined ? card.sentInvest : rec.sentInvest,
          sentDigits: card.sentDigits || rec.sentDigits,
          sentSourceMode: card.sentSourceMode || rec.sentSourceMode,
          sentTrick: card.sentTrick || rec.sentTrick,
          sentTargets: Array.isArray(card.sentTargets) ? card.sentTargets : rec.sentTargets,
          manualStatus: Boolean(card.manualStatus || rec.manualStatus) || undefined,
          manualRate: Boolean(card.manualRate || rec.manualRate) || undefined,
          manualOverrideAt: card.manualOverrideAt || rec.manualOverrideAt,
          loopAccountSkipped:card.loopAccountSkipped||rec.loopAccountSkipped,
          loopAccountReason:card.loopAccountReason||rec.loopAccountReason,
          loopAccountReservation:card.loopAccountReservation,
          dispatchState: card.dispatchState || rec.dispatchState,
          dispatchKey: card.dispatchKey || rec.dispatchKey,
          queuedAt: card.queuedAt || rec.queuedAt,
          sentAt: card.sentAt || rec.sentAt,
          settledAt: card.settledAt || rec.settledAt,
          jodiOpenStatus: card.jodiOpenStatus || rec.jodiOpenStatus,
          jodiOpenResult: card.jodiOpenResult || rec.jodiOpenResult,
          jodiOpenSettledAt: card.jodiOpenSettledAt || rec.jodiOpenSettledAt,
          deliveryMissedAt: card.deliveryMissedAt || rec.deliveryMissedAt,
          deliveryMissedReason: card.deliveryMissedReason || rec.deliveryMissedReason,
          deliveryPartial: card.deliveryPartial !== undefined ? card.deliveryPartial : rec.deliveryPartial,
          rateFinalizedFrom: card.rateFinalizedFrom || rec.rateFinalizedFrom,
          rateFinalizedAt: card.rateFinalizedAt || rec.rateFinalizedAt,
        };
        applySourceSnapshot(nextRec, card, rec);
        if (card.deliveryRestoredAt) { nextRec.deliveryRestoredAt = card.deliveryRestoredAt; nextRec.s = card.s; clearRestoredDelivery(nextRec); }
        if (!sameAdminValue(nextRec, rec)) {
          dict[idx] = nextRec;
          dayStore[dictName] = dict;
          profileChanged = true;
        }
      }
      if (profileChanged) {
        profile.dayRecords[date] = dayStore;
        state.profiles[pid] = profile;
        changed = true;
      }
    }
    let merged=changed?state:input;
    if(date===businessDateIST())for(const [pid,profile] of Object.entries(merged.profiles) as Array<[string,any]>){
      const pinned=pinRecoverySettings(profile,date);
      if(pinned!==profile)merged={...merged,profiles:{...merged.profiles,[pid]:pinned}};
    }
    return merged;
  };
  const pendingAuditsFile = path.join(titanDataDir, 'titan_pending_audits.json');
  const calculateBusinessDateIST = (): string => businessDateIST();
  try {
    if (fs.existsSync(resultFollowUpFile)) {
      const raw = JSON.parse(fs.readFileSync(resultFollowUpFile, 'utf-8'));
      if (raw && typeof raw === 'object') botState.resultFollowUpSent = raw;
    }
  } catch (_) {}
  try {
    if (fs.existsSync(pendingAuditsFile)) {
      const raw = JSON.parse(fs.readFileSync(pendingAuditsFile, 'utf-8'));
      if (Array.isArray(raw)) {
        botState.pendingAuditResults = raw.filter((item: any) => item && !item.processed).slice(-50);
      }
    }
  } catch (_) {}
  // V14.22: broadcast delivery is intentionally non-durable. Never restore a
  // pre-restart/pre-login backlog; clear any legacy queue file from older builds.
  try {
    if (fs.existsSync(pendingBroadcastsFile)) fs.rmSync(pendingBroadcastsFile, { force: true });
  } catch (_) {}
  try {
    if (fs.existsSync(expiredBroadcastKeysFile)) {
      const raw = JSON.parse(fs.readFileSync(expiredBroadcastKeysFile, 'utf-8'));
      if (raw && typeof raw === 'object' && !Array.isArray(raw)) expiredBroadcastKeys = raw;
    }
  } catch (_) {}
  try {
    if (fs.existsSync(profitMilestonesFile)) {
      const raw = JSON.parse(fs.readFileSync(profitMilestonesFile, 'utf-8'));
      if (raw && typeof raw === 'object' && !Array.isArray(raw)) profitMilestones = raw;
    }
  } catch (_) {}
  try {
    if (fs.existsSync(deletedProfilesFile)) {
      const raw = JSON.parse(fs.readFileSync(deletedProfilesFile, 'utf-8'));
      if (Array.isArray(raw)) botState.deletedProfileIds = raw.map((pid) => String(pid || '')).filter(Boolean);
    }
  } catch (_) {}
  try {
    if (fs.existsSync(explicitlyDeletedProfilesFile)) {
      const raw = JSON.parse(fs.readFileSync(explicitlyDeletedProfilesFile, 'utf-8'));
      if (Array.isArray(raw)) botState.explicitlyDeletedProfileIds = raw.map((pid) => String(pid || '')).filter(Boolean);
    }
  } catch (_) {}
  try {
    const schedFile = path.join(titanDataDir, 'active_schedules.json');
    if (fs.existsSync(schedFile)) {
      const raw = JSON.parse(fs.readFileSync(schedFile, 'utf-8'));
      if (Array.isArray(raw)) botState.activeSchedules = raw;
    }
  } catch (_) {}
  try {
    if (fs.existsSync(ledgerSnapshotFile)) {
      const raw = JSON.parse(fs.readFileSync(ledgerSnapshotFile, 'utf-8'));
      if (raw?.date === calculateBusinessDateIST() && raw?.profiles && typeof raw.profiles === 'object') {
        botState.ledgerState = raw;
      }
    }
  } catch (_) {}

  let pendingLedgerDiskJson: string | null = null;
  let ledgerDiskFlushRunning = false;
  const flushLedgerSnapshotAsync = async () => {
    if (ledgerDiskFlushRunning) return;
    ledgerDiskFlushRunning = true;
    try {
      while (pendingLedgerDiskJson !== null) {
        const jsonToWrite = pendingLedgerDiskJson;
        pendingLedgerDiskJson = null;
        const temp = `${ledgerSnapshotFile}.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2)}.tmp`;
        try {
          await fs.promises.mkdir(path.dirname(ledgerSnapshotFile), { recursive: true });
          await fs.promises.writeFile(temp, jsonToWrite, 'utf-8');
          await fs.promises.rename(temp, ledgerSnapshotFile);
        } catch (err) {
          try { await fs.promises.unlink(temp); } catch (_) {}
          console.error('[persist:ledger-snapshot-async]', err);
        }
      }
    } finally {
      ledgerDiskFlushRunning = false;
      if (pendingLedgerDiskJson !== null) void flushLedgerSnapshotAsync();
    }
  };
  function persistLedgerSnapshot() {
    pendingLedgerDiskJson = JSON.stringify(botState.ledgerState);
    void flushLedgerSnapshotAsync();
  }

  function persistResultFollowUps() {
    try {
      // Follow-up keys use the 6 AM business date. Calendar-date cleanup before
      // 6 AM deleted a freshly-added previous-business-day key immediately and
      // allowed the same PASS/FAIL reply to be queued again.
      const todayIST = calculateBusinessDateIST();
      const cleaned: Record<string, boolean> = {};
      for (const [k, v] of Object.entries(botState.resultFollowUpSent || {})) {
        if (v && String(k).includes(todayIST)) cleaned[k] = true;
      }
      botState.resultFollowUpSent = cleaned;
      atomicWriteFileAsync(resultFollowUpFile, JSON.stringify(cleaned), 'result-followups');
    } catch (_) {}
  }

  function persistProfitMilestones() {
    try {
      const date = String(botState.ledgerState?.date || calculateBusinessDateIST());
      const cleaned: Record<string, number> = {};
      for (const [key, milestone] of Object.entries(profitMilestones || {})) {
        if (String(key).startsWith(`${date}|`) && Number(milestone) >= 1000) cleaned[key] = Number(milestone);
      }
      profitMilestones = cleaned;
      atomicWriteFile(profitMilestonesFile, JSON.stringify(cleaned), 'profit-milestones');
    } catch (_) {}
  }

  function persistPendingAudits() {
    try {
      const pending = botState.pendingAuditResults.filter((item: any) => !item.processed).slice(-50);
      atomicWriteFileAsync(pendingAuditsFile, JSON.stringify(pending), 'pending-audits');
    } catch (_) {}
  }

  function persistDeletedProfiles() {
    try {
      atomicWriteFile(deletedProfilesFile, JSON.stringify([...new Set(botState.deletedProfileIds || [])]), 'deleted-profiles');
    } catch (_) {}
  }

  function persistExplicitlyDeletedProfiles() {
    try {
      atomicWriteFile(explicitlyDeletedProfilesFile, JSON.stringify([...new Set(botState.explicitlyDeletedProfileIds || [])]), 'explicitly-deleted-profiles');
    } catch (_) {}
  }

  function persistPendingBroadcasts() {
    // Intentionally persist no delivery backlog. The in-memory array is only a
    // short-lived handoff between server.ts and an already-running gateway.
    try {
      if (fs.existsSync(pendingBroadcastsFile)) fs.rmSync(pendingBroadcastsFile, { force: true });
    } catch (_) {}
  }

  function persistExpiredBroadcastKeys() {
    try {
      const today = calculateBusinessDateIST();
      const cleaned: Record<string, boolean> = {};
      for (const [key, value] of Object.entries(expiredBroadcastKeys || {})) {
        if (value && String(key).includes(today)) cleaned[key] = true;
      }
      expiredBroadcastKeys = cleaned;
      atomicWriteFile(expiredBroadcastKeysFile, JSON.stringify(cleaned), 'expired-broadcast-keys');
    } catch (_) {}
  }

  const releaseExpiredVipBroadcast = (b: any, reason = 'LIVE_DELIVERY_MISSED', partial = false) => {
    if (b?.broadcastKind !== 'vip-auto-card' || !b?.profileId || !b?.cardType || !Number.isFinite(Number(b?.index))) return;
    const rec = botState.ledgerState?.profiles?.[String(b.profileId)]?.cards?.[`${String(b.cardType)}_${Number(b.index)}`];
    if (Number(rec?.cardGeneration || 0) !== Number(b.cardGeneration || 0)) return;
    const deliveredTargets = normalizeTargetList(transportReceipts[`broadcast:${b?.id}`] || []);

    // An acknowledged partial send remains a financial play even if pause won
    // the race against the transport receipt.
    if (partial && deliveredTargets.length > 0 && rec?.vipAutoStopSkipped && !rec.deliveryRestoredAt) { rec.s = 'WAIT'; delete rec.vipAutoStopSkipped; }

    if (rec && !rec.deliveryRestoredAt && rec.s !== 'SKIP' && rec.dispatchState !== 'SETTLED') {
      if (partial && deliveredTargets.length > 0) {
        // A partially delivered play is still a real business play for the
        // recipients that received it. Freeze its play terms, but remember the
        // exact delivered subset so the result reply is not sent to failed targets.
        const digits = String(b.digits || rec.d || '').trim();
        const rateNum = Number(b.rateNum || rec.r || 0);
        const count = digits ? digits.split(/[,|\s]+/).filter(Boolean).length : 0;
        const investTotal = Number(b.investTotal || 0) || count * rateNum;
        rec.d = digits || rec.d;
        rec.r = rateNum > 0 ? String(rateNum) : rec.r;
        rec.sentRate = rateNum > 0 ? String(rateNum) : rec.sentRate;
        rec.sentInvest = investTotal > 0 ? investTotal : rec.sentInvest;
        rec.sentDigits = digits || rec.sentDigits;
        rec.sentSourceMode = b.sourceMode || rec.sentSourceMode || rec.sourceMode;
        rec.sentTrick = b.trick || rec.sentTrick || rec.trick;
        rec.sentScrapeSource = normalizeScrapeSource(b.scrapeSource) || getScrapeSource(rec);
        rec.sentLoopId = rec.loopId || rec.sentLoopId;
        rec.sentTargets = deliveredTargets;
        rec.deliveryMissedAt = undefined;
        rec.deliveryMissedReason = reason;
        rec.deliveryPartial = true;
        rec.dispatchState = 'SENT_PARTIAL';
        rec.dispatchKey = String(b.scheduleKey || rec.dispatchKey || '');
        rec.queuedAt = undefined;
        rec.sentAt = rec.sentAt || Date.now();
        if (b.scheduleKey) {
          botState.sentSchedules[String(b.scheduleKey)] = true;
          persistSentSchedules();
        }
      } else if (rec.dispatchState !== 'SENT' && rec.dispatchState !== 'SENT_PARTIAL' && !rec.sentAt) {
        rec.dispatchState = undefined;
        rec.dispatchKey = undefined;
        rec.queuedAt = undefined;
        rec.sentTargets = undefined;
        rec.deliveryMissedAt = Date.now();
        rec.deliveryMissedReason = reason;
        rec.deliveryPartial = undefined;
      }
      botState.ledgerState.updatedAt = Date.now();
      persistLedgerSnapshot();
    }
    if (b.scheduleKey) {
      // Tombstone prevents any transport replay of this exact card. Partial plays
      // settle normally from their frozen sent* fields; zero-delivery plays SKIP.
      expiredBroadcastKeys[String(b.scheduleKey)] = true;
      persistExpiredBroadcastKeys();
    }
  };

  const broadcastResolution = (b: any) => {
    const expected = normalizeTargetList(b?.targets || []);
    const delivered = new Set(normalizeTargetList(transportReceipts[`broadcast:${b?.id}`] || []));
    const failed = new Set(normalizeTargetList(b?.failedTargets || []));
    const unresolved = expected.filter((target) => !delivered.has(target) && !failed.has(target));
    return { expected, delivered, failed, unresolved };
  };

  const finishResolvedBroadcast = (b: any, failureReason = 'LIVE_DELIVERY_FAILED'): 'pending' | 'sent' | 'failed' => {
    const state = broadcastResolution(b);
    if (state.unresolved.length > 0) return 'pending';
    delete b.broadcastPng;
    if (state.failed.size > 0 || state.expected.length === 0) {
      b.status = 'failed';
      releaseExpiredVipBroadcast(b, failureReason, state.delivered.size > 0);
      return 'failed';
    }
    b.status = 'sent';
    return 'sent';
  };

  const closeVipLiveDeliveryForResult = (profileId: string, cardType: string, index: number): { closed: number; inFlight: boolean } => {
    let closed = 0;
    let inFlight = false;
    for (const b of botState.pendingBroadcasts || []) {
      if (
        b.status !== 'pending' || b.broadcastKind !== 'vip-auto-card' ||
        String(b.profileId || '') !== String(profileId) ||
        String(b.cardType || '') !== String(cardType) ||
        Number(b.index) !== Number(index)
      ) continue;
      const state = broadcastResolution(b);
      // A gateway can have completed the real send while its HTTP ACK is still
      // travelling back to this server.  Result ingestion and ack_broadcast are
      // separate requests, so declaring every unresolved target failed here
      // created a race: one VIP became SKIP while another already-acked VIP was
      // settled PASS/FAIL for the same result.  Keep an actively claimed send
      // alive for its authoritative ACK; the 5s audit retry settles immediately
      // afterwards.  Unclaimed/failed zero-delivery work still follows the
      // existing SKIP rule below.
      const hasActiveClaim = state.unresolved.some((target) => {
        const platform: Transport = isTelegramTarget(target) ? 'telegram' : 'whatsapp';
        return Boolean(b.claimedPlatforms?.[platform]);
      });
      // A queued/deferred card still has a legitimate delivery turn even when
      // another VIP currently owns the transport claim. Treating only the
      // actively claimed job as in-flight made later VIPs on the same target
      // fail as soon as the result arrived.
      const hasLiveQueueOpportunity = state.unresolved.some((target) => {
        const platform: Transport = isTelegramTarget(target) ? 'telegram' : 'whatsapp';
        const boundSession = String(b.platformSessions?.[platform] || '');
        return liveTransportUsable(platform) && boundSession === liveTransports[platform].sessionId;
      });
      if (hasActiveClaim || hasLiveQueueOpportunity) {
        inFlight = true;
        continue;
      }
      if (state.unresolved.length > 0) {
        b.failedTargets = [...new Set([...(b.failedTargets || []), ...state.unresolved])];
        b.claimedPlatforms = {};
        b.claimedTargets = {};
        b.platformNotBefore = {};
        b.platformSessions = {};
      }
      const final = finishResolvedBroadcast(b, 'RESULT_ARRIVED_BEFORE_DELIVERY_COMPLETE');
      if (final !== 'pending') closed++;
    }
    return { closed, inFlight };
  };

  const retireTransportTargets = (b: any, platform: Transport, reason: string): number => {
    if (!b || b.status !== 'pending') return 0;
    const state = broadcastResolution(b);
    const doomed = transportTargets(state.unresolved, platform);
    if (!doomed.length) return 0;
    b.failedTargets = [...new Set([...(b.failedTargets || []), ...doomed])];
    if (b.claimedPlatforms) delete b.claimedPlatforms[platform];
    if (b.claimedTargets) delete b.claimedTargets[platform];
    if (b.platformNotBefore) delete b.platformNotBefore[platform];
    if (b.platformSessions) delete b.platformSessions[platform];
    finishResolvedBroadcast(b, reason);
    return doomed.length;
  };

  const retireSessionBoundBroadcasts = (platform: Transport, activeSessionId: string, reason: string): number => {
    let retired = 0;
    for (const b of botState.pendingBroadcasts || []) {
      if (b.status !== 'pending') continue;
      const bound = String(b.platformSessions?.[platform] || '');
      if (bound && bound !== activeSessionId) retired += retireTransportTargets(b, platform, reason);
    }
    if (retired > 0) {
      // These are deliberately NOT replayed: retrying an uncertain provider ACK
      // after reconnect can deliver duplicate financial cards. Surface the miss.
      const message = `Delivery interrupted: ${retired} ${platform} target(s) cancelled (${reason}); verify recipients before manually resending.`;
      console.warn(`[delivery] ${message}`);
      botState.logs.unshift({ id: `${Date.now()}_session_retire`, time: new Date().toLocaleTimeString(), msg: message, type: 'warning' });
      if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
    }
    return retired;
  };

  const expireStaleLiveBroadcasts = (): number => {
    const now = Date.now();
    const businessDate = calculateBusinessDateIST();
    let retired = 0;
    for (const b of botState.pendingBroadcasts || []) {
      if (b.status !== 'pending') continue;
      const createdAt = new Date(b.createdAt).getTime();
      const staleDate = !Number.isFinite(createdAt) || businessDateIST(new Date(b.createdAt)) !== businessDate;
      const staleAge = !Number.isFinite(createdAt) || now - createdAt > LIVE_BROADCAST_MAX_AGE_MS;
      if (!staleDate && !staleAge) continue;
      for (const platform of ['whatsapp', 'telegram'] as Transport[]) {
        retired += retireTransportTargets(b, platform, staleDate ? 'BUSINESS_DATE_EXPIRED' : 'LIVE_WINDOW_EXPIRED');
      }
    }
    if (retired > 0) {
      botState.logs.unshift({
        id: `${Date.now()}_live_expire`, time: new Date().toLocaleTimeString(),
        msg: `⏭️ Expired ${retired} stale live broadcast target(s); no login/restart replay`, type: 'info',
      });
      if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
      persistPendingBroadcasts();
    }
    return retired;
  };
  const liveBroadcastCleanupTimer = setInterval(expireStaleLiveBroadcasts, 30_000);
  liveBroadcastCleanupTimer.unref();

  // Keep every live in-memory handoff. Completed history may still be trimmed.
  function compactPendingBroadcasts(maxCompleted = 80) {
    for(const item of botState.pendingBroadcasts)if(item.status!=='pending')delete item.broadcastPng;
    const pending = (botState.pendingBroadcasts || []).filter((b: any) => b.status === 'pending');
    const completed = (botState.pendingBroadcasts || [])
      .filter((b: any) => b.status !== 'pending')
      .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, maxCompleted)
      .reverse();
    botState.pendingBroadcasts = [...completed, ...pending];
  }

  function isDeletedProfile(profileId: unknown): boolean {
    const pid = String(profileId || '');
    return Boolean(pid && pid !== 'admin1' && botState.deletedProfileIds.includes(pid));
  }

  function purgeDeletedProfile(profileId: unknown, reason = 'profile deleted'): boolean {
    const pid = String(profileId || '').trim();
    if (!pid || pid === 'admin1') return false;
    const wasAlreadyDeleted = botState.deletedProfileIds.includes(pid);
    if (!wasAlreadyDeleted) botState.deletedProfileIds.push(pid);
    if (reason === 'explicit dashboard deletion' && !botState.explicitlyDeletedProfileIds.includes(pid)) {
      botState.explicitlyDeletedProfileIds.push(pid);
      persistExplicitlyDeletedProfiles();
    }
    botState.activeProfileIds = botState.activeProfileIds.filter((id) => id !== pid);
    botState.activeSchedules = (botState.activeSchedules || []).filter((s: any) => String(s?.profileId || '') !== pid);
    botState.pendingBroadcasts = botState.pendingBroadcasts.filter((b: any) => String(b?.profileId || '') !== pid);
    for (const key of Object.keys(botState.scheduleClaims || {})) {
      const claim = (botState.scheduleClaims as any)[key];
      if (String(claim?.profileId || '') === pid || key.startsWith(`${pid}_`) || key.startsWith(`vip_${pid}_`)) {
        delete botState.scheduleClaims[key];
      }
    }
    for (const key of Object.keys(botState.sentSchedules || {})) {
      if (key.startsWith(`${pid}_`) || key.startsWith(`vip_${pid}_`)) delete botState.sentSchedules[key];
    }
    for (const key of Object.keys(botState.resultFollowUpSent || {})) {
      if (key.startsWith(`${pid}_`)) delete botState.resultFollowUpSent[key];
    }
    delete botState.ledgerState.profiles[pid];
    delete botState.schedulePolicy[pid];
    for (const key of Object.keys(botState.scheduleMsgKeys || {})) {
      if (key.startsWith(`${pid}_`) || key.startsWith(`vip_${pid}_`)) delete botState.scheduleMsgKeys[key];
    }
    persistDeletedProfiles();
    persistSentSchedules();
    persistResultFollowUps();
    persistLedgerSnapshot();
    atomicWriteFileAsync(path.join(titanDataDir, 'active_schedules.json'), JSON.stringify(botState.activeSchedules || []), 'active-schedules');
    if (!wasAlreadyDeleted) {
      botState.logs.unshift({ id: Date.now().toString(), time: new Date().toLocaleTimeString(), msg: `🗑️ Permanently purged ${pid} (${reason})`, type: 'info' });
      if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
    }
    return !wasAlreadyDeleted;
  }

  /** Master full-state sync can repair tombstones created by older scoped VIP clients. */
  function reviveAuthoritativeProfiles(profileIds: string[], incomingProfiles: Record<string, any>, reason: string): string[] {
    const liveIds = new Set(
      profileIds.filter((pid) => pid !== 'admin1' && Object.prototype.hasOwnProperty.call(incomingProfiles || {}, pid)),
    );
    const explicit = new Set(botState.explicitlyDeletedProfileIds || []);
    const revived = botState.deletedProfileIds.filter((pid) => liveIds.has(pid) && !explicit.has(pid));
    if (!revived.length) return [];
    const revivedSet = new Set(revived);
    botState.deletedProfileIds = botState.deletedProfileIds.filter((pid) => !revivedSet.has(pid));
    persistDeletedProfiles();
    botState.logs.unshift({
      id: Date.now().toString(),
      time: new Date().toLocaleTimeString(),
      msg: `♻️ Restored live VIP profile(s): ${revived.join(', ')} (${reason})`,
      type: 'info',
    });
    if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
    return revived;
  }

  // ─── Server-side result parse + PASS/FAIL (works without open dashboard) ───
  function serverParseResult(textRaw: string) {
    const raw = String(textRaw || '').trim();
    const cleanedLines = raw
      .split(/\n/)
      .filter((ln) => !/^\s*(digits|rate|total|return|net|loss|played)\s*:/i.test(ln))
      .join(' ');
    // *SRIDEVI* *466-65-249* → SRIDEVI 466-65-249
    const upper = cleanedLines
      .toUpperCase()
      .replace(/[–—]/g, '-')
      .replace(/\*/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    const marketHints = [
      'SRIDEVI NIGHT', 'SRIDEVI DAY', 'SRIDEV NIGHT', 'SRIDEV DAY', 'SHRIDEVI NIGHT', 'SHRIDEVI DAY',
      'MADHUR NIGHT', 'MADHUR DAY',
      'MILAN NIGHT', 'MILAN DAY',
      'RAJDHANI NIGHT', 'RAJDHANI DAY',
      'SUPREME NIGHT', 'SUPREME DAY',
      'KALYAN NIGHT', 'TIME BAZAR', 'MAIN BAZAR',
      'KALYAN',
      'SRIDEVI', 'SRIDEV', 'SHRIDEVI', 'MADHUR', 'MILAN', 'RAJDHANI', 'SUPREME',
    ];
    let marketBase = '';
    for (const h of marketHints) {
      if (!upper.includes(h)) continue;
      // Bare name must not steal when DAY/NIGHT form is in the message
      if (['SRIDEVI', 'SRIDEV', 'SHRIDEVI', 'MADHUR', 'MILAN', 'RAJDHANI', 'SUPREME'].includes(h)) {
        if (upper.includes(h + ' NIGHT') || upper.includes(h + ' DAY')) continue;
      }
      marketBase = h;
      break;
    }
    if (marketBase === 'SRIDEV NIGHT' || marketBase === 'SHRIDEVI NIGHT') marketBase = 'SRIDEVI NIGHT';
    if (marketBase === 'SRIDEVI DAY' || marketBase === 'SRIDEV DAY' || marketBase === 'SHRIDEVI DAY' || marketBase === 'SRIDEV' || marketBase === 'SHRIDEVI') marketBase = 'SRIDEVI';
    // Bare family names resolve only after that market's real NIGHT start.
    marketBase = resolveAmbiguousMarketByIST(marketBase);
    let openPanel = '', openAnk = '', jodi = '', closeAnk = '', closePanel = '';
    let session: 'OPEN' | 'CLOSE' | 'FULL' = 'FULL';
    const structural = extractResultNumbers(raw);
    if (structural) {
      ({ openPanel, openAnk, jodi, closeAnk, closePanel, session } = structural);
    }
    const fullAll = structural ? [] : [...upper.matchAll(/(\d{3})\s*[-:]\s*(\d{2})\s*[-:]\s*(\d{3})/g)];
    const fullMatch = fullAll.length ? fullAll[fullAll.length - 1] : null;
    if (fullMatch) {
      openPanel = fullMatch[1];
      openAnk = fullMatch[2][0];
      closeAnk = fullMatch[2][1];
      jodi = fullMatch[2];
      closePanel = fullMatch[3];
      session = 'FULL';
    } else if (!structural) {
      const spacedAll = [...upper.matchAll(/\b(\d{3})\s+(\d{2})\s+(\d{3})\b/g)];
      const spaced = spacedAll.length ? spacedAll[spacedAll.length - 1] : null;
      if (spaced) {
        openPanel = spaced[1];
        openAnk = spaced[2][0];
        closeAnk = spaced[2][1];
        jodi = spaced[2];
        closePanel = spaced[3];
        session = 'FULL';
      } else {
        const openAll = [...upper.matchAll(/(\d{3})\s*[-:]\s*(\d)\b/g)];
        const openMatch = openAll.length ? openAll[openAll.length - 1] : null;
        if (openMatch) {
          openPanel = openMatch[1];
          openAnk = openMatch[2];
          session = 'OPEN';
        }
        const closeAll = [...upper.matchAll(/\b(\d)\s*[-:]\s*(\d{3})\b/g)];
        const closeMatch = closeAll.length ? closeAll[closeAll.length - 1] : null;
        if (closeMatch) {
          closeAnk = closeMatch[1];
          closePanel = closeMatch[2];
          session = openAnk ? 'FULL' : 'CLOSE';
        }
        const jodiLabel = upper.match(/JODI\s*[:\-]?\s*(\d{2})\b/);
        if (jodiLabel) {
          jodi = jodiLabel[1];
          if (!openAnk) openAnk = jodi[0];
          if (!closeAnk) closeAnk = jodi[1];
        }
      }
    }
    // Plain forms: "KALYAN OPEN 6" / "KALYAN CLOSE 4" / "OPEN : 6"
    if (!openAnk) {
      const openPlain = upper.match(/\bOPEN\b[^0-9]{0,12}(\d)\b/);
      if (openPlain) {
        openAnk = openPlain[1];
        if (!fullMatch) session = 'OPEN';
      }
    }
    if (!closeAnk) {
      const closePlain = upper.match(/\bCLOSE\b[^0-9]{0,12}(\d)\b/);
      if (closePlain) {
        closeAnk = closePlain[1];
        if (!fullMatch) session = openAnk ? 'FULL' : 'CLOSE';
      }
    }
    // Lone digit after market name when OPEN/CLOSE keyword present
    if (!openAnk && !closeAnk && marketBase) {
      const after = upper.split(marketBase)[1] || '';
      const lone = after.match(/\b(\d)\b/);
      if (lone) {
        if (upper.includes('CLOSE') && !upper.includes('OPEN')) {
          closeAnk = lone[1];
          session = 'CLOSE';
        } else {
          openAnk = lone[1];
          session = upper.includes('CLOSE') ? 'FULL' : 'OPEN';
        }
      }
    }

    if (openAnk && closeAnk) jodi = `${openAnk}${closeAnk}`;
    if (!fullMatch && structural?.session !== 'FULL') {
      if (upper.includes('CLOSE') && !upper.includes('OPEN')) session = 'CLOSE';
      else if (upper.includes('OPEN') && !upper.includes('CLOSE')) session = 'OPEN';
    }

    return { marketBase, session, openAnk, closeAnk, jodi, openPanel, closePanel, raw };
  }

  function serverTokenHit(cardDigits: string, winning: string, mode: 'ank' | 'jodi' | 'panel') {
    return settlementTokenHit(mode === 'panel' ? 'pannel' : mode, cardDigits, winning);
  }

  function serverCalculateNextCardRate(
    type: string,
    nextDigitsStr: unknown,
    pendingLoss = 0,
    targetProfitConfig = 100,
  ): string {
    // Backend remains authoritative; formula itself is shared to prevent drift.
    return calculateRecoveryRate(type, nextDigitsStr, pendingLoss, targetProfitConfig);
  }

  function serverRecoveryTrackKey(prof: any, type: string, marketName: string): string {
    return runtimeFinancialRecoveryTrack(prof,type,marketName);
  }

  // Rebuild debt from actual settled cards. A WAIT card's prevLoss is only an
  // earlier rate suggestion and can be stale when an accidental PASS is undone.
  function serverLiveFinancialCards(prof:any) {
    const autoVip=prof!==botState.ledgerState?.profiles?.admin1&&prof?.vipAutoMode!==false;
    return liveVipRecoveryCards(prof?.cards||{},autoVip);
  }
  function serverShareRecoveryState(prof:any,type:string,track:string,beforeIndex=Infinity) {
    return replayTwoCardRecovery(type,prof.markets||[],serverLiveFinancialCards(prof),track,name=>serverRecoveryTrackKey(prof,type,name),beforeIndex,
      {split:prof.splitMode?.[type]!==false,legacySplit:prof.twoCardRecoveryLegacySplit?.[type]??prof.splitMode?.[type]!==false,resetAfterThreeFails:prof.liveThreeFailReset===true&&botState.ledgerState.date===businessDateIST()});
  }
  function serverSettledTrackState(prof: any, type: string, trackKey: string, beforeIndex = Infinity, savedProfile?: any) {
    if (!prof?.loopConfig?.enabled && prof?.fourWaveRelay === true) {
      const fw = evaluateServerFourWaveType(prof, type as any, serverLiveFinancialCards(prof), Number.isFinite(beforeIndex) ? beforeIndex : undefined);
      if (Number.isFinite(beforeIndex)) {
        const st = fw.byIndex.get(Number(beforeIndex));
        return { debt: st?.debt ?? 0, fromIndex: st?.fromIndex ?? -1, fromCardKey: st?.fromCardKey, consecutiveFails: st?.consecutiveFails ?? 0, pendingProfit: st?.pendingProfit ?? 0 };
      }
      return { debt: fw.totalPendingLoss, fromIndex: -1, fromCardKey: undefined, consecutiveFails: 0, pendingProfit: 0 };
    }
    if(runtimeRecoveryShareLedger(prof,type)) {
      const state=serverShareRecoveryState(prof,type,trackKey,beforeIndex);
      return {debt:state.debt,fromIndex:state.fromIndex,fromCardKey:state.fromCardKey,consecutiveFails:state.consecutiveFails,cyclesClosed:state.cyclesClosed,lastResetDebt:state.lastResetDebt,lastResetCardKey:state.lastResetCardKey,pendingProfit:0};
    }
    const pid = Object.keys(botState.ledgerState?.profiles || {}).find(k => botState.ledgerState.profiles[k] === prof) || 'admin1';
    const fullProf = savedProfile || readFullAppStateView()?.profiles?.[pid];
    const baseMarket = String(trackKey || '').replace(/^(?:L\d+:)?(?:ank|jodi|pannel):/i, '').trim();
    const resetEnabled = prof?.liveThreeFailReset===true && botState.ledgerState.date===businessDateIST();
    const isProfitCarry = prof?.profitCarry === true || prof?.config?.profitCarry === true;
    const prior = (fullProf && prof?.sameMarketRecovery !== false && baseMarket && baseMarket !== 'ALL' && baseMarket !== 'OPEN' && baseMarket !== 'CLOSE')
      ? getBaseMarketUnsettledState(fullProf, String(botState.ledgerState?.date || calculateBusinessDateIST()), type as any, baseMarket, resetEnabled)
      : { debt: 0, consecutiveFails: 0, pendingProfit: 0 };
    return rebuildSettledTrackState(
      type, Array.isArray(prof?.markets) ? prof.markets : [], serverLiveFinancialCards(prof),
      trackKey, (marketName) => serverRecoveryTrackKey(prof, type, marketName), beforeIndex,
      resetEnabled,
      prior.debt,
      prior.consecutiveFails,
      isProfitCarry,
      prior.pendingProfit || 0,
      (marketName, card) => runtimeTarget(prof, type, trackKey),
      Boolean(prof?.openPassCloseZero || prof?.config?.openPassCloseZero),
    );
  }

  function serverFinalizeVipReadyRate(
    prof: any,
    type: string,
    rec: any,
    trackKey: string,
    debtOverride?: number,
    pendingProfitOverride?: number,
  ): { rate: string; debt: number; targetProfit: number; sourceKey: string } {
    prof.recoveryState = prof.recoveryState || {};
    const st = prof.recoveryState[trackKey] || { debt: 0 };
    if(runtimeRecoveryShareLedger(prof,type)) {
      if(debtOverride===undefined){
        const key=Object.keys(prof.cards||{}).find(key=>prof.cards[key]===rec);
        const shares=serverShareRecoveryState(prof,type,trackKey).assignments[key||'']||[];
        if(!recoveryCardFrozen(rec))rec.twoCardRecoveryShares=shares;
        debtOverride=shareTotal(shares);
      }
      if(!recoveryCardFrozen(rec))rec.twoCardRecoveryStrategy=prof.splitMode?.[type]!==false?'TWO':'ALL';
    }
    const debt = debtOverride !== undefined
      ? Math.max(0, Number(debtOverride) || 0)
      : Math.max(0, Number(st.debt) || 0);
    const manualRateNum = Number(rec?.r);
    const hasExplicitManualRate = Boolean(
      rec?.manualRate && Number(rec?.manualOverrideAt || 0) > 0 &&
      Number.isFinite(manualRateNum) && manualRateNum > 0
    );
    const isSplitStaking = (type === 'ank' || type === 'pannel') && prof?.fourWaveRelay !== true && prof?.splitMode?.[type] !== false && !hasExplicitManualRate;
    const baseTarget = runtimeTarget(prof,type,trackKey);
    const isProfitCarry = prof?.profitCarry === true || prof?.config?.profitCarry === true;
    const carriedProfit = isProfitCarry
      ? (pendingProfitOverride !== undefined ? Math.max(0, Number(pendingProfitOverride) || 0) : (st.pendingProfit || 0))
      : 0;
    const targetProfit = baseTarget + carriedProfit;
    const sourceKey = debt > 0 ? String(st.fromCardKey || '') : '';

    const isOpenPassCloseZero = Boolean(prof?.openPassCloseZero || prof?.config?.openPassCloseZero);
    const marketObj = (prof.markets || []).find((m: any) => String(m?.type) === type && prof.cards[`${type}_${m.index}`] === rec);
    const resolvedMarketName = String(rec?.marketName || marketObj?.n || '');
    const isClose = (type === 'ank' || type === 'pannel') && /\s+CLOSE$/i.test(resolvedMarketName);
    let isOpenPass = false;
    if (isOpenPassCloseZero && isClose) {
      const baseMarket = resolvedMarketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
      const openName = `${baseMarket} OPEN`;
      const openMarket = (prof.markets || []).find((m: any) => String(m?.type) === type && String(m?.n || '').trim().toUpperCase() === openName);
      const openCard = openMarket ? prof.cards?.[`${type}_${openMarket.index}`] : Object.values(prof.cards || {}).find((c: any) => String(c?.marketName || '').trim().toUpperCase() === openName);
      isOpenPass = openCard?.s === 'PASS';
    }
    if (isOpenPass && !hasExplicitManualRate) {
      rec.r = '0';
      rec.recRate = '0';
      rec.prevLoss = 0;
      rec.targetProfitWithLoss = 0;
      delete rec.smartStaking;
      rec.rateFinalizedAt = Date.now();
      return { rate: '0', debt: 0, targetProfit: 0, sourceKey: '' };
    }

    if (!areSettlementTokensValid(type, rec?.d)) {
      rec.r = '';
      rec.recRate = '';
      rec.invalidRateReason = 'INVALID_TOKENS';
      rec.prevLoss = debt;
      rec.targetProfitWithLoss = debt + targetProfit;
      rec.rateFinalizedFrom = sourceKey || undefined;
      rec.rateFinalizedAt = Date.now();
      return { rate: '', debt, targetProfit, sourceKey };
    }

    const rate = hasExplicitManualRate
      ? String(manualRateNum)
      : serverCalculateNextCardRate(type, String(rec?.d || ''), debt, targetProfit);
    const smartStaking = isSplitStaking
      ? calculateSmartStakingRates(type, String(rec?.d || ''), debt, targetProfit, rec?.smartSelection?.strongDigits, rec?.smartSelection?.supportDigits)
      : undefined;
    rec.r = rate;
    rec.recRate = rate;
    if (smartStaking?.isSmartStaking) {
      rec.smartStaking = smartStaking;
    } else {
      delete rec.smartStaking;
    }
    rec.invalidRateReason = rate ? undefined : 'TOKEN_COUNT_NOT_PROFITABLE';
    if (!hasExplicitManualRate) {
      rec.manualRate = undefined;
      rec.manualOverrideAt = undefined;
    }
    rec.prevLoss = debt;
    rec.targetProfitWithLoss = debt + targetProfit;
    if (sourceKey) rec.rateFinalizedFrom = sourceKey;
    else rec.rateFinalizedFrom = undefined;
    rec.rateFinalizedAt = Date.now();
    return { rate, debt, targetProfit, sourceKey };
  }

  function serverBuildPassFailMsg(
    marketName: string,
    status: 'PASS' | 'FAIL',
    type: string,
    rec: {
      d?: string;
      r?: string;
      sentRate?: string | number;
      sentInvest?: number;
      sentDigits?: string;
      smartStaking?: any;
    },
    resultDigit: string | null,
    detailedMessage = true,
    fullResult?: string,
  ) {
    if (!detailedMessage) {
      return buildPremiumResultCard({
        marketName, status, resultDigit, fullResult, detailed: false,
      });
    }
    // MUST match the schedule WhatsApp card: prefer frozen sentRate / sentInvest
    const digitsStr = String(rec.sentDigits || rec.d || '').trim();
    const settlement = calculateSettlement({
      type,
      digits: digitsStr,
      rate: rec.r,
      sentRate: rec.sentRate,
      sentInvest: rec.sentInvest,
      winningDigit: resultDigit,
      smartStaking: rec.smartStaking,
    });
    const { invest } = settlement;
    const inr = (n: number) => `₹${Math.round(n).toLocaleString('en-IN')}`;
    if (status === 'PASS') {
      const payout = settlement.payout;
      const net = settlement.net;
      return buildPremiumResultCard({
        marketName, status, resultDigit, fullResult, detailed: true,
        payout: inr(payout),
        net: `${net >= 0 ? '+' : ''}${inr(net)}`,
      });
    }
    return buildPremiumResultCard({
      marketName, status, resultDigit, fullResult, detailed: true,
      loss: inr(invest),
    });
  }

  function serverQueueResultFollowUp(opts: {
    profileId: string;
    profile: any;
    marketName: string;
    type: string;
    index: number;
    date: string;
    status: 'PASS' | 'FAIL';
    rec: any;
    resultDigit?: string | null;
    fullResult?: string;
  }): boolean {
    const { profileId, profile, marketName, type, index, date, status, rec } = opts;
    if (!isCardTypeEnabled(profileId, type)) return false;
    const schTimeNorm = String(rec?.schTime || '').trim()
      ? String(rec.schTime).trim().padStart(5, '0')
      : '';
    const baseScheduleKey = profileId !== 'admin1'
      ? `vipauto_${profileId}_${date}_${type}_${index}`
      : (schTimeNorm
          ? `${profileId}_${date}_${type}_${index}_${schTimeNorm}`
          : `${profileId}_${date}_${type}_${index}`);
    const scheduleKey = baseScheduleKey + (rec.cardGeneration ? `_g${rec.cardGeneration}` : '');
    const dedupeKey = `${profileId}_${date}_${type}_${index}_${status}${rec.cardGeneration ? `_g${rec.cardGeneration}` : ''}`;
    if (botState.resultFollowUpSent[dedupeKey]) return false;

    let targets = Array.isArray(rec?.schTargets) ? rec.schTargets.filter(Boolean) : [];
    if (profileId !== 'admin1') {
      // If the play only reached a subset of live destinations, settle the
      // business play but reply only to recipients that actually saw it.
      const deliveredPlayTargets = normalizeTargetList(rec?.sentTargets || []);
      targets = deliveredPlayTargets.length > 0 ? deliveredPlayTargets : serverVipDeliveryTargets(profile);
    } else {
      // Reply to the actual play recipients even if the selection changed later.
      // Older cards without receipts retain the normal global-marker fallback.
      const deliveredPlayTargets = normalizeTargetList(rec?.sentTargets || []);
      targets = deliveredPlayTargets.length ? deliveredPlayTargets : resolveAdminScheduleTargets(targets);
    }
    if (targets.length === 0) return false;
    const liveBinding = bindLiveBroadcastTargets(targets);
    if (liveBinding.targets.length === 0) {
      // Result replies are real-time only. Do not create a backlog that can be
      // replayed after login/reconnect; lock this event's dedupe key instead.
      botState.resultFollowUpSent[dedupeKey] = true;
      persistResultFollowUps();
      return false;
    }
    targets = liveBinding.targets;

    // Freeze display evidence with this queued reply, just like the drawn digit.
    const drawn = String(opts.resultDigit || '').replace(/^OPEN\s+/, '');
    const close = /\bCLOSE\b/i.test(marketName) && !/^OPEN\s/.test(String(opts.resultDigit || ''));
    const displayParts: {openPanel?:string;openAnk?:string;jodi?:string;closePanel?:string;closeAnk?:string} = {};
    const baseName = (name: string) => name.trim().toUpperCase().replace(/\s+(OPEN|CLOSE)$/, '');
    // Only this profile's current ledger day and settled matching-market cards.
    // Never borrow a result from another date or another market.
    if (date === botState.ledgerState.date) for (const market of profile.markets || []) {
      if (baseName(String(market.n || '')) !== baseName(marketName)) continue;
      const card = profile.cards?.[`${market.type}_${market.index}`];
      if (!card || (card.s !== 'PASS' && card.s !== 'FAIL')) continue;
      const value = String(card.manualStatus ? card.manualResult || '' : card.scrapeResultDigit || '');
      const side = /\bCLOSE\b/i.test(String(market.n)) ? 'close' : 'open';
      if (market.type === 'ank' && /^\d$/.test(value)) displayParts[side === 'close' ? 'closeAnk' : 'openAnk'] = value;
      if (market.type === 'jodi' && /^\d{2}$/.test(value)) displayParts.jodi = value;
      const panel = String(card.manualPanelResult || (market.type === 'pannel' ? value : ''));
      if (/^\d{3}$/.test(panel)) displayParts[side === 'close' ? 'closePanel' : 'openPanel'] = panel;
    }
    if (type === 'jodi' && /^\d{2}$/.test(drawn)) displayParts.jodi = drawn;
    else if (type === 'pannel' || type === 'panel') displayParts[close ? 'closePanel' : 'openPanel'] = drawn;
    else displayParts[close ? 'closeAnk' : 'openAnk'] = drawn;
    const fullResult = opts.fullResult || formatFullDrawResult(displayParts);
    botState.resultFollowUpSent[dedupeKey] = true;
    botState.pendingBroadcasts.push({
      id: `srv_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      message: serverBuildPassFailMsg(
        marketName,
        status,
        type,
        rec,
        opts.resultDigit || null,
        profile?.detailedMessage !== false,
        fullResult,
      ),
      targets,
      createdAt: new Date().toISOString(),
      status: 'pending',
      scheduleKey,
      dedupeKey,
      profileId,
      cardType: type,
      broadcastKind: 'result-followup',
      index,
      marketName,
      resultDigit: opts.resultDigit || null,
      fullResult,
      priority: 10,
      platformSessions: liveBinding.sessions,
    });
    persistResultFollowUps();
    persistPendingBroadcasts();
    return true;
  }

  function serverBuildVipCardMsg(marketName: string, type: string, rec: any, detailedMessage = true, cardDate = '') {
    const digits = String(rec?.d || '').trim();
    const cardType = type === 'jodi' ? 'jodi' : (type === 'pannel' || type === 'panel' ? 'pannel' : 'ank');
    if (!detailedMessage) {
      return buildPremiumPlayCard({ marketName, digits, type: cardType, detailed: false, date: cardDate });
    }
    const rateNum = parseFloat(String(rec?.r || '0')) || 0;
    const count = digits ? digits.split(/[,|\s]+/).filter(Boolean).length : 0;
    const total = count * rateNum;
    return buildPremiumPlayCard({
      marketName, digits, type: cardType, detailed: true, rate: rateNum, total: rec?.smartStaking?.isSmartStaking ? rec.smartStaking.totalInvest : total, date: cardDate, smartStaking: rec?.smartStaking,
    });
  }

  /** One VIP destination authority shared by card delivery and result follow-up. */
  function serverVipDeliveryTargets(profile: any): string[] {
    const configured = normalizeTargetList(profile?.deliveryTargets);
    if (profile?.deliveryMode === 'group') {
      const canonical = normalizeTargetJid(profile?.vipGroupJid, 'group');
      return [...new Set([
        ...configured.filter(isGroupTarget),
        ...(canonical ? [canonical] : []),
      ])] as string[];
    }
    if (profile?.deliveryMode === 'channel') {
      const canonical = normalizeTargetJid(profile?.vipChannelJid, 'channel');
      return [...new Set([
        ...configured.filter(isChannelTarget),
        ...(canonical ? [canonical] : []),
      ])] as string[];
    }
    if (isTelegramTarget(profile?.phone)) return normalizeTargetList([profile.phone], 'phone');
    const canonical = normalizeTargetJid(profile?.phone, 'phone');
    return canonical ? [canonical] : [];
  }

  function profileProfitNotificationsEnabled(profileId: string, stored?: any): boolean {
    if (profileId === 'admin1') return botState.profitMilestoneNotificationsEnabled === true;
    return !isDeletedProfile(profileId) && (stored === undefined ? readFullAppStateView() : stored)?.profiles?.[profileId]?.profitMilestoneNotificationsEnabled === true;
  }

  function cancelProfileProfitNotifications(profileId: string) {
    for (const pending of botState.pendingBroadcasts) {
      if (pending.status !== 'pending' || pending.broadcastKind !== 'profit-milestone' || pending.profileId !== profileId) continue;
      pending.failedTargets = normalizeTargetList(pending.targets);
      finishResolvedBroadcast(pending, 'PROFIT_NOTIFICATIONS_DISABLED');
    }
    persistPendingBroadcasts();
  }

  /** Revalidate an alert against today's ledger before claiming/sending it. */
  function currentProfitAlertSummary(job: typeof botState.pendingBroadcasts[number]) {
    const ledger=botState.ledgerState;
    if (!job.profitDate || job.profitDate!==calculateBusinessDateIST() || ledger?.date!==job.profitDate) return null;
    const profile=ledger.profiles?.[String(job.profileId || '')];
    if(!profile)return null;
    const destinations=job.profileId==='admin1'?normalizeTargetList(botState.targetGroups):serverVipDeliveryTargets(profile);
    const destination=normalizeTargetList(job.targets)[0];
    if(!destination || !destinations.includes(destination))return null;
    const report=profitMilestoneLedger(profile,readFullAppStateView()?.profiles?.[String(job.profileId || '')],job.profitDate);
    const summary=destinations.length===1?calculateProfitMilestoneSummary(report):calculateProfitMilestoneSummary(report,destination);
    return summary.profit>=Number(job.profitMilestone || 1000)?summary:null;
  }

  /** Queue one live notification when a profile reaches a new ₹1,000 day-profit milestone. */
  function queueProfitMilestoneNotifications(profileIds?: string[]): number {
    const ledger = botState.ledgerState;
    if (!ledger?.profiles) return 0;
    const date = String(ledger.date || calculateBusinessDateIST());
    if (date !== calculateBusinessDateIST()) return 0;
    const allowedIds = profileIds ? new Set(profileIds.map(String)) : null;
    let queued = 0;
    const savedState = readFullAppStateView();

    for (const [profileId, profile] of Object.entries(ledger.profiles as Record<string, any>)) {
      if (allowedIds && !allowedIds.has(String(profileId))) continue;
      if (isDeletedProfile(profileId) || !profileProfitNotificationsEnabled(profileId, savedState)) continue;
      const configuredTargets = profileId === 'admin1'
        ? normalizeTargetList(botState.targetGroups)
        : serverVipDeliveryTargets(profile);
      const reportProfile=profitMilestoneLedger(profile,savedState?.profiles?.[profileId],date);
      // A single-destination profile has one business ledger. Older delivered
      // cards may predate sentTargets receipts, so destination filtering would
      // show only a late-day fragment (for example 4/10 markets). Multiple
      // destinations still require strict delivery-scoped summaries.
      const singleDestinationSummary = configuredTargets.length === 1
        ? calculateProfitMilestoneSummary(reportProfile)
        : null;
      for (const destination of configuredTargets) {
        // Business scope follows actual delivery history. A JODI-only group
        // never receives ANK/PANEL profit, while one mixed destination naturally
        // combines only the card types that were really delivered there.
        const summary = singleDestinationSummary || calculateProfitMilestoneSummary(reportProfile, destination);
        const milestone = reachedProfitMilestone(summary.profit, 1000);
        const milestoneKey = `${date}|${profileId}|${destination}`;
        const previousMilestone = Math.max(0, Number(profitMilestones[milestoneKey]) || 0);
        if (milestone < 1000 || milestone <= previousMilestone) continue;

        const liveBinding = bindLiveBroadcastTargets([destination]);
        if (liveBinding.targets.length === 0) continue;
        const dedupeKey = `profit_${date}_${profileId}_${destination}_${milestone}`;
        if (botState.pendingBroadcasts.some((item: any) =>
          item.status === 'pending' && String(item.dedupeKey || '') === dedupeKey
        )) continue;

        botState.pendingBroadcasts.push({
          id: `profit_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
          message: buildProfitMilestoneMessage(summary),
          targets: liveBinding.targets,
          createdAt: new Date().toISOString(),
          status: 'pending',
          dedupeKey,
          profileId,
          broadcastKind: 'profit-milestone',
          profitDate: date,
          profitMilestone: milestone,
          // Final business summary always follows result reply and any newly
          // unlocked recovery card for the same settlement cycle.
          priority: 30,
          platformSessions: liveBinding.sessions,
        });
        // Each profile + destination owns an independent milestone ladder.
        profitMilestones[milestoneKey] = milestone;
        queued++;
        botState.logs.unshift({
          id: `${Date.now()}_profit_milestone`, time: new Date().toLocaleTimeString(),
          msg: `💰 Profit milestone ${profileId} → ${destination}: ₹${milestone.toLocaleString('en-IN')} (current +₹${Math.round(summary.profit).toLocaleString('en-IN')})`,
          type: 'success',
        });
        if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
      }
    }

    if (queued > 0) {
      persistProfitMilestones();
      persistPendingBroadcasts();
    }
    return queued;
  }


  /**
   * Re-render only UNSENT structured card/reply jobs from live ledger state.
   * This keeps persisted queue text on the current presentation template after
   * an app upgrade or a Detailed/Simple toggle without touching sent history,
   * dedupe keys, targets, rates, settlement, or delivery state.
   */
  function refreshPendingFormattedMessages(profileId?: string): number {
    let changed = 0;
    for (const pending of botState.pendingBroadcasts || []) {
      if (pending?.status !== 'pending') continue;
      const pid = String(pending?.profileId || '');
      if (!pid || (profileId && pid !== profileId)) continue;
      if (pending.broadcastKind !== 'vip-auto-card' && pending.broadcastKind !== 'result-followup') continue;

      const runtimeProfile = botState.ledgerState?.profiles?.[pid];
      if (!runtimeProfile) continue;
      const type = String(pending.cardType || '');
      const index = Number(pending.index);
      const rec = Number.isFinite(index) ? runtimeProfile.cards?.[`${type}_${index}`] : null;
      if (!rec) continue;
      const marketName = String(
        pending.marketName ||
        runtimeProfile.markets?.find((market: any) => String(market?.type || '') === type && Number(market?.index) === index)?.n ||
        'CARD'
      );
      const detailedMessage = runtimeProfile.detailedMessage !== false;

      if (pending.broadcastKind === 'vip-auto-card') {
        pending.message = serverBuildVipCardMsg(marketName, type, rec, detailedMessage, String(botState.ledgerState?.date || calculateBusinessDateIST()));
        changed++;
      } else if (rec.s === 'PASS' || rec.s === 'FAIL') {
        pending.message = serverBuildPassFailMsg(
          marketName,
          rec.s,
          type,
          rec,
          pending.resultDigit || null,
          detailedMessage,
          pending.fullResult,
        );
        changed++;
      }
    }
    return changed;
  }

  // Upgrade-safe queue migration: old persisted pending cards/replies adopt the
  // current template immediately on restart. Already-sent history is untouched.
  const startupFormattedQueueRefresh = refreshPendingFormattedMessages();
  if (startupFormattedQueueRefresh > 0) persistPendingBroadcasts();

  /** Fail closed: an automatic result cannot settle a card before its market time. */
  function serverResultTimeReached(market: { hr?: number; min?: number }): boolean {
    const hr = Number(market?.hr);
    const min = Number(market?.min);
    if (!Number.isFinite(hr) || !Number.isFinite(min)) return true;
    const parts = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
    }).formatToParts(new Date());
    const nowHour = Number(parts.find((part) => part.type === 'hour')?.value || 0);
    const nowMinute = Number(parts.find((part) => part.type === 'minute')?.value || 0);
    const businessMinute = (hour: number, minute: number) => (hour < 6 ? 24 * 60 : 0) + hour * 60 + minute;
    // Five-minute tolerance covers sources that publish just before the listed cutoff.
    return businessMinute(nowHour, nowMinute) + 5 >= businessMinute(hr, min);
  }

  /**
   * VIP cards are event-driven, never clock-driven.
   * Rule: digits + rate available = card ready.
   * One in-flight WAIT card per profile/type blocks the next card until result settlement.
   */
  function enforceLoopAccountRun(pid:string,_type:string,nextInvest=0,key?:string,readState=readFullAppState):boolean {
    const full=readState===readFullAppState?readFullAppStateView():readState(),saved=full?.profiles?.[pid],runtime:any=botState.ledgerState?.profiles?.[pid],date=String(botState.ledgerState?.date||'');
    if(!runtime||date!==calculateBusinessDateIST())return true;
    const config=resolveLoopAccountConfig(saved,runtime,date);if(!config)return true;
    const previous:LoopAccountStops={...runtime.loopAccountStops,...saved?.dayRecords?.[date]?.loopAccountStops};
    const own=key?runtime.cards?.[key]:undefined;
    const decision=evaluateLoopAccounts(config,runtime,date,previous,{liveOnly:true,nextKey:key,nextInvest:deliveredLoopCard(own)?0:nextInvest,excludeKey:key});
    const claimed=new Set<string>();
    for(const job of botState.pendingBroadcasts)if(job.status==='pending'&&job.profileId===pid&&Object.values(job.claimedPlatforms||{}).some(Boolean))claimed.add(`${job.cardType}_${job.index}`);
    for(const [k,r] of Object.entries(runtime.cards||{}) as [string,any][])if(r.loopAccountReservation?.expiresAt>Date.now())claimed.add(k);
    const skipped=stopLoopUnsentCards(runtime,config,date,decision.stops,claimed);
    let cancelled=0;
    for(const job of botState.pendingBroadcasts){
      if(job.status!=='pending'||job.profileId!==pid||job.broadcastKind!=='vip-auto-card'||claimed.has(`${job.cardType}_${job.index}`))continue;
      const r=runtime.cards?.[`${job.cardType}_${job.index}`],market=runtime.markets?.find((m:any)=>m.type===job.cardType&&Number(m.index)===Number(job.index));
      const id=accountForCard(config,String(job.cardType),market?.n||r?.marketName||'',r);
      if(id&&decision.stops[loopAccountKey(id,job.cardType as any)]?.date===date){job.failedTargets=normalizeTargetList(job.targets);finishResolvedBroadcast(job,'LOOP_ACCOUNT_STOPPED');cancelled++;}
    }
    if(skipped||cancelled||JSON.stringify(previous)!==JSON.stringify(decision.stops)){
      runtime.loopAccountStops=decision.stops;
      botState.ledgerState.updatedAt=Date.now();persistLedgerSnapshot();if(cancelled)persistPendingBroadcasts();
      if(full&&saved){const next={...full,profiles:{...full.profiles,[pid]:{...saved,dayRecords:{...saved.dayRecords,[date]:{...saved.dayRecords?.[date],loopAccountStops:decision.stops}}}}};writeFullAppState(mergeLedgerIntoFullAppState(next));}
    }else runtime.loopAccountStops=previous;
    return decision.allowed;
  }

  function enforceVipGameRun(pid: string, type: string, nextInvest = 0, queuedKey?: string, readState = readFullAppStateView): boolean {
    if(!['ank','jodi','pannel'].includes(type))return true;
    if(!enforceLoopAccountRun(pid,type,nextInvest,queuedKey,readState))return false;
    if(pid==='admin1')return true;
    const full = readState();
    const saved = full?.profiles?.[pid];
    const runtime: any = botState.ledgerState?.profiles?.[pid];
    const date = String(botState.ledgerState?.date || '');
    if (!saved || !runtime || date !== calculateBusinessDateIST()) return true;
    if (clearVipOrphanedReservations(runtime, pid, botState.pendingBroadcasts, botState.sentSchedules)) {
      botState.ledgerState.updatedAt = Date.now(); persistLedgerSnapshot();
    }
    const reason = vipStopReason(pid, date, saved, runtime, type as any, nextInvest, queuedKey);
    if (!reason) return true;
    const previous = saved.vipGameRuns?.[type];
    const run = previous?.date === date && !previous.on ? previous : {
      date, on: false, baseProfit: previous?.date === date ? previous.baseProfit : 0,
      baseInvest: previous?.date === date ? previous.baseInvest : 0, baselineCards: previous?.date === date ? previous.baselineCards : undefined, reason, updatedAt: Date.now(),
    };
    runtime.vipGameRuns = { ...saved.vipGameRuns, [type]: run };
    const skipped = skipVipUnsentCards(runtime, type as any);
    let cancelled = 0;
    for (const job of botState.pendingBroadcasts) {
      if (job.status !== 'pending' || job.broadcastKind !== 'vip-auto-card' || job.profileId !== pid || job.cardType !== type) continue;
      job.failedTargets = normalizeTargetList(job.targets);
      finishResolvedBroadcast(job, 'VIP_GAME_STOPPED'); cancelled++;
    }
    if (previous !== run || skipped || cancelled) {
      const next = { ...full, profiles: { ...full.profiles, [pid]: { ...saved, vipGameRuns: runtime.vipGameRuns } } };
      botState.ledgerState.updatedAt = Date.now();
      persistLedgerSnapshot(); persistPendingBroadcasts();
      writeFullAppState(mergeLedgerIntoFullAppState(next));
    }
    return false;
  }

  function enforceVipLiveBoundary(pid: string, runtime: any, savedState?:any) {
    if (pid === 'admin1') return;
    const saved = (savedState===undefined?readFullAppStateView():savedState)?.profiles?.[pid];
    if (!saved?.vipLiveStart) return;
    for (const market of runtime?.markets || []) {
      if (!vipLiveMarketEligible(saved, String(botState.ledgerState?.date || ''), market.type, market.n)) market.enabled = false;
    }
  }

  function queueVipAutoReadyCards(reason = 'server') {
    return liveQueueClock.run(()=>queueVipAutoReadyCardsInBatch(reason));
  }
  function queueVipAutoReadyCardsInBatch(reason = 'server') {
    const ledger = botState.ledgerState;
    if (!ledger?.profiles) return 0;
    const date = String(ledger.date || calculateBusinessDateIST());
    let queued = 0;
    // Valid only during this synchronous queue pass. A game-stop write must
    // invalidate it before the next type/profile; never retain between requests.
    let snapshot: any, snapshotRevision = -1;
    const readQueueState = () => {
      if (snapshotRevision !== fullAppStateRevision) {
        snapshot = readFullAppStateView(); snapshotRevision = fullAppStateRevision;
      }
      return snapshot;
    };

    for (const [pid, prof] of Object.entries(ledger.profiles as Record<string, any>)) {
      if (pid === 'admin1' || isDeletedProfile(pid)) continue;
      enforceVipLiveBoundary(pid, prof, readQueueState());
      for (const type of ['ank', 'jodi', 'pannel']) enforceVipGameRun(pid, type, 0, undefined, readQueueState);
      if (prof?.vipAutoMode === false) continue;
      const deliveryTargets = serverVipDeliveryTargets(prof);
      if (deliveryTargets.length === 0) continue;
      const markets = Array.isArray(prof?.markets) ? prof.markets : [];
      const cards = prof?.cards || {};
      prof.recoveryState = prof.recoveryState || {};

      for (const type of ['ank', 'jodi', 'pannel']) {
        if (!enforceVipGameRun(pid, type, 0, undefined, readQueueState)) continue;
        if (!isCardTypeEnabled(pid, type)) continue;
        const typedMarkets = markets
          .filter((m: any) => String(m?.type || '') === type && m?.enabled !== false)
          .sort((a: any, b: any) => Number(a?.index || 0) - Number(b?.index || 0));

        // Use this profile's active financial lanes; source/backtest lanes do not advance live VIP recovery.
        const trackKeys: string[] = [...new Set<string>(typedMarkets.map((m: any) => String(serverRecoveryTrackKey(prof, type, m?.n))))];
        for (const trackKey of trackKeys) {
          const trackMarkets = typedMarkets.filter((m: any) => serverRecoveryTrackKey(prof, type, m?.n) === trackKey);
          const st = prof.recoveryState[trackKey] || { debt: 0 };
          const fromIndex = Number.isFinite(Number(st.fromIndex)) ? Number(st.fromIndex) : -1;

          // Self-heal an orphaned QUEUED lock. Delivery uses two HTTP calls
          // (mark_sent + ack_broadcast); if Termux/network drops one of them, the
          // queue item may be gone while the card remains QUEUED forever. In that
          // state every later scan used to think a card was still in flight and
          // the next VIP card was never sent.
          for (const m of trackMarkets) {
            const rec = cards[`${type}_${Number(m.index)}`];
            if (!rec || rec.dispatchState !== 'QUEUED') continue;
            const dispatchKey = String(rec.dispatchKey || '');
            const stillPending = botState.pendingBroadcasts.some((b: any) =>
              b.status === 'pending' && b.broadcastKind === 'vip-auto-card' &&
              String(b.profileId || '') === String(pid) &&
              String(b.cardType || '') === type && Number(b.index) === Number(m.index)
            );
            if (!stillPending && !(dispatchKey && botState.sentSchedules[dispatchKey])) {
              rec.dispatchState = undefined;
              rec.dispatchKey = undefined;
              rec.queuedAt = undefined;
            }
          }

          const queuePosition=vipQueuePosition(trackMarkets,cards,type,fromIndex,Number(prof.loopConfig?.revision||0));
          if(queuePosition.kind!=='candidate')continue;
          const readyMarket=queuePosition.market;

          const idx = Number(readyMarket.index);
          if (isCloseBlockedByOpenPassZero(pid, type, String(readyMarket.n || ''), readQueueState()?.profiles?.[pid])) continue;
          const rec = cards[`${type}_${idx}`];
          if (!rec || !String(rec.d || '').trim()) continue;
          const finalized = serverFinalizeVipReadyRate(prof, type, rec, trackKey);
          const rateNum = parseFloat(finalized.rate) || 0;
          if (rateNum <= 0) continue;

          const scheduleKey = `vipauto_${pid}_${date}_${type}_${idx}${rec.cardGeneration ? `_g${rec.cardGeneration}` : ''}`;
          const dedupeKey = scheduleKey;
          if (botState.sentSchedules[scheduleKey] || expiredBroadcastKeys[scheduleKey]) continue;
          if (botState.pendingBroadcasts.some((b: any) => b.status === 'pending' && (b.dedupeKey === dedupeKey || b.scheduleKey === scheduleKey))) continue;

          const digits = String(rec.d || '').trim();
          const count = countSettlementTokens(digits, type);
          const investTotal = rec?.smartStaking?.isSmartStaking && Number(rec.smartStaking.totalInvest) > 0
            ? Number(rec.smartStaking.totalInvest)
            : count * rateNum;
          if (!enforceVipGameRun(pid, type, investTotal, `${type}_${idx}`, readQueueState)) continue;
          const liveBinding = bindLiveBroadcastTargets(deliveryTargets);
          if (liveBinding.targets.length === 0) {
            // The card became ready while no configured transport was live. It is
            // a missed play, not future backlog. Keep it WAIT until its result so
            // chronological recovery does not jump ahead, but never send it later.
            rec.deliveryMissedAt = Date.now();
            rec.deliveryMissedReason = 'NO_LIVE_TRANSPORT';
            rec.deliveryPartial = undefined;
            expiredBroadcastKeys[scheduleKey] = true;
            persistExpiredBroadcastKeys();
            botState.ledgerState.updatedAt = Date.now();
            persistLedgerSnapshot();
            botState.logs.unshift({
              id: `${Date.now()}_vip_missed`, time: new Date().toLocaleTimeString(),
              msg: `⏭️ VIP AUTO missed (no live gateway) → ${pid} ${readyMarket.n} ${type.toUpperCase()}`, type: 'warning',
            });
            if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
            continue;
          }

          rec.deliveryMissedAt = undefined;
          rec.deliveryMissedReason = undefined;
          rec.deliveryPartial = undefined;
          rec.dispatchState = 'QUEUED';
          rec.dispatchKey = scheduleKey;
          rec.queuedAt = Date.now();

          botState.pendingBroadcasts.push({
            id: `vipauto_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
            message: serverBuildVipCardMsg(
              String(readyMarket.n || 'VIP CARD'),
              type,
              { ...rec, r: String(rateNum) },
              prof.detailedMessage !== false,
              date,
            ),
            targets: liveBinding.targets,
            createdAt: new Date().toISOString(),
            status: 'pending',
            scheduleKey,
            dedupeKey,
            profileId: pid,
            cardType: type,
            broadcastKind: 'vip-auto-card',
            cardGeneration: rec.cardGeneration,
            index: idx,
            digits,
            sourceMode: rec.sourceMode,
            scrapeSource: rec.scrapeSource,
            trick: rec.trick,
            rateNum,
            investTotal,
            schTime: '',
            schTargets: liveBinding.targets,
            marketName: String(readyMarket.n || ''),
            // Cards and result replies share one FIFO business lane. Older
            // unresolved cards drain first; after settlement the result reply
            // is inserted before the newly unlocked next card.
            priority: 10,
            platformSessions: liveBinding.sessions,
          });
          queued++;
          botState.logs.unshift({
            id: Date.now().toString(),
            time: new Date().toLocaleTimeString(),
            msg: `⚡ VIP AUTO reserved → ${pid} ${readyMarket.n} ${type.toUpperCase()} @ ₹${rateNum} | ${trackKey} loss ₹${finalized.debt} + target ₹${finalized.targetProfit} (${reason})`,
            type: 'success',
          });
          if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
        }
      }
    }

    if (queued > 0) {
      botState.ledgerState.updatedAt = Date.now();
      persistLedgerSnapshot();
      persistPendingBroadcasts();
      try {
        const full = readFullAppState();
        if (full) writeFullAppState(mergeLedgerIntoFullAppState(full));
      } catch (_) {}
    }
    compactPendingBroadcasts(80);
    return queued;
  }

  /**
   * Master/Admin schedules also need a backend-finalized next rate. Previously
   * only VIP auto cards consumed recoveryState on the server. If the dashboard
   * was closed after a FAIL, the admin schedule kept its old/default rate and
   * WhatsApp froze that stale value; opening the UI later merely displayed the
   * correct recovery suggestion. Finalize the first ready unsent Admin card in
   * every recovery track immediately after settlement.
   */
  function finalizeProfileReadyRates(profileId: string, reason = 'server', savedState?:any) {
    const prof: any = botState.ledgerState?.profiles?.[profileId];
    if (!prof?.cards || !Array.isArray(prof.markets)) return 0;
    const carryState=savedState===undefined?readFullAppStateView():savedState,savedProfile=carryState?.profiles?.[profileId];
    if(savedProfile?.customLoopChanges){
      const effective=loopSettingsForDate(savedProfile,botState.ledgerState.date);
      if(effective&&JSON.stringify(effective)!==JSON.stringify(prof.loopConfig)){
        const claimed=new Set<string>();
        for(const job of botState.pendingBroadcasts){
          if(job.status!=='pending'||job.profileId!==profileId||job.broadcastKind!=='vip-auto-card')continue;
          if(Object.values(job.claimedPlatforms||{}).some(Boolean)){claimed.add(`${job.cardType}_${job.index}`);continue;}
          job.failedTargets=normalizeTargetList(job.targets);finishResolvedBroadcast(job,'CUSTOM_LOOP_SETUP_CHANGED');
        }
        prof.loopConfig=effective;
        for(const [key,rec] of Object.entries(prof.cards) as [string,any][]){
          if(claimed.has(key)||rec.loopAccountReservation?.expiresAt>Date.now()||deliveredLoopCard(rec)||rec.manualStatus)continue;
          if(rec.dispatchState==='QUEUED'){delete rec.dispatchState;delete rec.dispatchKey;delete rec.queuedAt;}
          if(isLoopAssignmentFrozen(rec))continue;
          delete rec.loopId;delete rec.sentLoopId;delete rec.recRate;delete rec.prevLoss;delete rec.targetProfitWithLoss;
          delete rec.twoCardRecoveryShares;delete rec.twoCardRecoveryStrategy;
          if(!effective.enabled&&rec.loopAccountSkipped){rec.s='WAIT';delete rec.loopAccountSkipped;delete rec.loopAccountReason;}
          const legacyStop=savedProfile.vipGameRuns?.[key.split('_')[0]]?.reason;
          if(effective.enabled&&rec.vipAutoStopSkipped&&['TARGET_REACHED','CAPITAL_LIMIT'].includes(legacyStop)){
            rec.s='WAIT';delete rec.vipAutoStopSkipped;
          }
        }
        persistPendingBroadcasts();
      }
    }
    enforceVipLiveBoundary(profileId, prof,carryState);
    if(savedProfile?.config.autoRemoveResultUnique3!==undefined)prof.autoRemoveResultUnique3=savedProfile.config.autoRemoveResultUnique3===true;
    const uniqueHistoryProfile=savedProfile&&prof.autoRemoveResultDigit&&prof.autoRemoveResultUnique3?carryRuntimeProfile(savedProfile,botState.ledgerState.date,prof.cards,prof.markets):undefined;
    const inheritedCarry=profileId!=='admin1'&&savedProfile&&vipCopiesAdmin(savedProfile)&&carryState?.profiles?.admin1?.config?.autoCarryResultSix===true;
    const carryOwner=inheritedCarry?carryState!.profiles.admin1:savedProfile;
    const carryRuntime=inheritedCarry?botState.ledgerState.profiles.admin1:prof;
    const carryHistory=carryOwner&&(inheritedCarry||savedProfile?.config.autoCarryResultSix===true)?carryRuntimeProfile(carryOwner,botState.ledgerState.date,carryRuntime?.cards||{},carryRuntime?.markets||[]):undefined;
    if(savedProfile)prof.openToCloseCut=savedProfile.dayRecords?.[botState.ledgerState.date]?.openToCloseCut===true;
    if(savedProfile)prof.autoCarryResultSix=inheritedCarry||savedProfile.config.autoCarryResultSix===true;
    if(prof.autoCarryResultSix || (prof.autoRemoveResultDigit && prof.autoRemoveResultUnique3))for(const m of prof.markets)if(m.type==='ank'&&m.enabled!==false&&!prof.cards[`ank_${m.index}`])prof.cards[`ank_${m.index}`]={s:'WAIT',d:'',r:'',marketName:m.n};
    const savedReset=savedProfile?.config?.liveThreeFailReset;
    if(savedProfile?.config?.autoResultParity!==undefined)prof.autoResultParity=savedProfile.config.autoResultParity===true;
    if(savedReset!==undefined)prof.liveThreeFailReset=savedReset===true;
    if(savedProfile && botState.ledgerState.date===businessDateIST()) {
      prof.twoCardRecoveryVersion=2;
      prof.twoCardRecoveryLegacySplit = savedProfile.config?.twoCardRecoveryLegacySplit || prof.splitMode || {ank:true,pannel:true};
      if (savedProfile.config?.fourWaveRelay !== undefined) {
        prof.fourWaveRelay = savedProfile.config.fourWaveRelay === true;
      }
      if (!prof.splitMode) {
        prof.splitMode = {ank:savedProfile.config?.ankSplit!==false,pannel:savedProfile.config?.panSplit!==false};
      }
    }
    prof.recoveryState = prof.recoveryState || {};
    const cutResolver=createCutResolver({profile:savedProfile,date:botState.ledgerState.date,
      markets:prof.markets.filter((m:any)=>m.type==='ank'),
      cards:Object.fromEntries(Object.entries(serverLiveFinancialCards(prof)).filter(([key])=>key.startsWith('ank_')).map(([key,r])=>[key.slice(4),r])) as Record<string,DayMarketRecord>,
      track:(n)=>runtimeRecoveryTrack(prof,'ank',n)});
    let finalizedCount = 0;

    for (const type of ['ank', 'jodi', 'pannel']) {
      const typedMarkets = prof.markets
        .filter((m: any) => String(m?.type || '') === type && m?.enabled !== false)
        .sort((a: any, b: any) => Number(a?.index || 0) - Number(b?.index || 0));
      const trackKeys = [...new Set<string>(typedMarkets.map((m: any) => serverRecoveryTrackKey(prof, type, m?.n)))];
      for (const trackKey of trackKeys) {
        const trackMarkets = typedMarkets.filter((m: any) => serverRecoveryTrackKey(prof, type, m?.n) === trackKey);
        // Upgrade a saved OPEN miss that older builds left financially WAIT.
        if(type==='jodi')for(const market of trackMarkets){
          const rec=prof.cards[`jodi_${market.index}`];
          if(!rec||rec.s!=='WAIT'||rec.manualStatus||rec.deliveryRestoredAt||rec.jodiOpenStatus!=='FAIL'||jodiOpenSideStatus(rec.sentDigits||rec.d,rec.jodiOpenResult)!=='FAIL')continue;
          const delivered=Boolean(rec.sentAt||rec.sentRate||rec.sentDigits||rec.dispatchState==='SENT'||rec.dispatchState==='SETTLED');
          if(profileId!=='admin1'&&prof.vipAutoMode!==false&&!delivered)continue;
          const stake=calculateSettlement({type:'jodi',digits:rec.sentDigits||rec.d,rate:rec.r,sentRate:rec.sentRate,sentInvest:rec.sentInvest});
          if(!(stake.invest>0))continue;
          rec.s='FAIL';rec.dispatchState='SETTLED';rec.settledAt=rec.jodiOpenSettledAt||Date.now();finalizedCount++;
        }
        // Refresh any settled today card that was not sent to WhatsApp (!rec.sentAt) so toggling Smart Stake updates its stake & debt
        for (const m of trackMarkets) {
          const idx = Number(m.index);
          const rec = prof.cards[`${type}_${idx}`];
          if (!rec || (rec.s !== 'PASS' && rec.s !== 'FAIL') || rec.sentAt) continue;
          const priorState = serverSettledTrackState(prof, type, trackKey, idx, savedProfile);
          const isGenuineManual = Boolean(rec.manualRate && !rec.manualStatus && Number(rec.r) > 0);
          const isSplit = (type === 'ank' || type === 'pannel') && prof?.fourWaveRelay !== true && prof?.splitMode?.[type] !== false && !isGenuineManual;
          const baseTarget = runtimeTarget(prof, type, trackKey);
          const isProfitCarry = prof?.config?.profitCarry === true || prof?.profitCarry === true;
          const carriedProfit = isProfitCarry ? (priorState.pendingProfit || 0) : 0;
          const targetProfit = baseTarget + carriedProfit;
          const isOpenPassCloseZero = Boolean(prof?.openPassCloseZero || prof?.config?.openPassCloseZero);
          const isClose = (type === 'ank' || type === 'pannel') && /\s+CLOSE$/i.test(String(m?.n || ''));
          let isOpenPass = false;
          if (isOpenPassCloseZero && isClose) {
            const baseMarket = String(m?.n || '').replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
            const openName = `${baseMarket} OPEN`;
            const openCard: any = Object.values(prof.cards || {}).find((c: any) => String(c?.marketName || '').trim().toUpperCase() === openName);
            isOpenPass = openCard?.s === 'PASS';
          }
          const nextRate = (isOpenPass && !isGenuineManual) ? '0' : (isGenuineManual ? String(rec.r) : serverCalculateNextCardRate(type, String(rec.d || ''), priorState.debt, targetProfit));
          const smart = isSplit ? calculateSmartStakingRates(type, String(rec.d || ''), priorState.debt, targetProfit, rec.smartSelection?.strongDigits, rec.smartSelection?.supportDigits) : undefined;
          const tokenCnt = countSettlementTokens(rec.d, type);
          const nextInvest = smart?.isSmartStaking ? smart.totalInvest : tokenCnt * (parseFloat(nextRate) || 0);
          if (rec.r !== nextRate || rec.recRate !== nextRate || rec.prevLoss !== priorState.debt || rec.sentInvest !== nextInvest || JSON.stringify(rec.smartStaking) !== JSON.stringify(smart?.isSmartStaking ? smart : undefined)) {
            rec.r = nextRate;
            rec.recRate = nextRate;
            rec.sentRate = nextRate;
            rec.sentInvest = nextInvest;
            rec.prevLoss = priorState.debt;
            rec.targetProfitWithLoss = priorState.debt + targetProfit;
            if (smart?.isSmartStaking) rec.smartStaking = smart; else delete rec.smartStaking;
            if (!isGenuineManual) delete rec.manualRate;
            finalizedCount++;
          }
        }
        const actual = serverSettledTrackState(prof, type, trackKey, Infinity, savedProfile);
        let st = prof.recoveryState[trackKey] || { debt: 0, fromIndex: -1 };
        if (Number(st.debt || 0) !== actual.debt || Number(st.fromIndex ?? -1) !== actual.fromIndex || st.consecutiveFails!==actual.consecutiveFails || st.cyclesClosed!==actual.cyclesClosed) {
          st = { ...actual, updatedAt: Date.now() };
          prof.recoveryState[trackKey] = st;
          finalizedCount++;
        }
        const fromIndex = Number.isFinite(Number(st.fromIndex)) ? Number(st.fromIndex) : -1;
        const trackDebt = Math.max(0, Number(st.debt) || 0);
        const isSplitTrack = (type === 'ank' || type === 'pannel') && prof?.fourWaveRelay !== true && prof?.splitMode?.[type] !== false;
        const baseTarget = runtimeTarget(prof,type,trackKey);
        const isProfitCarryTrack = prof?.config?.profitCarry === true || prof?.profitCarry === true;
        const carriedProfit = isProfitCarryTrack ? (st.pendingProfit || 0) : 0;
        const targetProfit = baseTarget + carriedProfit;
        let recoveryAssigned = false;
        let removalAssigned = false;
        const logicReserved:Record<string,boolean>={};
        const logicRemoval:Record<string,boolean>={};

        for (const readyMarket of trackMarkets) {
          const idx = Number(readyMarket.index);
          const logicTrack=runtimeRecoveryTrack(prof,type,readyMarket.n);
          const logicState=runtimeRecoveryShareLedger(prof,type)?rebuildSettledTrackState(type,prof.markets,serverLiveFinancialCards(prof),logicTrack,name=>runtimeRecoveryTrack(prof,type,name),idx):undefined;
          const logicIndex=logicState?.fromIndex??fromIndex;
          const logicRecovery=runtimeRecoveryShareLedger(prof,type)?Boolean(logicReserved[logicTrack]):recoveryAssigned;
          const logicRemoved=runtimeRecoveryShareLedger(prof,type)?Boolean(logicRemoval[logicTrack]):removalAssigned;
          const rec = prof.cards[`${type}_${idx}`];
          if (!rec || rec.deliveryRestoredAt || (rec.s && rec.s !== 'WAIT' && !((rec as any).closeZeroAutoSkipped && rec.s === 'SKIP'))) continue;
          if (idx <= fromIndex) {
            if (!rec.sentAt && !rec.sentRate && rec.dispatchState !== 'SENT' && (Number(rec.prevLoss || 0) !== 0 || Boolean(rec.smartStaking?.isSmartStaking) !== Boolean((type === 'ank' || type === 'pannel') && prof?.splitMode?.[type] !== false && !(rec.manualRate && Number(rec.manualOverrideAt || 0) > 0 && Number(rec.r) > 0) && countSettlementTokens(rec.d, type) >= 3 && isRecoveryRatePossible(type, rec.d)))) {
              serverFinalizeVipReadyRate(prof, type, rec, trackKey, 0, 0);
              finalizedCount++;
            }
            continue;
          }
          const openCloseOriginal=prof.openToCloseCut===true||rec.openCloseCut?{...rec}:undefined;
          if (rec.sentRate || rec.sentDigits || rec.dispatchState === 'SENT' || rec.dispatchState === 'SETTLED') {
            // This delivered WAIT card already occupies the recovery position;
            // later suggestions are target-only until its result arrives.
            recoveryAssigned = true;
            logicReserved[logicTrack]=true;logicRemoval[logicTrack]=true;
            removalAssigned = true;
            continue;
          }
          const activeClaim=botState.pendingBroadcasts.some((b:any)=>b.status==='pending' && String(b.profileId||'')===profileId && String(b.cardType||'')===type && Number(b.index)===idx && Object.values(b.claimedPlatforms||{}).some(Boolean));
          if(activeClaim){recoveryAssigned=true;removalAssigned=true;logicReserved[logicTrack]=true;logicRemoval[logicTrack]=true;continue;}

          if(type==='ank'&&rec.openCloseCut){const peeled=restoreOpenCloseInput(rec,prof.openToCloseCut!==true);if(peeled!==rec){for(const key of Object.keys(rec))if(!(key in peeled))delete rec[key];Object.assign(rec,peeled);}}
          if (!String(rec.d || '').trim() && !rec.autoRemovedResult && !rec.carryResultSix && !prof.autoCarryResultSix && !(prof.autoRemoveResultDigit && prof.autoRemoveResultUnique3)) continue;
          if(type==='ank'){
            const carryIndex=inheritedCarry&&carryHistory?getEffectiveMarkets(carryHistory.config).findIndex(m=>m.n===readyMarket.n):idx;
            const cHist=prof.autoCarryResultSix&&carryHistory?carryResultSixHistory(carryHistory,botState.ledgerState.date,carryIndex,readyMarket.n,inheritedCarry?carryHistory.dayRecords[botState.ledgerState.date]?.data?.[carryIndex]:rec,10):[];
            const cStreak=prof.autoCarryResultSix&&carryHistory?findLoopFailStreak(carryHistory,botState.ledgerState.date,carryIndex,readyMarket.n,inheritedCarry?carryHistory.dayRecords[botState.ledgerState.date]?.data?.[carryIndex]:rec):{streakCount:0,failedCards:[],lastSettledCard:null};
            const cWin=prof.autoCarryResultSix&&carryHistory?collectCarryTenWindowAnalysis(carryHistory,botState.ledgerState.date,carryIndex,readyMarket.n,inheritedCarry?carryHistory.dayRecords[botState.ledgerState.date]?.data?.[carryIndex]:rec):undefined;
            const carried=applyCarryResultSix(rec,cHist,prof.autoCarryResultSix===true,cStreak.lastSettledCard,cStreak.streakCount,cStreak.failedCards,undefined,cWin);
            if(carried!==rec){Object.assign(rec,carried);for(const field of ['od','sourceMode','scrapeSource','trick','positionRule','marketModel','strictPanel30','autoRemovedResult','autoResultParity','firstDigitMirrorCut','triCut','sniperOne','tesla369','mssdState','masterFlow','liveCombinedCut','carryResultSix','scrapeResultDigit','manualResult','recRate','prevLoss','targetProfitWithLoss','rateFinalizedFrom','rateFinalizedAt'])if(!(field in carried))delete rec[field];finalizedCount++;}
          }
          if (type === 'ank' && !prof.autoCarryResultSix && rec.sourceMode!=='RESULT_CARRY6') {
            const candidate = areSettlementTokensValid('ank', autoRemovalInput(rec));
            const source = prof.cards[`ank_${logicIndex}`];
            const parity=applyResultParity(rec,prof.autoResultParity===true?cutResolver(idx,rec):undefined,prof.autoResultParity===true);
            if(parity!==rec){for(const key of ['autoRemovedResult','autoResultParity','trick','positionRule','rateFinalizedAt','rateFinalizedFrom'])if(!(key in parity))delete rec[key];Object.assign(rec,parity);finalizedCount++;}
            const uniqueHistory=prof.autoRemoveResultUnique3&&!logicRecovery&&!logicRemoved?uniqueHistoryProfile?carryResultSixHistory(uniqueHistoryProfile,botState.ledgerState.date,idx,readyMarket.n,rec,5):[]:undefined;
            const filtered = removePreviousResult(rec, logicRecovery || logicRemoved ? undefined : confirmedAnkResult(source), uniqueHistory?uniqueHistory.map(h=>h.key).join('|'):`${botState.ledgerState.date}:ank_${logicIndex}`, prof.autoRemoveResultDigit === true, prof.autoRemoveResultMirror === true,uniqueHistory?.map(h=>h.actual));
            if (filtered !== rec) { Object.assign(rec, filtered); finalizedCount++; }
            if (candidate) {removalAssigned = true;logicRemoval[logicTrack]=true;}
            if (!String(rec.d || '').trim()) continue;
          }
          if(type==='ank'&&prof.openToCloseCut===true){
            const ankMarkets=prof.markets.filter((m:any)=>m.type==='ank');
            const ankCards=Object.fromEntries(ankMarkets.map((m:any)=>[String(m.index),prof.cards[`ank_${m.index}`]]));
            const filtered=cutOpenActual(rec,sameMarketOpenActual(ankMarkets,ankCards,readyMarket.n));
            if(filtered&&filtered!==rec){for(const key of Object.keys(rec))if(!(key in filtered))delete rec[key];Object.assign(rec,filtered);finalizedCount++;}
          }
          if(type==='ank'&&openCloseOriginal&&rec.d===openCloseOriginal.d){
            if(openCloseOriginal.sourceEditedAt===undefined)delete rec.sourceEditedAt;else rec.sourceEditedAt=openCloseOriginal.sourceEditedAt;
            if(rec.openCloseCut)rec.openCloseCut={...rec.openCloseCut,outputVersion:Number(rec.sourceEditedAt||0)};
            for(const key of ['rateFinalizedAt','rateFinalizedFrom'])if(openCloseOriginal[key]!==undefined)rec[key]=openCloseOriginal[key];
          }
          if(type==='ank'&&!String(rec.d||'').trim())continue;
          const splitAllocation=runtimeRecoveryShareLedger(prof,type)
            ? serverShareRecoveryState(prof,type,trackKey).assignments[`${type}_${idx}`]||[] : undefined;
          const fwCardState = (!prof?.loopConfig?.enabled && prof?.fourWaveRelay === true)
            ? evaluateServerFourWaveType(prof, type as any, serverLiveFinancialCards(prof), idx).byIndex.get(idx)
            : undefined;
          const debtForCard = fwCardState
            ? (fwCardState.debt ?? 0)
            : (splitAllocation ? shareTotal(splitAllocation) : recoveryAssigned ? 0 : trackDebt);
          const profitCarryForCard = isProfitCarryTrack
            ? (fwCardState ? (fwCardState.pendingProfit ?? 0) : (recoveryAssigned ? 0 : carriedProfit))
            : 0;
          const targetProfitForCard = baseTarget + profitCarryForCard;
          const allocationChanged=splitAllocation!==undefined&&(JSON.stringify(rec.twoCardRecoveryShares)!==JSON.stringify(splitAllocation)||(!recoveryCardFrozen(rec)&&rec.twoCardRecoveryStrategy!==(prof.splitMode?.[type]!==false?'TWO':'ALL')));
          if(splitAllocation!==undefined)rec.twoCardRecoveryShares=splitAllocation;
          const explicitManualRate = rec.manualRate && Number(rec.manualOverrideAt || 0) > 0 && Number(rec.r) > 0
            ? String(Number(rec.r))
            : '';
          const profOpenPassCloseZero = Boolean(prof?.openPassCloseZero || prof?.config?.openPassCloseZero || savedProfile?.config?.openPassCloseZero || savedProfile?.openPassCloseZero);
          const isCloseReadyMkt = (type === 'ank' || type === 'pannel') && /\s+CLOSE$/i.test(String(readyMarket.n || ''));
          let isOpenPassReady = false;
          if (profOpenPassCloseZero && isCloseReadyMkt) {
            const bMkt = String(readyMarket.n || '').replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
            const oName = `${bMkt} OPEN`;
            const oMkt = prof.markets.find((om: any) => String(om?.type || '') === type && String(om?.n || '').trim().toUpperCase() === oName);
            const oRec = oMkt ? prof.cards[`${type}_${oMkt.index}`] : undefined;
            isOpenPassReady = oRec?.s === 'PASS';
          }
          if (isOpenPassReady && !explicitManualRate && !rec.sentAt) {
            if (rec.r !== '0' || rec.recRate !== '0' || rec.s !== 'SKIP' || rec.smartStaking) {
              rec.r = '0';
              rec.recRate = '0';
              rec.prevLoss = 0;
              rec.targetProfitWithLoss = 0;
              delete rec.smartStaking;
              if (!rec.manualStatus) {
                rec.s = 'SKIP';
                (rec as any).closeZeroAutoSkipped = true;
              }
              rec.rateFinalizedAt = Date.now();
              finalizedCount++;
            }
            if (Array.isArray(botState.activeSchedules)) {
              botState.activeSchedules = botState.activeSchedules.filter((s: any) =>
                !(String(s?.profileId || 'admin1') === profileId && String(s?.type || '') === type && Number(s?.index) === idx)
              );
            }
            continue;
          }
          if (!isOpenPassReady && (rec as any).closeZeroAutoSkipped && rec.s === 'SKIP' && !rec.manualStatus) {
            rec.s = 'WAIT';
            delete (rec as any).closeZeroAutoSkipped;
            delete rec.rateFinalizedAt;
            finalizedCount++;
          }
          const expectedRate = explicitManualRate || serverCalculateNextCardRate(type, String(rec.d || ''), debtForCard, targetProfitForCard);
          const expectSmartStaking = Boolean((type === 'ank' || type === 'pannel') && prof?.fourWaveRelay !== true && prof?.splitMode?.[type] !== false && !explicitManualRate && countSettlementTokens(rec.d, type) >= 3 && isRecoveryRatePossible(type, rec.d));
          const alreadyCurrent =
            String(rec.r || '') === expectedRate &&
            String(rec.recRate || '') === expectedRate &&
            Number(rec.prevLoss || 0) === debtForCard &&
            Number(rec.targetProfitWithLoss || 0) === debtForCard + targetProfitForCard &&
            Boolean(rec.smartStaking?.isSmartStaking) === expectSmartStaking &&
            Boolean(rec.rateFinalizedAt);
          if (!alreadyCurrent || allocationChanged) {
            serverFinalizeVipReadyRate(prof, type, rec, trackKey, debtForCard, profitCarryForCard);
            finalizedCount++;
          }
          // Digits/source may change while a manual or same-count rate stays
          // identical. Reconcile the unclaimed snapshot independently of money.
          // Active claims and delivered cards have already been skipped above.
          const queued = botState.pendingBroadcasts.find((b: any) =>
            b.status === 'pending' && b.broadcastKind === 'vip-auto-card' &&
            String(b.profileId || '') === profileId && String(b.cardType || '') === type &&
            Number(b.index) === idx && Number(b.cardGeneration || 0) === Number(rec.cardGeneration || 0)
          );
          if (queued && !rec.sentRate && rec.dispatchState === 'QUEUED') {
            const digits = String(rec.d || '').trim(), rateNum = Number(rec.r) || 0;
            const payload = {
              digits, sourceMode: rec.sourceMode, scrapeSource: rec.scrapeSource, trick: rec.trick,
              rateNum, investTotal: rec?.smartStaking?.isSmartStaking && Number(rec.smartStaking.totalInvest) > 0 ? Number(rec.smartStaking.totalInvest) : countSettlementTokens(digits, type) * rateNum,
              message: serverBuildVipCardMsg(String(readyMarket.n || queued.marketName || 'VIP CARD'),
                type, {...rec,r:String(rateNum)}, prof.detailedMessage !== false,
                String(botState.ledgerState?.date || calculateBusinessDateIST())),
            };
            // Relative support belongs to this digit set, not an older deferred payload.
            if (cardUsesPng(queued) && queued.digits !== digits) Object.assign(payload,
              cardPresentation({ ...queued, ...payload, digitSupport: undefined }));
            if (Object.entries(payload).some(([key,value]) => JSON.stringify((queued as any)[key]) !== JSON.stringify(value))) {
              Object.assign(queued, payload); persistPendingBroadcasts();
            }
          }
          if (profileId === 'admin1' && !rec.sentRate && Array.isArray(botState.activeSchedules)) {
            const schedDate = String(botState.ledgerState?.date || calculateBusinessDateIST());
            const activeSched = botState.activeSchedules.find((s: any) =>
              String(s?.profileId || 'admin1') === 'admin1' &&
              String(s?.type || '') === type &&
              Number(s?.index) === idx &&
              (!s?.date || String(s.date) === schedDate) &&
              !botState.sentSchedules[String(s?.key || '')]
            );
            if (activeSched) {
              const digits = String(rec.d || '').trim();
              const rateNum = Number(rec.r || rec.recRate || 0) || 0;
              const investTotal = rec?.smartStaking?.isSmartStaking && Number(rec.smartStaking.totalInvest) > 0
                ? Number(rec.smartStaking.totalInvest)
                : countSettlementTokens(digits, type) * rateNum;
              const nextMsg = rateNum > 0 && digits
                ? serverBuildVipCardMsg(String(readyMarket.n || activeSched.marketName || 'CARD'), type, { ...rec, d: digits, r: String(rateNum) }, prof.detailedMessage !== false, schedDate)
                : activeSched.message;
              if (
                activeSched.digits !== digits ||
                Number(activeSched.rateNum || 0) !== rateNum ||
                Number(activeSched.investTotal || 0) !== investTotal ||
                activeSched.message !== nextMsg
              ) {
                activeSched.digits = digits;
                activeSched.sourceMode = rec.sourceMode;
                activeSched.scrapeSource = rec.scrapeSource;
                activeSched.trick = rec.trick;
                activeSched.invest = String(rateNum);
                activeSched.rateNum = rateNum;
                activeSched.investTotal = investTotal;
                activeSched.message = nextMsg;
                delete (activeSched as any).senderFormat;
                delete (activeSched as any).broadcastPng;
                try {
                  atomicWriteFileAsync(path.join(titanDataDir, 'active_schedules.json'), JSON.stringify(botState.activeSchedules), 'active-schedules');
                } catch (_) {}
              }
            }
          }
          // An invalid/unsendable WAIT card cannot consume the pending recovery.
          if (expectedRate) {recoveryAssigned = true;logicReserved[logicTrack]=true;}
        }
      }
    }

    if (finalizedCount > 0) {
      botState.ledgerState.updatedAt = Date.now();
      botState.logs.unshift({
        id: `${Date.now()}_admin_rate`,
        time: new Date().toLocaleTimeString(),
        msg: `💹 ${profileId} next-rate finalized for ${finalizedCount} card(s) (${reason})`,
        type: 'success',
      });
      if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
    }
    if(prof.loopConfig?.independentAccounts)enforceLoopAccountRun(profileId,'ank');
    return finalizedCount;
  }

  function finalizeAllReadyRates(reason = 'server') {
    let count = 0;
    // One synchronous operation snapshot; never retained for later requests.
    const savedState=readFullAppStateView();
    const allPids = Object.keys(botState.ledgerState?.profiles || {}).sort((a, b) => (a === 'admin1' ? -1 : b === 'admin1' ? 1 : a.localeCompare(b)));
    for (const pid of allPids) {
      if (isDeletedProfile(pid)) continue;
      if (pid !== 'admin1') {
        const savedVip = savedState?.profiles?.[pid];
        const adminRuntime = botState.ledgerState?.profiles?.admin1;
        const vipRuntime = botState.ledgerState?.profiles?.[pid];
        if (savedVip && vipCopiesAdmin(savedVip) && adminRuntime?.cards && vipRuntime?.cards && Array.isArray(vipRuntime.markets)) {
          const liveDate = String(botState.ledgerState?.date || calculateBusinessDateIST());
          for (const m of vipRuntime.markets) {
            if (m?.enabled === false) continue;
            const t = String(m.type || '');
            const mName = String(m.n || '').trim().toUpperCase();
            if (!vipLiveMarketEligible(savedVip, liveDate, t as any, mName)) continue;
            const vipKey = `${t}_${m.index}`;
            const vipRec = vipRuntime.cards[vipKey] || { s: 'WAIT', d: '', r: '', marketName: mName };
            const vipFrozen = Boolean(vipRec.sentRate || vipRec.sentDigits || vipRec.sentAt || ['QUEUED', 'SENT', 'SETTLED'].includes(String(vipRec.dispatchState || '')) || vipRec.s === 'PASS' || vipRec.s === 'FAIL');
            if (vipFrozen) continue;
            const adminMarket = (adminRuntime.markets || []).find((am: any) => String(am?.type || '') === t && String(am?.n || '').trim().toUpperCase() === mName);
            const adminCard = adminMarket ? adminRuntime.cards[`${t}_${adminMarket.index}`] : undefined;
            if (adminCard && String(adminCard.d || '').trim() && String(vipRec.d || '').trim() !== String(adminCard.d || '').trim()) {
              const projected = projectAdminSource(vipRec as any, adminCard as any, mName, false, true);
              if (projected.d !== vipRec.d) {
                delete (projected as any).rateFinalizedAt;
                delete (projected as any).rateFinalizedFrom;
                vipRuntime.cards[vipKey] = projected;
                count++;
              }
            }
          }
        }
      }
      count += finalizeProfileReadyRates(pid, reason,savedState);
    }
    if (count > 0) {
      persistLedgerSnapshot();
      try {
        const full = readFullAppState();
        if (full) writeFullAppState(mergeLedgerIntoFullAppState(full));
      } catch (_) {}
    }
    return count;
  }

  function serverProcessPendingAudits() {
    return liveQueueClock.run(()=>serverProcessPendingAuditsInBatch());
  }
  function serverProcessPendingAuditsInBatch() {
    const ledger = botState.ledgerState;
    if (!ledger?.profiles || Object.keys(ledger.profiles).length === 0) {
      return { processed: 0, replies: 0, reason: 'no_ledger' };
    }
    let processed = 0;
    let replies = 0;
    let ledgerChanged = false;
    const date = ledger.date || calculateBusinessDateIST();

    for (const item of botState.pendingAuditResults) {
      if (item.processed) continue;
      // Once this exact event has marked the cards that existed at result time,
      // keep it queued only for frontend painting/ack. A later profile/card sync
      // must never let the old event settle newly-created business plays.
      // OPEN_ONLY -> FULL explicitly reopens the same item at ingestion below.
      const deferredBefore = item.deferredCards || {};
      const retryDeferred = item.serverMarked === true;
      if (retryDeferred && Object.keys(deferredBefore).length === 0) continue;
      const auditDate = String(item.mergeKey || '').split('|')[0];
      if (auditDate && auditDate !== String(date)) {
        // Never apply a persisted result from another business day to today's cards.
        item.processed = true;
        processed++;
        continue;
      }
      const text = String(item.text || '').trim();
      if (!text) {
        item.processed = true;
        processed++;
        ledgerChanged = true;
        continue;
      }
      const parsed = serverParseResult(text);
      // Freeze the market identity chosen when the result entered the queue.
      // Re-parsing a bare name later must never flip DAY → NIGHT as time passes.
      const queuedBase = String(item.mergeKey || '').split('|').slice(1).join('|').trim();
      if (queuedBase) parsed.marketBase = queuedBase;
      if (automaticResultError(text, parsed)) {
        item.processed = true;
        continue;
      }
      if (!parsed.marketBase) {
        // leave unprocessed for frontend if we can't parse market
        continue;
      }
      const markOpen = parsed.session === 'OPEN' || parsed.session === 'FULL';
      const markClose = parsed.session === 'CLOSE' || parsed.session === 'FULL';
      const baseUpper = parsed.marketBase.toUpperCase();
      let markedThis = 0;
      let repliesThis = 0;
      let earlyBlockedThis = false;
      const deferredNext: NonNullable<typeof item.deferredCards> = {};

      const savedProfilesForOpenPass = readFullAppStateView()?.profiles || {};
      for (const [pid, prof] of Object.entries(ledger.profiles)) {
        enforceVipLiveBoundary(pid, prof);
        if (!prof?.cards) continue;
        const markets = Array.isArray(prof.markets) ? prof.markets : [];

        for (const m of markets) {
          if ((m as any)?.enabled === false) continue;
          const type = m.type as string;
          const idx = m.index;
          const n = String(m.n || '').toUpperCase();

          // Schedule-type OFF only blocks WhatsApp result-followup broadcast.
          // Cards must still auto PASS/FAIL so ledger UI stays correct.
          const typeEnabled = isCardTypeEnabled(String(pid), type);

          const cardBase = n.replace(/\s+(OPEN|CLOSE)$/i, '').trim();
          // Strict: SRIDEVI ≠ SRIDEVI NIGHT (no loose includes)
          const normBase = (s: string) =>
            s.replace(/^(?:SHRIDEVI|SRIDEVI|SRIDEV)\s+DAY\b/, 'SRIDEVI').replace(/^SRIDEV\b/, 'SRIDEVI').replace(/^SHRIDEVI\b/, 'SRIDEVI').replace(/\s+/g, ' ').trim();
          const rb = normBase(baseUpper);
          const cb = normBase(cardBase);
          if (rb !== cb) continue;

          const resultTimingMarket = type === 'jodi' && markOpen && !markClose
            ? markets.find((candidate: any) =>
                String(candidate?.type || '') === 'ank' &&
                String(candidate?.n || '').toUpperCase() === `${cardBase} OPEN`
              ) || m
            : m;
          if (!serverResultTimeReached(resultTimingMarket as any)) {
            earlyBlockedThis = true;
            botState.logs.unshift({
              id: `${Date.now()}_early_result`,
              time: new Date().toLocaleTimeString(),
              msg: `🛡️ Early result blocked: ${parsed.marketBase} → ${n} before ${String((m as any).hr).padStart(2, '0')}:${String((m as any).min).padStart(2, '0')}`,
              type: 'warning',
            });
            if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
            continue;
          }

          const isOpenCard = n.includes('OPEN');
          const isCloseCard = n.includes('CLOSE');
          if (type === 'ank' || type === 'pannel') {
            if (isOpenCard && !markOpen) continue;
            if (isCloseCard && !markClose) continue;
          }

          const cardKey = `${type}_${idx}`;
          const cardIdentity = `${String(pid)}|${cardKey}`;
          if (Array.isArray((item as any).ignoredCardKeys) && (item as any).ignoredCardKeys.includes(cardIdentity)) continue;
          const rec = prof.cards[cardKey];
          if(rec&&type==='ank'&&rec.s==='SKIP'&&rec.liveCombinedCut?.reason){
            const actual=isCloseCard?(parsed.closeAnk||parsed.openAnk):(parsed.openAnk||parsed.closeAnk);
            const observed=observeLiveCombinedSkip(rec as DayMarketRecord,actual,date);
            if(observed!==rec){prof.cards[cardKey]=observed;ledgerChanged=true;}
            continue;
          }
          if (!rec || rec.deliveryRestoredAt || !rec.d) continue;
          if (retryDeferred) {
            const original = deferredBefore[cardIdentity];
            const failedOriginalAttempt = original && original.dispatchKey && expiredBroadcastKeys[original.dispatchKey] && rec.deliveryMissedAt && !rec.dispatchKey && !rec.sentAt;
            if (!original || original.marketName !== n || (!failedOriginalAttempt && original.dispatchKey !== String(rec.dispatchKey || '')) || original.digits !== String(rec.sentDigits || rec.d).split(/[,|\s]+/).filter(Boolean).join(',')) continue;
          }

          // A published result ends the play window immediately. Do not let a
          // slow multi-target Telegram delivery continue sending the old play
          // after its outcome is already known. Any recipients already reached
          // remain a real (possibly partial) business play; zero-delivery SKIPs.
          if (String(pid) !== 'admin1' && prof.vipAutoMode !== false) {
            const deliveryAtResult = closeVipLiveDeliveryForResult(String(pid), type, Number(idx));
            // Do not decide SKIP while a gateway owns this delivery attempt.
            // serverProcessPendingAudits runs every 5 seconds and will apply the
            // same result after the send ACK records SENT, or SKIP after a real
            // delivery failure/expiry.  Business settlement rules are unchanged.
            if (deliveryAtResult.inFlight) {
              deferredNext[cardIdentity] = {
                marketName: n,
                digits: String(rec.sentDigits || rec.d).split(/[,|\s]+/).filter(Boolean).join(','),
                dispatchKey: String(rec.dispatchKey || ''),
              };
              continue;
            }
          }

          // The exact stale audit/card pair is blocked above. A later audit is
          // a genuinely new result, so release WAIT and allow normal marking.
          if (rec.manualStatus && rec.s === 'WAIT') {
            rec.manualStatus = undefined;
            rec.manualOverrideAt = undefined;
          } else if (rec.manualStatus) {
            continue;
          }
          if (rec.s === 'PASS' || rec.s === 'FAIL' || rec.s === 'SKIP') continue;
          if ((type === 'ank' || type === 'pannel') && isCloseCard && !rec.sentAt && !rec.manualRate) {
            const profOpenPassCloseZero = Boolean(prof?.openPassCloseZero || prof?.config?.openPassCloseZero || savedProfilesForOpenPass?.[String(pid)]?.config?.openPassCloseZero);
            if (profOpenPassCloseZero) {
              const oName = `${cardBase} OPEN`;
              const oMkt = markets.find((om: any) => String(om?.type || '') === type && String(om?.n || '').trim().toUpperCase() === oName);
              const oRec = oMkt ? prof.cards[`${type}_${oMkt.index}`] : Object.entries(prof.cards || {}).find(([k, v]: [string, any]) => k.startsWith(`${type}_`) && String(v?.marketName || '').trim().toUpperCase() === oName)?.[1];
              if (oRec?.s === 'PASS') {
                rec.s = 'SKIP';
                rec.r = '0';
                rec.recRate = '0';
                delete rec.smartStaking;
                (rec as any).closeZeroAutoSkipped = true;
                ledgerChanged = true;
                continue;
              }
            }
          }

          // VIP Auto business truth: an automatic play only exists after full
          // live delivery. A missed/partial transport event must never create a
          // fake PASS/FAIL, recovery debt, or result reply. Manual/VIP-Auto-OFF
          // ledger behavior stays unchanged.
          const vipHasLiveTargets = String(pid) !== 'admin1' && prof.vipAutoMode !== false && botState.autoSendEnabled && serverVipDeliveryTargets(prof).length > 0 && isCardTypeEnabled(String(pid), type);
          if (vipHasLiveTargets) {
            const actuallyDelivered = Boolean(
              rec.sentAt || rec.sentRate || rec.sentDigits ||
              rec.dispatchState === 'SENT' || rec.dispatchState === 'SENT_PARTIAL' || rec.dispatchState === 'SETTLED'
            );
            if (!actuallyDelivered) {
              if (rec.deliveryMissedAt) {
                rec.s = 'SKIP';
                rec.manualStatus = undefined;
                rec.manualOverrideAt = undefined;
                rec.dispatchState = undefined;
                rec.settledAt = Date.now();
                (item as any).markedCardKeys = Array.isArray((item as any).markedCardKeys)
                  ? [...new Set([...(item as any).markedCardKeys, cardIdentity])]
                  : [cardIdentity];
                markedThis++;
                ledgerChanged = true;
                botState.logs.unshift({
                  id: `${Date.now()}_delivery_skip`, time: new Date().toLocaleTimeString(),
                  msg: `⏭️ VIP result skipped for undelivered card: ${String(pid)} ${n} ${type.toUpperCase()} (${rec.deliveryMissedReason || 'LIVE_DELIVERY_MISSED'})`,
                  type: 'warning',
                });
                if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
              }
              continue;
            }
          } else if (!rec.sentRate && !rec.sentAt) {
            const tk = serverRecoveryTrackKey(prof, type, String(m.n || ''));
            const priorSt = serverSettledTrackState(prof, type, tk, Number(idx));
            serverFinalizeVipReadyRate(prof, type, rec, tk, priorSt.debt);
          }

          // An OPEN miss makes every selected pair impossible: settle FAIL now.
          // An OPEN match still waits for the full pair for financial settlement.
          if (type === 'jodi' && markOpen && parsed.openAnk && (rec.jodiOpenStatus !== 'PASS' && rec.jodiOpenStatus !== 'FAIL' || rec.jodiOpenStatus==='FAIL'&&rec.s==='WAIT')) {
            const openStatus = jodiOpenSideStatus(String(rec.sentDigits || rec.d || ''), parsed.openAnk);
            if (!openStatus) continue;
            const settled = calculateSettlement({
              type: 'jodi', digits: rec.sentDigits || rec.d, rate: rec.r,
              sentRate: rec.sentRate, sentInvest: rec.sentInvest,
            });
            const trackKey = serverRecoveryTrackKey(prof, type, String(m.n || ''));
            const priorDebt = Math.max(0, Number(prof.recoveryState?.[trackKey]?.debt ?? rec.prevLoss) || 0);
            const priorOpenFailure=rec.jodiOpenStatus==='FAIL';
            const nextDebt = openStatus === 'FAIL' ? (priorOpenFailure?serverSettledTrackState(prof,type,trackKey).debt:priorDebt + settled.invest) : 0;
            rec.jodiOpenStatus = openStatus;
            rec.jodiOpenResult = String(parsed.openAnk);
            rec.jodiOpenSettledAt = Date.now();
            if(openStatus==='FAIL'&&!markClose){
              rec.s='FAIL';rec.dispatchState='SETTLED';rec.settledAt=rec.jodiOpenSettledAt;
              delete rec.manualStatus;delete rec.manualOverrideAt;delete rec.manualResultSources;
            }
            prof.recoveryState = prof.recoveryState || {};
            prof.recoveryState[trackKey] = {
              debt: nextDebt,
              fromCardKey: cardKey,
              fromIndex: Number(idx),
              updatedAt: Date.now(),
            };
            if(prof.liveThreeFailReset===true)prof.recoveryState[trackKey]={...serverSettledTrackState(prof,type,trackKey),updatedAt:Date.now()};
            ledgerChanged = true;
            if (!markClose) {
              (item as any).markedCardKeys = Array.isArray((item as any).markedCardKeys)
                ? [...new Set([...(item as any).markedCardKeys, cardIdentity])]
                : [cardIdentity];
              markedThis++;
              finalizeProfileReadyRates(String(pid), `jodi-open-${openStatus.toLowerCase()}`);
              if(openStatus==='FAIL'&&typeEnabled&&serverQueueResultFollowUp({profileId:String(pid),profile:prof,marketName:String(m.n),type,index:Number(idx),date,status:'FAIL',rec,resultDigit:`OPEN ${parsed.openAnk}`,fullResult:formatFullDrawResult(parsed)})){repliesThis++;replies++;}
            }
            botState.logs.unshift({
              id: `${Date.now()}_jodi_open_recovery`, time: new Date().toLocaleTimeString(),
              msg: `🎯 JODI OPEN ${openStatus}: ${String(pid)} ${String(m.n)} O:${parsed.openAnk} | next loss ₹${nextDebt}`,
              type: openStatus === 'PASS' ? 'success' : 'warning',
            });
            if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
          }
          if (type === 'jodi' && markOpen && !markClose) continue;

          let winning = '';
          let resultDigit: string | null = null;
          let mode: 'ank' | 'jodi' | 'panel' = 'ank';
          if (type === 'jodi') {
            winning = parsed.jodi || `${parsed.openAnk || ''}${parsed.closeAnk || ''}`;
            if (!/^\d{2}$/.test(winning) && /^\d$/.test(String(rec.jodiOpenResult || '')) && /^\d$/.test(parsed.closeAnk)) winning = `${rec.jodiOpenResult}${parsed.closeAnk}`;
            if (!/^\d{2}$/.test(winning)) continue;
            resultDigit = winning || null;
            mode = 'jodi';
          } else if (type === 'pannel') {
            winning = isCloseCard
              ? parsed.closePanel || parsed.openPanel
              : parsed.openPanel || parsed.closePanel;
            resultDigit = winning || null;
            mode = 'panel';
          } else {
            winning = isCloseCard
              ? parsed.closeAnk || parsed.openAnk
              : parsed.openAnk || parsed.closeAnk;
            resultDigit = winning || null;
            mode = 'ank';
          }
          if (!winning) continue;

          const isHit = serverTokenHit(String(rec.sentDigits || rec.d || ''), winning, mode);
          const status: 'PASS' | 'FAIL' = isHit ? 'PASS' : 'FAIL';
          rec.s = status;
          if (type === 'ank' && /^\d$/.test(winning)) rec.scrapeResultDigit = winning;
          if (type === 'ank' && /^\d$/.test(winning) && rec.weekdaySelectedDigits) {
            const selected = String(rec.weekdaySelectedDigits).match(/\d/g) || [];
            if (selected.length === 6) rec.weekdayHitPosition = Math.max(0, selected.indexOf(winning) + 1);
          }
          rec.manualStatus = undefined;
          rec.manualOverrideAt = undefined;
          delete rec.manualResultSources;
          delete rec.manualPanelResult;
          (item as any).markedCardKeys = Array.isArray((item as any).markedCardKeys)
            ? [...new Set([...(item as any).markedCardKeys, cardIdentity])]
            : [cardIdentity];
          markedThis++;
          ledgerChanged = true;

          rec.dispatchState = 'SETTLED';
          rec.settledAt = Date.now();

          // Update SERVER-OWNED recovery state for the exact OPEN/CLOSE/ALL track.
          // We do not blindly assign recovery to the immediate chronological card:
          // if that slot has no digits, the next actually-ready card receives it.
          const currentDigits = String(rec.sentDigits || rec.d || '');
          const trackKey = serverRecoveryTrackKey(prof, type, String(m.n || ''));
          const targetProfit = runtimeTarget(prof,type,trackKey);
          const settled = calculateSettlement({
            type,
            digits: currentDigits,
            rate: rec.r,
            sentRate: rec.sentRate,
            sentInvest: rec.sentInvest,
            smartStaking: rec.smartStaking,
          });
          if (!rec.sentAt && !rec.sentRate && settled.rate > 0 && settled.invest > 0) {
            rec.r = String(settled.rate);
            rec.recRate = String(settled.rate);
            rec.sentRate = String(settled.rate);
            rec.sentInvest = settled.invest;
          }
          prof.recoveryState = prof.recoveryState || {};
          const settledTrackState = serverSettledTrackState(prof, type, trackKey);
          const nextDebt = settledTrackState.debt;
          prof.recoveryState[trackKey] = {
            ...settledTrackState,
            fromCardKey: settledTrackState.fromCardKey || cardKey,
            fromIndex: Number.isFinite(Number(settledTrackState.fromIndex)) && Number(settledTrackState.fromIndex) >= 0 ? Number(settledTrackState.fromIndex) : Number(idx),
            updatedAt: Date.now(),
          };
          // Handoff must happen after EACH settlement, not once after the whole
          // pending-audit batch. With the dashboard closed several audits may be
          // waiting together; delaying finalization let the following card keep
          // its default rate until the browser opened and synced again.
          finalizeProfileReadyRates(String(pid), 'result-card-settlement');
          botState.logs.unshift({
            id: `${Date.now()}_recovery`,
            time: new Date().toLocaleTimeString(),
            msg: `💹 VIP recovery ${String(pid)} ${String(m.n)} ${status} | ${trackKey} loss ₹${nextDebt} + target ₹${targetProfit}`,
            type: 'info',
          });
          if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
          ledgerChanged = true;

          // If a later card is already ready, queueVipAutoReadyCards() below will
          // finalize its rate from this recoveryState and send it immediately.

          if (typeEnabled && serverQueueResultFollowUp({
            profileId: String(pid), profile: prof, marketName: String(m.n),
            type, index: Number(idx), date, status, rec, resultDigit, fullResult: formatFullDrawResult(parsed),
          })) {
            repliesThis++;
            replies++;
          }
        }
      }

      if (repliesThis > 0) {
        try { persistResultFollowUps(); } catch (_) {}
      }

      // Keep unprocessed so open dashboard can apply the same PASS/FAIL on UI cards.
      // WA replies already queued with dedupeKey — frontend will not double-send.
      // Frontend acks after painting marks.
      item.deferredCards = deferredNext;
      if (markedThis > 0 || Object.keys(deferredNext).length > 0 || retryDeferred) {
        (item as any).serverMarked = true;
        (item as any).serverMarkedCount = Number(item.serverMarkedCount || 0) + markedThis;
        processed++;
        botState.logs.unshift({
          id: Date.now().toString(),
          time: new Date().toLocaleTimeString(),
          msg: `🤖 Server auto PASS/FAIL: ${parsed.marketBase} (${parsed.session}) · ${markedThis} card(s) · ${repliesThis} reply · waiting UI ack`,
          type: 'success',
        });
        if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
      } else if (earlyBlockedThis) {
        item.processed = true;
        (item as any).rejectedEarly = true;
        processed++;
        botState.logs.unshift({
          id: `${Date.now()}_early_rejected`,
          time: new Date().toLocaleTimeString(),
          msg: `🛡️ Rejected early result: ${parsed.marketBase} (${parsed.session}) — no card changed`,
          type: 'warning',
        });
        if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
      } else {
        botState.logs.unshift({
          id: Date.now().toString(),
          time: new Date().toLocaleTimeString(),
          msg: `⏳ Result parsed (${parsed.marketBase} O:${parsed.openAnk || '-'} C:${parsed.closeAnk || '-'}) — no WAIT ledger card, left for dashboard`,
          type: 'info',
        });
        if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
      }
    }

    if (ledgerChanged) {
      // Must run before persistence and before the schedule bot can claim the
      // next Admin slot, otherwise an old/default rate may be delivered.
      finalizeAllReadyRates('result-settlement');
      botState.ledgerState.updatedAt = Date.now();
      persistLedgerSnapshot();
      try {
        const full = readFullAppState();
        if (full) writeFullAppState(mergeLedgerIntoFullAppState(full));
      } catch (_) {}
    }

    persistPendingAudits();
    persistPendingBroadcasts();

    // Result settlement unlocks the next recovery card only after PASS/FAIL and
    // calculation are committed. Profit milestone is deliberately queued last.
    queueVipAutoReadyCards('result-settlement');
    if (ledgerChanged) queueProfitMilestoneNotifications();

    // Cap follow-up dedupe map
    const rfKeys = Object.keys(botState.resultFollowUpSent);
    if (rfKeys.length > 500) {
      rfKeys.slice(0, rfKeys.length - 300).forEach((k) => delete botState.resultFollowUpSent[k]);
    }
    compactPendingBroadcasts(80);

    return { processed, replies };
  }

  // BUG FIX: A restored ledger may already contain FAIL debt + a stale next rate.
  // Reconcile once on backend boot so opening the UI is never the trigger.
  setTimeout(() => {
    try {
      restoreSavedAdminSchedules();
      serverProcessPendingAudits();
      finalizeAllReadyRates('backend-startup');
      // Delivery is real-time only: boot may reconcile calculations, but must
      // never reconstruct/send an old ready VIP card from a restored snapshot.
    } catch (error: any) {
      console.error('Backend startup recovery reconciliation failed:', error?.message || error);
    }
  }, 0);

  // Browser-independent retry loop. If a result arrives before the ledger snapshot
  // syncs, it is processed as soon as the snapshot becomes available.
  setInterval(() => {
    try {
      restoreSavedAdminSchedules();
      serverProcessPendingAudits();
    } catch (_) {}
  }, 5000);

  // Sync WhatsApp Groups / Channels / Contacts from Bot
  app.post("/api/bot/sync_chats", (req, res) => {
    const { groups, channels, contacts } = req.body;
    if (Array.isArray(groups)) botState.syncedGroups = groups;
    if (Array.isArray(channels)) {
      botState.syncedChannels = channels
        .map((channel: any) => {
          const jid = normalizeTargetJid(channel?.jid, 'channel');
          return jid ? { jid, name: String(channel?.name || jid) } : null;
        })
        .filter((channel: any): channel is { jid: string; name: string } => Boolean(channel));
      persistKnownChannels();
    }
    if (Array.isArray(contacts)) {
      const existingMap = new Map(botState.syncedContacts.map((c) => [c.jid, c]));
      contacts.forEach((c) => {
        if (c && c.jid) {
          existingMap.set(c.jid, {
            jid: c.jid,
            name: c.name || c.phone || c.jid.split('@')[0],
            phone: c.phone || c.jid.split('@')[0]
          });
        }
      });
      botState.syncedContacts = Array.from(existingMap.values());
    }
    botState.lastSyncTime = new Date().toISOString();

    botState.logs.unshift({
      id: Date.now().toString(),
      time: new Date().toLocaleTimeString(),
      msg: `Synced ${botState.syncedGroups.length} WA Groups, ${botState.syncedChannels.length} Channels & ${botState.syncedContacts.length} Contacts from Bot`,
      type: 'info'
    });
    if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);

    res.json({
      status: "success",
      groupsCount: botState.syncedGroups.length,
      channelsCount: botState.syncedChannels.length,
      contactsCount: botState.syncedContacts.length
    });
  });

  // Get Synced WhatsApp Groups & Contacts for Web App Target Selector
  app.get("/api/bot/chats", (_req, res) => {
    const channels = botState.syncedChannels;
    res.json({
      status: "success",
      groups: botState.syncedGroups,
      channels,
      contacts: botState.syncedContacts,
      chats: {
        groups: botState.syncedGroups,
        channels,
        contacts: botState.syncedContacts,
        lastSync: botState.lastSyncTime
      }
    });
  });

  app.get("/api/bot/synced_chats", (_req, res) => {
    const channels = botState.syncedChannels;
    res.json({
      status: "success",
      groups: botState.syncedGroups,
      channels,
      contacts: botState.syncedContacts
    });
  });

  // Resolve a public WhatsApp Channel link or @newsletter JID through the connected Baileys bot.
  app.post("/api/bot/resolve_channel", (req, res) => {
    const raw = String(req.body?.channelLink || req.body?.invite || '').trim();
    const cleanJid = normalizeTargetJid(raw, 'channel');
    if (cleanJid && cleanJid.endsWith('@newsletter')) {
      const existing = new Map(botState.syncedChannels.map((c) => [c.jid, c]));
      if (!existing.has(cleanJid)) {
        existing.set(cleanJid, { jid: cleanJid, name: String(req.body?.name || cleanJid.split('@')[0]) });
        botState.syncedChannels = Array.from(existing.values());
        botState.lastSyncTime = new Date().toISOString();
        persistKnownChannels();
      }
      return res.json({ status: 'success', resolved: true, jid: cleanJid });
    }
    const match = raw.match(/(?:https?:\/\/)?(?:www\.)?whatsapp\.com\/channel\/([A-Za-z0-9_-]+)/i);
    const invite = match?.[1] || (/^[A-Za-z0-9_-]{8,}$/.test(raw) ? raw : '');
    if (!invite) {
      return res.status(400).json({ status: 'error', message: 'Valid WhatsApp Channel link ya @newsletter JID paste karein.' });
    }
    const existing = botState.pendingChannelInvites.find((item) => item.invite === invite);
    const request = existing || { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, invite };
    if (!existing) botState.pendingChannelInvites.push(request);
    res.json({ status: 'success', pending: true, requestId: request.id });
  });

  app.post("/api/bot/channel_resolved", (req, res) => {
    const requestId = String(req.body?.requestId || '');
    botState.pendingChannelInvites = botState.pendingChannelInvites.filter((item) => item.id !== requestId);
    const jid = normalizeTargetJid(req.body?.jid, 'channel');
    if (jid) {
      const name = String(req.body?.name || jid);
      const existing = new Map(botState.syncedChannels.map((channel) => [channel.jid, channel]));
      existing.set(jid, { jid, name });
      botState.syncedChannels = Array.from(existing.values());
      botState.lastSyncTime = new Date().toISOString();
      persistKnownChannels();
    }
    res.json({ status: 'success' });
  });

  /** Persist sent schedule keys so server restart / dashboard reopen doesn't resend all */
  const sentSchedulesFile = path.join(titanDataDir, 'titan_sent_schedules.json');
  try {
    if (fs.existsSync(sentSchedulesFile)) {
      const raw = JSON.parse(fs.readFileSync(sentSchedulesFile, 'utf-8'));
      if (raw && typeof raw === 'object') botState.sentSchedules = raw;
    }
  } catch (_) {}
  function persistSentSchedules() {
    atomicWriteFileAsync(sentSchedulesFile, JSON.stringify(botState.sentSchedules || {}), 'sent-schedules');
  }

  /** Only fire within configured minutes after schTime (prevents all-day backlog dump). */

  app.post('/api/bot/delete_profile', (req, res) => {
    const profileId = String(req.body?.profileId || '').trim();
    if (!profileId || profileId === 'admin1') {
      return res.status(400).json({ status: 'error', message: 'valid VIP profileId is required' });
    }
    if (!hasProfileAccess(req, profileId)) return rejectProfileAccess(res, profileId);
    const purged = purgeDeletedProfile(profileId, 'explicit dashboard deletion');
    const stored = readFullAppState();
    if (stored?.profiles?.[profileId]) {
      const profiles = { ...stored.profiles };
      delete profiles[profileId];
      writeFullAppState({
        ...stored,
        profiles,
        activeId: stored.activeId === profileId ? 'admin1' : stored.activeId,
      });
    }
    return res.json({ status: 'success', profileId, purged, deletedProfileIds: botState.deletedProfileIds });
  });

  // Sync Market Card Active Schedules from Web App
  // CRITICAL: MERGE by key — never wipe admin slots when a VIP client syncs only its profiles.
  app.post("/api/bot/sync_schedules", (req, res) => {
    const { schedules, profileIds, schedulePolicy } = req.body;
    const masterProfileIds = authoritativeProfileIds(profileIds);
    if (masterProfileIds && isVipPortalRequest(req)) {
      return res.status(403).json({ status: 'error', message: 'VIP portal cannot submit a master schedule sync' });
    }
    if (!masterProfileIds) {
      const scopedIds = new Set<string>([
        ...Object.keys(schedulePolicy && typeof schedulePolicy === 'object' ? schedulePolicy : {}),
        ...(Array.isArray(schedules) ? schedules.map((item: any) => String(item?.profileId || '')).filter(Boolean) : []),
      ]);
      if (scopedIds.size !== 1) {
        return res.status(403).json({ status: 'error', message: 'Scoped schedule sync requires exactly one VIP profile' });
      }
      const scopedId = [...scopedIds][0];
      if (scopedId === 'admin1' || !hasProfileAccess(req, scopedId)) return rejectProfileAccess(res, scopedId);
    }
    if (masterProfileIds) {
      reviveAuthoritativeProfiles(
        masterProfileIds,
        Object.fromEntries(masterProfileIds.map((pid) => [pid, true])),
        'master schedule sync',
      );
      const liveMasterProfileIds = masterProfileIds.filter((pid) => pid === 'admin1' || !isDeletedProfile(pid));
      const incomingSet = new Set(liveMasterProfileIds);
      const knownIds = new Set([
        ...botState.activeProfileIds,
        ...Object.keys(botState.ledgerState?.profiles || {}),
      ]);
      for (const pid of knownIds) {
        if (pid !== 'admin1' && !incomingSet.has(pid)) purgeDeletedProfile(pid, 'authoritative schedule sync');
      }
      botState.activeProfileIds = liveMasterProfileIds;
    }
    if (Array.isArray(schedules)) {
      const byKey = new Map<string, any>();
      for (const s of botState.activeSchedules || []) {
        const k = String(s?.key || '');
        if (k) byKey.set(k, s);
      }
      const incomingProfiles = new Set<string>();
      const incomingKeys = new Set<string>();
      const authoritativeProfiles = masterProfileIds
        ? new Set(masterProfileIds.filter((pid) => pid === 'admin1' || !isDeletedProfile(pid)))
        : null;
      for (const s of schedules) {
        const k = String(s?.key || '');
        if (!k) continue;
        incomingKeys.add(k);
        if (s.profileId) incomingProfiles.add(String(s.profileId));
        const previous = byKey.get(k);
        byKey.set(k, {
          ...s,
          senderFormat: previous?.senderFormat,
          senderFormats: previous?.senderFormats,
          detailedMessage: previous?.detailedMessage,
          ...(previous?.recoveryWaitSince ? { recoveryWaitSince: previous.recoveryWaitSince } : {}),
        });
      }
      // Drop slots that belong to profiles present in this sync but no longer listed
      // (card cleared / schedule removed). When profileIds is supplied, it is the
      // authoritative full profile set, so a deleted VIP is removed immediately.
      const deletedProfileIds = new Set<string>();
      if (authoritativeProfiles) {
        for (const pid of Object.keys(botState.ledgerState?.profiles || {})) {
          if (pid !== 'admin1' && !authoritativeProfiles.has(pid)) deletedProfileIds.add(pid);
        }
      }
      for (const [k, s] of [...byKey.entries()]) {
        const pid = String(s?.profileId || '');
        if (!pid) continue;
        if (authoritativeProfiles && !authoritativeProfiles.has(pid)) {
          deletedProfileIds.add(pid);
          byKey.delete(k);
        } else if ((incomingProfiles.has(pid) || authoritativeProfiles?.has(pid)) && !incomingKeys.has(k)) {
          // VIP profiles are event-driven now; authoritative sync with no VIP
          // schedule keys must remove every legacy time-based VIP slot.
          byKey.delete(k);
        }
      }
      if (deletedProfileIds.size > 0) {
        const isDeleted = (pid: unknown) => deletedProfileIds.has(String(pid || ''));
        botState.pendingBroadcasts = botState.pendingBroadcasts.filter((b: any) => !isDeleted(b?.profileId));
        for (const key of Object.keys(botState.scheduleClaims || {})) {
          const claim = (botState.scheduleClaims as any)[key];
          if (isDeleted(claim?.profileId) || [...deletedProfileIds].some((pid) => key.startsWith(`${pid}_`) || key.startsWith(`vip_${pid}_`))) {
            delete botState.scheduleClaims[key];
          }
        }
        for (const key of Object.keys(botState.sentSchedules || {})) {
          if ([...deletedProfileIds].some((pid) => key.startsWith(`${pid}_`) || key.startsWith(`vip_${pid}_`))) {
            delete botState.sentSchedules[key];
          }
        }
        for (const key of Object.keys(botState.resultFollowUpSent || {})) {
          if ([...deletedProfileIds].some((pid) => key.startsWith(`${pid}_`))) {
            delete botState.resultFollowUpSent[key];
          }
        }
        botState.logs.unshift({
          id: Date.now().toString(),
          time: new Date().toLocaleTimeString(),
          msg: `🗑️ Removed stale schedules for deleted VIP profile(s): ${[...deletedProfileIds].join(', ')}`,
          type: 'info',
        });
        if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
        try { persistSentSchedules(); } catch (_) {}
        try { persistResultFollowUps(); } catch (_) {}
      }
      botState.activeSchedules = Array.from(byKey.values());
      atomicWriteFileAsync(path.join(titanDataDir, 'active_schedules.json'), JSON.stringify(botState.activeSchedules || []), 'active-schedules');

      if (schedulePolicy && typeof schedulePolicy === 'object') {
        botState.schedulePolicy = {
          ...(botState.schedulePolicy || {}),
          ...schedulePolicy,
        };
        // Keep the same policy in the persisted profile ledger so restart never defaults VIP OFF types to ON.
        for (const [pid, incomingPolicy] of Object.entries(schedulePolicy as Record<string, any>)) {
          const runtimeProfile: any = botState.ledgerState?.profiles?.[pid];
          if (!runtimeProfile || !incomingPolicy || typeof incomingPolicy !== 'object') continue;
          runtimeProfile.schedulePolicy = {
            ank: incomingPolicy.ank !== false,
            jodi: incomingPolicy.jodi !== false,
            pannel: incomingPolicy.pannel !== false,
          };
        }
        persistLedgerSnapshot();

        // HARD CANCEL: when a card type is switched OFF, remove every pending
        // delivery belonging to that profile/type — not only result follow-ups.
        // This also releases any short-lived schedule claims so an OFF→ON cycle
        // starts cleanly instead of leaving a stale queue item behind.
        const cancelledIds: string[] = [];
        botState.pendingBroadcasts = botState.pendingBroadcasts.filter((b: any) => {
          if (!b.profileId || !b.cardType) return true;
          const policy = botState.schedulePolicy[String(b.profileId)];
          const disabled = policy && ['ank','jodi','pannel'].includes(String(b.cardType)) && (policy as any)[String(b.cardType)] === false;
          if (disabled) { cancelledIds.push(String(b.id || '')); return false; }
          return true;
        });
        // Any claim whose schedule disappeared from the newly-synced active list
        // must be released. This is what makes OFF cancel a schedule that was
        // already claimed by the bot but not yet delivered.
        const activeKeys = new Set((botState.activeSchedules || []).map((x: any) => String(x?.key || '')).filter(Boolean));
        for (const key of Object.keys(botState.scheduleClaims || {})) {
          if (!activeKeys.has(String(key))) delete botState.scheduleClaims[key];
        }
        if (cancelledIds.length) {
          botState.logs.unshift({
            id: Date.now().toString(),
            time: new Date().toLocaleTimeString(),
            msg: `🛑 Cancelled ${cancelledIds.length} queued broadcast(s) because card type was switched OFF`,
            type: 'info',
          });
          if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
        }
      }

      const todayIST = calculateBusinessDateIST();
      const nowIST = new Date().toLocaleTimeString('en-GB', {
        timeZone: 'Asia/Kolkata',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
      });
      const nowMinutes = timeToBusinessMinutes(nowIST);

      // Only mark ancient slots (60+ min past) as sent — NEVER kill slots still inside
      // the live grace window (was marking admin ledger sent before bot could deliver).
      const BACKLOG_MARK_MINUTES = 60;
      let backlogMarked = 0;
      for (const s of botState.activeSchedules || []) {
        const key = String(s?.key || '');
        if (!key || botState.sentSchedules[key]) continue;
        const cleanSchTime = normalizeScheduleTime(s.schTime);
        if (!cleanSchTime) continue;
        const schMinutes = timeToBusinessMinutes(cleanSchTime);
        if (nowMinutes > schMinutes + BACKLOG_MARK_MINUTES) {
          botState.sentSchedules[key] = true;
          backlogMarked++;
        }
      }
      if (backlogMarked > 0) {
        botState.logs.unshift({
          id: Date.now().toString(),
          time: new Date().toLocaleTimeString(),
          msg: `⏭️ ${backlogMarked} past schedule(s) marked sent on sync (no backlog flood)`,
          type: 'info',
        });
        if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
      }

      // Keep only today's sent keys
      const cleaned: Record<string, boolean> = {};
      for (const [key, val] of Object.entries(botState.sentSchedules)) {
        if (String(key).includes(todayIST)) cleaned[key] = val;
      }
      botState.sentSchedules = cleaned;
      persistSentSchedules();
    }
    res.json({ status: "success", count: botState.activeSchedules.length });
  });

  // Raw-result forwarding uses the transient real-time handoff and dedupes per
  // destination/business-date/result, independent of which source published it.
  app.post('/api/bot/forward_result', (req, res) => {
    const source = String(req.body?.sourceJid || '');
    if (!botState.autoResultForwardEnabled || !botState.resultReadGroups.includes(source)) {
      return res.json({ status: 'success', queued: 0, reason: 'source-disabled' });
    }
    const message = String(req.body?.resultText || '').trim();
    const parsed = serverParseResult(message);
    const resultError = automaticResultError(message, parsed);
    if (resultError) return res.status(400).json({ status: 'error', message: resultError });
    if (!parsed.marketBase || !(parsed.openAnk || parsed.closeAnk || parsed.jodi || parsed.openPanel || parsed.closePanel)) {
      return res.status(400).json({ status: 'error', message: 'Unrecognized result; not forwarded' });
    }
    const date = calculateBusinessDateIST();
    const identity = `${resultMergeKey(date, parsed)}:${resultSignature(parsed)}`;
    let queued = 0;
    for (const target of normalizeTargetList(botState.targetGroups)) {
      if (target === source) continue;
      const key = `raw:${date}:${identity}:${target}`;
      if (botState.resultFollowUpSent[key] || botState.pendingBroadcasts.some(b => b.dedupeKey === key)) continue;
      const liveBinding = bindLiveBroadcastTargets([target]);
      // Raw results are event-time only. Even when no gateway is live, consume
      // this exact dedupe key so a later duplicate source cannot replay it.
      botState.resultFollowUpSent[key] = true;
      if (!liveBinding.targets.length) continue;
      botState.pendingBroadcasts.push({
        id: `raw_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
        message, targets: liveBinding.targets, createdAt: new Date().toISOString(), status: 'pending',
        dedupeKey: key, broadcastKind: 'raw-result', platformSessions: liveBinding.sessions,
      });
      queued++;
    }
    persistPendingBroadcasts();
    persistResultFollowUps();
    return res.json({ status: 'success', queued });
  });

  // Send a frozen display copy only. No play reservation, rate finalization,
  // sent marker, recovery advance or financial ACK is attached to this notice.
  app.post('/api/bot/vip_send_now', (req, res) => {
    try {
      const pid=String(req.body?.profileId||''), type=String(req.body?.type||'');
      const index=Number(req.body?.index), date=String(req.body?.date||'');
      const fail=(message:string,code=409)=>res.status(code).json({status:'error',message});
      if(!pid||pid==='admin1'||!['ank','jodi','pannel'].includes(type)||!Number.isInteger(index)||index<0||!/^\d{4}-\d{2}-\d{2}$/.test(date))return fail('Select a valid VIP card and date',400);
      const stored=readFullAppStateView(),saved=stored?.profiles?.[pid];
      const runtime:any=date===botState.ledgerState?.date?botState.ledgerState?.profiles?.[pid]:undefined;
      if(!saved||isDeletedProfile(pid))return fail('VIP profile unavailable',404);
      if(!botState.autoSendEnabled)return fail('Delivery is paused. Enable the main sender first');
      if(!isCardTypeEnabled(pid,type))return fail('This VIP card type is OFF');
      const dict=type==='ank'?'data':type==='jodi'?'jodiData':'pannelData';
      const cfg=saved.dayRecords?.[date]?.recoveryConfigSnapshot||saved.config;
      const market=runtime?.markets?.find((m:any)=>m.type===type&&Number(m.index)===index)
        ||(type==='jodi'?getEffectiveBaseMarkets(cfg):getEffectiveMarkets(cfg))[index];
      const rec=runtime?.cards?.[`${type}_${index}`]||saved.dayRecords?.[date]?.[dict]?.[index];
      if(!market||!rec)return fail('VIP card unavailable');
      const digits=String(rec.sentDigits||rec.d||'').trim();
      const rateNum=Number(rec.sentRate||rec.r||rec.recRate||req.body?.rate||0);
      const canonical=(v:unknown)=>String(v??'').split(/[,|\s]+/).filter(Boolean).join(',');
      if(String(req.body?.marketName||'')!==String(market.n)||canonical(req.body?.digits)!==canonical(digits)||(rec.sentRate&&Number(req.body?.rate)!==Number(rec.sentRate))||Number(req.body?.cardGeneration||0)!==Number(rec.cardGeneration||0))return fail('Card changed or is still syncing. Check the refreshed card and retry');
      if(!areSettlementTokensValid(type,digits)||!Number.isFinite(rateNum)||rateNum<=0)return fail('Valid card digits and rate are required');
      const deliveryProfile={deliveryMode:saved.vipDeliveryMode||'private',phone:saved.vipSchTarget||saved.phone,vipGroupJid:saved.vipGroupJid,vipChannelJid:saved.vipChannelJid};
      const targets=serverVipDeliveryTargets(deliveryProfile);
      if(!targets.length)return fail('Save a valid VIP delivery destination first');
      const binding=bindLiveBroadcastTargets(targets);
      if(!binding.targets.length)return fail('VIP delivery gateway is offline. Connect it and retry');
      const fingerprint=JSON.stringify([pid,date,type,index,rec.cardGeneration||0,digits,rateNum,targets]);
      // Pending AND recently completed copies are one click intent; do not
      // double deliver when an ACK is lost or the user double-taps.
      const existing=botState.pendingBroadcasts.find(b=>b.broadcastKind==='vip-card-copy'&&b.dedupeKey===fingerprint&&
        (b.status==='pending'||(b.status==='sent'&&Date.now()-new Date(b.createdAt).getTime()<60000&&Number.isFinite(new Date(b.createdAt).getTime()))));
      if(existing)return res.json({status:'success',queued:true,alreadyQueued:true,id:existing.id});
      const id=`vipcopy_${Date.now()}_${randomBytes(6).toString('hex')}`;
      const item={id,message:serverBuildVipCardMsg(String(market.n),type,{...rec,d:digits,r:String(rateNum)},saved.config?.detailedMessage!==false,date),targets:binding.targets,createdAt:new Date().toISOString(),status:'pending' as const,dedupeKey:fingerprint,profileId:pid,cardType:type,broadcastKind:'vip-card-copy',cardGeneration:rec.cardGeneration,index,digits,sourceMode:rec.sentSourceMode||rec.sourceMode,scrapeSource:rec.sentScrapeSource||rec.scrapeSource,trick:rec.sentTrick||rec.trick,rateNum,investTotal:rec?.smartStaking?.isSmartStaking&&Number(rec.smartStaking.totalInvest)>0?Number(rec.smartStaking.totalInvest):countSettlementTokens(digits,type)*rateNum,marketName:String(market.n),date,priority:5,platformSessions:binding.sessions};
      Object.assign(item,cardPresentation(item,stored));
      botState.pendingBroadcasts.push(item);
      persistPendingBroadcasts();
      return res.json({status:'success',queued:true,id});
    }catch(error:any){return res.status(500).json({status:'error',message:error?.message||'Send now failed'});}
  });

  // Manual / Auditor broadcast queue — bot picks these up and sends via WhatsApp
  app.post("/api/bot/broadcast", (req, res) => {
    try {
      const { message, targets, scheduleKey, dedupeKey, profileId, cardType, broadcastKind } = req.body;
      let broadcastLink='';
      if(broadcastKind==='vip-live-push'){try{broadcastLink=normalizeBroadcastLink(req.body.broadcastLink);}catch(error:any){return res.status(400).json({status:'error',message:error.message});}}
      const originalMsg=String(message||'').trim();
      const msg=originalMsg+(broadcastLink&&req.body.senderFormat!=='png'?'\n\n'+broadcastLink:'');
      if(req.body.senderFormat!==undefined&&!['text','png','gif_video'].includes(req.body.senderFormat))return res.status(400).json({status:'error',message:'Choose TXT, PNG, or GIF Video'});
      if(req.body.senderFormat==='png'&&broadcastKind!=='vip-live-push')return res.status(400).json({status:'error',message:'PNG upload is only supported for Live Push'});
      if(req.body.senderFormat==='png'){try{decodeBroadcastPng(req.body.broadcastPng);if(!Number.isInteger(req.body.broadcastDesign)||req.body.broadcastDesign<0||req.body.broadcastDesign>4)throw Error('Choose a valid PNG design');}catch(error:any){return res.status(400).json({status:'error',message:error.message});}}
      if(req.body.senderFormat==='gif_video'){
        const rawVideo = String(req.body.broadcastVideo || '');
        if (!rawVideo || rawVideo.length > 6 * 1024 * 1024) {
          return res.status(400).json({ status: 'error', message: 'Invalid or oversized GIF video (max 4MB)' });
        }
      }
      if (!originalMsg) {
        return res.status(400).json({ status: 'error', message: 'message is required' });
      }

      // Hard server-side guard: OFF means this profile/card type cannot enter the WA queue.
      if (profileId && cardType && ['result-followup', 'schedule', 'auto-schedule'].includes(String(broadcastKind || ''))) {
        if (!isCardTypeEnabled(String(profileId), String(cardType))) {
          return res.json({ status: 'success', message: 'Broadcast blocked by schedule policy', id: 'policy-off', targets: 0, blocked: true });
        }
      }

      let targetList: string[] = Array.isArray(targets) ? targets.filter(Boolean) : [];
      if (broadcastKind === 'vip-test' && profileId) {
        const saved = readFullAppState()?.profiles?.[String(profileId)];
        if (!saved) return res.status(404).json({ status: 'error', message: 'VIP not found' });
        targetList = serverVipDeliveryTargets({
          deliveryMode: saved.vipDeliveryMode || 'private',
          vipGroupJid: saved.vipGroupJid,
          vipChannelJid: saved.vipChannelJid,
          phone: saved.vipSchTarget || saved.phone,
        });
        if (!targetList.length) return res.status(400).json({ status: 'error', message: 'Save a valid VIP destination first' });
      }
      if (broadcastKind === 'vip-live-push' && targetList.length === 0) {
        return res.status(400).json({ status: 'error', message: 'Select at least one target for Live Push' });
      }
      if (targetList.length === 0) {
        targetList = Array.isArray(botState.targetGroups) ? [...botState.targetGroups] : [];
      }
      targetList = normalizeTargetList(targetList);
      if (targetList.length === 0) {
        return res.status(400).json({
          status: 'error',
          message: 'No targets provided and no global targetGroups configured'
        });
      }
      const requestedTargetCount = targetList.length;
      const liveBinding = bindLiveBroadcastTargets(targetList);
      targetList = liveBinding.targets;
      if (broadcastKind === 'vip-live-push' && targetList.length !== requestedTargetCount) {
        return res.status(409).json({
          status: 'error',
          message: 'All selected targets require live WhatsApp/Telegram gateways. Nothing was queued.',
          targets: 0,
        });
      }
      if (targetList.length === 0) {
        return res.status(409).json({
          status: 'error',
          message: 'No configured target has a live WhatsApp/Telegram session. Real-time broadcast was not queued.',
          targets: 0,
        });
      }

      // Permanent today-dedupe (dashboard reopen must NOT re-queue same PASS/FAIL reply)
      const dk = dedupeKey ? String(dedupeKey) : '';
      if (dk && botState.resultFollowUpSent[dk]) {
        return res.json({
          status: 'success',
          message: 'Duplicate result follow-up skipped (already sent/queued today)',
          id: 'dup',
          targets: 0,
          duplicate: true,
        });
      }

      const now = Date.now();
      const isDup = botState.pendingBroadcasts.some((b) => {
        if (dk) return b.dedupeKey === dk;
        const age = now - new Date(b.createdAt).getTime();
        if (age > 120_000 && b.status !== 'pending') return false;
        if (b.message === msg && (b.broadcastLink||'')===broadcastLink && (b.broadcastPng||'')===(req.body.senderFormat==='png'?req.body.broadcastPng:'') && b.status === 'pending' &&
          normalizeTargetList(b.targets).sort().join('|') === normalizeTargetList(targetList).sort().join('|')) return true;
        return false;
      });
      if (isDup) {
        if (dk) {
          botState.resultFollowUpSent[dk] = true;
          persistResultFollowUps();
        }
        return res.json({
          status: 'success',
          message: 'Duplicate broadcast skipped',
          id: 'dup',
          targets: 0,
          duplicate: true,
        });
      }

      if(req.body.senderFormat==='png'&&botState.pendingBroadcasts.reduce((sum,b)=>sum+(b.status==='pending'?b.broadcastPng?.length||0:0),0)+req.body.broadcastPng.length>16*1024*1024)return res.status(429).json({status:'error',message:'PNG queue is full. Wait for current broadcasts to finish.'});
      const id = `bc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      botState.pendingBroadcasts.push({
        id,
        message: msg,
        ...(broadcastLink?{broadcastLink}:{}),
        ...(req.body.senderFormat==='png'?{senderFormat:'png',broadcastPng:req.body.broadcastPng,broadcastDesign:req.body.broadcastDesign}:{}),
        ...(req.body.senderFormat==='gif_video'?{senderFormat:'gif_video',broadcastVideo:String(req.body.broadcastVideo),gifPlayback:Boolean(req.body.gifPlayback)} : {}),
        targets: targetList,
        createdAt: new Date().toISOString(),
        status: 'pending',
        scheduleKey: scheduleKey ? String(scheduleKey) : undefined,
        dedupeKey: dk || undefined,
        profileId: profileId ? String(profileId) : undefined,
        cardType: cardType ? String(cardType) : undefined,
        broadcastKind: broadcastKind ? String(broadcastKind) : undefined,
        platformSessions: liveBinding.sessions,
      });
      // Lock dedupe as soon as queued (not only after WA send)
      if (dk) {
        botState.resultFollowUpSent[dk] = true;
        persistResultFollowUps();
      }
      // Cap queue size
      compactPendingBroadcasts(80);
      persistPendingBroadcasts();

      botState.logs.unshift({
        id: Date.now().toString(),
        time: new Date().toLocaleTimeString(),
        msg: `Broadcast queued (${id}) → ${targetList.length} target(s)${dk ? ' [deduped]' : ''}`,
        type: 'info'
      });
      if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);

      res.json({
        status: 'success',
        message: 'Real-time broadcast accepted for live gateway target(s)',
        id,
        targets: targetList.length,
        skippedOfflineTargets: Math.max(0, requestedTargetCount - targetList.length)
      });
    } catch (e: any) {
      res.status(500).json({ status: 'error', message: e?.message || 'Broadcast failed' });
    }
  });

  // Race-safe queue policy guard. The bot uses this immediately before sending a
  // queued result/schedule broadcast so OFF takes effect even during a poll race.
  app.get("/api/bot/schedule_policy", (req, res) => {
    const profileId = String(req.query.profileId || '');
    const cardType = String(req.query.cardType || '');
    const job = botState.pendingBroadcasts.find(item => item.id === String(req.query.broadcastId || ''));
    const jobAllowed = !req.query.broadcastId || Boolean(job?.status === 'pending' && job.profileId === profileId && String(job.cardType || '') === cardType);
    const runAllowed = job?.broadcastKind === 'vip-auto-card' && job.profileId === profileId
      ? enforceVipGameRun(profileId, cardType, Number(job.investTotal || 0), `${cardType}_${job.index}`) : true;
    const playReason=job?.broadcastKind==='vip-auto-card'?(!botState.autoSendEnabled?'auto-send-off':queuedPlayBlockReason(job,botState.ledgerState?.profiles?.[profileId],calculateBusinessDateIST())):'';
    const playAllowed=!playReason;
    // Previously delivered plays may still need their result/settlement notice after renewal lapses.
    const membershipAllowed = profileId === 'admin1' || ['result-followup', 'profit-milestone'].includes(String(job?.broadcastKind || '')) || vipMembershipActive(readFullAppStateView()?.profiles?.[profileId]?.expiryDate);
    const allowed = jobAllowed && runAllowed && playAllowed && membershipAllowed && (job?.broadcastKind === 'profit-milestone' ? profileProfitNotificationsEnabled(profileId) && Boolean(currentProfitAlertSummary(job)) : isCardTypeEnabled(profileId, cardType));
    res.json({ status: 'success', allowed, reason: allowed ? 'enabled' : !membershipAllowed?'vip-membership-expired':!jobAllowed?'queue-removed':!runAllowed?'vip-game-stopped':playReason||'policy-off' });
  });

  // Gateways fetch RAM-only live broadcasts. Jobs are bound to the exact
  // gateway session that was online when the event was created, so logout,
  // reconnect, login or process restart can never replay old work.
  app.get("/api/bot/pending_broadcasts", (req, res) => {
    const cancelled: string[] = [];
    const platform = requestPlatform(req);
    const sessionId = String(req.query?.sessionId || '').trim();
    const sessionStartedAt = Number(req.query?.sessionStartedAt || 0);
    const now = Date.now();

    // The current authenticated gateway may poll normally while its separate
    // heartbeat is delayed. Never revive an offline, unknown or replaced session.
    noteRegisteredGatewayPoll(liveTransports[platform],sessionId,sessionStartedAt,now);

    expireStaleLiveBroadcasts();
    // An expired or unconfigured membership must not receive queued automated plays.
    // Read once for this poll, not once for each target; never replay old sessions.
    const membershipProfiles = readFullAppStateView()?.profiles || {};

    for (const b of botState.pendingBroadcasts) {
      if (b.status === 'pending' && b.profileId && b.profileId !== 'admin1' &&
          ['vip-auto-card','vip-card-copy','schedule','auto-schedule'].includes(String(b.broadcastKind || '')) &&
          !vipMembershipActive(membershipProfiles[String(b.profileId)]?.expiryDate)) {
        b.failedTargets = normalizeTargetList(b.targets);
        finishResolvedBroadcast(b, 'VIP_MEMBERSHIP_EXPIRED');
        cancelled.push(String(b.id));
        continue;
      }
      if (b.status === 'pending' && b.broadcastKind === 'profit-milestone' &&
          !profileProfitNotificationsEnabled(String(b.profileId || ''))) {
        b.failedTargets = normalizeTargetList(b.targets);
        finishResolvedBroadcast(b, 'PROFIT_NOTIFICATIONS_DISABLED');
        cancelled.push(String(b.id));
        continue;
      }
      if (b.status === 'pending' && b.broadcastKind === 'raw-result' &&
          (!botState.autoResultForwardEnabled || !b.targets.every(t => normalizeTargetList(botState.targetGroups).includes(t)))) {
        b.failedTargets = normalizeTargetList(b.targets);
        finishResolvedBroadcast(b, 'RAW_RESULT_DISABLED');
        cancelled.push(String(b.id));
        continue;
      }
      if (b.status !== 'pending' || !b.profileId) continue;
      if (b.broadcastKind==='profit-milestone') {
        const summary=currentProfitAlertSummary(b);
        if(!summary) {
          b.failedTargets=normalizeTargetList(b.targets);
          finishResolvedBroadcast(b,'PROFIT_SUMMARY_CHANGED');
          cancelled.push(String(b.id));
          continue;
        }
        // Claimed payloads belong to the gateway; refresh only before a claim.
        if(!Object.keys(b.claimedPlatforms || {}).length)b.message=buildProfitMilestoneMessage(summary);
      }
      if (isDeletedProfile(String(b.profileId))) {
        b.failedTargets = normalizeTargetList(b.targets);
        finishResolvedBroadcast(b, 'PROFILE_DELETED');
        cancelled.push(String(b.id));
        continue;
      }
      if (b.broadcastKind === 'vip-auto-card') {
        if (!enforceVipGameRun(String(b.profileId), String(b.cardType), Number(b.investTotal || 0), `${b.cardType}_${b.index}`)) {
          cancelled.push(String(b.id)); continue;
        }
        const prof = botState.ledgerState?.profiles?.[String(b.profileId)];
        if (!prof || prof.vipAutoMode === false) {
          b.failedTargets = normalizeTargetList(b.targets);
          finishResolvedBroadcast(b, 'VIP_AUTO_DISABLED');
          cancelled.push(String(b.id));
          continue;
        }
        // A destination edit may stop a stale destination, but it must never add
        // a newly-online transport/session to an older event.
        const currentTargets = new Set(serverVipDeliveryTargets(prof));
        for (const target of normalizeTargetList(b.targets)) {
          if (!currentTargets.has(target)) {
            b.failedTargets = [...new Set([...(b.failedTargets || []), target])];
          }
        }
        if (finishResolvedBroadcast(b, 'VIP_DESTINATION_CHANGED') !== 'pending') {
          cancelled.push(String(b.id));
          continue;
        }
      } else if (
        (b.broadcastKind === 'result-followup' || b.broadcastKind === 'profit-milestone' || b.broadcastKind === 'vip-card-copy') &&
        String(b.profileId) !== 'admin1'
      ) {
        const prof = botState.ledgerState?.profiles?.[String(b.profileId)];
        const currentTargets = new Set(serverVipDeliveryTargets(prof));
        for (const target of normalizeTargetList(b.targets)) {
          if (!currentTargets.has(target)) b.failedTargets = [...new Set([...(b.failedTargets || []), target])];
        }
        if (finishResolvedBroadcast(b, b.broadcastKind === 'profit-milestone' ? 'PROFIT_DESTINATION_CHANGED' : 'RESULT_DESTINATION_CHANGED') !== 'pending') {
          cancelled.push(String(b.id));
          continue;
        }
      } else if (b.broadcastKind === 'profit-milestone' && String(b.profileId) === 'admin1') {
        const currentTargets = new Set(normalizeTargetList(botState.targetGroups));
        for (const target of normalizeTargetList(b.targets)) {
          if (!currentTargets.has(target)) b.failedTargets = [...new Set([...(b.failedTargets || []), target])];
        }
        if (finishResolvedBroadcast(b, 'PROFIT_DESTINATION_CHANGED') !== 'pending') {
          cancelled.push(String(b.id));
          continue;
        }
      }
      if (b.cardType && !isCardTypeEnabled(String(b.profileId), String(b.cardType))) {
        b.failedTargets = normalizeTargetList(b.targets);
        finishResolvedBroadcast(b, 'CARD_TYPE_DISABLED');
        cancelled.push(String(b.id));
      }
    }

    if (!sessionId || !Number.isFinite(sessionStartedAt) || sessionStartedAt <= 0) {
      return res.json({ status: 'success', broadcasts: [], cancelled, realtime: true, reason: 'live-session-required' });
    }
    const authoritativeRuntime = liveTransports[platform];
    if (!liveTransportUsable(platform) || authoritativeRuntime.sessionId !== sessionId || authoritativeRuntime.startedAt !== sessionStartedAt) {
      return res.json({ status: 'success', broadcasts: [], cancelled, realtime: true, reason: 'stale-gateway-session' });
    }

    // If this is a new gateway runtime, retire work bound to the previous one.
    retireSessionBoundBroadcasts(platform, sessionId, `${platform.toUpperCase()}_SESSION_CHANGED`);

    const eligibleTargets = (b: any): string[] => {
      const failed = new Set(broadcastResolution(b).failed);
      return remainingTargets(`broadcast:${b.id}`, b.targets, platform).filter(target => {
        if (failed.has(target) || Number(b.targetNotBefore?.[target] || 0) > now) return false;
        if (b.broadcastKind !== 'vip-auto-card') return true;
        // A recipient must see its preceding result before the next play. Other
        // recipients can progress independently while that result retries.
        return !botState.pendingBroadcasts.some(reply =>
          reply.status === 'pending' && reply.broadcastKind === 'result-followup' &&
          reply.profileId === b.profileId && reply.cardType === b.cardType &&
          new Date(reply.createdAt).getTime() <= new Date(b.createdAt).getTime() &&
          broadcastResolution(reply).unresolved.includes(target));
      });
    };
    const candidate = botState.pendingBroadcasts
      .filter((b) => b.status === 'pending')
      .sort((a: any, b: any) => {
        const pa = Number(a.priority ?? (a.broadcastKind === 'result-followup' ? 10 : a.broadcastKind === 'vip-auto-card' ? 20 : 30));
        const pb = Number(b.priority ?? (b.broadcastKind === 'result-followup' ? 10 : b.broadcastKind === 'vip-auto-card' ? 20 : 30));
        if (pa !== pb) return pa - pb;
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      })
      .find((b: any) => {
        const createdAt = new Date(b.createdAt).getTime();
        if (!Number.isFinite(createdAt) || createdAt < sessionStartedAt) {
          retireTransportTargets(b, platform, `${platform.toUpperCase()}_SESSION_PRE_DATES_EVENT`);
          return false;
        }
        if (String(b.platformSessions?.[platform] || '') !== sessionId) return false;
        if (Number(b.platformNotBefore?.[platform] || 0) > now) return false;
        if (b.claimedPlatforms?.[platform]) {
          // A dropped ACK must not reserve this live job forever. Only this
          // same bound session may retry it; gateway receipts dedupe real sends.
          if (now - Number(b.claimedPlatforms[platform]) < LIVE_CLAIM_TTL_MS) return false;
          delete b.claimedPlatforms[platform];
          if (b.claimedTargets) delete b.claimedTargets[platform];
        }
        const targets = eligibleTargets(b);
        return targets.length > 0;
      });

    if (!candidate) {
      if (cancelled.length) persistPendingBroadcasts();
      return res.json({ status: 'success', broadcasts: [], cancelled, realtime: true });
    }

    const targets = eligibleTargets(candidate);
    // Telegram is intentionally one-target-per-claim. Its 5-second pacing means a
    // 30-target batch can run for minutes; one-at-a-time claims let a newly-arrived
    // result close the old play before the next destination is attempted.
    const claimTargets = platform === 'telegram' ? targets.slice(0, 1) : targets;
    candidate.claimedPlatforms = { ...(candidate.claimedPlatforms || {}), [platform]: now };
    candidate.claimedTargets = { ...(candidate.claimedTargets || {}), [platform]: claimTargets };
    if(['vip-auto-card','vip-card-copy'].includes(String(candidate.broadcastKind))&&(!(candidate as any).senderFormat||cardUsesPng(candidate)&&(!candidate.digitSupport||!Object.keys(candidate.digitSupport).length||Object.values(candidate.digitSupport).some(value=>!['Strong','Support','SupportLow'].includes(String(value)))))){Object.assign(candidate,cardPresentation(candidate));persistPendingBroadcasts();}
    // Updated gateways opt into attempt identities; older clients remain compatible.
    const claimToken = req.query.claimVersion === '2' ? randomBytes(16).toString('hex') : undefined;
    candidate.claimTokens = { ...(candidate.claimTokens || {}), [platform]: claimToken };
    const outbound = { ...candidate, ...(['vip-auto-card','vip-card-copy'].includes(String(candidate.broadcastKind))?{senderFormat:cardSenderFormatForDelivery(candidate,platform)}:{}), claimToken, claimTokens: undefined, claimedPlatforms: undefined, claimedTargets: undefined, platformNotBefore: undefined, targetNotBefore: undefined, failedTargets: undefined, targets: claimTargets };
    res.json({ status: 'success', broadcasts: [outbound], cancelled, realtime: true });
  });

  // Gateways acknowledge one live attempt. Temporary Telegram/transport pacing
  // releases the claim for the SAME live session; permanent failures are recorded
  // per target. A VIP card becomes SENT only if every originally-live target was
  // delivered, never on a partial delivery.
  app.post("/api/bot/ack_broadcast", (req, res) => {
    const { id, status, details } = req.body || {};
    if (!['sent', 'failed', 'deferred'].includes(status)) {
      return res.status(400).json({ status: 'error', message: 'Invalid broadcast acknowledgement status' });
    }
    const platform = requestPlatform(req);
    const item = botState.pendingBroadcasts.find((b) => b.id === id);
    if (!item) return res.json({ status: 'success', ignored: true, realtime: true });

    if (item.status !== 'pending') {
      return res.json({ status: 'success', ignored: true, finalStatus: item.status, realtime: true });
    }
    if (item.claimTokens?.[platform] && req.body?.claimToken !== item.claimTokens[platform]) {
      return res.json({ status: 'success', ignored: true, finalStatus: item.status, reason: 'stale-claim', realtime: true });
    }
    const hadActiveClaim = Boolean(item.claimedPlatforms?.[platform]);
    const claimedBatch = normalizeTargetList(item.claimedTargets?.[platform] || []);
    // A late duplicate ACK must not consume targets from a newer one-at-a-time
    // Telegram cycle. Only the transport that currently owns the claim may
    // mutate a still-pending job; completed-job ACKs remain idempotent below.
    if (item.status === 'pending' && !hadActiveClaim) {
      return res.json({ status: 'success', ignored: true, finalStatus: 'pending', realtime: true });
    }
    if (item.claimTokens) delete item.claimTokens[platform];
    if (item.claimedPlatforms) delete item.claimedPlatforms[platform];
    if (item.claimedTargets) delete item.claimedTargets[platform];
    const receiptKey = `broadcast:${item.id}`;
    const platformExpected = transportTargets(item.targets, platform);
    const reported = normalizeTargetList(Array.isArray(req.body?.targets) ? req.body.targets : [])
      .filter((target) => platformExpected.includes(target));
    const attempted = normalizeTargetList(Array.isArray(req.body?.attemptedTargets) ? req.body.attemptedTargets : [])
      .filter((target) => platformExpected.includes(target));
    if (reported.length > 0) recordDelivery(receiptKey, reported, item.targets);
    // The first confirmed recipient makes the card a real investment, even
    // while another destination is still pending. It is counted once per card.
    if (reported.length > 0 && item.broadcastKind === 'vip-auto-card') {
      const rec = botState.ledgerState?.profiles?.[String(item.profileId)]?.cards?.[`${item.cardType}_${item.index}`];
      if (rec && !rec.deliveryRestoredAt && Number(rec.cardGeneration || 0) === Number(item.cardGeneration || 0)) {
        rec.sentDigits = String(item.digits || rec.d || ''); rec.sentRate = String(item.rateNum || rec.r || '');
        rec.sentInvest = Number(item.investTotal || 0) || countSettlementTokens(rec.sentDigits, String(item.cardType)) * Number(rec.sentRate);
        rec.sentAt = rec.sentAt || Date.now();
        rec.sentTargets = normalizeTargetList([...(rec.sentTargets || []), ...reported]);
        rec.deliveryPartial = true;
        if (rec.vipAutoStopSkipped) { rec.s = 'WAIT'; delete rec.vipAutoStopSkipped; }
        persistLedgerSnapshot();
        const full = readFullAppState(); if (full) writeFullAppState(mergeLedgerIntoFullAppState(full));
      }
    }

    let finalStatus: 'pending' | 'sent' | 'failed' = 'pending';
    if (status === 'deferred') {
      const requestedRetryAt = Number(req.body?.retryAt || 0);
      const retryAt = Math.max(Date.now() + 1000, Number.isFinite(requestedRetryAt) ? requestedRetryAt : 0);
      const delivered = new Set(normalizeTargetList(transportReceipts[receiptKey] || []));
      item.targetNotBefore = item.targetNotBefore || {};
      for (const target of claimedBatch) {
        if (!delivered.has(target)) item.targetNotBefore[target] = retryAt;
      }
      // A deferred one-target Telegram claim must not pause untouched groups.
      if (item.platformNotBefore) delete item.platformNotBefore[platform];
      finalStatus = finishResolvedBroadcast(item, 'LIVE_DELIVERY_DEFERRED_EXPIRED');
    } else if (status === 'failed') {
      const delivered = new Set(normalizeTargetList(transportReceipts[receiptKey] || []));
      const failureScope = acknowledgedTargets(attempted, claimedBatch, platformExpected);
      const permanentlyFailed = failureScope.filter((target) => !delivered.has(target));
      item.failedTargets = [...new Set([...(item.failedTargets || []), ...permanentlyFailed])];
      if (item.platformNotBefore) delete item.platformNotBefore[platform];
      finalStatus = finishResolvedBroadcast(item, 'LIVE_TARGET_FAILED');
    } else {
      // status=sent means this platform confirms every remaining target returned
      // in its claimed batch. Record them even when the gateway omitted targets.
      const sentTargets = acknowledgedTargets(reported, claimedBatch, platformExpected);
      if (sentTargets.length > 0) recordDelivery(receiptKey, sentTargets, item.targets);
      if (item.platformNotBefore) delete item.platformNotBefore[platform];
      finalStatus = finishResolvedBroadcast(item, 'LIVE_DELIVERY_FAILED');
    }

    // Delivery confirmation is authoritative. Freeze a VIP play only after ALL
    // live targets that existed when the event happened were delivered.
    if (item.broadcastKind === 'vip-auto-card' && finalStatus === 'sent' && item.scheduleKey && item.profileId && item.cardType && Number.isFinite(Number(item.index))) {
      const pid = String(item.profileId);
      const type = String(item.cardType);
      const idx = Number(item.index);
      const rec = botState.ledgerState?.profiles?.[pid]?.cards?.[`${type}_${idx}`];
      if (rec && !rec.deliveryRestoredAt && Number(rec.cardGeneration || 0) === Number(item.cardGeneration || 0)) {
        const digits = String(item.digits || rec.d || '').trim();
        const rateNum = Number(item.rateNum || rec.r || 0);
        const count = digits ? digits.split(/[,|\s]+/).filter(Boolean).length : 0;
        const investTotal = Number(item.investTotal || 0) || count * rateNum;
        rec.d = digits || rec.d;
        rec.r = rateNum > 0 ? String(rateNum) : rec.r;
        rec.sentRate = rateNum > 0 ? String(rateNum) : rec.sentRate;
        rec.sentInvest = investTotal > 0 ? investTotal : rec.sentInvest;
        rec.sentDigits = digits || rec.sentDigits;
        rec.sentSourceMode = item.sourceMode || rec.sentSourceMode || rec.sourceMode;
        rec.sentTrick = item.trick || rec.sentTrick || rec.trick;
        rec.sentScrapeSource = normalizeScrapeSource(item.scrapeSource) || getScrapeSource(rec);
        rec.sentLoopId = rec.loopId || rec.sentLoopId;
        rec.sentTargets = normalizeTargetList(item.targets || []);
        rec.deliveryMissedAt = undefined;
        rec.deliveryMissedReason = undefined;
        rec.deliveryPartial = undefined;
        rec.dispatchState = 'SENT';
        rec.dispatchKey = String(item.scheduleKey);
        rec.sentAt = rec.sentAt || Date.now();
        activityRecorder.record({
          date: botState.ledgerState.date || calculateBusinessDateIST(),
          profileId: pid,
          market: String(item.marketName || rec.marketName || 'MARKET'),
          type: (cardType === 'ank' || cardType === 'jodi' || cardType === 'pannel') ? cardType : 'ank',
          action: 'CARD_SENT',
          digits: rec.sentDigits || rec.d,
          rate: rec.sentRate || rec.r,
          invest: rec.sentInvest,
          status: 'SENT',
          trick: rec.sentTrick || rec.trick,
          sourceMode: rec.sentSourceMode || rec.sourceMode,
          subtitle: `${item.marketName || rec.marketName || 'Card'} (${String(cardType || 'ank').toUpperCase()}) ke digits [${rec.sentDigits || rec.d}] Rs ${rec.sentRate || rec.r || 0} rate par ${(item.targets || []).length} WhatsApp/TG group me bhej diye gaye!`,
        });
        botState.sentSchedules[String(item.scheduleKey)] = true;
        botState.ledgerState.updatedAt = Date.now();
        persistSentSchedules();
        persistLedgerSnapshot();
        try {
          const full = readFullAppState();
          if (full) writeFullAppState(mergeLedgerIntoFullAppState(full));
        } catch (_) {}
      }
    }

    botState.pendingBroadcasts = botState.pendingBroadcasts.filter(
      (b) => b.status === 'pending' || Date.now() - new Date(b.createdAt).getTime() < 5 * 60 * 1000
    );
    botState.logs.unshift({
      id: Date.now().toString(), time: new Date().toLocaleTimeString(),
      msg: details || `Broadcast ${id} → ${finalStatus}`,
      type: finalStatus === 'failed' ? 'danger' : finalStatus === 'pending' ? 'info' : 'success',
    });
    if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
    persistPendingBroadcasts();
    if (item.broadcastKind === 'vip-auto-card' && finalStatus !== 'pending') {
      serverProcessPendingAudits();
      queueVipAutoReadyCards('broadcast-ack');
    }
    res.json({ status: 'success', partial: finalStatus === 'pending', deferred: status === 'deferred', finalStatus, realtime: true });
  });

  // Get Bot Config & Status (with stale-heartbeat detection)
  app.get("/api/bot/config", (_req, res) => {
    const STALE_MS = 45_000; // The socket cannot be confirmed healthy after this interval.
    let effectiveStatus = botState.status || 'offline';
    let secondsSinceHeartbeat: number | null = null;
    let connectionHealthy = false;

    if (botState.lastHeartbeat) {
      const age = Date.now() - new Date(botState.lastHeartbeat).getTime();
      secondsSinceHeartbeat = Math.floor(age / 1000);
      if (age > STALE_MS && (effectiveStatus === 'online' || effectiveStatus === 'reconnecting')) {
        // A missing heartbeat is NOT proof that WhatsApp logged out. Avoid
        // displaying an incorrect permanent Offline state after an API stall.
        // Delivery safety below still requires a fresh live transport heartbeat.
        effectiveStatus = 'unresponsive';
      }
      connectionHealthy = age <= STALE_MS && effectiveStatus === 'online';
    } else if (effectiveStatus === 'online') {
      // Never received heartbeat but marked online → inconsistent
      effectiveStatus = 'offline';
      botState.status = 'offline';
    }

    // Do not leak internal flags — UI would save them back and force logout after pair
    const {
      forceRelogin: _fr,
      logoutRequested: _lr,
      scheduleMsgKeys: _smk,
      resultFollowUpSent: _rfs,
      pendingAuditResults: _par,
      pendingBroadcasts: _pb,
      activeSchedules: _as,
      sentSchedules: _ss,
      scheduleClaims: _sc,
      ledgerState: _ls,
      logs: _logs,
      deletedProfileIds: _deletedProfileIds,
      pendingChannelInvites: _pendingChannelInvites,
      ...safeConfig
    } = botState as any;

    res.json({
      status: "success",
      config: {
        ...safeConfig,
        status: effectiveStatus,
        connectionHealthy,
        secondsSinceHeartbeat,
        groupsCount: (botState.syncedGroups || []).length,
        channelsCount: botState.syncedChannels.length,
        contactsCount: (botState.syncedContacts || []).length,
        deletedProfileIds: botState.deletedProfileIds,

      },
    });
  });

  // Auto Audit & Result Forwarding Ingestion Endpoint
  app.post("/api/bot/auto_audit_result", (req, res) => {
    try {
      if (req.body?.sourcePlatform === 'telegram' && (!botState.autoResultForwardEnabled ||
          !isTelegramTarget(req.body?.sourceJid) || !botState.resultReadGroups.includes(req.body.sourceJid))) {
        return res.status(403).json({ status: 'error', message: 'Telegram source is not selected' });
      }
      const { resultText, market, openPanel, openAnk, jodi, closeAnk, closePanel } = req.body;
      const text = String(resultText || `${market} ${openPanel || ''}-${jodi || (openAnk || '') + (closeAnk || '')}-${closePanel || ''}`).trim();
      const parsedIncoming = serverParseResult(text);
      const resultError = automaticResultError(text, parsedIncoming);
      if (resultError) return res.status(400).json({ status: 'error', message: resultError });
      restoreSavedAdminSchedules();
      const resultStage = classifyResultStage(parsedIncoming);
      const mergeKey = resultMergeKey(botState.ledgerState?.date || calculateBusinessDateIST(), parsedIncoming);
      const signature = resultSignature(parsedIncoming);

      const auditId = Date.now().toString() + Math.random().toString().slice(2, 6);
      const auditLog = {
        id: auditId,
        time: new Date().toLocaleTimeString(),
        text,
        market: market || 'AUTO DETECTED',
        openAnk,
        jodi,
        closeAnk,
        status: 'VERIFIED'
      };

      const duplicate = botState.pendingAuditResults.find((p: any) =>
        !p.processed && p.signature === signature && p.mergeKey === mergeKey
      );
      if (duplicate) {
        return res.json({
          status: 'success',
          message: 'Duplicate result ignored',
          audit: { id: duplicate.id, text: duplicate.text, status: 'VERIFIED' },
          targets: botState.targetGroups,
          serverProcessed: { processed: 0, replies: 0, reason: 'duplicate' },
        });
      }

      // A source may first publish OPEN-only (789-4), then publish the FULL
      // result (789-42-237). Keep one queue item and replace the partial with
      // the full declaration for the same business date and market.
      const partialToUpgrade = resultStage === 'FULL'
        ? botState.pendingAuditResults.find((p: any) =>
            p.mergeKey === mergeKey && p.stage === 'OPEN_ONLY'
          )
        : null;
      if (partialToUpgrade) {
        partialToUpgrade.id = auditId;
        partialToUpgrade.text = text;
        partialToUpgrade.time = new Date().toLocaleTimeString();
        partialToUpgrade.stage = 'FULL';
        partialToUpgrade.signature = signature;
        partialToUpgrade.processed = false;
        partialToUpgrade.serverMarked = false;
        partialToUpgrade.deferredCards = {};
        partialToUpgrade.awaitingFull = false;
        partialToUpgrade.fullText = text;
      } else {
        botState.pendingAuditResults.push({
          id: auditId,
          text,
          time: new Date().toLocaleTimeString(),
          processed: false,
          stage: resultStage,
          mergeKey,
          signature,
          awaitingFull: resultStage === 'OPEN_ONLY',
          partialText: resultStage === 'OPEN_ONLY' ? text : undefined,
        });
      }
      if (botState.pendingAuditResults.length > 50) {
        botState.pendingAuditResults = botState.pendingAuditResults.slice(-50);
      }
      persistPendingAudits();

      botState.logs.unshift({
        id: Date.now().toString(),
        time: new Date().toLocaleTimeString(),
        msg: `🎯 Received & Verified Result: ${text}`,
        type: 'success'
      });

      // Process immediately on server (works even if dashboard is closed)
      const srv = serverProcessPendingAudits();

      res.json({
        status: "success",
        message: "Result verified & queued for forwarding!",
        audit: auditLog,
        targets: botState.targetGroups,
        serverProcessed: srv,
      });
    } catch (err: any) {
      res.status(500).json({ status: "error", message: err?.message || "Audit failed" });
    }
  });

  // Cross-origin dashboard state: localhost and Cloudflare both use this same file.
  const rangeJobFile = path.join(titanDataDir, 'titan_range_backtest_job.json');
  let savedRangeJob: RangeJob | undefined;
  try {
    const candidate = JSON.parse(fs.readFileSync(rangeJobFile, 'utf8'));
    validateRangeOptions(candidate);
    if (candidate.id && candidate.config && Array.isArray(candidate.tasks) && ['running','paused','completed','stopped','cleared'].includes(candidate.state)) savedRangeJob = candidate;
  } catch (_) {}
  const rangeHistoryFile=path.join(titanDataDir,'titan_range_backtest_history.json');
  let rangeHistory:any[]=[];try{const saved=JSON.parse(fs.readFileSync(rangeHistoryFile,'utf8'));if(Array.isArray(saved))rangeHistory=saved.slice(0,30);}catch(_){}
  const rangeChartSnapshots = new Map<string, any>();
  const rangeDatedRows = new Map<string, ReturnType<typeof parseDatedActuals>>();
  const rangeRunner = new RangeBacktestRunner({
    resumeInterrupted: true,
    read: readFullAppState, write: writeFullAppState,
    persistHistory: history=>atomicWriteFile(rangeHistoryFile,JSON.stringify(history),'range-history',true),
    persist: job => atomicWriteFile(rangeJobFile, JSON.stringify(job), 'range-backtest', true),
    resetSources: () => { rangeChartSnapshots.clear(); rangeDatedRows.clear(); },
    scrape: async body => {
      let httpStatus = 200, data: any;
      const response = { status: (code: number) => { httpStatus = code; return response; }, json: (value: any) => { data = value; return response; } };
      await scrapeMarketHandler({ body, rangeChartSnapshots, rangeDatedRows }, response);
      return { ...data, httpStatus };
    },
  }, savedRangeJob,rangeHistory);
  const rangeMaster = (req: any, res: any) => {
    if (isVipPortalRequest(req)) { res.status(403).json({status:'error',message:'Bulk date backtest is Master-only'}); return false; }
    return true;
  };
  app.get('/api/app/backtest_range', (req,res) => {
    if (!rangeMaster(req,res)) return;
    res.json({status:'success',job:req.query.summary==='1'?rangeRunner.summary():rangeRunner.view()});
  });
  app.post('/api/app/backtest_range/preview', (req,res) => {
    if (!rangeMaster(req,res)) return;
    try {
      const options = validateRangeOptions(req.body), profile = readFullAppState()?.profiles[options.profileId];
      if (!profile || isDeletedProfile(options.profileId)) return res.status(404).json({status:'error',message:'Profile not found'});
      const tasks=planRange(profile,options);
      res.json({status:'success',dates:[...new Set(tasks.map(t=>t.date))].length,total:tasks.length,
        counts:Object.fromEntries(['pending','protected','disabled','live','weekday_skip'].map(s=>[s,tasks.filter(t=>t.status===s).length]))});
    } catch(e:any) { res.status(400).json({status:'error',message:e.message}); }
  });
  app.post('/api/app/backtest_range/start', (req,res) => {
    if (!rangeMaster(req,res)) return;
    try { const options=validateRangeOptions(req.body);if(isDeletedProfile(options.profileId))throw new Error('Profile not found');rangeRunner.start(options);res.json({status:'success',job:rangeRunner.view()}); }
    catch(e:any) { res.status(409).json({status:'error',message:e.message}); }
  });
  app.post('/api/app/backtest_range/pause', (req,res) => {
    if (!rangeMaster(req,res)) return;
    rangeRunner.pause();res.json({status:'success',job:rangeRunner.view()});
  });
  app.post('/api/app/backtest_range/stop',(req,res)=>{if(!rangeMaster(req,res))return;rangeRunner.stop();res.json({status:'success',job:rangeRunner.view()});});
  app.post('/api/app/backtest_range/clear',(req,res)=>{if(!rangeMaster(req,res))return;try{if(req.body?.profileId!==rangeRunner.job?.profileId||req.body?.jobId!==rangeRunner.job?.id)throw new Error('Run changed; refresh before clearing');const result=rangeRunner.clear();res.json({status:'success',...result,job:rangeRunner.view()});}catch(e:any){res.status(409).json({status:'error',message:e.message});}});
  app.post('/api/app/backtest_range/resume', (req,res) => {
    if (!rangeMaster(req,res)) return;
    try { rangeRunner.resume();res.json({status:'success',job:rangeRunner.view()}); }
    catch(e:any) {res.status(409).json({status:'error',message:e.message});}
  });

  app.get("/api/app/activity_timeline", async (req, res) => {
    try {
      const date = String(req.query.date || calculateBusinessDateIST()).trim();
      const profileId = String(req.query.profileId || "admin1").trim();
      const events = activityRecorder.readDate(date, profileId);
      const hasFfmpeg = await isFfmpegAvailable();
      res.json({ status: "success", date, profileId, hasFfmpeg, events });
    } catch (e: any) {
      res.status(500).json({ status: "error", message: e?.message || "Failed to load activity timeline" });
    }
  });

  app.post("/api/app/activity_log", (req, res) => {
    try {
      const b = req.body || {};
      const date = String(b.date || calculateBusinessDateIST()).trim();
      const profileId = String(b.profileId || "admin1").trim();
      if (!b.market || !b.action || !b.subtitle) {
        return res.status(400).json({ status: "error", message: "market, action and subtitle are required" });
      }
      const event = activityRecorder.record({
        date,
        profileId,
        market: String(b.market),
        type: (b.type === "ank" || b.type === "jodi" || b.type === "pannel") ? b.type : "ank",
        action: b.action,
        digits: b.digits ? String(b.digits) : undefined,
        rate: b.rate !== undefined ? String(b.rate) : undefined,
        invest: b.invest !== undefined ? Number(b.invest) : undefined,
        status: b.status,
        actual: b.actual ? String(b.actual) : undefined,
        pl: b.pl !== undefined ? Number(b.pl) : undefined,
        netDayPl: b.netDayPl !== undefined ? Number(b.netDayPl) : undefined,
        trick: b.trick ? String(b.trick) : undefined,
        sourceMode: b.sourceMode ? String(b.sourceMode) : undefined,
        subtitle: String(b.subtitle).slice(0, 240),
      });
      res.json({ status: "success", event });
    } catch (e: any) {
      res.status(500).json({ status: "error", message: e?.message || "Failed to record activity" });
    }
  });

  app.post("/api/app/activity_video", async (req, res) => {
    try {
      const b = req.body || {};
      const date = String(b.date || calculateBusinessDateIST()).trim();
      const profileId = String(b.profileId || "admin1").trim();
      const period: "day" | "week" = b.period === "week" ? "week" : "day";
      const filter = String(b.filter || "all");
      const secondsPerStep = Number(b.secondsPerStep || 2.4);
      const showSubtitles = b.showSubtitles !== false;

      const targetDates: string[] = [];
      if (period === "week") {
        const endDt = new Date(`${date}T00:00:00Z`);
        const dow = endDt.getUTCDay();
        const mondayOffset = dow === 0 ? -6 : 1 - dow;
        const monDt = new Date(endDt);
        monDt.setUTCDate(endDt.getUTCDate() + mondayOffset);
        for (let d = new Date(monDt); d <= endDt; d.setUTCDate(d.getUTCDate() + 1)) {
          targetDates.push(d.toISOString().slice(0, 10));
        }
      } else {
        targetDates.push(date);
      }
      const dateRangeLabel = period === "week" && targetDates.length > 1
        ? `${targetDates[0]} to ${targetDates[targetDates.length - 1]}`
        : date;

      // Collect raw played cards in chronological market order with full Smart Stake,
      // Profit Carry, Close Zero (OPEN pass -> CLOSE Rs 0 skip), and 4-Wave Relay logic.
      const savedProf = readFullAppStateView()?.profiles?.[profileId];
      const mkts = savedProf ? getEffectiveMarkets(savedProf.config) : [];
      const rawCards: Array<{
        date: string;
        idx: number;
        market: string;
        digits: string;
        rate: string;
        rateNum: number;
        invest: number;
        sourceMode: string;
        trick: string;
        isSettled: boolean;
        isSent: boolean;
        status: string;
        actual: string;
        cardPl: number;
        runningPl: number;
        ts: number;
        isSmartStakeOn: boolean;
        strongDigits?: string;
        supportDigits?: string;
        strongRate?: number;
        supportRate?: number;
        isProfitCarryOn: boolean;
        prevLoss: number;
        carriedProfit: number;
        baseTargetProfit: number;
        isCloseZeroOn: boolean;
        isCloseZeroSkip: boolean;
        isSkippedCard: boolean;
        skipReason?: string;
        isFourWaveOn: boolean;
        waveId?: string;
      }> = [];

      let runningPl = 0;
      for (const dStr of targetDates) {
        const dayStore = savedProf?.dayRecords?.[dStr];
        if (!dayStore) continue;
        const dayCfg = (dStr < calculateBusinessDateIST() ? dayStore?.recoveryConfigSnapshot : undefined) || savedProf?.config || {};
        const loopEnabled = Boolean(dayLoopConfig(savedProf, dStr)?.enabled);
        const isFourWaveOn = Boolean(!loopEnabled && (dayCfg?.fourWaveRelay === true || savedProf?.config?.fourWaveRelay === true));
        const isSmartStakeOn = Boolean(!isFourWaveOn && (dayCfg?.ankSplit !== false));
        const isProfitCarryOn = Boolean(dayCfg?.profitCarry === true || savedProf?.config?.profitCarry === true || savedProf?.profitCarry === true);
        const isCloseZeroOn = Boolean(
          dayCfg?.openPassCloseZero === true ||
          savedProf?.config?.openPassCloseZero === true ||
          savedProf?.openPassCloseZero === true ||
          dayStore?.backtestRecoveryPolicy?.openPassCloseZero === true
        );
        const baseTargetProfit = Number(dayCfg?.ank?.tgt || savedProf?.config?.ank?.tgt || 100) || 100;

        const entries = Object.entries(dayStore.data || {})
          .map(([idxStr, rec]) => [Number(idxStr), rec] as [number, any])
          .filter(([idx]) => Number.isFinite(idx))
          .sort((a, b) => a[0] - b[0]);

        for (const [idx, rec] of entries) {
          if (!rec) continue;
          const mName = String(rec?.marketName || mkts[idx]?.n || `MARKET #${idx}`);
          const isCloseMkt = /\s+CLOSE$/i.test(mName);
          const baseMktName = mName.replace(/\s+(OPEN|CLOSE)$/i, "").trim().toUpperCase();
          const openMktName = `${baseMktName} OPEN`;
          const openEntry = entries.find(([oIdx, oRec]) => String(oRec?.marketName || mkts[oIdx]?.n || "").trim().toUpperCase() === openMktName);
          const openRec = openEntry?.[1];
          const isOpenPassForThisClose = Boolean(isCloseZeroOn && isCloseMkt && openRec?.s === "PASS");

          const isExplicitSkip = rec.s === "SKIP";
          const isSkippedCard = Boolean(isExplicitSkip || isOpenPassForThisClose);
          let skipReason = "";
          if (isOpenPassForThisClose) {
            skipReason = "OPEN PASS -> CLOSE ZERO RULE (Rs 0 Risk Lock)";
          } else if (isExplicitSkip) {
            if (rec?.liveCombinedCut?.reason) skipReason = String(rec.liveCombinedCut.reason);
            else if (rec?.vipAutoStopSkipped || rec?.autoStopSkipped) skipReason = "DAILY PROFIT / LOSS TARGET STOP";
            else if (rec?.deliveryMissedAt) skipReason = String(rec?.deliveryMissedReason || "DELIVERY MISSED / NO LIVE GATEWAY");
            else if (rec?.loopAccountStop || rec?.accountStopped) skipReason = "LOOP ACCOUNT STOP RULE";
            else skipReason = "LOGIC / MANUAL SKIP (Rs 0 INVEST)";
          }
          let digits = String(rec?.sentDigits || rec?.d || "").trim();
          if (!digits && isSkippedCard) {
            digits = String(openRec?.sentDigits || openRec?.d || "0").trim();
          }
          if (!digits) continue;

          const recovState = savedProf
            ? getCardSameMarketRecoveryState(savedProf, dStr, "ank", idx, mName)
            : { debt: 0, consecutiveFails: 0, pendingProfit: 0, waveId: undefined };

          const prevLoss = Math.round(Number(recovState.debt || rec?.prevLoss || 0));
          const carriedProfit = isProfitCarryOn ? Math.round(Number(recovState.pendingProfit || 0)) : 0;
          const effectiveTargetProfit = baseTargetProfit + carriedProfit;
          const isGenuineManualRate = Boolean(rec?.manualRate && !rec?.manualStatus && Number(rec?.r) > 0);

          const rate = isOpenPassForThisClose && !isGenuineManualRate
            ? "0"
            : String(rec?.sentRate || rec?.r || rec?.recRate || "0").trim();
          const rateNum = Math.max(0, Number(rate) || 0);

          let smartInfo = rec?.smartStaking;
          if (!isOpenPassForThisClose && isSmartStakeOn && !isGenuineManualRate && (!smartInfo || !smartInfo.isSmartStaking)) {
            const computed = calculateSmartStakingRates(
              "ank",
              digits,
              prevLoss,
              effectiveTargetProfit,
              rec?.smartSelection?.strongDigits,
              rec?.smartSelection?.supportDigits
            );
            if (computed?.isSmartStaking) smartInfo = computed;
          }

          const isSettled = rec?.s === "PASS" || rec?.s === "FAIL";
          const isSent = Boolean(rec?.sentAt || rec?.dispatchState === "SENT" || isSettled || isSkippedCard);
          const actual = isSettled
            ? String(rec?.manualResult || rec?.scrapeResultDigit || rec?.backtestResult?.actual || "")
            : "";

          if (filter === "results" && !isSettled && !isSkippedCard) continue;
          if (filter === "sent" && !isSent) continue;
          if (period === "week" && !isSettled && !isSent) continue;

          const settled = (isSkippedCard && !isGenuineManualRate)
            ? { invest: 0, win: 0, net: 0 }
            : calculateSettlement({
                type: "ank",
                digits,
                rate,
                sentRate: rec?.sentAt ? rec?.sentRate : undefined,
                sentInvest: rec?.sentAt ? rec?.sentInvest : undefined,
                smartStaking: smartInfo?.isSmartStaking ? smartInfo : undefined,
                winningDigit: isSettled ? actual : undefined,
              });

          const invest = Math.round(Number(settled.invest || 0));
          const cardPl = isSkippedCard && !isGenuineManualRate
            ? 0
            : isSettled
            ? Math.round(rec.s === "PASS" ? Number(settled.net || (rateNum * 9.5 - invest)) : -invest)
            : 0;
          if (isSettled && !isSkippedCard) runningPl += cardPl;

          const sourceMode = String(rec?.sentSourceMode || rec?.sourceMode || rec?.positionRule || "AUTO SMART").trim();
          const trick = String(rec?.sentTrick || rec?.trick || "").trim();

          rawCards.push({
            date: dStr,
            idx,
            market: mName,
            digits,
            rate: String(rateNum),
            rateNum,
            invest,
            sourceMode,
            trick,
            isSettled: isSettled || isSkippedCard,
            isSent,
            status: isSkippedCard ? "SKIP" : isSettled ? String(rec.s) : isSent ? "SENT" : "WAIT",
            actual,
            cardPl,
            runningPl: Math.round(runningPl),
            ts: Number(rec?.settledAt || rec?.sentAt || Date.now()),
            isSmartStakeOn: Boolean(smartInfo?.isSmartStaking),
            strongDigits: Array.isArray(smartInfo?.strongDigits) ? smartInfo.strongDigits.join(", ") : undefined,
            supportDigits: Array.isArray(smartInfo?.supportDigits) ? smartInfo.supportDigits.join(", ") : undefined,
            strongRate: smartInfo?.strongRate,
            supportRate: smartInfo?.supportRate,
            isProfitCarryOn,
            prevLoss,
            carriedProfit,
            baseTargetProfit,
            isCloseZeroOn,
            isCloseZeroSkip: isOpenPassForThisClose && !isGenuineManualRate,
            isSkippedCard: isSkippedCard && !isGenuineManualRate,
            skipReason,
            isFourWaveOn,
            waveId: recovState.waveId,
          });
        }
      }

      // Running-day intelligent filtering:
      // When settled cards (PASS / FAIL / Close-Zero Skip) exist AND remaining markets are still WAIT/pending,
      // render ONLY the settled cards in the 3-step breakdown, and pass the pending markets to the dedicated
      // "Abhi Aage Ka Market Baki Hai — Dekhte Hain Aage Kya Hoga!" professional 3D scene!
      const isUnboxingReveal = b.videoMode === "unboxing_reveal";
      const targetMarketFilter = String(b.targetMarket || "ALL").trim().toUpperCase();
      const availableMarkets = Array.from(new Set(rawCards.map((c) => String(c.market || "").trim().toUpperCase()).filter(Boolean)));

      const settledCardsOnly = rawCards.filter((c) => c.isSettled);
      const unsettledGuessingCards = rawCards.filter((c) => !c.isSettled && String(c.digits || "").trim().length > 0);
      const hasSettledCards = settledCardsOnly.length > 0;

      // In Unboxing Reveal Mode: prioritize raw/unsettled guessing cards (or all cards with digits if all are settled),
      // and filter by targetMarket if the user picked a specific market to unbox!
      let cardsForVideo = isUnboxingReveal
        ? (unsettledGuessingCards.length > 0 ? unsettledGuessingCards : rawCards)
        : (hasSettledCards ? settledCardsOnly : rawCards);

      if (targetMarketFilter && targetMarketFilter !== "ALL") {
        const matchingMarketCards = rawCards.filter(
          (c) => String(c.market || "").trim().toUpperCase() === targetMarketFilter
        );
        if (matchingMarketCards.length > 0) {
          cardsForVideo = matchingMarketCards;
        }
      }

      const pendingMarkets: string[] = [];
      if (!isUnboxingReveal && hasSettledCards && filter !== "sent") {
        const latestDate = targetDates[targetDates.length - 1];
        const latestDayStore = savedProf?.dayRecords?.[latestDate];
        const lastSettledIdxOnLatest = settledCardsOnly
          .filter((c) => c.date === latestDate)
          .reduce((maxIdx, c) => Math.max(maxIdx, c.idx), -1);

        // Include any unsettled WAIT/SENT cards from rawCards + remaining enabled markets on latestDate after lastSettledIdxOnLatest
        const seenPending = new Set<string>();
        for (const c of rawCards) {
          if (!c.isSettled && c.date === latestDate) {
            const mLabel = String(c.market || "").trim().toUpperCase();
            if (mLabel && !seenPending.has(mLabel)) {
              seenPending.add(mLabel);
              pendingMarkets.push(mLabel);
            }
          }
        }
        if (latestDayStore && Array.isArray(mkts)) {
          for (let mIdx = Math.max(0, lastSettledIdxOnLatest + 1); mIdx < mkts.length; mIdx++) {
            const mktObj = mkts[mIdx];
            if (!mktObj) continue;
            const mName = String(mktObj.n || "").trim().toUpperCase();
            if (!mName || seenPending.has(mName)) continue;
            if (!isMarketEnabledForDate(savedProf?.config, latestDayStore?.visAnk, mName, latestDate)) continue;
            const rec = latestDayStore?.data?.[mIdx];
            if (rec?.s === "PASS" || rec?.s === "FAIL" || rec?.s === "SKIP") continue;
            seenPending.add(mName);
            pendingMarkets.push(mName);
          }
        }
      }

      // Compute exact 6-Metric Daily Report Summary ("Aaj Ka Chhota Review") across all settled/played cards of the day:
      // 1. Kitne card the (totalCards)
      // 2. Kitne fail hua aur kitne pass hua (totalFail, totalPass)
      // 3. Investment me kitna hua (totalInvest)
      // 4. Lagataar kitne card fail hua (maxConsecutiveFails)
      // 5. Max risk kitna tha (maxRiskExposure)
      // 6. Final profit ya loss kitne ka hua (finalNetPl)
      const reportBasisCards = settledCardsOnly.length > 0 ? settledCardsOnly : cardsForVideo;
      let summaryTotalPass = 0;
      let summaryTotalFail = 0;
      let summaryTotalInvest = 0;
      let curConsecutiveFails = 0;
      let maxConsecutiveFails = 0;
      let curCumulativeLoss = 0;
      let maxRiskExposure = 0;
      let summaryFinalNetPl = 0;

      for (const rc of reportBasisCards) {
        const inv = Math.max(0, Math.round(Number(rc.invest || 0)));
        summaryTotalInvest += inv;
        const currentPlayExposure = curCumulativeLoss + inv;
        if (currentPlayExposure > maxRiskExposure) {
          maxRiskExposure = currentPlayExposure;
        }
        if (!rc.isSkippedCard && !rc.isCloseZeroSkip && rc.status !== "SKIP") {
          if (rc.status === "PASS") {
            summaryTotalPass++;
            curConsecutiveFails = 0;
            curCumulativeLoss = 0;
          } else if (rc.status === "FAIL") {
            summaryTotalFail++;
            curConsecutiveFails++;
            if (curConsecutiveFails > maxConsecutiveFails) {
              maxConsecutiveFails = curConsecutiveFails;
            }
            curCumulativeLoss += inv;
            if (curCumulativeLoss > maxRiskExposure) {
              maxRiskExposure = curCumulativeLoss;
            }
          }
        }
        summaryFinalNetPl = Math.round(Number(rc.runningPl || 0));
      }

      const dailyReportSummary = {
        totalCards: reportBasisCards.length,
        totalPass: summaryTotalPass,
        totalFail: summaryTotalFail,
        totalInvest: summaryTotalInvest,
        maxConsecutiveFails,
        maxRiskExposure,
        finalNetPl: summaryFinalNetPl,
      };

      const positiveRates = cardsForVideo.map((c) => c.rateNum).filter((r) => r > 0);
      const baseRateNum = positiveRates.length > 0 ? Math.min(...positiveRates) : 10;

      const videoMode: "trailer_status" | "full_breakdown" | "unboxing_reveal" =
        b.videoMode === "unboxing_reveal"
          ? "unboxing_reveal"
          : b.videoMode === "trailer_status" || Number(b.durationSec) === 20
          ? "trailer_status"
          : "full_breakdown";

      let events: any[] = [];
      if (cardsForVideo.length > 0) {
        // In 15-30s Trailer Mode, select up to 5 top highlight cards (prioritizing PASS & Close-Zero skips)
        // and emit a single 1-Shot Power Scene (stepPhase: 3, action: 'TRAILER_HIGHLIGHT') per card so the
        // entire trailer finishes in 15-30 seconds with maximum impact!
        const selectedCards = videoMode === "unboxing_reveal"
          ? (targetMarketFilter !== "ALL" ? cardsForVideo.slice(-1) : cardsForVideo.slice(0, 4))
          : videoMode === "trailer_status"
          ? cardsForVideo.slice(-30)
          : cardsForVideo.slice(-30);

        for (let k = 0; k < selectedCards.length; k++) {
          const c = selectedCards[k];
          const prev = k > 0 ? selectedCards[k - 1] : null;
          const next = k + 1 < selectedCards.length ? selectedCards[k + 1] : null;
          const prevRateNum = prev && prev.rateNum > 0 ? prev.rateNum : baseRateNum;
          const prevStatus = prev ? prev.status : "START";
          const rateDiff = c.rateNum > prevRateNum ? c.rateNum - prevRateNum : 0;
          const cardSlot = k;

          const commonFields = {
            cardSlot,
            date: c.date,
            profileId,
            market: c.market,
            type: "ank",
            digits: c.digits,
            rate: c.rate,
            baseRate: String(baseRateNum),
            prevRate: String(prevRateNum),
            rateDiff,
            prevStatus,
            nextMarket: next?.market,
            nextRate: next?.rate,
            isLastCard: k === selectedCards.length - 1,
            hasPendingAfter: pendingMarkets.length > 0,
            invest: c.invest,
            sourceMode: "TITAN NOVA TRICK",
            trick: "",
            isSmartStakeOn: c.isSmartStakeOn,
            strongDigits: c.strongDigits,
            supportDigits: c.supportDigits,
            strongRate: c.strongRate,
            supportRate: c.supportRate,
            isProfitCarryOn: c.isProfitCarryOn,
            prevLoss: c.prevLoss,
            carriedProfit: c.carriedProfit,
            baseTargetProfit: c.baseTargetProfit,
            isCloseZeroOn: c.isCloseZeroOn,
            isCloseZeroSkip: c.isCloseZeroSkip,
            isSkippedCard: c.isSkippedCard,
            skipReason: c.skipReason,
            isFourWaveOn: c.isFourWaveOn,
            waveId: c.waveId,
          };

          if (videoMode === "unboxing_reveal") {
            events.push({
              ...commonFields,
              id: `card_${c.date}_${c.idx}_unbox`,
              stepPhase: 3,
              ts: c.ts,
              timeIST: "UNBOXING",
              action: "UNBOXING_REVEAL",
              status: "WAIT",
              actual: "LIVE",
              pl: 0,
              netDayPl: c.runningPl,
              subtitle: "",
            });
            continue;
          }

          if (videoMode === "trailer_status") {
            events.push({
              ...commonFields,
              id: `card_${c.date}_${c.idx}_trailer`,
              stepPhase: 3,
              ts: c.ts,
              timeIST: "HIGHLIGHT",
              action: "TRAILER_HIGHLIGHT",
              status: c.status,
              actual: c.actual,
              pl: c.cardPl,
              netDayPl: c.runningPl,
              subtitle: "",
            });
            continue;
          }

          // If this card was SKIPPED by logic (Close Zero / Daily Stop / Cut / Missed), do NOT show all 3 steps!
          // Emit 1 crisp CARD_SKIPPED notice stating the exact skip reason and immediately move to the next card.
          if (c.isSkippedCard || c.status === "SKIP") {
            events.push({
              ...commonFields,
              id: `card_${c.date}_${c.idx}_skip`,
              stepPhase: 3,
              ts: c.ts,
              timeIST: "SKIPPED",
              action: "CARD_SKIPPED",
              status: "SKIP",
              actual: "SKIP",
              pl: 0,
              netDayPl: c.runningPl,
              subtitle: "",
            });
            continue;
          }

          // STEP 1: Normal Card Start + Titan Nova Guessing Trick / Smart Stake Split
          events.push({
            ...commonFields,
            id: `card_${c.date}_${c.idx}_step1`,
            stepPhase: 1,
            ts: c.ts,
            timeIST: "STEP 1",
            action: "DIGITS_APPLIED",
            status: "WAIT",
            netDayPl: prev ? prev.runningPl : 0,
            subtitle: "",
          });

          // STEP 2: Rate Logic (Smart Stake / Profit Carry / Close Zero / 4-Wave)
          events.push({
            ...commonFields,
            id: `card_${c.date}_${c.idx}_step2`,
            stepPhase: 2,
            ts: c.ts + 1,
            timeIST: "STEP 2",
            action: "CARD_SENT",
            status: "SENT",
            netDayPl: prev ? prev.runningPl : 0,
            subtitle: "",
          });

          // STEP 3: Live Result Reveal (PASS / FAIL / Close Zero Safe Skip) + Next Card Plan
          if (c.isSettled) {
            events.push({
              ...commonFields,
              id: `card_${c.date}_${c.idx}_step3`,
              stepPhase: 3,
              ts: c.ts + 2,
              timeIST: "STEP 3",
              action: "RESULT_SETTLED",
              status: c.status,
              actual: c.actual,
              pl: c.cardPl,
              netDayPl: c.runningPl,
              subtitle: "",
            });
          }
        }
      } else if (Array.isArray(b.events) && b.events.length > 0) {
        events = b.events;
      } else {
        for (const dStr of targetDates) {
          events.push(...activityRecorder.readDate(dStr, profileId));
        }
      }

      if (!events.length) {
        return res.json({ status: "success", empty: true, hasFfmpeg: await isFfmpegAvailable(), events: [] });
      }

      const profName = savedProf?.name || profileId;
      const style = ["cyber_neon", "gold_royal", "emerald_matrix"].includes(String(b.style)) ? b.style : "cyber_neon";
      const hookStyle = ["auto_viral", "hook_a", "hook_b", "hook_c", "hook_d", "hook_e"].includes(String(b.hookStyle)) ? b.hookStyle : "auto_viral";
      const durationSec = [20, 30, 45, 60, 75].includes(Number(b.durationSec)) ? (Number(b.durationSec) as 20 | 30 | 45 | 60 | 75) : (videoMode === "trailer_status" || videoMode === "unboxing_reveal" ? 20 : 60);
      const voiceLang = ["hinglish", "hindi", "english"].includes(String(b.voiceLang)) ? b.voiceLang : "hinglish";
      const voiceGender = b.voiceGender === "male" ? "male" : "female";
      const voicePack = ["swara_hi", "madhur_hi", "andrew_pro", "brian_hype", "ava_studio", "emma_reels", "gemini_flash_tts", "minimax", "elevenlabs", "xai_grok", "heygen"].includes(String(b.voicePack)) ? b.voicePack : "swara_hi";
      const voiceEnabled = b.voiceEnabled !== false;
      const voicePitchShift = Number.isFinite(Number(b.voicePitchShift)) ? Math.max(0.75, Math.min(1.25, Number(b.voicePitchShift))) : undefined;
      const voiceSpeed = Number.isFinite(Number(b.voiceSpeed)) ? Math.max(0.75, Math.min(1.35, Number(b.voiceSpeed))) : undefined;
      const musicStyle = ["cinematic_bass", "lofi_chill", "upbeat_synth", "off"].includes(String(b.musicStyle)) ? b.musicStyle : "cinematic_bass";
      const customTitle = b.customTitle ? String(b.customTitle).slice(0, 60) : undefined;
      const customCta = b.customCta ? String(b.customCta).slice(0, 80) : undefined;

      const savedVoicePath = path.join(titanDataDir, "custom_voice_sample.b64");
      let voiceSampleBase64: string | undefined = undefined;
      if (typeof b.voiceSampleBase64 === "string" && b.voiceSampleBase64.length > 100) {
        voiceSampleBase64 = b.voiceSampleBase64;
        try { fs.writeFileSync(savedVoicePath, voiceSampleBase64, "utf8"); } catch (_) {}
      } else if (b.clearVoiceSample === true) {
        try { if (fs.existsSync(savedVoicePath)) fs.rmSync(savedVoicePath, { force: true }); } catch (_) {}
      } else if (fs.existsSync(savedVoicePath)) {
        try { voiceSampleBase64 = fs.readFileSync(savedVoicePath, "utf8"); } catch (_) {}
      }

      const result = await renderActivityGifVideo(events, {
        secondsPerStep,
        showSubtitles,
        profileName: profName,
        period,
        dateRangeLabel,
        style,
        hookStyle,
        durationSec,
        videoMode,
        socialPlatform: b.socialPlatform ? String(b.socialPlatform) : undefined,
        voiceLang,
        voiceGender,
        voicePack,
        voiceEnabled,
        voicePitchShift,
        voiceSpeed,
        voiceSampleBase64,
        musicStyle,
        customTitle,
        customCta,
        pendingMarkets,
        dailyReportSummary,
      });

      if (!result.available || !result.buffer) {
        return res.json({
          status: "success",
          hasFfmpeg: false,
          hasEmbeddedVoice: false,
          frameCount: events.length,
          voiceScript: result.voiceScript || [],
          pendingMarkets,
          availableMarkets,
          events: events.slice(-45),
        });
      }

      res.json({
        status: "success",
        hasFfmpeg: true,
        hasEmbeddedVoice: Boolean(result.hasEmbeddedVoice),
        mimeType: result.mimeType,
        frameCount: result.frameCount,
        sizeBytes: result.buffer.length,
        videoBase64: result.buffer.toString("base64"),
        voiceScript: result.voiceScript || [],
        pendingMarkets,
        availableMarkets,
        events: events.slice(-45),
      });
    } catch (e: any) {
      res.status(500).json({ status: "error", message: e?.message || "Activity video render failed" });
    }
  });

  app.get("/api/app/state", (req, res) => {
    try {
      const started=performance.now();
      restoreSavedAdminSchedules();
      const stored = readFullAppStateView(true);
      if (!stored) return res.json({ status: 'success', exists: false, state: null });
      const merged = mergeLedgerIntoFullAppState(stored);
      if (merged !== stored) writeFullAppState(merged);

      const profileId = String(req.query.profileId || '').trim();
      if (profileId) {
        if (!hasProfileAccess(req, profileId)) return rejectProfileAccess(res, profileId);
        const prof = merged.profiles?.[profileId];
        const scoped = prof ? {
          activeId: profileId,
          profiles: { [profileId]: prof },
          sourceIndexHistory: profileId !== 'admin1' ? buildSourceIndexHistory(merged.profiles?.admin1, prof) : undefined,
          paymentMethods: merged.paymentMethods || {},
          payments: Array.isArray(merged.payments) ? merged.payments.filter((p: any) => String(p?.userId || '') === profileId) : [],
          broadcasts: [],
        } : null;
        res.set('Cache-Control', 'no-store');
        const body=serializeWorkspaceSnapshot(scoped,req.query.knownStateHash);
        res.set('Server-Timing',`workspace;dur=${(performance.now()-started).toFixed(1)}`);
        return res.type('json').send(body);
      }

      if (isVipPortalRequest(req)) {
        return res.status(403).json({ status: 'error', message: 'VIP portal must request its token-scoped profile state' });
      }

      res.set('Cache-Control', 'no-store');
      const body=serializeWorkspaceSnapshot(merged,req.query.knownStateHash);
      res.set('Server-Timing',`workspace;dur=${(performance.now()-started).toFixed(1)}`);
      res.type('json').send(body);
    } catch (e: any) {
      res.status(500).json({ status: 'error', message: e?.message || 'state read failed' });
    }
  });

  /** Persist one market switch atomically for one Admin/VIP profile. */
  app.post("/api/app/profile_market_toggle", (req, res) => {
    try {
      const profileId = String(req.body?.profileId || '').trim();
      const baseMarketName = String(req.body?.baseMarketName || '').trim();
      const date = String(req.body?.date || '').trim();
      const enabled = req.body?.enabled;
      if (!profileId || !baseMarketName || !/^\d{4}-\d{2}-\d{2}$/.test(date) || typeof enabled !== 'boolean') {
        return res.status(400).json({ status: 'error', message: 'profileId, market, enabled and valid date required' });
      }
      if (isVipPortalRequest(req) && !hasProfileAccess(req, profileId)) {
        return rejectProfileAccess(res, profileId);
      }
      const stored = readFullAppState();
      if (!stored?.profiles?.[profileId]) {
        return res.status(404).json({ status: 'error', message: 'Profile not found' });
      }
      if (isVipPortalRequest(req) && stored.profiles[profileId].vipAccessEnabled === false) {
        return res.status(403).json({ status: 'error', message: 'VIP profile is read-only' });
      }

      const nextState = applyProfileMarketToggle(stored, profileId, baseMarketName, enabled, date);
      writeFullAppState(nextState);

      // Runtime automation must observe the same isolated setting immediately,
      // without waiting for the next eight-second dashboard ledger snapshot.
      const runtimeProfile = botState.ledgerState?.profiles?.[profileId];
      if (runtimeProfile && String(botState.ledgerState?.date || '') === date) {
        runtimeProfile.markets = setRuntimeMarketEnabled(runtimeProfile.markets, baseMarketName, enabled);
        enforceVipLiveBoundary(profileId, runtimeProfile);
        persistLedgerSnapshot();
      }

      res.json({
        status: 'success',
        profileId,
        profile: nextState.profiles[profileId],
      });
    } catch (e: any) {
      res.status(500).json({ status: 'error', message: e?.message || 'market setting save failed' });
    }
  });

  app.post('/api/app/profile_profit_notifications', (req, res) => {
    try {
      const profileId = String(req.body?.profileId || '');
      const enabled = req.body?.enabled;
      if (!profileId || typeof enabled !== 'boolean') return res.status(400).json({ status: 'error', message: 'Profile and boolean enabled required' });
      if (isVipPortalRequest(req) && !hasProfileAccess(req, profileId)) return rejectProfileAccess(res, profileId);
      const full = readFullAppState();
      const profile = full?.profiles?.[profileId];
      if (!profile) return res.status(404).json({ status: 'error', message: 'Profile not found' });
      if (isVipPortalRequest(req) && profile.vipAccessEnabled === false) return res.status(403).json({ status: 'error', message: 'VIP profile is read-only' });
      if (profileId === 'admin1') {
        botState.profitMilestoneNotificationsEnabled = enabled;
        persistLoginConfig();
      } else {
        writeFullAppState({ ...full, profiles: { ...full.profiles, [profileId]: { ...profile, profitMilestoneNotificationsEnabled: enabled } } });
      }
      if (!enabled) cancelProfileProfitNotifications(profileId);
      // ON arms future settlement milestones; it does not replay existing profit.
      res.json({ status: 'success', profileId, enabled });
    } catch (error: any) {
      res.status(500).json({ status: 'error', message: error?.message || 'Profit notification setting failed' });
    }
  });

  /** Explicit VIP-only pause/resume. A resumed cycle retains financial history. */
  app.post('/api/app/vip_game_run', (req, res) => {
    try {
      const pid = String(req.body?.profileId || '');
      const type = String(req.body?.cardType || '');
      const enabled = req.body?.enabled;
      if (!pid || pid === 'admin1' || !['ank', 'jodi', 'pannel'].includes(type) || typeof enabled !== 'boolean') {
        return res.status(400).json({ status: 'error', message: 'VIP profile, game type and enabled required' });
      }
      if (isVipPortalRequest(req) && !hasProfileAccess(req, pid)) return rejectProfileAccess(res, pid);
      let full = readFullAppState();
      const saved = full?.profiles?.[pid];
      if (!saved) return res.status(404).json({ status: 'error', message: 'Profile not found' });
      if (isVipPortalRequest(req) && saved.vipAccessEnabled === false) return res.status(403).json({ status: 'error', message: 'VIP profile is read-only' });
      const date = calculateBusinessDateIST();
      if (req.body?.date !== date) return res.status(400).json({ status: 'error', message: 'Game control applies to the current business day only' });
      if (botState.ledgerState.date !== date) return res.status(409).json({ status: 'error', message: 'Live ledger is not ready; refresh and retry' });
      const runtime: any = botState.ledgerState.profiles?.[pid];
      if (!runtime) return res.status(409).json({ status: 'error', message: 'Live VIP ledger is not ready; refresh and retry' });
      const old = saved.vipGameRuns?.[type];
      if (enabled && old?.date === date && old.on) return res.json({ status: 'success', profile: saved });
      const totals = vipGameTotals(runtime, type as any, '*');
      const run = { date, on: enabled, baseProfit: enabled ? totals.profit : (old?.date === date ? old.baseProfit : 0),
        baseInvest: enabled ? totals.invest : (old?.date === date ? old.baseInvest : 0),
        baselineCards: enabled ? vipBaselineCards(runtime, type as any) : (old?.date === date ? old.baselineCards : undefined),
        ...(!enabled ? { reason: 'MANUAL_OFF' as const } : {}), updatedAt: Date.now() };
      runtime.vipGameRuns = { ...saved.vipGameRuns, [type]: run };
      full = { ...full, profiles: { ...full.profiles, [pid]: { ...saved, vipGameRuns: runtime.vipGameRuns } } };
      writeFullAppState(full);
      let resumedCards=0, missedCards=0;
      if (!enabled) enforceVipGameRun(pid, type);
      else {
        enforceVipLiveBoundary(pid, runtime);
        for (const [key, card] of Object.entries(runtime.cards || {}) as Array<[string, any]>) {
          if (!card || !key.startsWith(`${type}_`) || !(card.vipAutoStopSkipped||card.vipAutoStopResumeEligible) || !['SKIP','WAIT'].includes(card.s) || card.sentRate || card.sentDigits || card.sentAt || ['SENT','SETTLED'].includes(card.dispatchState)) continue;
          if(card.deliveryRestoredAt && !card.vipAutoStopResumeEligible)continue;
          const market = runtime.markets.find((m: any) => `${m.type}_${m.index}` === key);
          // A missed market stays SKIP; resuming must never send retrospective bets.
          if (!market || market.enabled===false || vipResumeCutoffReached(saved, runtime, market, type as any)) {missedCards++;continue;}
          const releaseKeys=vipResumeExpiredKeys(pid,date,key,card);
          card.s = 'WAIT'; delete card.vipAutoStopSkipped;
          delete card.vipAutoStopResumeEligible; delete card.deliveryRestoredAt;
          // A new play generation fences cancelled ACKs and stale paused browser snapshots.
          card.cardGeneration=Math.max(Date.now(),Number(card.cardGeneration||0)+1,Number(card.sourceEditedAt||0)+1);
          card.sourceEditedAt=card.cardGeneration;
          delete card.deliveryMissedAt; delete card.deliveryMissedReason;
          delete card.dispatchState; delete card.dispatchKey; delete card.queuedAt;
          for(const expiredKey of releaseKeys)delete expiredBroadcastKeys[expiredKey];
          resumedCards++;
        }
        persistExpiredBroadcastKeys();
        finalizeProfileReadyRates(pid, 'manual-game-resume');
      }
      botState.ledgerState.updatedAt = Date.now(); persistLedgerSnapshot();
      // Restored WAIT must replace only this feature's SKIP, never settled history.
      const latest = readFullAppState();
      if (latest) {
        const profile = latest.profiles[pid];
        const day = profile.dayRecords?.[date];
        if (enabled && day) for (const [key, card] of Object.entries(runtime.cards || {}) as Array<[string, any]>) {
          if (!card || !key.startsWith(`${type}_`) || card.s !== 'WAIT') continue;
          const index = Number(key.split('_')[1]);
          const dict = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
          if (day[dict]?.[index]?.vipAutoStopSkipped || day[dict]?.[index]?.vipAutoStopResumeEligible) day[dict][index] = { ...day[dict][index], ...card, vipAutoStopSkipped: undefined, vipAutoStopResumeEligible: undefined, deliveryRestoredAt: undefined };
        }
        writeFullAppState(mergeLedgerIntoFullAppState(latest));
      }
      if (enabled) queueVipAutoReadyCards('manual-game-resume');
      return res.json({ status: 'success', profile: readFullAppState()?.profiles?.[pid], resumedCards, missedCards });
    } catch (error: any) {
      return res.status(500).json({ status: 'error', message: error?.message || 'VIP game control failed' });
    }
  });

  /** Persist and enforce one Admin/VIP card-type delivery switch immediately. */
  app.post('/api/app/profile_schedule_policy', (req, res) => {
    try {
      const profileId = String(req.body?.profileId || '').trim();
      const cardType = String(req.body?.cardType || '').toLowerCase();
      const enabled = req.body?.enabled;
      if (!profileId || !['ank', 'jodi', 'pannel'].includes(cardType) || typeof enabled !== 'boolean') {
        return res.status(400).json({ status: 'error', message: 'profileId, valid cardType and enabled required' });
      }
      if (isVipPortalRequest(req) && !hasProfileAccess(req, profileId)) return rejectProfileAccess(res, profileId);
      const stored = readFullAppState();
      const storedProfile = stored?.profiles?.[profileId];
      if (!storedProfile) return res.status(404).json({ status: 'error', message: 'Profile not found' });
      if (isVipPortalRequest(req) && storedProfile.vipAccessEnabled === false) {
        return res.status(403).json({ status: 'error', message: 'VIP profile is read-only' });
      }

      const previous = profileId === 'admin1'
        ? storedProfile.config?.scheduleTypeEnabled || {}
        : storedProfile.vipScheduleEnabled || {};
      const nextPolicy = {
        ank: previous.ank !== false,
        jodi: previous.jodi !== false,
        pannel: previous.pannel !== false,
        [cardType]: enabled,
      };
      const nextProfile = profileId === 'admin1'
        ? { ...storedProfile, config: { ...storedProfile.config, scheduleTypeEnabled: nextPolicy } }
        : { ...storedProfile, vipScheduleEnabled: nextPolicy };
      writeFullAppState({ ...stored, profiles: { ...stored.profiles, [profileId]: nextProfile } });

      botState.schedulePolicy[profileId] = nextPolicy;
      const runtimeProfile: any = botState.ledgerState?.profiles?.[profileId];
      if (runtimeProfile) runtimeProfile.schedulePolicy = nextPolicy;

      let cancelled = 0;
      if (!enabled) {
        for (const job of botState.pendingBroadcasts || []) {
          const matches = job?.status === 'pending' && String(job?.profileId || '') === profileId && String(job?.cardType || '') === cardType;
          if (!matches) continue;
          cancelled++;
          job.failedTargets = normalizeTargetList(job.targets);
          finishResolvedBroadcast(job, 'CARD_TYPE_DISABLED');
        }
        const beforeCount = (botState.activeSchedules || []).length;
        botState.activeSchedules = (botState.activeSchedules || []).filter(
          (item: any) => !(String(item?.profileId || 'admin1') === profileId && String(item?.type || '') === cardType)
        );
        if (botState.activeSchedules.length !== beforeCount) {
          atomicWriteFileAsync(path.join(titanDataDir, 'active_schedules.json'), JSON.stringify(botState.activeSchedules), 'active-schedules');
        }
      }
      persistPendingBroadcasts();
      persistLedgerSnapshot();
      if (enabled && profileId !== 'admin1') queueVipAutoReadyCards('policy-enabled');
      return res.json({ status: 'success', profileId, cardType, enabled, policy: nextPolicy, cancelled });
    } catch (error: any) {
      return res.status(500).json({ status: 'error', message: error?.message || 'schedule policy save failed' });
    }
  });

  /** Persist one VIP delivery destination atomically and update queued work immediately. */
  app.post('/api/app/profile_delivery_destination', (req, res) => {
    try {
      const profileId = String(req.body?.profileId || '').trim();
      const mode = String(req.body?.mode || '').trim();
      const destinationName = String(req.body?.destinationName || '').trim();
      if (!profileId || profileId === 'admin1' || !['private', 'group', 'channel'].includes(mode)) {
        return res.status(400).json({ status: 'error', message: 'Valid VIP profile and delivery mode required' });
      }
      if (isVipPortalRequest(req) && !hasProfileAccess(req, profileId)) return rejectProfileAccess(res, profileId);
      const stored = readFullAppState();
      const storedProfile = stored?.profiles?.[profileId];
      if (!storedProfile) return res.status(404).json({ status: 'error', message: 'VIP profile not found' });
      if (isVipPortalRequest(req) && storedProfile.vipAccessEnabled === false) {
        return res.status(403).json({ status: 'error', message: 'VIP profile is read-only' });
      }

      const destination = mode === 'group'
        ? normalizeTargetJid(req.body?.destinationJid, 'group')
        : mode === 'channel'
          ? normalizeTargetJid(req.body?.destinationJid, 'channel')
          : normalizeTargetJid(req.body?.destinationJid, 'phone');
      if (mode === 'group' && !destination) return res.status(400).json({ status: 'error', message: 'Valid WhatsApp Group required' });
      if (mode === 'channel' && !destination) return res.status(400).json({ status: 'error', message: 'Valid WhatsApp Channel required' });

      const nextProfile = {
        ...storedProfile,
        vipDestinationConfirmed: true,
        ...(mode === 'private' && destination ? { phone: destination, vipSchTarget: destination } : {}),
        vipDeliveryMode: mode,
        vipGroupJid: mode === 'group' ? destination : undefined,
        vipGroupName: mode === 'group' ? (destinationName || destination) : undefined,
        vipChannelJid: mode === 'channel' ? destination : undefined,
        vipChannelName: mode === 'channel' ? (destinationName || destination) : undefined,
      };
      writeFullAppState({ ...stored, profiles: { ...stored.profiles, [profileId]: nextProfile } });

      const runtimeProfile: any = botState.ledgerState?.profiles?.[profileId];
      if (runtimeProfile) {
        runtimeProfile.deliveryMode = mode;
        if (mode === 'private' && destination) runtimeProfile.phone = destination;
        runtimeProfile.vipGroupJid = mode === 'group' ? destination : undefined;
        runtimeProfile.vipChannelJid = mode === 'channel' ? destination : undefined;
        runtimeProfile.deliveryTargets = destination ? [destination] : [];
        runtimeProfile.deliveryTargetName = destinationName || destination || '';
        for (const job of botState.pendingBroadcasts || []) {
          if (job?.status !== 'pending' || String(job?.profileId || '') !== profileId) continue;
          if (job.broadcastKind !== 'vip-auto-card' && job.broadcastKind !== 'result-followup') continue;
          const currentTargets = new Set(serverVipDeliveryTargets(runtimeProfile));
          for (const target of normalizeTargetList(job.targets)) {
            if (!currentTargets.has(target)) job.failedTargets = [...new Set([...(job.failedTargets || []), target])];
          }
          finishResolvedBroadcast(job, 'VIP_DESTINATION_CHANGED');
        }
        persistLedgerSnapshot();
        persistPendingBroadcasts();
        queueVipAutoReadyCards('destination-saved');
      }
      return res.json({ status: 'success', profileId, mode, destination: destination || '' });
    } catch (error: any) {
      return res.status(500).json({ status: 'error', message: error?.message || 'VIP destination save failed' });
    }
  });

  app.post('/api/app/profile_card_sender_format',(req,res)=>{
    try{
      const profileId=String(req.body?.profileId||'').trim(),format=req.body?.cardSenderFormat,platform=req.body?.platform;
      if(!profileId||!['text','png'].includes(format)||(platform!==undefined&&!['whatsapp','telegram'].includes(platform)))return res.status(400).json({status:'error',message:'Valid profileId and text/png format required'});
      if(isVipPortalRequest(req)&&!hasProfileAccess(req,profileId))return rejectProfileAccess(res,profileId);
      const stored=readFullAppState();
      if(!stored?.profiles?.[profileId])return res.status(404).json({status:'error',message:'Profile not found'});
      if(isVipPortalRequest(req)&&stored.profiles[profileId].vipAccessEnabled===false)return res.status(403).json({status:'error',message:'VIP profile is read-only'});
      writeFullAppState(applyProfileCardSenderFormat(stored,profileId,format,platform));
      res.json({status:'success',profileId,cardSenderFormat:format,...(platform?{platform}: {})});
    }catch(e:any){res.status(500).json({status:'error',message:e.message||'Sender save failed'});}
  });

  // Internal/local bot route: render the exact already-guarded delivery snapshot.
  app.post('/api/bot/card_png',async(req,res)=>{
    let data;try{data=scheduledCardImage(req.body);}catch(e:any){return res.status(400).json({status:'error',message:e.message});}
    try{res.set('Cache-Control','no-store').type('png').send(await renderScheduledCardPngAsync(data));}
    catch(error:any){res.status(String(error?.message||'').includes('busy')?503:500).json({status:'error',message:'PNG generation unavailable; card remains pending'});}
  });

  // Profile presentation is read from its atomic saved preference. Delivery identity stays unchanged.
  function cardPresentation(item:any,stored=readFullAppStateView()){
    const profile=stored?.profiles?.[String(item.profileId||'admin1')];
    const {senderFormat,senderFormats}=cardSenderPresentation(item,profile?.config);
    const date=String(item.date||botState.ledgerState?.date||calculateBusinessDateIST());
    const detailedMessage=item.senderFormat==='png'||item.senderFormat==='text'?item.detailedMessage!==false:profile?.config?.detailedMessage!==false;
    const supportKeys=Object.keys(item.digitSupport||{}),tokens=String(item.digits||'').split(/[,|\s]+/).filter(Boolean);
    const frozenSupport=supportKeys.length>0&&supportKeys.length<=3&&new Set(Object.values(item.digitSupport)).size===supportKeys.length&&supportKeys.every(key=>tokens.includes(key)&&['Strong','Support','SupportLow'].includes(item.digitSupport[key]))?item.digitSupport:undefined;
    return {senderFormat,senderFormats,detailedMessage,date,...(cardUsesPng({senderFormat,senderFormats})?{digitSupport:frozenSupport??cardDigitSupport(profile,date,item.type||item.cardType,item.marketName,String(item.digits||''),String(item.profileId||'admin1')!=='admin1'?stored?.profiles?.admin1:undefined)??{}}:{})};
  }

  /** Persist Detailed/Simple WhatsApp/Telegram format for exactly one profile. */
  app.post("/api/app/profile_message_format", (req, res) => {
    try {
      const profileId = String(req.body?.profileId || '').trim();
      const detailedMessage = req.body?.detailedMessage;
      if (!profileId || typeof detailedMessage !== 'boolean') {
        return res.status(400).json({ status: 'error', message: 'profileId and detailedMessage required' });
      }
      if (isVipPortalRequest(req) && !hasProfileAccess(req, profileId)) {
        return rejectProfileAccess(res, profileId);
      }
      const stored = readFullAppState();
      if (!stored?.profiles?.[profileId]) {
        return res.status(404).json({ status: 'error', message: 'Profile not found' });
      }
      if (isVipPortalRequest(req) && stored.profiles[profileId].vipAccessEnabled === false) {
        return res.status(403).json({ status: 'error', message: 'VIP profile is read-only' });
      }

      const nextState = applyProfileMessageFormat(stored, profileId, detailedMessage);
      writeFullAppState(nextState);

      const runtimeProfile = botState.ledgerState?.profiles?.[profileId];
      if (runtimeProfile) {
        runtimeProfile.detailedMessage = detailedMessage;
        persistLedgerSnapshot();

        // A reserved but unsent item must follow the newly acknowledged
        // profile format. Sent history remains immutable.
        if (refreshPendingFormattedMessages(profileId) > 0) persistPendingBroadcasts();
      }

      res.json({ status: 'success', profileId, detailedMessage });
    } catch (e: any) {
      res.status(500).json({ status: 'error', message: e?.message || 'message format save failed' });
    }
  });

  /** Persist per-game visibility atomically for exactly one profile/day. */
  app.post("/api/app/profile_visibility", (req, res) => {
    try {
      const profileId = String(req.body?.profileId || '').trim();
      const date = String(req.body?.date || '').trim();
      const updates = normalizeVisibilityUpdates(req.body?.updates);
      if (!profileId || !/^\d{4}-\d{2}-\d{2}$/.test(date) || updates.length === 0) {
        return res.status(400).json({ status: 'error', message: 'profileId, valid date and visibility updates required' });
      }
      if (isVipPortalRequest(req) && !hasProfileAccess(req, profileId)) {
        return rejectProfileAccess(res, profileId);
      }
      const stored = readFullAppState();
      if (!stored?.profiles?.[profileId]) {
        return res.status(404).json({ status: 'error', message: 'Profile not found' });
      }
      if (isVipPortalRequest(req) && stored.profiles[profileId].vipAccessEnabled === false) {
        return res.status(403).json({ status: 'error', message: 'VIP profile is read-only' });
      }
      const nextState = applyProfileVisibilityUpdates(stored, profileId, date, updates);
      writeFullAppState(nextState);
      const runtimeProfile = botState.ledgerState?.profiles?.[profileId];
      if (runtimeProfile&&botState.ledgerState.date===date) {
        runtimeProfile.markets = applyRuntimeVisibilityUpdates(runtimeProfile.markets, updates);
        persistLedgerSnapshot();
      }
      res.json({ status: 'success', profileId, updates });
    } catch (e: any) {
      res.status(500).json({ status: 'error', message: e?.message || 'visibility save failed' });
    }
  });

  const bulkReceiptResult=(receipt:BulkReceipt):any=>{
    const state=readFullAppStateView(true);
    if(receipt.kind==='undo')return {status:'success',operationId:receipt.id,date:receipt.date,cards:receipt.cards,
      days:Object.fromEntries((receipt.profileIds||[]).map(id=>[id,state?.profiles?.[id]?.dayRecords?.[receipt.date]]))};
    const historical=receipt.date!==String(botState.ledgerState?.date||calculateBusinessDateIST());
    const records=historical?state?.profiles?.[receipt.profileId]?.dayRecords?.[receipt.date]?.data:botState.ledgerState?.profiles?.[receipt.profileId]?.cards;
    return {status:'success',operationId:receipt.id,profileId:receipt.profileId,date:receipt.date,type:'ank',results:receipt.results,
      cards:Object.fromEntries((receipt.indices||[]).map(i=>[i,records?.[historical?i:`ank_${i}`]]))};
  };
  app.get('/api/app/bulk_operation',(req,res)=>{
    const pid=String(req.query.profileId||'admin1'),date=String(req.query.date||''),id=String(req.query.operationId||''),kind=String(req.query.kind||'');
    if(!hasProfileAccess(req,pid)||(kind==='undo'&&isVipPortalRequest(req)))return rejectProfileAccess(res,pid);
    res.set('Cache-Control','no-store');
    const receipt=bulkOperationReceipts.find(id);
    if(!receipt||receipt.profileId!==pid||receipt.date!==date||receipt.kind!==kind)return res.status(404).json({status:'error',code:'BULK_OPERATION_NOT_FOUND',message:'No saved confirmation for this action'});
    try{return res.json(bulkReceiptResult(receipt));}catch(error:any){return res.status(500).json({status:'error',message:error?.message||'Confirmation unavailable'});}
  });

  app.post('/api/app/restore_backtest', (req, res) => {
    try {
      if (isVipPortalRequest(req)) return res.status(403).json({ status: 'error', message: 'Bulk backtest restore is an Admin action' });
      const date = String(req.body?.date || '').trim(), pid = String(req.body?.profileId || 'admin1');
      if (!validLoopDate(date) || date >= businessDateIST()) return res.status(400).json({ status: 'error', message: 'Bulk Restore: choose a valid past Ledger date' });
      const receipt=bulkOperationReceipts.prepare(req.body,'undo');
      if(receipt&&bulkOperationReceipts.find(receipt.id))return res.json(bulkReceiptResult(receipt));
      const state = readFullAppState();
      if (!state?.profiles?.[pid]||(!state.profiles[pid].dayRecords?.[date]&&!req.body?.sourceDays?.[pid])) return res.status(404).json({ status: 'error', message: 'Selected backtest day not found' });
      const ids = Object.keys(state.profiles).filter(id => id === pid || (pid === 'admin1' && req.body?.mirrorAdmin === true && vipCopiesAdmin(state.profiles[id])));
      const job=rangeRunner.view();
      if(job&&ids.includes(job.profileId)&&(job.busy||job.state==='running'||job.state==='paused')&&date>=job.from&&date<=job.to)return res.status(409).json({status:'error',message:'Stop the range trial before Undo All on this date.'});
      const profiles = { ...state.profiles }, days: Record<string, any> = {};
      let cards = 0;
      for (const id of ids) {
        let profile = mergeRestoreSources(profiles[id],date,req.body?.sourceDays?.[id]);
        const settings=req.body?.settings?.[id],visibility=normalizeVisibilityUpdates(settings?.visibility);
        if(visibility.length)profile=applyProfileVisibilityUpdates({profiles:{[id]:profile}},id,date,visibility).profiles[id];
        if(typeof settings?.openToCloseCut==='boolean')profile={...profile,dayRecords:{...profile.dayRecords,[date]:{...profile.dayRecords[date],openToCloseCut:settings.openToCloseCut}}};
        if (!profile.dayRecords?.[date]) continue;
        const revision=Number(req.body?.revision);
        const next = restoreBacktestDay(profile, date), day = { ...next.dayRecords[date], backtestRevision: Math.max(Date.now(), Number(profile.dayRecords[date].backtestRevision || 0) + 1,Number.isSafeInteger(revision)&&revision>0?revision:0) };
        profiles[id] = { ...next, dayRecords: { ...next.dayRecords, [date]: day } };
        days[id] = day;
        if (id === pid) cards = ['data','jodiData','pannelData'].reduce((total, key) => total + Object.keys(day[key] || {}).length, 0);
      }
      bulkOperationReceipts.commit(receipt?{...receipt,profileIds:Object.keys(days),cards}:undefined,()=>writeFullAppState({ ...state, profiles }));
      return res.json({ status: 'success', operationId:receipt?.id, date, cards, days });
    } catch (error: any) {
      return res.status(error?.statusCode||500).json({ status: 'error', message: error?.message || 'Backtest restore failed' });
    }
  });

  // Admin-only independent actual-result carry; existing parity/cut settings remain saved.
  app.post('/api/app/profile_result_carry6',(req,res)=>{
    try{
      const pid=String(req.body?.profileId||''),date=String(req.body?.date||businessDateIST()),enabled=req.body?.enabled,mode=req.body?.mode;
      if(!pid||typeof enabled!=='boolean'||!validLoopDate(date)||date>businessDateIST()||(mode!==undefined&&(!['OFF','CARRY6','CUT3'].includes(mode)||enabled!==(mode==='CARRY6'))))return res.status(400).json({status:'error',message:'Profile, valid date and matching enabled/mode required'});
      if(isVipPortalRequest(req)||isDeletedProfile(pid))return rejectProfileAccess(res,pid);
      const full=readFullAppState(),p=full?.profiles?.[pid];if(!p)return res.status(404).json({status:'error',message:'Profile not found'});
      if(pid!=='admin1'&&vipCopiesAdmin(p)&&full.profiles.admin1&&carryControlMode(full.profiles.admin1,date)==='CARRY6')return res.status(409).json({status:'error',message:'Carry Result 6 is inherited from Copy Admin; change the Admin setting first'});
      const job=rangeRunner.view();if(job?.profileId===pid&&(job.busy||job.state==='running'||job.state==='paused'))return res.status(409).json({status:'error',message:'Stop this profile’s range trial before changing Carry Result 6'});
      const currentRuntime=botState.ledgerState?.date===date?botState.ledgerState.profiles[pid]:undefined;
      const input=currentRuntime?carryRuntimeProfile(p,date,currentRuntime.cards as any,currentRuntime.markets):p;
      const settings=mode!==undefined?carryControlSettings(p,date,mode):{autoCarryResultSix:enabled};
      let next=applyCarryResultSixDay({...input,config:date<businessDateIST()?p.config:{...p.config,...settings}},date,enabled);
      if(date<businessDateIST()){const day=next.dayRecords[date]||{};next=calculateBacktestRecovery({...next,dayRecords:{...next.dayRecords,[date]:{...day,backtestRevision:Math.max(Date.now(),Number(day.backtestRevision||0)+1),backtestRecoveryPolicy:{resetAfterThreeFails:false,maxStake:0,...day.backtestRecoveryPolicy,...settings,updatedAt:Date.now()}}}},date);}
      writeFullAppState({...full,profiles:{...full.profiles,[pid]:next}});
      if(date===businessDateIST()){
        if(!botState.ledgerState.date)botState.ledgerState.date=date;
        restoreSavedAdminSchedules();
        if(botState.ledgerState.date===date){
          const fresh=readFullAppState(),restored=fresh?savedDailyLedgerProfiles(fresh.profiles,date):{};
          for(const id of Object.keys(restored))if((id===pid||(pid==='admin1'&&vipCopiesAdmin(fresh?.profiles[id])))&&!botState.ledgerState.profiles[id])botState.ledgerState.profiles[id]=restored[id];
        }
      }
      const runtime=botState.ledgerState?.profiles?.[pid];if(date===businessDateIST()&&runtime&&botState.ledgerState.date===date){Object.assign(runtime,settings);finalizeProfileReadyRates(pid,'carry-result-six');if(pid==='admin1')for(const id of Object.keys(botState.ledgerState.profiles))if(id!=='admin1'&&vipCopiesAdmin(full.profiles[id]))finalizeProfileReadyRates(id,'carry-result-six-copy');persistLedgerSnapshot();}
      const saved=readFullAppState(),finalized=saved?mergeLedgerIntoFullAppState(saved):null;if(finalized&&finalized!==saved)writeFullAppState(finalized);
      const finalProfile=finalized?.profiles?.[pid]||next;
      return res.json({status:'success',profileId:pid,date,enabled,mode,config:finalProfile.config,day:finalProfile.dayRecords?.[date],carryReport:carryResultSixStatus(finalProfile,date)});
    }catch(error:any){return res.status(500).json({status:'error',message:error?.message||'Carry Result 6 save failed'});}
  });

  app.post('/api/app/profile_result_parity',(req,res)=>{
    try{
      const pid=String(req.body?.profileId||''),date=String(req.body?.date||businessDateIST()),enabled=req.body?.enabled;
      if(!pid||typeof enabled!=='boolean'||!validLoopDate(date)||date>businessDateIST())return res.status(400).json({status:'error',message:'Profile, valid business date and boolean enabled required'});
      if(!hasProfileAccess(req,pid))return rejectProfileAccess(res,pid);
      const full=readFullAppState(),p=full?.profiles?.[pid];
      if(!p)return res.status(404).json({status:'error',message:'Profile not found'});
      if(isVipPortalRequest(req)&&p.vipAccessEnabled===false)return res.status(403).json({status:'error',message:'VIP profile is read-only'});
      const job=rangeRunner.view();
      if(job?.profileId===pid&&(job.busy||job.state==='running'||job.state==='paused'))return res.status(409).json({status:'error',message:'Stop this profile’s range trial before changing its F/C/L-cut setting'});
      let next=date<businessDateIST()?p:{...p,config:{...p.config,autoResultParity:enabled}};
      if(date<businessDateIST()){
        const day=p.dayRecords?.[date]||{},version=Math.max(Date.now(),Number(day.backtestRevision||0)+1);
        next=calculateBacktestRecovery({...next,dayRecords:{...next.dayRecords,[date]:{...day,backtestRevision:version,backtestRecoveryPolicy:{resetAfterThreeFails:false,maxStake:0,...day.backtestRecoveryPolicy,autoResultParity:enabled,updatedAt:version}}}},date);
      }
      writeFullAppState({...full,profiles:{...full.profiles,[pid]:next}});
      const runtime=botState.ledgerState?.profiles?.[pid];if(date===businessDateIST()&&botState.ledgerState.date===date&&runtime){runtime.autoResultParity=enabled;finalizeProfileReadyRates(pid,'result-parity-setting');persistLedgerSnapshot();}
      const saved=readFullAppState(),finalized=saved?mergeLedgerIntoFullAppState(saved):null;if(finalized&&finalized!==saved)writeFullAppState(finalized);
      const finalProfile=finalized?.profiles?.[pid]||next;
      return res.json({status:'success',profileId:pid,date,enabled,config:finalProfile?.config,day:finalProfile?.dayRecords?.[date]});
    }catch(error:any){return res.status(500).json({status:'error',message:error?.message||'F/C/L-cut save failed'});}
  });

  // Historical manual trials have a date-owned policy, independent of live.
  app.post('/api/app/archive_recovery_reset', (req, res) => {
    try {
      const pid=String(req.body?.profileId||'').trim(), date=String(req.body?.date||'');
      const enabled=req.body?.enabled;
      if(!pid||!validLoopDate(date)||date>=businessDateIST()||typeof enabled!=='boolean')return res.status(400).json({status:'error',message:'Profile, past business date and boolean enabled required'});
      if(!hasProfileAccess(req,pid))return rejectProfileAccess(res,pid);
      const stored=readFullAppState(),profile=stored?.profiles?.[pid];
      if(!profile)return res.status(404).json({status:'error',message:'Profile not found'});
      if(isVipPortalRequest(req)&&profile.vipAccessEnabled===false)return res.status(403).json({status:'error',message:'VIP profile is read-only'});
      const job=rangeRunner.view();
      if(job?.profileId===pid&&date>=job.from&&date<=job.to&&(job.busy||job.state==='running'||job.state==='paused'))return res.status(409).json({status:'error',message:'Stop the range trial before changing its date policy'});
      const day=profile.dayRecords?.[date]||{};
      const updatedAt=Math.max(Date.now(),Number(day.backtestRevision||0)+1);
      const policy={...day.backtestRecoveryPolicy,resetAfterThreeFails:enabled,maxStake:Number(day.backtestRecoveryPolicy?.maxStake)||0,updatedAt};
      const prepared={...profile,dayRecords:{...profile.dayRecords,[date]:{...day,backtestRecoveryPolicy:policy,backtestRevision:updatedAt}}};
      const next=calculateBacktestRecovery(prepared,date);
      writeFullAppState({...stored,profiles:{...stored.profiles,[pid]:next}});
      return res.json({status:'success',profileId:pid,date,day:next.dayRecords[date]});
    }catch(error:any){return res.status(500).json({status:'error',message:error?.message||'Archive recovery save failed'});}
  });

  registerManualPayments(app,{read:()=>readFullAppState(true),write:writeFullAppState,isVip:isVipPortalRequest,hasAccess:hasProfileAccess});

  app.post('/api/app/profile_custom_loops',(req,res)=>{
    try{
      const pid=String(req.body?.profileId||''),date=String(req.body?.date||'');
      if(!validLoopDate(date))return res.status(400).json({status:'error',message:'Select a valid business date.'});
      if(!hasProfileAccess(req,pid))return rejectProfileAccess(res,pid);
      const full=mergeLedgerIntoFullAppState(readFullAppState(true)),profile=full?.profiles?.[pid];
      if(!profile)return res.status(404).json({status:'error',message:'Profile unavailable.'});
      if(isVipPortalRequest(req)&&profile.vipAccessEnabled===false)return res.status(403).json({status:'error',message:'This profile is read-only.'});
      const job=rangeRunner.view();
      if(job?.profileId===pid&&(job.busy||job.state==='running'||job.state==='paused'))return res.status(409).json({status:'error',message:'Stop this profile’s range trial before changing custom loops.'});
      const toggle=req.body?.action==='toggle';
      if(toggle&&typeof req.body.enabled!=='boolean')return res.status(400).json({status:'error',message:'ON/OFF value required.'});
      const draft=toggle?{...(loopSettingsForDate(profile,date)||normalizeDualLoops({enabled:false,startsOn:date,loopCount:1,loops:{},assignments:{}},profile.config)),enabled:req.body.enabled}:req.body?.config;
      const next=applyCustomLoopSetup(profile,date,draft);
      writeFullAppState({...full,profiles:{...full.profiles,[pid]:next}});
      if(botState.ledgerState.date===calculateBusinessDateIST()){
        finalizeProfileReadyRates(pid,'custom-loop-settings');
        persistLedgerSnapshot();
      }
      const preMerge=readFullAppState(true),saved=mergeLedgerIntoFullAppState(preMerge);if(saved&&saved!==preMerge)writeFullAppState(saved);
      const confirmed=saved.profiles[pid],today=calculateBusinessDateIST();
      return res.json({status:'success',profile:{customLoopChanges:confirmed.customLoopChanges,config:{dualLoops:confirmed.config.dualLoops},dayRecords:{[date]:confirmed.dayRecords[date],...(date!==today&&confirmed.dayRecords[today]?{[today]:confirmed.dayRecords[today]}:{})}},date});
    }catch(error:any){return res.status(409).json({status:'error',message:error?.message||'Custom loop save failed.'});}
  });

  app.post("/api/app/state", (req, res) => {
    try {
      if (isVipPortalRequest(req)) {
        return res.status(403).json({ status: 'error', message: 'VIP portal cannot replace master app state' });
      }
      let compact = req.body?.compact === true && req.body?.baseVersion === workspaceVersion();
      const stored = readFullAppStateView(true);
      let state = req.body?.state || req.body;
      if (req.body?.adminPatch) {
        if (!stored) return res.status(409).json({status:'error',message:'Workspace missing; reload first'});
        // One Admin owns writes. Reconcile late backend/archive snapshots in
        // the acknowledgement instead of negotiating a multi-editor conflict.
        const result=applyAdminChanges(stored,protectCustomLoopChanges(req.body.adminPatch,stored),true);
        // A rejected input is absent from result.state. Diffing that state
        // would falsely acknowledge the client's rejected value as saved.
        if(result.conflicts.length)compact=false;
        state=result.state;
      } else if (!trustedLocalClient(req) && stored) {
        return res.status(409).json({status:'error',code:'WORKSPACE_UPGRADE_REQUIRED',message:'Reload the updated app before saving; old full-workspace saves are blocked'});
      }
      if (!state || typeof state !== 'object' || !state.profiles) {
        return res.status(400).json({ status: 'error', message: 'valid state.profiles required' });
      }
      // Existing server-owned preferences and financial safeguards remain authoritative.
      const preferenceBase=req.body?.adminPatch?acceptedVisibilityPreferences(stored,state,req.body.adminPatch):stored;
      let protectedState = preserveServerPayments(preserveRangeArchive(preserveAtomicProfilePreferences(state, preferenceBase), preferenceBase),stored);
      const controlJob=rangeRunner.view();
      try{protectedState=reconcileResultControlChanges(protectedState,stored,controlJob&&(controlJob.busy||controlJob.state==='running'||controlJob.state==='paused')?controlJob.profileId:undefined);}
      catch(error:any){return res.status(409).json({status:'error',message:error?.message||'Result setting could not be applied'});}
      // Validate before saved preferences can outrank the live ledger config.
      // Delivered identities must remain in the active account set.
      for(const [pid,profile] of Object.entries(protectedState.profiles) as [string,any][]){
        const old=stored?.profiles?.[pid],dates=new Set<string>();
        if(!sameAdminValue(old?.config?.dualLoops,profile.config?.dualLoops))dates.add(calculateBusinessDateIST());
        if(old?.dayRecords !== profile.dayRecords){
          for(const date of Object.keys({...old?.dayRecords,...profile.dayRecords})){
            if(old?.dayRecords?.[date] === profile.dayRecords?.[date]) continue;
            if(!sameAdminValue(old?.dayRecords?.[date]?.loopConfig,profile.dayRecords?.[date]?.loopConfig))dates.add(date);
          }
        }
        for(const date of dates){
          const config=dayLoopConfig(profile,date);if(!config)continue;
          const live=date===botState.ledgerState?.date?botState.ledgerState.profiles?.[pid]:undefined;
          if(hasCommittedInactiveLoop(old?.dayRecords?.[date],config)||hasCommittedInactiveLoop({data:live?.cards as any},config)){
            return res.status(409).json({status:'error',code:'COMMITTED_LOOP_ACCOUNT',message:'Accounts with committed cards cannot be removed. Keep their original accounts active.'});
          }
        }
      }
      const confirmedProfiles = stored?.profiles || {};
      // Live entry is immutable: stale dashboard state cannot restore morning cards.
      let clonedProfilesForConfirm = false;
      const ensureMutableProfile = (pid: string) => {
        if (!clonedProfilesForConfirm) {
          protectedState = { ...protectedState, profiles: { ...protectedState.profiles } };
          clonedProfilesForConfirm = true;
        }
        if (protectedState.profiles[pid] === stored?.profiles?.[pid]) {
          protectedState.profiles[pid] = { ...protectedState.profiles[pid] };
        }
      };
      for (const [pid, profile] of Object.entries(confirmedProfiles) as any[]) {
        if (profile.vipLiveStart && protectedState.profiles?.[pid] && protectedState.profiles[pid].vipLiveStart !== profile.vipLiveStart) {
          ensureMutableProfile(pid);
          protectedState.profiles[pid].vipLiveStart = profile.vipLiveStart;
        }
      }
      for (const [pid, profile] of Object.entries(confirmedProfiles) as any[]) {
        if (!profile.vipDestinationConfirmed || !protectedState.profiles?.[pid]) continue;
        for (const key of ['vipDestinationConfirmed', 'vipDeliveryMode', 'vipGroupJid', 'vipGroupName', 'vipChannelJid', 'vipChannelName', 'phone', 'vipSchTarget']) {
          if (protectedState.profiles[pid][key] !== profile[key]) {
            ensureMutableProfile(pid);
            protectedState.profiles[pid][key] = profile[key];
          }
        }
      }
      const merged = mergeLedgerIntoFullAppState(protectedState);
      if (merged?.profiles?.admin1?.config?.scheduleTypeEnabled) {
        botState.schedulePolicy.admin1 = {
          ank: merged.profiles.admin1.config.scheduleTypeEnabled.ank !== false,
          jodi: merged.profiles.admin1.config.scheduleTypeEnabled.jodi !== false,
          pannel: merged.profiles.admin1.config.scheduleTypeEnabled.pannel !== false,
        };
        for (const [cType, isEn] of Object.entries(botState.schedulePolicy.admin1)) {
          if (!isEn) {
            botState.activeSchedules = (botState.activeSchedules || []).filter(
              (item: any) => !(String(item?.profileId || 'admin1') === 'admin1' && String(item?.type || '') === cType)
            );
          }
        }
      }
      if(!sameAdminValue(stored,merged))writeFullAppState(merged, true);
      res.json({ status: 'success', saved: true, profileCount: Object.keys(merged.profiles || {}).length, ...(req.body?.adminPatch ? (compact ? {statePatch:adminChanges(state,merged)} : {state:merged}) : {}) });
    } catch (e: any) {
      res.status(500).json({ status: 'error', message: e?.message || 'state save failed' });
    }
  });

  // Dashboard pushes compact ledger so server can auto PASS/FAIL without open browser.
  // CRITICAL: never let client WAIT overwrite server PASS/FAIL (was wiping auto marks every 8s).
  app.post("/api/bot/sync_ledger", (req, res) => {
    try {
      const { date, profiles, profileIds } = req.body || {};
      let runningLoopModeChanged=false;
      if (profiles && typeof profiles === 'object') {
        const masterProfileIds = authoritativeProfileIds(profileIds);
        if (masterProfileIds && isVipPortalRequest(req)) {
          return res.status(403).json({ status: 'error', message: 'VIP portal cannot submit a master ledger sync' });
        }
        if (!masterProfileIds) {
          const scopedIds = Object.keys(profiles as Record<string, any>);
          if (scopedIds.length !== 1 || scopedIds[0] === 'admin1' || !hasProfileAccess(req, scopedIds[0])) {
            return scopedIds.length === 1
              ? rejectProfileAccess(res, scopedIds[0])
              : res.status(403).json({ status: 'error', message: 'Scoped ledger sync requires exactly one VIP profile' });
          }
        }
        if (masterProfileIds) {
          reviveAuthoritativeProfiles(masterProfileIds, profiles as Record<string, any>, 'master ledger sync');
          const liveMasterProfileIds = masterProfileIds.filter((pid) => pid === 'admin1' || !isDeletedProfile(pid));
          const incomingSet = new Set(liveMasterProfileIds);
          for (const pid of Object.keys(botState.ledgerState?.profiles || {})) {
            if (pid !== 'admin1' && !incomingSet.has(pid)) purgeDeletedProfile(pid, 'authoritative ledger sync');
          }
          botState.activeProfileIds = [...incomingSet];
        }
        const dateStrEarly = String(date || '');
        if (
          !masterProfileIds && dateStrEarly && botState.ledgerState?.date &&
          botState.ledgerState.date !== dateStrEarly
        ) {
          return res.status(409).json({
            status: 'error',
            message: 'Scoped VIP sync cannot change the global business date; waiting for master sync',
          });
        }
        // NEW BUSINESS DAY: never carry Monday PASS/FAIL into Tuesday snapshot.
        // Server ledger is a single-day cache — date change = full reset of marks.
        let prev: Record<string, any> = (botState.ledgerState?.profiles || {}) as Record<string, any>;
        if (
          dateStrEarly &&
          botState.ledgerState?.date &&
          botState.ledgerState.date !== dateStrEarly
        ) {
          // A new business day must never deliver an old pending card.
          const oldDate = String(botState.ledgerState.date);
          botState.pendingBroadcasts = (botState.pendingBroadcasts || []).filter((b: any) => {
            const key = String(b?.scheduleKey || '');
            return b?.status !== 'pending' || !key.includes(oldDate);
          });
          prev = {};
          botState.logs.unshift({
            id: Date.now().toString(),
            time: new Date().toLocaleTimeString(),
            msg: `Ledger day rollover ${botState.ledgerState.date} → ${dateStrEarly} (cleared prior marks)`,
            type: 'info',
          });
          if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
        }
        for(const [pid,incoming] of Object.entries(profiles as Record<string,any>)) {
          if(runtimeCatalogChanged(prev[pid],incoming) && botState.pendingBroadcasts.some((b:any)=>b.status==='pending' && String(b.profileId||'')===pid && Object.values(b.claimedPlatforms||{}).some(Boolean)))return res.status(409).json({status:'error',message:'A broadcast is in flight. Market reindex will sync after delivery finishes.'});
        }
        const rawSyncView = readFullAppStateView();
        const savedSyncState = rawSyncView ? { ...rawSyncView, profiles: Object.fromEntries(Object.entries(rawSyncView.profiles || {}).map(([k, v]: [string, any]) => [k, { ...v, config: v?.config ? { ...v.config } : {} }])) } : null;
        const merged: Record<string, any> = {};
        const catalogActions:Array<()=>void>=[];
        for (const [pid, incoming] of Object.entries(profiles as Record<string, any>)) {
          if (isDeletedProfile(pid)) continue;
          let oldProf = prev[pid] || {};
          const migration=remapRuntimeCatalog(oldProf,incoming);
          if(Object.keys(migration.indexMap).length){
            oldProf=migration.profile;
            const rename=(key:string)=>remapScheduleIdentity(key,pid,dateStrEarly,migration.indexMap);
            for(const rec of Object.values(oldProf.cards||{}) as any[])if(rec.dispatchKey)rec.dispatchKey=rename(String(rec.dispatchKey));
            catalogActions.push(()=>{
            for(const key of ['sentSchedules','scheduleMsgKeys','resultFollowUpSent','scheduleClaims'] as const)botState[key]=Object.fromEntries(Object.entries(botState[key]||{}).map(([k,v])=>[rename(k),v]));
            expiredBroadcastKeys=Object.fromEntries(Object.entries(expiredBroadcastKeys).map(([k,v])=>[rename(k),v]));
            for(const b of botState.pendingBroadcasts){
              if(String(b.profileId||'')!==pid || b.broadcastKind==='vip-card-copy')continue;
              const legacyIndex=String(b.scheduleKey||'').match(/(?:ank|jodi|pannel)_(-?\d+)(?:_|$)/)?.[1];
              const index=migration.indexMap[`${b.cardType}_${b.index??legacyIndex}`];
              if(index===undefined){if(b.scheduleKey)b.scheduleKey=rename(String(b.scheduleKey));if(b.dedupeKey)b.dedupeKey=rename(String(b.dedupeKey));continue;}
              if(index<0 && b.status==='pending'){
                b.status='failed';const rec=oldProf.cards?.[`${b.cardType}_${index}`];
                if(rec?.dispatchState==='QUEUED' && !rec.sentRate && !rec.sentDigits){delete rec.dispatchState;delete rec.dispatchKey;delete rec.queuedAt;}
              }
              b.index=index;if(b.scheduleKey)b.scheduleKey=rename(String(b.scheduleKey));if(b.dedupeKey)b.dedupeKey=rename(String(b.dedupeKey));
            }
            botState.activeSchedules=botState.activeSchedules.filter((item:any)=>{
              if(String(item.profileId||'')!==pid)return true;
              const index=migration.indexMap[`${item.type}_${item.index}`];
              if(index===undefined)return true;
              if(index<0)return false;
              item.index=index;if(item.key)item.key=rename(String(item.key));return true;
            });
            for(const audit of botState.pendingAuditResults){
              const identity=(key:string)=>{if(!key.startsWith(pid+'|'))return key;const card=key.slice(pid.length+1),index=migration.indexMap[card];return index===undefined?key:`${pid}|${card.split('_')[0]}_${index}`;};
              if(audit.deferredCards)audit.deferredCards=Object.fromEntries(Object.entries(audit.deferredCards).map(([key,value])=>[identity(key),{...value,dispatchKey:rename(value.dispatchKey)}]));
              if(Array.isArray((audit as any).ignoredCardKeys))(audit as any).ignoredCardKeys=(audit as any).ignoredCardKeys.map(identity);
            }
            persistPendingAudits();
            persistSentSchedules();persistResultFollowUps();persistExpiredBroadcastKeys();
            atomicWriteFileAsync(path.join(titanDataDir,'active_schedules.json'),JSON.stringify(botState.activeSchedules),'active-schedules');
            });
          }
          const hidden=(oldProf.markets||[]).filter((m:any)=>Number(m.index)<0);
          if(hidden.length)incoming.markets=[...(incoming.markets||[]),...hidden.filter((m:any)=>!(incoming.markets||[]).some((n:any)=>n.type===m.type&&Number(n.index)===Number(m.index)))];
          const nextSplitModeEarly = incoming?.splitMode || oldProf.splitMode || { ank: true, pannel: true };
          const splitModeChanged = Boolean(
            (oldProf?.splitMode &&
              (oldProf.splitMode.ank !== nextSplitModeEarly.ank || oldProf.splitMode.pannel !== nextSplitModeEarly.pannel)) ||
            Boolean(oldProf?.fourWaveRelay) !== Boolean(incoming?.fourWaveRelay) ||
            Boolean(oldProf?.profitCarry ?? oldProf?.config?.profitCarry) !== Boolean(incoming?.profitCarry ?? incoming?.config?.profitCarry) ||
            Boolean(oldProf?.openPassCloseZero ?? oldProf?.config?.openPassCloseZero) !== Boolean(incoming?.openPassCloseZero ?? incoming?.config?.openPassCloseZero)
          );
          if (savedSyncState?.profiles?.[pid]?.config && incoming?.splitMode) {
            savedSyncState.profiles[pid].config.ankSplit = nextSplitModeEarly.ank !== false;
            savedSyncState.profiles[pid].config.panSplit = nextSplitModeEarly.pannel !== false;
            if (incoming?.fourWaveRelay !== undefined) {
              savedSyncState.profiles[pid].config.fourWaveRelay = incoming.fourWaveRelay === true;
            }
            if (incoming?.profitCarry !== undefined) {
              savedSyncState.profiles[pid].config.profitCarry = incoming.profitCarry === true;
              savedSyncState.profiles[pid].profitCarry = incoming.profitCarry === true;
            }
            if (incoming?.openPassCloseZero !== undefined) {
              savedSyncState.profiles[pid].config.openPassCloseZero = incoming.openPassCloseZero === true;
              savedSyncState.profiles[pid].openPassCloseZero = incoming.openPassCloseZero === true;
            }
          }
          const oldCards = oldProf.cards || {};
          const newCards = { ...(incoming?.cards || {}) };
          for (const [ck, oldCard] of Object.entries(oldCards as Record<string, any>)) {
            // A sparse background sync cannot clear a VIP play/reservation.
            // Explicit Clear/Restore remains owned by ledger_set_card.
            if (pid !== 'admin1' && !newCards[ck] && oldCard) newCards[ck] = { ...oldCard };
            const nc = reconcileVipAutoStopCard(newCards[ck], oldCard);
            if (nc !== newCards[ck]) newCards[ck] = nc;
            if (nc && isStaleModelSnapshot(oldCard, nc)) {
              newCards[ck] = { ...oldCard, schTime: nc.schTime || oldCard.schTime, schTargets: nc.schTargets || oldCard.schTargets };
              continue;
            }
            if (isEditableSourceSkip(oldCard) && nc && Math.max(Number(nc.marketModel?.updatedAt || 0), Number(nc.sourceEditedAt || 0)) < Math.max(Number(oldCard.marketModel?.updatedAt || 0), Number(oldCard.sourceEditedAt || 0))) {
              newCards[ck] = { ...nc, ...oldCard, schTime: nc.schTime || oldCard.schTime, schTargets: nc.schTargets || oldCard.schTargets };
              continue;
            }
            // Server is authoritative: never let a client snapshot overwrite
            // a terminal PASS/FAIL mark. Explicit user corrections go through
            // /api/bot/ledger_set_card, not this background sync endpoint.
            const closeZeroReleased = Boolean(oldCard?.s === 'SKIP' && (oldCard?.closeZeroAutoSkipped || (!oldCard?.manualStatus && !oldCard?.vipAutoStopSkipped && !oldCard?.loopAccountSkipped && !oldCard?.deliveryMissedAt)) && nc?.s === 'WAIT' && incoming?.openPassCloseZero === false);
            if (oldCard && !closeZeroReleased && (oldCard.s === 'PASS' || oldCard.s === 'FAIL' || oldCard.s === 'SKIP') && !(isEditableSourceSkip(oldCard) && nc && Math.max(Number(nc.marketModel?.updatedAt || 0), Number(nc.sourceEditedAt || 0)) >= Math.max(Number(oldCard.marketModel?.updatedAt || 0), Number(oldCard.sourceEditedAt || 0)))) {
              const incomingManualStatus = Boolean(
                nc?.manualStatus && Number(nc?.manualOverrideAt || 0) > Number(oldCard.settledAt || 0)
              );
              const incomingManualRate = Boolean(nc?.manualRate);
              newCards[ck] = {
                ...oldCard,
                ...(nc || {}),
                s: incomingManualStatus ? String(nc?.s || oldCard.s) : oldCard.s,
                // Terminal history is delivery-authoritative. Never let a
                // dashboard-calculated future/recovery rate rewrite a sent card.
                r: oldCard.sentRate && parseFloat(String(oldCard.sentRate)) > 0
                  ? String(oldCard.sentRate)
                  : (incomingManualRate ? String(nc?.r ?? '') : ((nc && nc.r) || oldCard.r)),
                manualStatus: incomingManualStatus || Boolean(oldCard.manualStatus),
                manualRate: incomingManualRate || Boolean(oldCard.manualRate),
                manualOverrideAt: nc?.manualOverrideAt || oldCard.manualOverrideAt,
                d: (nc && nc.d) || oldCard.d,
                sentRate: oldCard.sentRate || (nc && nc.sentRate) || undefined,
                sentInvest: oldCard.sentInvest || (nc && nc.sentInvest) || undefined,
                sentDigits: oldCard.sentDigits || (nc && nc.sentDigits) || undefined,
                scrapeSource: oldCard.sentRate || oldCard.sentDigits || oldCard.s === 'PASS' || oldCard.s === 'FAIL'
                  ? (oldCard.scrapeSource || nc?.scrapeSource) : normalizeScrapeSource(nc?.scrapeSource),
                sentScrapeSource: oldCard.sentScrapeSource || nc?.sentScrapeSource,
                sentLoopId: oldCard.sentLoopId || nc?.sentLoopId,
                scrapeResultDigit: oldCard.scrapeResultDigit,
                manualResult: oldCard.manualResult,
                manualPanelResult: oldCard.manualPanelResult,
                manualResultSources: oldCard.manualResultSources,
                weekdaySelectedDigits: oldCard.weekdaySelectedDigits || nc?.weekdaySelectedDigits,
                weekdayHitPosition: oldCard.weekdayHitPosition !== undefined ? oldCard.weekdayHitPosition : nc?.weekdayHitPosition,
                positionRule: oldCard.positionRule || (nc && nc.positionRule) || undefined,
                trick: oldCard.trick || (nc && nc.trick) || undefined,
                sentSourceMode: oldCard.sentSourceMode || (nc && nc.sentSourceMode) || undefined,
                sentTrick: oldCard.sentTrick || (nc && nc.sentTrick) || undefined,
                sentTargets: Array.isArray(oldCard.sentTargets) ? oldCard.sentTargets : (Array.isArray(nc?.sentTargets) ? nc.sentTargets : undefined),
                schTime: (nc && nc.schTime) || oldCard.schTime,
                schTargets: (nc && nc.schTargets?.length ? nc.schTargets : oldCard.schTargets) || [],
                dispatchState: oldCard.dispatchState || nc?.dispatchState,
                dispatchKey: oldCard.dispatchKey || nc?.dispatchKey,
                queuedAt: oldCard.queuedAt || nc?.queuedAt,
                sentAt: oldCard.sentAt || nc?.sentAt,
                settledAt: oldCard.settledAt || nc?.settledAt,
                jodiOpenStatus: oldCard.jodiOpenStatus || nc?.jodiOpenStatus,
                jodiOpenResult: oldCard.jodiOpenResult || nc?.jodiOpenResult,
                jodiOpenSettledAt: oldCard.jodiOpenSettledAt || nc?.jodiOpenSettledAt,
                deliveryMissedAt: oldCard.deliveryMissedAt || nc?.deliveryMissedAt,
                deliveryMissedReason: oldCard.deliveryMissedReason || nc?.deliveryMissedReason,
                deliveryPartial: oldCard.deliveryPartial !== undefined ? oldCard.deliveryPartial : nc?.deliveryPartial,
                rateFinalizedFrom: oldCard.rateFinalizedFrom || nc?.rateFinalizedFrom,
                rateFinalizedAt: oldCard.rateFinalizedAt || nc?.rateFinalizedAt,
              };
            } else if (oldCard && nc) {
              if(oldCard.liveCombinedCut?.observation&&nc.liveCombinedCut&&Number(nc.sourceEditedAt||0)===Number(oldCard.sourceEditedAt||0)&&JSON.stringify(nc.scrapeSource)===JSON.stringify(oldCard.scrapeSource))nc.liveCombinedCut.observation=oldCard.liveCombinedCut.observation;

              if (oldCard.s === 'WAIT' && oldCard.manualStatus && Number(oldCard.manualOverrideAt || 0) > Number(nc.manualOverrideAt || 0) && Number(nc.sourceEditedAt || 0) <= Number(oldCard.manualOverrideAt || 0)) {
                nc.s = 'WAIT'; nc.manualStatus = true; nc.manualOverrideAt = oldCard.manualOverrideAt;
                nc.manualResult = undefined;
              }
              const explicitlyUnlocked = Boolean(
                nc.s === 'WAIT' && nc.manualStatus && oldCard.dispatchState === 'SETTLED'
              );
              if (explicitlyUnlocked) {
                for (const field of ['sentRate','sentInvest','sentDigits','sentSourceMode','sentTrick','sentScrapeSource','scrapeResultDigit','manualResult','sentTargets','dispatchState','dispatchKey','queuedAt','sentAt','settledAt','jodiOpenStatus','jodiOpenResult','jodiOpenSettledAt','deliveryMissedAt','deliveryMissedReason','deliveryPartial','rateFinalizedFrom','rateFinalizedAt']) {
                  delete oldCard[field];
                  delete nc[field];
                }
              }
              // A finalized automatic rate is valid only for the digit set it
              // was calculated from. When an unsent card receives new digits,
              // release the old suggestion and let finalizeAllReadyRates below
              // calculate again from backend debt + target. Genuine manual
              // overrides and delivered cards remain authoritative.
              const digitsChanged = String(nc.d || '').trim() !== String(oldCard.d || '').trim();
              const releaseAutoRate = Boolean(
                (digitsChanged || splitModeChanged) && !oldCard.manualRate && !nc.manualRate &&
                !oldCard.sentRate && oldCard.dispatchState !== 'SENT'
              );
              if (releaseAutoRate) {
                for (const field of ['recRate','prevLoss','targetProfitWithLoss','rateFinalizedFrom','rateFinalizedAt','smartStaking']) {
                  delete nc[field];
                }
              }
              // A backend-finalized WAIT rate is otherwise the target/recovery
              // source of truth. A stale local default must never roll it back.
              if (oldCard.rateFinalizedAt && !releaseAutoRate) {
                nc.r = oldCard.r;
                nc.recRate = oldCard.recRate;
                nc.prevLoss = oldCard.prevLoss;
                nc.targetProfitWithLoss = oldCard.targetProfitWithLoss;
                nc.smartStaking = oldCard.smartStaking;
                nc.manualRate = oldCard.manualRate;
                nc.manualOverrideAt = oldCard.manualOverrideAt;
                nc.rateFinalizedFrom = oldCard.rateFinalizedFrom;
                nc.rateFinalizedAt = oldCard.rateFinalizedAt;
              }
              // mark_sent freeze ALWAYS wins — client must never overwrite
              if (oldCard.sentRate) {
                nc.sentRate = oldCard.sentRate;
                nc.loopId = oldCard.loopId;
                nc.sentLoopId = oldCard.sentLoopId;
                nc.sentInvest = oldCard.sentInvest ?? nc.sentInvest;
                nc.sentDigits = oldCard.sentDigits || nc.sentDigits;
                nc.sentSourceMode = oldCard.sentSourceMode || nc.sentSourceMode;
                nc.sentTrick = oldCard.sentTrick || nc.sentTrick;
              }
              if (oldCard.dispatchState) nc.dispatchState = oldCard.dispatchState;
              if (oldCard.dispatchKey) nc.dispatchKey = oldCard.dispatchKey;
              if (oldCard.queuedAt) nc.queuedAt = oldCard.queuedAt;
              if (oldCard.sentAt) nc.sentAt = oldCard.sentAt;
              if (oldCard.settledAt) nc.settledAt = oldCard.settledAt;
              if (oldCard.jodiOpenStatus) nc.jodiOpenStatus = oldCard.jodiOpenStatus;
              if (oldCard.jodiOpenResult) nc.jodiOpenResult = oldCard.jodiOpenResult;
              if (oldCard.jodiOpenSettledAt) nc.jodiOpenSettledAt = oldCard.jodiOpenSettledAt;
              nc.manualPanelResult = oldCard.manualPanelResult;
              nc.manualResultSources = oldCard.manualResultSources;
              if (Array.isArray(oldCard.sentTargets)) nc.sentTargets = oldCard.sentTargets;
              if (oldCard.deliveryMissedAt) nc.deliveryMissedAt = oldCard.deliveryMissedAt;
              if (oldCard.deliveryMissedReason) nc.deliveryMissedReason = oldCard.deliveryMissedReason;
              if (oldCard.deliveryPartial !== undefined) nc.deliveryPartial = oldCard.deliveryPartial;
              if (!releaseAutoRate && oldCard.rateFinalizedFrom) nc.rateFinalizedFrom = oldCard.rateFinalizedFrom;
              if (!releaseAutoRate && oldCard.rateFinalizedAt) nc.rateFinalizedAt = oldCard.rateFinalizedAt;
            }
          }
          const authoritative=savedSyncState?.profiles?.[pid];
          const proposedLoopConfig = authoritative?.customLoopChanges?loopSettingsForDate(authoritative,dateStrEarly):normalizeDualLoops(incoming?.loopConfig);
          const requestedLoops = proposedLoopConfig && dateStrEarly >= proposedLoopConfig.startsOn ? proposedLoopConfig : undefined;
          const loopModeChanged = Boolean(requestedLoops && requestedLoops.startsOn===dateStrEarly && Number(requestedLoops.revision||0)>Number(oldProf.loopConfig?.revision||0));
          const nextLoopConfig = loopModeChanged ? requestedLoops : oldProf.loopConfig || requestedLoops;
          if(loopModeChanged) runningLoopModeChanged=true;
          if(loopModeChanged && nextLoopConfig?.enabled && hasCommittedInactiveLoop({data:oldCards},nextLoopConfig))return res.status(409).json({status:'error',message:'Committed cards require their original loops; turn Loop mode OFF to use legacy recovery.'});
          if(!oldProf.loopConfig && requestedLoops && !loopModeChanged && dayHasCommittedPlays({data:oldCards})) return res.status(409).json({status:'error',message:'Use Apply now to change the running day mode; an old background snapshot cannot activate it.'});
          if (nextLoopConfig?.enabled) {
            for (const market of incoming?.markets || oldProf.markets || []) {
              const key = `${market.type}_${market.index}`, rec = newCards[key], old = oldCards[key];
              if (!rec) continue;
              if (old?.sentLoopId) rec.sentLoopId = old.sentLoopId;
              const claimed=botState.pendingBroadcasts.some((b:any)=>b.status==='pending' && String(b.profileId||'')===pid && String(b.cardType||'')===market.type && Number(b.index)===Number(market.index) && Object.values(b.claimedPlatforms||{}).some(Boolean));
              if (old?.loopId && (old.sentRate || old.sentDigits || old.dispatchState==='SENT' || old.dispatchState==='SETTLED' || claimed || old.s==='PASS' || old.s==='FAIL')) rec.loopId=old.loopId;
              else delete rec.loopId;
              const loop = runtimeLoop({loopConfig:nextLoopConfig,markets:incoming?.markets || oldProf.markets,cards:newCards},market.type,market.n,rec);
              if(loop) rec.loopId=loop;
            }
          }
          for(const [key,old] of Object.entries(oldCards) as [string,any][]) {
            if(recoveryCardFrozen(old)&&newCards[key]){newCards[key].twoCardRecoveryShares=old.twoCardRecoveryShares;newCards[key].twoCardRecoveryStrategy=old.twoCardRecoveryStrategy;}
          }
          for(const [key,old] of Object.entries(oldCards) as [string,any][]){
            const r=newCards[key];if(!r)continue;
            if(old.loopAccountReservation?.expiresAt>Date.now())r.loopAccountReservation=old.loopAccountReservation;
            if(old.loopAccountSkipped&&nextLoopConfig?.independentAccounts&&nextLoopConfig.enabled){r.s='SKIP';r.loopAccountSkipped=true;r.loopAccountReason=old.loopAccountReason;}
            else if(old.loopAccountSkipped&&!deliveredLoopCard(r)){r.s='WAIT';delete r.loopAccountSkipped;delete r.loopAccountReason;}
            if(loopModeChanged&&nextLoopConfig?.independentAccounts&&!oldProf.loopConfig?.independentAccounts&&old.vipAutoStopSkipped&&!deliveredLoopCard(r)&&!r.manualStatus&&oldProf.vipGameRuns?.[key.split('_')[0]]?.reason!=='MANUAL_OFF'){r.s='WAIT';delete r.vipAutoStopSkipped;}
          }
          const nextSplitMode = incoming?.splitMode || oldProf.splitMode || { ank: true, pannel: true };
          let migratedRecoveryState = loopModeChanged ? {} : { ...(oldProf.recoveryState || incoming?.recoveryState || {}) };
          for (const recoveryType of nextLoopConfig?.enabled ? [] : ['ank', 'pannel'] as const) {
            const oldSplitSetting = oldProf?.splitMode?.[recoveryType];
            const hasOldUnifiedTrack = Object.prototype.hasOwnProperty.call(
              migratedRecoveryState,
              `${recoveryType}:ALL`,
            );
            const wasSplit = oldSplitSetting === undefined
              ? !hasOldUnifiedTrack
              : oldSplitSetting !== false;
            const isSplit = nextSplitMode?.[recoveryType] !== false;
            migratedRecoveryState = migrateRecoveryStateForSplitChange(
              migratedRecoveryState,
              incoming?.markets || oldProf.markets || [],
              recoveryType,
              wasSplit,
              isSplit,
            );
          }
          merged[pid] = {
            ...incoming,
            cards: newCards,
            markets: incoming?.markets || oldProf.markets || [],
            phone: incoming?.phone || oldProf.phone || '',
            deliveryMode: incoming?.deliveryMode || oldProf.deliveryMode || 'private',
            deliveryTargets: Array.isArray(incoming?.deliveryTargets) ? incoming.deliveryTargets : (oldProf.deliveryTargets || []),
            deliveryTargetName: incoming?.deliveryTargetName || oldProf.deliveryTargetName || '',
            name: incoming?.name || oldProf.name || '',
            vipAutoMode: incoming?.vipAutoMode !== undefined ? Boolean(incoming.vipAutoMode) : (oldProf.vipAutoMode !== false),
            vipGameRuns: savedSyncState?.profiles?.[pid]?.vipGameRuns,
            detailedMessage: incoming?.detailedMessage !== undefined
              ? Boolean(incoming.detailedMessage)
              : oldProf.detailedMessage !== false,
            twoCardRecoveryLegacySplit: oldProf.twoCardRecoveryLegacySplit||incoming?.twoCardRecoveryLegacySplit||oldProf.splitMode||nextSplitMode,
            splitMode: nextSplitMode,
            twoCardRecoveryVersion: incoming?.twoCardRecoveryVersion===2||oldProf.twoCardRecoveryVersion===2?2:undefined,
            loopConfig: nextLoopConfig,
            loopAccountStops:{...oldProf.loopAccountStops,...savedSyncState?.profiles?.[pid]?.dayRecords?.[dateStrEarly]?.loopAccountStops},
            autoRemoveResultUnique3: incoming?.autoRemoveResultUnique3!==undefined?incoming.autoRemoveResultUnique3===true:oldProf.autoRemoveResultUnique3===true,
            autoCarryResultSix: incoming?.autoCarryResultSix!==undefined?incoming.autoCarryResultSix===true:oldProf.autoCarryResultSix===true,
            autoResultParity: incoming?.autoResultParity!==undefined?incoming.autoResultParity===true:oldProf.autoResultParity===true,
            liveThreeFailReset: incoming?.liveThreeFailReset!==undefined?incoming.liveThreeFailReset===true:oldProf.liveThreeFailReset===true,
            profitCarry: incoming?.profitCarry!==undefined?incoming.profitCarry===true:Boolean(oldProf.profitCarry ?? savedSyncState?.profiles?.[pid]?.config?.profitCarry),
            openPassCloseZero: incoming?.openPassCloseZero!==undefined?incoming.openPassCloseZero===true:Boolean(oldProf.openPassCloseZero ?? savedSyncState?.profiles?.[pid]?.config?.openPassCloseZero),
            // recoveryState is backend-owned; background dashboard snapshots must never erase it.
            recoveryState: migratedRecoveryState,
          };
          const savedDestination = savedSyncState?.profiles?.[pid];
          if (savedDestination?.vipDestinationConfirmed) {
            const runtime = merged[pid];
            runtime.deliveryMode = savedDestination.vipDeliveryMode;
            runtime.phone = savedDestination.vipSchTarget || savedDestination.phone;
            runtime.vipGroupJid = savedDestination.vipGroupJid;
            runtime.vipChannelJid = savedDestination.vipChannelJid;
            runtime.deliveryTargets = runtime.deliveryMode === 'group'
              ? normalizeTargetList([runtime.vipGroupJid], 'group')
              : runtime.deliveryMode === 'channel'
                ? normalizeTargetList([runtime.vipChannelJid], 'channel') : [];
          }
        }
        for (const [pid, runtime] of Object.entries(merged) as Array<[string, any]>) {
          const saved = savedSyncState?.profiles?.[pid];
          if(saved?.config?.autoResultParity!==undefined)runtime.autoResultParity=saved.config.autoResultParity===true;
          if(saved?.config?.liveThreeFailReset!==undefined)runtime.liveThreeFailReset=saved.config.liveThreeFailReset===true;
          else if(runtime.liveThreeFailReset===undefined)runtime.liveThreeFailReset=(prev[pid] as any)?.liveThreeFailReset===true;
          if (saved?.vipLiveStart) for (const market of runtime.markets || []) {
            if (!vipLiveMarketEligible(saved, String(date || ''), market.type, market.n)) market.enabled = false;
          }
        }
        for(const applyCatalog of catalogActions)applyCatalog();
        // The dashboard sends the complete profile set. If profileIds is present,
        // omitted profiles were deleted and must not remain in the server snapshot.
        const dateStr = String(date || '');
        if (!masterProfileIds && (!botState.ledgerState?.date || botState.ledgerState.date === dateStr)) {
          for (const [pid, oldProf] of Object.entries(prev)) {
            if (!merged[pid]) merged[pid] = oldProf;
          }
        }
        botState.ledgerState = {
          date: dateStr || botState.ledgerState?.date || '',
          updatedAt: Date.now(),
          profiles: merged,
        };
        // Market OFF is fail-closed: drop any queued broadcast for that exact disabled card.
        for (const b of botState.pendingBroadcasts || []) {
          if (b.status !== 'pending' || !b.profileId || b.index === undefined || !b.cardType) continue;
          if (b.broadcastKind === 'vip-card-copy') continue; // Display copy is independent of market play switches.
          const pr: any = merged[String(b.profileId)];
          const mm = (pr?.markets || []).find((x: any) => String(x?.type) === String(b.cardType) && Number(x?.index) === Number(b.index));
          if ((b.broadcastKind === 'vip-auto-card' && (!pr || pr.vipAutoMode === false)) || (mm && mm.enabled === false)) {
            b.failedTargets = normalizeTargetList(b.targets);
            finishResolvedBroadcast(b, 'LEDGER_POLICY_DISABLED');
          }
        }
        persistPendingBroadcasts();
      }
      // Calculation is independent from delivery. Run the same ready-card
      // finalizer for Admin and every VIP even when VIP Auto Mode is OFF or no
      // phone is configured; queueVipAutoReadyCards below controls sending only.
      const ratesFinalized = finalizeAllReadyRates('ledger-sync');
      const srv = serverProcessPendingAudits();
      const vipQueued = queueVipAutoReadyCards('ledger-sync');
      const profitNotificationsQueued = queueProfitMilestoneNotifications();
      // Empty source edits may finalize no rate and process no result. They
      // still need a durable ledger before acknowledging the browser sync.
      persistLedgerSnapshot();
      if(runningLoopModeChanged){const full=readFullAppState();if(full)writeFullAppState(mergeLedgerIntoFullAppState(full));}
      res.json({
        status: 'success',
        profileCount: Object.keys(botState.ledgerState.profiles || {}).length,
        serverProcessed: srv,
        ratesFinalized,
        profitNotificationsQueued,
        vipAutoQueued: vipQueued,
      });
    } catch (e: any) {
      res.status(500).json({ status: 'error', message: e?.message || 'sync failed' });
    }
  });

  /** Read-only: explain this VIP's current queue lane without claiming/sending work. */
  function describeVipQueue(pid:string,prof:any,marketName:string,type:string,saved:any) {
    const normalize=(value:unknown)=>String(value||'').trim().replace(/\s+/g,' ').toUpperCase();
    const market=(prof.markets||[]).find((m:any)=>m.type===type&&normalize(m.n)===normalize(marketName));
    const key=market?`${type}_${market.index}`:'';
    const rec=prof.cards?.[key];
    const track=market?serverRecoveryTrackKey(prof,type,market.n):'';
    const state=prof.recoveryState?.[track]||{};
    const fromIndex=Number.isFinite(Number(state.fromIndex))?Number(state.fromIndex):-1;
    const previous=fromIndex>=0?prof.cards?.[`${type}_${fromIndex}`]:undefined;
    const previousMarket=(prof.markets||[]).find((m:any)=>m.type===type&&Number(m.index)===fromIndex);
    const resultKey=previous?`${pid}_${botState.ledgerState.date}_${type}_${fromIndex}_${previous.s}${previous.cardGeneration?`_g${previous.cardGeneration}`:''}`:'';
    const previousReply=botState.pendingBroadcasts.find((b:any)=>b.broadcastKind==='result-followup'&&b.dedupeKey===resultKey);
    const previousReplyState=previousReply?String(previousReply.status).toUpperCase():resultKey&&botState.resultFollowUpSent[resultKey]?'DEDUPED_OR_FINISHED':'NOT_QUEUED';
    const base={profileId:pid,name:String(prof.name||pid),market:String(market?.n||marketName),type,
      previousMarket:previousMarket?.n,previousStatus:previous?.s,previousReplyState,
      cardStatus:rec?.s||'MISSING',digitsAvailable:countSettlementTokens(rec?.d,type),rate:String(rec?.sentRate||rec?.r||''),fromIndex};
    const report=(reason:string,blocker?:any)=>({...base,reason,...(blocker?{blockingMarket:String(blocker.n),blockingStatus:prof.cards?.[`${type}_${blocker.index}`]?.s||'MISSING'}:{})});
    if(prof.vipAutoMode===false)return report('VIP_AUTO_OFF');
    if(!market)return report('MARKET_MISSING');
    if(market.enabled===false)return report(saved&&!vipLiveMarketEligible(saved,botState.ledgerState.date,type,market.n)?'LIVE_ENTRY_EXCLUDED':'MARKET_OFF');
    if(!isCardTypeEnabled(pid,type))return report('CARD_TYPE_OFF');
    const accounts=resolveLoopAccountConfig(saved,prof,botState.ledgerState.date);
    if(accounts){const decision=evaluateLoopAccounts(accounts,prof,botState.ledgerState.date,{...prof.loopAccountStops,...saved?.dayRecords?.[botState.ledgerState.date]?.loopAccountStops},{liveOnly:true,nextKey:key,nextInvest:rec?.smartStaking?.isSmartStaking&&Number(rec.smartStaking.totalInvest)>0?Number(rec.smartStaking.totalInvest):countSettlementTokens(rec?.d,type)*Number(rec?.r||0),excludeKey:key});if(!decision.allowed){const state=decision.states.find(s=>s.key===decision.nextAccountKey);return report(state?.reason?`LOOP_${state.reason}`:'LOOP_CAPITAL_RESERVED');}}
    const stop=vipStopReason(pid,botState.ledgerState.date,saved,prof,type as any);
    if(stop)return report(stop);
    if(rec?.s==='PASS'||rec?.s==='FAIL'||rec?.s==='SKIP')return report(rec.backtestResult&&!rec.manualStatus&&!rec.sentRate&&!rec.sentDigits&&!rec.sentAt&&rec.dispatchState!=='SETTLED'?'UNSENT_BACKTEST_OUTCOME':'CARD_SETTLED_OR_SKIPPED');
    const pending=botState.pendingBroadcasts.find((b:any)=>b.status==='pending'&&b.broadcastKind==='vip-auto-card'&&b.profileId===pid&&b.cardType===type&&Number(b.index)===Number(market.index)&&Number(b.cardGeneration||0)===Number(rec?.cardGeneration||0));
    if(pending)return report('QUEUED');
    if(rec?.sentRate||rec?.sentDigits||rec?.sentAt)return report('WAITING_OWN_RESULT');
    if(rec?.dispatchState==='QUEUED')return report('QUEUE_LOCK_WITHOUT_PENDING_JOB');
    if(rec?.deliveryRestoredAt)return report('CARD_RESTORED');
    if(rec?.deliveryMissedAt)return report(`LIVE_DELIVERY_MISSED:${rec.deliveryMissedReason||'UNKNOWN'}`);
    if(fromIndex>=Number(market.index))return report('RECOVERY_ALREADY_ADVANCED',(prof.markets||[]).find((m:any)=>m.type===type&&Number(m.index)===fromIndex));
    const trackMarkets=(prof.markets||[]).filter((m:any)=>m.type===type&&m.enabled!==false&&serverRecoveryTrackKey(prof,type,m.n)===track).sort((a:any,b:any)=>Number(a.index)-Number(b.index));
    const position=vipQueuePosition(trackMarkets,prof.cards||{},type,fromIndex,Number(prof.loopConfig?.revision||0));
    if(position.kind==='in-flight')return report('ANOTHER_CARD_AWAITING_RESULT_OR_ACK',position.market);
    if(position.kind==='none')return report('NO_ELIGIBLE_CARD');
    if(Number(position.market.index)!==Number(market.index))return report('EARLIER_CARD_NOT_READY_OR_NOT_QUEUED',position.market);
    if(!rec||!String(rec.d||'').trim())return report('SOURCE_DIGITS_MISSING');
    if(!areSettlementTokensValid(type,rec.d)||!isRecoveryRatePossible(type,rec.d))return report('UNSENDABLE_DIGITS');
    if(!(Number(rec.r)>0))return report('RATE_NOT_READY');
    const targets=serverVipDeliveryTargets(prof);
    if(!targets.length)return report('DELIVERY_TARGET_MISSING');
    const keySchedule=`vipauto_${pid}_${botState.ledgerState.date}_${type}_${market.index}${rec.cardGeneration?`_g${rec.cardGeneration}`:''}`;
    if(expiredBroadcastKeys[keySchedule])return report('LIVE_DELIVERY_EXPIRED');
    if(botState.sentSchedules[keySchedule])return report('ALREADY_SENT_MARKER');
    const budget=vipStopReason(pid,botState.ledgerState.date,saved,prof,type as any,rec?.smartStaking?.isSmartStaking&&Number(rec.smartStaking.totalInvest)>0?Number(rec.smartStaking.totalInvest):countSettlementTokens(rec.d,type)*Number(rec.r),key);
    if(budget)return report(budget);
    if(!bindLiveBroadcastTargets(targets).targets.length)return report('NO_LIVE_TRANSPORT');
    return report('READY_FOR_QUEUE');
  }

  // Frontend can pull server-side status updates after offline processing
  app.get("/api/bot/ledger_snapshot", (req, res) => {
    // This high-frequency Admin/VIP poll only inspects stored preferences and
    // historical limits. Never JSON.parse/clone the whole year's archive for
    // every 2-second poll: FullStateReader validates the file signature and
    // shares an immutable view, invalidated immediately by atomic writes.
    const stored = readFullAppStateView();
    const profileId = String(req.query.profileId || '').trim();
    const queueMarket=String(req.query.queueMarket||'').trim();
    const sendSnapshot = (payload: unknown) => {
      // Conditional GET still hashes the *real* ledger, not updatedAt: many
      // backend mutations intentionally preserve that timestamp.
      const body = JSON.stringify(payload);
      const etag = `\"${createHash('sha256').update(body).digest('hex')}\"`;
      res.set('Cache-Control', 'private, no-cache');
      res.set('ETag', etag);
      if (req.headers['if-none-match'] === etag) return res.status(304).end();
      return res.type('application/json').send(body);
    };
    if(queueMarket){
      if(!profileId&&isVipPortalRequest(req))return res.status(403).json({status:'error',message:'VIP portal must request its token-scoped ledger snapshot'});
      if(profileId&&!hasProfileAccess(req,profileId))return rejectProfileAccess(res,profileId);
      const type=String(req.query.queueType||'ank');
      if(!['ank','jodi','pannel'].includes(type))return res.status(400).json({status:'error',message:'Invalid queue type'});
      const entries=Object.entries(botState.ledgerState.profiles||{}).filter(([pid])=>pid!=='admin1'&&(!profileId||pid===profileId));
      return sendSnapshot({status:'success',date:botState.ledgerState.date,diagnostics:entries.map(([pid,prof])=>describeVipQueue(pid,prof,queueMarket,type,stored?.profiles?.[pid]))});
    }
    if (!profileId) {
      if (isVipPortalRequest(req)) {
        return res.status(403).json({ status: 'error', message: 'VIP portal must request its token-scoped ledger snapshot' });
      }
      return sendSnapshot({ status: 'success', ledger: { ...botState.ledgerState, profiles: Object.fromEntries(Object.entries(botState.ledgerState.profiles || {}).map(([pid, runtime]) => [pid, { ...runtime, profitMilestoneNotificationsEnabled: profileProfitNotificationsEnabled(pid, stored) }])) } });
    }
    if (!hasProfileAccess(req, profileId)) return rejectProfileAccess(res, profileId);
    const profile = botState.ledgerState?.profiles?.[profileId];
    return sendSnapshot({
      status: 'success',
      vipGameRuns: profileId !== 'admin1' ? stored?.profiles?.[profileId]?.vipGameRuns || {} : undefined,
      profitMilestoneNotificationsEnabled: profileProfitNotificationsEnabled(profileId, stored),
      ledger: {
        date: botState.ledgerState?.date || '',
        updatedAt: botState.ledgerState?.updatedAt || 0,
        profiles: profile ? { [profileId]: profile } : {},
      },
    });
  });

  /** Apply confirmed market results within one authorized profile/date only. */
  function applyLinkedManualResults(pid: string, prof: any, type: string, index: number, undo = false, historical = false) {
    const cards = prof.cards || {};
    const originKey = `${type}_${index}`;
    const origin = cards[originKey];
    const changed: string[] = [];
    const tracks = new Map<string, string>();
    const markets = prof.markets || [];
    const rememberTrack = (key: string) => {
      const market = markets.find((m: any) => `${m.type}_${m.index}` === key);
      if (market) tracks.set(serverRecoveryTrackKey(prof, market.type, market.n), market.type);
    };
    const settleLinkedOpenFailure=(rec:any)=>{
      rec.s='FAIL';rec.manualStatus=true;rec.manualOverrideAt=Date.now();delete rec.manualResult;
      if(!rec.sentRate){const rate=Number(rec.r);rec.sentRate=String(rate);rec.sentDigits=String(rec.d);rec.sentInvest=countSettlementTokens(rec.d,'jodi')*rate;rec.sentSourceMode=rec.sourceMode;rec.sentTrick=rec.trick;rec.sentScrapeSource=getScrapeSource(rec);}
      rec.dispatchState='SETTLED';rec.settledAt=rec.jodiOpenSettledAt;
    };
    if (undo) {
      const invalid = new Set([originKey]);
      const openFailedBets=new Map<string,{digits:string;rate:string;invest:number;settledAt?:number;openSettledAt?:number}>();
      let found = true;
      while (found) {
        found = false;
        for (const [key, rec] of Object.entries(cards) as any[]) {
          if (invalid.has(key) || !rec.manualResultSources?.some((source: string) => invalid.has(source))) continue;
          invalid.add(key); found = true; changed.push(key);
          if(key.startsWith('jodi_')&&rec.jodiOpenStatus==='FAIL')openFailedBets.set(key,{digits:String(rec.sentDigits||rec.d),rate:String(rec.sentRate||rec.r),settledAt:rec.settledAt,openSettledAt:rec.jodiOpenSettledAt,invest:Number(rec.sentInvest)||calculateSettlement({type:'jodi',digits:rec.sentDigits||rec.d,rate:rec.sentRate||rec.r}).invest});
          rec.s = 'WAIT'; rec.manualStatus = true; rec.manualOverrideAt = Date.now();
          for (const field of ['manualResult', 'manualPanelResult', 'manualResultSources', 'settledAt', 'jodiOpenStatus', 'jodiOpenResult', 'jodiOpenSettledAt']) delete rec[field];
          // Preserve genuine delivery snapshots; a linked undo is not a new play.
          rec.dispatchState = rec.sentAt ? 'SENT' : undefined;
          if (!rec.sentAt) for (const field of ['sentRate', 'sentInvest', 'sentDigits', 'sentSourceMode', 'sentTrick', 'sentScrapeSource']) delete rec[field];
          if (historical && !rec.sentAt) {
            const restored = restoreBacktestRecord(rec);
            for (const field of Object.keys(rec)) delete rec[field];
            Object.assign(rec, restored, { manualStatus: true, manualOverrideAt: Date.now() });
          }
          rememberTrack(key);
        }
      }
      // Undoing CLOSE invalidates the pair, but a still-valid OPEN result must
      // retain its existing OPEN-driven JODI recovery outcome.
      for (const key of changed) {
        const market = markets.find((m: any) => `${m.type}_${m.index}` === key);
        if (market?.type !== 'jodi') continue;
        const open = markets.find((m: any) => m.type === 'ank' && String(m.n).trim().toUpperCase() === `${String(market.n).trim().toUpperCase()} OPEN`);
        const openKey = open ? `ank_${open.index}` : '';
        const openRec = cards[openKey];
        const digit = openRec && (openRec.s === 'PASS' || openRec.s === 'FAIL')
          ? normalizeManualResult('ank', openRec.manualStatus ? openRec.manualResult : openRec.scrapeResultDigit) : undefined;
        const failedBet=openFailedBets.get(key);
        const openStatus = digit ? jodiOpenSideStatus(failedBet?.digits||cards[key].sentDigits || cards[key].d, digit) : null;
        if (openStatus) {
          cards[key].jodiOpenStatus = openStatus; cards[key].jodiOpenResult = digit;
          cards[key].jodiOpenSettledAt = Date.now(); cards[key].manualResultSources = [openKey];
          if(openStatus==='FAIL'){if(failedBet)Object.assign(cards[key],{sentDigits:failedBet.digits,sentRate:failedBet.rate,sentInvest:failedBet.invest,r:failedBet.rate,jodiOpenSettledAt:failedBet.openSettledAt||cards[key].jodiOpenSettledAt});settleLinkedOpenFailure(cards[key]);}
        }
      }
    } else {
      const actual = normalizeManualResult(type, origin?.manualResult);
      if (!actual) return changed;
      for (const target of linkedManualResults(markets, cards, type, index, actual, origin.manualPanelResult)) {
        const key = `${target.type}_${target.index}`;
        const rec = cards[key];
        const market = markets.find((m: any) => `${m.type}_${m.index}` === key);
        if (!rec || !market || market.enabled === false || rec.s === 'SKIP') continue;
        const ownDigits = rec.sentDigits || rec.d;
        const rate = Number(rec.sentRate || rec.r);
        if (!areSettlementTokensValid(target.type, ownDigits) || !Number.isFinite(rate) || !(rate > 0)) continue;
        // A related result must never invent an undelivered VIP Auto play.
        if (!historical && pid !== 'admin1' && prof.vipAutoMode !== false && !rec.sentAt && rec.dispatchState !== 'SENT' && rec.dispatchState !== 'SETTLED') continue;
        if ((rec.s === 'PASS' || rec.s === 'FAIL') && !rec.manualResultSources?.length) continue;
        if (target.openOnly) {
          const previousEarlyFail=rec.s==='FAIL'&&rec.jodiOpenStatus==='FAIL'&&!rec.manualResult;
          if (rec.s !== 'WAIT'&&!previousEarlyFail) continue;
          const openStatus = jodiOpenSideStatus(ownDigits, target.result);
          if (!openStatus || (rec.jodiOpenResult === target.result && rec.jodiOpenStatus === openStatus && !(openStatus==='FAIL'&&rec.s==='WAIT'))) continue;
          rec.jodiOpenStatus = openStatus; rec.jodiOpenResult = target.result; rec.jodiOpenSettledAt = Date.now();
          rec.manualResultSources = target.sources;
          if(openStatus==='FAIL'){
            settleLinkedOpenFailure(rec);
            if(!historical)serverQueueResultFollowUp({profileId:pid,profile:prof,marketName:market.n,type:'jodi',index:target.index,date:botState.ledgerState.date,status:'FAIL',rec,resultDigit:`OPEN ${target.result}`});
          }else if(previousEarlyFail){rec.s='WAIT';delete rec.manualStatus;delete rec.manualOverrideAt;delete rec.settledAt;rec.dispatchState=rec.sentAt?'SENT':undefined;}
        } else {
          // A later CLOSE cannot settle or charge the same OPEN failure twice.
          if(target.type==='jodi'&&rec.s==='FAIL'&&rec.jodiOpenStatus==='FAIL'&&rec.jodiOpenResult===target.result[0]){
            if(rec.manualResult!==target.result){rec.manualResult=target.result;rec.manualResultSources=target.sources;rec.manualOverrideAt=Date.now();changed.push(key);rememberTrack(key);}
            continue;
          }
          const nextStatus = manualResultStatus(target.type, ownDigits, target.result);
          if (rec.manualResult === target.result && rec.s === nextStatus) continue;
          if (target.type === 'jodi') {
            const openStatus = jodiOpenSideStatus(ownDigits, target.result[0]);
            if (openStatus && (rec.jodiOpenResult !== target.result[0] || rec.jodiOpenStatus !== openStatus)) {
              rec.jodiOpenStatus = openStatus; rec.jodiOpenResult = target.result[0]; rec.jodiOpenSettledAt = Date.now();
            }
          }
          rec.s = nextStatus; rec.manualStatus = true; rec.manualResult = target.result;
          rec.manualResultSources = target.sources; rec.manualOverrideAt = Date.now();
          delete rec.scrapeResultDigit;
          if (!rec.sentRate) {
            rec.sentRate = String(rate); rec.sentDigits = String(ownDigits);
            rec.sentInvest = rec.smartStaking?.isSmartStaking && rec.smartStaking.totalInvest ? rec.smartStaking.totalInvest : countSettlementTokens(ownDigits, target.type) * rate;
            rec.sentSourceMode = rec.sourceMode; rec.sentTrick = rec.trick; rec.sentScrapeSource = getScrapeSource(rec);
          }
          rec.dispatchState = 'SETTLED'; rec.settledAt = Date.now();
          if (!historical) serverQueueResultFollowUp({ profileId: pid, profile: prof, marketName: market.n, type: target.type, index: target.index, date: botState.ledgerState.date, status: nextStatus, rec, resultDigit: target.result });
        }
        changed.push(key); rememberTrack(key);
      }
    }
    if (!historical) {
      prof.recoveryState = prof.recoveryState || {};
      for (const [track, t] of tracks) prof.recoveryState[track] = { ...serverSettledTrackState(prof, t, track), updatedAt: Date.now() };
      if (undo && changed.length) {
        for (const job of botState.pendingBroadcasts) {
          if (job.status !== 'pending' || job.broadcastKind !== 'result-followup' || job.profileId !== pid || !changed.includes(`${job.cardType}_${job.index}`)) continue;
          job.failedTargets = normalizeTargetList(job.targets);
          finishResolvedBroadcast(job, 'LINKED_MANUAL_UNDO');
        }
      }
    }
    return changed;
  }

  /**
   * Manual unlock / status from dashboard.
   * Clears sticky server PASS/FAIL so undo to WAIT actually sticks.
   */
  let ledgerSetCardHandler: express.RequestHandler;
  app.post("/api/bot/ledger_set_card", ledgerSetCardHandler = (req, res) => {
    try {
      const { profileId, type, index, status, rate, digits, sourceMode, trick, positionRule, marketName, manualSettlement, mirrorFromAdmin, clearManualRate, date, actualResult, actualPanel, linkRelatedResults, resultUndoOnly, clearCard, copyAdmin, sourceEditedAt } = req.body || {};
      const pid = String(profileId || 'admin1');
      const t = String(type || '');
      const idx = Number(index);
      let st = clearCard === true ? 'WAIT' : String(status || 'WAIT').toUpperCase();
      if (!['ank', 'jodi', 'pannel'].includes(t) || !Number.isInteger(idx) || idx < 0) {
        return res.status(400).json({ status: 'error', message: 'type + index required' });
      }
      if (!hasProfileAccess(req, pid)) return rejectProfileAccess(res, pid);
      const entryProfile = readFullAppStateView()?.profiles?.[pid];
      if ((mirrorFromAdmin || copyAdmin === true) && entryProfile?.vipLiveStart) {
        const list = t === 'jodi' ? getEffectiveBaseMarkets(entryProfile.config) : getEffectiveMarkets(entryProfile.config);
        const name = String(marketName || list[idx]?.n || '');
        if (!vipLiveMarketEligible(entryProfile, String(date || calculateBusinessDateIST()), t, name)) {
          return res.json({status:'success', skipped:true, reason:'BEFORE_VIP_LIVE_ENTRY'});
        }
      }
      const hasStatus = clearCard === true || (status !== undefined && status !== null);
      const hasRate = rate !== undefined && rate !== null;
      const selectedResult = normalizeManualResult(t, actualResult);
      const selectedPanel = actualPanel === undefined ? undefined : normalizeManualResult('pannel', actualPanel);
      if (actualPanel !== undefined && (t !== 'ank' || !selectedPanel || !selectedResult || panelAnkDigit(selectedPanel) !== selectedResult)) {
        return res.status(400).json({ status: 'error', message: 'Actual Panel patti must match the selected ANK result' });
      }
      if (actualResult !== undefined && (!selectedResult || !hasStatus || (st !== 'PASS' && st !== 'FAIL'))) {
        return res.status(400).json({ status: 'error', message: 'Invalid actual result for manual PASS/FAIL' });
      }
      const cleanSourceMode = CARD_SOURCE_MODES.includes(String(sourceMode || '') as CardSourceMode)
        ? String(sourceMode) as CardSourceMode
        : undefined;
      const cleanTrick = ['T1', 'T2', 'T3'].includes(String(trick || ''))
        ? String(trick) as 'T1' | 'T2' | 'T3'
        : undefined;
      const cleanPositionRule = ['FIRST_CUT', 'CUT2', 'FCUT', 'LCUT', 'CENTER', 'WEEKDAY', 'RECENT2', 'RECENT6', 'RECENT4', 'LAST_ACTUAL_MIRROR', 'FIRST_DIGIT_MIRROR', 'SSD', 'FLOW_3_1', 'TRI_CUT', 'SNIPER_1', 'TESLA_369'].includes(String(positionRule || ''))
        ? String(positionRule)
        : undefined;
      const freshCard = (old: any, targetDate: string) => {
        const fresh=clearedLedgerCard(old,marketName,Number(sourceEditedAt||0)),version=fresh.cardGeneration;
        if (copyAdmin === true) {
          const full = readFullAppState(); const admin = full?.profiles?.admin1;
          const list = t === 'jodi' ? getEffectiveBaseMarkets(admin?.config) : getEffectiveMarkets(admin?.config);
          const normMkt = (v: unknown) => String(v || '').trim().replace(/\s+/g, ' ').toUpperCase().replace(/^(?:SHRIDEVI|SRIDEVI|SRIDEV) DAY\b/, 'SRIDEVI').replace(/^(?:SHRIDEVI|SRIDEV)\b/, 'SRIDEVI');
          const ai = list.findIndex((m: any) => normMkt(m.n) === normMkt(fresh.marketName));
          const dict = t === 'ank' ? 'data' : t === 'jodi' ? 'jodiData' : 'pannelData';
          const liveCandidate = targetDate === botState.ledgerState?.date ? botState.ledgerState?.profiles?.admin1?.cards?.[`${t}_${ai}`] : undefined;
          const storedCandidate = admin?.dayRecords?.[targetDate]?.[dict]?.[ai];
          const source: any = (liveCandidate && Number(storedCandidate?.sourceEditedAt || 0) <= Number(liveCandidate?.sourceEditedAt || 0) && (String(liveCandidate.d || '').trim() || isEditableSourceSkip(liveCandidate as any)))
            ? liveCandidate
            : (storedCandidate || liveCandidate);
          if (source) Object.assign(fresh, projectAdminSource(fresh, source, fresh.marketName, false, true));
          fresh.cardGeneration = version; fresh.sourceEditedAt = Math.max(version, fresh.sourceEditedAt || 0);
        }
        return fresh;
      };
      const requestedDate = String(date || '').trim();
      const liveDate = String(botState.ledgerState?.date || calculateBusinessDateIST());
      if (requestedDate && (requestedDate < businessDateIST() || requestedDate !== liveDate)) {
        const stored = readFullAppState();
        const storedProfile = stored?.profiles?.[pid];
        if (!storedProfile) return res.status(404).json({ status: 'error', message: 'Profile not found for historical update' });
        const dictName = t === 'ank' ? 'data' : t === 'jodi' ? 'jodiData' : t === 'pannel' ? 'pannelData' : '';
        if (!dictName) return res.status(400).json({ status: 'error', message: 'Invalid card type' });
        const dayRecords = { ...(storedProfile.dayRecords || {}) };
        const dayStore = { ...(dayRecords[requestedDate] || {}) };
        const dict = { ...(dayStore[dictName] || {}) };
        const historical = { ...(dict[idx] || { s: 'WAIT', d: '', r: '' }) } as any;
        const previousActualResult = historical.manualResult || historical.scrapeResultDigit;
        if (
          manualSettlement && !mirrorFromAdmin && hasStatus && (st === 'PASS' || st === 'FAIL') &&
          !areSettlementTokensValid(t, digits || historical.sentDigits || historical.d)
        ) {
          return res.status(400).json({ status: 'error', message: `Invalid ${t.toUpperCase()} digits/tokens` });
        }
        if (selectedResult && mirrorFromAdmin) {
          const ownDigits = historical.sentDigits || historical.d;
          if (!areSettlementTokensValid(t, ownDigits)) return res.status(400).json({ status: 'error', message: 'VIP card digits missing or invalid' });
          st = manualResultStatus(t, ownDigits, selectedResult);
        }
        if (selectedResult && !mirrorFromAdmin && !manualResultMatchesStatus(t, historical.sentDigits || digits || historical.d, selectedResult, st)) {
          return res.status(400).json({ status: 'error', message: 'Actual result does not match selected PASS/FAIL' });
        }
        if (hasStatus) {
          historical.s = st === 'PASS' || st === 'FAIL' || st === 'SKIP' ? st : 'WAIT';
          historical.manualStatus = true;
          delete historical.backtestResult;
        }
        if (hasRate && !mirrorFromAdmin) {
          historical.r = String(rate);
          if (!hasStatus) historical.manualRate = true;
        }
        if (digits !== undefined && digits !== null && !mirrorFromAdmin) historical.d = String(digits);
        if (cleanSourceMode) historical.sourceMode = cleanSourceMode;
        if (hasStatus) { delete historical.scrapeResultDigit; delete historical.manualResult; }
        if (selectedResult) historical.manualResult = selectedResult;
        if (hasStatus) { delete historical.manualResultSources; delete historical.manualPanelResult; }
        if (selectedPanel) historical.manualPanelResult = selectedPanel;
        if (cleanTrick) historical.trick = cleanTrick;
        if (cleanPositionRule) historical.positionRule = cleanPositionRule;
        if (marketName) historical.marketName = String(marketName).trim().toUpperCase();
        historical.manualOverrideAt = Date.now();
        if (manualSettlement && !mirrorFromAdmin && hasStatus && (st === 'PASS' || st === 'FAIL') && hasRate) {
          const manualRateNum = Math.max(0, Number(rate) || 0);
          const manualDigits = String(digits || historical.d || '').trim();
          const manualCount = countSettlementTokens(manualDigits, t);
          if (manualRateNum > 0 && manualCount > 0) {
            historical.d = manualDigits;
            historical.r = String(manualRateNum);
            historical.sentRate = String(manualRateNum);
            historical.sentInvest = historical.smartStaking?.isSmartStaking && historical.smartStaking.totalInvest > 0
              ? historical.smartStaking.totalInvest
              : manualCount * manualRateNum;
            historical.sentDigits = manualDigits;
            historical.sentSourceMode = historical.sourceMode;
            historical.sentTrick = historical.trick;
            historical.sentScrapeSource = getScrapeSource(historical);
            historical.dispatchState = 'SETTLED';
            historical.settledAt = Date.now();
          }
        }
        if (hasStatus && st === 'WAIT') {
          const restored = restoreBacktestRecord(historical);
          for (const field of Object.keys(historical)) delete historical[field];
          Object.assign(historical, restored, { manualStatus: true, manualOverrideAt: Date.now() });
        }
        dict[idx] = clearCard === true ? freshCard(dict[idx]||historical, requestedDate) : historical;
        dayStore[dictName] = dict;
        if (linkRelatedResults === true && hasStatus && (st === 'WAIT' || selectedResult)) {
          const historyProfile = { ...storedProfile, dayRecords: { ...dayRecords, [requestedDate]: dayStore } };
          const runtime = savedDailyLedgerProfiles({ [pid]: historyProfile }, requestedDate)[pid];
          const invalidated = selectedResult && previousActualResult && selectedResult !== previousActualResult
            ? applyLinkedManualResults(pid, runtime, t, idx, true, true) : [];
          const changed = [...invalidated, ...applyLinkedManualResults(pid, runtime, t, idx, st === 'WAIT', true)];
          for (const key of changed) {
            const [relatedType, relatedIndex] = key.split('_');
            const relatedDict = relatedType === 'ank' ? 'data' : relatedType === 'jodi' ? 'jodiData' : 'pannelData';
            dayStore[relatedDict] = { ...dayStore[relatedDict], [relatedIndex]: runtime.cards[key] };
          }
        }
        dayRecords[requestedDate] = dayStore;
        writeFullAppState({
          ...stored,
          profiles: { ...stored.profiles, [pid]: calculateBacktestRecovery({ ...storedProfile, dayRecords }, requestedDate) },
        });
        return res.json({ status: 'success', historical: true, date: requestedDate, card: dict[idx] });
      }
      if (!botState.ledgerState) {
        botState.ledgerState = { date: liveDate, updatedAt: Date.now(), profiles: {} };
      }
      if (!botState.ledgerState.date) botState.ledgerState.date = liveDate;
      if (!botState.ledgerState.profiles[pid]) {
        botState.ledgerState.profiles[pid] = { name: pid, phone: '', markets: [], cards: {} };
      }
      const cards = botState.ledgerState.profiles[pid].cards || {};
      const key = `${t}_${idx}`;
      const prev = cards[key] || { s: 'WAIT', d: '', r: '' };
      const rateIsFrozen = Boolean(
        prev.sentRate || prev.dispatchState === 'SENT' || prev.dispatchState === 'SETTLED' ||
        prev.s === 'PASS' || prev.s === 'FAIL'
      );
      const acceptSourceMetadata = !rateIsFrozen;
      // A delayed rate-only request must never rewrite a card after delivery or
      // settlement. A status command is allowed because it atomically freezes
      // the newest visible manual rate with PASS/FAIL.
      const acceptRate = hasRate && !mirrorFromAdmin && (hasStatus || !rateIsFrozen);
      if (
        manualSettlement && !mirrorFromAdmin && hasStatus && (st === 'PASS' || st === 'FAIL') &&
        !areSettlementTokensValid(t, digits || prev.sentDigits || prev.d)
      ) {
        return res.status(400).json({ status: 'error', message: `Invalid ${t.toUpperCase()} digits/tokens` });
      }
      if (selectedResult && mirrorFromAdmin) {
        const ownDigits = prev.sentDigits || prev.d;
        if (!areSettlementTokensValid(t, ownDigits)) return res.status(400).json({ status: 'error', message: 'VIP card digits missing or invalid' });
        st = manualResultStatus(t, ownDigits, selectedResult);
      }
      if (selectedResult && !mirrorFromAdmin && !manualResultMatchesStatus(t, prev.sentDigits || digits || prev.d, selectedResult, st)) {
        return res.status(400).json({ status: 'error', message: 'Actual result does not match selected PASS/FAIL' });
      }
      // Network retries of an identical manual result must not rerun recovery
      // handoff or move the settlement time after newer cards were processed.
      const sameManualSettlement = hasStatus && (st === 'PASS' || st === 'FAIL') &&
        prev.manualStatus && prev.s === st && !clearManualRate &&
        String(prev.manualResult || '') === String(selectedResult || '') &&
        (mirrorFromAdmin || digits === undefined || String(digits).split(/[,|\s]+/).filter(Boolean).join(',') === String(prev.sentDigits || prev.d || '').split(/[,|\s]+/).filter(Boolean).join(',')) &&
        (mirrorFromAdmin || !hasRate || Number(rate) === Number(prev.sentRate || prev.r));
      if (sameManualSettlement) {
        if (selectedPanel) prev.manualPanelResult = selectedPanel;
        const linkedCards = linkRelatedResults === true ? applyLinkedManualResults(pid, botState.ledgerState.profiles[pid], t, idx) : [];
        if (linkedCards.length) { finalizeProfileReadyRates(pid, 'linked-manual-settlement'); if (pid !== 'admin1') queueVipAutoReadyCards('linked-manual-settlement'); queueProfitMilestoneNotifications([pid]); }
        if (linkedCards.length || selectedPanel) persistLedgerSnapshot();
        return res.json({ status: 'success', card: prev, unchanged: true, linkedCards });
      }
      cards[key] = {
        ...prev,
        ...(hasStatus ? { s: st === 'PASS' || st === 'FAIL' || st === 'SKIP' ? st : 'WAIT', manualStatus: true } : {}),
        ...(acceptRate ? { r: String(rate), ...(!hasStatus ? { manualRate: true } : {}) } : {}),
        ...(cleanSourceMode && acceptSourceMetadata ? { sourceMode: cleanSourceMode } : {}),
        ...(cleanTrick && acceptSourceMetadata ? { trick: cleanTrick } : {}),
        ...(cleanPositionRule && acceptSourceMetadata ? { positionRule: cleanPositionRule } : {}),
        ...(marketName ? { marketName: String(marketName).trim().toUpperCase() } : {}),
        ...(hasStatus || acceptRate ? { manualOverrideAt: Date.now() } : {}),
      };
      if (clearManualRate === true && !rateIsFrozen) {
        delete cards[key].manualRate;
        delete cards[key].manualOverrideAt;
        delete cards[key].rateFinalizedAt;
        delete cards[key].rateFinalizedFrom;
      }
      // Manual PASS/FAIL is an explicit UI settlement. Freeze the exact digits
      // and rate visible in the box atomically with the status, so an older
      // sent/default rate cannot reappear after the click.
      if (manualSettlement && hasStatus && (st === 'PASS' || st === 'FAIL')) {
        const profRuntime: any = botState.ledgerState.profiles[pid];
        const mktObj = (profRuntime?.markets || []).find((m: any) => String(m?.type) === t && Number(m?.index) === idx);
        const trackKeyForSettle = mktObj ? serverRecoveryTrackKey(profRuntime, t, String(mktObj.n || '')) : `${t}:ALL`;
        if (mirrorFromAdmin && !cards[key].sentRate) {
          const priorState = serverSettledTrackState(profRuntime, t, trackKeyForSettle, idx);
          serverFinalizeVipReadyRate(profRuntime, t, cards[key], trackKeyForSettle, priorState.debt);
        }
        const manualRateNum = mirrorFromAdmin
          ? Math.max(0, Number(cards[key].sentRate || cards[key].r || cards[key].recRate || 0))
          : (acceptRate ? Math.max(0, Number(rate) || 0) : Math.max(0, Number(cards[key].sentRate || cards[key].r || cards[key].recRate || 0)));
        const manualDigits = String((!mirrorFromAdmin && digits) || cards[key].sentDigits || cards[key].d || '').trim();
        const manualCount = countSettlementTokens(manualDigits, t);
        if (manualRateNum > 0 && manualCount > 0) {
          cards[key].d = manualDigits || cards[key].d;
          cards[key].r = String(manualRateNum);
          cards[key].sentRate = String(manualRateNum);
          cards[key].sentInvest = cards[key].smartStaking?.isSmartStaking && cards[key].smartStaking.totalInvest > 0
            ? cards[key].smartStaking.totalInvest
            : manualCount * manualRateNum;
          cards[key].sentDigits = manualDigits;
          cards[key].sentSourceMode = cards[key].sourceMode;
          cards[key].sentTrick = cards[key].trick;
          cards[key].sentScrapeSource = getScrapeSource(cards[key]);
          cards[key].sentLoopId = cards[key].loopId || cards[key].sentLoopId;
        }
      }
      if (hasStatus) { delete cards[key].scrapeResultDigit; delete cards[key].manualResult; }
        if (selectedResult) cards[key].manualResult = selectedResult;
      if (hasStatus) { delete cards[key].manualResultSources; delete cards[key].manualPanelResult; }
      if (selectedPanel) cards[key].manualPanelResult = selectedPanel;
      if (hasStatus && st === 'WAIT') {
        if((prev.vipAutoStopSkipped||prev.vipAutoStopResumeEligible)&&!prev.sentRate&&!prev.sentDigits&&!prev.sentAt&&prev.dispatchState!=='SENT'&&prev.dispatchState!=='SETTLED')cards[key].vipAutoStopResumeEligible=true;
        else delete cards[key].vipAutoStopResumeEligible;
        if (resultUndoOnly !== true && (clearCard === true || prev.sentRate || prev.sentDigits || prev.sentAt || prev.deliveryRestoredAt)) cards[key].deliveryRestoredAt = Date.now();
        // Undo means the prior settlement is invalid. Keep digits/rate for
        // correction, but release every frozen delivery/settlement field.
        // The PASS/FAIL status request included its visible rate; that alone
        // must not turn the undone card into a permanent manual-rate override.
        delete cards[key].manualRate;
        delete cards[key].rateFinalizedAt;
        delete cards[key].rateFinalizedFrom;
        delete cards[key].sentRate;
        delete cards[key].sentInvest;
        delete cards[key].sentDigits;
        delete cards[key].sentSourceMode;
        delete cards[key].sentTrick;
        delete cards[key].sentScrapeSource;
        delete cards[key].scrapeResultDigit;
        delete cards[key].dispatchState;
        delete cards[key].dispatchKey;
        delete cards[key].queuedAt;
        delete cards[key].sentAt;
        delete cards[key].settledAt;
        delete cards[key].sentTargets;
        delete cards[key].sentLoopId;
        delete cards[key].jodiOpenStatus;
        delete cards[key].jodiOpenResult;
        delete cards[key].jodiOpenSettledAt;
        if ((cards[key].deliveryRestoredAt || resultUndoOnly === true) && !(req as any).deferBulkClearSave) {
          const full = readFullAppState();
          const saved = full?.profiles?.[pid];
          const run = saved?.vipGameRuns?.[t];
          const baseline = run?.date === liveDate ? run.baselineCards?.[key] : undefined;
          if (baseline) {
            const baselineCards = { ...run.baselineCards };
            if (resultUndoOnly === true) baselineCards[key] = { invest: baseline.invest, profit: 0 }; else delete baselineCards[key];
            const adjusted = { ...run, baseInvest: Math.max(0, run.baseInvest - (resultUndoOnly === true ? 0 : baseline.invest)), baseProfit: run.baseProfit - baseline.profit, baselineCards };
            saved.vipGameRuns = { ...saved.vipGameRuns, [t]: adjusted };
            botState.ledgerState.profiles[pid].vipGameRuns = saved.vipGameRuns;
            writeFullAppState(full);
          }
          for (const job of botState.pendingBroadcasts) {
            if (resultUndoOnly === true && job.broadcastKind !== 'result-followup') continue;
            if (job.status !== 'pending' || job.profileId !== pid || job.cardType !== t || Number(job.index) !== idx) continue;
            job.failedTargets = normalizeTargetList(job.targets); finishResolvedBroadcast(job, 'CARD_RESTORED');
          }
          persistPendingBroadcasts();
        }
        // Ignore only the exact audit event(s) that previously marked this
        // card. A future result is a new queue item and remains automatic.
        const cardIdentity = `${pid}|${key}`;
        for (const audit of botState.pendingAuditResults || []) {
          if (clearCard !== true && (!Array.isArray((audit as any).markedCardKeys) || !(audit as any).markedCardKeys.includes(cardIdentity))) continue;
          if (clearCard === true && audit.deferredCards) delete audit.deferredCards[cardIdentity];
          (audit as any).ignoredCardKeys = Array.isArray((audit as any).ignoredCardKeys)
            ? [...new Set([...(audit as any).ignoredCardKeys, cardIdentity])]
            : [cardIdentity];
        }
        // Roll this track back to the state immediately before the invalid
        // result, then recalculate all following suggestions.
        const prof: any = botState.ledgerState.profiles[pid];
        const market = (prof.markets || []).find((m: any) => String(m?.type) === t && Number(m?.index) === idx);
        if (market) {
          const trackKey = serverRecoveryTrackKey(prof, t, String(market.n || ''));
          prof.recoveryState = prof.recoveryState || {};
          prof.recoveryState[trackKey] = {
            ...serverSettledTrackState(prof, t, trackKey, idx),
            updatedAt: Date.now(),
          };
        }
      }
      if (hasStatus && st === 'WAIT' && resultUndoOnly === true && !prev.deliveryRestoredAt && (prev.sentRate || prev.sentDigits)) {
        for (const field of ['sentRate','sentInvest','sentDigits','sentSourceMode','sentTrick','sentScrapeSource','sentTargets','sentLoopId','sentAt','dispatchKey']) if (prev[field] !== undefined) cards[key][field] = prev[field];
        cards[key].dispatchState = 'SENT';
      }
      botState.ledgerState.profiles[pid].cards = cards;
      if (linkRelatedResults === true && selectedResult && (prev.manualResult || prev.scrapeResultDigit) && selectedResult !== (prev.manualResult || prev.scrapeResultDigit)) {
        applyLinkedManualResults(pid, botState.ledgerState.profiles[pid], t, idx, true);
      }
      // Manual Admin and VIP PASS/FAIL use the same backend recovery handoff.
      // Keeping Admin out of this block made realtime sync finalize its next
      // Ledger card with debt=0 after a FAIL.
      if (hasStatus && (st === 'PASS' || st === 'FAIL')) {
        const prof: any = botState.ledgerState.profiles[pid];
        const rec: any = cards[key];
        const market = (prof.markets || []).find((m: any) => String(m?.type) === t && Number(m?.index) === idx);
        if (market && market.enabled !== false) {
          const trackKey = serverRecoveryTrackKey(prof, t, String(market.n || ''));
          const priorDebt = Math.max(0, Number(prof.recoveryState?.[trackKey]?.debt ?? rec.prevLoss) || 0);
          const settled = calculateSettlement({
            type: t,
            digits: rec.sentDigits || rec.d,
            rate: rec.r,
            sentRate: rec.sentRate,
            sentInvest: rec.sentInvest,
            smartStaking: rec.smartStaking,
          });
          const correctedSettlement = linkRelatedResults === true && (prev.s === 'PASS' || prev.s === 'FAIL');
          const nextDebt = (correctedSettlement||prof.liveThreeFailReset===true||runtimeRecoveryShareLedger(prof,t)) ? serverSettledTrackState(prof, t, trackKey).debt : st === 'FAIL' ? priorDebt + settled.invest : 0;
          prof.recoveryState = prof.recoveryState || {};
          prof.recoveryState[trackKey] = {
            debt: nextDebt,
            fromCardKey: key,
            fromIndex: idx,
            updatedAt: Date.now(),
          };
          if(prof.liveThreeFailReset===true||runtimeRecoveryShareLedger(prof,t))prof.recoveryState[trackKey]={...serverSettledTrackState(prof,t,trackKey),updatedAt:Date.now()};
          rec.dispatchState = 'SETTLED';
          rec.settledAt = Date.now();
          serverQueueResultFollowUp({
            profileId: pid,
            profile: prof,
            marketName: String(market.n || ''),
            type: t,
            index: idx,
            date: String(botState.ledgerState.date || date || calculateBusinessDateIST()),
            status: st,
            rec,
            resultDigit: selectedResult || null,
          });
        }
      }
      const isDeferredBulk = Boolean((req as any).deferBulkClearSave);
      if (clearCard === true) {
        cards[key] = freshCard(prev, liveDate);
        botState.activeSchedules = botState.activeSchedules.filter((job: any) => !(String(job.profileId || 'admin1') === pid && job.type === t && Number(job.index) === idx));
        if (!isDeferredBulk) {
          atomicWriteFileAsync(path.join(titanDataDir, 'active_schedules.json'), JSON.stringify(botState.activeSchedules), 'active-schedules');
        }
      }
      botState.ledgerState.updatedAt = Date.now();
      const linkedCards = linkRelatedResults === true && hasStatus && (st === 'WAIT' || selectedResult)
        ? applyLinkedManualResults(pid, botState.ledgerState.profiles[pid], t, idx, st === 'WAIT') : [];
      if (clearManualRate === true && !rateIsFrozen && !isDeferredBulk) {
        finalizeProfileReadyRates(pid, 'manual-rate-release');
      }
      if (hasStatus && (st === 'PASS' || st === 'FAIL') && !isDeferredBulk) {
        // Calculation handoff is immediate for both Ledger/Admin and VIP.
        finalizeProfileReadyRates(pid, 'manual-settlement');
        if (pid !== 'admin1') queueVipAutoReadyCards('manual-settlement');
        queueProfitMilestoneNotifications([pid]);
      }
      if (hasStatus && st === 'WAIT' && !isDeferredBulk) {
        finalizeProfileReadyRates(pid, copyAdmin === true ? 'copy-admin' : 'manual-undo');
        if (pid !== 'admin1' && copyAdmin === true && !(req as any).deferSnapshotQueue) {
          queueVipAutoReadyCards('copy-admin');
        }
        persistPendingAudits();
      }
      if (!isDeferredBulk) {
        persistLedgerSnapshot();
      }
      if (clearCard === true && !isDeferredBulk) { const full = readFullAppState(); if (full) writeFullAppState(mergeLedgerIntoFullAppState(full)); }
      res.json({ status: 'success', card: cards[key], linkedCards });
    } catch (e: any) {
      res.status(500).json({ status: 'error', message: e?.message || 'set card failed' });
    }
  });

  // Admin-only preview: selected date and eligibility, never the full workspace archive.
  app.get('/api/bot/ledger_copy_admin_snapshot_preview', (req,res)=>{
    try{
      const pid=String(req.query.profileId||''),date=String(req.query.date||'');
      if(!pid||pid==='admin1'||!validLoopDate(date))return res.status(400).json({status:'error',message:'VIP profile and valid date required'});
      if(!hasProfileAccess(req,pid))return rejectProfileAccess(res,pid);
      const state=readFullAppStateView(true),vip=state?.profiles?.[pid],admin=state?.profiles?.admin1;
      if(!vip||!admin)return res.status(404).json({status:'error',message:'VIP/Admin profile missing'});
      res.set('Cache-Control','no-store');
      return res.json({status:'success',profileId:pid,date,...adminSnapshotPreview(vip,admin,date,botState.ledgerState,pid)});
    }catch(error:any){return res.status(500).json({status:'error',message:error?.message||'Snapshot preview unavailable'});}
  });

  // Faster transport for one-time Copy Admin snapshot; the SAME original
  // ledgerSetCardHandler below still runs for every card, in the same order.
  // This removes browser HTTP + repaint waterfalls, not financial safeguards.
  app.post('/api/bot/ledger_copy_admin_snapshot_batch', (req, res) => {
    try {
      const pid = String(req.body?.profileId || '');
      const date = String(req.body?.date || '');
      const items = req.body?.cards;
      if (!pid || pid === 'admin1' || !validLoopDate(date) || !Array.isArray(items) ||
        items.length < 1 || items.length > 16) {
        return res.status(400).json({ status: 'error', message: 'VIP profile, date and 1–16 cards required' });
      }
      if (!hasProfileAccess(req, pid)) return rejectProfileAccess(res, pid);
      const state = readFullAppStateView();
      const vip = state?.profiles?.[pid];
      const admin = state?.profiles?.admin1;
      if (!vip || !admin) return res.status(404).json({ status: 'error', message: 'VIP/Admin profile missing' });
      const seen = new Set<string>();
      const prepared: Array<{ type: string; index: number; marketName: string; sourceEditedAt: number }> = [];
      for (const item of items) {
        const type = String(item?.type || '');
        const index = item?.index;
        const revision = item?.sourceEditedAt;
        if (!['ank', 'jodi', 'pannel'].includes(type) || !Number.isInteger(index) || index < 0 ||
          !Number.isSafeInteger(revision) || revision < 0 || seen.has(`${type}_${index}`)) {
          return res.status(400).json({ status: 'error', message: 'Invalid or duplicate snapshot card' });
        }
        seen.add(`${type}_${index}`);
        const vipMarkets = type === 'jodi' ? getEffectiveBaseMarkets(vip.config) : getEffectiveMarkets(vip.config);
        const market = vipMarkets[index];
        if (!market || String(item.marketName || '').trim().toUpperCase() !== String(market.n).trim().toUpperCase()) {
          return res.status(400).json({ status: 'error', message: 'VIP market name/index changed; refresh first' });
        }
        prepared.push({ type, index, marketName: String(market.n), sourceEditedAt: revision });
      }
      // Recovery replay of an eligible card can refresh suggestion fields on
      // other cards. Snapshot must preserve every settled/OFF record verbatim.
      const initialRuntime = date===String(botState.ledgerState?.date||'') ? botState.ledgerState?.profiles?.[pid] : undefined;
      const preserved: Array<{dict:string;key:string;runtimeKey:string;saved:any;live:any}> = [];
      for(const type of ['ank','jodi','pannel'] as const){
        const dict=type==='ank'?'data':type==='jodi'?'jodiData':'pannelData';
        const list=type==='jodi'?getEffectiveBaseMarkets(vip.config):getEffectiveMarkets(vip.config);
        list.forEach((market,index)=>{
          const key=String(index),runtimeKey=`${type}_${index}`,saved=vip.dayRecords?.[date]?.[dict]?.[key],live=initialRuntime?.cards?.[runtimeKey];
          const runtimeMarket=initialRuntime?.markets?.find((m:any)=>m.type===type&&Number(m.index)===index);
          if(!adminSnapshotMarketEnabled(vip,date,type,market.n)||runtimeMarket?.enabled===false||isAdminSnapshotProtected(saved)||isAdminSnapshotProtected(live)){
            preserved.push({dict,key,runtimeKey,saved:saved===undefined?undefined:structuredClone(saved),live:live===undefined?undefined:structuredClone(live)});
          }
        });
      }
      const results: Array<{ type: string; index: number; ok: boolean; skipped?: boolean; message?: string; card?: any }> = [];
      try {
      for (const item of prepared) {
        const dict = item.type === 'ank' ? 'data' : item.type === 'jodi' ? 'jodiData' : 'pannelData';
        const savedVip = readFullAppState()?.profiles?.[pid];
        const old = savedVip?.dayRecords?.[date]?.[dict]?.[item.index];
        if (old?.marketName && String(old.marketName).trim().toUpperCase() !== item.marketName.toUpperCase()) {
          results.push({ type: item.type, index: item.index, ok: false, skipped: true, message: 'VIP market identity changed' });
          continue;
        }
        if (!vipLiveMarketEligible(savedVip || vip, date, item.type as any, item.marketName)) {
          results.push({ type: item.type, index: item.index, ok: false, skipped: true, message: 'VIP live entry protection' });
          continue;
        }
        const liveVip = date === String(botState.ledgerState?.date || '') ? botState.ledgerState?.profiles?.[pid] : undefined;
        const liveCard = liveVip?.cards?.[`${item.type}_${item.index}`];
        const liveMarket = liveVip?.markets?.find((m:any)=>m.type===item.type && Number(m.index)===item.index);
        if ((liveCard?.marketName && String(liveCard.marketName).trim().toUpperCase()!==item.marketName.toUpperCase()) ||
            (liveMarket && String(liveMarket.n||'').trim().toUpperCase()!==item.marketName.toUpperCase())) {
          results.push({type:item.type,index:item.index,ok:false,skipped:true,message:'VIP live market identity changed'}); continue;
        }
        if (!savedVip || !adminSnapshotMarketEnabled(savedVip,date,item.type as any,item.marketName) || liveMarket?.enabled===false) {
          results.push({type:item.type,index:item.index,ok:false,skipped:true,message:'VIP market is OFF'}); continue;
        }
        if (isAdminSnapshotProtected(old) || isAdminSnapshotProtected(liveCard)) {
          results.push({type:item.type,index:item.index,ok:false,skipped:true,message:'VIP card is settled or protected'}); continue;
        }
        const normSnap = (v: unknown) => String(v || '').trim().replace(/\s+/g, ' ').toUpperCase().replace(/^(?:SHRIDEVI|SRIDEVI|SRIDEV) DAY\b/, 'SRIDEVI').replace(/^(?:SHRIDEVI|SRIDEV)\b/, 'SRIDEVI');
        const adminMarkets = item.type === 'jodi' ? getEffectiveBaseMarkets(admin.config) : getEffectiveMarkets(admin.config);
        const sourceIndex = adminMarkets.findIndex(m => normSnap(m.n) === normSnap(item.marketName));
        const adminStored = admin.dayRecords?.[date]?.[dict]?.[sourceIndex];
        const liveDate = String(botState.ledgerState?.date || calculateBusinessDateIST());
        const adminLive = date === liveDate ? botState.ledgerState?.profiles?.admin1?.cards?.[`${item.type}_${sourceIndex}`] : undefined;
        const source: any = (adminLive && Number(adminStored?.sourceEditedAt || 0) <= Number(adminLive?.sourceEditedAt || 0) && (String(adminLive.d || '').trim() || isEditableSourceSkip(adminLive as any)))
          ? adminLive
          : (adminStored || adminLive);
        if (!source || (!String(source.d || '').trim() && !isEditableSourceSkip(source)) ||
          (source.marketName && normSnap(source.marketName) !== normSnap(item.marketName))) {
          results.push({ type: item.type, index: item.index, ok: false, skipped: true, message: 'Admin source missing or name mismatch' });
          continue;
        }
        // The existing handler retains frozen-rate, result-reversal, recovery,
        // broadcast cancellation, schedule cleanup and full-state persistence.
        const command = Object.create(req) as express.Request;
        command.body = {
          profileId: pid, date, type: item.type, index: item.index,
          status: 'WAIT', clearCard: true, copyAdmin: true,
          marketName: item.marketName, sourceEditedAt: item.sourceEditedAt,
        };
        let code = 200; let payload: any;
        const capture = { status(value: number) { code = value; return this; }, json(value: any) { payload = value; return this; } };
        ledgerSetCardHandler(command, capture as unknown as express.Response, () => {});
        const ok = code === 200 && payload?.status === 'success' && Boolean(payload.card) && !payload.skipped;
        results.push({ type: item.type, index: item.index, ok, card: ok ? payload.card : undefined,
          skipped: Boolean(payload?.skipped), message: ok ? undefined : (payload?.message || payload?.reason || `HTTP ${code}`) });
      }
      } finally {
      const afterCopy=readFullAppState();
      const savedDay=afterCopy?.profiles?.[pid]?.dayRecords?.[date];
      let savedRestored=false,runtimeRestored=false;
      for(const keep of preserved){
        const dict=savedDay?.[keep.dict];
        if(dict && JSON.stringify(dict[keep.key])!==JSON.stringify(keep.saved)){
          if(keep.saved===undefined)delete dict[keep.key];else dict[keep.key]=keep.saved;
          savedRestored=true;
        }
        if(initialRuntime?.cards && JSON.stringify(initialRuntime.cards[keep.runtimeKey])!==JSON.stringify(keep.live)){
          if(keep.live===undefined)delete initialRuntime.cards[keep.runtimeKey];else initialRuntime.cards[keep.runtimeKey]=keep.live;
          runtimeRestored=true;
        }
      }
      if(runtimeRestored)persistLedgerSnapshot();
      if(savedRestored)writeFullAppState(afterCopy);
      }
      // A later card's recovery recalculation may update an earlier card.
      // Return the final server state, never a stale per-handler reference.
      const historical = date !== String(botState.ledgerState?.date || calculateBusinessDateIST());
      if (!historical && pid !== 'admin1') {
        finalizeProfileReadyRates(pid, 'admin-snapshot-batch');
        queueVipAutoReadyCards('admin-snapshot-batch');
      }
      const finalDicts = historical ? readFullAppStateView()?.profiles?.[pid]?.dayRecords?.[date] : null;
      const finalCards = botState.ledgerState?.profiles?.[pid]?.cards;
      for (const result of results) {
        if (!result.ok) continue;
        const field = result.type === 'ank' ? 'data' : result.type === 'jodi' ? 'jodiData' : 'pannelData';
        const latest = historical ? finalDicts?.[field]?.[result.index] : finalCards?.[`${result.type}_${result.index}`];
        if (latest) result.card = latest;
      }
      return res.json({ status: 'success', profileId: pid, date, results });
    } catch (error: any) {
      return res.status(500).json({ status: 'error', message: error?.message || 'Snapshot batch failed' });
    }
  });

  // One request for bulk Clear; reuse the exact financial reset command.
  app.post('/api/bot/ledger_clear_cards', (req, res) => {
    try {
      const pid=String(req.body?.profileId||'admin1'),date=String(req.body?.date||''),items=req.body?.cards;
      const cType = ['ank', 'jodi', 'pannel'].includes(String(req.body?.type || '')) ? String(req.body.type) : 'ank';
      const dictField = cType === 'ank' ? 'data' : cType === 'jodi' ? 'jodiData' : 'pannelData';
      if(!validLoopDate(date)||!Array.isArray(items)||!items.length||items.length>1000)return res.status(400).json({status:'error',message:'Valid date, card type and card list required'});
      if(!hasProfileAccess(req,pid))return rejectProfileAccess(res,pid);
      const state=readFullAppState(),profile=state?.profiles?.[pid];
      if(!profile)return res.status(404).json({status:'error',message:'Profile not found'});
      const receipt=bulkOperationReceipts.prepare(req.body,'clear');
      if(receipt&&bulkOperationReceipts.find(receipt.id))return res.json(bulkReceiptResult(receipt));
      const markets=cType==='jodi'?getEffectiveBaseMarkets(profile.config):getEffectiveMarkets(profile.config),seen=new Set<number>();
      for(const item of items){
        if(!item||!Number.isInteger(item.index)||item.index<0||!markets[item.index]||seen.has(item.index)||
          (item.sourceEditedAt!==undefined&&(!Number.isSafeInteger(item.sourceEditedAt)||item.sourceEditedAt<0)))return res.status(400).json({status:'error',message:'Invalid, duplicate or mismatched card index'});
        seen.add(item.index);
      }
      const results:any[]=[];
      const historical=date<businessDateIST()||date!==String(botState.ledgerState?.date||calculateBusinessDateIST());
      if(historical){
        const day=profile.dayRecords?.[date]||{},dictData={...(day[dictField]||{})};
        for(const item of items){
          dictData[item.index]=clearedLedgerCard(dictData[item.index],markets[item.index].n,Number(item.sourceEditedAt||0));
          results.push({index:item.index,ok:true});
        }
        const next=calculateBacktestRecovery({...profile,dayRecords:{...profile.dayRecords,[date]:{...day,[dictField]:dictData}}},date);
        bulkOperationReceipts.commit(receipt?{...receipt,indices:items.map((item:any)=>item.index),results}:undefined,
          ()=>writeFullAppState({...state,profiles:{...state.profiles,[pid]:next}}));
        return res.json({status:'success',operationId:receipt?.id,profileId:pid,date,type:cType,cards:Object.fromEntries(items.map((item:any)=>[item.index,next.dayRecords[date]?.[dictField]?.[item.index]])),results});
      }
      for(const item of items){
        const command=Object.create(req) as express.Request;
        (command as any).deferBulkClearSave=true;
        command.body={profileId:pid,date,type:cType,index:item.index,status:'WAIT',clearCard:true,sourceEditedAt:item.sourceEditedAt,marketName:markets[item.index].n};
        let code=200,payload:any;
        const capture={status(value:number){code=value;return this;},json(value:any){payload=value;return this;}};
        ledgerSetCardHandler(command,capture as unknown as express.Response,()=>{});
        results.push({index:item.index,ok:code===200&&payload?.status==='success'&&Boolean(payload.card),message:payload?.message});
      }
      // Perform all post-clear persistence & rate finalization ONCE for the entire batch!
      atomicWriteFileAsync(path.join(titanDataDir, 'active_schedules.json'), JSON.stringify(botState.activeSchedules), 'active-schedules');
      finalizeProfileReadyRates(pid, 'bulk-clear');
      persistPendingAudits();
      persistLedgerSnapshot();
      const full=readFullAppState();
      bulkOperationReceipts.commit(receipt?{...receipt,indices:results.filter(item=>item.ok).map(item=>item.index),results}:undefined,
        ()=>{if(full)writeFullAppState(mergeLedgerIntoFullAppState(full));});
      const final=botState.ledgerState?.profiles?.[pid]?.cards;
      const cards:Record<number,any>={};
      for(const item of results)if(item.ok)cards[item.index]=final?.[`${cType}_${item.index}`];
      return res.json({status:'success',operationId:receipt?.id,profileId:pid,date,type:cType,cards,results});
    }catch(error:any){return res.status(error?.statusCode||500).json({status:'error',message:error?.message||'Bulk Clear failed'});}
  });

  // Get Pending Unprocessed Results for Frontend Auto-Marking
  app.get("/api/bot/pending_audits", (_req, res) => {
    // Also try server process (in case ledger arrived after result)
    try { serverProcessPendingAudits(); } catch (_) {}
    // Expire only after 30 min (2 min was killing audits before UI could mark)
    const now = Date.now();
    botState.pendingAuditResults.forEach((p: any) => {
      if (p.processed) return;
      const ts = Number(String(p.id || '').slice(0, 13)) || 0;
      if (ts && now - ts > 30 * 60_000 && !Object.keys(p.deferredCards || {}).length) p.processed = true;
    });
    persistPendingAudits();
    const unproc = botState.pendingAuditResults.filter((p) => !p.processed).slice(0, 15);
    res.json({ status: "success", results: unproc });
  });

  // Acknowledge Audit Processed
  app.post("/api/bot/ack_audit", (req, res) => {
    const { id } = req.body;
    if (id) {
      const item = botState.pendingAuditResults.find((p: any) => p.id === id);
      if (item && Object.keys(item.deferredCards || {}).length > 0) return res.json({ status: 'success', deferred: true, reason: 'awaiting_delivery_ack' });
      // OPEN-only result is valid for the open card, but must stay queued until
      // the source publishes the full panna-jodi-panna declaration.
      if (item?.awaitingFull) {
        return res.json({ status: 'success', deferred: true, reason: 'awaiting_full_result' });
      }
      botState.pendingAuditResults = botState.pendingAuditResults.map((p) =>
        p.id === id ? { ...p, processed: true } : p
      );
      persistPendingAudits();
    }
    res.json({ status: "success" });
  });

  // Save Bot Config
  app.post("/api/bot/config", (req, res) => {
    const { autoSendEnabled, autoResultForwardEnabled, profitMilestoneNotificationsEnabled, loginMethod, loginPhone, targetGroups, resultReadGroups, customHeader, prefix, botPhone, pairingCode, forceRelogin } = req.body;
    const prevPhone = String(botState.loginPhone || '').replace(/[^0-9]/g, '');
    if (autoSendEnabled !== undefined) botState.autoSendEnabled = Boolean(autoSendEnabled);
    if (autoResultForwardEnabled !== undefined) botState.autoResultForwardEnabled = Boolean(autoResultForwardEnabled);
    if (profitMilestoneNotificationsEnabled !== undefined) {
      botState.profitMilestoneNotificationsEnabled = Boolean(profitMilestoneNotificationsEnabled);
      if (!botState.profitMilestoneNotificationsEnabled) cancelProfileProfitNotifications('admin1');
    }
    if (loginMethod !== undefined) botState.loginMethod = String(loginMethod);
    if (loginPhone !== undefined) {
      botState.loginPhone = String(loginPhone).replace(/[^0-9]/g, '');
    }
    // BUG FIX: Preserve valid Channel JIDs and reject malformed targets before they reach the bot.
    if (Array.isArray(targetGroups)) botState.targetGroups = normalizeTargetList(targetGroups);
    if (Array.isArray(resultReadGroups)) botState.resultReadGroups = normalizeIncomeSourceList(resultReadGroups);
    if (customHeader !== undefined) botState.customHeader = String(customHeader);
    if (prefix !== undefined) botState.prefix = String(prefix);
    if (botPhone !== undefined) botState.botPhone = String(botPhone);
    if (pairingCode !== undefined) botState.pairingCode = String(pairingCode);
    // BUG FIX: Admin Group/Channel destinations must survive a PM2/server restart.
    try { persistLoginConfig(); } catch (_) {}

    const newPhone = String(botState.loginPhone || '').replace(/[^0-9]/g, '');
    // ONLY explicit forceRelogin:true triggers session wipe.
    // (Do NOT auto-force on every config save that includes loginPhone — that caused auto-logout after successful pair.)
    if (forceRelogin === true) {
      botState.forceRelogin = true;
      botState.pairingCode = '';
      botState.qrCodeData = '';
      botState.botPhone = '';
      botState.status = 'offline';
      try {
        if (fs.existsSync(sessionBackupFile)) fs.unlinkSync(sessionBackupFile);
      } catch (_) {}
      botState.logs.unshift({
        id: Date.now().toString(),
        time: new Date().toLocaleTimeString(),
        msg: `📲 Force re-login for +${newPhone || 'new number'} — old session cleared`,
        type: 'warning',
      });
    } else if (loginPhone !== undefined && newPhone && prevPhone && newPhone !== prevPhone) {
      // Phone changed in config only — remember number, do NOT kill live session unless user hits Force Re-login
      botState.logs.unshift({
        id: Date.now().toString(),
        time: new Date().toLocaleTimeString(),
        msg: `📱 Login phone updated to +${newPhone} (session keeps running until Force Re-login)`,
        type: 'info',
      });
    }

    botState.logs.unshift({
      id: Date.now().toString(),
      time: new Date().toLocaleTimeString(),
      msg: `Bot config updated (phone: +${botState.loginPhone || '-'}, method: ${botState.loginMethod}, Auto Forward: ${botState.autoResultForwardEnabled ? 'ON' : 'OFF'}, Profit Alerts: ${botState.profitMilestoneNotificationsEnabled ? 'ON' : 'OFF'})`,
      type: 'info'
    });
    if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);

    res.json({ status: "success", config: botState });
  });

  // Explicit: pair with whatever loginPhone is set now
  app.post("/api/bot/force_relogin", (req, res) => {
    const requestedMethod = String(req.body?.loginMethod || botState.loginMethod || 'pairing').toLowerCase();
    const phone = req.body?.loginPhone != null
      ? String(req.body.loginPhone).replace(/[^0-9]/g, '')
      : botState.loginPhone;
    if (requestedMethod !== 'pairing' && requestedMethod !== 'qr') {
      return res.status(400).json({ status: 'error', message: 'loginMethod pairing ya qr hona chahiye' });
    }
    if (requestedMethod === 'pairing' && String(phone || '').length < 10) {
      return res.status(400).json({ status: 'error', message: 'Country code ke saath valid mobile number required' });
    }
    if (phone) botState.loginPhone = phone;
    botState.loginMethod = requestedMethod;
    try { persistLoginConfig(); } catch (_) {}
    botState.forceRelogin = true;
    botState.pairingCode = '';
    botState.qrCodeData = '';
    botState.botPhone = '';
    botState.status = 'pairing';
    if (liveTransports.whatsapp.sessionId) retireSessionBoundBroadcasts('whatsapp', '', 'WHATSAPP_RELOGIN_REQUESTED');
    liveTransports.whatsapp.online = false;
    try {
      if (fs.existsSync(sessionBackupFile)) fs.unlinkSync(sessionBackupFile);
    } catch (_) {}
    botState.logs.unshift({
      id: Date.now().toString(),
      time: new Date().toLocaleTimeString(),
      msg: `🔄 Force re-login requested for +${botState.loginPhone || 'unknown'}`,
      type: 'warning',
    });
    res.json({
      status: 'success',
      accepted: true,
      loginPhone: botState.loginPhone,
      loginMethod: botState.loginMethod,
      message: requestedMethod === 'pairing' ? 'Pairing code generation started' : 'QR generation started',
    });
  });

  // Heartbeat from Termux Baileys Bot
  app.post("/api/bot/heartbeat", (req, res) => {
    const { botPhone, status, pairingCode, qrCodeData, logMsg, logType, runtimeId, sessionStartedAt } = req.body;
    const now = Date.now();
    const runtimeSession = String(runtimeId || '').trim();
    const runtimeStartedAt = Number(sessionStartedAt || 0);
    if (isStaleWhatsAppHeartbeat(liveTransports.whatsapp, {status, runtimeId: runtimeSession, sessionStartedAt: runtimeStartedAt})) {
      // Network latency can deliver an old 'online' pulse after 'close', or
      // an old 'offline' event after a newer socket is already connected.
      return res.json({status: 'success', ignoredStale: true});
    }
    botState.lastHeartbeat = new Date(now).toISOString();
    botState.status = status || 'offline';
    if (botPhone) botState.botPhone = botPhone;
    if (botState.status === 'online' && runtimeSession && Number.isFinite(runtimeStartedAt) && runtimeStartedAt > 0) {
      const previousSession = liveTransports.whatsapp.sessionId;
      liveTransports.whatsapp = { online: true, sessionId: runtimeSession, startedAt: runtimeStartedAt, lastSeen: now };
      if (previousSession && previousSession !== runtimeSession) {
        retireSessionBoundBroadcasts('whatsapp', runtimeSession, 'WHATSAPP_SESSION_CHANGED');
      }
    } else {
      if (liveTransports.whatsapp.sessionId) {
        retireSessionBoundBroadcasts('whatsapp', '', 'WHATSAPP_WENT_OFFLINE');
      }
      liveTransports.whatsapp.online = false;
      liveTransports.whatsapp.lastSeen = now;
    }
    // V14.07: empty strings are meaningful here: they clear an expired code/QR.
    // Truthy-only assignment left stale pairing codes visible after reconnects.
    if (Object.prototype.hasOwnProperty.call(req.body, 'pairingCode')) {
      botState.pairingCode = String(pairingCode || '');
    }
    if (Object.prototype.hasOwnProperty.call(req.body, 'qrCodeData')) {
      botState.qrCodeData = String(qrCodeData || '');
    }

    if (logMsg) {
      const safeLogType = ['success', 'info', 'warning', 'danger'].includes(String(logType || ''))
        ? String(logType)
        : 'info';
      botState.logs.unshift({
        id: Date.now().toString(),
        time: new Date().toLocaleTimeString(),
        msg: String(logMsg),
        type: safeLogType
      });
      if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
    }

    res.json({
      status: "success",
      autoSendEnabled: botState.autoSendEnabled,
      targetGroups: botState.targetGroups,
      resultReadGroups: botState.resultReadGroups,
      pendingChannelInvites: botState.pendingChannelInvites,
      customHeader: botState.customHeader,
      prefix: botState.prefix,
      loginMethod: botState.loginMethod,
      loginPhone: botState.loginPhone,
      logoutRequested: botState.logoutRequested,
      forceRelogin: botState.forceRelogin,
      deletedProfileIds: botState.deletedProfileIds,
    });
  });

  app.post("/api/bot/force_relogin_ack", (_req, res) => {
    botState.forceRelogin = false;
    res.json({ status: 'success' });
  });

  // Logout Endpoints
  app.post("/api/bot/logout", (_req, res) => {
    botState.logoutRequested = true;
    if (liveTransports.whatsapp.sessionId) retireSessionBoundBroadcasts('whatsapp', '', 'WHATSAPP_LOGOUT_REQUESTED');
    liveTransports.whatsapp.online = false;
    
    if (fs.existsSync(sessionBackupFile)) {
      try { fs.unlinkSync(sessionBackupFile); } catch (e) {}
    }

    botState.logs.unshift({
      id: Date.now().toString(),
      time: new Date().toLocaleTimeString(),
      msg: 'Logout requested by user. Waiting for bot to disconnect...',
      type: 'info'
    });
    
    res.json({ status: "success" });
  });

  app.post("/api/bot/logout_ack", (_req, res) => {
    botState.logoutRequested = false;
    botState.botPhone = '';
    botState.status = 'offline';
    botState.pairingCode = '';
    liveTransports.whatsapp.online = false;
    res.json({ status: "success" });
  });

  // Report Executed Schedule / Log from Bot
  app.post("/api/bot/mark_sent", (req, res) => {
    const {
      scheduleKey,
      cardGeneration: bodyCardGeneration,
      details,
      profileId: bodyProfileId,
      type: bodyType,
      index: bodyIndex,
      digits: bodyDigits,
      sourceMode: bodySourceMode,
      scrapeSource: bodyScrapeSource,
      trick: bodyTrick,
      rateNum: bodyRateNum,
      investTotal: bodyInvestTotal,
      schTime: bodySchTime,
      schTargets: suppliedSchTargets,
    } = req.body || {};
    let bodySchTargets = suppliedSchTargets;
    if (scheduleKey) {
      const scheduled = botState.activeSchedules.find((x: any) => x.key === scheduleKey);
      const queued = botState.pendingBroadcasts.find((x: any) => x.scheduleKey === scheduleKey && x.broadcastKind === 'vip-auto-card');
      const expected = queued?.targets || (scheduled ? resolveAdminScheduleTargets(scheduled.schTargets) : bodySchTargets || []);
      if (expected.some(isTelegramTarget) && !recordDelivery(`schedule:${scheduleKey}`, transportTargets(bodySchTargets || [], requestPlatform(req)), expected)) {
        return res.json({ status: 'success', partial: true });
      }
      if (expected.some(isTelegramTarget)) bodySchTargets = expected;
      botState.sentSchedules[scheduleKey] = true;
      delete botState.scheduleClaims[scheduleKey];
      try { persistSentSchedules(); } catch (_) {}

      // Freeze the exact rate/invest that went out on WhatsApp onto the ledger card.
      // PASS/FAIL reply must use these values — never a later UI rate change.
      try {
        const item = (botState.activeSchedules || []).find(
          (x: any) => String(x?.key || '') === String(scheduleKey)
        ) || {
          // The bot sends these frozen values with mark_sent. Use them as a
          // durable fallback when a schedule was refreshed or claimed between
          // delivery and acknowledgement.
          cardGeneration: bodyCardGeneration,
          profileId: bodyProfileId || 'admin1',
          type: bodyType || '',
          index: Number.isFinite(Number(bodyIndex)) ? Number(bodyIndex) : -1,
          digits: bodyDigits,
          sourceMode: bodySourceMode,
          scrapeSource: bodyScrapeSource,
          trick: bodyTrick,
          rateNum: Number(bodyRateNum),
          investTotal: Number(bodyInvestTotal),
          schTime: bodySchTime,
          schTargets: Array.isArray(bodySchTargets) ? bodySchTargets : [],
        };
        if (item && botState.ledgerState?.profiles) {
          const pid = String(item.profileId || 'admin1');
          if (isDeletedProfile(pid)) {
            botState.logs.unshift({ id: Date.now().toString(), time: new Date().toLocaleTimeString(), msg: `🛑 Ignored stale mark_sent for deleted ${pid}`, type: 'warning' });
            if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
            return res.status(410).json({ status: 'error', message: 'VIP profile was deleted' });
          }
          const type = String(item.type || '');
          const idx =
            typeof item.index === 'number'
              ? item.index
              : (() => {
                  // key: pid_YYYY-MM-DD_type_idx_HH:mm
                  const parts = String(scheduleKey).split('_');
                  const maybeIdx = parseInt(parts[parts.length - 2], 10);
                  return Number.isFinite(maybeIdx) ? maybeIdx : -1;
                })();
          if (type && idx >= 0) {
            if (!botState.ledgerState.profiles[pid]) {
              botState.ledgerState.profiles[pid] = {
                name: pid,
                phone: '',
                markets: [],
                cards: {},
              };
            }
            const cards = botState.ledgerState.profiles[pid].cards || {};
            const ck = `${type}_${idx}`;
            const prev = cards[ck] || { s: 'WAIT', d: '', r: '' };
            if (Number(prev.cardGeneration || 0) !== Number(item.cardGeneration || 0)) return res.json({ status: 'success', ignored: true, reason: 'stale-card-generation' });
            if (prev.deliveryRestoredAt) return res.json({ status: 'success', ignored: true, reason: 'card-restored' });
            const suppliedRateNum = Number(bodyRateNum);
            const liveCardRateNum = parseFloat(String(prev.r || prev.recRate || '0')) || 0;
            const rateNum =
              Number.isFinite(suppliedRateNum) && suppliedRateNum > 0
                ? suppliedRateNum
                : liveCardRateNum > 0
                  ? liveCardRateNum
                  : typeof item.rateNum === 'number' && item.rateNum > 0
                    ? item.rateNum
                    : parseFloat(String((item as any).invest || '0')) || 0;
            const digits = String(bodyDigits || prev.d || item.digits || '').trim();
            const count = digits ? digits.split(/[, ]+/).filter((x: string) => x.trim()).length : 0;
            const investTotal =
              prev?.smartStaking?.isSmartStaking && Number(prev.smartStaking.totalInvest) > 0
                ? Number(prev.smartStaking.totalInvest)
                : typeof item.investTotal === 'number' && item.investTotal > 0
                  ? item.investTotal
                  : count * rateNum;
            cards[ck] = {
              ...prev,
              ...(prev.vipAutoStopSkipped ? { s: 'WAIT', vipAutoStopSkipped: undefined } : {}),
              d: digits || prev.d,
              r: rateNum > 0 ? String(rateNum) : prev.r,
              sentRate: rateNum > 0 ? String(rateNum) : prev.sentRate,
              sentInvest: investTotal > 0 ? investTotal : prev.sentInvest,
              sentDigits: digits || prev.sentDigits,
              sentSourceMode: (item as any).sourceMode || prev.sentSourceMode || prev.sourceMode,
              sentScrapeSource: normalizeScrapeSource((item as any).scrapeSource) || getScrapeSource(prev),
              sentLoopId: prev.loopId || prev.sentLoopId,
              sentTrick: (item as any).trick || prev.sentTrick || prev.trick,
              sentTargets: normalizeTargetList(expected),
              dispatchState: 'SENT',
              dispatchKey: String(scheduleKey),
              sentAt: Date.now(),
              deliveryMissedAt: undefined,
              deliveryMissedReason: undefined,
              deliveryPartial: undefined,
              schTime: item.schTime || prev.schTime,
              schTargets:
                Array.isArray(item.schTargets) && item.schTargets.length
                  ? item.schTargets
                  : prev.schTargets,
            };
            botState.ledgerState.profiles[pid].cards = cards;
            botState.ledgerState.updatedAt = Date.now();
            persistLedgerSnapshot();
            try {
              const full = readFullAppState();
              if (full) writeFullAppState(mergeLedgerIntoFullAppState(full));
            } catch (_) {}
          }
        }
      } catch (_) {}
      // A sent WAIT card intentionally blocks the next VIP card until result settlement.
      queueVipAutoReadyCards('mark-sent');
    }
    botState.logs.unshift({
      id: Date.now().toString(),
      time: new Date().toLocaleTimeString(),
      msg: details || `Dispatched auto-schedule for key: ${scheduleKey}`,
      type: 'success'
    });
    if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);

    res.json({ status: "success" });
  });

  // Bot saves WhatsApp message key after schedule send (for later quote-reply)
  app.post("/api/bot/save_schedule_msg", (req, res) => {
    const { scheduleKey, jid, messageKey } = req.body || {};
    if (scheduleKey && jid && messageKey) {
      const jNorm = normalizeTargetJid(jid) || '';
      // Store under both exact + normalized so lookup always hits
      const variants = Array.from(new Set([String(jid).trim(), jNorm].filter(Boolean)));
      variants.forEach((j) => {
        botState.scheduleMsgKeys[`${scheduleKey}||${j}`] = messageKey;
      });
      // Cap map size
      const keys = Object.keys(botState.scheduleMsgKeys);
      if (keys.length > 300) {
        keys.slice(0, keys.length - 200).forEach((old) => delete botState.scheduleMsgKeys[old]);
      }
    }
    res.json({ status: 'success' });
  });

  app.get("/api/bot/schedule_msg_key", (req, res) => {
    const scheduleKey = String(req.query.scheduleKey || '');
    const jid = String(req.query.jid || '');
    const jNorm = normalizeTargetJid(jid) || '';
    const tryKeys = [
      `${scheduleKey}||${jid}`,
      `${scheduleKey}||${jNorm}`,
    ];
    let messageKey = null as any;
    for (const k of tryKeys) {
      if (botState.scheduleMsgKeys[k]) {
        messageKey = botState.scheduleMsgKeys[k];
        break;
      }
    }
    // Fuzzy: any key starting with scheduleKey|| that ends with same group id
    if (!messageKey && scheduleKey) {
      const groupId = jNorm.split('@')[0] || jid.split('@')[0];
      for (const [k, v] of Object.entries(botState.scheduleMsgKeys)) {
        if (k.startsWith(`${scheduleKey}||`) && groupId && k.includes(groupId)) {
          messageKey = v;
          break;
        }
      }
    }
    res.json({
      status: 'success',
      messageKey: messageKey || null,
    });
  });

  // WhatsApp gateway reports actual per-target send outcomes here.
  // This is telemetry only: it never changes delivery/ledger state.
  app.post("/api/bot/delivery_log", (req, res) => {
    const deliveryStatus = String(req.body?.status || '').toLowerCase();
    const targetJid = normalizeTargetJid(req.body?.targetJid);
    if (!targetJid || targetJid.startsWith('tg:') || !['success', 'failed'].includes(deliveryStatus)) {
      return res.status(400).json({ status: 'error', message: 'Invalid WhatsApp delivery log' });
    }

    const targetKind = targetJid.endsWith('@g.us')
      ? 'group'
      : targetJid.endsWith('@newsletter')
        ? 'channel'
        : 'private';
    const known = targetKind === 'group'
      ? botState.syncedGroups.find((x) => normalizeTargetJid(x?.jid, 'group') === targetJid)
      : targetKind === 'channel'
        ? botState.syncedChannels.find((x) => normalizeTargetJid(x?.jid, 'channel') === targetJid)
        : botState.syncedContacts.find((x) => normalizeTargetJid(x?.jid, 'phone') === targetJid);
    const targetName = String(known?.name || (known as any)?.phone || targetJid).slice(0, 100);
    const sourceKind = String(req.body?.sourceKind || '').slice(0, 60);
    const sourceLabel = String(req.body?.sourceLabel || '').slice(0, 100);
    const error = String(req.body?.error || '').replace(/\s+/g, ' ').trim().slice(0, 220);
    const icon = deliveryStatus === 'success' ? '✅' : '❌';
    const suffix = deliveryStatus === 'failed' && error ? `: ${error}` : '';
    const entry = {
      id: `${Date.now()}-${botState.logs.length}`,
      time: new Date().toLocaleTimeString(),
      msg: `${icon} ${deliveryStatus === 'success' ? 'Sent' : 'Failed'} → ${targetName}${suffix}`,
      type: deliveryStatus === 'success' ? 'success' : 'danger',
      event: 'whatsapp-delivery',
      deliveryStatus,
      targetJid,
      targetKind,
      targetName,
      sourceKind,
      sourceLabel,
    };
    botState.logs.unshift(entry as any);
    if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
    res.json({ status: 'success' });
  });

  // Remove only a saved WhatsApp outbound Group/Channel target.
  // Income sources and VIP profile destinations are intentionally untouched.
  app.post("/api/bot/remove_target", (req, res) => {
    const target = normalizeTargetJid(req.body?.targetJid);
    const removable = Boolean(target && (target.endsWith('@g.us') || target.endsWith('@newsletter')));
    if (!target || target.startsWith('tg:') || !removable) {
      return res.status(400).json({ status: 'error', message: 'Only WhatsApp Group/Channel Sending Targets can be removed here' });
    }
    const before = normalizeTargetList(botState.targetGroups);
    const next = before.filter((jid) => jid !== target);
    const removed = next.length !== before.length;
    botState.targetGroups = next;
    if (removed) {
      try { persistLoginConfig(); } catch (_) {}
      botState.logs.unshift({
        id: `${Date.now()}-${botState.logs.length}`,
        time: new Date().toLocaleTimeString(),
        msg: `🗑️ Removed from Sending Targets → ${target}`,
        type: 'warning',
      });
      if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
    }
    res.json({ status: 'success', removed, targetGroups: botState.targetGroups });
  });

  // Get Bot Execution Logs
  app.get("/api/bot/logs", (_req, res) => {
    res.json({ status: "success", logs: botState.logs, sentSchedules: botState.sentSchedules });
  });

  // --- SPAM PROCTOR & GROUP PROTECTION SYSTEM CONFIG & ENDPOINTS ---
  let spamConfig = {
    enabled: true,
    antiLink: true,
    antiFlood: true,
    antiMediaFlood: true,
    maxWarnings: 1, // 1 = 1st warning, 2nd kick
    messageLimit: 5,
    timeFrameMs: 5000,
    groupProtectionMode: 'selected_only' as 'all' | 'selected_only' | 'all_groups',
    protectedGroups: [] as string[],
    whitelistedGroups: [] as string[],
    whitelistedUsers: [] as string[],
  };

  let spamIncidents: Array<{
    id: string;
    timestamp: string;
    chatId: string;
    chatName: string;
    sender: string;
    senderPhone: string;
    reason: 'Link Detected' | 'Message Flood' | 'Media Burst';
    action: 'Warning Issued' | 'User Kicked' | 'Message Deleted';
    messageText: string;
    warningCount: number;
  }> = [];

  // Server-side maps are for dashboard display only.
  // Real enforcement runs inside titan-bot.js (WhatsApp process).
  const warningMap = new Map<string, number>();
  const userMsgTracker = new Map<string, number[]>();

  app.get("/api/spam/config", (_req, res) => {
    res.json({
      status: "success",
      config: spamConfig,
      activeWarningsCount: warningMap.size,
      botPhone: botState.botPhone,
      botStatus: botState.status
    });
  });

  app.post("/api/spam/config", (req, res) => {
    try {
      const updated = req.body;
      if (updated && typeof updated === 'object') {
        spamConfig = { ...spamConfig, ...updated };
        // Normalize mode aliases
        if (spamConfig.groupProtectionMode === 'all_groups') {
          (spamConfig as any).groupProtectionMode = 'all';
        }
      }
      botState.logs.unshift({
        id: Date.now().toString(),
        time: new Date().toLocaleTimeString(),
        msg: `Spam config updated (enabled=${spamConfig.enabled}, mode=${spamConfig.groupProtectionMode}, protected=${(spamConfig.protectedGroups || []).length})`,
        type: 'info'
      });
      if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
      res.json({ status: "success", config: spamConfig });
    } catch (err: any) {
      res.status(500).json({ status: "error", message: err.message });
    }
  });

  app.get("/api/spam/incidents", (_req, res) => {
    res.json({ status: "success", incidents: spamIncidents });
  });

  // Bot reports a spam action here so dashboard stays in sync
  app.post("/api/spam/incident", (req, res) => {
    try {
      const body = req.body || {};
      const incident = {
        id: String(body.id || Date.now()),
        timestamp: body.timestamp || new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' }),
        chatId: String(body.chatId || ''),
        chatName: String(body.chatName || body.chatId || ''),
        sender: String(body.sender || ''),
        senderPhone: String(body.senderPhone || ''),
        reason: (body.reason || 'Link Detected') as any,
        action: (body.action || 'Message Deleted') as any,
        messageText: String(body.messageText || '').slice(0, 120),
        warningCount: Number(body.warningCount) || 0,
      };
      spamIncidents.unshift(incident);
      if (spamIncidents.length > 100) spamIncidents = spamIncidents.slice(0, 100);

      if (body.senderPhone && body.chatId && typeof body.warningCount === 'number') {
        const key = `${body.chatId}_${body.senderPhone}`;
        if (body.action === 'User Kicked') warningMap.delete(key);
        else warningMap.set(key, body.warningCount);
      }

      botState.logs.unshift({
        id: Date.now().toString(),
        time: new Date().toLocaleTimeString(),
        msg: `🛡️ Spam: ${incident.action} — ${incident.reason} from +${incident.senderPhone}`,
        type: incident.action === 'User Kicked' ? 'danger' : 'warning'
      });
      if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);

      res.json({ status: 'success', incident });
    } catch (err: any) {
      res.status(500).json({ status: 'error', message: err?.message || 'Failed' });
    }
  });

  app.post("/api/spam/reset_warnings", (_req, res) => {
    warningMap.clear();
    userMsgTracker.clear();
    // Bump token so live bot clears its in-memory warning maps on next config fetch
    (spamConfig as any).warningsResetAt = Date.now();
    res.json({ status: "success", message: "All user warning counts cleared!" });
  });

  app.post("/api/spam/clear_logs", (_req, res) => {
    spamIncidents = [];
    res.json({ status: "success", message: "Spam incident logs cleared." });
  });

  // Backup & Persistent WhatsApp Auth Session
  const sessionBackupFile = path.join(titanDataDir, "titan_session_backup.json");
  const loginConfigFile = path.join(titanDataDir, "titan_login_config.json");

  // Restore last saved login phone/method so overwrite sticks across restarts
  try {
    if (fs.existsSync(loginConfigFile)) {
      const lc = JSON.parse(fs.readFileSync(loginConfigFile, "utf-8"));
      if (lc.loginPhone) botState.loginPhone = String(lc.loginPhone).replace(/[^0-9]/g, "");
      if (lc.loginMethod) botState.loginMethod = String(lc.loginMethod);
      if (Array.isArray(lc.targetGroups)) botState.targetGroups = normalizeTargetList(lc.targetGroups);
      if (Array.isArray(lc.resultReadGroups)) botState.resultReadGroups = normalizeIncomeSourceList(lc.resultReadGroups);
      if (typeof lc.autoSendEnabled === 'boolean') botState.autoSendEnabled = lc.autoSendEnabled;
      if (typeof lc.autoResultForwardEnabled === 'boolean') botState.autoResultForwardEnabled = lc.autoResultForwardEnabled;
      if (typeof lc.profitMilestoneNotificationsEnabled === 'boolean') {
        botState.profitMilestoneNotificationsEnabled = lc.profitMilestoneNotificationsEnabled;
      }
      if (typeof lc.customHeader === 'string') botState.customHeader = lc.customHeader;
      if (typeof lc.prefix === 'string') botState.prefix = lc.prefix;
    }
  } catch (_) {}

  // Freeze the legacy global setting once for existing VIPs before separating controls.
  const legacyProfitState = readFullAppState();
  if (legacyProfitState?.profiles) {
    let migrated = false;
    for (const [pid, profile] of Object.entries(legacyProfitState.profiles) as Array<[string, any]>) {
      if (pid === 'admin1' || typeof profile.profitMilestoneNotificationsEnabled === 'boolean') continue;
      profile.profitMilestoneNotificationsEnabled = botState.profitMilestoneNotificationsEnabled === true;
      migrated = true;
    }
    if (migrated) writeFullAppState(legacyProfitState);
  }

  function persistLoginConfig() {
    atomicWriteFile(loginConfigFile, JSON.stringify({
      loginPhone: botState.loginPhone,
      loginMethod: botState.loginMethod,
      targetGroups: normalizeTargetList(botState.targetGroups),
      resultReadGroups: normalizeIncomeSourceList(botState.resultReadGroups),
      autoSendEnabled: Boolean(botState.autoSendEnabled),
      autoResultForwardEnabled: Boolean(botState.autoResultForwardEnabled),
      profitMilestoneNotificationsEnabled: botState.profitMilestoneNotificationsEnabled === true,
      customHeader: String(botState.customHeader || ''),
      prefix: String(botState.prefix || '.'),
    }), 'login-config');
  }

  const normalizeWhatsAppAuthFiles = (input: unknown): Record<string, string> => {
    if (!input || typeof input !== 'object' || Array.isArray(input)) {
      throw new Error('Invalid WhatsApp auth snapshot');
    }
    const files: Record<string, string> = {};
    let totalBytes = 0;
    for (const [name, contents] of Object.entries(input as Record<string, unknown>)) {
      const cleanName = String(name || '');
      if (!cleanName || cleanName !== path.basename(cleanName) || cleanName.includes('..') || !cleanName.endsWith('.json')) {
        throw new Error(`Invalid WhatsApp auth filename: ${cleanName || '(empty)'}`);
      }
      if (typeof contents !== 'string') throw new Error(`Invalid WhatsApp auth contents: ${cleanName}`);
      totalBytes += Buffer.byteLength(contents, 'utf8');
      if (totalBytes > 8 * 1024 * 1024) throw new Error('WhatsApp auth snapshot exceeds 8 MB safety limit');
      JSON.parse(contents);
      files[cleanName] = contents;
    }
    const rawCreds = files['creds.json'];
    if (!rawCreds) throw new Error('WhatsApp auth snapshot is missing creds.json');
    const parsedCreds = JSON.parse(rawCreds);
    if (parsedCreds?.registered !== true) throw new Error('Ignoring unregistered WhatsApp pairing state');
    return files;
  };

  app.post("/api/bot/save_session", (req, res) => {
    const { creds, authFiles } = req.body || {};
    try {
      if (authFiles) {
        // V14.10: Baileys useMultiFileAuthState is a multi-file crypto store.
        // Back up the whole registered snapshot, not only creds.json, otherwise
        // a lost local auth directory cannot be faithfully restored.
        const files = normalizeWhatsAppAuthFiles(authFiles);
        atomicWriteFile(sessionBackupFile, JSON.stringify({
          version: 2,
          savedAt: new Date().toISOString(),
          files,
        }), 'session-backup', true);
        return res.json({ status: "success", message: "Complete WhatsApp auth session backed up to disk!" });
      }

      if (creds) {
        // Legacy V14.09 client compatibility. Keep accepting registered creds-only
        // backups during rolling updates; the next V14.10 bot heartbeat upgrades it.
        const parsed = JSON.parse(String(creds));
        if (parsed?.registered !== true) {
          return res.status(409).json({ status: "error", message: "Ignoring unregistered WhatsApp pairing state" });
        }
        atomicWriteFile(sessionBackupFile, String(creds), 'session-backup', true);
        return res.json({ status: "success", message: "Legacy WhatsApp credentials backed up to disk!" });
      }
      return res.status(400).json({ status: "error", message: "No credentials provided" });
    } catch (err: any) {
      const message = err?.message || "Failed to save session";
      const status = /unregistered/i.test(message) ? 409 : /invalid|missing|exceeds/i.test(message) ? 400 : 500;
      return res.status(status).json({ status: "error", message });
    }
  });

  app.get("/api/bot/get_session", (_req, res) => {
    try {
      if (fs.existsSync(sessionBackupFile)) {
        const raw = fs.readFileSync(sessionBackupFile, "utf-8");
        let parsed: any;
        try {
          parsed = JSON.parse(raw);
        } catch (_) {
          return res.status(500).json({ status: "error", message: "Saved WhatsApp session backup is corrupted" });
        }
        if (parsed?.version === 2) {
          try {
            const files = normalizeWhatsAppAuthFiles(parsed?.files);
            return res.json({ status: "success", version: 2, authFiles: files });
          } catch (err: any) {
            return res.status(500).json({ status: "error", message: err?.message || "Saved WhatsApp auth snapshot is invalid" });
          }
        }
        return res.json({ status: "success", creds: raw });
      }
    } catch (e) {}
    res.json({ status: "none", message: "No saved session found" });
  });

  // Clear dead / logged-out session so bot can show fresh QR / pairing code
  app.post("/api/bot/clear_session", (_req, res) => {
    try {
      if (fs.existsSync(sessionBackupFile)) {
        fs.unlinkSync(sessionBackupFile);
      }
      botState.botPhone = '';
      botState.status = 'offline';
      botState.pairingCode = '';
      botState.qrCodeData = '';
      botState.logs.unshift({
        id: Date.now().toString(),
        time: new Date().toLocaleTimeString(),
        msg: '🗑️ WhatsApp session backup cleared — ready for fresh QR / pairing login',
        type: 'warning',
      });
      if (botState.logs.length > 50) botState.logs = botState.logs.slice(0, 50);
      return res.json({ status: 'success', message: 'Session backup cleared' });
    } catch (e: any) {
      return res.status(500).json({ status: 'error', message: e?.message || 'clear failed' });
    }
  });

  // Serve the maintained bot implementation instead of a second stale scheduler.
  // The old embedded template diverged from titan-bot.js and could reintroduce
  // target normalization, retry, and duplicate-delivery bugs when downloaded.
  app.get("/api/bot/script", (req, res) => {
    const host = req.headers.host || 'localhost:3000';
    const protocol = req.headers['x-forwarded-proto'] || 'http';
    const serverUrl = `${protocol}://${host}`;

    try {
      const maintainedBotPath = path.join(titanAppRoot, 'titan-bot.js');
      let maintainedSource = fs.readFileSync(maintainedBotPath, 'utf-8');
      // Keep the downloadable standalone bot self-contained as before.
      const controlSource = fs.readFileSync(path.join(titanAppRoot, 'wa-send-control.js'), 'utf8').replace(/^export /gm, '');
      maintainedSource = maintainedSource.replace("import { createSendControl, retryDelay, startIndependentHeartbeat } from './wa-send-control.js';", controlSource);
      const sessionPolicySource=fs.readFileSync(path.join(titanAppRoot,'wa-session-policy.js'),'utf8').replace(/^export /gm,'');
      maintainedSource=maintainedSource.replace("import {whatsappSessionPhone,sameWhatsAppPhone} from './wa-session-policy.js';",sessionPolicySource);
      const linkSource=fs.readFileSync(path.join(titanAppRoot,'scripts/broadcast-link.mjs'),'utf8').replace(/^export /gm,'');
      const pngSource=fs.readFileSync(path.join(titanAppRoot,'scripts/broadcast-png.mjs'),'utf8').replace(/^export /gm,'');
      const cardContentSource=fs.readFileSync(path.join(titanAppRoot,'scripts/card-send-content.mjs'),'utf8')
        .replace(/^export /gm,'').replace(/^import .* from '\.\/(?:broadcast-link|broadcast-png)\.mjs';\r?\n/gm,'');
      maintainedSource=maintainedSource.replace("import {scheduledCardContent} from './scripts/card-send-content.mjs';",linkSource+'\n'+pngSource+'\n'+cardContentSource);
      const drainSource=fs.readFileSync(path.join(titanAppRoot,'scripts/drain-live-broadcasts.mjs'),'utf8').replace(/^export /gm,'');
      maintainedSource=maintainedSource.replace("import {drainLiveBroadcasts} from './scripts/drain-live-broadcasts.mjs';",drainSource);
      const safeServerUrl = serverUrl.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      maintainedSource = maintainedSource.replace(
        "const SERVER_URL = process.env.TITAN_SERVER || 'http://127.0.0.1:3000';",
        `const SERVER_URL = process.env.TITAN_SERVER || '${safeServerUrl}';`,
      );
      res.setHeader('Content-Type', 'text/javascript');
      return res.send(maintainedSource);
    } catch (error: any) {
      // Fail closed. Serving the obsolete inline scheduler below would restore
      // duplicate delivery, stale target normalization and old session logic.
      return res.status(500).json({
        status: 'error',
        message: `Maintained titan-bot.js unavailable: ${error?.message || 'file missing'}`,
      });
    }

  });

  // Calculate & Return Auto Schedules Endpoint for Bot
  // Helper: convert HH:mm to minutes since business-day start (6:00 AM)
  // Hours < 6 are treated as next calendar day (+24h) so 00:05 works correctly.
  const normalizeScheduleTime = (value: unknown): string => {
    const match = String(value || '').trim().match(/^(\d{1,2}):(\d{2})$/);
    if (!match) return '';
    const hour = Number(match[1]);
    const minute = Number(match[2]);
    if (!Number.isInteger(hour) || !Number.isInteger(minute) || hour < 0 || hour > 23 || minute < 0 || minute > 59) {
      return '';
    }
    return `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
  };
  const timeToBusinessMinutes = (timeStr: string): number => {
    const clean = normalizeScheduleTime(timeStr);
    if (!clean) return -1;
    const [hour, minute] = clean.split(':').map(Number);
    let minutes = hour * 60 + minute;
    if (minutes < 6 * 60) minutes += 24 * 60; // 00:00-05:59 → next day
    return minutes;
  };
  /** Resolve destinations for admin-ledger schedules only. */
  const isDummyScheduleTarget = (target: unknown): boolean => {
    const value = String(target || '').trim();
    return !value || value.includes('1203630123456789') || value === '__USE_GLOBAL_TARGETS__';
  };
  const resolveAdminScheduleTargets = (cardTargets?: unknown): string[] => {
    const explicit = Array.isArray(cardTargets)
      ? cardTargets.map((t) => String(t || '').trim()).filter((t) => !isDummyScheduleTarget(t))
      : [];
    if (explicit.length > 0) return [...new Set(explicit)];

    const configured = (botState.targetGroups || [])
      .map((t) => String(t || '').trim())
      .filter((t) => !isDummyScheduleTarget(t));
    if (configured.length > 0) return [...new Set(configured)];

    // No explicit or global selection means no recipients. Discovery is not consent.
    return [];
  };

  /** Admin must wait for the previous delivered card in this recovery track. */
  const serverHasEarlierInFlightCard = (profileId: string, cardType: string, index: number, marketName: string): boolean => {
    const pid = profileId || 'admin1';
    const prof: any = botState.ledgerState?.profiles?.[pid];
    if (!prof?.cards || !Array.isArray(prof.markets) || !Number.isFinite(index)) return false;
    const trackKey = serverRecoveryTrackKey(prof, cardType, marketName);
    return prof.markets.some((market: any) => {
      if (String(market?.type || '') !== cardType || market?.enabled === false) return false;
      const earlierIndex = Number(market?.index);
      if (!Number.isFinite(earlierIndex) || earlierIndex >= index) return false;
      if (serverRecoveryTrackKey(prof, cardType, String(market?.n || '')) !== trackKey) return false;
      const earlier = prof.cards[`${cardType}_${earlierIndex}`];
      if (!earlier || (earlier.s && earlier.s !== 'WAIT')) return false;
      if (cardType === 'jodi' && (earlier.jodiOpenStatus === 'PASS' || earlier.jodiOpenStatus === 'FAIL')) return false;
      return Boolean(earlier.sentRate || earlier.sentDigits || earlier.dispatchState === 'SENT');
    });
  };

  // Race-safe delivery guard. The bot checks this immediately before sending.
  // If the dashboard toggled a type OFF after the schedule was fetched, delivery is refused.
  app.get("/api/bot/schedule_guard", (req, res) => {
    const key = String(req.query.key || '');
    if (!key) return res.json({ status: 'success', allowed: false, reason: 'missing-key' });
    const item = Array.isArray(botState.activeSchedules)
      ? botState.activeSchedules.find((x: any) => String(x?.key || '') === key)
      : null;
    if (!item) return res.json({ status: 'success', allowed: false, reason: 'schedule-removed' });
    const profileId = String(item.profileId || '');
    const cardType = String(item.type || '');
    const recoveryBlocked = (profileId || 'admin1') === 'admin1' && serverHasEarlierInFlightCard(
      profileId || 'admin1', cardType, Number(item.index), String(item.marketName || ''),
    );
    const openPassCloseHold = isCloseBlockedByOpenPassZero(
      profileId || 'admin1', cardType, String(item.marketName || ''),
    );
    const policyAllowed = isCardTypeEnabled(profileId, cardType);
    const dateAllowed = !item.date || item.date === calculateBusinessDateIST();
    const rec: any = dateAllowed ? botState.ledgerState?.profiles?.[profileId || 'admin1']?.cards?.[`${cardType}_${item.index}`] : null;
    const terminal = ['PASS', 'FAIL', 'SKIP'].includes(rec?.s);
    const alreadySent = Boolean(botState.sentSchedules[key]);
    const knownType = ['ank','jodi','pannel'].includes(cardType);
    // An existing card owns readiness, including an intentionally empty selection.
    // A stale schedule is a fallback only when there is no live ledger card.
    const digits = rec ? rec.sentDigits || rec.d : item.digits;
    const rate = rec ? Number(rec.sentRate || rec.r || rec.recRate || 0) : Number(item.rateNum || item.invest || 0);
    const validCard = !knownType || (areSettlementTokensValid(cardType,digits) && isRecoveryRatePossible(cardType,digits) && rate > 0);
    const canonicalDigits = (value: unknown) => String(value ?? '').split(/[,|\s]+/).filter(Boolean).join(',');
    const stalePayload = knownType && ((req.query.digits !== undefined && canonicalDigits(req.query.digits) !== canonicalDigits(digits)) ||
      (req.query.rate !== undefined && Number(req.query.rate) !== rate) ||
      (req.query.cardGeneration !== undefined && Number(req.query.cardGeneration) !== Number(rec?.cardGeneration || 0)));
    const runAllowed = !knownType || !dateAllowed || enforceVipGameRun(profileId || 'admin1', cardType, countSettlementTokens(String(digits || ''), cardType as any) * rate, `${cardType}_${item.index}`);
    const nowTime=new Date().toLocaleTimeString('en-GB',{timeZone:'Asia/Kolkata',hour:'2-digit',minute:'2-digit',hour12:false});
    const windowAllowed=scheduleWindowAllowed(normalizeScheduleTime(item.schTime),nowTime,SCHEDULE_GRACE_MINUTES,Boolean(item.recoveryWaitSince));
    const reason = !botState.autoSendEnabled ? 'auto-send-off' : !dateAllowed ? 'wrong-business-date'
      : !windowAllowed ? 'outside-schedule-window'
      : Number(rec?.cardGeneration || 0) !== Number(item.cardGeneration || 0) ? 'stale-card-generation'
      : rec?.deliveryRestoredAt ? 'card-restored' : !runAllowed ? 'vip-game-stopped'
      : !policyAllowed ? 'policy-off' : terminal ? 'card-settled' : alreadySent ? 'already-sent'
      : !validCard ? 'card-not-ready' : stalePayload ? 'stale-card-payload' : (recoveryBlocked || openPassCloseHold) ? 'waiting-prior-result' : 'enabled';
    if(reason==='enabled'&&knownType&&rec&&!deliveredLoopCard(rec)){
      const saved=readFullAppStateView()?.profiles?.[profileId||'admin1'];
      if(resolveLoopAccountConfig(saved,botState.ledgerState.profiles[profileId||'admin1'],calculateBusinessDateIST())){
        rec.loopAccountReservation={key,invest:countSettlementTokens(digits,cardType)*rate,expiresAt:Date.now()+300000};persistLedgerSnapshot();
      }
    }
    res.json({ status: 'success', allowed: reason === 'enabled', reason });
  });


  // Debug: why admin/VIP schedules fire or not
  /** Restore missing current-day Admin slots from saved data without browser sync. */
  function restoreSavedAdminSchedules() {
    const date = calculateBusinessDateIST();
    const fullState = readFullAppStateView();
    const saved = fullState?.profiles?.admin1;
    if (!saved?.config) return;
    // Archive the previous live date before loading today's saved records.
    // Browser focus must not be the event that advances the server ledger.
    if (botState.ledgerState?.date && botState.ledgerState.date !== date) {
      const archived = mergeLedgerIntoFullAppState(readFullAppState() || fullState);
      writeFullAppState(archived);
      const profiles = savedDailyLedgerProfiles(archived.profiles, date);
      for (const pid of Object.keys(profiles)) if (isDeletedProfile(pid)) delete profiles[pid];
      botState.ledgerState = { date, updatedAt: Date.now(), profiles };
      botState.activeSchedules = botState.activeSchedules.filter(item => !item.date || item.date === date);
      // Live jobs from previous dates must never survive rollover.
      botState.pendingBroadcasts = botState.pendingBroadcasts.filter((item: any) => {
        const key = String(item.scheduleKey || '');
        const keyDate = key.match(/\d{4}-\d{2}-\d{2}/)?.[0];
        return !keyDate || keyDate === date;
      });
      finalizeAllReadyRates('server-schedule-day-rollover');
      persistLedgerSnapshot();
      persistPendingBroadcasts();
      atomicWriteFileAsync(path.join(titanDataDir,'active_schedules.json'), JSON.stringify(botState.activeSchedules), 'active-schedules');
    }
    if (!botState.ledgerState || !botState.ledgerState.date) {
      botState.ledgerState = { date, updatedAt: Date.now(), profiles: {} };
    }
    const runtime: any = botState.ledgerState.profiles?.admin1;
    if (!runtime) {
      const restored = savedDailyLedgerProfiles(fullState.profiles, date);
      for (const pid of Object.keys(restored)) if (isDeletedProfile(pid)) delete restored[pid];
      botState.ledgerState.profiles = { ...restored, ...(botState.ledgerState.profiles || {}) };
      finalizeAllReadyRates('saved-schedule-restore');
      persistLedgerSnapshot();
    }
    const day = saved?.dayRecords?.[date];
    if (!day) return;
    const cfg = saved.config;
    const groups = [
      { type: 'ank', dict: 'data', visibility: 'visAnk', markets: getEffectiveMarkets(cfg) },
      { type: 'jodi', dict: 'jodiData', visibility: 'visJodi', markets: getEffectiveBaseMarkets(cfg) },
      { type: 'pannel', dict: 'pannelData', visibility: 'visPan', markets: getEffectiveMarkets(cfg) },
    ];
    const profile: any = botState.ledgerState.profiles.admin1;
    const expectedMarkets=groups.flatMap(group=>group.markets.map((m,index)=>({...m,type:group.type,index})));
    if((profile.markets||[]).some((m:any)=>Number(m.index)>=0 && !expectedMarkets.some(expected=>expected.type===m.type && Number(expected.index)===Number(m.index) && expected.n===m.n)))return;
    let restoredCards = false;
    groups.forEach(group => group.markets.forEach((market, index) => {
      const rec = day[group.dict]?.[index];
      const key = `${group.type}_${index}`;
      if (!rec || profile.cards?.[key]) return;
      profile.cards = { ...(profile.cards || {}), [key]: { ...rec, marketName: market.n } };
      if (!(profile.markets || []).some((item: any) => item.type === group.type && Number(item.index) === index)) {
        profile.markets = [...(profile.markets || []), { ...market, type: group.type, index, enabled: isMarketEnabledForDate(cfg, day[group.visibility], market.n) }];
      }
      restoredCards = true;
    }));
    if (restoredCards) {
      finalizeProfileReadyRates('admin1', 'saved-schedule-restore');
      persistLedgerSnapshot();
    }
    let changed = false;
    groups.forEach(group => group.markets.forEach((market, index) => {
      if (cfg.scheduleTypeEnabled?.[group.type] === false || !isMarketEnabledForDate(cfg, day[group.visibility], market.n)) return;
      const rec = profile.cards?.[`${group.type}_${index}`] || day[group.dict]?.[index];
      if (!rec || rec.s !== 'WAIT' || rec.sentDigits || rec.sentRate) return;
      const schTime = normalizeScheduleTime(day[group.dict]?.[index]?.schTime ?? cfg.marketScheduleTimes?.[`${group.type}_${index}`] ?? cfg.marketScheduleTimes?.[market.n] ?? '');
      if (!schTime) return;
      const digits = String(rec.d || '').trim();
      const rate = Number(rec.r || rec.recRate || 0);
      if (!areSettlementTokensValid(group.type, digits) || !isRecoveryRatePossible(group.type, digits) || rate <= 0) return;
      const key = `admin1_${date}_${group.type}_${index}_${schTime}${rec.cardGeneration ? `_g${rec.cardGeneration}` : ''}`;
      if (isCloseBlockedByOpenPassZero('admin1', group.type, market.n, profile)) return;
      if (botState.sentSchedules[key] || botState.activeSchedules.some(item => item.key === key)) return;
      const targets = day[group.dict]?.[index]?.schTargets ?? cfg.marketScheduleTargets?.[`${group.type}_${index}`] ?? cfg.marketScheduleTargets?.[market.n] ?? [];
      botState.activeSchedules.push({
        key, cardGeneration: rec.cardGeneration, profileId: 'admin1', date, type: group.type, index, marketName: market.n, schTime,
        schTargets: targets.length ? targets : ['__USE_GLOBAL_TARGETS__'],
        digits, sourceMode: rec.sourceMode, scrapeSource: rec.scrapeSource, trick: rec.trick,
        invest: String(rate), rateNum: rate, investTotal: countSettlementTokens(digits, group.type) * rate,
        message: serverBuildVipCardMsg(market.n, group.type, rec, cfg.detailedMessage !== false, date),
      });
      changed = true;
    }));
    if (changed) atomicWriteFileAsync(path.join(titanDataDir,'active_schedules.json'), JSON.stringify(botState.activeSchedules), 'active-schedules');
  }

  app.get("/api/bot/schedule_debug", (_req, res) => {
    restoreSavedAdminSchedules();
    const nowIST = new Date().toLocaleTimeString('en-GB', {
      timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hour12: false,
    });
    const nowMinutes = timeToBusinessMinutes(nowIST);
    const currentBusinessDate = calculateBusinessDateIST();
    const rows = (botState.activeSchedules || []).map((item: any) => {
      const cleanSchTime = normalizeScheduleTime(item.schTime);
      const schMinutes = timeToBusinessMinutes(cleanSchTime);
      const sameBusinessDate = !item.date || String(item.date) === currentBusinessDate;
      const key = String(item.key || '');
      const profileId = String(item.profileId || '');
      const cardType = String(item.type || '');
      const isTimeHit = Boolean(
        cleanSchTime &&
        schMinutes >= 0 &&
        nowMinutes >= schMinutes &&
        nowMinutes <= schMinutes + SCHEDULE_GRACE_MINUTES
      );
      const isAlreadySent = !!(key && botState.sentSchedules[key]);
      const policyEnabled = isCardTypeEnabled(profileId, cardType);
      const recoveryBlocked = (profileId || 'admin1') === 'admin1' && serverHasEarlierInFlightCard(
        profileId || 'admin1', cardType, Number(item.index), String(item.marketName || ''),
      );
      const openPassCloseHold = isCloseBlockedByOpenPassZero(
        profileId || 'admin1', cardType, String(item.marketName || ''),
      );
      const shouldSend = policyEnabled && !recoveryBlocked && !openPassCloseHold && sameBusinessDate && isTimeHit && !isAlreadySent;
      let schTargets = Array.isArray(item.schTargets) ? [...item.schTargets] : [];
      if (profileId === 'admin1' || !profileId) {
        schTargets = resolveAdminScheduleTargets(schTargets);
      }
      return {
        key,
        profileId,
        marketName: item.marketName,
        type: cardType,
        schTime: cleanSchTime,
        sameBusinessDate,
        shouldSend,
        isTimeHit,
        isAlreadySent,
        policyEnabled,
        recoveryBlocked,
        targets: schTargets,
        targetCount: schTargets.length,
        digitsLen: String(item.digits || '').length,
        hasMessage: Boolean(item.message && String(item.message).trim()),
      };
    });
    res.json({
      status: 'success',
      nowIST,
      currentBusinessDate,
      ledgerDate: botState.ledgerState?.date || null,
      hasCurrentDaySavedData: Boolean(readFullAppStateView()?.profiles?.admin1?.dayRecords?.[currentBusinessDate]),
      graceMinutes: SCHEDULE_GRACE_MINUTES,
      globalTargetGroups: botState.targetGroups || [],
      autoSendEnabled: botState.autoSendEnabled,
      total: rows.length,
      adminDue: rows.filter((r) => (r.profileId === 'admin1' || !r.profileId) && r.shouldSend),
      vipDue: rows.filter((r) => r.profileId && r.profileId !== 'admin1' && r.shouldSend),
      adminBlocked: rows.filter((r) => (r.profileId === 'admin1' || !r.profileId) && !r.shouldSend),
      rows,
    });
  });

  app.get("/api/bot/schedule", (req, res) => {
    restoreSavedAdminSchedules();
    // Current IST time (Asia/Kolkata) in HH:mm 24-hour format
    const nowIST = new Date().toLocaleTimeString('en-GB', {
      timeZone: 'Asia/Kolkata',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });

    const nowMinutes = timeToBusinessMinutes(nowIST);
    const currentBusinessDate = calculateBusinessDateIST();

    /** True if this exact schedule slot was already fired (exact key only — no fuzzy cross-profile match). */
    const wasSent = (item: any): boolean => {
      const key = String(item.key || '');
      // Exact key only — never prefix-match (was able to cross-mark related keys)
      return !!(key && botState.sentSchedules[key]);
    };

    const schedulesToReturn = botState.activeSchedules.map((storedItem) => {
      // Last-moment SSOT reconciliation: schedule rows can be older than the
      // recovery ledger when a result and a schedule sync cross in flight.
      // Build the outgoing card from the current backend card, not a stale
      // active_schedules.json payload.
      let item: any = storedItem;
      let calculationBlocked = false;
      const livePid = String(storedItem?.profileId || 'admin1');
      const liveType = String(storedItem?.type || '');
      const liveIdx = Number(storedItem?.index);
      const liveRec: any = Number.isFinite(liveIdx) && (!storedItem.date || storedItem.date === botState.ledgerState?.date)
        ? botState.ledgerState?.profiles?.[livePid]?.cards?.[`${liveType}_${liveIdx}`]
        : null;
      if (liveRec && ['PASS', 'FAIL', 'SKIP'].includes(liveRec.s)) calculationBlocked = true;
      if (liveRec && !liveRec.sentRate && liveRec.s !== 'PASS' && liveRec.s !== 'FAIL') {
        const liveDigits = String(liveRec.d ?? storedItem.digits ?? '').trim();
        const liveRate = parseFloat(String(liveRec.r || liveRec.recRate || '0')) || 0;
        const validLiveCard = areSettlementTokensValid(liveType as any, liveDigits) &&
          isRecoveryRatePossible(liveType as any, liveDigits) && liveRate > 0;
        if (!validLiveCard) calculationBlocked = true;
        const liveCount = validLiveCard ? countSettlementTokens(liveDigits, liveType as any) : 0;
        const liveProfile: any = botState.ledgerState?.profiles?.[livePid];
        item = {
          ...storedItem,
          digits: liveDigits,
          rateNum: validLiveCard ? liveRate : 0,
          invest: validLiveCard ? String(liveRate) : '0',
          investTotal: validLiveCard ? liveCount * liveRate : 0,
          message: validLiveCard ? serverBuildVipCardMsg(
            String(storedItem.marketName || 'CARD'),
            liveType,
            { ...liveRec, d: liveDigits, r: String(liveRate) },
            liveProfile?.detailedMessage !== false,
            String(storedItem.date || currentBusinessDate),
          ) : '',
        };
      }
      const cleanSchTime = normalizeScheduleTime(item.schTime);
      const schMinutes = timeToBusinessMinutes(cleanSchTime);
      const sameBusinessDate = !item.date || String(item.date) === currentBusinessDate;
      // Only within grace window after schTime — never dump all past slots on dashboard open
      const isTimeHit = Boolean(
        cleanSchTime &&
        schMinutes >= 0 &&
        nowMinutes >= schMinutes &&
        nowMinutes <= schMinutes + SCHEDULE_GRACE_MINUTES
      );
      const isAlreadySent = wasSent(item);
      const profileId = String(item.profileId || '');
      const cardType = String(item.type || '');
      const policyEnabled = isCardTypeEnabled(profileId, cardType);
      const profileStillExists =
        !profileId || profileId === 'admin1' ||
        botState.activeProfileIds.length === 0 ||
        botState.activeProfileIds.includes(profileId);
      // claimFresh no longer blocks shouldSend — it caused admin ledger slots to
      // stay false while VIP (different key) still fired. Delivery safety = mark_sent + inFlight.
      const recoveryBlocked = (profileId || 'admin1') === 'admin1' && serverHasEarlierInFlightCard(
        profileId || 'admin1', cardType, liveIdx, String(item.marketName || ''),
      );
      const openPassCloseHold = isCloseBlockedByOpenPassZero(
        profileId || 'admin1', cardType, String(item.marketName || ''),
      );
      if (
        (recoveryBlocked || openPassCloseHold) && !storedItem.recoveryWaitSince && cleanSchTime && schMinutes >= 0 &&
        nowMinutes >= schMinutes && nowMinutes <= schMinutes + 60
      ) {
        storedItem.recoveryWaitSince = Date.now();
        atomicWriteFileAsync(path.join(titanDataDir, 'active_schedules.json'), JSON.stringify(botState.activeSchedules || []), 'active-schedules');
      }
      const recoveryReleaseWindow = Boolean(
        storedItem.recoveryWaitSince && nowMinutes >= schMinutes && nowMinutes <= schMinutes + 60
      );
      const budgetRuntime=botState.ledgerState?.profiles?.[livePid];
      const accountConfig=resolveLoopAccountConfig(readFullAppStateView()?.profiles?.[livePid],budgetRuntime,currentBusinessDate);
      const accountAllowed=!accountConfig||evaluateLoopAccounts(accountConfig,budgetRuntime,currentBusinessDate,budgetRuntime?.loopAccountStops,{liveOnly:true,nextKey:`${cardType}_${liveIdx}`,nextInvest:countSettlementTokens(item.digits,cardType)*Number(item.rateNum||item.invest||0),excludeKey:`${cardType}_${liveIdx}`}).allowed;
      const shouldSend = profileStillExists && policyEnabled && !recoveryBlocked && !openPassCloseHold && accountAllowed && sameBusinessDate &&
        (isTimeHit || recoveryReleaseWindow) && !isAlreadySent && !calculationBlocked;

      // Admin slots: explicit card target → configured group → synced group.
      // VIP slots keep their immutable private target from the incoming schedule.
      let schTargets = Array.isArray(item.schTargets) ? [...item.schTargets] : [];
      const pid = profileId || 'admin1';
      if (pid === 'admin1' || !pid) {
        schTargets = resolveAdminScheduleTargets(schTargets);
      }

      return {
        ...item,
        key: item.key,
        schTimeClean: cleanSchTime,
        schTargets,
        shouldSend,
        calculationBlocked,
        isAlreadySent,
        sameBusinessDate,
        profileStillExists,
        policyEnabled,
        recoveryBlocked,
        recoveryReleaseWindow
      };
    });

    const senderState=readFullAppStateView();
    let senderLocked=false;
    for(const item of schedulesToReturn){
      const original=botState.activeSchedules.find(job=>job.key===item.key) as any;
      if(item.shouldSend&&original&&!original.senderFormat){Object.assign(original,cardPresentation(item,senderState));Object.assign(item,cardPresentation(original,senderState));senderLocked=true;}
    }
    if(senderLocked)atomicWriteFileAsync(path.join(titanDataDir,'active_schedules.json'),JSON.stringify(botState.activeSchedules),'active-schedules');
    res.json({
      status: "success",
      currentTimeIST: nowIST,
      schedules: schedulesToReturn.map(item => {
        const presentation=cardPresentation(item,senderState);
        return {...item,...presentation,senderFormat:cardSenderFormatForDelivery(presentation,requestPlatform(req)),
          schTargets:remainingTargets(`schedule:${item.key}`,item.schTargets,requestPlatform(req))};
      }).filter(item => item.schTargets.length > 0)
    });
  });

  installTelegramGateway(app, {
    dataDir: titanDataDir, port: PORT,
    sources: () => botState.resultReadGroups,
    monitoring: () => botState.autoResultForwardEnabled,
    autoSend: () => botState.autoSendEnabled,
    canSwitchAccount: () => !botState.resultReadGroups.some(isTelegramTarget) &&
      !botState.targetGroups.some(isTelegramTarget) &&
      !botState.pendingBroadcasts.some(b => b.status === 'pending' && b.targets.some(isTelegramTarget)) &&
      !Object.values(readFullAppStateView()?.profiles || {}).some((p: any) =>
        [p.phone, p.vipSchTarget, p.vipGroupJid, p.vipChannelJid].some(isTelegramTarget) ||
        Object.values(p.config?.marketScheduleTargets || {}).some((ts: any) => Array.isArray(ts) && ts.some(isTelegramTarget))),
    selection: (field, values) => {
      botState[field] = [...botState[field].filter(t => !isTelegramTarget(t)), ...values];
      persistLoginConfig();
    },
    runtimeState: (state) => {
      const previousSession = liveTransports.telegram.sessionId;
      if (!state.online && previousSession) {
        retireSessionBoundBroadcasts('telegram', '', 'TELEGRAM_WENT_OFFLINE');
      }
      liveTransports.telegram = {
        online: Boolean(state.online),
        sessionId: String(state.sessionId || ''),
        startedAt: Number(state.startedAt || 0),
        lastSeen: Date.now(),
      };
      if (state.online && previousSession && previousSession !== state.sessionId) {
        retireSessionBoundBroadcasts('telegram', String(state.sessionId || ''), 'TELEGRAM_SESSION_CHANGED');
      }
    },
  });

  const flushPendingDatabaseWritesSync = () => {
    try {
      if (pendingAppStateDiskJson !== null) {
        atomicWriteFile(fullAppStateFile, pendingAppStateDiskJson, 'app-state-shutdown');
        pendingAppStateDiskJson = null;
      }
      if (pendingLedgerDiskJson !== null) {
        atomicWriteFile(ledgerSnapshotFile, pendingLedgerDiskJson, 'ledger-snapshot-shutdown');
        pendingLedgerDiskJson = null;
      }
      for (const [target, entry] of asyncDiskQueues.entries()) {
        if (entry.pending !== null) {
          atomicWriteFile(target, entry.pending, 'async-queue-shutdown');
          entry.pending = null;
        }
      }
    } catch (_) {}
  };
  process.once('SIGINT', () => { flushPendingDatabaseWritesSync(); process.exit(0); });
  process.once('SIGTERM', () => { flushPendingDatabaseWritesSync(); process.exit(0); });

  startAppListeners(app, PORT, positiveIntEnv('TITAN_LOCAL_PORT', 5000, 65_535));

  // Vite middleware for development (awaited per-request after listener is bound so startup health checks never time out)
  if (process.env.NODE_ENV !== "production") {
    const vitePromise = createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(async (req, res, next) => {
      try {
        const vite = await vitePromise;
        vite.middlewares(req, res, next);
      } catch (err) {
        next(err);
      }
    });
  } else {
    const distPath = path.join(titanAppRoot, "dist");
    app.use(express.static(distPath, {setHeaders: (res, file) => {
      if (file.endsWith('.html')) {
        res.setHeader('Cache-Control', 'no-store');
      } else if (/[\/]assets[\/].+[-.][a-zA-Z0-9_-]{8,}\.(?:js|css|woff2?|png|jpe?g|webp|svg)$/.test(file)) {
        // Vite fingerprints asset filenames; reuse unchanged bundles across visits.
        res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      }
    }}));
    // Missing old build assets must return 404, never the SPA HTML as JavaScript.
    app.use('/assets', (_req, res) => { res.setHeader('Cache-Control', 'no-store'); res.sendStatus(404); });
    app.get("*", (_req, res) => {
      res.setHeader('Cache-Control', 'no-store');
      res.sendFile(path.join(distPath, "index.html"));
    });
  }
}

startServer();
