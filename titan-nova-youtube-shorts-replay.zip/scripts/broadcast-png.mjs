/** Only inline PNG, never arbitrary paths/URLs. Used by both real transports. */
export function decodeBroadcastPng(value){
 if(typeof value!=='string'||value.length>5600000||!/^data:image\/png;base64,[A-Za-z0-9+/]+={0,2}$/.test(value))throw new Error('Invalid broadcast PNG');
 const png=Buffer.from(value.slice(22),'base64');
 if(png.length<33||png.subarray(0,8).toString('hex')!=='89504e470d0a1a0a'||png.toString('ascii',12,16)!=='IHDR')throw new Error('Invalid broadcast PNG');
 const width=png.readUInt32BE(16),height=png.readUInt32BE(20);
 if(width!==1080||height<1||height>8000||png.length>4*1024*1024)throw new Error('Broadcast PNG exceeds image limits');
 return png;
}
