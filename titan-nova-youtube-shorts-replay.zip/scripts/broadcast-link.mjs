/** Caption-safe web link; never fetched by the app or gateway. */
export function normalizeBroadcastLink(value){
 if(value===undefined||value===null||value==='')return '';
 if(typeof value!=='string')throw new Error('Link URL must be a valid http:// or https:// link');
 const link=value.trim();if(!link)return '';
 if(!/^https?:\/\//i.test(link))throw new Error('Link URL must start with http:// or https://');
 if(link.length>1000||/[\s\u0000-\u001f\u007f]/u.test(link))throw new Error('Link URL must be at most 1000 characters with no spaces');
 let url;try{url=new URL(link);}catch{throw new Error('Link URL must start with http:// or https://');}
 if(!['http:','https:'].includes(url.protocol)||!url.hostname||url.username||url.password)throw new Error('Link URL must be a valid http:// or https:// link');
 return link;
}
