/** One claim at a time. Re-check server priority after each handled/ACKed job.
 * Bounded local work removes poll-only idle gaps without changing send pacing.
 */
export async function* drainLiveBroadcasts({next,beforeNext=async()=>{},canContinue=()=>true,now=Date.now,budgetMs=5000,maxClaims=8}){
 const deadline=now()+budgetMs;
 for(let count=0;count<maxClaims&&canContinue()&&now()<deadline;count++){
  if(count){await beforeNext();if(!canContinue()||now()>=deadline)return;}
  const data=await next();
  if(data?.status!=='success'||!Array.isArray(data.broadcasts)||!data.broadcasts.length)return;
  // A returned claim must be handled even when its request exhausted the budget.
  for(const job of data.broadcasts)yield job;
 }
}
