import {normalizeBroadcastLink} from './broadcast-link.mjs';
import {decodeBroadcastPng} from './broadcast-png.mjs';
/** Local renderer failure must never silently downgrade a chosen PNG delivery to text. */
export async function scheduledCardContent(item,serverUrl,fetcher){
  if(item.broadcastKind==='vip-live-push'&&item.senderFormat==='png'){const caption=normalizeBroadcastLink(item.broadcastLink);return {image:decodeBroadcastPng(item.broadcastPng),mimetype:'image/png',...(caption?{caption}:{})};}
  if(item.senderFormat!=='png')return {text:item.message};
  const response=await fetcher(`${serverUrl}/api/bot/card_png`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(item)});
  if(!response.ok)throw new Error(`Card PNG failed (${response.status})`);
  const image=Buffer.from(await response.arrayBuffer());
  if(image.length<24||image.subarray(0,8).toString('hex')!=='89504e470d0a1a0a')throw new Error('Invalid card PNG response');
  return {image,mimetype:'image/png'};
}
