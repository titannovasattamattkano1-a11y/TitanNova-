const fs = require('fs');
const path = require('path');

// Titan Nova V14.09 compatibility patch for @whiskeysockets/baileys 7.0.0-rc14.
// Upstream pairing fixes referenced here are not present in rc14 as published:
// - #2749: pre-login notification ACK must tolerate creds.me being undefined.
// - #2559/#2560: requestPairingCode must await the companion_hello IQ response;
//   otherwise Baileys can return a plausible code after WhatsApp already rejected it.
// - #2608/#2600: empty/partial link_code_companion_reg notifications must be ignored
//   instead of throwing Invalid buffer during pairing.

const root = path.join(process.cwd(), 'node_modules', '@whiskeysockets', 'baileys', 'lib', 'Socket');
const socketFile = path.join(root, 'socket.js');
const recvFile = path.join(root, 'messages-recv.js');

function mustRead(file) {
  if (!fs.existsSync(file)) {
    throw new Error(`[Titan V14.09] Required Baileys runtime file missing: ${file}`);
  }
  return fs.readFileSync(file, 'utf8');
}

function patchPreloginAck(src) {
  const oldNeedle = 'buildAckStanza(node, errorCode, authState.creds.me.id)';
  const newNeedle = 'buildAckStanza(node, errorCode, authState.creds.me?.id)';
  if (src.includes(newNeedle)) return { src, state: 'already' };
  if (!src.includes(oldNeedle)) throw new Error('[Titan V14.09] ACK patch target not found');
  return { src: src.replace(oldNeedle, newNeedle), state: 'patched' };
}

function patchEmptyLinkCodeNotification(src) {
  const marker = "const linkCodeCompanionReg = getBinaryNodeChild(node, 'link_code_companion_reg')";
  const guardMarker = 'Titan V14.09: ignore incomplete link_code_companion_reg';
  if (src.includes(guardMarker)) return { src, state: 'already' };
  const idx = src.indexOf(marker);
  if (idx < 0) throw new Error('[Titan V14.09] link_code_companion_reg patch target not found');
  const insertAt = idx + marker.length;
  const guard = `\n                // Titan V14.09: ignore incomplete link_code_companion_reg (upstream #2608).\n                if (!getBinaryNodeChildBuffer(linkCodeCompanionReg, 'link_code_pairing_ref') ||\n                    !getBinaryNodeChildBuffer(linkCodeCompanionReg, 'primary_identity_pub') ||\n                    !getBinaryNodeChildBuffer(linkCodeCompanionReg, 'link_code_pairing_wrapped_primary_ephemeral_pub')) {\n                    logger.debug({ id: node.attrs.id, type: node.attrs.type }, 'incomplete link_code_companion_reg notification, skipping');\n                    break;\n                }`;
  return { src: src.slice(0, insertAt) + guard + src.slice(insertAt), state: 'patched' };
}

function patchPairingCodeServerAck(src) {
  const start = src.indexOf('const requestPairingCode = async');
  const end = src.indexOf('async function generatePairingKey', start);
  if (start < 0 || end < 0 || end <= start) {
    throw new Error('[Titan V14.09] requestPairingCode block not found');
  }

  let block = src.slice(start, end);
  const alreadyPatched = block.includes('const pairingJid = jidEncode(phoneNumber') && block.includes('await query({');
  if (alreadyPatched) return { src, state: 'already' };

  const earlyIdentity = /authState\.creds\.me\s*=\s*\{\s*id:\s*jidEncode\(phoneNumber,\s*['"]s\.whatsapp\.net['"]\),\s*name:\s*['"]~['"]\s*\}\s*;?\s*ev\.emit\(['"]creds\.update['"],\s*authState\.creds\)\s*;?/m;
  if (!earlyIdentity.test(block)) {
    throw new Error('[Titan V14.09] requestPairingCode early identity pattern not found');
  }
  block = block.replace(earlyIdentity, "const pairingJid = jidEncode(phoneNumber, 's.whatsapp.net')");

  const sendNeedle = 'await sendNode({';
  if (!block.includes(sendNeedle)) {
    throw new Error('[Titan V14.09] requestPairingCode sendNode pattern not found');
  }
  block = block.replace(sendNeedle, 'await query({');

  // query() auto-generates the IQ id, but retaining an existing id is also valid.
  // Remove it to mirror upstream #2559 and make the response correlation explicit.
  block = block.replace(/\n\s*id:\s*generateMessageTag\(\),?/, '');

  if (!block.includes('jid: authState.creds.me.id')) {
    throw new Error('[Titan V14.09] requestPairingCode JID pattern not found');
  }
  block = block.replace('jid: authState.creds.me.id', 'jid: pairingJid');

  const returnNeedle = 'return authState.creds.pairingCode';
  if (!block.includes(returnNeedle)) {
    throw new Error('[Titan V14.09] requestPairingCode return pattern not found');
  }
  block = block.replace(
    returnNeedle,
    "authState.creds.me = { id: pairingJid, name: '~' }\n        ev.emit('creds.update', authState.creds)\n        " + returnNeedle
  );

  return { src: src.slice(0, start) + block + src.slice(end), state: 'patched' };
}

function patchAtomicAuthWrites(src) {
  const marker='Titan atomic auth-file write';
  if(src.includes(marker))return {src,state:'already'};
  const old="await writeFile(filePath, JSON.stringify(data, BufferJSON.replacer));";
  if(!src.includes(old)||!src.includes("unlink, writeFile } from 'fs/promises'"))throw new Error('[Titan] Atomic auth patch target not found');
  src=src.replace("unlink, writeFile } from 'fs/promises'","unlink, writeFile, rename } from 'fs/promises'");
  src=src.replace('const fileLocks = new Map();','let titanAuthWriteSequence = 0;\nconst fileLocks = new Map();');
  src=src.replace(old,`// ${marker}: keep the last complete JSON if Termux/PM2 interrupts a write.
                const tempPath = filePath + '.' + process.pid + '.' + (++titanAuthWriteSequence) + '.tmp';
                try {
                    await writeFile(tempPath, JSON.stringify(data, BufferJSON.replacer), { mode: 0o600 });
                    await rename(tempPath, filePath);
                } finally {
                    await unlink(tempPath).catch(() => {});
                }`);
  return {src,state:'patched'};
}

try {
  let socketSrc = mustRead(socketFile);
  let recvSrc = mustRead(recvFile);
  const authFile=path.join(root,'..','Utils','use-multi-file-auth-state.js');
  const authResult=patchAtomicAuthWrites(mustRead(authFile));

  const pairResult = patchPairingCodeServerAck(socketSrc);
  socketSrc = pairResult.src;

  const ackResult = patchPreloginAck(recvSrc);
  recvSrc = ackResult.src;
  const emptyResult = patchEmptyLinkCodeNotification(recvSrc);
  recvSrc = emptyResult.src;

  fs.writeFileSync(socketFile, socketSrc, 'utf8');
  fs.writeFileSync(recvFile, recvSrc, 'utf8');
  fs.writeFileSync(authFile,authResult.src,'utf8');

  // Fail install rather than deploy a silently-unpatched pairing runtime.
  const verifySocket = fs.readFileSync(socketFile, 'utf8');
  const verifyRecv = fs.readFileSync(recvFile, 'utf8');
  const pairingBlock = verifySocket.slice(
    verifySocket.indexOf('const requestPairingCode = async'),
    verifySocket.indexOf('async function generatePairingKey', verifySocket.indexOf('const requestPairingCode = async'))
  );
  if (!pairingBlock.includes('await query({') || pairingBlock.includes('await sendNode({') || !pairingBlock.includes('jid: pairingJid')) {
    throw new Error('[Titan V14.09] Pairing-code server-ACK patch verification failed');
  }
  if (!verifyRecv.includes('authState.creds.me?.id')) {
    throw new Error('[Titan V14.09] Pre-login ACK patch verification failed');
  }
  if (!verifyRecv.includes('Titan V14.09: ignore incomplete link_code_companion_reg')) {
    throw new Error('[Titan V14.09] Empty link-code notification guard verification failed');
  }

  if(!fs.readFileSync(authFile,'utf8').includes('await rename(tempPath, filePath)'))throw new Error('[Titan] Atomic auth write verification failed');
  console.log(`[Titan auth] Atomic credential/key writes: ${authResult.state}`);
  console.log(`[Titan V14.09] Baileys pairing patches OK: request=${pairResult.state}, ack=${ackResult.state}, empty-notify=${emptyResult.state}`);
} catch (err) {
  console.error(err?.stack || err);
  process.exit(1);
}
