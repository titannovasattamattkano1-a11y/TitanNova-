const path = require('path');
try { require('dotenv').config({ path: path.join(__dirname, '.env') }); } catch (_) {}
const home = process.env.HOME || __dirname;
const dataDir = process.env.TITAN_DATA || path.join(home, 'titan_data');
const serverUrl = process.env.TITAN_SERVER || 'http://127.0.0.1:3000';
module.exports = { apps: [
  // BUG FIX: Explicit app root prevents dist/bot file lookup failures when PM2 inherits a different shell cwd.
  { name:'titan-nova-web', cwd:__dirname, script:'dist/server.cjs', interpreter:'node', exec_mode:'fork', instances:1, autorestart:true, max_memory_restart:'500M', restart_delay:5000, max_restarts:20, time:true, env:{ NODE_ENV:'production', TITAN_APP_ROOT:__dirname, TITAN_SERVER:serverUrl, TITAN_DATA:dataDir, TITAN_ADMIN_KEY:process.env.TITAN_ADMIN_KEY||'', PUBLIC_APP_ORIGIN:process.env.PUBLIC_APP_ORIGIN||'', GEMINI_API_KEY:process.env.GEMINI_API_KEY||'', PORT:process.env.PORT||'3000', TITAN_LOCAL_PORT:process.env.TITAN_LOCAL_PORT||'5000' } },
  { name:'titan-nova-bot', cwd:__dirname, script:'titan-bot.js', interpreter:'node', exec_mode:'fork', instances:1, autorestart:true, max_memory_restart:'350M', restart_delay:5000, max_restarts:20, time:true, env:{ NODE_ENV:'production', TITAN_APP_ROOT:__dirname, TITAN_SERVER:serverUrl, TITAN_DATA:dataDir, LOGIN_METHOD:process.env.LOGIN_METHOD||'pairing', PHONE:process.env.PHONE||'' } },
  { name:'titan-cloudflare', cwd:__dirname, script:'./start-cloudflare.sh', interpreter:'bash', exec_mode:'fork', instances:1, autorestart:true, restart_delay:10000, max_restarts:100, time:true }
]};
