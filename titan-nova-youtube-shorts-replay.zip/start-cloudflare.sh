#!/data/data/com.termux/files/usr/bin/bash
export SSL_CERT_FILE=/data/data/com.termux/files/usr/etc/tls/cert.pem
exec termux-chroot /data/data/com.termux/files/usr/bin/cloudflared tunnel --protocol http2 --edge-ip-version 4 --url http://127.0.0.1:3000
