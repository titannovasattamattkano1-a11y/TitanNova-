import {drainLiveBroadcasts} from './scripts/drain-live-broadcasts.mjs';
import {whatsappSessionPhone,sameWhatsAppPhone} from './wa-session-policy.js';
import {scheduledCardContent} from './scripts/card-send-content.mjs';
// TITAN NOVA BAILEYS WHATSAPP BOT GATEWAY
// Run this standalone or alongside the server: node titan-bot.js

import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  fetchLatestWaWebVersion
} from '@whiskeysockets/baileys';
import pino from 'pino';
import qrcode from 'qrcode-terminal';
import rawFetch from 'node-fetch';
// A stalled local API request must not freeze every subsequent schedule tick.
const fetch = (url, options = {}) => rawFetch(url, { ...options, signal: options.signal || AbortSignal.timeout(10000) });
import fs from 'fs';
import path from 'path';
import { createSendControl, retryDelay, startIndependentHeartbeat } from './wa-send-control.js';

const titanAppRoot = path.resolve(process.env.TITAN_APP_ROOT || process.cwd());
for (const envCandidate of [path.join(titanAppRoot, '.env'), path.join(process.env.HOME || '', 'Titan', '.env')]) {
  try {
    if (!fs.existsSync(envCandidate)) continue;
    for (const rawLine of fs.readFileSync(envCandidate, 'utf8').split(/\r?\n/)) {
      const line = rawLine.trim();
      if (!line || line.startsWith('#')) continue;
      const eq = line.indexOf('=');
      if (eq <= 0) continue;
      const k = line.slice(0, eq).trim();
      const v = line.slice(eq + 1).trim().replace(/^(['"])(.*)\1$/, '$2');
      if (k && process.env[k] === undefined) process.env[k] = v;
    }
    break;
  } catch (_) {}
}
const SERVER_URL = process.env.TITAN_SERVER || `http://127.0.0.1:${process.env.PORT || 3000}`;
const POLL_INTERVAL_MS = 3000; // Faster local work discovery; existing single-flight guard prevents overlapping schedules
const titanDataDir = path.resolve(process.env.TITAN_DATA || process.env.TITAN_DATA_DIR || path.join(process.env.HOME || titanAppRoot, 'titan_data'));
const retryFile = path.join(titanDataDir, 'wa_send_cooldowns.json');
let sendFailures = {};
try { sendFailures = JSON.parse(fs.readFileSync(retryFile, 'utf8')); } catch (_) {}
const controlSender = createSendControl({ failures: sendFailures, save: value => atomicWriteJson(retryFile, value) });
const metadataCooldowns = new Map();
let liveBroadcastSessionId = '';
let liveBroadcastSessionStartedAt = 0;

// V14.06: serialize only expensive full chat discovery with Telegram. This is
// a cross-process file lock in TITAN_DATA; normal send/reconnect/schedule work
// never waits on it.
const discoveryLockFile = path.join(titanDataDir, 'titan_gateway_discovery.lock');
const discoveryOwner = `whatsapp:${process.pid}`;
function acquireDiscoveryLock() {
  const tryAcquire = () => {
    try {
      const fd = fs.openSync(discoveryLockFile, 'wx', 0o600);
      fs.writeFileSync(fd, JSON.stringify({ owner: discoveryOwner, at: Date.now() }));
      return () => {
        try { fs.closeSync(fd); } catch (_) {}
        try {
          const current = JSON.parse(fs.readFileSync(discoveryLockFile, 'utf8'));
          if (current?.owner === discoveryOwner) fs.rmSync(discoveryLockFile, { force: true });
        } catch (_) { try { fs.rmSync(discoveryLockFile, { force: true }); } catch (_) {} }
      };
    } catch (_) { return null; }
  };
  let release = tryAcquire();
  if (release) return release;
  try {
    const current = JSON.parse(fs.readFileSync(discoveryLockFile, 'utf8'));
    if (Date.now() - Number(current?.at || 0) > 3 * 60_000) {
      fs.rmSync(discoveryLockFile, { force: true });
      release = tryAcquire();
    }
  } catch (_) {}
  return release;
}

// BUG FIX: Bot delivery ledgers use atomic replace so a Termux/PM2 interruption cannot leave partial JSON.
function atomicWriteJson(filePath, value) {
  const dir = path.dirname(filePath);
  fs.mkdirSync(dir, { recursive: true });
  const tempPath = path.join(dir, `.${path.basename(filePath)}.${process.pid}.${Date.now()}.tmp`);
  try {
    fs.writeFileSync(tempPath, JSON.stringify(value), 'utf8');
    fs.renameSync(tempPath, filePath);
  } catch (error) {
    try { fs.rmSync(tempPath, { force: true }); } catch (_) {}
    throw error;
  }
}

function isSafeAuthFileName(name) {
  const clean = String(name || '');
  return clean.length > 0 && clean === path.basename(clean) && !clean.includes('..') && clean.endsWith('.json');
}

function pruneStaleAuthPreKeys(authFolder) {
  try {
    if (!fs.existsSync(authFolder)) return;
    const entries = fs.readdirSync(authFolder);
    const preKeys = [];
    for (const name of entries) {
      if (/^pre-key-\d+\.json$/.test(name)) {
        const fullPath = path.join(authFolder, name);
        try {
          const stat = fs.statSync(fullPath);
          if (stat.isFile()) preKeys.push({ name, fullPath, mtimeMs: stat.mtimeMs });
        } catch (_) {}
      }
    }
    // Keep the newest 150 pre-keys so Baileys E2EE session handshakes remain 100% intact
    // while preventing multi-month accumulation from exceeding the 8 MB snapshot limit.
    if (preKeys.length > 180) {
      preKeys.sort((a, b) => b.mtimeMs - a.mtimeMs);
      for (const item of preKeys.slice(150)) {
        try { fs.unlinkSync(item.fullPath); } catch (_) {}
      }
    }
  } catch (_) {}
}

function readRegisteredAuthSnapshot(authFolder) {
  if (!fs.existsSync(authFolder)) return null;
  pruneStaleAuthPreKeys(authFolder);
  const files = {};
  let totalBytes = 0;
  for (const name of fs.readdirSync(authFolder)) {
    if (!isSafeAuthFileName(name)) continue;
    const fullPath = path.join(authFolder, name);
    let stat;
    try { stat = fs.statSync(fullPath); } catch (_) { continue; }
    if (!stat.isFile()) continue;
    const raw = fs.readFileSync(fullPath, 'utf8');
    totalBytes += Buffer.byteLength(raw, 'utf8');
    if (totalBytes > 8 * 1024 * 1024) throw new Error('WhatsApp auth snapshot exceeds 8 MB safety limit');
    JSON.parse(raw);
    files[name] = raw;
  }
  if (!files['creds.json']) return null;
  const creds = JSON.parse(files['creds.json']);
  if (creds?.registered !== true) return null;
  return files;
}

function restoreAuthSnapshot(authFolder, authFiles) {
  if (!authFiles || typeof authFiles !== 'object' || Array.isArray(authFiles)) {
    throw new Error('Invalid WhatsApp auth snapshot');
  }
  const entries = Object.entries(authFiles);
  if (!entries.length || !Object.prototype.hasOwnProperty.call(authFiles, 'creds.json')) {
    throw new Error('WhatsApp auth snapshot is missing creds.json');
  }
  const restoreDir = `${authFolder}.restore.${process.pid}.${Date.now()}`;
  fs.mkdirSync(restoreDir, { recursive: true });
  try {
    let totalBytes = 0;
    for (const [name, contents] of entries) {
      if (!isSafeAuthFileName(name) || typeof contents !== 'string') {
        throw new Error(`Invalid WhatsApp auth snapshot file: ${name}`);
      }
      totalBytes += Buffer.byteLength(contents, 'utf8');
      if (totalBytes > 8 * 1024 * 1024) throw new Error('WhatsApp auth snapshot exceeds 8 MB safety limit');
      JSON.parse(contents);
      fs.writeFileSync(path.join(restoreDir, name), contents, 'utf8');
    }
    const restoredCreds = JSON.parse(fs.readFileSync(path.join(restoreDir, 'creds.json'), 'utf8'));
    if (restoredCreds?.registered !== true) throw new Error('Refusing to restore unregistered WhatsApp auth snapshot');
    fs.rmSync(authFolder, { recursive: true, force: true });
    fs.renameSync(restoreDir, authFolder);
  } catch (error) {
    try { fs.rmSync(restoreDir, { recursive: true, force: true }); } catch (_) {}
    throw error;
  }
}

console.log('===================================================');
console.log('🚀 TITAN NOVA BAILEYS WHATSAPP BOT GATEWAY');
console.log('📡 Connecting to Titan Server:', SERVER_URL);
console.log('===================================================\n');

/** Wait until Titan server is reachable (avoids ECONNREFUSED on startup). */
async function waitForServer(maxAttempts = 30, delayMs = 2000) {
  for (let i = 1; i <= maxAttempts; i++) {
    try {
      const res = await fetch(`${SERVER_URL}/api/bot/config`);
      if (res.ok) {
        console.log(`✅ Titan server is online (${SERVER_URL})`);
        return true;
      }
    } catch (e) {
      console.warn(
        `⏳ Server not ready (${i}/${maxAttempts}): ${e.message || e} — start server with: npm start`
      );
    }
    await new Promise((r) => setTimeout(r, delayMs));
  }
  console.error('❌ Titan server still offline. Bot will keep retrying in background loops.');
  return false;
}

let isPairingRequested = false;
let scheduleInterval = null;
let heartbeatStop = null;
let scheduleLoopRunning = false;
let intentionalRestart = false;
// V14.06: one live Baileys lifecycle per process.  A noisy/duplicated
// connection.close event must not fan out into multiple startBot() sockets.
let botStartInProgress = false;
let activeBotGeneration = 0;
let reconnectTimer = null;
let botStartupFailures = 0;
// A fetch/auth initialization exception used to leave the process alive with
// no socket or retry timer. Re-attempt with bounded backoff; never wipe auth.
function scheduleBotStartupRetry(error) {
  if (intentionalRestart || reconnectTimer) return;
  botStartupFailures += 1;
  const delayMs = Math.min(120_000, 5000 * 2 ** Math.min(botStartupFailures - 1, 5));
  console.error(`WhatsApp startup failed; retry in ${Math.round(delayMs / 1000)}s:`, error?.message || error);
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    void startBot().catch(scheduleBotStartupRetry);
  }, delayMs);
}
let badSessionCloseCount=0;
// Cache a valid WA Web revision across short reconnects. Re-fetching both
// external version endpoints for every transient 408/428 can cost 10-20s.
let cachedWaVersion = null;
let cachedWaVersionSource = 'package-default';
let cachedWaVersionUntil = 0;
const inFlightScheduleKeys = new Set();
const deliveredTargets = new Map();

// Single-instance guard: prevents accidental `npm run bot` duplicates from
// creating two Baileys sockets and sending the same schedule twice.
const botLockFile = path.join(titanDataDir, 'whatsapp_bot.lock');
let botLockFd = null;
function acquireBotLock() {
  fs.mkdirSync(titanDataDir, { recursive: true });
  try {
    botLockFd = fs.openSync(botLockFile, 'wx');
    fs.writeFileSync(botLockFd, JSON.stringify({ pid: process.pid, startedAt: new Date().toISOString() }));
    return true;
  } catch (e) {
    try {
      const raw = fs.readFileSync(botLockFile, 'utf8');
      const pid = Number(JSON.parse(raw)?.pid);
      // Same process reconnect (WA connection.close → startBot again): keep lock, do NOT exit
      if (pid && pid === process.pid) {
        return true;
      }
      if (pid && pid !== process.pid) {
        try { process.kill(pid, 0); return false; } catch (_) {
          fs.rmSync(botLockFile, { force: true });
          botLockFd = fs.openSync(botLockFile, 'wx');
          fs.writeFileSync(botLockFd, JSON.stringify({ pid: process.pid, startedAt: new Date().toISOString() }));
          return true;
        }
      }
    } catch (_) {
      try { fs.rmSync(botLockFile, { force: true }); } catch (_) {}
      try {
        botLockFd = fs.openSync(botLockFile, 'wx');
        fs.writeFileSync(botLockFd, JSON.stringify({ pid: process.pid, startedAt: new Date().toISOString() }));
        return true;
      } catch (_) {}
    }
    return false;
  }
}
function releaseBotLock() {
  try { if (botLockFd !== null) fs.closeSync(botLockFd); } catch (_) {}
  botLockFd = null;
  try { fs.rmSync(botLockFile, { force: true }); } catch (_) {}
}

const deliveryStateFile = path.join(titanDataDir, 'schedule_delivery_state.json');
const broadcastDeliveryStateFile = path.join(titanDataDir, 'broadcast_delivery_state.json');
const deliveredBroadcastTargets = new Map();

function loadDeliveryState() {
  try {
    if (fs.existsSync(deliveryStateFile)) {
      const raw = JSON.parse(fs.readFileSync(deliveryStateFile, 'utf8'));
      for (const [key, targets] of Object.entries(raw || {})) {
        deliveredTargets.set(key, new Set(Array.isArray(targets) ? targets : []));
      }
    }
  } catch (e) {
    console.warn('⚠️ Could not load schedule delivery state:', e.message);
  }
}

function saveDeliveryState() {
  try {
    const dir = path.dirname(deliveryStateFile);
    fs.mkdirSync(dir, { recursive: true });
    const out = {};
    for (const [key, targets] of deliveredTargets.entries()) out[key] = [...targets];
    atomicWriteJson(deliveryStateFile, out);
  } catch (e) {
    console.warn('⚠️ Could not save schedule delivery state:', e.message);
  }
}

function loadBroadcastDeliveryState() {
  try {
    if (fs.existsSync(broadcastDeliveryStateFile)) {
      const raw = JSON.parse(fs.readFileSync(broadcastDeliveryStateFile, 'utf8'));
      for (const [key, targets] of Object.entries(raw || {})) {
        deliveredBroadcastTargets.set(key, new Set(Array.isArray(targets) ? targets : []));
      }
    }
  } catch (e) {
    console.warn('⚠️ Could not load broadcast delivery state:', e.message);
  }
}

function saveBroadcastDeliveryState() {
  try {
    const dir = path.dirname(broadcastDeliveryStateFile);
    fs.mkdirSync(dir, { recursive: true });
    const out = {};
    for (const [key, targets] of deliveredBroadcastTargets.entries()) out[key] = [...targets];
    atomicWriteJson(broadcastDeliveryStateFile, out);
  } catch (e) {
    console.warn('⚠️ Could not save broadcast delivery state:', e.message);
  }
}

loadDeliveryState();
loadBroadcastDeliveryState();
process.once('SIGINT', () => { releaseBotLock(); process.exit(0); });
process.once('SIGTERM', () => { releaseBotLock(); process.exit(0); });
process.once('exit', () => { releaseBotLock(); });

// Keep bot alive on transient crashes (Android/Termux + Baileys noise)
process.on('uncaughtException', (err) => {
  console.error('💥 uncaughtException (bot stays up):', err?.message || err);
});
process.on('unhandledRejection', (err) => {
  console.error('💥 unhandledRejection (bot stays up):', err?.message || err);
});

/** Normalize dashboard target values to a real WhatsApp JID.
 * Raw group ids commonly look like 1203630...-1234567890 and must use @g.us.
 * Raw phone numbers use @s.whatsapp.net.
 */
function normalizeTargetJid(raw) {
  let clean = String(raw || '').trim();
  if (!clean) return null;
  if (clean.startsWith('tg:')) return null;
  const lower = clean.toLowerCase();
  if (lower.endsWith('@newsletter')) return /^\d{8,}@newsletter$/.test(lower) ? lower : null;
  if (lower.endsWith('@g.us') || lower.endsWith('@s.whatsapp.net') || lower.endsWith('@lid')) return lower;
  if (/^\d{8,}-\d{4,}$/.test(clean)) return `${clean}@g.us`;
  const digits = clean.replace(/[^0-9]/g, '');
  return digits ? `${digits}@s.whatsapp.net` : null;
}

// Dashboard-only delivery telemetry. This must never block or change WhatsApp delivery.
async function reportDeliveryLog({ status, targetJid, sourceKind = '', sourceLabel = '', error = '' }) {
  try {
    await fetch(`${SERVER_URL}/api/bot/delivery_log`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, targetJid, sourceKind, sourceLabel, error }),
    });
  } catch (_) {
    // Logging is best-effort only; business delivery remains authoritative.
  }
}

function broadcastSourceLabel(bc) {
  const kind = String(bc?.broadcastKind || '');
  if (kind === 'vip-auto-card') return 'VIP Auto Card';
  if (kind === 'result-followup') return 'VIP Result Follow-up';
  if (kind === 'raw-result') return 'Auto Result Forward';
  if (kind === 'vip-test') return 'VIP Test';
  return 'Live Push / Manual';
}

async function startBot() {
  if (botStartInProgress) {
    console.log('⏳ WhatsApp start already in progress — duplicate reconnect ignored.');
    return;
  }
  botStartInProgress = true;
  const myGeneration = ++activeBotGeneration;
  try {
  if (!acquireBotLock()) {
    console.error('🛑 Another Titan Nova WhatsApp bot process is already running. Refusing duplicate instance.');
    botStartInProgress = false;
    process.exit(1);
  }
  const authFolder = path.join(titanDataDir, 'whatsapp_auth');
  if (!fs.existsSync(authFolder)) {
    fs.mkdirSync(authFolder, { recursive: true });
  }

  const credsPath = path.join(authFolder, 'creds.json');

  // Dashboard/server config is authoritative. Environment PHONE is fallback
  // only for first boot; it must not pin an old/banned number forever.
  let config = { loginMethod: 'pairing', loginPhone: '' };
  try {
    const cfgRes = await fetch(`${SERVER_URL}/api/bot/config`);
    const cfgData = await cfgRes.json();
    if (cfgData.status === 'success' && cfgData.config) config = cfgData.config;
  } catch (e) {
    console.log('⚠️ Could not fetch remote config, using environment fallback.');
  }
  const desiredPhone = String(config.loginPhone || process.env.PHONE || '').replace(/[^0-9]/g, '');

  // Skip restore if we just had a forced logout (401) — avoid infinite restore of dead session
  const skipRestoreFlag = path.join(titanDataDir, 'skip_session_restore.flag');
  let skipRestore = fs.existsSync(skipRestoreFlag);
  if (skipRestore) {
    console.log('🚫 skip_session_restore.flag present — will NOT restore dead session. Fresh QR/pairing only.');
    // The revoked session was cleared at logout. Keep this flag until a new valid backup succeeds.
    // A restart during a newly accepted pairing must not delete its fresh local credentials.
  }

  // Attempt to restore session from server backup if local session is missing
  if (!skipRestore && !fs.existsSync(credsPath)) {
    try {
      console.log('🔍 Checking server for backed-up WhatsApp session credentials...');
      const sRes = await fetch(`${SERVER_URL}/api/bot/get_session`);
      const sData = await sRes.json();
      if (sData.status === 'success' && sData.authFiles) {
        restoreAuthSnapshot(authFolder, sData.authFiles);
        console.log(`✅ Restored complete WhatsApp auth snapshot (${Object.keys(sData.authFiles).length} files) from server backup!`);
      } else if (sData.status === 'success' && sData.creds) {
        // Backward compatibility with V14.09 and older single-file backups.
        if (!fs.existsSync(authFolder)) fs.mkdirSync(authFolder, { recursive: true });
        fs.writeFileSync(credsPath, sData.creds, 'utf-8');
        console.log('⚠️ Restored legacy creds-only WhatsApp backup. It will be upgraded after a stable connection.');
      }
    } catch (e) {
      console.log('ℹ️ No remote session backup found.');
    }
  }

  // A registered session belongs to one WhatsApp account. Never restore an
  // old/banned account when dashboard now requests another phone.
  if (!skipRestore && config.forceRelogin===true && desiredPhone && fs.existsSync(credsPath)) {
    try {
      const saved = JSON.parse(fs.readFileSync(credsPath, 'utf-8'));
      const savedPhone = whatsappSessionPhone(saved);
      const samePhone = sameWhatsAppPhone(savedPhone,desiredPhone);
      if (savedPhone && !samePhone) {
        console.log(`🧹 Saved session +${savedPhone} does not match requested +${desiredPhone}; clearing old session.`);
        fs.rmSync(authFolder, { recursive: true, force: true });
        await fetch(`${SERVER_URL}/api/bot/clear_session`, { method: 'POST' }).catch(() => null);
        skipRestore = true;
      }
    } catch (_) {}
  }

  const tryRestoreRegisteredBackup=async()=>{
    if(skipRestore)return false;
    try{
      const response=await fetch(`${SERVER_URL}/api/bot/get_session`);
      const backup=await response.json();
      if(backup.status!=='success'||!backup.authFiles)return false;
      const restored=JSON.parse(backup.authFiles['creds.json']||'null');
      const restoredPhone=whatsappSessionPhone(restored);
      if(restored?.registered!==true||(config.forceRelogin===true&&desiredPhone&&restoredPhone&&!sameWhatsAppPhone(restoredPhone,desiredPhone)))return false;
      restoreAuthSnapshot(authFolder,backup.authFiles);
      return true;
    }catch{return false;}
  };

  // V14.08: only a fully registered Baileys session is restorable.
  // requestPairingCode() writes creds.me + creds.pairingCode BEFORE the phone
  // accepts the link. Treating creds.me as a valid session preserves stale
  // half-paired crypto state and can make the next code appear "mismatched".
  if (fs.existsSync(credsPath)) {
    try {
      const rawCreds = fs.readFileSync(credsPath, 'utf-8');
      const creds = JSON.parse(rawCreds);
      if (creds?.registered !== true) {
        if(config.forceRelogin!==true&&await tryRestoreRegisteredBackup()){
          console.log('Registered backup restored over incomplete local pairing.');
        }else{
          console.log('🧹 Unregistered/half-paired WhatsApp auth found. Cleaning before fresh pairing...');
          fs.rmSync(authFolder, { recursive: true, force: true });
          // An incomplete local pairing is not proof that a registered server backup is revoked.
          fs.mkdirSync(authFolder, { recursive: true });
        }
      } else {
        console.log(`🔒 Valid registered WhatsApp Session Found for ${creds.me?.id || creds.me?.name || 'Registered Account'}. Preserving login state!`);
      }
    } catch (e) {
      console.warn('Local WhatsApp creds unreadable; checking registered backup before any reset.');
      if(config.forceRelogin===true){
        console.log('Explicit fresh login requested; replacing unreadable local auth.');
        fs.rmSync(authFolder,{recursive:true,force:true});fs.mkdirSync(authFolder,{recursive:true});
        await fetch(`${SERVER_URL}/api/bot/clear_session`,{method:'POST'}).catch(()=>null);
        fs.writeFileSync(skipRestoreFlag,String(Date.now()),'utf8');skipRestore=true;
      }else{
        if(!await tryRestoreRegisteredBackup())throw new Error('Local auth unreadable and complete backup unavailable. Auth kept; restore backup or explicitly generate a fresh login.');
        console.log('Registered WhatsApp auth recovered from complete backup.');
      }
    }
  }

  const { state, saveCreds } = await useMultiFileAuthState(authFolder);
  // Initialize registration state before version-cache selection. Previously
  // this const was referenced in its temporal dead zone, making EVERY socket
  // startup fail while PM2 still showed the bot process as online.
  const registeredAtSocketStart = state.creds.registered === true;
  
  // V14.07: new-device pairing must use the LIVE WhatsApp Web revision.
  // fetchLatestBaileysVersion() can lag behind Meta and still generate a code
  // that WhatsApp later refuses to link. Prefer sw.js client_revision, then
  // fall back to the Baileys repo version only if the live lookup fails.
  let version = registeredAtSocketStart && Date.now() < cachedWaVersionUntil ? cachedWaVersion : null;
  let versionSource = version ? cachedWaVersionSource : 'package-default';
  if (!version) try {
    const live = await fetchLatestWaWebVersion({ signal: AbortSignal.timeout(10000) });
    if (live?.isLatest === true && live?.version && Array.isArray(live.version)) {
      version = live.version;
      versionSource = 'wa-web-live';
    } else if (live?.error) {
      console.log(`⚠️ Live WhatsApp Web version was unavailable: ${live.error?.message || live.error}`);
    }
  } catch (e) {
    console.log(`⚠️ Live WhatsApp Web version lookup failed: ${e?.message || e}`);
  }
  if (!version) {
    try {
      const repo = await fetchLatestBaileysVersion({ signal: AbortSignal.timeout(10000) });
      if (repo?.version && Array.isArray(repo.version)) {
        version = repo.version;
        versionSource = 'baileys-repo';
      }
    } catch (e) {
      console.log(`⚠️ Baileys version fallback failed: ${e?.message || e}`);
    }
  }
  if (version) {
    cachedWaVersion = version;
    cachedWaVersionSource = versionSource;
    cachedWaVersionUntil = Date.now() + 60 * 60_000;
    console.log(`🌐 WhatsApp Web version: ${version.join('.')} (${versionSource})`);
  } else {
    console.log('⚠️ Dynamic WhatsApp version unavailable; using Baileys package default.');
  }

  const LOGIN_METHOD = (config.loginMethod || process.env.LOGIN_METHOD || 'pairing').toLowerCase();
  const rawPhone = config.loginPhone || process.env.PHONE || '';
  // Sanitize phone number: DIGITS ONLY without leading + or spaces (e.g. 91XXXXXXXXXX)
  const PHONE_NUMBER = rawPhone.replace(/[^0-9]/g, '');
  const usePairingCode = LOGIN_METHOD === 'pairing';

  console.log(`🔑 Login Mode: ${LOGIN_METHOD.toUpperCase()}`);
  if (usePairingCode) {
    console.log(`📱 Target Phone Number: +${PHONE_NUMBER}`);
  }

  let pairingSocketPoisoned = false;
  // V14.11: hard one-shot latch per Baileys socket generation. WhatsApp emits
  // a fresh QR reference after 60s and then roughly every 20s while unpaired.
  // Those QR refreshes must never cause another requestPairingCode() on the
  // same socket because the pairing code and crypto state are shared.
  let pairingAttemptStarted = false;
  let connectionOpenedAt = 0;
  let socketClosed=false;
  let lastFullSessionBackupAt = 0;
  let sessionBackupInFlight = null;

  const sock = makeWASocket({
    ...(version ? { version } : {}),
    auth: state,
    printQRInTerminal: !usePairingCode,
    logger: pino({ level: 'silent' }),
    // V14.08: keep Baileys' canonical default browser identity for link-code
    // registration. WhatsApp validates pairing platform/display fields more
    // strictly than normal reconnects, so avoid overriding it here.
    markOnlineOnConnect: true,
    generateHighQualityLinkPreview: true,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 60000,
    keepAliveIntervalMs: 25000,
  });
  sock.sendMessage = controlSender(sock.sendMessage.bind(sock));

  const backupRegisteredAuthSession = async (force = false) => {
    if(socketClosed||myGeneration!==activeBotGeneration)return false;
    if (sock.authState.creds.registered !== true) return false;
    const now = Date.now();
    if (!registeredAtSocketStart && (!connectionOpenedAt || now - connectionOpenedAt < 30_000)) return false;
    if (!force && now - lastFullSessionBackupAt < 60_000) return false;
    if (sessionBackupInFlight) return sessionBackupInFlight;
    sessionBackupInFlight = (async () => {
      try {
        const authFiles = readRegisteredAuthSnapshot(authFolder);
        if (!authFiles) return false;
        const response = await fetch(`${SERVER_URL}/api/bot/save_session`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ authFiles }),
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        lastFullSessionBackupAt = Date.now();
        if(!socketClosed&&myGeneration===activeBotGeneration){try{fs.rmSync(skipRestoreFlag,{force:true});}catch{}}
        return true;
      } catch (error) {
        console.warn('⚠️ Complete WhatsApp session backup failed:', error?.message || error);
        return false;
      } finally {
        sessionBackupInFlight = null;
      }
    })();
    return sessionBackupInFlight;
  };

  // Heavy dashboard discovery can be requested by several Baileys events at
  // nearly the same time (history, contacts, channel metadata, connection.open).
  // Keep it single-flight per socket and coalesce bursts into one trailing sync.
  let chatSyncInFlight = null;
  let chatSyncPending = false;
  let chatSyncNextAttempt = 1;
  let chatSyncTrailingTimer = null;
  const queueTrailingChatSync = (delayMs = 1500, attempt = 1) => {
    if (myGeneration !== activeBotGeneration) return;
    chatSyncPending = true;
    chatSyncNextAttempt = Math.max(chatSyncNextAttempt, attempt);
    if (chatSyncTrailingTimer) return;
    chatSyncTrailingTimer = setTimeout(() => {
      chatSyncTrailingTimer = null;
      if (myGeneration !== activeBotGeneration) return;
      const nextAttempt = chatSyncNextAttempt;
      chatSyncPending = false;
      chatSyncNextAttempt = 1;
      void syncWhatsAppChats(sock, nextAttempt);
    }, delayMs);
  };

  sock.ev.on('creds.update', async () => {
    // Always persist locally: Baileys needs transient pairing keys during the
    // current handshake. Remote backup is different: only a fully registered
    // complete multi-file auth snapshot is safe to restore on a later start.
    if(socketClosed||myGeneration!==activeBotGeneration)return;
    try{await saveCreds();}catch(error){console.error('WhatsApp credential save failed:',error?.message||error);return;}
    if (sock.authState.creds.registered === true) {
      void backupRegisteredAuthSession(false);
    }
  });

  // Function to request pairing code with retry & clean state
  // Always re-reads phone from dashboard so NEW numbers work (not stuck on first number).
  const requestPairingCodeWithRetry = async (attempts = 1) => {
    if (pairingAttemptStarted) return;
    if (isPairingRequested || pairingSocketPoisoned || sock.authState.creds.registered) return;
    pairingAttemptStarted = true;
    isPairingRequested = true;

    // Latest phone from server (dashboard may have changed it)
    let pairPhone = PHONE_NUMBER;
    try {
      const cfgRes = await fetch(`${SERVER_URL}/api/bot/config`);
      const cfgData = await cfgRes.json();
      if (cfgData?.config?.loginPhone) {
        pairPhone = String(cfgData.config.loginPhone).replace(/[^0-9]/g, '') || pairPhone;
      }
    } catch (_) {}

    if (!pairPhone || pairPhone.length < 10) {
      console.error('❌ No valid login phone set. Dashboard → WA BOT → enter number with country code (e.g. 91XXXXXXXXXX)');
      isPairingRequested = false;
      pairingAttemptStarted = false; // no crypto request was sent; safe to retry after fixing the number
      sendHeartbeat({
        status: 'offline',
        logMsg: '❌ Set login phone in dashboard first (with country code)',
        logType: 'warning',
      });
      return;
    }

    try {
      console.log(`📲 Requesting WhatsApp Pairing Code for +${pairPhone}...`);
      let code = await sock.requestPairingCode(pairPhone);
      code = code?.match(/.{1,4}/g)?.join("-") || code;

      console.log('\n=================================================');
      console.log(`📲 YOUR WHATSAPP PAIRING CODE (${pairPhone}):`, code);
      console.log('=================================================\n');
      console.log('👉 Open WhatsApp on THAT phone > Linked Devices > Link with Phone Number!');
      console.log('👉 Enter code:', code);

      sendHeartbeat({
        status: 'pairing',
        pairingCode: code,
        qrCodeData: '',
        logMsg: `🔑 Pairing Code: ${code} for +${pairPhone}`
      });
    } catch (err) {
      const statusCode = err?.output?.statusCode || err?.statusCode || err?.data?.statusCode || '';
      const detail = err?.output?.payload?.message || err?.message || String(err);
      console.error(`❌ Pairing code request rejected${statusCode ? ` (${statusCode})` : ''}:`, detail);
      isPairingRequested = false;
      pairingSocketPoisoned = true;

      // V14.10: permanently poison this socket after a rejected pairing request.
      // Some Baileys/WhatsApp flows emit another QR reference after rejection;
      // that must NOT trigger requestPairingCode again with the same one-time keys.
      // A dashboard Generate action performs the existing force-relogin restart,
      // creating a brand-new socket/auth state instead.
      // requestPairingCode uses one-time crypto material; a rejected/closed hello
      // must be followed by a fresh local socket, otherwise WhatsApp can receive
      // repeated companion registrations from stale pairing state.
      sendHeartbeat({
        status: 'offline',
        pairingCode: '',
        qrCodeData: '',
        logMsg: `Pairing request rejected${statusCode ? ` (${statusCode})` : ''} for +${pairPhone}: ${detail}. Press Generate Pairing Code once for a fresh attempt.`,
        logType: 'danger',
      });
    }
  };

  sock.ev.on('connection.update', async (update) => {
    // Events from an older socket may arrive after a reconnect. They are stale
    // and must never clear auth, stop the current scheduler, or spawn a socket.
    if (myGeneration !== activeBotGeneration) return;
    const { connection, lastDisconnect, qr } = update;

    // V14.07: request a phone-link code only after WhatsApp has emitted a QR
    // reference. That event proves the pair-device handshake is ready. Calling
    // requestPairingCode() on an earlier arbitrary connection.update can create
    // a valid-looking code that the phone later refuses to link.
    if (qr && usePairingCode && !sock.authState.creds.registered && !pairingAttemptStarted && !isPairingRequested && !pairingSocketPoisoned) {
      void requestPairingCodeWithRetry(1);
    }

    if (qr && !usePairingCode) {
      console.log('📲 QR Code generated! Scan via WhatsApp > Linked Devices:');
      qrcode.generate(qr, { small: true });
      sendHeartbeat({ status: 'pairing', pairingCode: '', qrCodeData: qr, logMsg: 'QR Code generated in terminal', logType: 'info' });
    }

    if (connection === 'open') {
      if(socketClosed)return;
      if (reconnectTimer) {
        clearTimeout(reconnectTimer);
        reconnectTimer = null;
      }
      const userJid = sock.user?.id || '';
      const phone = whatsappSessionPhone({me:{id:userJid}});
      console.log('✅ WhatsApp Bot Connected Successfully! Phone:', phone);
      isPairingRequested = false;
      pairingSocketPoisoned = false;
      botStartupFailures = 0;
      connectionOpenedAt = Date.now();
      liveBroadcastSessionStartedAt = connectionOpenedAt;
      liveBroadcastSessionId = `wa:${process.pid}:${myGeneration}:${connectionOpenedAt}`;
      // Clear any leftover forceRelogin so heartbeat cannot logout a fresh session
      fetch(`${SERVER_URL}/api/bot/force_relogin_ack`, { method: 'POST' }).catch(() => null);
      // Existing registered sessions can be backed up immediately. A newly paired
      // session gets a short stability window first so a handshake-only 401 cannot
      // overwrite the server backup with a just-rejected companion state.
      if (registeredAtSocketStart) void backupRegisteredAuthSession(true);
      sendHeartbeat({ status: 'online', botPhone: phone, pairingCode: '', qrCodeData: '', logMsg: `Connected as +${phone}`, logType: 'success' });

      // Sync WhatsApp Groups & Contacts to Server
      syncWhatsAppChats(sock);
    }

    if (connection === 'close') {
      if(socketClosed)return;socketClosed=true;
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const currentlyRegistered = sock.authState?.creds?.registered === true;
      // A 401 during a brand-new pairing handshake is not enough evidence that a
      // previously valid account session was revoked. Only treat 401 as a true
      // logout when this socket STARTED from an already-registered session.
      // Registered 500 errors preserve auth and use bounded recovery attempts.
      const isConfirmedLogout = statusCode === DisconnectReason.loggedOut && registeredAtSocketStart;
      const isBadSession = statusCode === DisconnectReason.badSession && currentlyRegistered;
      // A 500 can be transient or local state trouble; never destroy the last registered backup on it.
      const shouldWipeSession = isConfirmedLogout;
      const isReplaced=statusCode===DisconnectReason.connectionReplaced;
      const isUnregisteredPairingTimeout = statusCode === DisconnectReason.timedOut && !currentlyRegistered;
      console.log(`⚠️ Connection closed (Status Code: ${statusCode || 'Unknown'}). Wipe session: ${shouldWipeSession}`);
      if (isUnregisteredPairingTimeout) {
        console.log('⏱️ Pairing window timed out (408). This socket will not re-request a code; next reconnect uses fresh auth state.');
      }

      isPairingRequested = false;
      sendHeartbeat({
        // Not connected: never advertise online during recovery.
        // Distinguish a temporary reconnect from logout/competing sessions.
        status: shouldWipeSession || isReplaced || intentionalRestart ? 'offline' : 'reconnecting',
        pairingCode: '',
        qrCodeData: '',
        logMsg: `Connection closed (${statusCode || 'closed'}). ${shouldWipeSession ? 'Session ended.' : 'Reconnecting / pairing state kept until fresh socket decision.'}`,
        logType: shouldWipeSession ? 'warning' : 'info',
      });

      if (shouldWipeSession) {
        // Drain an already-started remote backup before clearing it; do not recreate a revoked backup late.
        if(sessionBackupInFlight)await sessionBackupInFlight.catch(()=>null);
        console.log('🧹 Confirmed logout. Clearing LOCAL + SERVER backup...');
        try {
          if (fs.existsSync(authFolder)) {
            fs.rmSync(authFolder, { recursive: true, force: true });
          }
        } catch (e) {
          console.error('Failed to clean auth folder:', e);
        }
        try {
          fs.mkdirSync(titanDataDir, { recursive: true });
          fs.writeFileSync(path.join(titanDataDir, 'skip_session_restore.flag'), String(Date.now()), 'utf-8');
        } catch (_) {}
        fetch(`${SERVER_URL}/api/bot/clear_session`, { method: 'POST' }).catch(() => null);
      }

      if (heartbeatStop) { heartbeatStop(); heartbeatStop = null; }

      if (scheduleInterval) {
        clearInterval(scheduleInterval);
        scheduleInterval = null;
      }
      if(isBadSession){
        if(connectionOpenedAt&&Date.now()-connectionOpenedAt>=30_000)badSessionCloseCount=0;
        badSessionCloseCount++;
      }
      else if(!isConfirmedLogout)badSessionCloseCount=0;
      if(isReplaced){
        // Code 440 signals a competing login. Reconnecting here would kick
        // the other device repeatedly; keep auth and require owner action.
        console.warn('WhatsApp session replaced by another client (440). Auth kept. Stop the competing instance/device before reconnecting.');
        return;
      }
      if (intentionalRestart) {
        console.log('🔄 Intentional logout/re-login; PM2 will start one clean bot process.');
        return;
      }
      if (reconnectTimer) {
        console.log('⏳ Reconnect already scheduled — duplicate close event ignored.');
        return;
      }
      const reconnectDelayMs = isUnregisteredPairingTimeout ? 30000 : 5000;
      // Do not give up forever after three 500/badSession closures. Keep the
      // registered credentials and retry with a capped exponential cooldown.
      // Unregistered pairing timeouts retain the slower 30s cooldown.
      const effectiveDelay=isBadSession
        ? Math.min(120_000, reconnectDelayMs * 2 ** Math.min(Math.max(0, badSessionCloseCount - 1), 5))
        : reconnectDelayMs;
      console.log(`🔄 Reconnecting in ${Math.round(effectiveDelay / 1000)} seconds...`);
      reconnectTimer = setTimeout(() => {
        reconnectTimer = null;
        if (myGeneration !== activeBotGeneration) return;
        void startBot().catch(scheduleBotStartupRetry);
      }, effectiveDelay);
    }
  });

  const contactsMap = new Map();
  const newsletterMap = new Map();
  const subscribedNewsletters = new Set();
  const resolvedNewsletterMetadata = new Set();
  const knownChannelsFile = path.join(titanDataDir, 'titan_known_channels.json');
  try {
    const savedChannels = JSON.parse(fs.readFileSync(knownChannelsFile, 'utf-8'));
    if (Array.isArray(savedChannels)) {
      for (const channel of savedChannels) {
        const jid = normalizeTargetJid(channel?.jid);
        if (jid?.endsWith('@newsletter')) {
          newsletterMap.set(jid, { jid, name: String(channel?.name || jid.split('@')[0]) });
        }
      }
    }
  } catch (_) {}

  function persistKnownChannels() {
    try {
      fs.mkdirSync(titanDataDir, { recursive: true });
      fs.writeFileSync(knownChannelsFile, JSON.stringify(Array.from(newsletterMap.values()), null, 2), 'utf-8');
    } catch (e) {
      console.warn('Channel cache write warning:', e.message || e);
    }
  }

  async function rememberNewsletter(jid, fallbackName = '') {
    if (myGeneration !== activeBotGeneration) return false;
    const cleanJid = normalizeTargetJid(jid);
    if (!cleanJid || !cleanJid.endsWith('@newsletter')) return false;
    if ((metadataCooldowns.get(cleanJid) || 0) > Date.now()) return false;
    const existing = newsletterMap.get(cleanJid);
    let name = fallbackName || existing?.name || cleanJid.split('@')[0];
    if (!resolvedNewsletterMetadata.has(cleanJid)) {
      try {
        const metadata = await sock.newsletterMetadata('jid', cleanJid);
        if (metadata?.name) name = metadata.name;
        resolvedNewsletterMetadata.add(cleanJid);
      } catch (e) {
        metadataCooldowns.set(cleanJid, Date.now() + Math.max(5 * 60_000, retryDelay(e, 1)));
        console.warn(`Channel metadata warning (${cleanJid}):`, e.message || e);
      }
    }
    newsletterMap.set(cleanJid, { jid: cleanJid, name });
    if (!existing || existing.name !== name) persistKnownChannels();
    if (!subscribedNewsletters.has(cleanJid)) {
      try {
        await sock.subscribeNewsletterUpdates(cleanJid);
        subscribedNewsletters.add(cleanJid);
      } catch (e) {
        metadataCooldowns.set(cleanJid, Date.now() + Math.max(5 * 60_000, retryDelay(e, 1)));
        console.warn(`Channel live-update subscription warning (${cleanJid}):`, e.message || e);
      }
    }
    return !existing || existing.name !== name;
  }

  const rememberNewsletterEntries = async (entries = []) => {
    if (myGeneration !== activeBotGeneration) return;
    let changed = false;
    for (const entry of entries) {
      const jid = String(entry?.id || '');
      if (!jid.endsWith('@newsletter')) continue;
      const fallbackName = entry?.name || entry?.verifiedName || entry?.notify || entry?.displayName || '';
      changed = (await rememberNewsletter(jid, fallbackName)) || changed;
    }
    if (changed) await syncWhatsAppChats(sock);
  };

  const rememberNewslettersFromMessages = async (messages = []) => {
    if (myGeneration !== activeBotGeneration) return;
    let changed = false;
    const candidates = new Map();
    const addCandidate = (jid, name = '') => {
      const cleanJid = normalizeTargetJid(jid);
      if (!cleanJid || !cleanJid.endsWith('@newsletter')) return;
      if (!candidates.has(cleanJid) || name) candidates.set(cleanJid, String(name || ''));
    };

    for (const message of messages) {
      addCandidate(message?.key?.remoteJid, message?.pushName || '');

      // A Channel may also be referenced by a forwarded/admin/follower invite
      // inside a normal chat. Walk only plain message data and collect the
      // protocol's newsletter JIDs; binary media buffers are deliberately skipped.
      const pending = [{ value: message?.message, depth: 0 }];
      const visited = new Set();
      let inspected = 0;
      while (pending.length && inspected < 500) {
        const { value, depth } = pending.pop();
        if (!value || typeof value !== 'object' || depth > 12 || visited.has(value)) continue;
        visited.add(value);
        inspected += 1;
        for (const [key, child] of Object.entries(value)) {
          if (typeof child === 'string') {
            if (child.endsWith('@newsletter')) {
              const siblingName = value.newsletterName || value.name || value.channelName || '';
              addCandidate(child, siblingName);
            }
          } else if (child && typeof child === 'object' && !Buffer.isBuffer(child) && !(child instanceof Uint8Array)) {
            pending.push({ value: child, depth: depth + 1 });
          }
        }
      }
    }

    for (const [jid, name] of candidates) {
      changed = (await rememberNewsletter(jid, name)) || changed;
    }
    if (changed) await syncWhatsAppChats(sock);
  };

  sock.ev.on('messaging-history.set', ({ chats, contacts, messages }) => {
    if (myGeneration !== activeBotGeneration) return;
    void (async () => {
      await rememberNewsletterEntries([...(chats || []), ...(contacts || [])]);
      await rememberNewslettersFromMessages(messages || []);
    })();
  });
  sock.ev.on('chats.upsert', (chats) => { if (myGeneration === activeBotGeneration) void rememberNewsletterEntries(chats); });
  sock.ev.on('chats.update', (chats) => { if (myGeneration === activeBotGeneration) void rememberNewsletterEntries(chats); });
  sock.ev.on('contacts.update', (contacts) => { if (myGeneration === activeBotGeneration) void rememberNewsletterEntries(contacts); });

  // Listen for contacts updates
  sock.ev.on('contacts.upsert', async (newContacts) => {
    if (myGeneration !== activeBotGeneration) return;
    for (const c of newContacts) {
      if (c.id && c.id.endsWith('@newsletter')) {
        await rememberNewsletter(c.id, c.name || c.verifiedName || c.notify || '');
      } else if (c.id && c.id.endsWith('@s.whatsapp.net')) {
        const phone = c.id.split('@')[0];
        const name = c.name || c.verifiedName || c.notify || `+${phone}`;
        contactsMap.set(c.id, { jid: c.id, name, phone });
      }
    }
    syncWhatsAppChats(sock);
  });

  // ─── Spam Proctor (runs in WhatsApp process; config from server) ───
  let spamCfgCache = null;
  let spamCfgFetchedAt = 0;
  let lastWarningsResetAt = 0;
  const spamWarningMap = new Map(); // key: groupJid_phone → count
  const spamMsgTracker = new Map(); // key: groupJid_phone → timestamps[]

  async function getSpamConfig() {
    if (spamCfgCache && Date.now() - spamCfgFetchedAt < 8000) return spamCfgCache;
    try {
      const res = await fetch(`${SERVER_URL}/api/spam/config`);
      const data = await res.json();
      if (data.status === 'success' && data.config) {
        const resetAt = Number(data.config.warningsResetAt || 0);
        if (resetAt && resetAt !== lastWarningsResetAt) {
          spamWarningMap.clear();
          spamMsgTracker.clear();
          lastWarningsResetAt = resetAt;
          console.log('🛡️ Spam warnings reset from dashboard');
        }
        spamCfgCache = data.config;
        spamCfgFetchedAt = Date.now();
      }
    } catch (e) {
      console.warn('Spam config fetch failed:', e.message || e);
    }
    return spamCfgCache || {
      enabled: false,
      antiLink: true,
      antiFlood: true,
      antiMediaFlood: true,
      maxWarnings: 1,
      messageLimit: 5,
      timeFrameMs: 5000,
      groupProtectionMode: 'selected_only',
      protectedGroups: [],
      whitelistedGroups: [],
      whitelistedUsers: [],
    };
  }

  function jidMatch(a, b) {
    if (!a || !b) return false;
    const ca = String(a).split('@')[0].split(':')[0];
    const cb = String(b).split('@')[0].split(':')[0];
    return a === b || ca === cb || String(a).includes(cb) || String(b).includes(ca);
  }

  function detectLink(text, msg) {
    const hasMatchedUrl = !!(msg.message?.extendedTextMessage?.canonicalUrl || msg.message?.extendedTextMessage?.matchedText);
    if (hasMatchedUrl) return true;
    // Strict URL / invite patterns — avoid matching normal words
    const linkRegex = /(https?:\/\/\S+)|(www\.\S+)|(t\.me\/\S+)|(telegram\.me\/\S+)|(wa\.me\/\S+)|(chat\.whatsapp\.com\/\S+)/i;
    return linkRegex.test(String(text || ''));
  }

  async function reportSpamIncident(incident) {
    try {
      await fetch(`${SERVER_URL}/api/spam/incident`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(incident),
      });
    } catch (e) {
      console.warn('Spam incident report failed:', e.message || e);
    }
  }

  /**
   * Returns true if message was treated as spam (deleted / warned / kicked).
   * Caller should skip further processing when true.
   */
  async function runSpamProctor(sock, msg, from) {
    const cfg = await getSpamConfig();
    if (!cfg.enabled) return false;
    if (!from || !from.endsWith('@g.us')) return false;
    if (msg.key.fromMe) return false;

    // Whitelist group?
    const wlGroups = cfg.whitelistedGroups || [];
    if (wlGroups.some((g) => jidMatch(g, from))) return false;

    // Which groups to protect?
    const mode = cfg.groupProtectionMode || 'selected_only';
    const protectedList = cfg.protectedGroups || [];
    let shouldProtect = false;
    if (mode === 'all' || mode === 'all_groups') {
      shouldProtect = true;
    } else {
      // selected_only: ONLY protect listed groups (empty list = protect nothing)
      shouldProtect = protectedList.length > 0 && protectedList.some((g) => jidMatch(g, from));
    }
    if (!shouldProtect) return false;

    const rawSender = msg.key.participant || msg.participant || msg.key.participantAlt || '';
    const senderPhone = String(rawSender).split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
    if (!senderPhone) return false;

    const wlUsers = (cfg.whitelistedUsers || []).map((u) => String(u).replace(/[^0-9]/g, ''));
    if (wlUsers.includes(senderPhone)) return false;

    const cleanSenderJid = `${senderPhone}@s.whatsapp.net`;
    const msgText =
      msg.message?.conversation ||
      msg.message?.extendedTextMessage?.text ||
      msg.message?.imageMessage?.caption ||
      msg.message?.videoMessage?.caption ||
      msg.message?.documentMessage?.caption ||
      '';

    const isMedia = !!(
      msg.message?.imageMessage ||
      msg.message?.videoMessage ||
      msg.message?.stickerMessage ||
      msg.message?.documentMessage ||
      msg.message?.audioMessage
    );

    // Flood tracker
    const trackerKey = `${from}_${senderPhone}`;
    const now = Date.now();
    const timeFrame = cfg.timeFrameMs || 5000;
    const limit = cfg.messageLimit || 5;
    let stamps = spamMsgTracker.get(trackerKey) || [];
    stamps = stamps.filter((t) => now - t < timeFrame);
    stamps.push(now);
    spamMsgTracker.set(trackerKey, stamps);

    // Media-only stamps for media burst
    const mediaKey = `${trackerKey}_media`;
    let mediaStamps = spamMsgTracker.get(mediaKey) || [];
    if (isMedia) {
      mediaStamps = mediaStamps.filter((t) => now - t < timeFrame);
      mediaStamps.push(now);
      spamMsgTracker.set(mediaKey, mediaStamps);
    } else {
      mediaStamps = mediaStamps.filter((t) => now - t < timeFrame);
      spamMsgTracker.set(mediaKey, mediaStamps);
    }

    let isSpam = false;
    let spamReason = 'Link Detected';

    if (cfg.antiLink && detectLink(msgText, msg)) {
      isSpam = true;
      spamReason = 'Link Detected';
    } else if (cfg.antiFlood && stamps.length > limit) {
      isSpam = true;
      spamReason = 'Message Flood';
    } else if (cfg.antiMediaFlood && isMedia && mediaStamps.length >= 3) {
      isSpam = true;
      spamReason = 'Media Burst';
    }

    if (!isSpam) return false;

    console.log(`🛡️ [SPAM] ${spamReason} from +${senderPhone} in ${from}`);

    // Delete message
    try {
      await sock.sendMessage(from, {
        delete: {
          remoteJid: from,
          fromMe: false,
          id: msg.key.id,
          participant: rawSender || cleanSenderJid,
        },
      });
    } catch (e) {
      console.warn('🛡️ Delete failed (bot must be admin):', e.message || e);
    }

    const userKey = `${from}_${senderPhone}`;
    const currentWarnings = spamWarningMap.get(userKey) || 0;
    const maxWarn = typeof cfg.maxWarnings === 'number' ? cfg.maxWarnings : 1;

    if (currentWarnings < maxWarn) {
      const newCount = currentWarnings + 1;
      spamWarningMap.set(userKey, newCount);
      try {
        await sock.sendMessage(from, {
          text: `⚠️ *@${senderPhone}*, group me spam / links allowed nahi hai!\nWarning *${newCount}/${maxWarn}*. Dobara pe group se remove ho jaoge.`,
          mentions: [cleanSenderJid],
        });
      } catch (e) {
        console.warn('Warning send failed:', e.message || e);
      }
      await reportSpamIncident({
        chatId: from,
        chatName: from.split('@')[0],
        sender: cleanSenderJid,
        senderPhone,
        reason: spamReason,
        action: 'Warning Issued',
        messageText: String(msgText).slice(0, 100) || '[Media]',
        warningCount: newCount,
      });
    } else {
      try {
        await sock.sendMessage(from, {
          text: `🚨 *@${senderPhone}* ko spam ki wajah se group se remove kiya ja raha hai.`,
          mentions: [cleanSenderJid],
        });
      } catch (_) {}
      try {
        const toRemove = [...new Set([cleanSenderJid, rawSender].filter(Boolean))];
        await sock.groupParticipantsUpdate(from, toRemove, 'remove');
        spamWarningMap.delete(userKey);
        console.log(`🚨 Kicked +${senderPhone} from ${from}`);
      } catch (err) {
        console.error('Kick failed (bot needs admin):', err.message || err);
        try {
          await sock.sendMessage(from, {
            text: '❌ Bot user ko remove nahi kar saka — Bot ko Group Admin banao.',
          });
        } catch (_) {}
      }
      await reportSpamIncident({
        chatId: from,
        chatName: from.split('@')[0],
        sender: cleanSenderJid,
        senderPhone,
        reason: spamReason,
        action: 'User Kicked',
        messageText: String(msgText).slice(0, 100) || '[Media]',
        warningCount: currentWarnings + 1,
      });
    }

    return true;
  }

  // Listen for incoming messages & commands
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (myGeneration !== activeBotGeneration) return;
    for (const msg of messages) {
      if (!msg.message) continue;
      const from = msg.key.remoteJid;

      if (from && from.endsWith('@newsletter')) {
        const changed = await rememberNewsletter(from, msg.pushName || '');
        if (changed) await syncWhatsAppChats(sock);
      }
      await rememberNewslettersFromMessages([msg]);

      // Extract contact if direct chat
      if (from && from.endsWith('@s.whatsapp.net')) {
        const phone = from.split('@')[0];
        const name = msg.pushName || `+${phone}`;
        if (!contactsMap.has(from) || (msg.pushName && contactsMap.get(from).name === `+${phone}`)) {
          contactsMap.set(from, { jid: from, name, phone });
          syncWhatsAppChats(sock);
        }
      }

      if (msg.key.fromMe || type !== 'notify') continue;

      // Spam proctor first — if blocked, skip rest
      try {
        const blocked = await runSpamProctor(sock, msg, from);
        if (blocked) continue;
      } catch (e) {
        console.error('Spam proctor error:', e.message || e);
      }

      const text = msg.message.conversation || msg.message.extendedTextMessage?.text || '';

      if (text.trim() === '.ping') {
        await sock.sendMessage(from, { text: '🏓 *Titan Nova Gateway Active!* Status: Online ⚡' });
      }
      if (text.trim() === '.status') {
        await sock.sendMessage(from, { text: `🚀 *TITAN NOVA BOT ACTIVE*\n📡 Server: ${SERVER_URL}\n⏰ Time: ${new Date().toLocaleTimeString()}` });
      }

      // --- AUTOMATED RESULT READ → AUDIT (always) + optional FORWARD ---
      // Detect real results; never treat schedule cards / pass-fail replies as results.
      const cleanText = text.trim();
      const looksLikeScheduleOrReply =
        /digits\s*:/i.test(cleanText) ||
        /rate\s*:/i.test(cleanText) ||
        /total\s*:/i.test(cleanText) ||
        /congratulations dosto/i.test(cleanText) ||
        /bad luck dosto/i.test(cleanText) ||
        /pass\*?\s*hua/i.test(cleanText) ||
        /fail\*?\s*hua/i.test(cleanText) ||
        /next time dhamaka/i.test(cleanText);
      // Result shapes: full / open / close / spaced / "KALYAN OPEN 4"
      const hasStrictResult =
        /(\d{3})\s*[-:–—]\s*(\d{2})\s*[-:–—]\s*(\d{3})/.test(cleanText) ||
        /(\d{3})\s*[-:–—]\s*(\d)\b/.test(cleanText) ||
        /\b(\d)\s*[-:–—]\s*(\d{3})\b/.test(cleanText) ||
        /\*{0,2}(\d{3})\*{0,2}\s+\*{0,2}(\d{2})\*{0,2}\s+\*{0,2}(\d{3})\*{0,2}/.test(cleanText) ||
        /(open|close)\s*[:\-]?\s*\*{0,2}(\d{1,3})\*{0,2}\b/i.test(cleanText) ||
        /\b(open|close)\b[^0-9]{0,12}(\d)\b/i.test(cleanText);
      const hasMarketName =
        /sridevi|kalyan|time\s*bazar|milan|rajdhani|main\s*bazar|supreme|madhur/i.test(cleanText);
      const isResultPattern =
        !looksLikeScheduleOrReply &&
        hasStrictResult &&
        hasMarketName &&
        cleanText.length > 5 &&
        cleanText.length < 500;

      // If a source group is explicitly configured for reading results, allow
      // the server parser to handle loose formats that the strict bot regex may
      // not recognize. This is what keeps background marking independent of the UI.
      const hasLooseResultSignal =
        !looksLikeScheduleOrReply &&
        hasMarketName &&
        /\d/.test(cleanText) &&
        cleanText.length > 5 &&
        cleanText.length < 500;

      if (isResultPattern || hasLooseResultSignal) {
        try {
          const cfgRes = await fetch(`${SERVER_URL}/api/bot/config`);
          const cfgJson = await cfgRes.json();
          if (cfgJson.status === 'success' && cfgJson.config) {
            const { autoResultForwardEnabled, resultReadGroups } = cfgJson.config;
            const isAllowedSource =
              Array.isArray(resultReadGroups) &&
              resultReadGroups.length > 0 &&
              resultReadGroups.includes(from);
            const shouldQueueAudit = isAllowedSource && (isResultPattern || hasLooseResultSignal);

            if (shouldQueueAudit) {
              console.log(`🎯 [INCOMING RESULT] Source: ${from} | AllowedForward=${isAllowedSource} | ${cleanText.replace(/\n/g, ' ').slice(0, 120)}`);
              try {
                const auditResponse = await fetch(`${SERVER_URL}/api/bot/auto_audit_result`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ resultText: cleanText, sourceJid: from }),
                });
                if (!auditResponse.ok) {
                  const rejected = await auditResponse.json().catch(() => null);
                  throw new Error(rejected?.message || `HTTP ${auditResponse.status}`);
                }
                await auditResponse.text();
                console.log('  ✅ auto_audit_result queued');
              } catch (auditErr) {
                console.error('  ⚠️ auto_audit_result failed:', auditErr.message || auditErr);
              }
            }

            // Optional WhatsApp forward only when strict result + source allowed
            if (isResultPattern && autoResultForwardEnabled && isAllowedSource) {
              const response = await fetch(`${SERVER_URL}/api/bot/forward_result`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ resultText: cleanText, sourceJid: from }),
              });
              if (!response.ok) console.warn(`Raw result forwarding rejected: HTTP ${response.status}`);
            }
          }
        } catch (err) {
          console.error('Error processing auto result / audit:', err.message || err);
        }
      }
    }
  });

  // Heartbeat & Auto-Schedule Loop
  // IMPORTANT: only one scheduler loop may exist for this bot process.
  // Reconnects must not create additional intervals (the previous implementation
  // could create multiple loops and burst-send the same card).
  if (heartbeatStop) { heartbeatStop(); heartbeatStop = null; }
  if (scheduleInterval) {
    clearInterval(scheduleInterval);
    scheduleInterval = null;
  }

  heartbeatStop = startIndependentHeartbeat({ pulse: async signal => {
    if (socketClosed || myGeneration !== activeBotGeneration || !sock.user || !connectionOpenedAt || sock.ws?.isOpen === false) return;
    const id = sock.user.id || '';
    const response = await fetch(`${SERVER_URL}/api/bot/heartbeat`, {
      method: 'POST', signal,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'online', botPhone: whatsappSessionPhone({me:{id}}), runtimeId: liveBroadcastSessionId, sessionStartedAt: liveBroadcastSessionStartedAt }),
    });
    await response.text();
  }});

  scheduleInterval = setInterval(async () => {
    if (socketClosed||myGeneration!==activeBotGeneration||scheduleLoopRunning) return;
    scheduleLoopRunning = true;

    try {
      const userJid = sock.user?.id || '';
      const phone = whatsappSessionPhone({me:{id:userJid}});
      const currentStatus = connectionOpenedAt&&sock.user&&!socketClosed&&sock.ws?.isOpen !== false ? 'online' : (isPairingRequested ? 'pairing' : 'reconnecting');

      const hbRes = await fetch(`${SERVER_URL}/api/bot/heartbeat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: currentStatus, botPhone: phone,
          runtimeId: liveBroadcastSessionId, sessionStartedAt: liveBroadcastSessionStartedAt,
        })
      });
      const hbData = await hbRes.json();
      if(socketClosed||myGeneration!==activeBotGeneration)return;
      if (sock.authState?.creds?.registered === true && connectionOpenedAt && Date.now() - connectionOpenedAt >= 30_000) {
        void backupRegisteredAuthSession(false);
      }
      const configuredChannelJids = [
        ...(Array.isArray(hbData.resultReadGroups) ? hbData.resultReadGroups : []),
      ];
      if (configuredChannelJids.length > 0) {
        let channelsChanged = false;
        for (const jid of new Set(configuredChannelJids)) {
          if (String(jid).endsWith('@newsletter')) {
            channelsChanged = (await rememberNewsletter(jid)) || channelsChanged;
          }
        }
        if (channelsChanged) await syncWhatsAppChats(sock);
      }
      if (Array.isArray(hbData.pendingChannelInvites)) {
        for (const request of hbData.pendingChannelInvites) {
          let resolved = null;
          let errorMessage = '';
          try {
            const metadata = await sock.newsletterMetadata('invite', String(request.invite || ''));
            if (!metadata?.id || !String(metadata.id).endsWith('@newsletter')) {
              throw new Error('WhatsApp did not return a Channel JID');
            }
            await rememberNewsletter(metadata.id, metadata.name || 'WhatsApp Channel');
            resolved = { jid: metadata.id, name: metadata.name || metadata.id };
          } catch (e) {
            errorMessage = e.message || String(e);
            console.error(`Channel link resolution failed (${request.invite}):`, errorMessage);
          }
          await fetch(`${SERVER_URL}/api/bot/channel_resolved`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ requestId: request.id, ...resolved, error: errorMessage }),
          }).catch(() => null);
          if (resolved) await syncWhatsAppChats(sock);
        }
      }
      const deletedProfileIds = new Set(
        Array.isArray(hbData.deletedProfileIds)
          ? hbData.deletedProfileIds.map((pid) => String(pid || '')).filter(Boolean)
          : []
      );

      if (hbData.logoutRequested) {
        console.log('🛑 Logout requested from dashboard!');
        intentionalRestart = true;
        if (sock.authState?.creds?.registered === true) {
          try { await sock.logout(); } catch (e) {}
        } else {
          console.log('🧹 Unregistered pairing socket: local reset only (no remote WhatsApp logout).');
        }
        if (fs.existsSync(authFolder)) fs.rmSync(authFolder, { recursive: true, force: true });
        try {
          fs.mkdirSync(titanDataDir, { recursive: true });
          fs.writeFileSync(path.join(titanDataDir, 'skip_session_restore.flag'), String(Date.now()), 'utf-8');
        } catch (_) {}
        await fetch(`${SERVER_URL}/api/bot/clear_session`, { method: 'POST' }).catch(() => null);
        await fetch(`${SERVER_URL}/api/bot/logout_ack`, { method: 'POST' }).catch(() => null);
        process.exit(0);
      }

      // Force re-login: only if not already connected on the requested number
      if (hbData.forceRelogin) {
        const wantPhone = String(hbData.loginPhone || '').replace(/[^0-9]/g, '');
        const currentPhone = phone ? String(phone).replace(/[^0-9]/g, '') : '';
        const alreadyOk = sock.user && !socketClosed && (
          (wantPhone&&currentPhone&&sameWhatsAppPhone(currentPhone,wantPhone)) ||
          (!currentPhone&&connectionOpenedAt&&sock.authState?.creds?.registered===true)
        );

        if (alreadyOk) {
          console.log(`✅ Already online as +${currentPhone} — ignoring forceRelogin (prevents auto-logout)`);
          await fetch(`${SERVER_URL}/api/bot/force_relogin_ack`, { method: 'POST' }).catch(() => null);
        } else {
          console.log(`🛑 Force re-login — switch to +${wantPhone || 'new number'}`);
          intentionalRestart = true;
          if (sock.authState?.creds?.registered === true) {
          try { await sock.logout(); } catch (e) {}
        } else {
          console.log('🧹 Unregistered pairing socket: local reset only (no remote WhatsApp logout).');
        }
          if (fs.existsSync(authFolder)) fs.rmSync(authFolder, { recursive: true, force: true });
          try {
            fs.mkdirSync(titanDataDir, { recursive: true });
            fs.writeFileSync(path.join(titanDataDir, 'skip_session_restore.flag'), String(Date.now()), 'utf-8');
          } catch (_) {}
          await fetch(`${SERVER_URL}/api/bot/clear_session`, { method: 'POST' }).catch(() => null);
          await fetch(`${SERVER_URL}/api/bot/force_relogin_ack`, { method: 'POST' }).catch(() => null);
          if (heartbeatStop) { heartbeatStop(); heartbeatStop = null; }
          if (scheduleInterval) {
            clearInterval(scheduleInterval);
            scheduleInterval = null;
          }
          isPairingRequested = false;
          // One restart authority only. PM2 restarts this process with a clean
          // socket/auth state; connection.close must not launch a second socket.
          setTimeout(() => process.exit(0), 250);
          return;
        }
      }

      if (!sock.user||!connectionOpenedAt||socketClosed||sock.ws?.isOpen === false) return;

      const processScheduledCards = async () => {
        // Auto-schedule only when enabled
        if (!hbData.autoSendEnabled) return;
  
        // The server may resolve admin ledger targets from explicit card targets or
        // synced WhatsApp groups even when the global targetGroups list is empty.
        // Do not print a warning on every poll; the due-item guard below reports
        // only a real schedule that has no valid destination.
        const globalTargets = Array.isArray(hbData.targetGroups) ? hbData.targetGroups : [];
  
        const schedRes = await fetch(`${SERVER_URL}/api/bot/schedule`);
        const schedData = await schedRes.json();
  
        if (schedData.status === 'success' && Array.isArray(schedData.schedules)) {
          // Dedupe per unique schedule key only (admin + VIP same market/time both allowed)
          const seenSlots = new Set();
          const isVipItem = (it) => {
            const pa = String(it.profileId || 'admin1');
            return pa !== 'admin1' || String(it.type || '') === 'vip' || String(it.key || '').startsWith('client_') || String(it.key || '').startsWith('vip_');
          };
          const byTime = (a, b) => String(a.schTime || '').localeCompare(String(b.schTime || ''))
            || String(a.key || '').localeCompare(String(b.key || ''));
          const allDue = (schedData.schedules || []).filter((it) =>
            it && it.shouldSend && !deletedProfileIds.has(String(it.profileId || ''))
          );
          // PHASE 1: VIP/client  PHASE 2: admin ledger — both in same poll
          const due = [
            ...allDue.filter(isVipItem).sort(byTime),
            ...allDue.filter((it) => !isVipItem(it)).sort(byTime),
          ];
          if (due.length) {
            const vipN = due.filter(isVipItem).length;
            const admN = due.length - vipN;
            console.log(`📋 [SCHEDULE DUE] total=${due.length} vip=${vipN} admin=${admN} | ${due.map((d) => `${d.profileId||'?'}@${d.schTime}:${d.marketName}`).join(' | ')}`);
          }
          for (const item of due) {
            if (!item.shouldSend) continue;
            if (!item.key || inFlightScheduleKeys.has(item.key)) continue;
            // MUST include profileId — admin + VIP can share same market/time; skipping
            // without profile caused admin-only or VIP delayed ~1 poll/claim window.
            const slotId = `${item.profileId || 'admin1'}_${item.date || ''}_${item.type || ''}_${item.marketName || ''}_${item.schTime || ''}_${item.key || ''}`;
            if (seenSlots.has(slotId)) {
              console.log(`⏭️ [SCHEDULE SKIP DUPLICATE SLOT] ${slotId}`);
              continue;
            }
            seenSlots.add(slotId);
            if (!item.message || !String(item.message).trim()) {
              console.log(`⚠️ [SCHEDULE] Empty message for ${item.key}, skip`);
              continue;
            }
  
            // Prefer card-specific targets.
            // VIP/profile schedules (profileId or client_* key) must NEVER fall back to
            // admin global groups — only their own number / schTargets.
            const isVipSlot =
              (item.profileId && item.profileId !== 'admin1') ||
              String(item.key || '').startsWith('client_') ||
              String(item.type || '') === 'vip';
            const isDummyGroup = (t) => {
              const s = String(t || '');
              return !s || s.includes('1203630123456789') || s === '__USE_GLOBAL_TARGETS__';
            };
            let rawTargets = Array.isArray(item.schTargets) ? item.schTargets.slice() : [];
            // Expand admin marker / empty → global WA Bot target groups
            if (!isVipSlot) {
              const onlyMarkerOrEmpty =
                rawTargets.length === 0 ||
                rawTargets.every((t) => isDummyGroup(t));
              if (onlyMarkerOrEmpty) {
                rawTargets = (globalTargets || []).filter((t) => !isDummyGroup(t));
              } else {
                rawTargets = rawTargets.filter((t) => !isDummyGroup(t));
                if (rawTargets.length === 0) {
                  rawTargets = (globalTargets || []).filter((t) => !isDummyGroup(t));
                }
              }
            }
  
            const targetJids = [...new Set(rawTargets.map(normalizeTargetJid).filter(Boolean))];
  
            if (targetJids.length === 0) {
              console.log(
                `⚠️ [SCHEDULE] No valid targets for ${item.marketName} [${item.key}] ` +
                `profile=${item.profileId || '?'} isVip=${isVipSlot} ` +
                `schTargets=${JSON.stringify(item.schTargets || [])} global=${(globalTargets || []).length}`
              );
              if (!isVipSlot) {
                console.log('💡 Admin ledger needs real groups in WA Bot → Target Groups (not dummy id)');
              }
              continue;
            }
            console.log(
              `🎯 [SCHEDULE TARGETS] ${item.profileId || '?'} ${item.marketName} → ${targetJids.join(', ')}`
            );
  
            const alreadyDelivered = deliveredTargets.get(item.key) || new Set();
            const pendingTargets = targetJids.filter(jid => !alreadyDelivered.has(jid));
  
            if (pendingTargets.length === 0) {
              await fetch(`${SERVER_URL}/api/bot/mark_sent`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    scheduleKey: item.key,
                    profileId: item.profileId || 'admin1',
                    type: item.type || '',
                    cardGeneration: item.cardGeneration,
                    index: typeof item.index === 'number' ? item.index : undefined,
                    digits: item.digits || '',
                    sourceMode: item.sourceMode || '',
                    trick: item.trick || '',
                    rateNum: typeof item.rateNum === 'number' ? item.rateNum : Number(item.invest || 0),
                    investTotal: typeof item.investTotal === 'number' ? item.investTotal : undefined,
                    schTime: item.schTime || '',
                    schTargets: Array.isArray(item.schTargets) ? item.schTargets : [],
                    details: `Schedule already delivered to all ${targetJids.length} targets`
                })
              }).catch(() => null);
              continue;
            }
  
            inFlightScheduleKeys.add(item.key);
            // Do NOT mark the schedule SENT before WhatsApp delivery. The server's
            // schedule claim is only a short-lived mutex; SENT is committed only
            // after every target has actually succeeded. This keeps retries safe
            // after crashes/network failures.
            try {
              console.log(`⚡ [SCHEDULE] ${item.marketName} ${item.type?.toUpperCase()} → ${pendingTargets.length} pending target(s)`);
  
              const scheduleGuardUrl = `${SERVER_URL}/api/bot/schedule_guard?key=${encodeURIComponent(item.key)}&digits=${encodeURIComponent(item.digits || '')}&rate=${encodeURIComponent(item.rateNum ?? item.invest ?? 0)}&cardGeneration=${encodeURIComponent(item.cardGeneration || 0)}`;
              // Re-check the server-side policy immediately before delivery.
              // This closes the OFF-toggle race where the bot fetched/claimed the
              // schedule just before the dashboard disabled that card type.
              try {
                const guardRes = await fetch(scheduleGuardUrl);
                const guard = await guardRes.json();
                if (!guard?.allowed) {
                  console.log(`🛑 [SCHEDULE CANCELLED] ${item.marketName} [${item.key}] → ${guard?.reason || 'disabled'}`);
                  continue;
                }
              } catch (guardErr) {
                // Fail closed on a guard/network error. The schedule remains unsent
                // and will retry during the next poll inside the grace window.
                console.log(`⚠️ [SCHEDULE GUARD] verify failed for ${item.key}; retrying next poll`);
                continue;
              }
  
              const cardContent=await scheduledCardContent(item,SERVER_URL,fetch);
              let successCount = 0;
              for (const targetJid of pendingTargets) {
                try {
                  const latestGuard = await (await fetch(scheduleGuardUrl)).json();
                  if (!latestGuard?.allowed) {
                    console.log(`🛑 [SCHEDULE STOPPED] ${item.key}: ${latestGuard?.reason || 'disabled'}`);
                    break;
                  }
                  const sent = await sock.sendMessage(targetJid, cardContent, {titanBeforeSend:async()=>{
                    const guard=await (await fetch(scheduleGuardUrl)).json();
                    if(!guard.allowed)throw new Error(`CARD_DELIVERY_CANCELLED: ${guard.reason||'disabled'}`);
                  }});
                  successCount++;
                  alreadyDelivered.add(targetJid);
                  deliveredTargets.set(item.key, alreadyDelivered);
                  saveDeliveryState();
                  // Save WA message key so Congrats/Bad luck can quote this card (right-swipe style)
                  if (sent?.key && item.key) {
                    const mk = {
                      remoteJid: sent.key.remoteJid || targetJid,
                      fromMe: sent.key.fromMe !== false,
                      id: sent.key.id,
                      participant: sent.key.participant,
                    };
                    fetch(`${SERVER_URL}/api/bot/save_schedule_msg`, {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        scheduleKey: item.key,
                        jid: targetJid,
                        messageKey: mk,
                      }),
                    }).catch(() => null);
                    console.log(`  📌 Quote-key saved ${item.key} → ${targetJid} id=${mk.id}`);
                  }
                  console.log(`  ✅ Sent ${item.key} → ${targetJid}`);
                  void reportDeliveryLog({
                    status: 'success',
                    targetJid,
                    sourceKind: 'schedule',
                    sourceLabel: `Admin Schedule${item.marketName ? ` · ${item.marketName}` : ''}${item.type ? ` ${String(item.type).toUpperCase()}` : ''}`,
                  });
                } catch (err) {
                  console.error(`  ❌ Failed ${item.key} → ${targetJid}:`, err.message || err);
                  void reportDeliveryLog({
                    status: 'failed',
                    targetJid,
                    sourceKind: 'schedule',
                    sourceLabel: `Admin Schedule${item.marketName ? ` · ${item.marketName}` : ''}${item.type ? ` ${String(item.type).toUpperCase()}` : ''}`,
                    error: err?.message || String(err),
                  });
                }
              }
  
              const allDelivered = targetJids.every(jid => alreadyDelivered.has(jid));
              if (allDelivered) {
                await fetch(`${SERVER_URL}/api/bot/mark_sent`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    scheduleKey: item.key,
                    profileId: item.profileId || 'admin1',
                    type: item.type || '',
                    cardGeneration: item.cardGeneration,
                    index: typeof item.index === 'number' ? item.index : undefined,
                    digits: item.digits || '',
                    sourceMode: item.sourceMode || '',
                    trick: item.trick || '',
                    rateNum: typeof item.rateNum === 'number' ? item.rateNum : Number(item.invest || 0),
                    investTotal: typeof item.investTotal === 'number' ? item.investTotal : undefined,
                    schTime: item.schTime || '',
                    schTargets: Array.isArray(item.schTargets) ? item.schTargets : [],
                    details: `Delivered ${targetJids.length}/${targetJids.length} targets`
                  })
                }).catch(() => null);
                console.log(`  ✅ [SCHEDULE COMPLETE] ${item.key}`);
              } else {
                console.log(`  🔁 [SCHEDULE RETRY] ${item.key}: ${alreadyDelivered.size}/${targetJids.length} delivered`);
              }
            } catch(error) {
              console.error(`⚠️ [SCHEDULE DEFERRED] ${item.key}: ${error?.message||error}`);
            } finally {
              inFlightScheduleKeys.delete(item.key);
            }
          }
        }
      };

      // --- Pending manual broadcasts (Result Auditor / UI) — always process when bot is online ---
      try {
        const backgroundDeadline = Date.now() + 5000;
        const nextBroadcast = async () => {
          const response = await fetch(`${SERVER_URL}/api/bot/pending_broadcasts?claimVersion=2&platform=whatsapp&sessionStartedAt=${liveBroadcastSessionStartedAt}&sessionId=${encodeURIComponent(liveBroadcastSessionId)}`);
          return response.json();
        };
        for await (const bc of drainLiveBroadcasts({next:nextBroadcast,beforeNext:processScheduledCards,
          canContinue:()=>!socketClosed&&myGeneration===activeBotGeneration})) {
            const businessJob = ['result-followup','vip-auto-card'].includes(bc.broadcastKind);
            if (inFlightScheduleKeys.has(bc.id)) continue;
            if (bc.profileId && deletedProfileIds.has(String(bc.profileId))) {
              console.log(`🛑 [DELETED VIP BLOCKED] broadcast ${bc.id} for ${bc.profileId}`);
              await fetch(`${SERVER_URL}/api/bot/ack_broadcast`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: bc.id, claimToken: bc.claimToken, status: 'failed', details: `Blocked deleted VIP ${bc.profileId}` })
              }).catch(() => null);
              continue;
            }
            if (bc.profileId && (bc.broadcastKind === 'profit-milestone' || (bc.cardType && ['ank','jodi','pannel'].includes(String(bc.cardType))))) {
              try {
                const guardRes = await fetch(`${SERVER_URL}/api/bot/schedule_policy?profileId=${encodeURIComponent(bc.profileId)}&cardType=${encodeURIComponent(bc.cardType || '')}&broadcastId=${encodeURIComponent(bc.id)}`);
                const guard = await guardRes.json();
                if (!guard?.allowed) {
                  console.log(`🛑 [QUEUE CANCELLED] ${bc.id} → ${guard?.reason || 'policy-off'}`);
                  await fetch(`${SERVER_URL}/api/bot/ack_broadcast?platform=whatsapp`, {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: bc.id, claimToken: bc.claimToken, status: 'failed', details: `WhatsApp broadcast policy disabled: ${bc.id}` })
                  }).catch(() => null);
                  continue;
                }
              } catch (_) {
                console.log(`⏳ [QUEUE GUARD] Could not verify ${bc.id}; live retry deferred`);
                await fetch(`${SERVER_URL}/api/bot/ack_broadcast?platform=whatsapp`, {
                  method: 'POST', headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ id: bc.id, claimToken: bc.claimToken, status: 'deferred', retryAt: Date.now() + 10000, details: `WhatsApp queue guard temporarily unavailable: ${bc.id}` })
                }).catch(() => null);
                continue;
              }
            }
            inFlightScheduleKeys.add(bc.id);
            try {
              const targetJids = [...new Set((bc.targets || []).map(normalizeTargetJid).filter(Boolean))];

              if (targetJids.length === 0) {
                await fetch(`${SERVER_URL}/api/bot/ack_broadcast`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ id: bc.id, claimToken: bc.claimToken, status: 'failed', details: `Broadcast ${bc.id}: no valid targets` })
                }).catch(() => null);
                continue;
              }

              const deliveryKey = String(bc.dedupeKey || bc.id);
              const delivered = deliveredBroadcastTargets.get(deliveryKey) || new Set();
              const pendingTargets = targetJids.filter((jid) => !delivered.has(jid));
              if (pendingTargets.length === 0) {
                await fetch(`${SERVER_URL}/api/bot/ack_broadcast`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ id: bc.id, claimToken: bc.claimToken, status: 'sent', targets: targetJids, details: `Broadcast ${bc.id}: all targets already delivered` })
                }).catch(() => null);
                continue;
              }

              console.log(`📢 [BROADCAST] ${bc.id} → ${pendingTargets.length}/${targetJids.length} pending target(s)${bc.scheduleKey ? ` quoteKey=${bc.scheduleKey}` : ''}`);
              const broadcastContent = bc.senderFormat === 'gif_video' && bc.broadcastVideo
                ? { video: Buffer.from(bc.broadcastVideo, 'base64'), gifPlayback: Boolean(bc.gifPlayback), caption: bc.message || '' }
                : (['vip-auto-card','vip-card-copy'].includes(bc.broadcastKind)||bc.broadcastKind==='vip-live-push'&&bc.senderFormat==='png')?await scheduledCardContent(bc,SERVER_URL,fetch):{text:bc.message};
              let ok = 0;
              for (const jid of pendingTargets) {
                // Background notices yield to due Admin slots between targets.
                // Complete result replies/VIP play jobs first to preserve business order.
                if (!businessJob) {
                  await processScheduledCards();
                  if (Date.now() >= backgroundDeadline) break;
                }
                try {
                  // WhatsApp right-swipe quote: reply in the SAME group, quoting the original schedule card
                  let quotedMsg = undefined;
                  // BUG FIX: Newsletter posts do not reliably accept chat-style quoted context.
                  if (bc.scheduleKey && !jid.endsWith('@newsletter')) {
                    try {
                      const qRes = await fetch(
                        `${SERVER_URL}/api/bot/schedule_msg_key?scheduleKey=${encodeURIComponent(bc.scheduleKey)}&jid=${encodeURIComponent(jid)}`
                      );
                      const qData = await qRes.json();
                      if (qData.messageKey) {
                        const mk = qData.messageKey;
                        // Baileys expects a minimal WAMessage-like object for quote
                        quotedMsg = {
                          key: {
                            remoteJid: mk.remoteJid || jid,
                            fromMe: mk.fromMe !== false,
                            id: mk.id,
                            participant: mk.participant,
                          },
                          message: { conversation: ' ' },
                        };
                      }
                    } catch (_) {}
                  }
                  // options.quoted = native WhatsApp "reply to message" (right-swipe style)
                  if (['vip-auto-card','vip-card-copy','profit-milestone'].includes(bc.broadcastKind)) {
                    const latest = await (await fetch(`${SERVER_URL}/api/bot/schedule_policy?profileId=${encodeURIComponent(bc.profileId)}&cardType=${encodeURIComponent(bc.cardType || '')}&broadcastId=${encodeURIComponent(bc.id)}`)).json();
                    if (!latest.allowed) break;
                  }
                  const sent = await sock.sendMessage(
                      jid,
                      broadcastContent,
                      {...(quotedMsg?{quoted:quotedMsg}:{}),...(['vip-auto-card','vip-card-copy'].includes(bc.broadcastKind)?{titanBeforeSend:async()=>{
                        const guard=await (await fetch(`${SERVER_URL}/api/bot/schedule_policy?profileId=${encodeURIComponent(bc.profileId)}&cardType=${encodeURIComponent(bc.cardType||'')}&broadcastId=${encodeURIComponent(bc.id)}`)).json();
                        if(!guard.allowed)throw new Error('CARD_DELIVERY_CANCELLED');
                      }}:{})}
                    );
                  // VIP auto card is a real card delivery, not a generic notice.
                  // Save its WA key so PASS/FAIL can quote the exact original card.
                  if (bc.broadcastKind === 'vip-auto-card' && sent?.key && bc.scheduleKey && !jid.endsWith('@newsletter')) {
                    const mk = {
                      remoteJid: sent.key.remoteJid || jid,
                      fromMe: sent.key.fromMe !== false,
                      id: sent.key.id,
                      participant: sent.key.participant,
                    };
                    fetch(`${SERVER_URL}/api/bot/save_schedule_msg`, {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ scheduleKey: bc.scheduleKey, jid, messageKey: mk }),
                    }).catch(() => null);
                  }
                  ok++;
                  delivered.add(jid);
                  deliveredBroadcastTargets.set(deliveryKey, delivered);
                  saveBroadcastDeliveryState();
                  console.log(`  ✅ Broadcast → ${jid}${quotedMsg ? ' (quoted reply)' : ''}`);
                  void reportDeliveryLog({
                    status: 'success',
                    targetJid: jid,
                    sourceKind: String(bc.broadcastKind || 'live-broadcast'),
                    sourceLabel: broadcastSourceLabel(bc),
                  });
                } catch (err) {
                  console.error(`  ❌ Broadcast failed → ${jid}:`, err.message || err);
                  void reportDeliveryLog({
                    status: 'failed',
                    targetJid: jid,
                    sourceKind: String(bc.broadcastKind || 'live-broadcast'),
                    sourceLabel: broadcastSourceLabel(bc),
                    error: err?.message || String(err),
                  });
                }
              }
              if (targetJids.every((jid) => delivered.has(jid))) {
                await fetch(`${SERVER_URL}/api/bot/ack_broadcast`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    id: bc.id, claimToken: bc.claimToken,
                    status: 'sent',
                    targets: targetJids,
                    details: `Broadcast ${bc.id}: ${targetJids.length}/${targetJids.length} delivered`
                  })
                }).catch(() => null);
              } else {
                // Keep temporary send failures inside this exact live WhatsApp
                // connection only. Server receipts ensure successful targets are
                // not resent; a reconnect/new login invalidates the old job.
                console.log(`  ⏳ Live broadcast deferred ${bc.id}: ${targetJids.filter(jid => delivered.has(jid)).length}/${targetJids.length} delivered`);
                await fetch(`${SERVER_URL}/api/bot/ack_broadcast?platform=whatsapp`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    id: bc.id, claimToken: bc.claimToken,
                    status: 'deferred',
                    retryAt: Date.now() + 10000,
                    targets: targetJids.filter((jid) => delivered.has(jid)),
                    details: `WhatsApp live broadcast ${bc.id}: ${targetJids.filter(jid => delivered.has(jid)).length}/${targetJids.length} delivered; remaining targets deferred in same live session`
                  })
                }).catch(() => null);
              }
            } catch(error) {
              console.error(`⚠️ [BROADCAST DEFERRED] ${bc.id}: ${error?.message||error}`);
              await fetch(`${SERVER_URL}/api/bot/ack_broadcast?platform=whatsapp`,{
                method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:bc.id, claimToken: bc.claimToken,status:'deferred',retryAt:Date.now()+10000,
                  targets:[...(deliveredBroadcastTargets.get(String(bc.dedupeKey||bc.id))||[])],details:'Card preparation/delivery temporarily unavailable'})
              }).catch(()=>null);
            } finally {
              inFlightScheduleKeys.delete(bc.id);
            }
        }
      } catch (bcErr) {
        console.error('Pending broadcast error:', bcErr.message || bcErr);
      }

      await processScheduledCards();
    } catch (e) {
      console.error('Heartbeat / Schedule error:', e.message || e);
    } finally {
      scheduleLoopRunning = false;
    }
  }, POLL_INTERVAL_MS);

  // Sync Joined WhatsApp Groups & Contacts to Titan Server
  async function syncWhatsAppChats(socket, attempt = 1) {
    if (myGeneration !== activeBotGeneration) return;
    if (chatSyncInFlight) {
      // Do not run groupFetchAllParticipating() in parallel. One trailing pass
      // is enough to capture any contacts/channels discovered during this pass.
      chatSyncPending = true;
      chatSyncNextAttempt = Math.max(chatSyncNextAttempt, attempt);
      return chatSyncInFlight;
    }

    chatSyncInFlight = (async () => {
      let releaseDiscovery = null;
      try {
        releaseDiscovery = acquireDiscoveryLock();
        if (!releaseDiscovery) {
          console.log('⏳ WA chat discovery deferred — Telegram/other gateway sync is active.');
          queueTrailingChatSync(5000, attempt);
          return;
        }
        console.log('🔄 Fetching WhatsApp Groups, Channels & Contacts for dashboard sync...');
        let groups = [];
        try {
          const groupsObj = await socket.groupFetchAllParticipating();
          groups = Object.values(groupsObj).map(g => ({
            jid: g.id,
            name: g.subject || 'WhatsApp Group',
            size: g.participants?.length || 0
          }));
        } catch (ge) {
          console.error('Group fetch warning:', ge.message);
        }

        // Baileys does not expose a group-style "fetch every followed Channel" call.
        // Seed selected Channel JIDs here; history/upsert events discover the rest.
        try {
          const cfgRes = await fetch(`${SERVER_URL}/api/bot/config`);
          const cfgJson = await cfgRes.json();
          const configuredJids = [
            ...(Array.isArray(cfgJson?.config?.resultReadGroups) ? cfgJson.config.resultReadGroups : []),
            ...(Array.isArray(cfgJson?.config?.targetGroups) ? cfgJson.config.targetGroups : []),
          ];
          const configuredChannels = [...new Set(configuredJids.filter(jid => String(jid).endsWith('@newsletter')))];
          for (const jid of configuredChannels) await rememberNewsletter(jid);
        } catch (ce) {
          console.error('Channel config sync warning:', ce.message || ce);
        }

        // Auto-discover subscribed/followed newsletters from Baileys if supported
        try {
          if (typeof socket.newsletterSubscribed === 'function') {
            const subs = await socket.newsletterSubscribed();
            if (Array.isArray(subs)) {
              for (const sub of subs) {
                const jid = normalizeTargetJid(sub?.id || sub?.jid);
                if (jid && jid.endsWith('@newsletter')) {
                  const name = String(sub?.name || sub?.subject || sub?.thread_metadata?.name?.text || jid.split('@')[0]);
                  await rememberNewsletter(jid, name);
                }
              }
            }
          }
        } catch (subErr) {
          console.log('Newsletter auto-discovery note:', subErr.message || subErr);
        }

        // Also seed any channels previously known to server
        try {
          const chatsRes = await fetch(`${SERVER_URL}/api/bot/chats`);
          const chatsJson = await chatsRes.json();
          if (Array.isArray(chatsJson?.channels)) {
            for (const ch of chatsJson.channels) {
              const jid = normalizeTargetJid(ch?.jid);
              if (jid && jid.endsWith('@newsletter')) {
                newsletterMap.set(jid, { jid, name: String(ch?.name || jid.split('@')[0]) });
              }
            }
          }
        } catch (_) {}

        const contacts = Array.from(contactsMap.values());
        const channels = Array.from(newsletterMap.values());

        console.log(`📲 Syncing ${groups.length} WA Groups, ${channels.length} Channels & ${contacts.length} Contacts...`);

        const res = await fetch(`${SERVER_URL}/api/bot/sync_chats`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ groups, channels, contacts })
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        console.log('✅ WhatsApp Chats successfully synced with Titan Web Server!');
      } catch (err) {
        const msg = err.message || String(err);
        console.error(`❌ Failed to sync WA chats (attempt ${attempt}):`, msg);
        if (/ECONNREFUSED|fetch failed|network/i.test(msg) && attempt < 8) {
          const wait = attempt * 2000;
          console.log(`⏳ Retry sync in ${wait / 1000}s — is server running? (npm start)`);
          queueTrailingChatSync(wait, attempt + 1);
        }
      } finally {
        try { releaseDiscovery?.(); } catch (_) {}
      }
    })();

    try {
      await chatSyncInFlight;
    } finally {
      chatSyncInFlight = null;
      if (chatSyncPending && !chatSyncTrailingTimer && myGeneration === activeBotGeneration) {
        queueTrailingChatSync(1500, chatSyncNextAttempt);
      }
    }
  }

  async function sendHeartbeat(payload) {
    try {
      await fetch(`${SERVER_URL}/api/bot/heartbeat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...payload, runtimeId: liveBroadcastSessionId, sessionStartedAt: liveBroadcastSessionStartedAt })
      });
    } catch (e) {
      // ignore
    }
  }

  // Socket/listeners are installed; future reconnects are controlled by the
  // generation + reconnectTimer guards above.
  } finally {
    botStartInProgress = false;
  }
}

(async () => {
  await waitForServer();
  await startBot().catch(scheduleBotStartupRetry);
})();
