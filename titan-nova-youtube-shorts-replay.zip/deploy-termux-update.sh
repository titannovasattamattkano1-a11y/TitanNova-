#!/data/data/com.termux/files/usr/bin/bash
# Deploy an already extracted source update from ~/Titan.
# Compile away from the running dist, then swap only after verification.
# Keep runtime data, credentials, existing tunnel and business logic intact.
set -euo pipefail
cd "$HOME/Titan"
for cmd in node npm pm2 tar sha256sum; do
  command -v "$cmd" >/dev/null || { echo "Missing prerequisite: $cmd" >&2; exit 1; }
done
[ -f package-lock.json ] && [ -f ecosystem.config.cjs ] || { echo 'Run from a complete Titan source installation.' >&2; exit 1; }
mkdir -p "$HOME/titan_data" "$HOME/titan_backups"
if [ -d "$HOME/Titan/titan_data" ]; then
  # Preserve historic data; do not overwrite existing canonical copies.
  cp -an "$HOME/Titan/titan_data/." "$HOME/titan_data/" 2>/dev/null || true
fi
backup="$HOME/titan_backups/titan_data_$(date +%Y%m%d_%H%M%S).tar.gz"
tar -czf "$backup" -C "$HOME" titan_data
test -s "$backup" || { echo 'Data backup failed. Deployment stopped.' >&2; exit 1; }
echo "Data backup: $backup"
if [ -f scripts/migrate-sridevi-name.cjs ]; then
  TITAN_DATA_DIR="$HOME/titan_data" node scripts/migrate-sridevi-name.cjs
fi

# Dependencies: reuse existing verified node_modules in Termux whenever core
# build/runtime binaries are already installed, avoiding slow or broken npm ci runs.
lock_sig="$(sha256sum package-lock.json | cut -d' ' -f1)-$(node -p "process.versions.modules+'-'+process.platform+'-'+process.arch")"
sig_file='node_modules/.titan-lock-signature'
if [ -x node_modules/.bin/vite ] && [ -x node_modules/.bin/esbuild ] \
  && [ -x node_modules/.bin/tsc ] && [ -d node_modules/@whiskeysockets/baileys ] \
  && [ -d node_modules/pureimage ]; then
  echo 'Dependencies verified in node_modules; skipping npm reinstall (fast update).'
  printf '%s\n' "$lock_sig" > "${sig_file}.tmp" 2>/dev/null && mv "${sig_file}.tmp" "$sig_file" 2>/dev/null || true
else
  echo 'Installing dependencies (missing packages)...'
  npm install --no-audit --no-fund || npm ci --no-audit --no-fund
  printf '%s\n' "$lock_sig" > "${sig_file}.tmp"
  mv "${sig_file}.tmp" "$sig_file"
fi

npm run lint || true
# Compile all three outputs into a staging directory: a failed build cannot
# delete the files being served by the current PM2 web process.
staging=".dist-titan-staging-$$"
trap 'rm -rf "$staging"' EXIT
TITAN_BUILD_OUT_DIR="$staging" npm run build
for file in index.html server.cjs card-png-worker.cjs; do
  test -s "$staging/$file" || { echo "Missing compiled artifact: $file" >&2; exit 1; }
done
node --check "$staging/server.cjs"
node --check "$staging/card-png-worker.cjs"
node --check titan-bot.js

rollback="$HOME/titan_backups/dist_$(date +%Y%m%d_%H%M%S)_$$"
if [ -d dist ]; then mv dist "$rollback"; else rollback=''; fi
if ! mv "$staging" dist; then
  [ -z "$rollback" ] || mv "$rollback" dist
  echo 'Could not publish staged build. Old build restored.' >&2
  exit 1
fi
# Restart web+bot once on a known-good build. Do NOT bounce the independent
# Cloudflare tunnel on every UI/code update.
if ! pm2 startOrRestart ecosystem.config.cjs --only titan-nova-web,titan-nova-bot --update-env; then
  echo 'PM2 restart failed. Restoring prior build.' >&2
  failed="$HOME/titan_backups/dist_failed_$(date +%Y%m%d_%H%M%S)_$$"
  mv dist "$failed"
  if [ -n "$rollback" ]; then
    mv "$rollback" dist
    pm2 startOrRestart ecosystem.config.cjs --only titan-nova-web,titan-nova-bot --update-env || true
  fi
  exit 1
fi
pm2 save
command -v termux-wake-lock >/dev/null && termux-wake-lock || true
pm2 status
echo 'Deployment complete. Prior compiled build:' "${rollback:-none}"
