import { Component, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { AdminWorkspaceGate } from './components/AdminWorkspaceGate';
import { AccessGate } from './components/AccessGate';
import './index.css';

/** Prevents whole-app blank screen if any child throws during render */
class RootErrorBoundary extends Component<
  { children: ReactNode },
  { error: Error | null }
> {
  state = { error: null as Error | null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error) {
    console.error('TITAN UI crash:', error);
  }

  render() {
    if (this.state.error) {
      return (
        <div
          style={{
            minHeight: '100vh',
            background: '#17212B',
            color: '#fff',
            padding: 24,
            fontFamily: 'sans-serif',
          }}
        >
          <h2 style={{ color: '#FF5D5D', marginBottom: 8 }}>UI Error</h2>
          <p style={{ color: '#8DA6C0', fontSize: 13, marginBottom: 16 }}>
            {String(this.state.error?.message || this.state.error)}
          </p>
          <button
            type="button"
            onClick={() => {
              this.setState({ error: null });
              window.location.reload();
            }}
            style={{
              background: '#2AABEE',
              color: '#fff',
              border: 0,
              borderRadius: 10,
              padding: '10px 16px',
              fontWeight: 700,
            }}
          >
            Reload App
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

createRoot(document.getElementById('root')!).render(
  <RootErrorBoundary>
    <AccessGate><AdminWorkspaceGate><App /></AdminWorkspaceGate></AccessGate>
  </RootErrorBoundary>
);
