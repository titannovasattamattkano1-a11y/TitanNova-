import type {ScrapeCommitGuard} from './scrapeCommitGuard';
export interface MarketHistoryRun { readonly id:string;readonly guard:ScrapeCommitGuard;readonly index:number;readonly controller:AbortController }
/** Default exclusive; Tie bulk explicitly supplies its complete independent-market count. */
export function createMarketHistoryRunGate(){
 const active=new Set<MarketHistoryRun>();
 const cancel=(run:MarketHistoryRun)=>{if(!active.delete(run))return false;run.controller.abort();return true;};
 return {
  current:()=>active.values().next().value??null,
  all:()=>[...active],
  acquire(guard:ScrapeCommitGuard,index:number,limit=1):MarketHistoryRun|null{
   if(!Number.isInteger(limit)||limit<1||active.size>=limit||[...active].some(r=>r.index===index))return null;
   const run={id:`history_${Date.now()}_${Math.random().toString(36).slice(2)}`,guard,index,controller:new AbortController()};active.add(run);return run;
  },
  owns:(run:MarketHistoryRun)=>active.has(run)&&!run.controller.signal.aborted,
  release:(run:MarketHistoryRun)=>active.delete(run),
  cancel,
  cancelAll:()=>{for(const run of [...active])cancel(run);},
 };
}
