import { businessDateIST } from './businessDate';
import { calculateSettlement, isRecoveryRatePossible } from './settlement';
import {recoveryMarketOrder} from './recoveryMarketOrder';

export type RecoveryShare = { source: string; part: 0 | 1; amount: number };
/** One FAIL -> two distinct future cards; one card -> at most two FAIL sources. */
export class TwoCardRecovery {
  private pending: RecoveryShare[] = [];
  private failures = new Set<string>();
  private sourceOrder = new Map<string,number>();
  private active = false;
  private legacySequence=0;
  private legacy = new Map<string,{source:string;investment:number;order:number}[]>();
  /** Until the first new-mode card, preserve the old settled prefix exactly. */
  legacySettlement(source:string,track:string,status:string,investment:number,frozen:boolean,saved:unknown):boolean {
    if(this.active || !frozen || saved !== undefined)return false;
    if(status==='PASS')this.legacy.delete(track);
    if(status==='FAIL' && investment>0)this.legacy.set(track,[...(this.legacy.get(track)||[]),{source,investment,order:this.legacySequence++}]);
    return true;
  }
  private activate() {
    if(this.active)return;
    this.active=true;
    const entries=[...this.legacy.values()].flat().sort((a,b)=>a.order-b.order);this.legacy.clear();
    for(const entry of entries)this.fail(entry.source,entry.investment);
  }
  take(_frozen?: readonly RecoveryShare[], _all = true): RecoveryShare[] {
    this.activate();
    const selected: RecoveryShare[] = [];
    for (const share of this.pending) {
      selected.push({ ...share });
    }
    const ids = new Set(selected.map(s => `${s.source}|${s.part}`));
    this.pending = this.pending.filter(s => !ids.has(`${s.source}|${s.part}`));
    return selected;
  }
  peek(frozen?: readonly RecoveryShare[], all = false): RecoveryShare[] {
    const saved={pending:this.pending.map(s=>({...s})),active:this.active,failures:new Set(this.failures),sourceOrder:new Map(this.sourceOrder),legacy:new Map(this.legacy)};
    const result=this.take(frozen,all);
    this.pending=saved.pending;this.active=saved.active;this.failures=saved.failures;this.sourceOrder=saved.sourceOrder;this.legacy=saved.legacy;
    return result;
  }
  fail(source: string, investment: number, unrecovered:readonly RecoveryShare[] = []) {
    this.activate();
    if(this.failures.has(source))return;
    // Assignment is not recovery. A failed play returns the SAME old shares,
    // then creates two shares for its new actual stake. Only PASS clears debt.
    const pendingIds=new Set(this.pending.map(s=>`${s.source}|${s.part}`));
    for(const share of unrecovered){
      const id=`${share.source}|${share.part}`;
      if(!pendingIds.has(id)&&this.sourceOrder.has(share.source)){
        this.pending.push({...share});pendingIds.add(id);
      }
    }
    this.pending.sort((a,b)=>(this.sourceOrder.get(a.source)??Infinity)-(this.sourceOrder.get(b.source)??Infinity)||a.part-b.part);
    if (!(investment > 0) || !Number.isFinite(investment)) return;
    this.failures.add(source);this.sourceOrder.set(source,this.sourceOrder.size);
    const fullAmount = Math.round(investment * 100) / 100;
    this.pending.push({source,part:0,amount:fullAmount});
  }
  clearPending(){this.activate();this.pending=[];}
  get debt(): number { return this.active?shareTotal(this.pending):Math.round([...this.legacy.values()].flat().reduce((n,e)=>n+e.investment,0)*100)/100; }
  get shares(): RecoveryShare[] { this.activate();return this.pending.map(s => ({...s})); }
}
export const shareTotal = (shares: readonly RecoveryShare[]) => Math.round(shares.reduce((n,s) => n+s.amount,0)*100)/100;
export function useTwoCardRecovery(config: {ankSplit?:boolean;panSplit?:boolean;twoCardRecoveryFrom?:string;sameMarketRecovery?:boolean;fourWaveRelay?:boolean}, _date: string, type: string): boolean {
  if (!config || config.fourWaveRelay === true) return false;
  return type === 'ank' ? config.ankSplit !== false : type === 'pannel' ? config.panSplit !== false : false;
}
export function useRecoveryShareLedger(_config:{twoCardRecoveryFrom?:string;sameMarketRecovery?:boolean},_date:string,_type:string):boolean {
  return false;
}
export function runtimeRecoveryShareLedger(_profile:any,_type:string):boolean {
  return false;
}
export function recoverySharesForCard(queue:TwoCardRecovery,card:any,split:boolean,frozen:boolean,peek=false):RecoveryShare[] {
  const all=frozen?card.twoCardRecoveryStrategy==='ALL':!split;
  return peek?queue.peek(frozen?card.twoCardRecoveryShares||[]:undefined,all):queue.take(frozen?card.twoCardRecoveryShares||[]:undefined,all);
}
export function recoveryCardFrozen(card: any): boolean {
  return Boolean(card?.sentRate || card?.sentDigits || card?.sentAt || card?.dispatchState === 'SENT' || card?.dispatchState === 'SETTLED' || card?.dispatchState === 'QUEUED');
}
/** Replay uses actual delivered assignments; old delivered cards cannot gain new debt. */
export function replayTwoCardRecovery(type: string, markets: any[], cards: Record<string, any>, track: string,
  resolveTrack: (name:string)=>string, beforeIndex = Infinity, options:{split?:boolean;legacySplit?:boolean;resetAfterThreeFails?:boolean}={}) {
  const queue = new TwoCardRecovery();
  const assignments: Record<string, RecoveryShare[]> = {};
  let fromIndex = -1; let fromCardKey: string | undefined;
  let held = 0;
  let consecutiveFails=0,cyclesClosed=0,lastResetDebt=0,lastResetCardKey:string|undefined;
  const reset=options.resetAfterThreeFails===true&&options.split===false;
  for (const market of recoveryMarketOrder(markets.filter(m => m.type === type && Number(m.index) < beforeIndex && resolveTrack(String(m.n||'')) === track))) {
    const key = `${type}_${market.index}`, card = cards[key];
    if (!card || card.deliveryRestoredAt || card.s === 'SKIP') continue;
    const settled = card.s === 'PASS' || card.s === 'FAIL';
    const frozen = recoveryCardFrozen(card) || settled && !card.backtestResult;
    if (market.enabled === false && !settled && !frozen) continue;
    const stake = calculateSettlement({type,digits:card.sentDigits||card.d,rate:card.r||card.recRate,sentRate:card.sentRate,sentInvest:card.sentInvest});
    if (settled || frozen) {if (!(stake.tokenCount>0&&stake.rate>0&&stake.invest>0))continue;}
    else if (!isRecoveryRatePossible(type,card.d)) continue;
    const legacyTrack=track.startsWith('L')||options.legacySplit===false?track:/CLOSE/i.test(String(market.n))?'CLOSE':'OPEN';
    if(queue.legacySettlement(key,legacyTrack,card.s,stake.invest,frozen,card.twoCardRecoveryShares)) {
      if(settled){
        fromIndex=Number(market.index);fromCardKey=key;
        if(reset){consecutiveFails=card.s==='FAIL'?consecutiveFails+1:0;if(consecutiveFails===3){lastResetDebt=queue.debt;lastResetCardKey=key;cyclesClosed++;queue.clearPending();consecutiveFails=0;}}
      }
      continue;
    }
    const shares = recoverySharesForCard(queue,card,options.split!==false,frozen);
    assignments[key] = shares;
    if (settled) {
      fromIndex = Number(market.index); fromCardKey = key;
      if (card.s === 'FAIL') queue.fail(key,stake.invest,shares);
      if(reset){consecutiveFails=card.s==='FAIL'?consecutiveFails+1:0;if(consecutiveFails===3){lastResetDebt=queue.debt+held;lastResetCardKey=key;cyclesClosed++;queue.clearPending();held=0;consecutiveFails=0;}}
    } else held += shareTotal(shares);
  }
  return {debt:Math.round((queue.debt+held)*100)/100, fromIndex, fromCardKey, assignments, pending:queue.shares,...(reset?{consecutiveFails,cyclesClosed,lastResetDebt,lastResetCardKey}:{})};
}
