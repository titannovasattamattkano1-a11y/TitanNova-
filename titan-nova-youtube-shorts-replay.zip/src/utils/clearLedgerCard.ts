/** Shared Clear reset: release the old play, retaining only card identity and schedule. */
export function clearedLedgerCard(old:any,marketName:string,sourceEditedAt=0,now=Date.now()):any {
  const version=Math.max(now,Number(old?.cardGeneration||0)+1,Number(old?.sourceEditedAt||0)+1,sourceEditedAt);
  return {s:'WAIT',d:'',r:'',sourceMode:'MANUAL',sourceEditedAt:version,cardGeneration:version,
    marketName:old?.marketName||marketName,loopId:old?.loopId,schTime:old?.schTime,schTargets:old?.schTargets,
    ...((old?.vipAutoStopSkipped||old?.vipAutoStopResumeEligible)&&!old?.sentRate&&!old?.sentDigits&&!old?.sentAt?{vipAutoStopResumeEligible:true}:{})};
}
