import type {DayMarketRecord,DayRecordStore,ProfileConfig} from '../types';
import {getEffectiveMarkets} from '../data/markets';
import {getScrapeSource,normalizeScrapeSource} from './scrapeProvenance';
import {modelSourceVersion} from './marketModelCard';
import {areSettlementTokensValid} from './settlement';
import {evaluateBacktest} from './backtestResult';
import {businessDateIST} from './businessDate';
import {freshSourceReplacement} from './freshEmptySource';
const sourceProtected=(rec:DayMarketRecord)=>Boolean(rec.sentDigits||rec.sentRate||rec.dispatchState||rec.deliveryRestoredAt||rec.manualStatus||((rec.s==='PASS'||rec.s==='FAIL')&&!rec.backtestResult));

/** A day-settings revision must not discard a later explicit source edit.
 * Narrow recovery: only a matching, unprotected empty ANK slot; never a reset,
 * a different job/generation, existing selection, or an unproven/manual source.
 */
export function newerSourceOverEmptyArchive(local:DayMarketRecord|undefined,saved:DayMarketRecord|undefined,localName:string|undefined,savedName:string|undefined):DayMarketRecord|undefined {
  if(!local||!saved||saved.s!=='WAIT'||String(saved.d||'').trim()||sourceProtected(saved)||saved.manualStatus||saved.sentAt||saved.settledAt||saved.vipAutoStopSkipped||
    sourceProtected(local)||local.manualStatus||local.s==='SKIP'||local.sentAt||local.settledAt||local.vipAutoStopSkipped)return;
  const revision=Number(local.sourceEditedAt||0);
  if(!Number.isFinite(revision)||revision<=Math.max(modelSourceVersion(saved),Number(saved.manualOverrideAt||0))||
    Number(local.cardGeneration||0)!==Number(saved.cardGeneration||0)||local.bulkBacktestJobId!==saved.bulkBacktestJobId||
    Number(local.bulkBacktestVersion||0)!==Number(saved.bulkBacktestVersion||0))return;
  const norm=(name:string|undefined)=>String(name||'').trim().toUpperCase();
  if(!norm(localName)||norm(localName)!==norm(savedName)||
    (local.marketName&&norm(local.marketName)!==norm(localName))||(saved.marketName&&norm(saved.marketName)!==norm(savedName)))return;
  const source=local.scrapeSource===undefined?getScrapeSource(local):normalizeScrapeSource(local.scrapeSource);
  // Pair Follow deliberately permits a partial source; never invent missing indices.
  const partialPairFollow=(local.sourceMode==='PAIR_FOLLOW'||local.sourceMode==='PAIR_COMBO'||local.sourceMode==='MSSD'||local.sourceMode==='DIGIT_FOLLOW'||local.sourceMode==='PANNA_FOLLOW'||local.sourceMode==='FLOW_3_1'||local.sourceMode==='SELF_LEARNING')&&local.scrapeSource===undefined;
  if((!partialPairFollow&&(!source||local.sourceMode!==source.mode))||!areSettlementTokensValid('ank',local.d))return;
  // Rebase source fields only. Saved rate overrides, schedules, loops and the
  // authoritative day economics/policies stay owned by the stored archive.
  let next:DayMarketRecord={...saved,s:'WAIT'};
  for(const key of ['d','od','sourceMode','sourceEditedAt','scrapeSource','trick','positionRule','weekdaySelectedDigits','weekdayHitPosition','firstDigitMirrorCut','tesla369','triCut','sniperOne','mssdState','marketModel','strictPanel30','liveCombinedCut','carryResultSix','autoRemovedResult','autoResultParity','selfLearning','mirroredFromAdmin'] as const){
    if(local[key]===undefined)delete next[key];else (next as any)[key]=structuredClone(local[key]);
  }
  next.marketName=norm(savedName);
  delete next.backtestResult;delete next.scrapeResultDigit;delete next.manualResult;delete next.manualResultSources;delete next.manualPanelResult;
  delete next.recRate;delete next.prevLoss;delete next.targetProfitWithLoss;delete next.rateFinalizedAt;delete next.rateFinalizedFrom;
  const check=local.backtestResult;
  if(check?.checked&&check.digits===next.d&&/^\d$/.test(check.actual||'')){
    next=evaluateBacktest(next,'ank',check.actual);
    if(next.backtestResult&&check.updatedAt)next.backtestResult={...next.backtestResult,updatedAt:check.updatedAt};
  }
  return next;
}
/** A fresh source-button choice can replace an older scraped selection even
 * when a newer day-settings snapshot arrives while that scrape is in flight. */
export function newerReplacementArchiveSource(local:DayMarketRecord|undefined,saved:DayMarketRecord|undefined,localName:string|undefined,savedName:string|undefined):DayMarketRecord|undefined {
 if(!local||!saved)return;
 const norm=(name:string|undefined)=>String(name||'').trim().toUpperCase();
 if(!norm(localName)||norm(localName)!==norm(savedName)||(local.marketName&&norm(local.marketName)!==norm(localName))||(saved.marketName&&norm(saved.marketName)!==norm(savedName)))return;
 return freshSourceReplacement({...saved,marketName:norm(savedName)},{...local,marketName:norm(localName)},'ank');
}
/** A result-only refresh owns no source or financial fields. */
export function newerResultForSameArchiveSource(local:DayMarketRecord,saved:DayMarketRecord|undefined,localName:string|undefined,savedName:string|undefined):DayMarketRecord|undefined {
  if(!saved||sourceProtected(saved)||sourceProtected(local)||saved.s==='SKIP'||local.s==='SKIP'||saved.sentAt||local.sentAt||saved.settledAt||local.settledAt||saved.vipAutoStopSkipped||local.vipAutoStopSkipped)return;
  if(!localName||localName!==savedName||
    (local.marketName&&local.marketName.trim().toUpperCase()!==localName.trim().toUpperCase())||
    (saved.marketName&&saved.marketName.trim().toUpperCase()!==savedName.trim().toUpperCase())||
    Number(local.cardGeneration||0)!==Number(saved.cardGeneration||0)||local.bulkBacktestJobId!==saved.bulkBacktestJobId||
    Number(local.bulkBacktestVersion||0)!==Number(saved.bulkBacktestVersion||0)||modelSourceVersion(local)!==modelSourceVersion(saved))return;
  if(!areSettlementTokensValid('ank',local.d)||['d','sourceMode','sourceEditedAt','scrapeSource','od','trick','positionRule','carryResultSix','autoRemovedResult','autoResultParity','liveCombinedCut'].some(key=>JSON.stringify((local as any)[key])!==JSON.stringify((saved as any)[key])))return;
  const check=local.backtestResult;
  if(!check?.checked||check.digits!==local.d||!/^\d$/.test(check.actual||'')||
    !(Number(check.updatedAt||0)>Number(saved.backtestResult?.updatedAt||0)))return;
  const next=evaluateBacktest({...saved,s:'WAIT'},'ank',check.actual);
  if(next.backtestResult)next.backtestResult={...next.backtestResult,updatedAt:check.updatedAt};
  return next;
}
/** Stored day economics/policies win, while proven later source edits survive. */
export function reconcileArchiveDayRevision(incoming:DayRecordStore|undefined,stored:DayRecordStore,incomingConfig:ProfileConfig,storedConfig:ProfileConfig,date:string):DayRecordStore {
  const next=structuredClone(stored);
  if(date>=businessDateIST()||!incoming?.data)return next;
  const localMarkets=getEffectiveMarkets(incomingConfig),savedMarkets=getEffectiveMarkets(storedConfig);
  for(const [key,card] of Object.entries(incoming.data)){
    const index=Number(key);if(!Number.isInteger(index)||index<0)continue;
    const source=newerSourceOverEmptyArchive(card,stored.data?.[key],localMarkets[index]?.n,savedMarkets[index]?.n)||newerReplacementArchiveSource(card,stored.data?.[key],localMarkets[index]?.n,savedMarkets[index]?.n)||newerResultForSameArchiveSource(card,stored.data?.[key],localMarkets[index]?.n,savedMarkets[index]?.n);
    if(source)next.data={...next.data,[key]:source};
  }
  return next;
}

/** Individually checked archive cards need the same stale-save protection as range jobs.
 * Explicit newer source/reset/manual edits still win; do not recalculate a saved bet.
 */
export function retainedCheckedArchiveCard(local:DayMarketRecord|undefined,saved:DayMarketRecord|undefined,localName?:string,savedName?:string):DayMarketRecord|undefined {
  const check=saved?.backtestResult;
  if(!saved||!['PASS','FAIL'].includes(saved.s)||!check?.checked||check.digits!==saved.d||!String(saved.d||'').trim())return;
  const norm=(name:string|undefined)=>String(name||'').trim().toUpperCase();
  if(localName&&savedName&&norm(localName)!==norm(savedName))return;
  if((saved.marketName&&savedName&&norm(saved.marketName)!==norm(savedName))||
    (local?.marketName&&norm(local.marketName)!==norm(saved.marketName||savedName)))return;
  if(!local)return structuredClone(saved);
  const editVersion=(rec:DayMarketRecord)=>Math.max(modelSourceVersion(rec),Number(rec.cardGeneration||0),Number(rec.manualOverrideAt||0),Number(rec.deliveryRestoredAt||0));
  const incomingVersion=editVersion(local),storedVersion=editVersion(saved);
  if(incomingVersion>storedVersion)return;
  // Real delivered/manual outcomes are authoritative, rather than a stale UI WAIT.
  if(local.sentDigits||local.sentRate||local.dispatchState||local.manualStatus||local.deliveryRestoredAt)return;
  if(local.bulkBacktestJobId!==saved.bulkBacktestJobId||Number(local.bulkBacktestVersion||0)!==Number(saved.bulkBacktestVersion||0))return;
  if(incomingVersion<storedVersion)return structuredClone(saved);
  // A complete equal/newer evaluation can intentionally replace a previous result.
  if(local.s!=='WAIT'&&local.backtestResult?.checked&&local.backtestResult.digits===local.d&&Number(local.backtestResult.updatedAt||0)>=Number(check.updatedAt||0))return;
  if(Number(local.backtestResult?.updatedAt||0)>Number(check.updatedAt||0))return;
  if(!String(local.d||'').trim()||(local.s==='WAIT'&&local.d===saved.d)||((local.s==='WAIT'||local.backtestResult)&&Number(check.updatedAt||0)>Number(local.backtestResult?.updatedAt||0)))return structuredClone(saved);
}
