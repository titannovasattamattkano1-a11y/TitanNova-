import { businessDateIST } from './businessDate';
import type { UserProfile, DayMarketRecord } from '../types';
import { areSettlementTokensValid, countSettlementTokens } from './settlement';
import { evaluateBacktest } from './backtestResult';
import { modelSourceVersion } from './marketModelCard';

export type ResultRemovalConfig={autoRemoveResultDigit?:boolean;autoRemoveResultMirror?:boolean;autoRemoveResultUnique3?:boolean};
export function resultRemovalMode(config:ResultRemovalConfig):'OFF'|'RESULT'|'RESULT + MIRROR'|'CUT 5' {
  return !config.autoRemoveResultDigit?'OFF':config.autoRemoveResultUnique3?'CUT 5':config.autoRemoveResultMirror?'RESULT + MIRROR':'RESULT';
}
export function nextResultRemovalSettings(config:ResultRemovalConfig) {
  return !config.autoRemoveResultDigit||config.autoRemoveResultUnique3?{autoRemoveResultDigit:true,autoRemoveResultMirror:false,autoRemoveResultUnique3:false}:config.autoRemoveResultMirror?{autoRemoveResultDigit:false,autoRemoveResultMirror:false,autoRemoveResultUnique3:false}:{autoRemoveResultDigit:true,autoRemoveResultMirror:true,autoRemoveResultUnique3:false};
}

/** Apply only the preceding settled ANK result in the existing recovery track. */
export function confirmedAnkResult(rec: DayMarketRecord | undefined): string | undefined {
  if (!rec || (rec.s !== 'PASS' && rec.s !== 'FAIL')) return undefined;
  if (!rec.manualStatus && rec.backtestResult && (!rec.backtestResult.checked || rec.backtestResult.digits !== rec.d)) return undefined;
  const actual = rec.manualStatus ? rec.manualResult : rec.backtestResult?.actual || rec.scrapeResultDigit;
  return /^\d$/.test(String(actual || '')) ? String(actual) : undefined;
}
/** Explicit source edits replace the input even when they reselect the same visible digits. */
export function autoRemovalInput(rec: DayMarketRecord): string {
  const old = rec.autoRemovedResult;
  return old && rec.d === old.output && (old.outputVersion === undefined || old.outputVersion === modelSourceVersion(rec)) ? old.input : rec.d;
}
export function removePreviousResult(rec: DayMarketRecord, actual: string | undefined, sourceKey: string, enabled: boolean, includeMirror = false, uniqueActuals?:string[]): DayMarketRecord {
  if (rec.sentDigits || rec.sentRate || rec.dispatchState || rec.s === 'SKIP' || (rec.manualStatus && rec.s !== 'WAIT') || rec.deliveryRestoredAt || ((rec.s === 'PASS' || rec.s === 'FAIL') && !rec.backtestResult)) return rec;
  const old = rec.autoRemovedResult;
  const isCutFive = uniqueActuals !== undefined;
  let base = autoRemovalInput(rec);

  // Cut 5 operates directly on 0-9 digits universe without needing an external scraping source
  if (isCutFive) {
    if (!areSettlementTokensValid('ank', base) || countSettlementTokens(base, 'ank') < 10) {
      base = '0, 1, 2, 3, 4, 5, 6, 7, 8, 9';
    }
  } else if (!areSettlementTokensValid('ank', base)) {
    return old ? { ...rec, autoRemovedResult: undefined } : rec;
  }

  const unique = uniqueActuals === undefined ? undefined : [...new Set(uniqueActuals.filter(d => /^\d$/.test(d)))].slice(0, 5);
  const primary = unique === undefined ? actual : unique.length === 5 ? unique[0] : undefined;
  const mirror = unique === undefined && includeMirror && /^\d$/.test(primary || '') ? String((Number(primary) + 5) % 10) : undefined;
  const cuts = new Set(unique === undefined ? [primary, ...(mirror ? [mirror] : [])] : unique.length === 5 ? unique : []);

  let output = base;
  if (enabled) {
    if (isCutFive) {
      if (cuts.size === 5) {
        output = (base.match(/\d/g) || []).filter(d => !cuts.has(d)).join(', ');
      } else {
        // Wait for 5 unique actual result digits
        output = '';
      }
    } else if (cuts.size && (base.match(/\d/g) || []).some(d => cuts.has(d))) {
      output = (base.match(/\d/g) || []).filter(d => !cuts.has(d)).join(', ');
    }
  }

  const changed = rec.d !== output;
  const version = changed ? Math.max(Date.now(), modelSourceVersion(rec) + 1) : modelSourceVersion(rec);
  const meta = enabled && (primary || unique !== undefined)
    ? {
        input: base,
        output,
        actual: primary || '',
        sourceKey,
        outputVersion: version,
        ...(mirror ? { mirror } : {}),
        ...(unique !== undefined ? { unique3: true as const, actuals: unique } : {})
      }
    : undefined;

  if (!changed && JSON.stringify(old) === JSON.stringify(meta)) return rec;
  let next: DayMarketRecord = { ...rec, d: output, autoRemovedResult: meta };
  if (isCutFive && enabled && output) {
    next.sourceMode = 'RESULT_CUT5';
  } else if (isCutFive && !enabled && next.sourceMode === 'RESULT_CUT5') {
    delete next.sourceMode;
  }
  if (changed) {
    next.sourceEditedAt = version;
    delete next.rateFinalizedAt;
    delete next.rateFinalizedFrom;
    if (rec.backtestResult) {
      const result = rec.backtestResult.actual;
      next.s = 'WAIT';
      delete next.backtestResult;
      if (result && output) next = evaluateBacktest(next, 'ank', result);
      else next.backtestResult = { digits: output, actual: result, checked: rec.backtestResult.checked };
    }
  }
  return next;
}

/** Archive controls never change the live profile setting. */
export function datedResultRemovalSettings(profile:UserProfile,date:string):ResultRemovalConfig {
  const policy=date<businessDateIST()?profile.dayRecords[date]?.backtestRecoveryPolicy:undefined;
  const config=date<businessDateIST()?profile.dayRecords[date]?.recoveryConfigSnapshot||profile.config:profile.config;
  return {
    autoRemoveResultDigit:policy?.autoRemoveResultDigit??config.autoRemoveResultDigit,
    autoRemoveResultMirror:policy?.autoRemoveResultMirror??config.autoRemoveResultMirror,
    autoRemoveResultUnique3:policy?.autoRemoveResultUnique3??config.autoRemoveResultUnique3,
  };
}
export function cycleDatedResultRemoval(profile:UserProfile,date:string):UserProfile {
  const settings=nextResultRemovalSettings(datedResultRemovalSettings(profile,date));
  return setDatedResultRemoval(profile,date,settings);
}
/** Set an explicit cut mode without cycling through intermediate saves. */
export function setDatedResultRemoval(profile:UserProfile,date:string,settings:ResultRemovalConfig&{autoCarryResultSix?:boolean}):UserProfile {
  if(date>=businessDateIST())return {...profile,config:{...profile.config,...settings}};
  const day=profile.dayRecords[date]||{};
  const version=Math.max(Date.now(),Number(day.backtestRevision||0)+1,Number(day.backtestRecoveryPolicy?.updatedAt||0)+1);
  return {...profile,dayRecords:{...profile.dayRecords,[date]:{...day,backtestRevision:version,backtestRecoveryPolicy:{resetAfterThreeFails:false,maxStake:0,...day.backtestRecoveryPolicy,...settings,updatedAt:version}}}};
}

export type CarryControlMode='OFF'|'CARRY6'|'CUT3';
export function carryControlMode(profile:UserProfile,date:string):CarryControlMode {
  const carry=date<businessDateIST()?profile.dayRecords[date]?.backtestRecoveryPolicy?.autoCarryResultSix??(profile.dayRecords[date]?.recoveryConfigSnapshot||profile.config).autoCarryResultSix:profile.config.autoCarryResultSix;
  const cut=datedResultRemovalSettings(profile,date);
  return carry?'CARRY6':cut.autoRemoveResultDigit&&cut.autoRemoveResultUnique3?'CUT3':'OFF';
}
export function carryControlSettings(profile:UserProfile,date:string,mode:CarryControlMode) {
  const cut=datedResultRemovalSettings(profile,date);
  return {autoCarryResultSix:mode==='CARRY6',...(mode==='CUT3'?{autoRemoveResultDigit:true,autoRemoveResultMirror:false,autoRemoveResultUnique3:true}:cut.autoRemoveResultUnique3?{autoRemoveResultDigit:false,autoRemoveResultMirror:false,autoRemoveResultUnique3:false}:{...cut,autoRemoveResultUnique3:false})};
}

export type ResultControl='RESULT'|'RESULT + MIRROR'|'CARRY6'|'CUT3';
/** A small immutable settings edit. Recalculation and persistence belong to the
 * existing worker/autosave paths, never to the click handler.
 */
export function toggleDatedResultControl(profile:UserProfile,date:string,control:ResultControl):UserProfile {
 if(control==='CARRY6'||control==='CUT3'){
  const mode=carryControlMode(profile,date)===control?'OFF':control;
  return setDatedResultRemoval(profile,date,carryControlSettings(profile,date,mode));
 }
 const enabled=resultRemovalMode(datedResultRemovalSettings(profile,date))!==control;
 return setDatedResultRemoval(profile,date,{autoRemoveResultDigit:enabled,autoRemoveResultMirror:enabled&&control==='RESULT + MIRROR',autoRemoveResultUnique3:false});
}
