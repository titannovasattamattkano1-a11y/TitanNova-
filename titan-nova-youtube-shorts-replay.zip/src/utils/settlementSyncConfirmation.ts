/** Verify an uncertain manual status POST with a read-only, authoritative server snapshot.
 * NEVER replay the mutation: the first request may have already settled a card.
 */
export async function confirmSettlementAfterTransportError(options: {
  profileId: string; type: string; index: number; date: string; status: string;
  issuedAt: number; snapshotUrl: string; headers?: HeadersInit;
  fetcher?: typeof fetch;
}): Promise<'confirmed' | 'unconfirmed'> {
  const {profileId, type, index, date, status, issuedAt, snapshotUrl, headers, fetcher = fetch} = options;
  try {
    const response = await fetcher(snapshotUrl, {method:'GET', cache:'no-store', headers});
    if (!response.ok) return 'unconfirmed';
    const body = await response.json();
    if (body?.status !== 'success' || body?.ledger?.date !== date) return 'unconfirmed';
    const card = body?.ledger?.profiles?.[profileId]?.cards?.[`${type}_${index}`];
    if (!card || String(card.s || 'WAIT').toUpperCase() !== status.toUpperCase()) return 'unconfirmed';
    // A matching old card cannot prove this specific request reached the server.
    if (card.manualStatus !== true || !Number.isFinite(Number(card.manualOverrideAt)) || Number(card.manualOverrideAt) < issuedAt - 1500)
      return 'unconfirmed';
    return 'confirmed';
  } catch {
    return 'unconfirmed';
  }
}
