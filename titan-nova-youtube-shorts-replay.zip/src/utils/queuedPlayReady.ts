/** Read-only reason for an already-queued VIP play; never computes a new rate. */
export function queuedPlayBlockReason(job:any,profile:any,currentDate:string):string {
  if(job?.broadcastKind!=='vip-auto-card')return '';
  if(!profile)return 'profile-unavailable';
  if(profile.vipAutoMode===false)return 'vip-auto-off';
  const keyDate=String(job.scheduleKey||'').match(/\d{4}-\d{2}-\d{2}/)?.[0];
  if((job.date&&String(job.date)!==currentDate)||(keyDate&&keyDate!==currentDate))return 'wrong-business-date';
  const card=profile.cards?.[`${job.cardType}_${job.index}`];
  if(!card)return 'card-unavailable';
  if(['PASS','FAIL','SKIP'].includes(card.s))return 'card-settled-or-skipped';
  if(card.deliveryRestoredAt)return 'card-restored';
  if(Number(card.cardGeneration||0)!==Number(job.cardGeneration||0))return 'stale-card-generation';
  const market=profile.markets?.find((m:any)=>m.type===job.cardType&&Number(m.index)===Number(job.index));
  if(market?.enabled===false)return 'market-off';
  const canonical=(value:unknown)=>String(value??'').split(/[,|\s]+/).filter(Boolean).join(',');
  if(canonical(card.sentDigits||card.d)!==canonical(job.digits))return 'stale-card-digits';
  const rate=Number(card.sentRate||card.r||card.recRate||0);
  if(!(rate>0))return 'card-rate-not-ready';
  return rate===Number(job.rateNum)?'':'stale-card-rate';
}
export function queuedPlayReady(job:any,profile:any,currentDate:string):boolean {
  return !queuedPlayBlockReason(job,profile,currentDate);
}
