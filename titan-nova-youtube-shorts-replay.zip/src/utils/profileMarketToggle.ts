import { isMarketEnabled } from '../data/markets';
import { isMarketOpenOnDate } from './sourceIndexDisplayDates';

const normalizeBaseMarketName = (value: unknown): string =>
  String(value || '')
    .trim()
    .replace(/\s+/g, ' ')
    .replace(/\s+(OPEN|CLOSE)$/i, '')
    .trim()
    .toUpperCase();

/** Toggle one base market for exactly one profile without touching any peer. */
export function applyProfileMarketToggle<T extends { profiles?: Record<string, any> }>(
  input: T,
  profileId: string,
  baseMarketName: string,
  enabled: boolean,
  date: string,
): T {
  const pid = String(profileId || '').trim();
  const base = normalizeBaseMarketName(baseMarketName);
  const day = String(date || '').trim();
  const sourceProfile = input?.profiles?.[pid];
  if (!pid || !base || !day || !sourceProfile) {
    throw new Error('valid profile, market and date required');
  }

  const open = `${base} OPEN`;
  const close = `${base} CLOSE`;
  const oldDayStore = sourceProfile.dayRecords?.[day] || {};
  const nextProfile = {
    ...sourceProfile,
    dayRecords: {
      ...(sourceProfile.dayRecords || {}),
      [day]: {
        ...oldDayStore,
        visAnk: { ...(oldDayStore.visAnk || {}), [base]: enabled, [open]: enabled, [close]: enabled },
        visPan: { ...(oldDayStore.visPan || {}), [base]: enabled, [open]: enabled, [close]: enabled },
        visJodi: { ...(oldDayStore.visJodi || {}), [base]: enabled },
      },
    },
  };

  return {
    ...input,
    profiles: { ...(input.profiles || {}), [pid]: nextProfile },
  };
}

/** Daily visibility and 5/6/7-day weekday schedule win; legacy global config is only the no-daily-value fallback. */
export function isMarketEnabledForDate(
  config: any,
  visibility: Record<string, boolean> | undefined,
  marketName: string,
  dateStr?: string,
): boolean {
  const name = String(marketName || '').trim().toUpperCase();
  if (dateStr && !isMarketOpenOnDate(name, dateStr)) {
    return false;
  }
  if (visibility && Object.prototype.hasOwnProperty.call(visibility, name)) {
    return visibility[name] !== false;
  }
  return isMarketEnabled(config, name);
}

export function setRuntimeMarketEnabled<T extends { n?: string; enabled?: boolean }>(
  markets: T[] | undefined,
  baseMarketName: string,
  enabled: boolean,
): T[] {
  const base = normalizeBaseMarketName(baseMarketName);
  const names = new Set([base, `${base} OPEN`, `${base} CLOSE`]);
  return (markets || []).map((market) =>
    names.has(String(market?.n || '').trim().toUpperCase()) ? { ...market, enabled } as T : market,
  );
}

