import {applyCarryResultSix} from './carryResultSix';
import {modelSourceVersion} from './marketModelCard';
import {holdBacktestSelection} from './backtestSelectionHold';
import {canReplaceLiveCombinedDecision,releaseLiveCombinedDecision} from './liveCombinedDecision';
import type {DayMarketRecord} from '../types';
import {getScrapeSource} from './scrapeProvenance';
import {isMirrorProtected} from './adminMirror';
const canonical=(value: string)=>value.split(/[,|\s]+/).filter(Boolean).join(', ');
/** Restores the saved source for any selection mode, without editing committed bets. */
export function selectionUndoSource(record: DayMarketRecord | undefined): string | undefined {
  if(!record || !canReplaceLiveCombinedDecision(record) || isMirrorProtected(record) || record.dispatchState) return undefined;
  const carried=record.carryResultSix&&record.d===record.carryResultSix.output&&modelSourceVersion(record)===record.carryResultSix.outputVersion?record.carryResultSix.input:undefined;
  const source=String(record.od || getScrapeSource(record)?.digits || carried?.od || getScrapeSource(carried)?.digits || carried?.d || '').trim();
  if(!source) return undefined;
  if(!record.trick && !record.positionRule && canonical(source)===canonical(record.d||''))return undefined;
  return source;
}
export function undoSelection(record: DayMarketRecord | undefined,date?:string): DayMarketRecord | undefined {
  const source=selectionUndoSource(record);if(!record||!source)return undefined;
  const base=record.carryResultSix&&record.d===record.carryResultSix.output&&modelSourceVersion(record)===record.carryResultSix.outputVersion?applyCarryResultSix(record,[],false):record;
  const next={...base,d:source,sourceEditedAt:Math.max(Date.now(),modelSourceVersion(record)+1,modelSourceVersion(base)+1)};
  releaseLiveCombinedDecision(next);
  delete next.autoRemovedResult;delete next.autoResultParity;delete next.firstDigitMirrorCut;delete next.triCut;delete next.sniperOne;delete next.tesla369;
  delete next.smartSelection;delete next.mssdState;
  delete next.trick;delete next.positionRule;delete next.weekdaySelectedDigits;delete next.weekdayHitPosition;
  delete next.marketModel;delete next.strictPanel30;delete next.scrapeResultDigit;
  if(next.backtestResult || next.s==='SKIP')next.s='WAIT';
  delete next.backtestResult;delete next.manualResult;delete next.manualResultSources;
  if(!next.manualRate){delete next.recRate;delete next.prevLoss;delete next.targetProfitWithLoss;delete next.rateFinalizedFrom;delete next.rateFinalizedAt;}
  return holdBacktestSelection(next,date);
}
