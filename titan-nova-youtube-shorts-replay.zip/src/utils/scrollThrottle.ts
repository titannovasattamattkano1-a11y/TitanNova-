/** At most one trailing layout read per interval; never retain React events. */
export function createScrollThrottle(run:(element:HTMLElement)=>void,delay=120){
 let timer:ReturnType<typeof setTimeout>|undefined,last:HTMLElement|undefined;
 return {schedule(element:HTMLElement){last=element;if(timer!==undefined)return;timer=setTimeout(()=>{timer=undefined;const target=last;last=undefined;if(target?.isConnected)run(target);},delay);},cancel(){if(timer!==undefined)clearTimeout(timer);timer=undefined;last=undefined;}};
}
