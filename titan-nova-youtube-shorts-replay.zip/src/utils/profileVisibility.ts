export type VisibilityTrack = 'visAnk' | 'visJodi' | 'visPan';
export interface VisibilityUpdate { trackDict: VisibilityTrack; marketName: string; enabled: boolean; }

const validTrack = (value: unknown): value is VisibilityTrack =>
  value === 'visAnk' || value === 'visJodi' || value === 'visPan';

export function normalizeVisibilityUpdates(values: unknown): VisibilityUpdate[] {
  if (!Array.isArray(values)) return [];
  const deduped = new Map<string, VisibilityUpdate>();
  for (const raw of values) {
    const trackDict = (raw as any)?.trackDict;
    const marketName = String((raw as any)?.marketName || '').trim().replace(/\s+/g, ' ').toUpperCase();
    const enabled = (raw as any)?.enabled;
    if (!validTrack(trackDict) || !marketName || typeof enabled !== 'boolean') continue;
    deduped.set(`${trackDict}|${marketName}`, { trackDict, marketName, enabled });
  }
  return [...deduped.values()];
}

export function applyProfileVisibilityUpdates<T extends { profiles?: Record<string, any> }>(
  input: T, profileId: string, date: string, rawUpdates: unknown,
): T {
  const pid = String(profileId || '').trim();
  const day = String(date || '').trim();
  const profile = input?.profiles?.[pid];
  const updates = normalizeVisibilityUpdates(rawUpdates);
  if (!pid || !/^\d{4}-\d{2}-\d{2}$/.test(day) || !profile || updates.length === 0) {
    throw new Error('valid profile, date and visibility updates required');
  }
  const oldDay = profile.dayRecords?.[day] || {};
  const nextDay = { ...oldDay };
  for (const update of updates) {
    nextDay[update.trackDict] = { ...(nextDay[update.trackDict] || {}), [update.marketName]: update.enabled };
  }
  return {
    ...input,
    profiles: {
      ...(input.profiles || {}),
      [pid]: { ...profile, dayRecords: { ...(profile.dayRecords || {}), [day]: nextDay } },
    },
  };
}

export function applyRuntimeVisibilityUpdates<T extends { n?: string; type?: string; enabled?: boolean }>(
  markets: T[] | undefined, rawUpdates: unknown,
): T[] {
  const typeFor: Record<VisibilityTrack, string> = { visAnk: 'ank', visJodi: 'jodi', visPan: 'pannel' };
  const map = new Map(normalizeVisibilityUpdates(rawUpdates).map((u) => [`${typeFor[u.trackDict]}|${u.marketName}`, u.enabled]));
  return (markets || []).map((market) => {
    const key = `${String(market?.type || '').toLowerCase()}|${String(market?.n || '').trim().toUpperCase()}`;
    return map.has(key) ? { ...market, enabled: map.get(key)! } as T : market;
  });
}
