import type {UserProfile} from '../types';
import {getEffectiveMarkets,getEffectiveBaseMarkets} from '../data/markets';
import {findHistoricalMarketRecord} from './cardHistory';
import {loopAssignmentKey,validLoopDate,type LoopId} from './dualLoops';
import {isMarketEnabledForDate} from './profileMarketToggle';
export type YesterdayLoopOutcome='FAIL'|'PASS'|'MISSING';
/** Last settled outcome in the previous seven calendar days, independently per card. */
export function yesterdayLoopGroups(profile:UserProfile,date:string):{sourceDate:string;outcomes:Record<string,YesterdayLoopOutcome>;sourceDates:Record<string,string>} {
 if(!validLoopDate(date))throw new Error('Choose a valid Ledger date.');
 const sourceDate=new Date(Date.parse(date+'T00:00:00Z')-86400000).toISOString().slice(0,10);
 const outcomes:Record<string,YesterdayLoopOutcome>={},sourceDates:Record<string,string>={};
 for(const type of ['ank','jodi','pannel'] as const){
  const markets=type==='jodi'?getEffectiveBaseMarkets(profile.config):getEffectiveMarkets(profile.config);
  const dict=type==='ank'?'data':type==='jodi'?'jodiData':'pannelData';
  markets.forEach((market,index)=>{
   const key=loopAssignmentKey(type,market.n);
   outcomes[key]='MISSING';
   for(let offset=1;offset<=7;offset++){
    const previousDate=new Date(Date.parse(date+'T00:00:00Z')-offset*86400000).toISOString().slice(0,10);
    const rec=findHistoricalMarketRecord(profile.dayRecords?.[previousDate]?.[dict],index,market.n);
    if(rec?.s!=='PASS'&&rec?.s!=='FAIL')continue;
    outcomes[key]=rec.s;sourceDates[key]=previousDate;break;
   }
  });
 }
 return {sourceDate,outcomes,sourceDates};
}

import {normalizeDualLoops,isLoopAssignmentFrozen,hasCommittedInactiveLoop,type DualLoopConfig} from './dualLoops';
import {calculateBacktestRecovery} from './backtestRecovery';
/** Walk actual timetable once. Prefer the expected category, then balance count and gap. */
export function mixedYesterdayAssignments(profile:UserProfile,date:string,outcomes:Record<string,YesterdayLoopOutcome>):{assignments:Record<string,LoopId>;repeats:number} {
 const assignments:Record<string,LoopId>={};let repeats=0;
 const day=profile.dayRecords?.[date];
 for(const type of ['ank','jodi','pannel'] as const){
  const dict=type==='ank'?'data':type==='jodi'?'jodiData':'pannelData';
  const vis=type==='ank'?'visAnk':type==='jodi'?'visJodi':'visPan';
  const visibility={...(day?.[vis]||{})};
  const markets=type==='jodi'?getEffectiveBaseMarkets(profile.config):getEffectiveMarkets(profile.config);
  const time=(m:typeof markets[number])=>{const hour=m.hr??0;return hour*60+(m.min??0)+(hour<6?1440:0);};
  const tracks:Record<'L1'|'L2'|'L3',{want?:'PASS'|'FAIL';count:number;last:number}>={L1:{want:'PASS',count:0,last:-Infinity},L2:{want:'FAIL',count:0,last:-Infinity},L3:{count:0,last:-Infinity}};
  markets.map((m,i)=>({m,i})).sort((a,b)=>time(a.m)-time(b.m)||a.i-b.i).forEach(({m,i})=>{
   const key=loopAssignmentKey(type,m.n),outcome=outcomes[key];
   const previous=day?.yesterdayLoopSetup?.priorVisibility;
   if(previous && Object.prototype.hasOwnProperty.call(previous,key)){
    if(previous[key]===null)delete visibility[m.n];else visibility[m.n]=previous[key]!;
   }
   if(!outcome || outcome==='MISSING' || !isMarketEnabledForDate(profile.config,visibility,m.n,date))return;
   const rec=findHistoricalMarketRecord(day?.[dict],i,m.n);
   const frozen=isLoopAssignmentFrozen(rec)?rec?.sentLoopId||rec?.loopId:undefined;
   const candidates=(['L1','L2','L3'] as const).slice().sort((a,b)=>
    Number(tracks[a].want!==undefined&&tracks[a].want!==outcome)-Number(tracks[b].want!==undefined&&tracks[b].want!==outcome)||tracks[a].count-tracks[b].count||tracks[a].last-tracks[b].last||a.localeCompare(b));
   const id=frozen==='L1'||frozen==='L2'||frozen==='L3'?frozen:candidates[0];
   if(tracks[id].count && tracks[id].want!==outcome)repeats++;
   assignments[key]=id;tracks[id].count++;tracks[id].last=time(m);tracks[id].want=outcome==='PASS'?'FAIL':'PASS';
  });
 }
 return {assignments,repeats};
}

/** Explicit one-day preset. Does not replace the persistent live default. */
export function applyYesterdayLoopGroups(profile:UserProfile,date:string,draft:DualLoopConfig,backtest:boolean):UserProfile {
 for(const id of ['L1','L2','L3'] as const){
  const loop=draft.loops[id];
  const amounts=[loop.capital,loop.dayTarget,...(['ank','jodi','pannel'] as const).flatMap(type=>[loop[type].cap,loop[type].tgt])];
  if(amounts.some(value=>!Number.isFinite(value)||value<0))throw new Error('Loop capital and targets must be zero or greater.');
 }
 const {sourceDate,outcomes,sourceDates}=yesterdayLoopGroups(profile,date);
 const {assignments,repeats}=mixedYesterdayAssignments(profile,date,outcomes);
 const config=normalizeDualLoops({...draft,enabled:true,loopCount:3,startsOn:date,assignments},profile.config)!;
 const original=profile.dayRecords?.[date]||{};
 if(hasCommittedInactiveLoop(original,config))throw new Error('This date has committed cards outside L1–L3. Their actual loop must stay active. Choose an uncommitted date for this 3-loop preset.');
 const day={...original,loopConfig:{...config,revision:Math.max(Date.now(),Number(original.loopConfig?.revision||0)+1)}};
 const prior={...(original.yesterdayLoopSetup?.priorVisibility||{})};
 for(const type of ['ank','jodi','pannel'] as const){
  const dict=type==='ank'?'data':type==='jodi'?'jodiData':'pannelData';
  const vis=type==='ank'?'visAnk':type==='jodi'?'visJodi':'visPan';
  const visibility={...(original[vis]||{})};
  const markets=type==='jodi'?getEffectiveBaseMarkets(profile.config):getEffectiveMarkets(profile.config);
  day[dict]=Object.fromEntries(Object.entries(original[dict]||{}).map(([i,rec])=>{
   if(isLoopAssignmentFrozen(rec))return [i,rec];
   const next={...rec};delete next.loopId;delete next.sentLoopId;
   if(!next.manualRate){delete next.recRate;delete next.prevLoss;delete next.targetProfitWithLoss;delete next.rateFinalizedFrom;delete next.rateFinalizedAt;}
   return [i,next];
  }));
  markets.forEach(m=>{
   const key=loopAssignmentKey(type,m.n);
   if(Object.prototype.hasOwnProperty.call(prior,key)){
    if(prior[key]===null)delete visibility[m.n];else visibility[m.n]=prior[key]!;
    delete prior[key];
   }
   if(outcomes[key]==='MISSING'){
    prior[key]=Object.prototype.hasOwnProperty.call(visibility,m.n)?visibility[m.n]:null;
    visibility[m.n]=false;
   }
  });
  day[vis]=visibility;
 }
 day.yesterdayLoopSetup={sourceDate,sourceDates,priorVisibility:prior,mixed:true,loopCount:3,repeats};
 const next={...profile,dayRecords:{...profile.dayRecords,[date]:day}};
 return backtest?calculateBacktestRecovery(next,date):next;
}
