import {resolveChartSource} from './chartSource';
import type {DayMarketRecord,MarketItem,ProfileConfig,UserProfile} from '../types';
import {CHART_LINKS,getEffectiveMarkets,getEffectiveBaseMarkets} from '../data/markets';
import {remapCardReferences} from './cardReferences';
const name=(v:unknown)=>String(v||'').trim().replace(/\s+/g,' ').toUpperCase().replace(/^(?:SHRIDEVI|SRIDEVI|SRIDEV) DAY\b/,'SRIDEVI');
export function remapMarketRecords(records:Record<string,DayMarketRecord>|undefined,oldMarkets:MarketItem[],newMarkets:MarketItem[]) {
 const result:Record<string,DayMarketRecord>={},keys:Record<string,string>={};
 const indices=new Map(newMarkets.map((m,i)=>[name(m.n),i]));let orphan=-1;
 for(const [key,rec] of Object.entries(records||{})){
  const identity=name(rec.marketName||oldMarkets[Number(key)]?.n);
  let next=identity?indices.get(identity):undefined;
  if(next===undefined){while(result[String(orphan)])orphan--;next=orphan--;}
  const stored={...rec,...(identity?{marketName:identity}:{})};
  if(next<0 && stored.dispatchState==='QUEUED' && !stored.sentRate && !stored.sentDigits){delete stored.dispatchState;delete stored.dispatchKey;delete stored.queuedAt;}
  result[String(next)]=stored;keys[key]=String(next);
 }
 return {records:result,keys};
}
/** UI-only inspector for immutable React record dictionaries. Never used by mutable server flows. */
export function createCatalogInspector(){
 const checked=new WeakMap<object,{signature:string;misplaced:boolean}>();
 return (records:Record<string,DayMarketRecord>|undefined,indices:Map<string,number>,signature:string):boolean=>{
  if(!records)return false;
  const previous=checked.get(records);if(previous?.signature===signature)return previous.misplaced;
  const misplaced=Object.entries(records).some(([key,rec])=>{if(!rec.marketName)return false;const index=indices.get(name(rec.marketName));return index===undefined?Number(key)>=0:index!==Number(key);});
  checked.set(records,{signature,misplaced});return misplaced;
 };
}
/** Records follow names through insertion/deletion/time edits; hidden records remain recoverable. */
export function updateProfileMarketCatalog(profile:UserProfile,config:ProfileConfig,inspect?:ReturnType<typeof createCatalogInspector>):UserProfile {
 const before=getEffectiveMarkets(profile.config),after=getEffectiveMarkets(config),oldBase=getEffectiveBaseMarkets(profile.config),newBase=getEffectiveBaseMarkets(config);
 // Migrate positional schedule settings before changing the catalog. Retain hidden
 // settings under type+market identity, then rebuild only current positional aliases.
 const scheduleFields=['marketScheduleTimes','marketScheduleTargets'] as const;
 for(const field of scheduleFields){
  const source=config[field];if(!source)continue;
  const named:Record<string,any>={...source};
  for(const [type,oldList] of [['ank',before],['pannel',before],['jodi',oldBase]] as const){
   oldList.forEach((m,i)=>{const positional=`${type}_${i}`,identity=`${type}:market:${name(m.n)}`;
    if(Object.prototype.hasOwnProperty.call(source,positional))named[identity]=source[positional];
   });
  }
  for(const key of Object.keys(named))if(/^(ank|jodi|pannel)_-?\d+$/.test(key))delete named[key];
  for(const [type,newList] of [['ank',after],['pannel',after],['jodi',newBase]] as const){
   newList.forEach((m,i)=>{const identity=`${type}:market:${name(m.n)}`;
    if(Object.prototype.hasOwnProperty.call(named,identity))named[`${type}_${i}`]=named[identity];
   });
  }
  if(JSON.stringify(source)!==JSON.stringify(named))config={...config,[field]:named};
 }
 const sameCatalog=JSON.stringify([before.map(m=>name(m.n)),oldBase.map(m=>name(m.n))])===JSON.stringify([after.map(m=>name(m.n)),newBase.map(m=>name(m.n))]);
 const dictionaries=([['data',after],['pannelData',after],['jodiData',newBase]] as const).map(([dict,list])=>({dict,indices:new Map(list.map((m,i)=>[name(m.n),i]))}));
 const signature=JSON.stringify([after.map(m=>name(m.n)),newBase.map(m=>name(m.n))]);
 const misplaced=Object.values(profile.dayRecords||{}).some(day=>dictionaries.some(({dict,indices})=>inspect?inspect(day[dict],indices,`${dict}:${signature}`):Object.entries(day[dict]||{}).some(([key,rec])=>{if(!rec.marketName)return false;const index=indices.get(name(rec.marketName));return index===undefined?Number(key)>=0:index!==Number(key);})));
 if(sameCatalog && !misplaced)return profile.config===config?profile:{...profile,config};
 const dayRecords={...profile.dayRecords};
 for(const [date,oldDay] of Object.entries(dayRecords)){
  const day={...oldDay};const references:Record<string,string>={};
  for(const [dict,type,oldList,newList] of [['data','ank',before,after],['pannelData','pannel',before,after],['jodiData','jodi',oldBase,newBase]] as const){
   const mapped=remapMarketRecords(day[dict],oldList,newList);day[dict]=mapped.records;
   for(const [oldKey,newKey] of Object.entries(mapped.keys))references[`${type}_${oldKey}`]=`${type}_${newKey}`;
  }
  for(const dict of ['data','pannelData','jodiData'] as const)for(const [index,rec] of Object.entries(day[dict]||{}))day[dict]![index]=remapCardReferences(rec,references);
  dayRecords[date]=day;
 }
 return {...profile,config,dayRecords};
}
export function runtimeCatalogChanged(old:any,incoming:any):boolean {
 const signature=(markets:any[])=>JSON.stringify((markets||[]).filter(m=>Number(m.index)>=0).map(m=>[m.type,Number(m.index),name(m.n)]));
 return Array.isArray(old?.markets)&&Array.isArray(incoming?.markets)&&signature(old.markets)!==signature(incoming.markets);
}
export function remapRuntimeCatalog(old:any,incoming:any):{profile:any;indexMap:Record<string,number>} {
 if(!runtimeCatalogChanged(old,incoming))return {profile:old,indexMap:{}};
 const markets=[...incoming.markets],cards:Record<string,any>={},indexMap:Record<string,number>={};
 const active=new Map(markets.map((m:any)=>[`${m.type}:${name(m.n)}`,Number(m.index)]));
 const nextOrphan:Record<string,number>={};
 for(const m of old.markets){
  let index=active.get(`${m.type}:${name(m.n)}`);
  if(index===undefined){index=nextOrphan[m.type]??-1;nextOrphan[m.type]=index-1;markets.push({...m,index,enabled:false});}
  const key=`${m.type}_${m.index}`,nextKey=`${m.type}_${index}`;indexMap[key]=index;
  if(old.cards?.[key])cards[nextKey]={...old.cards[key],marketName:name(m.n)};
 }
 const references=Object.fromEntries(Object.entries(indexMap).map(([key,index])=>[key,`${key.split('_')[0]}_${index}`]));
 for(const key of Object.keys(cards))cards[key]=remapCardReferences(cards[key],references);
 return {profile:{...old,markets,cards},indexMap};
}
export function remapScheduleIdentity(key:string,pid:string,date:string,indexMap:Record<string,number>):string {
 for(const type of ['ank','jodi','pannel'])for(const prefix of [`${pid}_${date}_${type}_`,`vipauto_${pid}_${date}_${type}_`]){
  if(!key.startsWith(prefix))continue;
  const match=key.slice(prefix.length).match(/^(-?\d+)(.*)$/);if(!match)continue;
  const next=indexMap[`${type}_${match[1]}`];if(next!==undefined)return prefix+next+match[2];
 }
 return key;
}
/** Custom definitions retain their URL even in legacy VIPs without a URL map. */
export function resolveMarketScrapeUrl(config:Partial<ProfileConfig>|undefined,marketName:string):string|undefined {
 const identity=name(marketName),base=identity.replace(/\s+(OPEN|CLOSE)$/i,'');
 const urls=config?.marketScrapeUrls||{};
 const mapped=String(urls[identity]||urls[base]||'').trim();if(mapped)return resolveChartSource(identity,mapped,CHART_LINKS);
 const custom=config?.customMarkets||[];
 const item=custom.find(m=>name(m.n)===identity)||custom.find(m=>name(m.n).replace(/\s+(OPEN|CLOSE)$/i,'')===base);
 return resolveChartSource(identity,String(item?.scrapeUrl||'').trim()||undefined,CHART_LINKS);
}
