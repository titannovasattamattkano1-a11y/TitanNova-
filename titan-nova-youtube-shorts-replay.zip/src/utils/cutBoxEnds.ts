import type {DayMarketRecord} from '../types';
import {cutCurrentSourceDigits} from './cumulativeSourceCut';
/** Each click uses the remaining box order, never historical/original source positions. */
export function cutBoxEnds(record:DayMarketRecord|undefined):DayMarketRecord|undefined {
 const current=String(record?.d||'').split(/[,|\s]+/).filter(Boolean);
 if(!current.length||new Set(current).size!==current.length||!current.every(d=>/^\d$/.test(d)))return undefined;
 return cutCurrentSourceDigits(record,[current[0],current[current.length-1]],'CUT2');
}
