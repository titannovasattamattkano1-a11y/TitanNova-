import type { DatedJodi } from './smartWeekday';

export type AnkSide = 'open' | 'close';
export interface WeekdayVerticalSelection {
  digits: string[];
  weekday: number;
  weekdayName: string;
  side: AnkSide | 'combo';
  samplesRead: number;
  weekdaySamples: number;
  fallbackSamples: number;
}
const WEEKDAYS = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];

/** Read the target weekday column newest-to-oldest; exclude target/future rows. */
export function selectSameWeekdayVerticalDigits(
  draws: DatedJodi[], targetDate: string, side: AnkSide, maxSamples = 60, allowPartial = false,
): WeekdayVerticalSelection | null {
  return selectWeekdayDigits(draws, targetDate, side, maxSamples, allowPartial);
}

/** Same weekday priority, reading CLOSE then OPEN before moving to an older day. */
export function selectSameWeekdayVerticalComboDigits(
  draws: DatedJodi[], targetDate: string, maxSamples = 60, allowPartial = false,
): WeekdayVerticalSelection | null {
  return selectWeekdayDigits(draws, targetDate, 'combo', maxSamples, allowPartial);
}

function selectWeekdayDigits(
  draws: DatedJodi[], targetDate: string, side: AnkSide | 'combo', maxSamples: number, allowPartial: boolean,
): WeekdayVerticalSelection | null {
  const target = new Date(`${targetDate}T00:00:00Z`);
  if (Number.isNaN(target.getTime()) || target.toISOString().slice(0, 10) !== targetDate) return null;
  const weekday = target.getUTCDay();
  const sideIndex = side === 'close' ? 1 : 0;
  const eligible = draws
    .filter((draw) => /^\d{2}$/.test(draw.jodi) && /^\d{4}-\d{2}-\d{2}$/.test(draw.date))
    .filter((draw) => draw.date < targetDate)
    .sort((a, b) => b.date.localeCompare(a.date));
  const history = eligible
    .filter((draw) => new Date(`${draw.date}T00:00:00Z`).getUTCDay() === weekday)
    .slice(0, Math.max(1, Math.floor(maxSamples)));
  const digits: string[] = [];
  const append = (rows: DatedJodi[]) => {
    let read = 0;
    for (const draw of rows) {
      read += 1;
      const candidates = side === 'combo' ? [draw.jodi[1], draw.jodi[0]] : [draw.jodi[sideIndex]];
      for (const digit of candidates) {
        if (/^\d$/.test(digit) && !digits.includes(digit)) digits.push(digit);
        if (digits.length === 10) break;
      }
      if (digits.length === 10) break;
    }
    return read;
  };
  append(history);

  // Some markets legitimately miss one digit in the same-weekday column even
  // though their full chart has it. Preserve weekday order first, then fill
  // only from the SAME OPEN/CLOSE side for Day, or CLOSE→OPEN pairs for Day Combo.
  const weekdayDates = new Set(history.map((draw) => draw.date));
  const fallbackHistory = eligible.filter((draw) => !weekdayDates.has(draw.date));
  const fallbackSamples = digits.length < 10 ? append(fallbackHistory) : 0;

  return digits.length === 10 || (allowPartial && digits.length > 0)
    ? {
        digits, weekday, weekdayName: WEEKDAYS[weekday], side,
        samplesRead: history.length + fallbackSamples,
        weekdaySamples: history.length,
        fallbackSamples,
      }
    : null;
}
