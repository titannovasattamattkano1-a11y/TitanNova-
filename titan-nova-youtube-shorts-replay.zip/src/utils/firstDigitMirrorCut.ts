import type {DayMarketRecord} from '../types';
import {isMirrorProtected} from './adminMirror';
import {getScrapeSource} from './scrapeProvenance';
import {modelSourceVersion} from './marketModelCard';
import {canReplaceLiveCombinedDecision,releaseLiveCombinedDecision} from './liveCombinedDecision';
/** Each click cuts only the first current digit; never its mirror or a restored source digit. */
export function cutFirstDigit(record:DayMarketRecord|undefined):DayMarketRecord|undefined {
  if(!record||record.s!=='WAIT'||record.manualStatus||record.deliveryRestoredAt||record.dispatchState||isMirrorProtected(record)||!canReplaceLiveCombinedDecision(record))return;
  const current=record.d.split(/[,|\s]+/).filter(Boolean);
  if(!current.length||new Set(current).size!==current.length||!current.every(d=>/^\d$/.test(d)))return;
  const source=getScrapeSource(record);
  const next:DayMarketRecord={...record,d:current.slice(1).join(', '),od:source?.digits||record.od||record.d,positionRule:'FIRST_CUT',sourceEditedAt:Math.max(Date.now(),modelSourceVersion(record)+1)};
  releaseLiveCombinedDecision(next);
  delete next.firstDigitMirrorCut;delete next.tesla369;delete next.triCut;delete next.sniperOne;delete next.trick;delete next.weekdaySelectedDigits;delete next.weekdayHitPosition;
  delete next.scrapeResultDigit;delete next.manualResult;delete next.manualResultSources;delete next.backtestResult;
  delete next.marketModel;delete next.autoRemovedResult;delete next.autoResultParity;delete next.smartSelection;
  if(!next.manualRate){delete next.recRate;delete next.prevLoss;delete next.targetProfitWithLoss;delete next.rateFinalizedFrom;delete next.rateFinalizedAt;}
  return next;
}
/** Compatibility name for old imports; mirror-stage behavior has been replaced. */
export const cutFirstDigitThenMirror=cutFirstDigit;
