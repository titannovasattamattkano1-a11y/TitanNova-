import { normalizeManualResult } from './manualResult';
import { panelAnkDigit } from './panelAnk';

export interface LinkedResult {
  type: 'ank' | 'jodi' | 'pannel';
  index: number;
  result: string;
  sources: string[];
  openOnly?: boolean;
}

/** Actual results only; an ANK never identifies a unique drawn Patti. */
export function linkedManualResults(
  markets: Array<{ type?: string; index?: number; n?: string; enabled?: boolean }>,
  cards: Record<string, any>, type: string, index: number, result: string, panelResult?: string,
): LinkedResult[] {
  const origin = markets.find(m => m.type === type && Number(m.index) === index);
  const name = String(origin?.n || '').trim().toUpperCase();
  const match = /^(.*?)\s+(OPEN|CLOSE)$/.exec(name);
  if (!match || (type !== 'ank' && type !== 'pannel')) return [];
  const [, base, side] = match;
  const key = `${type}_${index}`;
  const targets: LinkedResult[] = [];
  const find = (t: string, n: string) => markets.find(m => m.type === t && String(m.n || '').trim().toUpperCase() === n && m.enabled !== false);
  const actualAnk = type === 'ank' ? normalizeManualResult('ank', result) : panelAnkDigit(result);
  if (!actualAnk) return [];
  const ank = find('ank', name);
  if (type === 'pannel' && ank) targets.push({ type: 'ank', index: Number(ank.index), result: actualAnk, sources: [key] });
  const panel = find('pannel', name);
  if (type === 'ank' && panel && panelResult) targets.push({ type: 'pannel', index: Number(panel.index), result: panelResult, sources: [key] });
  const jodi = find('jodi', base);
  if (!jodi) return targets;
  const otherSide = side === 'OPEN' ? 'CLOSE' : 'OPEN';
  const other = find('ank', `${base} ${otherSide}`);
  const otherKey = other ? `ank_${other.index}` : '';
  const rec = cards[otherKey];
  const otherResult = rec && (rec.s === 'PASS' || rec.s === 'FAIL')
    ? normalizeManualResult('ank', rec.manualStatus ? rec.manualResult : rec.scrapeResultDigit) : undefined;
  const sources = [...new Set([key, ...(ank ? [`ank_${ank.index}`] : []), ...(otherResult ? [otherKey] : [])])];
  if (otherResult) {
    const pair = side === 'OPEN' ? `${actualAnk}${otherResult}` : `${otherResult}${actualAnk}`;
    targets.push({ type: 'jodi', index: Number(jodi.index), result: pair, sources });
  } else if (side === 'OPEN') {
    targets.push({ type: 'jodi', index: Number(jodi.index), result: actualAnk, sources, openOnly: true });
  }
  return targets;
}
