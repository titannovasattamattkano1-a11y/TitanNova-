import { apiUrl } from './api';
import { readTelegramKey } from './telegramCredentialStorage';
export const telegramKey = readTelegramKey;
export async function telegramApi(route: string, body?: unknown) {
  const response = await fetch(apiUrl(`/api/telegram/${route}`), {
    method: body === undefined ? 'GET' : 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Titan-Telegram-Key': telegramKey() },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const json = await response.json();
  if (!response.ok || json.status !== 'success') throw new Error(json.message || 'Telegram request failed');
  return json;
}
