/** Existing 06:00 business-day clock, normal grace and recovery-release window. */
export function scheduleWindowAllowed(time:string,nowTime:string,grace:number,recoveryWaiting=false):boolean{
  const minutes=(value:string)=>{const match=/^(\d{1,2}):(\d{2})$/.exec(value);if(!match)return -1;const h=Number(match[1]),m=Number(match[2]);return h>23||m>59?-1:(h<6?h+24:h)*60+m;};
  const start=minutes(time),now=minutes(nowTime);
  return start>=0&&now>=start&&(now<=start+grace||(recoveryWaiting&&now<=start+60));
}
