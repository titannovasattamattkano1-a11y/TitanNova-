export type SaveStatus = { phase: 'saved' | 'pending' | 'saving' | 'error'; message?: string };
export class StateSaveError extends Error {
  constructor(message: string, readonly retryable: boolean) { super(message); }
}
/** One idempotent full-state save at a time. Only the latest pending snapshot retries. */
export class ReliableStateSaver {
  private desired = '';
  private confirmed = '';
  private timer: ReturnType<typeof setTimeout> | undefined;
  private running: Promise<void> | undefined;
  private failures = 0;
  private stopped = false;
  private blocked = false;
  // Continuous background updates must not postpone a save indefinitely.
  private pendingSince = 0;
  constructor(private readonly save: (json: string) => Promise<void | string>, private readonly status: (value: SaveStatus) => void,
    private readonly debounceMs = 700, private readonly retryMs = 5000, private readonly maxWaitMs = 5000) {}
  seed(json: string) { this.confirmed = json; if (!this.desired) this.desired = json; if (this.desired === this.confirmed) this.pendingSince = 0; }
  /** A verified server refresh is already saved; never echo it as a new upload. */
  adoptRemote(confirmed: string, pending: string) {
    if (this.stopped) return;
    this.confirmed = confirmed; this.desired = pending;
    this.pendingSince = pending === confirmed ? 0 : Date.now();
    this.status({phase: pending === confirmed ? 'saved' : 'pending'});
    if (!this.running) this.schedule(this.debounceMs);
  }
  update(json: string) {
    if (this.stopped) return;
    if (json === this.desired) return;
    this.desired = json;
    if (json === this.confirmed) this.pendingSince = 0;
    else if (!this.pendingSince) this.pendingSince = Date.now();
    if (this.blocked) return;
    this.status({phase: json === this.confirmed ? 'saved' : 'pending'});
    this.schedule(this.debounceMs);
  }
  private schedule(delay: number) {
    clearTimeout(this.timer);
    if (this.stopped || this.blocked || this.desired === this.confirmed || this.running) return;
    // Max-wait applies only to successful debounce, never retry backoff.
    // When a save is running, its finally handler schedules the latest state.
    const boundedDelay = this.failures || !this.pendingSince
      ? delay
      : Math.min(delay, Math.max(0, this.maxWaitMs - (Date.now() - this.pendingSince)));
    this.timer = setTimeout(() => { void this.flush().catch(() => {}); }, boundedDelay);
  }
  async flush(): Promise<void> {
    clearTimeout(this.timer);
    if (this.running) { await this.running; return this.flush(); }
    if (this.stopped || !this.desired || this.desired === this.confirmed) return;
    if (this.blocked) throw new StateSaveError('Save blocked. Check the error before retrying.', false);
    const sent = this.desired;
    this.status({phase:'saving'});
    this.running = this.save(sent).then((accepted) => {
      const confirmed = typeof accepted === 'string' ? accepted : sent;
      if (this.desired === sent) this.desired = confirmed;
      this.confirmed = confirmed; this.failures = 0;
      if (this.desired === this.confirmed) this.pendingSince = 0;
      else if (!this.pendingSince) this.pendingSince = Date.now();
      if (!this.stopped) this.status({phase:this.desired === this.confirmed ? 'saved' : 'pending'});
    }).catch(error => {
      this.failures++;
      this.blocked = error instanceof StateSaveError && !error.retryable;
      if (!this.stopped) this.status({phase:'error',message:error instanceof Error ? error.message : 'Save failed'});
      throw error;
    }).finally(() => {
      this.running = undefined;
      this.schedule(this.failures ? Math.min(60000, this.retryMs * 2 ** Math.min(this.failures - 1, 4)) : this.debounceMs);
    });
    await this.running;
    if (this.desired !== this.confirmed) await this.flush();
  }
  retry() { this.blocked = false; this.failures = 0; void this.flush().catch(() => {}); }
  get dirty() { return this.desired !== this.confirmed; }
  dispose() { this.stopped = true; clearTimeout(this.timer); }
}
