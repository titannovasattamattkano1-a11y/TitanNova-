export type WeekdayPositionSide = 'open' | 'close';
export type WeekdayPositionPair = { open: number[]; close: number[] };

type MarketWeekdayPositions = Record<string, Partial<Record<string, WeekdayPositionPair>>>;

// Walk-forward backtest selections: older 70% chose the positions, recent 30% validated them.
// Markets whose primary page had short history were calibrated from verified long alternate archives.
export const WEEKDAY_MARKET_POSITIONS: MarketWeekdayPositions = {
  'SRIDEVI': {
    MON: { open: [1,2,3,4,5,7], close: [1,2,5,7,9,10] },
    TUE: { open: [1,2,4,5,7,9], close: [1,2,6,7,8,9] },
    WED: { open: [1,2,4,5,6,7], close: [1,3,4,5,6,7] },
    THU: { open: [1,2,3,5,6,10], close: [1,2,3,6,8,10] },
    FRI: { open: [1,3,5,6,8,9], close: [3,5,7,8,9,10] },
    SAT: { open: [1,3,4,6,9,10], close: [1,2,3,4,7,8] },
    SUN: { open: [1,2,5,7,8,9], close: [2,4,6,8,9,10] },
  },
  'TIME BAZAR': {
    MON: { open: [1,2,3,5,8,10], close: [2,3,5,6,7,9] },
    TUE: { open: [2,3,5,6,9,10], close: [1,2,6,7,9,10] },
    WED: { open: [1,2,3,6,8,10], close: [4,5,6,7,9,10] },
    THU: { open: [1,4,5,6,7,10], close: [1,3,5,7,8,10] },
    FRI: { open: [1,3,4,5,7,10], close: [3,4,6,7,8,9] },
    SAT: { open: [2,3,5,7,8,10], close: [2,4,5,6,7,8] },
  },
  'MADHUR DAY': {
    MON: { open: [3,4,6,7,8,9], close: [1,2,5,6,8,9] },
    TUE: { open: [1,2,5,8,9,10], close: [1,3,4,7,9,10] },
    WED: { open: [1,2,4,6,9,10], close: [2,5,6,8,9,10] },
    THU: { open: [3,5,7,8,9,10], close: [4,5,6,7,8,10] },
    FRI: { open: [1,3,5,6,9,10], close: [1,3,6,7,8,10] },
    SAT: { open: [3,4,5,7,8,10], close: [4,5,6,8,9,10] },
    SUN: { open: [1,3,6,7,8,9], close: [2,3,5,6,7,9] },
  },
  'MILAN DAY': {
    MON: { open: [2,4,5,7,8,9], close: [2,3,4,6,8,9] },
    TUE: { open: [2,3,5,7,8,10], close: [1,4,5,8,9,10] },
    WED: { open: [2,4,6,7,8,9], close: [1,2,3,4,8,9] },
    THU: { open: [1,4,6,7,9,10], close: [3,4,6,7,8,10] },
    FRI: { open: [2,3,5,7,8,9], close: [1,4,7,8,9,10] },
    SAT: { open: [1,2,3,4,8,9], close: [2,4,5,7,8,9] },
  },
  'RAJDHANI DAY': {
    MON: { open: [1,2,6,7,9,10], close: [2,3,4,7,8,10] },
    TUE: { open: [1,2,4,6,8,9], close: [1,4,5,7,9,10] },
    WED: { open: [1,2,3,6,7,8], close: [1,2,3,4,6,8] },
    THU: { open: [2,3,5,7,9,10], close: [1,2,4,5,8,9] },
    FRI: { open: [1,2,4,8,9,10], close: [2,4,5,6,7,10] },
    SAT: { open: [1,3,6,7,8,9], close: [1,2,5,6,7,10] },
  },
  'SUPREME DAY': {
    MON: { open: [1,2,5,6,7,8], close: [1,2,3,4,6,7] },
    TUE: { open: [1,2,3,4,7,10], close: [1,2,4,6,8,10] },
    WED: { open: [1,2,3,4,5,7], close: [1,3,4,6,7,9] },
    THU: { open: [1,3,4,5,7,10], close: [1,2,3,5,7,9] },
    FRI: { open: [1,2,4,6,8,10], close: [1,3,4,6,7,9] },
    SAT: { open: [1,3,5,6,7,9], close: [1,2,3,7,9,10] },
    SUN: { open: [1,3,4,5,7,10], close: [2,3,5,6,8,9] },
  },
  KALYAN: {
    MON: { open: [1,2,5,8,9,10], close: [2,4,5,6,9,10] },
    TUE: { open: [2,4,5,6,7,8], close: [2,3,5,7,9,10] },
    WED: { open: [1,3,6,7,8,9], close: [1,2,4,7,8,9] },
    THU: { open: [3,5,6,8,9,10], close: [1,4,6,7,8,10] },
    FRI: { open: [1,4,5,7,8,9], close: [4,5,6,8,9,10] },
    SAT: { open: [4,5,6,7,9,10], close: [1,2,3,5,7,8] },
  },
  'SRIDEVI NIGHT': {
    MON: { open: [1,2,3,6,7,10], close: [1,2,3,5,6,10] },
    TUE: { open: [1,2,5,6,8,9], close: [1,2,4,5,6,10] },
    WED: { open: [1,2,4,6,7,8], close: [1,3,5,6,7,9] },
    THU: { open: [1,3,4,5,8,9], close: [1,2,4,5,6,10] },
    FRI: { open: [1,2,3,6,8,10], close: [1,3,7,8,9,10] },
    SAT: { open: [1,2,5,8,9,10], close: [1,2,5,6,8,9] },
    SUN: { open: [3,4,5,6,7,8], close: [1,2,3,5,6,7] },
  },
  'MADHUR NIGHT': {
    MON: { open: [2,3,5,6,7,9], close: [3,4,6,7,8,9] },
    TUE: { open: [2,6,7,8,9,10], close: [1,3,6,7,8,9] },
    WED: { open: [4,5,6,7,9,10], close: [1,4,5,7,8,10] },
    THU: { open: [4,5,6,7,9,10], close: [2,4,6,7,8,10] },
    FRI: { open: [1,3,4,5,6,9], close: [5,6,7,8,9,10] },
    SAT: { open: [2,3,5,6,8,9], close: [2,4,5,6,8,10] },
  },
  'SUPREME NIGHT': {
    MON: { open: [2,3,4,5,6,9], close: [2,3,4,5,8,10] },
    TUE: { open: [1,2,3,4,5,9], close: [1,2,3,5,9,10] },
    WED: { open: [1,2,4,6,8,9], close: [1,3,5,7,9,10] },
    THU: { open: [1,2,4,5,8,10], close: [2,4,5,6,7,8] },
    FRI: { open: [1,2,3,4,5,7], close: [1,2,4,5,8,10] },
    SAT: { open: [1,2,3,6,8,9], close: [1,2,3,5,6,8] },
    SUN: { open: [1,2,6,7,9,10], close: [1,3,4,5,8,10] },
  },
  'MILAN NIGHT': {
    MON: { open: [1,3,4,6,7,8], close: [1,2,3,4,5,9] },
    TUE: { open: [2,4,6,7,8,10], close: [2,3,4,5,7,8] },
    WED: { open: [1,3,4,7,8,9], close: [1,3,6,7,9,10] },
    THU: { open: [1,4,6,7,8,10], close: [2,4,5,7,8,9] },
    FRI: { open: [2,4,6,8,9,10], close: [3,4,6,7,8,9] },
    SAT: { open: [1,2,3,4,7,10], close: [1,3,4,5,9,10] },
  },
  'KALYAN NIGHT': {
    MON: { open: [1,3,7,8,9,10], close: [1,4,5,7,8,9] },
    TUE: { open: [1,2,3,4,7,8], close: [4,5,6,7,8,9] },
    WED: { open: [1,2,3,4,8,9], close: [1,2,5,6,8,9] },
    THU: { open: [2,4,5,6,7,10], close: [2,3,6,7,8,10] },
    FRI: { open: [2,3,5,6,8,9], close: [2,3,7,8,9,10] },
  },
  'RAJDHANI NIGHT': {
    MON: { open: [1,3,7,8,9,10], close: [1,4,5,7,8,9] },
    TUE: { open: [1,2,3,4,7,8], close: [4,5,6,7,8,9] },
    WED: { open: [1,2,3,4,8,9], close: [1,2,5,6,8,9] },
    THU: { open: [2,4,5,6,7,10], close: [2,3,6,7,8,10] },
    FRI: { open: [2,3,5,6,8,9], close: [2,3,7,8,9,10] },
  },
  'MAIN BAZAR': {
    MON: { open: [1,2,3,5,7,9], close: [3,4,5,7,9,10] },
    TUE: { open: [1,2,4,6,8,10], close: [1,2,3,5,7,10] },
    WED: { open: [1,3,4,6,8,10], close: [2,4,5,6,7,9] },
    THU: { open: [1,2,3,4,6,8], close: [1,3,4,6,9,10] },
    FRI: { open: [1,2,5,6,8,10], close: [3,6,7,8,9,10] },
  },
};

const DAY_KEYS = ['SUN','MON','TUE','WED','THU','FRI','SAT'];

export function weekdayKeyFromISO(date: string): string | null {
  const parsed = new Date(`${date}T00:00:00Z`);
  if (Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== date) return null;
  return DAY_KEYS[parsed.getUTCDay()];
}

export function getWeekdayMarketPositions(marketName: string, date: string): { positions: number[]; day: string; side: WeekdayPositionSide } | null {
  const day = weekdayKeyFromISO(date);
  if (!day) return null;
  const normalized = String(marketName || '').trim().toUpperCase();
  const side: WeekdayPositionSide = /CLOSE\s*$/.test(normalized) ? 'close' : 'open';
  const baseMarket = normalized.replace(/\s+(OPEN|CLOSE)\s*$/, '').trim();
  const positions = WEEKDAY_MARKET_POSITIONS[baseMarket]?.[day]?.[side];
  return positions?.length === 6 ? { positions: [...positions], day, side } : null;
}

export function applyWeekdayPositions(rawDigits: string, positions: number[]): string | null {
  const digits = rawDigits.match(/\d/g) || [];
  if (digits.length !== 10 || positions.length !== 6) return null;
  const selected = positions.map((position) => digits[position - 1]);
  return selected.every((digit) => /^\d$/.test(digit || '')) ? selected.join(', ') : null;
}
