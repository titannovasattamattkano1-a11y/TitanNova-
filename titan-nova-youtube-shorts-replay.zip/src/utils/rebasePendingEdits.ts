import {adminChanges,applyAdminChanges,type AdminChange} from './adminStatePatch';

/** A save acknowledgement is based on the submitted snapshot. Edits made after
 * submission remain pending on this device, even when server reconciliation
 * correctly rejects the same change as a competing persisted write. */
export function rebasePendingEdits(remote:any,base:any,local:any){
 const changes=adminChanges(base,local),rebased=applyAdminChanges(remote,changes,true);
 const conflicts=new Set(rebased.conflicts),pending:AdminChange[]=[];
 for(const change of changes){
  if(!conflicts.has(change.path.join('/'))||!change.exists)continue;
  const p=change.path,current=p.reduce((v,k)=>v?.[k],rebased.state);
  const visibility=p[0]==='profiles'&&p[2]==='dayRecords'&&p.length===6&&['visAnk','visJodi','visPan'].includes(p[4])&&typeof change.value==='boolean';
  const card=p[0]==='profiles'&&p[2]==='dayRecords'&&p.length===6&&['data','jodiData','pannelData'].includes(p[4]);
  const next=change.value;
  if(p[0]==='profiles'&&p.length===3&&p[2]==='config'&&current){
   const toggles={...current.marketEnabled};let touched=false;
   for(const [market,enabled] of Object.entries(next?.marketEnabled||{}))if(typeof enabled==='boolean'&&enabled!==change.before?.marketEnabled?.[market]){toggles[market]=enabled;touched=true;}
   if(touched)pending.push({...change,beforeExists:true,before:current,value:{...current,marketEnabled:toggles}});
   continue;
  }
  const frozen=current&&(current.sentRate||current.sentDigits||current.sentAt||current.dispatchState||current.loopAccountReservation||(['PASS','FAIL'].includes(current.s)&&!current.backtestResult));
  const newer=card&&!frozen&&next&&Number(next.sourceEditedAt||0)>Math.max(Number(current?.sourceEditedAt||0),Number(change.before?.sourceEditedAt||0))&&Number(next.cardGeneration||0)>=Number(current?.cardGeneration||0)&&(!next.marketName||!current?.marketName||next.marketName===current.marketName);
  if(visibility||newer)pending.push({...change,beforeExists:current!==undefined,before:current});
 }
 return pending.length?applyAdminChanges(rebased.state,pending,true):rebased;
}
