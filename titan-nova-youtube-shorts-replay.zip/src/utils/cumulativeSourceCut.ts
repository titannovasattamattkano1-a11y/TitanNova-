import type {DayMarketRecord} from '../types';
import {isMirrorProtected} from './adminMirror';
import {getScrapeSource} from './scrapeProvenance';
import {modelSourceVersion} from './marketModelCard';
import {canReplaceLiveCombinedDecision,releaseLiveCombinedDecision} from './liveCombinedDecision';

/** Original source resolves target identity; only current box digits may be removed. */
export function cutCurrentSourceDigits(record:DayMarketRecord|undefined,targets:Iterable<string>,rule?:DayMarketRecord['positionRule'],noOpAsRecord=false):DayMarketRecord|undefined {
  if(!record||!canReplaceLiveCombinedDecision(record)||isMirrorProtected(record)||record.dispatchState||record.deliveryRestoredAt||record.manualStatus||record.s==='SKIP')return;
  const source=getScrapeSource(record),current=record.d.split(/[,|\s]+/).filter(Boolean);
  if(!source||!current.length||!current.every(d=>/^\d$/.test(d)))return;
  const removed=new Set(targets),kept=current.filter(d=>!removed.has(d));
  if(kept.length===current.length)return noOpAsRecord?record:undefined;
  const next:DayMarketRecord={...record,s:'WAIT',d:kept.join(', '),od:source.digits,scrapeSource:source,sourceEditedAt:Math.max(Date.now(),modelSourceVersion(record)+1)};
  releaseLiveCombinedDecision(next);
  delete next.trick;delete next.positionRule;if(rule)next.positionRule=rule;
  delete next.firstDigitMirrorCut;delete next.tesla369;delete next.triCut;delete next.sniperOne;delete next.weekdaySelectedDigits;delete next.weekdayHitPosition;
  delete next.scrapeResultDigit;delete next.manualResult;delete next.manualResultSources;delete next.backtestResult;
  delete next.marketModel;delete next.autoRemovedResult;delete next.autoResultParity;
  delete next.rateFinalizedAt;delete next.rateFinalizedFrom;
  if(!next.manualRate){delete next.recRate;delete next.prevLoss;delete next.targetProfitWithLoss;}
  return next;
}
