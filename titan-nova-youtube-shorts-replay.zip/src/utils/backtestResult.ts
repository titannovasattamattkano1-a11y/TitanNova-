import { normalizeProviderChartHtml } from './normalizeProviderChartHtml';
import { chartSingleDate, chartWeekDates, smartDateRange } from './smartWeekday';
import { panelAnkDigit } from './panelAnk';
import { jodiOpenSideStatus } from './recoveryLedger';
import { manualResultStatus } from './manualResult';
import { areSettlementTokensValid } from './settlement';
import type { DayMarketRecord, GameType } from '../types';

export interface DatedActual { date: string; open?: string; jodi?: string; close?: string }
export const BACKTEST_RESULT_RETRY_MS = 30_000;
export interface CachedBacktestActual { actual: DatedActual | null | undefined; expiresAt: number }
/** Completed historical draws are stable. Missing/partial/error lookups must retry. */
/**
 * For an old date with no/partial published actual, avoid re-downloading a
 * multi-year chart every 30 seconds. Manual Test Result still bypasses this.
 * Do not prolong transport errors (undefined) or recently published dates.
 */
export function cacheBacktestActual(actual: DatedActual | null | undefined, now = Date.now(), targetDate?: string): CachedBacktestActual {
  const complete = Boolean(actual?.open && actual?.jodi && actual?.close);
  const targetDay = targetDate && /^\d{4}-\d{2}-\d{2}$/.test(targetDate) ? Date.parse(`${targetDate}T00:00:00Z`) : NaN;
  const age = Number.isFinite(targetDay) ? now - targetDay : 0;
  const missingHistorical = actual !== undefined && age > 86400000;
  const retryMs = !missingHistorical ? BACKTEST_RESULT_RETRY_MS : age > 7 * 86400000 ? 30 * 60_000 : 5 * 60_000;
  return { actual, expiresAt: complete ? Infinity : now + retryMs };
}
export function isFreshBacktestActual(cached: CachedBacktestActual | undefined, now = Date.now()): boolean {
  return Boolean(cached && cached.expiresAt > now);
}
/** Date-labelled cells only. Missing/contradictory values never become a guessed result. */
export function parseDatedActuals(html: string): DatedActual[] {
  const normalizedHtml = normalizeProviderChartHtml(html);
  const table = normalizedHtml.match(/<table\b[^>]*class=["'][^"']*\bpchart\b[^"']*["'][^>]*>[\s\S]*?<\/table>/i)?.[0] || normalizedHtml;
  const readCells=(source:string) => [...source.matchAll(/<t[dh]\b[^>]*>([\s\S]*?)<\/t[dh]>/gi)].map(m => m[1].replace(/<[^>]+>/g, ' ').replace(/&nbsp;|&#160;/gi, ' ').replace(/\s+/g, ' ').trim());
  // Public charts sometimes omit the last </tr> while the current week is growing.
  // Stop at row/section boundaries so an unfinished row cannot swallow another.
  const physicalRows=[...table.matchAll(/<tr\b[^>]*>([\s\S]*?)(?=<\/tr\s*>|<tr\b|<\/(?:tbody|thead|tfoot|table)\b|$)/gi)].map(m=>readCells(m[1]));
  const weekHeaders=['mon','tue','wed','thu','fri','sat','sun'];
  // Charts declare Mon–Fri, Mon–Sat or Mon–Sun depending on the market.
  // Accept only an explicit ordered Monday prefix; no calendar inference from
  // row order or an unlabeled/incomplete header.
  const declaredWeekWidth=physicalRows.reduce((width,cells)=>{
    const names=cells.map(c=>c.toLowerCase().slice(0,3)).filter(c=>weekHeaders.includes(c));
    return names.length>=5 && names.length<=7 && names.every((day,i)=>day===weekHeaders[i])
      ? Math.max(width,names.length) : width;
  },0);
  const byDate = new Map<string,DatedActual>();
  const conflicts = new Set<string>();
  const rows=physicalRows.length ? physicalRows : [readCells(table)];
  for (const cells of rows) {
    const anchors=cells.flatMap((c,i)=>smartDateRange(c) || chartSingleDate(c) ? [i] : []);
    for (let i=0;i<anchors.length;i++) {
      const at=anchors[i], values=cells.slice(at+1,anchors[i+1] ?? cells.length), slots=values.length/3;
      if (!Number.isInteger(slots) || slots<1 || slots>7) continue;
      const single=chartSingleDate(cells[at]);
      let dates=single && slots===1 ? [single] : chartWeekDates(cells[at],slots);
      // Only explicit ordered weekday headers authorize a shortened week prefix.
      // Preserve each published triple's position; never fill absent days.
      if(!dates.length && declaredWeekWidth && slots<=declaredWeekWidth){
        const week=chartWeekDates(cells[at],7);
        const range=smartDateRange(cells[at]);
        const end=range ? chartSingleDate(range[1]) : null;
        // A declared 5/6-day week may label its actual end rather than Sunday.
        const expected=range && chartWeekDates(cells[at],declaredWeekWidth);
        const publishedWeek=week.length===7 ? week : expected || [];
        if(publishedWeek.length>=slots && end && new Date(`${publishedWeek[0]}T00:00:00Z`).getUTCDay()===1)dates=publishedWeek.slice(0,slots);
      }
      dates.forEach((date,slot) => {
        const panel=(v:string) => /^\d{3}$/.test(v.replace(/\s/g,'')) ? v.replace(/\s/g,'') : undefined;
        const open=panel(values[slot*3]), close=panel(values[slot*3+2]);
        const pair=values[slot*3+1].replace(/\s/g,'');
        const jodi=/^\d{2}$/.test(pair) ? pair : undefined;
        const row={date,open,jodi,close};
        // Unpublished dates are not actuals. Never persist or settle a blank result.
        if (!open && !jodi && !close) return;
        const prior=byDate.get(date);
        if (prior && (['open','jodi','close'] as const).some(key=>prior[key] && row[key] && prior[key]!==row[key])) { conflicts.add(date); return; }
        const merged={date,open:open || prior?.open,jodi:jodi || prior?.jodi,close:close || prior?.close};
        if (merged.jodi && ((merged.open && panelAnkDigit(merged.open)!==merged.jodi[0]) || (merged.close && panelAnkDigit(merged.close)!==merged.jodi[1]))) { conflicts.add(date); return; }
        // Both actual Pattis identify the full pair even when its cell is blank.
        if (!merged.jodi && merged.open && merged.close) merged.jodi=`${panelAnkDigit(merged.open)}${panelAnkDigit(merged.close)}`;
        byDate.set(date,merged);
      });
    }
  }
  return [...byDate.values()].filter(r=>!conflicts.has(r.date)).sort((a,b)=>a.date.localeCompare(b.date));
}
export function actualForGame(row: DatedActual | undefined, type: GameType, name: string): string | undefined {
  if (!row) return undefined;
  if (type==='jodi') return row.jodi;
  const side=/\s+CLOSE$/i.test(name) ? 1 : /\s+OPEN$/i.test(name) ? 0 : undefined;
  if (side===undefined) return undefined;
  const panel=side===0 ? row.open : row.close;
  return type==='pannel' ? panel : (row.jodi?.[side] || (panel ? panelAnkDigit(panel) : undefined));
}
/** Restore writes manual WAIT as an undo marker; it is not a confirmed result. */
export function canAutoEvaluateBacktest(record: DayMarketRecord | undefined, type: GameType): boolean {
  return Boolean(record && record.s!=='SKIP' && !record.sentDigits && !record.sentRate &&
    record.dispatchState!=='SENT' && record.dispatchState!=='SETTLED' && record.dispatchState!=='QUEUED' &&
    (!record.manualStatus || record.s==='WAIT') && areSettlementTokensValid(type,record.d));
}
export function evaluateBacktest(record: DayMarketRecord, type: GameType, actual: string | undefined, openActual?:string): DayMarketRecord {
  if (!canAutoEvaluateBacktest(record,type)) return record;
  const open=type==='jodi'?(/^\d{2}$/.test(actual||'')?actual![0]:/^\d$/.test(openActual||'')?openActual:undefined):undefined;
  const openStatus=open?jodiOpenSideStatus(record.d,open):null;
  const status = openStatus==='FAIL'?'FAIL':actual ? manualResultStatus(type,record.d,actual) : 'WAIT';
  if (!record.manualStatus && !record.manualResult && record.s === status && record.backtestResult?.checked &&
    record.backtestResult.digits === record.d && record.backtestResult.actual === actual && record.backtestResult.openActual===open && (type!=='jodi'||record.jodiOpenStatus===(openStatus||undefined)&&record.jodiOpenResult===open) && record.scrapeResultDigit === actual) return record;
  const next={...record};
  next.s=status;
  next.backtestResult={digits:record.d,actual,...(open?{openActual:open}:{}),checked:true,...(record.backtestResult?.updatedAt?{updatedAt:record.backtestResult.updatedAt}:{})};
  if(type==='jodi'){if(openStatus){next.jodiOpenStatus=openStatus;next.jodiOpenResult=open;}else{delete next.jodiOpenStatus;delete next.jodiOpenResult;}}
  delete next.manualStatus; delete next.manualResult;
  next.scrapeResultDigit=actual;
  return next;
}

/** A real OPEN miss is sufficient to settle JODI; no unknown CLOSE digit is invented. */
export function evaluateDatedBacktest(record:DayMarketRecord,type:GameType,row:DatedActual|undefined,name:string):DayMarketRecord {
  const base=name.replace(/\s+(OPEN|CLOSE)$/i,'').trim();
  return evaluateBacktest(record,type,actualForGame(row,type,name),type==='jodi'?actualForGame(row,'ank',`${base} OPEN`):undefined);
}
