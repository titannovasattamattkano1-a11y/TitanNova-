import { isTelegramTarget, normalizeTargetJid } from './targetNormalization';

export type Transport = 'whatsapp' | 'telegram';
export const transportOf = (target: string): Transport => isTelegramTarget(target) ? 'telegram' : 'whatsapp';
export function transportTargets(targets: unknown, transport: Transport): string[] {
  return Array.isArray(targets) ? [...new Set(targets.map(x => normalizeTargetJid(x)).filter((x): x is string => !!x && transportOf(x) === transport))] : [];
}
export function allDelivered(expected: string[], delivered: string[]): boolean {
  const actual = new Set(delivered.map(x => normalizeTargetJid(x)).filter(Boolean));
  return expected.length > 0 && expected.every(x => actual.has(normalizeTargetJid(x)));
}

/** ACK scope must never grow beyond the exact batch handed to a transport. */
export function acknowledgedTargets(reported: unknown, claimed: unknown, expected: unknown): string[] {
  const normalize = (values: unknown) => Array.isArray(values)
    ? [...new Set(values.map(x => normalizeTargetJid(x)).filter((x): x is string => Boolean(x)))]
    : [];
  const explicit = normalize(reported);
  if (explicit.length > 0) return explicit;
  const claimBatch = normalize(claimed);
  return claimBatch.length > 0 ? claimBatch : normalize(expected);
}
