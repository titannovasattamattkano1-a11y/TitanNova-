const istDateFormatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    hourCycle: 'h23',
  });

/** One business-date authority for browser and server. Day starts at 06:00 IST. */
export function businessDateIST(dateObj = new Date(), applyCutoff = true): string {
  const parts = istDateFormatter.formatToParts(new Date(dateObj));
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  const date = new Date(Date.UTC(Number(values.year), Number(values.month) - 1, Number(values.day)));
  if (applyCutoff && Number(values.hour) < 6) date.setUTCDate(date.getUTCDate() - 1);
  return date.toISOString().slice(0, 10);
}

export function dateValid(d: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(d) && Number.isFinite(Date.parse(d));
}
