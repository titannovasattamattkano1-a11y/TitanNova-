import {backtestMarketSelected} from './backtestMarketSelection';
import type {DayMarketRecord,UserProfile} from '../types';
import {getScrapeSource} from './scrapeProvenance';
import {autoRemovalInput} from './autoRemoveResult';
import {modelSourceVersion} from './marketModelCard';
import {evaluateBacktest} from './backtestResult';
import {profileRecoveryTrack,createProfileLoopContext} from './dualLoops';
import {getEffectiveMarkets} from '../data/markets';
import {isMarketEnabledForDate} from './profileMarketToggle';
import {isRecordedPlay} from './financialHistory';
import {recoveryMarketOrder} from './recoveryMarketOrder';

export type CutSide='FCUT'|'LCUT';
export interface CutSignal {cut:CutSide;key:string}
export interface CutDecision {cut:CutSide|'CENTER';loopCut:CutSide;marketCut?:CutSide;loopSourceKey?:string;marketSourceKey?:string;sourceKey:string}
export interface CutMarket {n:string;index:number;hr?:number;min?:number;enabled?:boolean}
const name=(value:string)=>value.trim().replace(/\s+/g,' ').toUpperCase();
const side=(value:unknown):value is CutSide=>value==='FCUT'||value==='LCUT';
const opposite=(value:CutSide):CutSide=>value==='FCUT'?'LCUT':'FCUT';
const canonical=(value:string)=>value.split(/[,|\s]+/).filter(Boolean).join(', ');

/** CENTER keeps the loop's requested side as its next-result state. */
export function recordedCutSide(rec:DayMarketRecord|undefined):CutSide|undefined {
  if(!rec)return;
  const meta=rec.autoResultParity;
  if(meta?.rule==='OPEN_LOOP_CUT'&&side(meta.loopCut))return meta.loopCut;
  if(side(rec.positionRule))return rec.positionRule;
  const source=getScrapeSource(rec)?.digits.split(', '),selected=canonical(rec.sentDigits||rec.d);
  if(!source||source.length<5)return;
  if(selected===source.slice(4).join(', '))return 'FCUT';
  if(selected===source.slice(0,-4).join(', '))return 'LCUT';
}
function settled(rec:DayMarketRecord|undefined):rec is DayMarketRecord {
  if(!rec||!['PASS','FAIL'].includes(rec.s)||rec.deliveryRestoredAt)return false;
  return Boolean(isRecordedPlay(rec)||rec.backtestResult?.checked&&rec.backtestResult.digits===rec.d);
}
export function cutSignal(rec:DayMarketRecord|undefined,key:string):CutSignal|undefined {
  if(!settled(rec))return;
  const used=recordedCutSide(rec);if(!used)return;
  return {cut:rec.s==='PASS'?opposite(used):used,key};
}
export function mergeCutSignals(loop:CutSignal|undefined,market:CutSignal|undefined,seed:CutSide='FCUT'):CutDecision {
  const loopCut=loop?.cut||market?.cut||seed;
  return {cut:loop&&market&&loop.cut!==market.cut?'CENTER':loopCut,loopCut,
    ...(market?{marketCut:market.cut,marketSourceKey:market.key}:{}),...(loop?{loopSourceKey:loop.key}:{}),
    sourceKey:[loop?.key,market?.key].filter((key,i,list)=>key&&list.indexOf(key)===i).join(' | ')};
}

/** One resolver per replay/finalization. Current records are read lazily so an
 * earlier simulated result is observed only after its new selection settles. */
export function createCutResolver(options:{profile?:UserProfile;date:string;markets:CutMarket[];cards:Record<string,DayMarketRecord>;track:(market:string,rec?:DayMarketRecord)=>string;selectedMarkets?:string[]}) {
  const ordered=recoveryMarketOrder(options.markets),prior=new Map<string,CutSignal|undefined>();
  let historyDates:string[]|undefined;
  let active:Set<string>|undefined;
  const catalogs=new Map<object,{list:ReturnType<typeof getEffectiveMarkets>;names:Map<string,ReturnType<typeof getEffectiveMarkets>[number]>}>();
  const historical=(requestedTrack:string)=>{
    if(prior.has(requestedTrack))return prior.get(requestedTrack);
    // A new/unseeded loop used to scan the entire archive separately. Resolve
    // all current tracks in one backwards pass, scoped to this replay only.
    const missing=new Set([requestedTrack,...ordered.map(m=>options.track(m.n,options.cards[String(m.index)]))].filter(track=>!prior.has(track)));
    const p=options.profile;
    if(p){
      historyDates ||= Object.keys(p.dayRecords||{}).filter(d=>d<options.date).sort().reverse();
      active ||= new Set(getEffectiveMarkets(p.config).map(m=>name(m.n)));
      for(const date of historyDates){
        const day=p.dayRecords[date],entries=Object.entries(day.data||{});
        const signals=new Map(entries.map(([i,rec])=>[i,cutSignal(rec,`${date}:ank_${i}`)]));
        // Legacy odd/even results without a recorded cut cannot seed O/D.
        // Reject them before building catalogs or normalizing loop settings.
        if(![...signals.values()].some(Boolean))continue;
        const config=day.recoveryConfigSnapshot||p.config;
        let known=catalogs.get(config);
        if(!known){
          const list=[...getEffectiveMarkets(config),...getEffectiveMarkets({...p.config,deletedMarketNames:[]})],names=new Map<string,typeof list[number]>();
          for(const m of list)if(!names.has(name(m.n)))names.set(name(m.n),m);
          known={list,names};catalogs.set(config,known);
        }
        const context=createProfileLoopContext(p,date);
        const rows=recoveryMarketOrder(entries.map(([i,rec])=>{const market=known!.names.get(name(rec.marketName||''))||known!.list[Number(i)];return {...market,index:Number(i),rec,signal:signals.get(i)};}));
        for(const row of rows.reverse()){
          if(!row.signal)continue;
          const rec=row.rec,n=rec.marketName||row.n;
          if(!n||!backtestMarketSelected(n,options.selectedMarkets))continue;
          if(!isRecordedPlay(rec)&&(!active.has(name(n))||!isMarketEnabledForDate(p.config,day.visAnk,n,date)))continue;
          const track=profileRecoveryTrack(p,date,'ank',n,rec,context);
          if(missing.has(track)){prior.set(track,row.signal);missing.delete(track);}
        }
        if(!missing.size)break;
      }
    }
    for(const track of missing)prior.set(track,undefined);
    return prior.get(requestedTrack);
  };
  return (index:number,rec:DayMarketRecord):CutDecision=>{
    const at=ordered.findIndex(m=>m.index===index),current=ordered[at],track=options.track(current?.n||rec.marketName||'',rec);
    let loop:CutSignal|undefined,market:CutSignal|undefined;
    const open=current&&/ CLOSE$/i.test(current.n)?name(current.n).replace(/ CLOSE$/,' OPEN'):undefined;
    for(const m of ordered.slice(0,Math.max(0,at))){
      const r=options.cards[String(m.index)];
      if(!isRecordedPlay(r)&&(m.enabled===false||!backtestMarketSelected(m.n,options.selectedMarkets)))continue;
      const signal=cutSignal(r,`${options.date}:ank_${m.index}`);if(!signal)continue;
      if(options.track(m.n,r)===track)loop=signal;
      if(open&&name(m.n)===open)market=signal;
    }
    return mergeCutSignals(loop||historical(track),market,recordedCutSide(rec)||'FCUT');
  };
}

/** O/D compatibility name: original source -> Fcut/Lcut/CENTER -> existing
 * result filters -> rate. A winning digit's odd/even value has no role. */
export function applyResultParity(rec:DayMarketRecord,decision:CutDecision|undefined,enabled:boolean):DayMarketRecord {
  if(rec.sentDigits||rec.sentRate||rec.dispatchState||rec.deliveryRestoredAt||rec.s==='SKIP'||(rec.manualStatus&&rec.s!=='WAIT')||((rec.s==='PASS'||rec.s==='FAIL')&&!rec.backtestResult))return rec;
  if(['FIRST_CUT','CUT2','RECENT2','RECENT6','RECENT4','LAST_ACTUAL_MIRROR','FIRST_DIGIT_MIRROR','SSD','TRI_CUT','SNIPER_1','TESLA_369'].includes(rec.positionRule||''))return rec;
  const old=rec.autoResultParity,visible=autoRemovalInput(rec);
  const active=Boolean(old&&visible===old.output&&(old.outputVersion===modelSourceVersion(rec)||rec.autoRemovedResult?.input===old.output&&rec.autoRemovedResult.outputVersion===modelSourceVersion(rec)));
  const input=active?old!.input:visible,inputTrick=active?old!.inputTrick:rec.trick;
  const inputPositionRule=active?old!.inputPositionRule:rec.positionRule;
  const source=getScrapeSource(rec),tokens=source?.digits.split(', ');
  const apply=Boolean(enabled&&decision&&tokens&&tokens.length>4);
  const output=apply?(decision!.cut==='FCUT'?tokens!.slice(4):decision!.cut==='LCUT'?tokens!.slice(0,-4):[...tokens!.slice(0,3),...tokens!.slice(7)]).join(', '):input;
  if(!apply&&!old)return rec;
  const previous=old&&{cut:old.cut,loopCut:old.loopCut,marketCut:old.marketCut,loopSourceKey:old.loopSourceKey,marketSourceKey:old.marketSourceKey,sourceKey:old.sourceKey};
  if(apply&&active&&old?.rule==='OPEN_LOOP_CUT'&&old.output===output&&['cut','loopCut','marketCut','loopSourceKey','marketSourceKey','sourceKey'].every(key=>(previous as any)?.[key]===(decision as any)?.[key]))return rec;
  const changed=rec.d!==output;
  const policyChanged=apply?old?.rule!=='OPEN_LOOP_CUT'||old.cut!==decision!.cut||rec.positionRule!==decision!.cut:Boolean(old);
  const version=changed||policyChanged?Math.max(Date.now(),modelSourceVersion(rec)+1):modelSourceVersion(rec);
  const meta=apply?{...decision!,rule:'OPEN_LOOP_CUT' as const,input,inputTrick,inputPositionRule,output,outputVersion:version}:undefined;
  let next:DayMarketRecord={...rec,d:output,trick:apply?undefined:inputTrick,positionRule:apply?decision!.cut:inputPositionRule,autoResultParity:meta};
  delete next.autoRemovedResult;
  if(changed||policyChanged)next.sourceEditedAt=version;
  if(changed){
    delete next.rateFinalizedAt;delete next.rateFinalizedFrom;
    if(rec.backtestResult){const r=rec.backtestResult;next.s='WAIT';delete next.backtestResult;
      if(r.checked&&r.actual&&output)next=evaluateBacktest(next,'ank',r.actual);
      else next.backtestResult={...r,digits:output};
    }
  }
  return next;
}
