/**
 * Text-only layout for Daily Audit shares (ANK / JODI / PANEL).
 * No state, settlement or business logic lives in this module.
 */
export function formatAuditTextDate(value: string): string {
  const raw = String(value || '').trim();
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(raw);
  if (!match) return raw;
  const [, year, month, day] = match;
  const date = new Date(`${year}-${month}-${day}T12:00:00Z`);
  if (Number.isNaN(date.getTime()) || date.getUTCFullYear() !== Number(year) || date.getUTCMonth() + 1 !== Number(month) || date.getUTCDate() !== Number(day)) return raw;
  const weekday = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'][date.getUTCDay()];
  return `${weekday} / ${day} / ${year}`;
}

function characterWidth(value: string): number {
  let width = 0;
  for (const char of Array.from(String(value || '').replace(/\*/g, ''))) {
    const cp = char.codePointAt(0) || 0;
    if (cp === 0xfe0f || cp === 0x200d || (cp >= 0x0300 && cp <= 0x036f)) continue;
    width += cp >= 0x1100 && (
      cp <= 0x115f || cp === 0x2329 || cp === 0x232a ||
      (cp >= 0x2e80 && cp <= 0xa4cf && cp !== 0x303f) ||
      (cp >= 0xac00 && cp <= 0xd7a3) ||
      (cp >= 0xf900 && cp <= 0xfaff) ||
      (cp >= 0xfe10 && cp <= 0xfe19) ||
      (cp >= 0xfe30 && cp <= 0xfe6f) ||
      (cp >= 0xff00 && cp <= 0xff60) ||
      (cp >= 0xffe0 && cp <= 0xffe6) ||
      (cp >= 0x1f300 && cp <= 0x1faff)
    ) ? 2 : 1;
  }
  return width;
}

/** Simple rounded box, matching the existing outgoing play-card TXT style. */
export function renderAuditTextBox(title: string, rows: readonly string[]): string {
  const content = [title, ...rows];
  const width = Math.max(23, ...content.map(characterWidth));
  return [
    `╭${'─'.repeat(width)}╮`,
    ...content.map((value) => `│${value}${' '.repeat(Math.max(0, width - characterWidth(value)))}│`),
    `╰${'─'.repeat(width)}╯`,
  ].join('\n');
}

/** Compact numeric tokens only for presentation; never alter saved selections. */
export function auditDigitsRows(game: 'ank' | 'jodi' | 'pannel', digits: string): string[] {
  const raw = String(digits || '').trim() || '---';
  if (game === 'ank') return [`🎯 Digits:${raw.split(',').map((part) => part.trim()).join(',')}`];
  const tokens = raw.split(/[,|\s]+/).filter(Boolean);
  if (!tokens.length || (tokens.length === 1 && tokens[0] === '---')) return [`🎯 ${game === 'jodi' ? 'Jodi' : 'Panel'}:---`];
  const perRow = game === 'jodi' ? 6 : 5;
  const label = game === 'jodi' ? `🎯 Jodi (${tokens.length})` : `🎯 Panel (${tokens.length})`;
  const lines = [label];
  for (let offset = 0; offset < tokens.length; offset += perRow) {
    lines.push(tokens.slice(offset, offset + perRow).join(' • '));
  }
  return lines;
}

export function auditGameTitle(game: 'ank' | 'jodi' | 'pannel' | 'all'): string {
  return game === 'pannel' ? 'PANEL' : game.toUpperCase();
}
