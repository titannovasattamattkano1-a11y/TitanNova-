/** Run independent card jobs with bounded concurrency and wait for every worker. */
export async function runConcurrentTasks<T>(items: readonly T[], limit: number, task: (item: T) => Promise<void>): Promise<void> {
  if (!Number.isInteger(limit) || limit < 1) throw new Error('Concurrency limit must be a positive integer');
  let cursor = 0;
  let failed = false, firstError: unknown;
  const worker = async () => {
    while (cursor < items.length) {
      const item = items[cursor++];
      try { await task(item); } catch (error) { if (!failed) { failed=true; firstError=error; } }
    }
  };
  const results = await Promise.allSettled(Array.from({ length: Math.min(limit, items.length) }, worker));
  const workerFailure = results.find((result): result is PromiseRejectedResult => result.status === 'rejected');
  if (workerFailure) throw workerFailure.reason;
  if (failed) throw firstError;
}
