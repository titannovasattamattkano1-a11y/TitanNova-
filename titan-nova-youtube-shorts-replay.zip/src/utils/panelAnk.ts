import { normalizeAnkDigits } from './ankDigits';
export { normalizeAnkDigits } from './ankDigits';

/** Canonical Matka order: 1..9 then 0 (0 is largest), e.g. 012 → 120. */
export function normalizePanelPatti(value: unknown): string | null {
  const digits = String(value ?? '').replace(/\D/g, '');
  if (!/^\d{3}$/.test(digits)) return null;
  const rank = (digit: string) => digit === '0' ? 10 : Number(digit);
  return [...digits].sort((a, b) => rank(a) - rank(b)).join('');
}

/** Matka Panel rule: sum of the three Patti digits, reduced modulo 10. */
export function panelAnkDigit(panel: unknown): string | null {
  const token = String(panel ?? '').trim();
  if (!/^\d{3}$/.test(token)) return null;
  return String([...token].reduce((sum, digit) => sum + Number(digit), 0) % 10);
}

/** Single Patti has three different digits. Double/Triple Pattis are rejected. */
export function isSinglePatti(panel: unknown): boolean {
  const token = String(panel ?? '').trim();
  return /^\d{3}$/.test(token) && new Set(token).size === 3;
}

/** Filter an array while preserving its original ranking/order. */
export function filterPanelListByAnkDigits(values: unknown[], ankDigits: unknown): string[] {
  const allowed = new Set(normalizeAnkDigits(ankDigits));
  if (allowed.size === 0 || !Array.isArray(values)) return [];
  return values
    .map((value) => String(value ?? '').trim())
    .filter((token) => {
      const ank = panelAnkDigit(token);
      return isSinglePatti(token) && ank !== null && allowed.has(ank);
    });
}

/** Keep only valid three-digit Pattis matching one of the selected ANK digits. */
export function filterPanelsByAnkDigits(value: unknown, ankDigits: unknown): string {
  return filterPanelListByAnkDigits(String(value ?? '').split(/[, ]+/), ankDigits).join(', ');
}

export interface GapRotationOptions {
  /** Exact latest result positions temporarily excluded. */
  cooldown?: number;
  /** Maximum Pattis returned. */
  limit?: number;
  /** Recent fallback is used only until this usable minimum is reached. */
  minOutput?: number;
  /** Keep multi-ANK cards balanced instead of letting one ANK consume the limit. */
  balanceByAnk?: boolean;
  /** Ranking chosen by the market/session walk-forward backtest. */
  rankingMode?: PanelRankingMode;
}

export type PanelRankingMode = 'gap' | 'frequency' | 'hybrid' | 'recent_frequency';

export interface LowFrequencyPanelOptions {
  /** Same-weekday side-specific Panel history. */
  weekdayHistory?: unknown[];
  /** Panels drawn immediately after the latest Jodi appeared historically. */
  successorHistory?: unknown[];
  /** Exact desired card size. */
  limit?: number;
}

export interface LowFrequencyPanelSelection {
  panels: string[];
  candidateCount: number;
  unseenSelected: number;
  weekdaySamples: number;
  successorSamples: number;
  complete: boolean;
  distribution: Record<string, number>;
}

/** All 120 canonical Single Pattis in Matka digit order (1..9, then 0). */
export function buildCanonicalSinglePattiUniverse(): string[] {
  const digits = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'];
  const panels: string[] = [];
  for (let a = 0; a < digits.length - 2; a++) {
    for (let b = a + 1; b < digits.length - 1; b++) {
      for (let c = b + 1; c < digits.length; c++) panels.push(`${digits[a]}${digits[b]}${digits[c]}`);
    }
  }
  return panels;
}

/**
 * Strict LOW PANEL 30 selector.
 * Rank order: never appeared → lowest weekday/Jodi-successor frequency →
 * lowest full-history frequency → longest gap → stable canonical order.
 * Round-robin ANK buckets keep the final card balanced without duplicates.
 */
export function selectLowFrequencyPanels(
  recentToOld: unknown[],
  ankDigits: unknown,
  options: LowFrequencyPanelOptions = {},
): LowFrequencyPanelSelection {
  const requestedAnks = normalizeAnkDigits(ankDigits);
  const allowed = new Set(requestedAnks);
  const limit = Math.max(0, Math.floor(Number(options.limit ?? 30) || 0));
  const universe = buildCanonicalSinglePattiUniverse();
  const canonicalOrder = new Map(universe.map((panel, index) => [panel, index]));
  const normalizeHistory = (values: unknown[] | undefined) => (Array.isArray(values) ? values : [])
    .map((value) => normalizePanelPatti(value))
    .filter((value): value is string => Boolean(value) && isSinglePatti(value));
  const full = normalizeHistory(recentToOld);
  const weekday = normalizeHistory(options.weekdayHistory);
  const successor = normalizeHistory(options.successorHistory);
  const counts = (values: string[]) => values.reduce<Map<string, number>>((map, panel) => {
    map.set(panel, (map.get(panel) || 0) + 1);
    return map;
  }, new Map());
  const fullCounts = counts(full);
  const weekdayCounts = counts(weekday);
  const successorCounts = counts(successor);
  const firstGap = new Map<string, number>();
  full.forEach((panel, index) => { if (!firstGap.has(panel)) firstGap.set(panel, index); });
  const candidates = universe.filter((panel) => {
    const ank = panelAnkDigit(panel);
    return ank !== null && allowed.has(ank);
  });
  const rank = (a: string, b: string) => {
    const fullA = fullCounts.get(a) || 0;
    const fullB = fullCounts.get(b) || 0;
    const unseenA = fullA === 0 ? 0 : 1;
    const unseenB = fullB === 0 ? 0 : 1;
    const contextA = (weekdayCounts.get(a) || 0) + (successorCounts.get(a) || 0);
    const contextB = (weekdayCounts.get(b) || 0) + (successorCounts.get(b) || 0);
    const gapA = firstGap.get(a) ?? Number.MAX_SAFE_INTEGER;
    const gapB = firstGap.get(b) ?? Number.MAX_SAFE_INTEGER;
    return unseenA - unseenB || contextA - contextB ||
      (weekdayCounts.get(a) || 0) - (weekdayCounts.get(b) || 0) ||
      (successorCounts.get(a) || 0) - (successorCounts.get(b) || 0) ||
      fullA - fullB || gapB - gapA ||
      (canonicalOrder.get(a) || 0) - (canonicalOrder.get(b) || 0);
  };
  const buckets = new Map(requestedAnks.map((ank) => [ank, [] as string[]]));
  candidates.sort(rank).forEach((panel) => {
    const ank = panelAnkDigit(panel);
    if (ank !== null) buckets.get(ank)?.push(panel);
  });
  const panels: string[] = [];
  const distribution: Record<string, number> = Object.fromEntries(requestedAnks.map((ank) => [ank, 0]));
  for (let position = 0; panels.length < limit; position++) {
    let added = false;
    for (const ank of requestedAnks) {
      const panel = buckets.get(ank)?.[position];
      if (!panel) continue;
      panels.push(panel);
      distribution[ank] += 1;
      added = true;
      if (panels.length === limit) break;
    }
    if (!added) break;
  }
  return {
    panels,
    candidateCount: candidates.length,
    unseenSelected: panels.filter((panel) => !fullCounts.has(panel)).length,
    weekdaySamples: weekday.length,
    successorSamples: successor.length,
    complete: panels.length === limit,
    distribution,
  };
}

/**
 * Rank chart-derived Single Pattis by how long ago they last appeared.
 * Input must be newest-to-oldest. No synthetic Patti is ever generated.
 */
export function selectGapRotationPanels(
  recentToOld: unknown[],
  ankDigits: unknown,
  options: GapRotationOptions = {},
): string[] {
  const allowed = new Set(normalizeAnkDigits(ankDigits));
  const limit = Math.max(0, Math.floor(Number(options.limit ?? 30) || 0));
  const cooldown = Math.max(0, Math.floor(Number(options.cooldown ?? 10) || 0));
  const minOutput = Math.min(limit, Math.max(0, Math.floor(Number(options.minOutput ?? 10) || 0)));
  if (!Array.isArray(recentToOld) || allowed.size === 0 || limit === 0) return [];

  const stats = new Map<string, { panel: string; ank: string; gap: number; appearances: number }>();
  recentToOld.forEach((value, index) => {
    const panel = String(value ?? '').trim();
    const ank = panelAnkDigit(panel);
    if (!isSinglePatti(panel) || ank === null || !allowed.has(ank)) return;
    const current = stats.get(panel);
    if (current) current.appearances += 1;
    else stats.set(panel, { panel, ank, gap: index, appearances: 1 });
  });

  type PanelStat = { panel: string; ank: string; gap: number; appearances: number };
  const rankingMode = options.rankingMode ?? 'gap';
  const recentCounts = new Map<string, number>();
  recentToOld.slice(0, 180).forEach((value) => {
    const panel = String(value ?? '').trim();
    recentCounts.set(panel, (recentCounts.get(panel) || 0) + 1);
  });
  const rank = (a: PanelStat, b: PanelStat) => {
    if (rankingMode === 'frequency') {
      return b.appearances - a.appearances || b.gap - a.gap || a.panel.localeCompare(b.panel);
    }
    if (rankingMode === 'recent_frequency') {
      return (recentCounts.get(b.panel) || 0) - (recentCounts.get(a.panel) || 0) ||
        b.gap - a.gap || a.panel.localeCompare(b.panel);
    }
    if (rankingMode === 'hybrid') {
      const score = (item: PanelStat) => item.gap + 12 * Math.log2(1 + item.appearances);
      return score(b) - score(a) || a.panel.localeCompare(b.panel);
    }
    return b.gap - a.gap || b.appearances - a.appearances || a.panel.localeCompare(b.panel);
  };
  const all = [...stats.values()];
  const overdue = all.filter((item) => item.gap >= cooldown).sort(rank);
  const recent = all.filter((item) => item.gap < cooldown).sort(rank);
  const balanceByAnk = options.balanceByAnk !== false && allowed.size > 1;

  if (balanceByAnk) {
    const requestedAnks = [...allowed];
    const targetPerAnk = Math.floor(limit / requestedAnks.length);
    if (targetPerAnk <= 0) return [];

    const overdueBuckets = new Map(requestedAnks.map((ank) => [ank, [] as PanelStat[]]));
    const recentBuckets = new Map(requestedAnks.map((ank) => [ank, [] as PanelStat[]]));
    // OPTIMIZATION: Bucket each ranked Patti once instead of filtering the full list once per ANK.
    for (const item of overdue) overdueBuckets.get(item.ank)?.push(item);
    for (const item of recent) recentBuckets.get(item.ank)?.push(item);

    const equalOverdueQuota = Math.min(
      targetPerAnk,
      ...requestedAnks.map((ank) => overdueBuckets.get(ank)?.length || 0),
    );
    const required = Math.min(minOutput, all.length, limit);
    let equalQuota = equalOverdueQuota;

    // BUG FIX: Recent/cooldown Pattis may fill only the configured usable minimum, never the full quota silently.
    if (equalQuota * requestedAnks.length < required) {
      const equalAvailableQuota = Math.min(
        targetPerAnk,
        ...requestedAnks.map((ank) =>
          (overdueBuckets.get(ank)?.length || 0) + (recentBuckets.get(ank)?.length || 0)),
      );
      equalQuota = Math.min(
        equalAvailableQuota,
        Math.max(equalQuota, Math.ceil(required / requestedAnks.length)),
      );
    }
    if (equalQuota <= 0) return [];

    const selected: PanelStat[] = [];
    const rankedBuckets = new Map(requestedAnks.map((ank) => [ank, [
      ...(overdueBuckets.get(ank) || []),
      ...(recentBuckets.get(ank) || []),
    ]]));
    // BUG FIX: Every requested ANK contributes the exact same quota while preserving its internal ranking.
    for (let position = 0; position < equalQuota; position++) {
      for (const ank of requestedAnks) {
        const item = rankedBuckets.get(ank)?.[position];
        if (item) selected.push(item);
      }
    }
    return selected.map((item) => item.panel);
  }

  const selected = overdue.slice(0, limit);

  // Keep recent repeats out unless the overdue pool cannot provide a minimally
  // usable card. Even then, use the oldest recent item first—not the latest.
  const required = Math.min(minOutput, all.length);
  for (const item of recent) {
    if (selected.length >= required || selected.length >= limit) break;
    selected.push(item);
  }
  return selected.slice(0, limit).map((item) => item.panel);
}

export interface PanelStrategyResult {
  mode: PanelRankingMode;
  samples: number;
  hits: number;
  passPercent: number;
  scores: Record<PanelRankingMode, number>;
}

/** Select a ranking using walk-forward history only (no future leakage). */
export function choosePanelRankingByBacktest(recentToOld: unknown[]): PanelStrategyResult {
  const chronological = [...recentToOld]
    .reverse()
    .map((value) => normalizePanelPatti(value))
    .filter((value): value is string => Boolean(value));
  const modes: PanelRankingMode[] = ['gap', 'frequency', 'hybrid', 'recent_frequency'];
  const start = Math.max(90, chronological.length - 200);
  const hits = Object.fromEntries(modes.map((mode) => [mode, 0])) as Record<PanelRankingMode, number>;
  let samples = 0;
  for (let index = start; index < chronological.length; index++) {
    const winning = chronological[index];
    // Double/Triple results remain in elapsed chart chronology (gap/cooldown),
    // but they are not eligible Single-Patti prediction samples.
    if (!isSinglePatti(winning)) continue;
    const winningAnk = panelAnkDigit(winning);
    if (winningAnk === null) continue;
    const history = chronological.slice(0, index).reverse();
    for (const mode of modes) {
      // Five Patti for one ANK equals its share of a balanced 30-Patti/6-ANK card.
      const selected = selectGapRotationPanels(history, [winningAnk], {
        cooldown: 10,
        limit: 5,
        minOutput: 0,
        balanceByAnk: false,
        rankingMode: mode,
      });
      if (selected.includes(winning)) hits[mode] += 1;
    }
    samples += 1;
  }
  const bestMode = modes.reduce((best, candidate) => hits[candidate] > hits[best] ? candidate : best, 'gap' as PanelRankingMode);
  const mode = samples >= 120 && hits[bestMode] >= hits.gap + 3 ? bestMode : 'gap';
  const scores = Object.fromEntries(modes.map((candidate) => [
    candidate,
    samples ? Number((100 * hits[candidate] / samples).toFixed(2)) : 0,
  ])) as Record<PanelRankingMode, number>;
  return { mode, samples, hits: hits[mode], passPercent: scores[mode], scores };
}
