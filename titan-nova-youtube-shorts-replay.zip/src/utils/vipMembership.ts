/** Consistent Indian business-date membership check for browser and server.
 * The expiry date is the FIRST day the VIP is inactive, matching the VIP list.
 * Invalid/missing dates do not authorize portal use.
 */
export function vipBusinessDate(now: number = Date.now()): string {
  return new Date(now + 330 * 60_000).toISOString().slice(0, 10);
}

export function validVipExpiryDate(value: unknown): value is string {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const timestamp = Date.parse(`${value}T00:00:00.000Z`);
  return Number.isFinite(timestamp) && new Date(timestamp).toISOString().slice(0, 10) === value;
}

export function vipMembershipActive(expiryDate: unknown, now: number = Date.now()): boolean {
  return validVipExpiryDate(expiryDate) && expiryDate > vipBusinessDate(now);
}

export function vipMembershipDaysLeft(expiryDate: unknown, now: number = Date.now()): number | null {
  if (!validVipExpiryDate(expiryDate)) return null;
  return Math.round((Date.parse(`${expiryDate}T00:00:00.000Z`) - Date.parse(`${vipBusinessDate(now)}T00:00:00.000Z`)) / 86_400_000);
}
