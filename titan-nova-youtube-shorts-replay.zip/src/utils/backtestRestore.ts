import {applyCarryResultSix} from './carryResultSix';
import {modelSourceVersion} from './marketModelCard';
import {holdBacktestSelection} from './backtestSelectionHold';
import {getScrapeSource,normalizeScrapeSource} from './scrapeProvenance';
import type { DayMarketRecord, DayRecordStore, UserProfile } from '../types';
import { businessDateIST } from './businessDate';
import { validLoopDate } from './dualLoops';
import { calculateBacktestRecovery } from './backtestRecovery';

const TRIAL_FIELDS = [
  'backtestResult', 'manualRate', 'manualStatus', 'manualOverrideAt',
  'manualResult', 'manualPanelResult', 'manualResultSources', 'scrapeResultDigit',
  'weekdayHitPosition', 'loopId', 'sentLoopId', 'recRate', 'prevLoss',
  'targetProfitWithLoss', 'rateFinalizedAt', 'rateFinalizedFrom',
  'sentRate', 'sentInvest', 'sentDigits', 'sentSourceMode', 'sentTrick',
  'sentScrapeSource', 'sentTargets', 'dispatchState', 'dispatchKey',
  'queuedAt', 'sentAt', 'settledAt', 'jodiOpenStatus', 'jodiOpenResult',
  'jodiOpenSettledAt', 'deliveryMissedAt', 'deliveryMissedReason', 'deliveryPartial',
  'loopAccountSkipped','loopAccountReason','loopAccountReservation','vipAutoStopSkipped','vipAutoStopResumeEligible',
  'backtestStakeLimitSkipped','backtestDailyStopLossSkipped','backtestDailyStopLossSourceSkipped',
  'backtestDailyProfitSkipped','backtestDailyProfitSourceSkipped','backtestSkipHistory','backtestRecoveryReset',
  'twoCardRecoveryShares','twoCardRecoveryStrategy',
] as const;

/** Explicit archive Restore releases the old trial, retaining prediction and settings. */
export function restoreBacktestRecord(record: DayMarketRecord): DayMarketRecord {
  const next: DayMarketRecord = { ...record, s: 'WAIT', r: '' };
  const source=normalizeScrapeSource(record.scrapeSource)||getScrapeSource(record);
  if(source){next.scrapeSource=source;if(!next.sourceMode)next.sourceMode=source.mode;}
  for (const field of TRIAL_FIELDS) delete (next as unknown as Record<string, unknown>)[field];
  if(!next.d.trim()&&next.carryResultSix?.output===''&&modelSourceVersion(next)===next.carryResultSix.outputVersion&&String(next.carryResultSix.input.d||'').trim())return applyCarryResultSix(next,[],false);
  return next;
}

/** All games together, including hidden cards. Reuse the existing recovery calculator. */
export function restoreBacktestDay(profile: UserProfile, date: string): UserProfile {
  if (!validLoopDate(date) || date >= businessDateIST()) throw new Error('Bulk Restore requires a valid past Ledger date');
  const original = profile.dayRecords?.[date];
  if (!original) return profile;
  const day = { ...original };
  delete day.loopAccountStops;
  for (const key of ['data', 'jodiData', 'pannelData'] as const) {
    if (original[key]) day[key] = Object.fromEntries(Object.entries(original[key]!).map(([index, rec]) => [index, holdBacktestSelection(restoreBacktestRecord(rec),date)]));
  }
  return calculateBacktestRecovery({ ...profile, dayRecords: { ...profile.dayRecords, [date]: day } }, date);
}

/** Carry unsaved selections in this date's request instead of flushing the
 * whole workspace. Equal/older sources cannot overwrite a newer saved edit. */
export function mergeRestoreSources(profile:UserProfile,date:string,source:DayRecordStore|undefined):UserProfile {
 if(!source)return profile;
 const old=profile.dayRecords[date]||{},day={...old};let changed=false;
 const fields=['d','od','sourceMode','scrapeSource','sourceEditedAt','trick','positionRule','weekdaySelectedDigits','weekdayHitPosition','firstDigitMirrorCut','tesla369','triCut','sniperOne','mssdState','marketModel','strictPanel30','smartSelection','carryResultSix','autoRemovedResult','autoResultParity','liveCombinedCut','openCloseCut','marketName'] as const;
 for(const key of ['data','jodiData','pannelData'] as const){
  const records={...old[key]};let touched=false;
  for(const [index,local] of Object.entries(source[key]||{})){
   if(!local||typeof local.d!=='string')continue;
   const stored=records[index];
   if(stored&&(modelSourceVersion(local)<=modelSourceVersion(stored)||(local.marketName&&stored.marketName&&local.marketName!==stored.marketName)))continue;
   const next:DayMarketRecord=stored?{...stored}:{s:'WAIT',r:'',d:''};
   for(const field of fields){if(local[field]===undefined)delete (next as any)[field];else (next as any)[field]=local[field];}
   records[index]=next;touched=true;
  }
  if(touched){day[key]=records;changed=true;}
 }
 return changed?{...profile,dayRecords:{...profile.dayRecords,[date]:day}}:profile;
}
