/**
 * Public API origin for the hybrid deployment.
 *
 * Local development keeps the original same-origin `/api/...` behavior.
 * Cloudflare Pages builds set VITE_API_BASE_URL to the current Cloudflare
 * Tunnel URL that points at the Termux server.
 */
const configuredApiBase = String(import.meta.env.VITE_API_BASE_URL || '')
  .trim()
  .replace(/\/+$/, '');

export const API_BASE_URL = configuredApiBase;

export function apiUrl(path: string): string {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  return API_BASE_URL ? `${API_BASE_URL}${normalizedPath}` : normalizedPath;
}
