/** Actual live recovery must not advance from an unsent backtest preview. */
export function liveVipRecoveryCards<T extends Record<string, any>>(cards:T, autoVip:boolean):T {
  if(!autoVip)return cards;
  let result:T|undefined;
  for(const [key,card] of Object.entries(cards)){
    if(!card?.backtestResult||card.manualStatus)continue;
    const delivered=Boolean(card.sentRate||card.sentDigits||card.sentAt||['SENT','SENT_PARTIAL','SETTLED'].includes(card.dispatchState));
    if(delivered)continue;
    if(card.s==='PASS'||card.s==='FAIL'){
      result ||= {...cards};delete result[key];
    }else if(card.jodiOpenStatus==='PASS'||card.jodiOpenStatus==='FAIL'){
      result ||= {...cards};
      const clean={...card};delete clean.jodiOpenStatus;delete clean.jodiOpenResult;delete clean.jodiOpenSettledAt;
      (result as Record<string,any>)[key]=clean;
    }
  }
  return result||cards;
}

/** Shared chronological selector for the sender and read-only queue diagnostics. */
import { areSettlementTokensValid, isRecoveryRatePossible } from "./settlement";

export function vipQueuePosition(markets:any[],cards:Record<string,any>,type:string,fromIndex:number,loopRevision=0):{kind:'in-flight'|'candidate';market:any}|{kind:'none'} {
  const inFlight=markets.find(m=>{
    const rec=cards[`${type}_${Number(m.index)}`];
    if(!loopRevision&&Number(m.index)<=fromIndex)return false;
    if(type==='jodi'&&(rec?.jodiOpenStatus==='PASS'||rec?.jodiOpenStatus==='FAIL'))return false;
    if(!rec||rec.deliveryRestoredAt||(rec.s&&rec.s!=='WAIT'))return false;
    return Boolean(rec.sentRate||rec.sentDigits||rec.dispatchState==='QUEUED'||rec.dispatchState==='SENT');
  });
  if(inFlight)return {kind:'in-flight',market:inFlight};
  const next=markets.find(m=>{
    if(Number(m.index)<=fromIndex)return false;
    const rec=cards[`${type}_${Number(m.index)}`];
    if(!rec||!String(rec.d||'').trim())return false;
    if(rec.deliveryRestoredAt||rec.deliveryMissedAt||(rec.s&&rec.s!=='WAIT'))return false;
    if(rec.sentRate||rec.sentDigits||rec.dispatchState==='QUEUED'||rec.dispatchState==='SENT')return false;
    if(!areSettlementTokensValid(type,rec.d)||!isRecoveryRatePossible(type,rec.d))return false;
    return true;
  });
  return next?{kind:'candidate',market:next}:{kind:'none'};
}

/** Heartbeats cannot run while JS is synchronously processing one delivery batch. */
export class LiveQueueFreshnessClock {
  private activeAt:number|undefined;
  constructor(private wallNow:()=>number=()=>Date.now()){}
  current():number{return this.activeAt??this.wallNow();}
  run<T>(callback:()=>T):T {
    const parent=this.activeAt;
    if(parent===undefined)this.activeAt=this.wallNow();
    try{return callback();}finally{this.activeAt=parent;}
  }
}

/** A poll proves activity only for the already-online exact registered session. */
export function noteRegisteredGatewayPoll(state:{online:boolean;sessionId:string;startedAt:number;lastSeen:number},sessionId:string,startedAt:number,now:number):boolean {
  if(!state.online||!sessionId||!Number.isFinite(startedAt)||startedAt<=0||state.sessionId!==sessionId||state.startedAt!==startedAt)return false;
  state.lastSeen=now;return true;
}
