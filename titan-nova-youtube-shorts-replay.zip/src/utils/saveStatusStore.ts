import type { SaveStatus } from './reliableStateSaver';

/** An external store avoids re-rendering the large dashboard for each save phase. */
export class SaveStatusStore {
  private value: SaveStatus = { phase: 'saved' };
  private readonly listeners = new Set<() => void>();
  readonly getSnapshot = () => this.value;
  readonly subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => { this.listeners.delete(listener); };
  };
  readonly set = (next: SaveStatus) => {
    if (next.phase === this.value.phase && next.message === this.value.message) return;
    this.value = next;
    this.listeners.forEach(listener => listener());
  };
}
