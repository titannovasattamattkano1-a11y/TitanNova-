import type {DayMarketRecord} from '../types';
import {getScrapeSource} from './scrapeProvenance';
import {isMirrorProtected} from './adminMirror';

export type CombinedCutInputs={auto:string[];day:string[];indices?:number[];position?:'first'|'last'};
/**
 * Combined Cut (A+D):
 * Cuts 4 digits (first 2 or last 2 of AUTO + DAY).
 * If there is any duplicate among the 4 digits or any digit is missing from current box,
 * it directly SKIPS the card (no fallback).
 */
export function applyBacktestCombinedCut(record:DayMarketRecord,inputs:CombinedCutInputs):DayMarketRecord {
  if(record.s==='SKIP'||isMirrorProtected(record)||record.dispatchState||record.deliveryRestoredAt)return record;
  const source=getScrapeSource(record);
  const selected=String(record.d||'').split(/[,|\s]+/).filter(Boolean);
  const position = inputs.position || 'first';
  const audit:NonNullable<DayMarketRecord['backtestCombinedCut']>={
    rule:'auto_day_recent2',
    position,
    auto:[...inputs.auto],
    day:[...inputs.day],
    indices:[...(inputs.indices||[])],
    fallback:[],
    removed:[],
    choices:[],
  };
  const next={...record,backtestCombinedCut:audit};
  const skip=(reason:string)=>({...next,s:'SKIP' as const,backtestCombinedCut:{...audit,reason}});
  if(!source)return skip('Combined cut: original ten-digit source missing');
  if(selected.length<=4||new Set(selected).size!==selected.length||!selected.every(d=>/^\d$/.test(d)))return skip('Combined cut: selection must contain more than four unique digits');
  if(inputs.auto.length!==2||inputs.day.length!==2||![...inputs.auto,...inputs.day].every(d=>/^\d$/.test(d)))return skip('Combined cut: AUTO/DAY two source digits missing');
  
  const main=[...inputs.auto,...inputs.day];
  // Direct SKIP on duplicate digits between AUTO and DAY (no fallback):
  if(new Set(main).size !== 4) {
    return skip(`Combined cut (${position}): duplicate digit in AUTO/DAY (${main.join(', ')}); card skipped directly`);
  }
  const present=new Set(selected);
  // Direct SKIP if any of the 4 target digits is not present in the current box:
  if(!main.every(d => present.has(d))) {
    return skip(`Combined cut (${position}): target digits (${main.join(', ')}) not all present in current box; card skipped directly`);
  }

  audit.choices = main.map(digit => ({ digit, via: 'original' as const }));
  audit.removed = [...main];
  next.d = selected.filter(d => !audit.removed.includes(d)).join(', ');
  next.od = source.digits;
  next.scrapeSource = source;
  delete next.trick;delete next.positionRule;delete next.weekdaySelectedDigits;delete next.weekdayHitPosition;
  delete next.scrapeResultDigit;delete next.manualResult;delete next.marketModel;
  if(!next.manualRate){delete next.recRate;delete next.prevLoss;delete next.targetProfitWithLoss;delete next.rateFinalizedFrom;delete next.rateFinalizedAt;}
  return next;
}
