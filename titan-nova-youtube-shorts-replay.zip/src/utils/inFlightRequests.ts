/** Share only a request already running. Completed responses are never reused. */
export class InFlightRequests<T> {
  private requests = new Map<string, Promise<T>>();

  run(key: string, fetcher: () => Promise<T>): Promise<T> {
    const existing = this.requests.get(key);
    if (existing) return existing;
    const request = Promise.resolve().then(fetcher);
    this.requests.set(key, request);
    const release = () => {
      if (this.requests.get(key) === request) this.requests.delete(key);
    };
    void request.then(release, release);
    return request;
  }
}
