/** Single approved chart publisher; previous saved provider URLs are ignored for stock markets. */
export const CHART_PROVIDER_HOSTS = ['playmatka.live', 'www.playmatka.live'] as const;
export function isChartProviderUrl(value: string): boolean {
  try {
    const u = new URL(value);
    return ['https:', 'http:'].includes(u.protocol)
      && CHART_PROVIDER_HOSTS.includes(u.hostname.toLowerCase() as any)
      && !u.username && !u.password && !u.port
      // Reject home/results pages and arbitrary endpoints. Every chart has
      // a single explicit market slug, never an auto-detected directory page.
      && /^\/panel-chart\/[a-z0-9]+(?:-[a-z0-9]+)*\/?$/.test(u.pathname)
      && !u.search;
  } catch { return false; }
}
export function resolveChartSource(market: string, configured: string | undefined, links: ReadonlyArray<{ n: string; l: string }>): string | undefined {
  const base = String(market || '').trim().toUpperCase().replace(/\s+(OPEN|CLOSE)$/i, '');
  const stock = links.find(item => item.n === base)?.l;
  if (stock) return stock;
  const custom = String(configured || '').trim();
  return isChartProviderUrl(custom) ? custom : undefined;
}
