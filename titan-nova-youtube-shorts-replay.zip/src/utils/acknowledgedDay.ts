import {rebasePendingEdits} from './rebasePendingEdits';
/** A selected-day settings response owns its settings at request time, not
 * source and visibility edits performed while that request was in flight. */
export function acknowledgedDay(before:any,saved:any,local:any){
 const wrap=(day:any)=>({profiles:{owner:{dayRecords:{selected:day||{}}}}});
 return rebasePendingEdits(wrap(saved),wrap(before),wrap(local)).state.profiles.owner.dayRecords.selected;
}
