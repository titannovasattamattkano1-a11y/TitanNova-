import type {ProfileConfig,UserProfile} from '../types';
import {businessDateIST} from './businessDate';
import {calculateBacktestRecovery} from './backtestRecovery';

/** Setup displays this date's economic inputs without replacing global delivery settings. */
export function financialSetupForDate(profile:UserProfile,date:string):ProfileConfig {
  const saved=profile.dayRecords[date]?.recoveryConfigSnapshot;
  if(!saved)return profile.config;
  return {...profile.config,capital:saved.capital,dayTarget:saved.dayTarget,ank:saved.ank,jodi:saved.jodi,pannel:saved.pannel};
}
/** Explicit Save may change a date snapshot; simply viewing it remains read-only. */
export function applyDatedFinancialSetup(profile:UserProfile,date:string,config:ProfileConfig):UserProfile {
  const today=businessDateIST();if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||date>today)throw new Error('Select today or a past date');
  const fields={capital:config.capital,dayTarget:config.dayTarget,ank:{...config.ank},jodi:{...config.jodi},pannel:{...config.pannel}};
  const day=profile.dayRecords[date]||{},base=date<today?day.recoveryConfigSnapshot||profile.config:profile.config;
  const snapshot=structuredClone({...base,...fields});
  const version=Math.max(Date.now(),Number(day.backtestRevision||0)+1);
  let next:UserProfile={...profile,config:date===today?{...profile.config,...fields}:profile.config,dayRecords:{...profile.dayRecords,[date]:{...day,recoveryConfigSnapshot:snapshot,backtestRevision:version}}};
  if(date<today)next=calculateBacktestRecovery(next,date);
  return next;
}
