export { getEffectiveMarkets } from '../data/markets';
import type { DayMarketRecord } from '../types';

const normalizeMarketIdentity = (value: unknown): string =>
  String(value || '')
    .trim()
    .replace(/\s+/g, ' ')
    .toUpperCase()
    .replace(/^(?:SHRIDEVI|SRIDEVI|SRIDEV) DAY\b/, 'SRIDEVI')
    .replace(/^(?:SHRIDEVI|SRIDEV)\b/, 'SRIDEVI');

export function findMarketIndexByName(
  markets: Array<{ n?: string }> | undefined,
  marketName: string,
): number {
  const target = normalizeMarketIdentity(marketName);
  if (!target || !Array.isArray(markets)) return -1;
  return markets.findIndex((market) => normalizeMarketIdentity(market?.n) === target);
}

/**
 * Resolve historical card by stable market identity. Index fallback is used
 * only for a fully legacy dictionary where no record has a stored name; once
 * named records exist, a missing name must not return another market's card.
 */
export function findHistoricalMarketRecord(
  records: Record<string | number, DayMarketRecord> | undefined,
  fallbackIndex: number,
  marketName: string,
): DayMarketRecord | undefined {
  if (!records) return undefined;
  const values = Object.values(records).filter(Boolean);
  const target = normalizeMarketIdentity(marketName);
  const exact = values.find((record) => normalizeMarketIdentity(record.marketName) === target);
  if (exact) return exact;
  const indexedLegacy = records[fallbackIndex];
  // BUG FIX: Partially migrated days may contain named and unnamed cards together; the same-index unnamed card remains a safe legacy match.
  if (indexedLegacy && !normalizeMarketIdentity(indexedLegacy.marketName)) return indexedLegacy;
  return undefined;
}

const descDatesCache = new WeakMap<object, { count: number; sorted: string[] }>();
const latestSettledCache = new WeakMap<object, { count: number; map: Map<string, { date: string; record: DayMarketRecord } | null> }>();

/** Find this market's latest settled card before the current business date. */
export function findLatestSettledMarketRecord(
  dayRecords: Record<string, any> | undefined,
  currentDate: string,
  dictName: 'data' | 'jodiData' | 'pannelData',
  fallbackIndex: number,
  marketName: string,
): { date: string; record: DayMarketRecord } | null {
  if (!dayRecords) return null;
  const rawKeys = Object.keys(dayRecords);
  let resEntry = latestSettledCache.get(dayRecords);
  if (!resEntry || resEntry.count !== rawKeys.length) {
    resEntry = { count: rawKeys.length, map: new Map() };
    latestSettledCache.set(dayRecords, resEntry);
  }
  const cacheKey = `${currentDate}|${dictName}|${fallbackIndex}|${marketName}`;
  if (resEntry.map.has(cacheKey)) return resEntry.map.get(cacheKey)!;

  let cached = descDatesCache.get(dayRecords);
  if (!cached || cached.count !== rawKeys.length) {
    cached = { count: rawKeys.length, sorted: rawKeys.sort((a, b) => b.localeCompare(a)) };
    descDatesCache.set(dayRecords, cached);
  }
  const allDesc = cached.sorted;
  const dates = allDesc.filter((date) => date < currentDate);
  for (const date of dates) {
    const record = findHistoricalMarketRecord(dayRecords[date]?.[dictName], fallbackIndex, marketName);
    if (record?.s === 'PASS' || record?.s === 'FAIL') {
      const hit = { date, record };
      resEntry.map.set(cacheKey, hit);
      return hit;
    }
  }
  resEntry.map.set(cacheKey, null);
  return null;
}

const POSITION_RULE_LABELS: Readonly<Record<string, string>> = {
  FCUT: 'Fcut',
  LCUT: 'Lcut',
  RECENT6: 'Keep6',
  RECENT4: 'Remove4',
  CENTER: 'Center',
  CUT2: 'Cut2',
  FIRST_CUT: 'FirstCut',
  FIRST_DIGIT_MIRROR: '1st+Mir',
  RECENT2: 'Recent2',
  LAST_ACTUAL_MIRROR: 'Act+Mir',
  SSD: 'SSD',
  WEEKDAY: 'WD',
  FLOW_3_1: '3+1 Flow',
  TRI_CUT: 'Tri-Cut',
  SNIPER_1: 'Sniper-1',
  TESLA_369: '3-6-9',
};

const COMPACT_FILTER_LABELS: Readonly<Record<string, string>> = {
  Keep6: 'K6',
  Remove4: 'R4',
  Fcut: 'FC',
  Lcut: 'LC',
  T1: 'T1',
  T2: 'T2',
  T3: 'T3',
  Center: 'CT',
  'Tri-Cut': 'TC',
  'Sniper-1': 'S1',
  '3-6-9': '369',
  Cut2: 'C2',
  FirstCut: '1C',
  '1st+Mir': '1M',
  Recent2: 'R2',
  'Act+Mir': 'AM',
  SSD: 'SSD',
  WD: 'WD',
  '3+1 Flow': '3+1',
};

function canonicalSingleDigits(value: unknown): string[] {
  return String(value || '')
    .split(/[,|\s]+/)
    .map((token) => token.trim())
    .filter((token) => /^\d$/.test(token));
}

/**
 * Resolve which filter/trick was used on a card (from explicit trick/positionRule
 * metadata, or deterministically inferred from its 10-digit source and selected digits).
 */
export function getRecordFilterLabel(
  record: DayMarketRecord | undefined,
  priorUniqueIndices?: number[],
): string | null {
  if (!record) return null;
  const explicitTrick = record.sentTrick || record.trick || record.autoResultParity?.inputTrick;
  if (explicitTrick === 'T1' || explicitTrick === 'T2' || explicitTrick === 'T3') {
    return explicitTrick;
  }
  const explicitRule =
    (record as any).sentPositionRule ||
    record.positionRule ||
    record.autoResultParity?.cut ||
    record.autoResultParity?.inputPositionRule;
  if (explicitRule && POSITION_RULE_LABELS[explicitRule]) {
    if (explicitRule === 'FIRST_DIGIT_MIRROR') {
      return record.firstDigitMirrorCut?.stage === 1 ? 'FirstCut' : '1st+Mir';
    }
    return POSITION_RULE_LABELS[explicitRule];
  }
  const rawSource =
    record.sentScrapeSource?.digits ||
    record.scrapeSource?.digits ||
    record.od ||
    '';
  const sourceTokens = canonicalSingleDigits(rawSource);
  const selectedTokens = canonicalSingleDigits(
    record.autoRemovedResult?.input || record.sentDigits || record.d,
  );
  if (sourceTokens.length >= 5 && selectedTokens.length > 0 && selectedTokens.length < sourceTokens.length) {
    const selected = selectedTokens.join(', ');
    if (selected === sourceTokens.slice(4).join(', ')) return 'Fcut';
    if (selected === sourceTokens.slice(0, -4).join(', ')) return 'Lcut';
    const t1 = sourceTokens.slice(0, 10).filter((_, idx) => idx % 2 === 0).join(', ');
    if (selected === t1) return 'T1';
    const t2 = sourceTokens.slice(0, 10).filter((_, idx) => idx % 2 === 1).join(', ');
    if (selected === t2) return 'T2';
    const t3 = [sourceTokens[1], sourceTokens[2], sourceTokens[6], sourceTokens[7]].filter(Boolean).join(', ');
    if (selected === t3) return 'T3';
    if (Array.isArray(priorUniqueIndices) && priorUniqueIndices.length >= 4) {
      if (priorUniqueIndices.length >= 6) {
        const keep6Set = new Set(priorUniqueIndices.slice(0, 6));
        const keep6Digits = sourceTokens.filter((_, idx) => keep6Set.has(idx + 1)).join(', ');
        if (selected === keep6Digits) return 'Keep6';
      }
      const remove4Set = new Set(priorUniqueIndices.slice(0, 4));
      const remove4Digits = sourceTokens.filter((_, idx) => !remove4Set.has(idx + 1)).join(', ');
      if (selected === remove4Digits) return 'Remove4';
    }
    if (sourceTokens.length >= 6 && selected === sourceTokens.slice(2, -2).join(', ')) return 'Center';
    if (sourceTokens.length >= 4 && selected === sourceTokens.slice(1, -1).join(', ')) return 'Cut2';
    if (sourceTokens.length >= 2 && selected === sourceTokens.slice(1).join(', ')) return 'FirstCut';
  }
  return null;
}

export function getCompactFilterBadge(
  record: DayMarketRecord | undefined,
  priorUniqueIndices?: number[],
): string | undefined {
  const label = getRecordFilterLabel(record, priorUniqueIndices);
  return label ? COMPACT_FILTER_LABELS[label] || label : undefined;
}

/**
 * Given yesterday's settled record and its filter, return today's recommended
 * filter (PASS switches complementary filter pairs; FAIL repeats/keeps).
 */
export function getNextDayFilterRecommendation(
  record: DayMarketRecord | undefined,
  resolvedFilter?: string | null,
): string | null {
  if (!record || (record.s !== 'PASS' && record.s !== 'FAIL')) return null;
  const used = resolvedFilter ?? getRecordFilterLabel(record);
  if (!used) return null;
  const isPass = record.s === 'PASS';
  if (used === 'Fcut') return isPass ? 'Lcut' : 'Fcut';
  if (used === 'Lcut') return isPass ? 'Fcut' : 'Lcut';
  if (used === 'T1') return isPass ? 'T2' : 'T1';
  if (used === 'T2') return isPass ? 'T1' : 'T2';
  if (used === 'T3') return 'T3';
  if (used === 'Keep6') return isPass ? 'Remove4' : 'Keep6';
  if (used === 'Remove4') return isPass ? 'Keep6' : 'Remove4';
  return used;
}

/**
 * Yesterday-driven bulk rule requested by the operator.
 * Operator state machine: FAIL keeps yesterday's T1/T2, while PASS switches
 * T1 ↔ T2. T3 remains manual and is never advanced automatically.
 */
export function getYesterdayAutoTrick(record: DayMarketRecord | undefined): 1 | 2 | null {
  if (!record) return null;
  const frozenTrick = record.sentTrick || record.trick;
  if (frozenTrick !== 'T1' && frozenTrick !== 'T2') return null;
  if (record.s === 'PASS') return frozenTrick === 'T1' ? 2 : 1;
  if (record.s === 'FAIL') return frozenTrick === 'T1' ? 1 : 2;
  return null;
}

/**
 * Reduce an applied six-digit T1/T2 selection to five digits.
 * T1 drops the last digit; T2 drops the first. Other shapes are left alone.
 */
export function trimAppliedTrickDigit(record: DayMarketRecord | undefined): string | null {
  if (!record || (record.trick !== 'T1' && record.trick !== 'T2')) return null;
  const digits = String(record.d || '')
    .split(/[,|\s]+/)
    .map((digit) => digit.trim())
    .filter(Boolean);
  if (digits.length !== 6 || digits.some((digit) => !/^\d$/.test(digit))) return null;
  const trimmed = record.trick === 'T1' ? digits.slice(0, -1) : digits.slice(1);
  return trimmed.join(', ');
}
