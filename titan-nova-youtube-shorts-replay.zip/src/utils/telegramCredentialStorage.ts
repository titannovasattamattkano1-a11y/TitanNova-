const KEY = 'titan-telegram-key';

/** Browser-origin scoped. Never include this credential in shared profile state. */
export function readTelegramKey(): string {
  try {
    const saved = localStorage.getItem(KEY);
    if (saved) return saved;
  } catch { /* Restricted browser storage: retain the session fallback. */ }
  try {
    const legacy = sessionStorage.getItem(KEY) || '';
    if (legacy) storeTelegramKey(legacy);
    return legacy;
  } catch { return ''; }
}

/** Returns false if the browser cannot persist the key across sessions. */
export function storeTelegramKey(value: string): boolean {
  const key = value.trim();
  try {
    if (key) localStorage.setItem(KEY, key);
    else localStorage.removeItem(KEY);
    try { sessionStorage.removeItem(KEY); } catch { /* Already persisted. */ }
    return true;
  } catch {
    try {
      if (key) sessionStorage.setItem(KEY, key);
      else sessionStorage.removeItem(KEY);
    } catch { /* Caller displays the persistence warning. */ }
    return false;
  }
}
