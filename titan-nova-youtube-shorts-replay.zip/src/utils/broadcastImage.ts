export const BROADCAST_DESIGNS=[
 {name:'Corporate',bg:'#eef3f8',panel:'#ffffff',ink:'#1d3047',accent:'#175dcc'},
 {name:'Premium',bg:'#141719',panel:'#1c2022',ink:'#fff7e8',accent:'#d5b477'},
 {name:'News Alert',bg:'#f1f0ec',panel:'#ffffff',ink:'#171c22',accent:'#c93232'},
 {name:'Modern Poster',bg:'#18266c',panel:'#ffffff',ink:'#172f50',accent:'#52e2d0'},
 {name:'Minimal Letter',bg:'#eeeae3',panel:'#fffefa',ink:'#313c48',accent:'#506c66'},
] as const;
export interface BroadcastPresentation{format:'text'|'png';design:number;png?:string;link?:string}
/** Local-only canvas; wrap every grapheme without dropping words or blank lines. */
export function renderBroadcastImage(title:string,message:string,design:number):string{
 const theme=BROADCAST_DESIGNS[design];if(!theme)throw Error('Choose one of the five PNG designs');
 if(title.length>500||message.length>12000)throw Error('PNG content is too long. Shorten it or use TXT; nothing has been sent.');
 const canvas=document.createElement('canvas');canvas.width=1080;
 const ctx=canvas.getContext('2d');if(!ctx)throw Error('PNG preview unavailable; nothing has been sent.');
 const layouts=[
  {width:864,x:108,top:270,titleSize:54,titleStep:72,bodySize:36,bodyStep:56,gap:90,minHeight:900,family:'Arial, sans-serif',titleFamily:'Arial, sans-serif'},
  {width:816,x:132,top:248,titleSize:56,titleStep:76,bodySize:36,bodyStep:58,gap:108,minHeight:980,family:'Georgia, serif',titleFamily:'Georgia, serif'},
  {width:888,x:96,top:245,titleSize:64,titleStep:82,bodySize:38,bodyStep:58,gap:100,minHeight:900,family:'Arial, sans-serif',titleFamily:'Arial, sans-serif'},
  {width:816,x:132,top:224,titleSize:64,titleStep:82,bodySize:36,bodyStep:56,gap:160,minHeight:980,family:'Arial, sans-serif',titleFamily:'Arial, sans-serif'},
  {width:848,x:116,top:300,titleSize:48,titleStep:68,bodySize:36,bodyStep:60,gap:88,minHeight:1100,family:'Georgia, serif',titleFamily:'Georgia, serif'},
 ];
 const layout=layouts[design],width=layout.width-(design===0?22:0),segmenter=new Intl.Segmenter(undefined,{granularity:'grapheme'});
 const wrap=(value:string,size:number,bold=false,family=layout.family)=>{
  ctx.font=`${bold?700:500} ${size}px ${family}`;
  const lines:string[]=[];
  for(const paragraph of value.replace(/\r\n?/g,'\n').split('\n')){
   let line='';
   for(const token of paragraph.match(/\s+|\S+/gu)||[]){
    if(ctx.measureText(token).width<=width){
     if(line&&ctx.measureText(line+token).width>width){lines.push(line);line='';}
     line+=token;
    }else for(const {segment} of segmenter.segment(token)){
     if(line&&ctx.measureText(line+segment).width>width){lines.push(line);line='';}
     line+=segment;
    }
   }
   lines.push(line);
  }
  return lines;
 };
 const heading=wrap(title,layout.titleSize,true,layout.titleFamily),body=wrap(message,layout.bodySize);
 const titleBottom=layout.top+(heading.length-1)*layout.titleStep;
 const bodyTop=titleBottom+layout.gap;
 const height=Math.max(layout.minHeight,bodyTop+body.length*layout.bodyStep+210);
 if(height>8000){canvas.width=0;throw Error('PNG content is too tall. Shorten it or use TXT; nothing has been sent.');}
 try{
  canvas.height=height;
  const rect=(x:number,y:number,w:number,h:number,color:string)=>{ctx.fillStyle=color;ctx.fillRect(x,y,w,h);};
  const line=(x:number,y:number,w:number,color:string)=>rect(x,y,w,2,color);
  const text=(value:string,x:number,y:number,size:number,color:string,font='Arial, sans-serif',bold=false,align:CanvasTextAlign='left')=>{
   ctx.textAlign=align;ctx.fillStyle=color;ctx.font=`${bold?700:500} ${size}px ${font}`;ctx.fillText(value,x,y);
  };
  const logo=(x:number,y:number,color:string,ink:string)=>{rect(x,y,62,62,color);text('TN',x+31,y+41,26,ink,'Arial, sans-serif',true,'center');};
  rect(0,0,1080,height,theme.bg);
  if(design===0){
   // Corporate: letterhead, blue masthead, left aligned executive title and report panel.
   rect(38,38,1004,height-76,theme.panel);rect(38,38,1004,14,theme.accent);
   logo(108,100,theme.accent,'#ffffff');text('TITAN NOVA',192,127,34,theme.ink,'Arial, sans-serif',true);
   text('LIVE PUSH BROADCAST',192,160,18,'#657b92');line(108,202,864,'#dce5ee');
   rect(108,bodyTop-40,5,(body.length-1)*layout.bodyStep+62,theme.accent);
   line(108,height-142,864,'#dce5ee');text('TITAN NOVA VIP',108,height-92,22,theme.accent);
   text('ANNOUNCEMENT',972,height-92,18,'#657b92','Arial, sans-serif',false,'right');
  }else if(design===1){
   // Premium: centered serif headline, inset double frame and gold ornaments.
   rect(38,38,1004,height-76,theme.accent);rect(41,41,998,height-82,theme.bg);
   ctx.strokeStyle='#756547';ctx.lineWidth=1;ctx.strokeRect(62,62,956,height-124);
   text('TITAN NOVA',540,131,30,theme.accent,'Georgia, serif',true,'center');
   text('VIP  /  LIVE BROADCAST',540,170,17,'#b8afa0','Arial, sans-serif',false,'center');
   const ruleY=titleBottom+48;line(340,ruleY,160,theme.accent);line(580,ruleY,160,theme.accent);
   ctx.fillStyle=theme.accent;ctx.beginPath();ctx.moveTo(540,ruleY-10);ctx.lineTo(550,ruleY);ctx.lineTo(540,ruleY+10);ctx.lineTo(530,ruleY);ctx.closePath();ctx.fill();
   line(400,height-130,280,'#756547');text('TITAN NOVA VIP',540,height-83,21,theme.accent,'Georgia, serif',false,'center');
  }else if(design===2){
   // News: red bulletin ribbon, oversized headline, black rule and article column.
   rect(42,42,996,height-84,theme.panel);rect(42,42,996,98,theme.accent);
   text('LIVE',96,105,33,'#ffffff','Arial, sans-serif',true);rect(220,68,2,46,'#ffffff88');
   text('TITAN NOVA  /  NEWS DESK',252,103,24,'#ffffff','Arial, sans-serif',true);
   line(96,titleBottom+42,888,theme.ink);rect(96,titleBottom+42,110,7,theme.accent);
   rect(42,height-135,996,93,'#171c22');text('TITAN NOVA VIP',96,height-79,22,'#ffffff');
   text('LIVE PUSH',984,height-79,20,'#f47878','Arial, sans-serif',true,'right');
  }else if(design===3){
   // Poster: gradient hero, geometric corner art, offset rounded content card.
   const gradient=ctx.createLinearGradient(0,0,1080,bodyTop+100);gradient.addColorStop(0,'#18266c');gradient.addColorStop(1,'#7b318c');ctx.fillStyle=gradient;ctx.fillRect(0,0,1080,height);
   ctx.fillStyle='#ffffff0c';ctx.beginPath();ctx.arc(1050,55,260,0,Math.PI*2);ctx.fill();
   ctx.strokeStyle='#52e2d066';ctx.lineWidth=22;ctx.beginPath();ctx.arc(1010,80,165,0,Math.PI*2);ctx.stroke();
   rect(96,86,8,40,theme.accent);text('TITAN NOVA',128,117,28,'#ffffff','Arial, sans-serif',true);
   text('LIVE PUSH',128,151,17,'#d7d8ff');
   ctx.fillStyle='#080b2b44';ctx.beginPath();ctx.roundRect(86,bodyTop-62,924,height-bodyTop-62,28);ctx.fill();
   ctx.fillStyle='#ffffff';ctx.beginPath();ctx.roundRect(78,bodyTop-70,924,height-bodyTop-62,28);ctx.fill();
   rect(132,bodyTop-44,76,6,'#6543aa');text('TITAN NOVA VIP',132,height-52,22,'#ffffff');
  }else{
   // Letter: warm paper, understated monogram, editorial serif body and sign-off.
   rect(38,32,1004,height-64,theme.panel);
   text('TITAN',116,119,34,theme.ink,'Georgia, serif',true);text('NOVA',116,153,20,theme.accent,'Arial, sans-serif',true);
   text('VIP COMMUNICATION',964,124,17,theme.accent,'Arial, sans-serif',false,'right');
   line(116,197,848,'#c4cdc8');
   text('TITAN NOVA',116,height-144,30,theme.accent,'Georgia, serif',true);
   text('VIP BROADCAST',116,height-110,16,'#77817c');line(116,height-73,848,'#c4cdc8');
  }
  const centered=design===1,titleInk=design===3?'#ffffff':theme.ink;
  heading.forEach((value,i)=>text(value,centered?540:layout.x,layout.top+i*layout.titleStep,layout.titleSize,titleInk,layout.titleFamily,true,centered?'center':'left'));
  const bodyX=design===0?layout.x+22:layout.x;
  // Corporate's inset stripe consumes 22px; wrap to that narrower content width above.
  body.forEach((value,i)=>text(value,bodyX,bodyTop+i*layout.bodyStep,layout.bodySize,theme.ink,layout.family));
  const png=canvas.toDataURL('image/png');if(png.length>5600000)throw Error('PNG is too large. Shorten the message or use TXT.');return png;
 }finally{canvas.width=0;canvas.height=0;}
}
