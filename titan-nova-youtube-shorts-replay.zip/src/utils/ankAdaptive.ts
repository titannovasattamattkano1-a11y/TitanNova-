import { selectRecentUniqueDigits } from './scrapeSelection';

export type AnkRankingMode = 'recent_unique' | 'frequency' | 'recent_frequency_30' | 'recent_frequency_60' | 'recent_frequency_120' | 'recent_frequency_180' | 'gap' | 'markov' | 'ensemble';
const DIGITS = Array.from({ length: 10 }, (_, index) => String(index));
const validHistory = (values: unknown[]) => values.map((value) => String(value ?? '').trim()).filter((value) => /^\d$/.test(value));

export function selectAnkDigits(recentToOld: unknown[], mode: AnkRankingMode, limit = 6): string[] {
  const history = validHistory(recentToOld);
  const take = Math.max(0, Math.min(10, Math.floor(limit)));
  if (!take || !history.length) return [];
  if (mode === 'recent_unique') return selectRecentUniqueDigits(history, take);
  const total = new Map(DIGITS.map((digit) => [digit, 0]));
  const gap = new Map(DIGITS.map((digit) => [digit, Number.MAX_SAFE_INTEGER]));
  history.forEach((digit, index) => {
    total.set(digit, (total.get(digit) || 0) + 1);
    if (gap.get(digit) === Number.MAX_SAFE_INTEGER) gap.set(digit, index);
  });
  const recentFrequency = (window: number) => {
    const counts = new Map(DIGITS.map((digit) => [digit, 0]));
    history.slice(0, window).forEach((digit) => counts.set(digit, (counts.get(digit) || 0) + 1));
    return counts;
  };
  if (mode === 'frequency') return [...DIGITS].sort((a, b) => (total.get(b) || 0) - (total.get(a) || 0) || (gap.get(b) || 0) - (gap.get(a) || 0)).slice(0, take);
  if (mode.startsWith('recent_frequency_')) {
    const counts = recentFrequency(Number(mode.split('_').at(-1)) || 60);
    return [...DIGITS].sort((a, b) => (counts.get(b) || 0) - (counts.get(a) || 0) || (gap.get(b) || 0) - (gap.get(a) || 0)).slice(0, take);
  }
  if (mode === 'gap') return [...DIGITS].sort((a, b) => (gap.get(b) || 0) - (gap.get(a) || 0) || (total.get(b) || 0) - (total.get(a) || 0)).slice(0, take);
  const chronological = [...history].reverse();
  const latest = history[0];
  const transitions = new Map(DIGITS.map((digit) => [digit, 0]));
  for (let index = 0; index + 1 < chronological.length; index++) {
    if (chronological[index] === latest) {
      const next = chronological[index + 1];
      transitions.set(next, (transitions.get(next) || 0) + 1);
    }
  }
  if (mode === 'markov') return [...DIGITS].sort((a, b) => (transitions.get(b) || 0) - (transitions.get(a) || 0) || (total.get(b) || 0) - (total.get(a) || 0)).slice(0, take);
  const recent120 = recentFrequency(120);
  const score = (digit: string) => 3 * (transitions.get(digit) || 0) + (recent120.get(digit) || 0) + 0.15 * (total.get(digit) || 0);
  return [...DIGITS].sort((a, b) => score(b) - score(a) || (gap.get(b) || 0) - (gap.get(a) || 0)).slice(0, take);
}

export interface AnkStrategyResult { mode: AnkRankingMode; digits: string[]; samples: number; hits: number; passPercent: number; scores: Record<AnkRankingMode, number>; selectionRule: 'precutoff_champion' | 'short_history_fallback' }

export function chooseAnkRankingByBacktest(recentToOld: unknown[]): AnkStrategyResult {
  const chronological = validHistory([...recentToOld].reverse());
  const modes: AnkRankingMode[] = ['recent_unique', 'frequency', 'recent_frequency_30', 'recent_frequency_60', 'recent_frequency_120', 'recent_frequency_180', 'gap', 'markov', 'ensemble'];
  const start = Math.max(90, chronological.length - 200);
  const hits = Object.fromEntries(modes.map((mode) => [mode, 0])) as Record<AnkRankingMode, number>;
  let samples = 0;
  for (let index = start; index < chronological.length; index++) {
    const history = chronological.slice(0, index).reverse();
    for (const mode of modes) if (selectAnkDigits(history, mode, 6).includes(chronological[index])) hits[mode] += 1;
    samples += 1;
  }
  const bestMode = modes.reduce((best, candidate) => hits[candidate] > hits[best] ? candidate : best, 'recent_unique' as AnkRankingMode);
  // Strict pre-cutoff champion: after a usable sample exists, use the mode
  // with the most walk-forward hits. Future outcomes never participate in the
  // choice. Short histories retain the deterministic Recent Unique fallback.
  const mode = samples >= 120 ? bestMode : 'recent_unique';
  const scores = Object.fromEntries(modes.map((candidate) => [candidate, samples ? Number((100 * hits[candidate] / samples).toFixed(2)) : 0])) as Record<AnkRankingMode, number>;
  return { mode, digits: selectAnkDigits(recentToOld, mode, 6), samples, hits: hits[mode], passPercent: scores[mode], scores, selectionRule: samples >= 120 ? 'precutoff_champion' : 'short_history_fallback' };
}
