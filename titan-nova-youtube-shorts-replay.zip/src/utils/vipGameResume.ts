import type { GameType, UserProfile } from '../types';
import {getEffectiveMarkets} from '../data/markets';

/** Resume uses the actual cutoff, not the result parser's early-publication tolerance. */
export function vipResumeCutoffReached(saved: UserProfile, runtime: any, market: any, type: GameType, now = new Date()): boolean {
  const name=String(market?.n||'');
  const deadlineName=type==='jodi'?`${name.replace(/\s+(OPEN|CLOSE)$/i,'').trim()} OPEN`:name;
  const runtimeDeadline=(runtime?.markets||[]).find((m:any)=>m.type==='ank' && m.n===deadlineName);
  const savedDeadline=getEffectiveMarkets(saved.config).find(m=>m.n===deadlineName);
  const deadline=type==='jodi' ? runtimeDeadline||savedDeadline : market;
  const hour=Number(deadline?.hr ?? savedDeadline?.hr),minute=Number(deadline?.min ?? savedDeadline?.min);
  // Unknown custom-market timing cannot prove a market was missed.
  if(!Number.isFinite(hour)||!Number.isFinite(minute)||hour<0||hour>23||minute<0||minute>59)return false;
  const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Kolkata',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(now);
  const h=Number(parts.find(p=>p.type==='hour')?.value),m=Number(parts.find(p=>p.type==='minute')?.value);
  const businessMinute=(h:number,m:number)=>(h<6?1440:0)+h*60+m;
  return businessMinute(h,m)>=businessMinute(hour,minute);
}

/** Release only this unsent card's pause/cancellation keys; sent dedupe is never removed. */
export function vipResumeExpiredKeys(pid:string,date:string,key:string,card:any):string[] {
  const base=`vipauto_${pid}_${date}_${key}`;
  const dispatchKey=String(card.dispatchKey||'');
  return [...new Set([base,...(card.cardGeneration?[`${base}_g${card.cardGeneration}`]:[]),...((dispatchKey===base||dispatchKey.startsWith(`${base}_g`))?[dispatchKey]:[])])];
}
