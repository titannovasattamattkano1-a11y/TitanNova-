import type {DayMarketRecord,GameType,ProfileConfig,UserProfile} from '../types';
import {getEffectiveMarkets,getEffectiveBaseMarkets} from '../data/markets';
import {findHistoricalMarketRecord} from './cardHistory';
import {isMarketEnabledForDate} from './profileMarketToggle';
import {remapCardReferences} from './cardReferences';

/** A visibility switch cannot reverse a real/manual play or an in-flight claim. */
export function isRecordedPlay(record:Partial<DayMarketRecord>|undefined):boolean {
  return Boolean(record&&(record.sentRate||record.sentDigits||record.sentAt||record.dispatchState||(record.manualStatus&&(record.s==='PASS'||record.s==='FAIL'))||
    ((record.s==='PASS'||record.s==='FAIL')&&!record.backtestResult)));
}
export interface FinancialMarket {n:string;type:GameType;index:number;enabled:boolean;hr?:number;min?:number}

/** Include hidden booked history without making it eligible for another send.
 * The same source is used for wallets and restoring a server ledger. */
export function buildFinancialLedger(profile:UserProfile,date:string,catalog:ProfileConfig=profile.config){
  const day=profile.dayRecords?.[date]||{},cards:Record<string,DayMarketRecord>={},markets:FinancialMarket[]=[],references:Record<string,string>={};
  const active=getEffectiveMarkets(catalog);
  const known=[...getEffectiveMarkets(profile.config),...getEffectiveMarkets({...catalog,deletedMarketNames:[]})];
  for(const type of ['ank','jodi','pannel'] as const){
    const dict=day[type==='ank'?'data':type==='jodi'?'jodiData':'pannelData']||{};
    const visibility=day[type==='ank'?'visAnk':type==='jodi'?'visJodi':'visPan'];
    const list=type==='jodi'?getEffectiveBaseMarkets(catalog):active;
    const used=new Set<DayMarketRecord>(),oldKeys=new Map(Object.entries(dict).map(([index,record])=>[record,index]));
    for(const [index,market] of list.entries()){
      const close=type==='jodi'?active.find(m=>m.n===market.n+' CLOSE'):undefined;
      markets.push({...market,...(close?{hr:close.hr,min:close.min}:{}),type,index,enabled:isMarketEnabledForDate(profile.config,visibility,market.n,date)});
      const record=findHistoricalMarketRecord(dict,index,market.n);if(!record)continue;
      used.add(record);cards[`${type}_${index}`]={...record,marketName:market.n};
      references[`${type}_${oldKeys.get(record)}`]=`${type}_${index}`;
    }
    let orphan=-1;
    for(const [oldIndex,record] of Object.entries(dict)){
      if(used.has(record)||!isRecordedPlay(record))continue;
      let index=Number(oldIndex);
      if(!Number.isInteger(index)||index>=0||cards[`${type}_${index}`]){while(cards[`${type}_${orphan}`])orphan--;index=orphan--;}
      const n=record.marketName||'',prior=known.find(m=>m.n===(type==='jodi'?n+' CLOSE':n));
      markets.push({n,type,index,enabled:false,...(prior?{hr:prior.hr,min:prior.min}:{})});
      cards[`${type}_${index}`]={...record};references[`${type}_${oldIndex}`]=`${type}_${index}`;
    }
  }
  for(const key of Object.keys(cards))cards[key]=remapCardReferences(cards[key],references);
  return {cards,markets};
}
