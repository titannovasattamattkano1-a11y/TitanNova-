import {SOURCE_HISTORY_POLICY,checkedSourceHistory,type SourceHistoryAnalysis} from './sourceWindowHistory';
import {newerSourceOverEmptyArchive,newerReplacementArchiveSource,newerResultForSameArchiveSource,reconcileArchiveDayRevision,retainedCheckedArchiveCard} from './archiveSourceReconciliation';
import {applyCarryResultSix,carryResultSixHistory,findPrecedingLoopCard} from './carryResultSix';
import {selectCarry6} from './carry6';
import {supportsMarketHistorySource,HISTORY_WINDOW_DAYS} from './marketHistoryLogic';
import {recentSixUniqueIndices,keepRecentSixIndices,recentUniqueSourceIndices,removeRecentFourIndices} from './keepRecentSixIndices';
import {backtestMarketBase,backtestMarketSelected} from './backtestMarketSelection';
import {observeSkippedAnk,skippedHistoryRecord} from './backtestSkipHistory';
import {applyBacktestCombinedKeep} from './backtestCombinedKeep';
import type { AppState, BacktestRecoveryPolicy, CardSourceMode, DayMarketRecord, GameType, ProfileConfig, UserProfile } from '../types';
import { getEffectiveMarkets, getEffectiveBaseMarkets } from '../data/markets';
import { resolveMarketScrapeUrl } from './marketCatalogMigration';
import { businessDateIST } from './businessDate';
import { pinDayLoops } from './dualLoops';
import { isMarketEnabledForDate } from './profileMarketToggle';
import { isMarketOpenOnDate, sourceIndexWeekLength } from './sourceIndexDisplayDates';
import { scrapeRecordVersion } from './scrapeCommitGuard';
import { actualForGame, evaluateDatedBacktest, type DatedActual } from './backtestResult';
import { backtestDailyTargetReached,backtestDailyStopLossReached, calculateBacktestRecovery } from './backtestRecovery';
import { areSettlementTokensValid, isRecoveryRatePossible } from './settlement';
import { getScrapeSource, normalizeScrapeSource } from './scrapeProvenance';
import { applyMarketModelSummary, summarizeMarketModel, modelSourceVersion } from './marketModelCard';
import { removeFirstFourSourceIndices } from './removeFirstFour';
import { buildJodisFromAnk } from './jodiFromAnk';
import { calculateProtocolStats, applyTrickFormula } from './calculator';
import { recentSourceIndices as savedRecentSourceIndices, removeRecentTwoIndices, removeRecentTwoAndScrapeDigits, SOURCE_INDEX_HISTORY_DAYS } from './removeRecentSourceIndices';
import { findHistoricalMarketRecord } from './cardHistory';
import { findLatestSettledMarketRecord, getYesterdayAutoTrick, trimAppliedTrickDigit } from './cardHistory';
import { calculateCapitalWallet } from './capitalWallet';
import {applyBacktestCombinedCut,type CombinedCutInputs} from './backtestCombinedCut';
import { applySelfLearning90DayBacktestSelection } from './selfLearningEngine';

export const RANGE_MODES = ['scrape','weekday','combo','day_combo','smart','market_model','pair_combo','freq_10','freq_10_combo','dynamic_4ank','open_auto_close_day'] as const;
export type RangeMode = typeof RANGE_MODES[number];
// Skipped result indices are opt-in for this archive strategy, never live bulk.
const recentSourceIndices=(days:UserProfile['dayRecords'],date:string,index:number,market:string,count:2|4=2,includeFail=false)=>savedRecentSourceIndices(days,date,index,market,count,includeFail,true);
export const RANGE_SELECTIONS = [
  ['self_learn_90d','🧠 AI PER-MARKET 12-TRICK TOURNAMENT · 2-FAIL MOOD SWITCH (90D)'],
  ['carry_result6','CARRY RESULT 6 · ACTUALS ONLY · CONTINUOUS DAYS'],
  ['carry6','CARRY6 · SOURCE LAST 2 + AUTO / DAY / COMBO / DAY MIX'],
  ['history_apply','HISTORY APPLY · SOURCE WINDOW KEEP6 / REMOVE4'],
  ['first4','✂ INDEX 1–4 CUT · CURRENT DIGITS'],
  ['recent2','RECENT 2 INDICES✅'],
  ['recent6_keep','KEEP RECENT 6 UNIQUE INDICES✅'],
  ['recent4','✂ RECENT 4 UNIQUE INDICES REMOVE BULK'],
  ['auto_day_recent2_keep','KEEP RECENT 2 + DAY 2 + INDEX 2 · BACKTEST ONLY'],
  ['auto_day_recent2','COMBINED AUTO + DAY · 4 CUT · BACKTEST ONLY'],
  ['result_parity','F/C/L-cut · Fcut / Center / Lcut'],
  ['yday','↶ YDAY AUTO · PASS SWITCH · FAIL KEEP'],
  ['yday_trim','✂ YDAY AUTO + 6→5 · T1 LAST / T2 FIRST'],
  ['t1','T1 ODD · 1 3 5 7 9 BULK'], ['t2','T2 EVEN · 2 4 6 8 0 BULK'], ['t3','T3 TRICK BULK'],
  ['t1_trim','T1 TRICK + 6→5 · REMOVE LAST'],
  ['t2_trim','T2 TRICK + 6→5 · REMOVE FIRST'],
  ['keep','Keep scraper selection'],
] as const;
export type RangeSelection = typeof RANGE_SELECTIONS[number][0];
export function rangeHistorySource(mode:RangeMode,market:string):CardSourceMode|undefined {
  const effective=mode==='open_auto_close_day'?(/\s+CLOSE$/i.test(market)?'weekday':'scrape'):mode;
  return effective==='scrape'?'AUTO':effective==='weekday'?'WEEKDAY':effective==='combo'?'COMBO':effective==='day_combo'?'DAY_COMBO':undefined;
}
export function rangeHistorySeed(job:RangeJob):UserProfile['dayRecords'] {
  return Object.fromEntries(Object.entries(job.recentWarmup?.data||{}).filter(([date])=>job.selection==='history_apply'||date<job.from).map(([date,data])=>[date,{data}]));
}
/** The same selection helpers as the ledger bulk buttons; only prior dates are history. */
export function applyRangeSelection(record:DayMarketRecord, task:RangeTask, selection:RangeSelection, profile:UserProfile, initialTrick:0|1|2=0,combined?:Omit<CombinedCutInputs,'indices'>,recent2IndicesOnly=true,_historySeed:UserProfile['dayRecords']={},carrySources?:Partial<Record<CardSourceMode,string>>,sourceAnalysis?:SourceHistoryAnalysis,recentDatedDraws?:Array<{date:string;jodi:string}>):DayMarketRecord {
  if(task.type!=='ank'||record.s==='SKIP'||selection==='keep')return record;
  if(selection==='self_learn_90d'){
    return applySelfLearning90DayBacktestSelection(record, task, profile, recentDatedDraws);
  }
  if(selection==='carry_result6'){
    const history=carryResultSixHistory(profile,task.date,task.index,task.market,record,6);
    if(history.length!==6)throw new Error(`Carry Result 6: ${history.length}/6 unique earlier confirmed actuals in recovery track; no invented digits`);
    return applyCarryResultSix(record,history,true);
  }
  if(selection==='carry6'){
    const source=getScrapeSource(record);
    const digits=selectCarry6(carrySources || {}, source?.digits || '');
    const next={...record,d:digits,sourceMode:'CARRY6' as const,scrapeSource:normalizeScrapeSource({mode:'CARRY6',digits:source!.digits})};
    delete next.marketModel;delete next.od;delete next.trick;delete next.positionRule;
    return next;
  }
  if(selection==='history_apply'){
    const source=getScrapeSource(record);
    if(!source||!sourceAnalysis)throw new Error('History Apply requires fresh source-window comparison');
    const choice=checkedSourceHistory({status:'success',sourceHistory:sourceAnalysis},task.date,task.market,source.mode,source.digits);
    if(!choice.mode)throw new Error(choice.reason||'Source-window weighted winner unavailable');
    const indices=choice.indices.slice(0,choice.mode==='keep6'?6:4);
    const next=choice.mode==='keep6'?keepRecentSixIndices(record,indices):removeRecentFourIndices(record,indices,true);
    if(!next)throw new Error('History Apply requires an editable original ten-digit source');
    return next;
  }
  if(selection==='auto_day_recent2_keep')return applyBacktestCombinedKeep(record,{auto:combined?.auto||[],day:combined?.day||[],indices:recentSourceIndices(profile.dayRecords,task.date,task.index,task.market,2,true)});
  if(selection==='auto_day_recent2')return applyBacktestCombinedCut(record,{auto:combined?.auto||[],day:combined?.day||[],indices:recentSourceIndices(profile.dayRecords,task.date,task.index,task.market,2,true)});
  // O/D begins with the existing Fcut seed; the walk-forward resolver owns later cut decisions.
  if(selection==='first4'||selection==='result_parity'){
    const next=removeFirstFourSourceIndices(record,true);
    if(!next)throw new Error('INDEX 1–4 REMOVE requires an editable ten-digit source');
    return next;
  }
  if(selection==='recent6_keep'){
    const indices=recentSixUniqueIndices(profile.dayRecords,task.date,task.index,task.market);
    if(indices.length!==6)throw new Error(`Recent 6 unique prior result-index history incomplete: ${indices.length}/6 distinct PASS/FAIL positions; older history required`);
    const next=keepRecentSixIndices(record,indices);
    if(!next)throw new Error('Keep recent 6 requires an eligible original ten-digit source');
    return next;
  }
  if(selection==='recent4'){
    const indices=recentUniqueSourceIndices(profile.dayRecords,task.date,task.index,task.market,4);
    if(indices.length!==4)throw new Error(`Recent 4 unique prior result-index history incomplete: ${indices.length}/4 distinct PASS/FAIL positions; duplicates skipped, older history required`);
    const next=removeRecentFourIndices(record,indices,true);
    if(!next)throw new Error('Recent 4 unique rule requires an eligible original ten-digit source');
    return next;
  }
  if(selection==='recent2'){
    const count=2;
    const indices=recentSourceIndices(profile.dayRecords,task.date,task.index,task.market,count,count===2);
    if(indices.length!==count)throw new Error(`Recent ${count} prior result-index history incomplete: ${indices.length}/${count} valid PASS/FAIL indices in the prior 14 days; prepare history or retry when exact prior results are available`);
    const next=recent2IndicesOnly?removeRecentTwoIndices(record,indices,true):removeRecentTwoAndScrapeDigits(record,indices,true);
    if(!next)throw new Error(`Recent ${count} rule requires its prior result-index history and an eligible original source`);
    return next;
  }
  const yesterday=selection==='yday'||selection==='yday_trim';
  const num=yesterday?(getYesterdayAutoTrick(findLatestSettledMarketRecord(profile.dayRecords,task.date,'data',task.index,task.market)?.record)||initialTrick):selection.startsWith('t1')?1:selection.startsWith('t2')?2:3;
  if(!num)throw new Error('YDAY Auto requires a prior settled T1/T2 card; select T1 or T2 to begin');
  const source=record.od||record.d,result=applyTrickFormula(source,num);
  if(!result)throw new Error(`T${num} cannot apply to this scraper source`);
  const next={...record,od:source,d:result.formatted,trick:result.trick};delete next.positionRule;
  if(selection.endsWith('_trim') && result.formatted.split(', ').length!==5){
    const trimmed=trimAppliedTrickDigit(next);
    if(!trimmed)throw new Error('6→5 requires six selected digits with T1 or T2');
    next.d=trimmed;
  }
  return next;
}
export type RangeOptions = { profileId: string; from: string; to: string; mode: RangeMode; selection: RangeSelection; games: GameType[]; markets?:string[]; weekdays?: number[]; fresh?: boolean; initialTrick?: 0|1|2; recentHistorySeed?:boolean; resetAfterThreeFails?: boolean; backtestMaxStake?: number; dailyProfitTarget?: number; dailyStopLoss?: number; autoResultParity?: boolean };
export type RangeTaskStatus = 'pending'|'done'|'missing'|'failed'|'protected'|'disabled'|'live'|'policy_skip'|'weekday_skip';
export function rangeProgress(tasks:Array<{status:RangeTaskStatus}>,staged=0){
  const excluded=new Set<RangeTaskStatus>(['weekday_skip','live','disabled','protected']);
  const eligible=tasks.filter(t=>!excluded.has(t.status)).length;
  const finalized=tasks.filter(t=>!excluded.has(t.status)&&t.status!=='pending').length;
  return {eligible,excluded:tasks.length-eligible,finalized,checked:Math.min(eligible,finalized+Math.max(0,staged))};
}
export type RangeTask = { date: string; type: GameType; index: number; market: string; status: RangeTaskStatus; reason?: string; selectionApplied?: boolean };
export const RECENT2_POLICY='indices2-repeat-mirror-v1';
export type RangeJob = RangeOptions & { historyChoiceCutoff?:string; historyChoicePolicy?:string; recent2IndicesOnly?: boolean; recent2Policy?:string; recentWarmup?: {seedRule?:'scraped';tasks:RangeTask[];data:Record<string,Record<string,DayMarketRecord>>}; id: string; state: 'running'|'paused'|'completed'|'stopped'|'cleared'; config: ProfileConfig; tasks: RangeTask[]; createdAt: number; updatedAt: number; current?: string; error?: string; restartCount?:number; lastRecoveredAt?:number; baselineRecoveryPolicies?: Record<string,BacktestRecoveryPolicy|null>; baseline?: Record<string,DayMarketRecord|null>; committed?: Record<string,number>; committedSources?: Record<string,string> };
export type RangeResult = { sourceHistory?:SourceHistoryAnalysis; recentDatedDraws?:Array<{date:string;jodi:string}>; status: string; httpStatus?: number; message?: string; digits?: string; smartDigits?: string; modelDigits?: string; open?: string; combined?: string; actual?: DatedActual|null; targetDate?: string; staleCache?: boolean; sourceDigits?: Partial<Record<CardSourceMode,string>>; marketModel?: any };
export function recentHistoryProfile(profile:UserProfile,job:RangeJob):UserProfile {
  if(job.selection==='history_apply')return profile; // Source-specific seed stays separate so saved records cannot mix modes.
  const days={...profile.dayRecords};
  for(const [date,data] of Object.entries(job.recentWarmup?.data || {})) {
    if(date>=job.from)continue;
    days[date]={...days[date],data:{...data,...days[date]?.data}};
  }
  for(const [date,day] of Object.entries(days)){
    if(!day.data)continue;
    days[date]={...day,data:Object.fromEntries(Object.entries(day.data).map(([i,rec])=>[i,skippedHistoryRecord(rec)]))};
  }
  return {...profile,dayRecords:days};
}
export function recentWarmupSummary(job:RangeJob) {
  if(job.selection==='history_apply'&&job.historyChoicePolicy===SOURCE_HISTORY_POLICY)return undefined;
  if(!['recent2','recent4','recent6_keep','history_apply','auto_day_recent2','auto_day_recent2_keep'].includes(job.selection))return undefined;
  const tasks=job.recentWarmup?.tasks || [];
  return {enabled:job.recentHistorySeed!==false,seedRule:job.recentWarmup?(job.recentWarmup.seedRule||'first4'):'scraped',total:tasks.length,checked:tasks.filter(t=>t.status!=='pending').length,done:tasks.filter(t=>t.status==='done').length,missing:tasks.filter(t=>t.status==='missing'||t.status==='failed').length,pending:tasks.filter(t=>t.status==='pending').length,issues:tasks.filter(t=>t.status==='missing'||t.status==='failed').slice(0,20)};
}
export const rangeDict = (type:GameType) => type==='ank'?'data':type==='jodi'?'jodiData':'pannelData';
const visibility = (type:GameType) => type==='ank'?'visAnk':type==='jodi'?'visJodi':'visPan';
export const rangeVersion = (rec?:DayMarketRecord) => Math.max(modelSourceVersion(rec), Number(rec?.manualOverrideAt||0), Number(rec?.bulkBacktestVersion||0));
export const rangeProtected = (rec?:DayMarketRecord) => Boolean(rec && (rec.sentRate || rec.sentDigits || rec.dispatchState || rec.deliveryRestoredAt || (rec.manualStatus && rec.s!=='WAIT') || ((rec.s==='PASS'||rec.s==='FAIL')&&!rec.backtestResult) || (rec.s==='SKIP'&&rec.manualStatus)));
export function rangeDates(from:string,to:string,today=businessDateIST()):string[] {
  const valid=(s:string)=>/^\d{4}-\d{2}-\d{2}$/.test(s)&&Number.isFinite(Date.parse(s))&&new Date(s).toISOString().slice(0,10)===s;
  if(!valid(from)||!valid(to)||from>to)throw new Error('Valid From/To dates required; From must be before To');
  if(to>today)throw new Error('Future dates are unavailable; choose today or an earlier date');
  const days=Math.round((Date.parse(to)-Date.parse(from))/86400000)+1;
  if(days>366)throw new Error('Choose at most 366 dates per run');
  return Array.from({length:days},(_,i)=>new Date(Date.parse(from)+i*86400000).toISOString().slice(0,10));
}
export const RANGE_WEEKDAYS = [[1,'Monday'],[2,'Tuesday'],[3,'Wednesday'],[4,'Thursday'],[5,'Friday'],[6,'Saturday'],[0,'Sunday']] as const;
export const rangeWeekdaySelected = (date:string, options:RangeOptions) => (options.weekdays || [0,1,2,3,4,5,6]).includes(new Date(`${date}T00:00:00Z`).getUTCDay());
export function validateRangeOptions(raw:any):RangeOptions {
  if(!raw||!raw.profileId||!RANGE_MODES.includes(raw.mode)||!RANGE_SELECTIONS.some(([value])=>value===raw.selection))throw new Error('Profile, scraping mode and digit selection are required');
  if(raw.selection==='history_apply'&&!rangeHistorySource(raw.mode,'OPEN'))throw new Error('History Apply supports Auto, Day, O/C, Combo and Day Mix');
  if(!Array.isArray(raw.games)||!raw.games.length||raw.games.some((g:any)=>!['ank','jodi','pannel'].includes(g)))throw new Error('Choose at least one game');
  rangeDates(raw.from,raw.to);
  if(raw.autoResultParity!==undefined&&typeof raw.autoResultParity!=='boolean')throw new Error('F/C/L-cut must be ON or OFF');
  if(raw.dailyStopLoss!==undefined&&(typeof raw.dailyStopLoss!=='number'||!Number.isFinite(raw.dailyStopLoss)||raw.dailyStopLoss<0))throw new Error('Daily stop loss must be zero or a positive amount');
  if(raw.dailyProfitTarget!==undefined&&(typeof raw.dailyProfitTarget!=='number'||!Number.isFinite(raw.dailyProfitTarget)||raw.dailyProfitTarget<0))throw new Error('Daily profit target must be zero or a positive amount');
  if(raw.resetAfterThreeFails!==undefined && typeof raw.resetAfterThreeFails!=='boolean')throw new Error('Recovery reset must be ON or OFF');
  if(raw.backtestMaxStake!==undefined && (typeof raw.backtestMaxStake!=='number'||!Number.isFinite(raw.backtestMaxStake)||raw.backtestMaxStake<0))throw new Error('Maximum card stake must be zero or a positive amount');
  if(raw.initialTrick!==undefined&&![0,1,2].includes(raw.initialTrick))throw new Error('Starting trick must be T1, T2 or Require history');
  if(raw.recentHistorySeed!==undefined&&typeof raw.recentHistorySeed!=='boolean')throw new Error('Recent history preparation must be ON or OFF');
  if(raw.weekdays!==undefined&&(!Array.isArray(raw.weekdays)||!raw.weekdays.length||raw.weekdays.some((d:any)=>!Number.isInteger(d)||d<0||d>6)))throw new Error('Choose at least one valid weekday');
  if(raw.markets!==undefined&&(!Array.isArray(raw.markets)||!raw.markets.length||raw.markets.some((m:any)=>typeof m!=='string'||!m.trim())))throw new Error('Choose at least one valid market');
  return {...(raw.markets!==undefined?{markets:[...new Set<string>(raw.markets.map((m:string)=>m.trim().toUpperCase()))]}:{}),autoResultParity:raw.selection==='result_parity'||raw.autoResultParity===true,dailyStopLoss:raw.dailyStopLoss||0,dailyProfitTarget:raw.dailyProfitTarget||0,profileId:String(raw.profileId),from:raw.from,to:raw.to,mode:raw.mode,selection:raw.selection,games:[...new Set<GameType>(raw.games)],weekdays:[...new Set<number>(raw.weekdays||[0,1,2,3,4,5,6])].sort(),fresh:raw.fresh===true,initialTrick:raw.initialTrick||0,recentHistorySeed:raw.recentHistorySeed!==false,resetAfterThreeFails:raw.resetAfterThreeFails===true,backtestMaxStake:raw.resetAfterThreeFails===true?raw.backtestMaxStake||0:0};
}
export const rangeMarketBase=backtestMarketBase;
export function rangeMarketChoices(config:ProfileConfig):string[]{
  return [...new Set([...getEffectiveMarkets(config),...getEffectiveBaseMarkets(config)].map(m=>rangeMarketBase(m.n)))];
}
export function planRange(profile:UserProfile,options:RangeOptions,today=businessDateIST()):RangeTask[] {
  if(options.selection==='history_apply'&&!rangeHistorySource(options.mode,'OPEN'))throw new Error('History Apply supports Auto, Day, O/C, Combo and Day Mix');
  if(options.markets?.some(name=>!rangeMarketChoices(profile.config).includes(name)))throw new Error('Selected market no longer exists in this profile; choose markets again');
  if(options.markets&&!options.markets.length)throw new Error('Choose at least one market');
  const games=(['ank',...options.games] as GameType[]).filter((g,i,a)=>a.indexOf(g)===i);
  return rangeDates(options.from,options.to,today).flatMap(date=>games.flatMap(type=>{
    const markets=type==='jodi'?getEffectiveBaseMarkets(profile.config):getEffectiveMarkets(profile.config),day=profile.dayRecords[date];
    return markets.flatMap((m,index)=>{
      if(!backtestMarketSelected(m.n,options.markets))return [];
      if(options.selection==='history_apply'&&type==='ank'&&!supportsMarketHistorySource(m.n,rangeHistorySource(options.mode,m.n)!))throw new Error(`History Apply has no supported source mapping for ${m.n}; select supported markets`);
      const rec=day?.[rangeDict(type)]?.[index];
      const marketWeekdayOpen = isMarketOpenOnDate(m.n, date);
      const status:RangeTaskStatus=!rangeWeekdaySelected(date,options)?'weekday_skip':!marketWeekdayOpen?'weekday_skip':date>=today?'live':!isMarketEnabledForDate(profile.config,day?.[visibility(type)],m.n,date)?'disabled':rangeProtected(rec)?'protected':'pending';
      return [{date,type,index,market:m.n,status,...(status==='weekday_skip'?{reason:!marketWeekdayOpen?`Market closed on this weekday (${sourceIndexWeekLength(m.n)}-Day schedule)`:'Weekday not selected'}:status==='live'?{reason:'Current business date is protected'}:status==='protected'?{reason:'Manual/queued/sent card kept'}:{})}];
    });
  }));
}
export function rangeScrapeBody(task:RangeTask,options:RangeOptions,config:ProfileConfig,ankDigits?:string):Record<string,unknown> {
  const mode=options.mode==='open_auto_close_day'?(/\s+CLOSE$/i.test(task.market)?'weekday':'scrape'):options.mode;
  return {market:task.market,type:task.type,targetDate:task.date,backtest:true,scrapeUrl:resolveMarketScrapeUrl(config,task.market),ankDigits,
    isCombo:task.type==='ank'&&(mode==='combo'||mode==='day_combo'||mode==='freq_10_combo'),smartMode:task.type==='ank'&&mode==='smart',
    ...(task.type==='ank'?{selectionMode:options.selection==='carry6'&&rangeHistorySource(options.mode,task.market)?'carry6':mode==='weekday'?'same_weekday_vertical':mode==='day_combo'?'same_weekday_vertical_combo':mode==='market_model'?'pair_follow':mode==='pair_combo'?'pair_combo':mode==='freq_10'?'freq_10_skip_recent':mode==='freq_10_combo'?'freq_10_combo_skip_recent':mode==='dynamic_4ank'?'dynamic_4ank':mode==='scrape'||mode==='combo'?'pre_target_recent':undefined}:{})};
}
function selectionRecord(original:DayMarketRecord|undefined,task:RangeTask,json:RangeResult,job:RangeJob):DayMarketRecord {
  const mode=job.mode==='open_auto_close_day'?(/\s+CLOSE$/i.test(task.market)?'weekday':'scrape'):job.mode;
  const sourceMode:CardSourceMode=task.type==='pannel'?'AUTO':mode==='scrape'?'AUTO':mode==='weekday'?'WEEKDAY':mode==='market_model'?'PAIR_FOLLOW':mode==='pair_combo'?'PAIR_COMBO':mode==='freq_10'?'FREQ_10':mode==='freq_10_combo'?'FREQ_10_COMBO':mode==='dynamic_4ank'?'FLOW_3_1':mode.toUpperCase() as CardSourceMode;
  const digits=String(task.type==='ank'&&job.selection==='carry6'?json.sourceDigits?.[sourceMode]||'':task.type==='ank'&&mode==='smart'?json.smartDigits||'':task.type==='ank'&&mode==='market_model'?json.digits||json.modelDigits||'':json.digits||json.open||'');
  let rec:DayMarketRecord={s:'WAIT',d:digits,r:original?.manualRate?original.r:'',manualRate:original?.manualRate,manualOverrideAt:original?.manualRate?original.manualOverrideAt:undefined,
    schTime:original?.schTime,schTargets:original?.schTargets,cardGeneration:original?.cardGeneration,marketName:task.market,sourceMode,sourceEditedAt:Math.max(Date.now(),rangeVersion(original)+1),bulkBacktestJobId:job.id,bulkBacktestVersion:Math.max(Date.now(),rangeVersion(original)+1)};
  if(job.selection==='history_apply'&&task.type==='ank'){
    const explicit=normalizeScrapeSource({mode:sourceMode,digits:json.sourceDigits?.[sourceMode]}),tokens=explicit?.digits.split(/[,|\s]+/).filter(Boolean)||[];
    if(json.targetDate!==task.date||tokens.length!==10||new Set(tokens).size!==10)throw new Error('History Apply requires explicit dated ten-digit source provenance');
  }
  rec.scrapeSource=normalizeScrapeSource({mode:sourceMode,digits:json.sourceDigits?.[sourceMode]||digits});
  if(task.type==='ank'&&mode==='market_model'&&json.marketModel&&job.selection!=='carry6')applyMarketModelSummary(rec,summarizeMarketModel(json.marketModel),json.sourceDigits?.MARKET_MODEL);
  if(rec.s!=='SKIP'&&!areSettlementTokensValid(task.type,rec.d))throw new Error('No valid historical selection returned');
  return rec;
}
export function replayRangeDate(profile:UserProfile,date:string,games:GameType[],runId?:string,policy?:BacktestRecoveryPolicy,protectedKeys?:Set<string>,allowedKeys?:Set<string>):UserProfile {
  const pinned=pinDayLoops(profile,date),day=pinned.dayRecords[date]||{};
  const chosen=(type:GameType)=>games.includes(type)?Object.fromEntries(Object.entries(day[rangeDict(type)]||{}).filter(([i])=>!allowedKeys||allowedKeys.has(`${type}_${i}`)).filter(([i,rec])=>protectedKeys?.has(`${type}_${i}`)||!runId||rec.bulkBacktestJobId===runId||rangeProtected(rec)).map(([i,rec])=>[i,protectedKeys?.has(`${type}_${i}`)?{...rec,dispatchState:rec.dispatchState||'SETTLED'}:rec])):undefined;
  const isolated={...day,...(policy?{backtestRecoveryPolicy:policy}:{}),data:chosen('ank'),jodiData:chosen('jodi'),pannelData:chosen('pannel')};
  const replay=calculateBacktestRecovery({...pinned,dayRecords:{...pinned.dayRecords,[date]:isolated}},date).dayRecords[date];
  for(const key of protectedKeys||[]){const [type,index]=key.split('_');const name=rangeDict(type as GameType);if(replay[name]&&day[name]?.[index])replay[name]![index]=day[name]![index];}
  return {...pinned,dayRecords:{...pinned.dayRecords,[date]:{...day,recoveryConfigSnapshot:replay.recoveryConfigSnapshot,...(replay.loopAccountStops?{loopAccountStops:replay.loopAccountStops}:{}),...(policy?{backtestRecoveryPolicy:policy}:{}),...Object.fromEntries(games.map(type=>[rangeDict(type),{...day[rangeDict(type)],...replay[rangeDict(type)]}]))}}};
}
/** Retain durable bulk archive commits when an older browser saves its full state. */
export function preserveRangeArchive(incoming:AppState,stored:AppState|null):AppState {
  if(!stored)return incoming;
  const profiles={...incoming.profiles};
  for(const [pid,p] of Object.entries(profiles)){
    const old=stored.profiles[pid];if(!old)continue;
    // Year-scale optimization: an Admin patch reuses untouched historical day
    // objects from the stored snapshot. There is nothing to reconcile if the
    // entire day map is identical. Do not scan all past cards on an unrelated
    // VIP preference, current date, login or payout setting change.
    // This is an identity check, NOT a time-based eviction or archive deletion.
    if(p.dayRecords===old.dayRecords)continue;
    let incomingMarkets:ReturnType<typeof getEffectiveMarkets>|undefined,savedMarkets:ReturnType<typeof getEffectiveMarkets>|undefined;
    const days={...p.dayRecords};let changed=false;
    const replayDates=new Set<string>();
    for(const [date,day] of Object.entries(old.dayRecords)){
      if(date>=businessDateIST())continue;
      let next=days[date];
      // Both sides point to the exact same historical record. Its revisions,
      // settlements and provenance are already identical; doing the old per-card
      // reconciliation would only waste work on years of archived dates.
      if(next===day)continue;
      if(day.recoveryConfigSnapshot&&!next){days[date]=structuredClone(day);changed=true;continue;}
      if(Number(day.backtestRevision||0)>Number(next?.backtestRevision||0)){
        const merged=reconcileArchiveDayRevision(next,day,p.config,old.config,date);
        if(JSON.stringify(merged.data)!==JSON.stringify(day.data))replayDates.add(date);
        days[date]=merged;changed=true;continue;
      }
      for(const type of ['ank','jodi','pannel'] as GameType[]){
        const name=rangeDict(type);let dict=next?.[name];
        for(const [i,rec] of Object.entries(day[name]||{})){
          const local=dict?.[i];
          if(type==='ank'&&local&&modelSourceVersion(local)!==modelSourceVersion(rec)){
            const index=Number(i),localMarkets=incomingMarkets??=getEffectiveMarkets(p.config),storedMarkets=savedMarkets??=getEffectiveMarkets(old.config);
            const forward=Number.isInteger(index)&&index>=0?newerReplacementArchiveSource(local,rec,localMarkets[index]?.n,storedMarkets[index]?.n):undefined;
            if(forward){dict={...dict,[i]:forward};changed=true;replayDates.add(date);continue;}
            const retained=Number.isInteger(index)&&index>=0?newerReplacementArchiveSource(rec,local,storedMarkets[index]?.n,localMarkets[index]?.n):undefined;
            if(retained){dict={...dict,[i]:structuredClone(rec)};changed=true;replayDates.add(date);continue;}
          }
          if(!rec.bulkBacktestJobId&&Number(next?.backtestRevision||0)<=Number(day.backtestRevision||0)){
            const index=Number(i),localMarkets=type==='jodi'?getEffectiveBaseMarkets(p.config):(incomingMarkets??=getEffectiveMarkets(p.config)),storedMarkets=type==='jodi'?getEffectiveBaseMarkets(old.config):(savedMarkets??=getEffectiveMarkets(old.config));
            const retained=Number.isInteger(index)&&index>=0?retainedCheckedArchiveCard(local,rec,localMarkets[index]?.n,storedMarkets[index]?.n):undefined;
            if(retained){dict={...dict,[i]:retained};changed=true;continue;}
          }
          if(type==='ank'&&local&&((!String(rec.d||'').trim()&&String(local.d||'').trim()&&modelSourceVersion(local)>modelSourceVersion(rec))||Number(local.backtestResult?.updatedAt||0)>Number(rec.backtestResult?.updatedAt||0))){
            const index=Number(i),localMarkets=incomingMarkets??=getEffectiveMarkets(p.config),storedMarkets=savedMarkets??=getEffectiveMarkets(old.config);
            const update=Number.isInteger(index)&&index>=0?(newerSourceOverEmptyArchive(local,rec,localMarkets[index]?.n,storedMarkets[index]?.n)||newerResultForSameArchiveSource(local,rec,localMarkets[index]?.n,storedMarkets[index]?.n)):undefined;
            if(update){dict={...dict,[i]:update};changed=true;replayDates.add(date);continue;}
          }
          if(type==='ank'&&local&&!String(local.d||'').trim()&&String(rec.d||'').trim()&&modelSourceVersion(rec)>modelSourceVersion(local)){
            const index=Number(i);
            const localMarkets=incomingMarkets??=getEffectiveMarkets(p.config),storedMarkets=savedMarkets??=getEffectiveMarkets(old.config);
            const restored=Number.isInteger(index)&&index>=0?newerSourceOverEmptyArchive(rec,local,storedMarkets[index]?.n,localMarkets[index]?.n):undefined;
            if(restored){dict={...dict,[i]:restored};changed=true;replayDates.add(date);continue;}
          }
          if(!rec.bulkBacktestJobId)continue;
          if(local&&(modelSourceVersion(local)>modelSourceVersion(rec)||Number(local.manualOverrideAt||0)>Number(rec.manualOverrideAt||0)||rangeVersion(local)>rangeVersion(rec)))continue;
          // A new browser result check may update an existing range card without
          // changing its source. Keep newer result/recovery fields only for the
          // exact same job/source generation; stale dumps cannot undo Clear,
          // Restore, a newer range run or a manual settlement.
          if(local && !rangeProtected(rec) && local.bulkBacktestJobId===rec.bulkBacktestJobId &&
            rangeVersion(local)===rangeVersion(rec) && modelSourceVersion(local)===modelSourceVersion(rec) &&
            Number(local.cardGeneration||0)===Number(rec.cardGeneration||0) &&
            local.backtestResult?.checked && local.backtestResult.digits===local.d &&
            Number(local.backtestResult.updatedAt||0)>Number(rec.backtestResult?.updatedAt||0) &&
            (local.backtestResult.actual!==undefined || local.backtestResult.openActual!==undefined) &&
            ['marketName','sourceMode','scrapeSource','od','trick','positionRule'].every(key=>JSON.stringify((local as any)[key])===JSON.stringify((rec as any)[key])))continue;
          if(local&&JSON.stringify(local)===JSON.stringify(rec))continue;
          dict={...dict,[i]:structuredClone(rec)};changed=true;
        }
        if(dict)next={...next,[name]:dict};
      }
      if(next && day.backtestRecoveryPolicy && Number(day.backtestRecoveryPolicy.updatedAt||0)>Number(next.backtestRecoveryPolicy?.updatedAt||0)){next={...next,backtestRecoveryPolicy:structuredClone(day.backtestRecoveryPolicy)};changed=true;}
      if(day.recoveryConfigSnapshot&&next&&!next.recoveryConfigSnapshot){next={...next,recoveryConfigSnapshot:structuredClone(day.recoveryConfigSnapshot)};changed=true;}
      if(next){if(!next.loopConfig&&day.loopConfig)next.loopConfig=structuredClone(day.loopConfig);days[date]=next;}
    }
    if(changed){
      let updated={...p,dayRecords:days};
      // Use the existing calculator and authoritative pinned settings; never
      // copy stale incoming automatic rates along with an accepted source/check.
      for(const date of replayDates)updated=calculateBacktestRecovery(updated,date);
      profiles[pid]=updated;
    }
  }
  return {...incoming,profiles};
}
export function rangeReport(job:RangeJob,profile:UserProfile|undefined){
  return rangeDates(job.from,job.to).map(date=>{
    const tasks=job.tasks.filter(t=>t.date===date),day=profile?.dayRecords[date];
    return {date,counts:Object.fromEntries(['done','missing','failed','protected','disabled','live','weekday_skip','policy_skip','pending'].map(s=>[s,tasks.filter(t=>t.status===s).length])),
      games:Object.fromEntries(job.games.map(type=>{
        const name=rangeDict(type),dict=Object.fromEntries(tasks.filter(t=>t.type===type&&!['disabled','live','weekday_skip'].includes(t.status)).flatMap(t=>{
          const rec=day?.[name]?.[t.index];
          // Preserve protected settlements explicitly; automatic totals belong to this run only.
          return rec&&(t.status==='protected'||(t.selectionApplied&&rec.bulkBacktestJobId===job.id))?[[t.index,rec]]:[];
        }));
        const scoped=profile?{...profile,dayRecords:{...profile.dayRecords,[date]:{...day,[name]:dict}}}:undefined;
        const enabled=rangeWeekdaySelected(date,job)&&date<businessDateIST();
        const stats=scoped&&enabled?calculateProtocolStats(type,scoped,date):{spent:0,win:0,pl:0,maxLoss:0};
        const wallet=enabled?calculateCapitalWallet(type,dict,true):{invested:0,balance:0,pending:0,turnover:0};
        return [type,{...stats,...wallet}];
      }))};
  });
}
export type RangeDeps={read:()=>AppState|null;write:(state:AppState)=>void;persist:(job:RangeJob)=>void;scrape:(body:Record<string,unknown>)=>Promise<RangeResult>;resetSources:()=>void;scrapeTimeoutMs?:number;resumeInterrupted?:boolean;persistHistory?:(history:any[])=>void};
export class RangeBacktestRunner {
  job:RangeJob|null=null;history:any[]=[];private busy=false;private currentStartedAt=0;private staging={date:'',checked:0,total:0,issues:[] as Array<{date:string;market:string;status:string;reason:string}>};
  constructor(private deps:RangeDeps,loaded?:RangeJob,history:any[]=[]){
    this.history=history;if(!loaded)return;this.job=loaded;
    if(loaded.state==='running'){
      if(deps.resumeInterrupted){
        loaded.restartCount=(loaded.restartCount||0)+1;loaded.lastRecoveredAt=Date.now();loaded.error=undefined;
        loaded.current=undefined;loaded.updatedAt=Date.now();deps.persist(loaded);
        // Resume only a persisted RUNNING job. Explicit Pause/Stop are never overridden.
        setTimeout(()=>{if(this.job===loaded&&loaded.state==='running'){deps.resetSources();void this.pump();}},0);
      }else{loaded.state='paused';loaded.error='Server restarted. Resume saved progress.';deps.persist(loaded);}
    }
  }
  start(options:RangeOptions){
    if(this.job?.state==='running'||this.busy)throw new Error('A range run is already active; pause it before starting another');
    const p=this.deps.read()?.profiles[options.profileId];if(!p)throw new Error('Profile not found');
    this.archiveCurrent();
    const at=Date.now(),tasks=planRange(p,options),baseline:Record<string,DayMarketRecord|null>={};
    const nextJob:RangeJob={...options,...(options.selection==='history_apply'?{historyChoicePolicy:SOURCE_HISTORY_POLICY}:{}),...(options.selection==='recent2'?{recent2IndicesOnly:true,recent2Policy:RECENT2_POLICY}:{}),id:`range_${at}_${Math.random().toString(36).slice(2,8)}`,config:structuredClone(p.config),tasks,state:'running',createdAt:at,updatedAt:at,baseline,baselineRecoveryPolicies:Object.fromEntries([...new Set(tasks.filter(t=>t.status==='pending').map(t=>t.date))].map(date=>[date,p.dayRecords[date]?.backtestRecoveryPolicy?structuredClone(p.dayRecords[date].backtestRecoveryPolicy!):null])),committed:{},committedSources:{}};
    let prepared=structuredClone(p),reset=false;
    for(const t of tasks){
      if(t.status!=='pending')continue;
      const name=rangeDict(t.type),rec=p.dayRecords[t.date]?.[name]?.[t.index],key=`${t.date}:${t.type}:${t.index}`;
      const freshReset=options.fresh&&Boolean(rec);
      const explicitBaseline=rec&&(rec.manualRate||rec.manualStatus||rec.sourceMode==='MANUAL'||(rec.bulkBacktestJobId&&rangeVersion(rec)>Number(rec.bulkBacktestVersion||0)));
      baseline[key]=freshReset&&!explicitBaseline?null:rec?structuredClone(rec):null;
      if(freshReset&&rec){
        const day=prepared.dayRecords[t.date],version=Math.max(at,rangeVersion(rec)+1);
        const cleared:DayMarketRecord={s:'WAIT',d:'',r:rec.manualRate?rec.r:'',manualRate:rec.manualRate,manualOverrideAt:rec.manualRate?rec.manualOverrideAt:undefined,
          marketName:t.market,cardGeneration:rec.cardGeneration,schTime:rec.schTime,schTargets:rec.schTargets,sourceEditedAt:version,bulkBacktestJobId:nextJob.id,bulkBacktestVersion:version};
        day[name]={...day[name],[t.index]:cleared};day.backtestRevision=Math.max(version,Number(day.backtestRevision||0)+1);
        nextJob.committed![key]=version;nextJob.committedSources![key]=scrapeRecordVersion(cleared);reset=true;
      }
    }
    this.job=nextJob;this.deps.persist(nextJob);
    if(reset)this.deps.write({...this.deps.read()!,profiles:{...this.deps.read()!.profiles,[options.profileId]:prepared}});
    this.deps.resetSources();this.deps.persist(this.job);void this.pump();return this.job;
  }
  pause(){if(this.job?.state==='running'){this.job.state='paused';this.job.updatedAt=Date.now();this.deps.persist(this.job);}return this.job;}
  stop(){if(this.job&&this.job.state!=='cleared'){this.job.state='stopped';this.job.error=undefined;this.job.updatedAt=Date.now();this.deps.persist(this.job);if(!this.busy)this.archiveCurrent();}return this.job;}
  clear(){
    if(!this.job)throw new Error('No range run');if(this.busy||this.job.state==='running')throw new Error('Stop the run and wait for the current request to finish before clearing');
    const job=this.job,state=this.deps.read(),profile=state?.profiles[job.profileId];if(!state||!profile)throw new Error('Profile not found');
    this.archiveCurrent();let next=structuredClone(profile);let cleared=0,kept=0;
    const committed=job.committed??Object.fromEntries(job.tasks.flatMap(t=>{const rec=profile.dayRecords[t.date]?.[rangeDict(t.type)]?.[t.index];return rec?.bulkBacktestJobId===job.id?[[`${t.date}:${t.type}:${t.index}`,Number(rec.bulkBacktestVersion||0)]]:[];}));
    for(const [key,version] of Object.entries(committed)){
      const [date,type,index]=key.split(':'),name=rangeDict(type as GameType),rec=next.dayRecords[date]?.[name]?.[index];
      if(date>=businessDateIST()||!rec||rangeProtected(rec)||rec.bulkBacktestJobId!==job.id||rangeVersion(rec)>version||(job.committedSources?.[key]&&scrapeRecordVersion(rec)!==job.committedSources[key])||(!job.baseline&&(rec.manualRate||rec.manualOverrideAt))){kept++;continue;}
      const original=job.baseline?.[key],at=Math.max(Date.now(),rangeVersion(rec)+1);
      const restored=original?structuredClone(original):null;if(restored?.autoRemovedResult&&restored.autoRemovedResult.outputVersion===modelSourceVersion(restored))restored.autoRemovedResult.outputVersion=at;
      next.dayRecords[date][name]![index]={...(restored||{s:'WAIT',d:'',r:'',marketName:rec.marketName}),sourceEditedAt:at,bulkBacktestJobId:`cleared_${job.id}`,bulkBacktestVersion:at};
      next.dayRecords[date].backtestRevision=Math.max(at,Number(next.dayRecords[date].backtestRevision||0)+1);cleared++;
    }
    for(const [date,baselinePolicy] of Object.entries(job.baselineRecoveryPolicies||{})){
      const day=next.dayRecords[date];
      if(day?.backtestRecoveryPolicy?.runId===job.id){
        if(baselinePolicy)day.backtestRecoveryPolicy=structuredClone(baselinePolicy);
        else delete day.backtestRecoveryPolicy;
      }
    }
    this.deps.write({...state,profiles:{...state.profiles,[job.profileId]:next}});job.state='cleared';job.updatedAt=Date.now();job.current=undefined;this.deps.persist(job);return {cleared,kept};
  }
  private archiveCurrent(refresh=false){
    const job=this.job;if(!job||job.state==='running')return;
    const snapshot={id:job.id,profileId:job.profileId,from:job.from,to:job.to,mode:job.mode,selection:job.selection,...(job.selection==='history_apply'?{historyChoicePolicy:job.historyChoicePolicy||'legacy-fixed',...(job.historyChoicePolicy===SOURCE_HISTORY_POLICY?{historyWindow:'source-first-ten-unique'}:{historyWindowDays:HISTORY_WINDOW_DAYS})}:{}),recent2IndicesOnly:job.recent2IndicesOnly,recent2Policy:job.recent2Policy,games:job.games,markets:job.markets,weekdays:job.weekdays,initialTrick:job.initialTrick||0,recentHistorySeed:job.recentHistorySeed!==false,warmup:recentWarmupSummary(job),autoResultParity:job.autoResultParity===true,dailyStopLoss:job.dailyStopLoss||0,dailyProfitTarget:job.dailyProfitTarget||0,resetAfterThreeFails:job.resetAfterThreeFails===true,backtestMaxStake:job.backtestMaxStake||0,state:job.state,autoRemoveResultDigit:job.config.autoRemoveResultDigit===true,autoRemoveResultMirror:job.config.autoRemoveResultDigit===true&&job.config.autoRemoveResultMirror===true,autoRemoveResultUnique3:job.config.autoRemoveResultDigit===true&&job.config.autoRemoveResultUnique3===true,updatedAt:job.updatedAt,report:rangeReport(job,this.deps.read()?.profiles[job.profileId])};
    if(this.history.some(h=>h.id===job.id)&&!refresh)return;
    this.history=[snapshot,...this.history.filter(h=>h.id!==job.id)].slice(0,30);this.deps.persistHistory?.(this.history);
  }
  resume(){if(!this.job)throw new Error('No saved range job');if(this.job.state==='stopped'||this.job.state==='cleared')throw new Error('This run is closed; preview and start a new test');if(this.busy)throw new Error('Stopping current request; retry Resume shortly');
    // An earlier recovered result changes following auto-removal, derived cards,
    // recovery rates and later-date strategy history. Rebuild the affected suffix
    // from original scraper inputs; retain excluded/protected tasks and run ID.
    const retryDates=this.job.tasks.filter(t=>t.status==='missing'||t.status==='failed').map(t=>t.date).sort();
    const retryFrom=retryDates[0];
    if(retryFrom)for(const t of this.job.tasks){
      if(t.date<retryFrom||!['done','policy_skip','missing','failed'].includes(t.status))continue;
      const rec=this.deps.read()?.profiles[this.job.profileId]?.dayRecords[t.date]?.[rangeDict(t.type)]?.[t.index];
      const key=`${t.date}:${t.type}:${t.index}`,version=this.job.committed?.[key],source=this.job.committedSources?.[key];
      const changed=version!==undefined&&(!rec||rec.bulkBacktestJobId!==this.job.id||rangeVersion(rec)>version||(source&&scrapeRecordVersion(rec)!==source));
      if(rangeProtected(rec)||changed){t.status='protected';t.reason='Source edited since checkpoint; saved card kept';continue;}
      t.status='pending';t.selectionApplied=false;t.reason=undefined;
    }
    for(const t of this.job.recentWarmup?.tasks || [])if(t.status==='missing'||t.status==='failed')t.status='pending';
    this.job.state='running';this.job.error=undefined;this.deps.resetSources();this.deps.persist(this.job);void this.pump();return this.job;}
  summary(){const job=this.job;if(!job)return null;return {id:job.id,profileId:job.profileId,state:job.state,from:job.from,to:job.to,mode:job.mode,selection:job.selection,...(job.selection==='history_apply'?{historyChoicePolicy:job.historyChoicePolicy||'legacy-fixed',...(job.historyChoicePolicy===SOURCE_HISTORY_POLICY?{historyWindow:'source-first-ten-unique'}:{historyWindowDays:HISTORY_WINDOW_DAYS})}:{}),recent2IndicesOnly:job.recent2IndicesOnly,recent2Policy:job.recent2Policy,games:job.games,markets:job.markets,weekdays:job.weekdays,fresh:job.fresh,initialTrick:job.initialTrick,recentHistorySeed:job.recentHistorySeed!==false,warmup:recentWarmupSummary(job),autoResultParity:job.autoResultParity===true,dailyStopLoss:job.dailyStopLoss||0,dailyProfitTarget:job.dailyProfitTarget||0,resetAfterThreeFails:job.resetAfterThreeFails===true,backtestMaxStake:job.backtestMaxStake||0,autoRemoveResultDigit:job.config.autoRemoveResultDigit===true,autoRemoveResultMirror:job.config.autoRemoveResultDigit===true&&job.config.autoRemoveResultMirror===true,autoRemoveResultUnique3:job.config.autoRemoveResultDigit===true&&job.config.autoRemoveResultUnique3===true,staging:this.staging,counts:Object.fromEntries(['pending','done','missing','failed','protected','disabled','live','weekday_skip','policy_skip'].map(s=>[s,job.tasks.filter(t=>t.status===s).length])),current:job.current,currentStartedAt:this.currentStartedAt,createdAt:job.createdAt,updatedAt:job.updatedAt,heartbeatAt:Date.now(),busy:this.busy,error:job.error,restartCount:job.restartCount||0,progress:rangeProgress(job.tasks,this.staging.checked)};}
  view(){const job=this.job;if(!job)return null;const {config:_,tasks,baseline:__,committed:___,committedSources:____,recentWarmup:_____,...meta}=job;
    return {...meta,...(job.selection==='history_apply'?{historyChoicePolicy:job.historyChoicePolicy||'legacy-fixed',...(job.historyChoicePolicy===SOURCE_HISTORY_POLICY?{historyWindow:'source-first-ten-unique'}:{historyWindowDays:HISTORY_WINDOW_DAYS})}:{}),recentHistorySeed:job.recentHistorySeed!==false,warmup:recentWarmupSummary(job),currentStartedAt:this.currentStartedAt,heartbeatAt:Date.now(),progress:rangeProgress(tasks,this.staging.checked),staging:this.staging,history:this.history.filter(h=>h.profileId===job.profileId),autoRemoveResultDigit:job.config.autoRemoveResultDigit===true,autoRemoveResultMirror:job.config.autoRemoveResultDigit===true&&job.config.autoRemoveResultMirror===true,autoRemoveResultUnique3:job.config.autoRemoveResultDigit===true&&job.config.autoRemoveResultUnique3===true,counts:Object.fromEntries(['pending','done','missing','failed','protected','disabled','live','weekday_skip','policy_skip'].map(s=>[s,tasks.filter(t=>t.status===s).length])),total:tasks.length,busy:this.busy,
      issues:[...this.staging.issues,...tasks.filter(t=>t.reason)].slice(0,100),report:rangeReport(job,this.deps.read()?.profiles[job.profileId])};}
  private async pump(){
    if(this.busy||!this.job)return;this.busy=true;const job=this.job;
    try{
      if(job.selection==='recent2'&&job.recent2IndicesOnly===true&&job.recent2Policy!==RECENT2_POLICY)throw new Error('Recent2 now cuts a repeated digit and its mirror; start a new trial instead of mixing legacy results');
      if(job.selection==='history_apply'&&job.historyChoicePolicy!==SOURCE_HISTORY_POLICY)throw new Error('History Apply now uses source-window weights; start a new trial instead of mixing legacy results');
      if(['recent2','recent4','recent6_keep','auto_day_recent2','auto_day_recent2_keep'].includes(job.selection)&&job.recentHistorySeed!==false)await this.prepareRecentHistory(job);
      for(const date of rangeDates(job.from,job.to)){
        if(job.state!=='running')break;
        const dateTasks=job.tasks.filter(t=>t.date===date),tasks=dateTasks.filter(t=>t.status==='pending');if(!tasks.length)continue;
        if(!rangeWeekdaySelected(date,job)){tasks.forEach(t=>{t.status='weekday_skip';t.reason='Weekday not selected';});continue;}
        if(date>=businessDateIST()){tasks.forEach(t=>{t.status='live';t.reason='Current business date is protected';});continue;}
        const base=this.deps.read()?.profiles[job.profileId];if(!base)throw new Error('Profile was removed; run stopped');
        if(JSON.stringify(base.config)!==JSON.stringify(job.config))throw new Error('Profile settings changed. Start a new preview with the current settings.');
        const dateSettings=(p:UserProfile)=>{const d=p.dayRecords[date];return JSON.stringify([d?.loopConfig,d?.backtestRevision,d?.backtestRecoveryPolicy,d?.visAnk,d?.visJodi,d?.visPan]);};
        const initialDateSettings=dateSettings(base);
        let local=structuredClone(base);
        const allowedKeys=job.markets?new Set(dateTasks.map(t=>`${t.type}_${t.index}`)):undefined;
        if(allowedKeys){const scoped={...local.dayRecords[date]};for(const g of ['ank','jodi','pannel'] as GameType[])scoped[rangeDict(g)]=Object.fromEntries(Object.entries(scoped[rangeDict(g)]||{}).filter(([i])=>allowedKeys.has(`${g}_${i}`)));local.dayRecords[date]=scoped;}
        const snapshots=new Map<string,string>(),results=new Map<RangeTask,{status:RangeTaskStatus;reason?:string;selectionApplied?:boolean}>();
        const games=[...new Set<GameType>(['ank',...job.games])];
        const protectedKeys=()=>new Set(dateTasks.filter(t=>t.status==='protected').map(t=>`${t.type}_${t.index}`));
        this.staging={date,checked:0,total:tasks.length,issues:[]};
        for(const t of tasks){
          if(job.state!=='running')break;
          this.currentStartedAt=Date.now();
          job.current=`${date} · ${t.market} · ${t.type.toUpperCase()}`;
          const name=rangeDict(t.type),original=base.dayRecords[date]?.[name]?.[t.index];
          snapshots.set(`${t.type}_${t.index}`,scrapeRecordVersion(original));
          if(rangeProtected(original)){results.set(t,{status:'protected',reason:'Card became manual/queued/sent'});continue;}
          if(!isMarketEnabledForDate(base.config,base.dayRecords[date]?.[visibility(t.type)],t.market,date)){results.set(t,{status:'disabled'});continue;}
          try{
            const lossStopped=job.games.includes(t.type)&&backtestDailyStopLossReached(local,date,t.type,job.dailyStopLoss||0,job.id,t.index);
            const dailyStopped=lossStopped||job.games.includes(t.type)&&backtestDailyTargetReached(local,date,t.type,job.dailyProfitTarget||0,job.id,t.index);
            if(dailyStopped&&t.type!=='ank'){
              const rec:DayMarketRecord={s:'SKIP',d:'',r:'',marketName:t.market,...(lossStopped?{backtestDailyStopLossSkipped:true}:{backtestDailyProfitSkipped:true}),bulkBacktestJobId:job.id};
              local={...local,dayRecords:{...local.dayRecords,[date]:{...local.dayRecords[date],[name]:{...local.dayRecords[date]?.[name],[t.index]:rec}}}};
              results.set(t,{status:'policy_skip',reason:lossStopped?`Daily stop loss ₹${job.dailyStopLoss} reached; rest of this game stopped for this date`:`Daily profit target ₹${job.dailyProfitTarget} reached; rest of this game stopped for this date`,selectionApplied:true});continue;
            }
            if(((job.dailyProfitTarget||0)>0||(job.dailyStopLoss||0)>0)&&t.type!=='ank'){
              const markets=getEffectiveMarkets(local.config),ank=local.dayRecords[date]?.data||{};
              const names=t.type==='jodi'?[`${t.market} OPEN`,`${t.market} CLOSE`]:[t.market];
              const sourceLossStopped=names.some(n=>ank[markets.findIndex(m=>m.n===n)]?.backtestDailyStopLossSkipped);
              if(sourceLossStopped||names.some(n=>ank[markets.findIndex(m=>m.n===n)]?.backtestDailyProfitSkipped)){
                const rec:DayMarketRecord={s:'SKIP',d:'',r:'',marketName:t.market,...(sourceLossStopped?{backtestDailyStopLossSkipped:true,backtestDailyStopLossSourceSkipped:true}:{backtestDailyProfitSkipped:true,backtestDailyProfitSourceSkipped:true}),bulkBacktestJobId:job.id};
                local={...local,dayRecords:{...local.dayRecords,[date]:{...local.dayRecords[date],[name]:{...local.dayRecords[date]?.[name],[t.index]:rec}}}};
                results.set(t,{status:'policy_skip',reason:sourceLossStopped?'Daily stop loss: required ANK source stopped for this date':'Daily profit exit: required ANK source stopped for this date',selectionApplied:true});continue;
              }
            }
            let rec:DayMarketRecord,json:RangeResult,resultOnlyLookup=false;
            if(['auto_day_recent2','auto_day_recent2_keep'].includes(job.selection)&&t.type!=='ank') {
              const markets=getEffectiveMarkets(local.config),ank=local.dayRecords[date]?.data || {};
              const names=t.type==='jodi'?[`${t.market} OPEN`,`${t.market} CLOSE`]:[t.market];
              const dependency=names.map(n=>ank[markets.findIndex(m=>m.n===n)]).find(r=>r?.s==='SKIP'&&(job.selection==='auto_day_recent2_keep'?r.backtestCombinedKeep:r.backtestCombinedCut));
              if(dependency) {
                const reason=`Combined ${job.selection==='auto_day_recent2_keep'?'keep':'cut'}: derived card skipped because its ANK source side is SKIP`;
                rec={s:'SKIP',d:'',r:original?.manualRate?original.r:'',manualRate:original?.manualRate,marketName:t.market,sourceMode:'COMBO',sourceEditedAt:Math.max(Date.now(),rangeVersion(original)+1),bulkBacktestJobId:job.id,bulkBacktestVersion:Math.max(Date.now(),rangeVersion(original)+1),backtestCombinedCut:{rule:'auto_day_recent2',auto:[],day:[],indices:[],fallback:[],removed:[],choices:[],reason}};
                if(job.selection==='auto_day_recent2_keep'){delete rec.backtestCombinedCut;rec.backtestCombinedKeep={rule:'auto_day_recent2_keep',auto:[],day:[],indices:[],indexDigits:[],kept:[],choices:[],reason};}
                local={...local,dayRecords:{...local.dayRecords,[date]:{...local.dayRecords[date],[name]:{...local.dayRecords[date]?.[name],[t.index]:rec}}}};
                results.set(t,{status:'policy_skip',reason,selectionApplied:true});continue;
              }
            }
            if(t.selectionApplied&&original?.bulkBacktestJobId===job.id){
              resultOnlyLookup=true;rec=structuredClone(original);json=await this.scrapeWithRetry({...rangeScrapeBody(t,job,job.config),type:'ank',resultOnly:true});
            }else if(t.type==='ank'&&job.selection==='carry_result6'){
              const seed:DayMarketRecord={s:'WAIT',d:original?.d||'',r:original?.manualRate?original.r:'',manualRate:original?.manualRate,marketName:t.market,sourceEditedAt:Math.max(Date.now(),rangeVersion(original)+1),bulkBacktestJobId:job.id,bulkBacktestVersion:Math.max(Date.now(),rangeVersion(original)+1)};
              rec=applyRangeSelection(seed,t,job.selection,local);
              resultOnlyLookup=true;json=await this.scrapeWithRetry({...rangeScrapeBody(t,job,job.config),type:'ank',selectionMode:undefined,smartMode:false,isCombo:false,resultOnly:true});
            }else if(t.type==='jodi'){
              const markets=getEffectiveMarkets(local.config),dict=local.dayRecords[date]?.data||{};
              const oi=markets.findIndex(m=>m.n===`${t.market} OPEN`),ci=markets.findIndex(m=>m.n===`${t.market} CLOSE`);
              const d=buildJodisFromAnk(dict[oi]?.d||'',dict[ci]?.d||'').join(', ');
              if(!d)throw new Error('Same-market OPEN/CLOSE historical ANK selections are required');
              rec=selectionRecord(original,t,{status:'success',digits:d},job);rec.sourceMode='COMBO';
              resultOnlyLookup=true;json=await this.scrapeWithRetry({...rangeScrapeBody(t,job,job.config),type:'ank',resultOnly:true});
            }else{
              const markets=getEffectiveMarkets(local.config),ai=markets.findIndex(m=>m.n===t.market);
              const ank=local.dayRecords[date]?.data?.[ai]?.d;
              if(t.type==='pannel'&&!ank)throw new Error('Same-market historical ANK selection is required for Panel');
              json=await this.scrapeWithRetry(rangeScrapeBody(t,job,job.config,ank));
              if(json.status!=='success'||json.staleCache)throw new Error(json.message||'Fresh historical chart unavailable');
              let carrySources:RangeResult['sourceDigits'];
              if(t.type==='ank'&&job.selection==='carry6'){
                const sources=rangeHistorySource(job.mode,t.market)?json:await this.scrapeWithRetry({...rangeScrapeBody(t,job,job.config),selectionMode:'carry6',isCombo:false,smartMode:false});
                if(sources.status!=='success'||sources.staleCache||sources.targetDate!==t.date)throw new Error(sources.message||'Fresh exact-date Carry6 sources unavailable');
                carrySources=sources.sourceDigits;
              }
              let combined:Omit<CombinedCutInputs,'indices'>|undefined;
              if(t.type==='ank'&&['auto_day_recent2','auto_day_recent2_keep'].includes(job.selection)) {
                if(job.state!=='running')break;
                const [auto,day]=await Promise.all([
                  this.scrapeWithRetry(rangeScrapeBody(t,{...job,mode:'scrape'},job.config)),
                  this.scrapeWithRetry(rangeScrapeBody(t,{...job,mode:'weekday'},job.config)),
                ]);
                for(const source of [auto,day]) {
                  if(source.status!=='success'||source.staleCache)throw new Error(source.message||'Fresh AUTO/DAY source unavailable');
                  if((source.targetDate&&source.targetDate!==t.date)||(source.actual?.date&&source.actual.date!==t.date))throw new Error('AUTO/DAY source returned a different date');
                }
                const digits=(value:string|undefined)=>String(value||'').split(/[,|\s]+/).filter(Boolean).slice(0,2);
                combined={auto:digits(auto.sourceDigits?.AUTO||auto.digits),day:digits(day.sourceDigits?.WEEKDAY||day.digits)};
              }
              const selected=selectionRecord(original,t,json,job);
              let sourceAnalysis:SourceHistoryAnalysis|undefined;
              if(t.type==='ank'&&job.selection==='history_apply'){
                const source=getScrapeSource(selected)!;
                const reply=await this.scrapeWithRetry({...rangeScrapeBody(t,job,job.config),selectionMode:'source_history_apply',frequencySourceMode:source.mode,expectedSourceDigits:source.digits});
                sourceAnalysis=checkedSourceHistory(reply,t.date,t.market,source.mode,source.digits);
              }
              rec=applyRangeSelection(selected,t,job.selection,recentHistoryProfile(local,job),job.initialTrick||0,combined,job.recent2IndicesOnly===true,rangeHistorySeed(job),carrySources,sourceAnalysis,json.recentDatedDraws);
            }
            if(json.status!=='success'||json.staleCache)throw new Error(json.message||'Exact-date result lookup unavailable');
            if(t.type==='ank'&&dailyStopped)rec={...rec,s:'SKIP',...(lossStopped?{backtestDailyStopLossSkipped:true}:{backtestDailyProfitSkipped:true})};
            if((json.targetDate&&json.targetDate!==date)||(json.actual?.date&&json.actual.date!==date))throw new Error('Historical source/result returned a different date');
            if(!resultOnlyLookup)json=await this.withDatedActual(t,job,json);
            if(rec.s!=='SKIP')rec=evaluateDatedBacktest(rec,t.type,json.actual||undefined,t.market);
            local={...local,dayRecords:{...local.dayRecords,[date]:{...local.dayRecords[date],[name]:{...local.dayRecords[date]?.[name],[t.index]:rec}}}};
            local=replayRangeDate(local,date,games,job.id,{autoCarryResultSix:job.selection==='carry_result6',autoResultParity:job.autoResultParity===true,dailyStopLoss:job.dailyStopLoss||0,dailyProfitTarget:job.dailyProfitTarget||0,dailyTargetGames:job.games,selectedMarkets:job.markets,resetAfterThreeFails:job.resetAfterThreeFails===true,maxStake:job.backtestMaxStake||0,runId:job.id,updatedAt:job.createdAt},protectedKeys(),allowedKeys);
            rec=local.dayRecords[date][name]![t.index];
            if(t.type==='ank'&&rec.s==='SKIP'){
              rec=observeSkippedAnk(rec,json.actual||undefined,date,t.market);
              local.dayRecords[date][name]![t.index]=rec;
              if(!rec.backtestSkipHistory?.actual||!rec.backtestSkipHistory?.sourceIndex){
                results.set(t,{status:'missing',reason:'No bet: skipped ANK history needs exact-date result and original source index; retry pending',selectionApplied:Boolean(getScrapeSource(rec))});continue;
              }
            }
            if(rec.s!=='SKIP'&&rec.d&&!isRecoveryRatePossible(t.type,rec.d)){
              rec={...rec,s:'WAIT'};local.dayRecords[date][name]![t.index]=rec;
              results.set(t,{status:'failed',reason:'Digit count has no recovery margin. Choose an existing digit-cut rule.',selectionApplied:true});
            }else results.set(t,{status:rec.s==='SKIP'?'policy_skip':(rec.backtestResult?.actual||rec.s==='FAIL'&&rec.jodiOpenStatus==='FAIL')?'done':'missing',reason:rec.s==='SKIP'?((rec.backtestDailyStopLossSkipped?`Daily stop loss ₹${job.dailyStopLoss} reached`:undefined)||(rec.backtestDailyProfitSkipped?`Daily profit target ₹${job.dailyProfitTarget} reached`:undefined)||rec.backtestCombinedKeep?.reason||rec.backtestCombinedCut?.reason|| (rec.backtestStakeLimitSkipped?`Backtest stake limit: next stake exceeds ₹${job.backtestMaxStake}`:'Existing Market Model policy SKIP')):(rec.backtestResult?.actual||rec.s==='FAIL'&&rec.jodiOpenStatus==='FAIL')?undefined:'Exact-date result missing; kept WAIT',selectionApplied:true});
          }catch(e:any){results.set(t,{status:'failed',reason:String(e?.message||e).slice(0,300),selectionApplied:t.selectionApplied});}
          finally{this.staging.checked=Array.from(results.values()).filter(r=>r.status!=='protected'&&r.status!=='disabled').length;this.staging.issues=Array.from(results.entries()).filter(([,r])=>r.reason).map(([task,r])=>({date,market:task.market,status:r.status,reason:r.reason!}));
            // Give status polling and Stop/Pause requests a turn between cached cards.
            await new Promise<void>(resolve=>setTimeout(resolve,0));}
        }
        const current=this.deps.read();const currentProfile=current?.profiles[job.profileId];
        if(!current||!currentProfile)throw new Error('Profile removed before archive commit');
        if(JSON.stringify(currentProfile.config)!==JSON.stringify(job.config))throw new Error('Profile settings changed during scraping; current date was not overwritten');
        if(dateSettings(currentProfile)!==initialDateSettings)throw new Error('Date loop/visibility/Restore settings changed during scraping; current date was kept');
        let updated=structuredClone(currentProfile),day={...updated.dayRecords[date]};
        let ankConflict=games.some(g=>g!=='ank') && JSON.stringify(Object.entries(base.dayRecords[date]?.data||{}).map(([i,r])=>[i,scrapeRecordVersion(r)]))!==JSON.stringify(Object.entries(currentProfile.dayRecords[date]?.data||{}).map(([i,r])=>[i,scrapeRecordVersion(r)]));
        for(const [t,result] of results){
          const name=rangeDict(t.type),latest=day[name]?.[t.index];
          if(scrapeRecordVersion(latest)!==snapshots.get(`${t.type}_${t.index}`)||rangeProtected(latest)||(t.type!=='ank'&&ankConflict)){
            Object.assign(t,{status:'protected',reason:'Source edited during run; saved card kept'});if(t.type==='ank')ankConflict=true;continue;
          }
          if(result.selectionApplied){const rec=local.dayRecords[date]?.[name]?.[t.index];if(rec)day={...day,[name]:{...day[name],[t.index]:rec}};}
          Object.assign(t,result);
        }
        updated=replayRangeDate({...updated,dayRecords:{...updated.dayRecords,[date]:day}},date,games,job.id,{autoCarryResultSix:job.selection==='carry_result6',autoResultParity:job.autoResultParity===true,dailyStopLoss:job.dailyStopLoss||0,dailyProfitTarget:job.dailyProfitTarget||0,dailyTargetGames:job.games,selectedMarkets:job.markets,resetAfterThreeFails:job.resetAfterThreeFails===true,maxStake:job.backtestMaxStake||0,runId:job.id,updatedAt:job.createdAt},protectedKeys(),allowedKeys);
        for(const type of games){const name=rangeDict(type),dict=updated.dayRecords[date][name];if(!dict)continue;
          for(const [index,rec] of Object.entries(dict)){
            const before=currentProfile.dayRecords[date]?.[name]?.[index];
            if(allowedKeys&&!allowedKeys.has(`${type}_${index}`))continue;
            if(rangeProtected(before)||protectedKeys().has(`${type}_${index}`))continue;
            if(JSON.stringify(rec)!==JSON.stringify(before)){
              const key=`${date}:${type}:${index}`;
              job.baseline??={};if(!(key in job.baseline))job.baseline[key]=before?structuredClone(before):null;
              const version=Math.max(Date.now(),rangeVersion(rec)+1,rangeVersion(before)+1);
              dict[index]={...rec,bulkBacktestJobId:job.id,bulkBacktestVersion:version};job.committed??={};job.committed[key]=version;job.committedSources??={};job.committedSources[key]=scrapeRecordVersion(dict[index]);
            }
          }
        }
        if(date<businessDateIST())this.deps.write({...current,profiles:{...current.profiles,[job.profileId]:updated}});
        job.updatedAt=Date.now();this.staging={date:'',checked:0,total:0,issues:[]};this.deps.persist(job);
      }
      if(job.state==='running'){job.state='completed';job.current=undefined;}
    }catch(e:any){if(job.state!=='stopped')job.state='paused';job.error=String(e?.message||e).slice(0,300);}
    finally{this.busy=false;this.staging={date:'',checked:0,total:0,issues:[]};job.updatedAt=Date.now();this.deps.persist(job);if(job.state==='completed'||job.state==='stopped')this.archiveCurrent(true);}
  }
  /** Source ranking and exact-date result lookup are separate, as in manual cutoff Auto Test. */
  private async withDatedActual(task:RangeTask,job:RangeJob,source:RangeResult):Promise<RangeResult>{
    if(actualForGame(source.actual||undefined,task.type,task.market)!==undefined||job.state!=='running')return source;
    const result=await this.scrapeWithRetry({...rangeScrapeBody(task,job,job.config),type:'ank',resultOnly:true});
    // An unavailable/partial lookup stays missing; never invent a result or change source digits.
    if(result.status!=='success'||result.staleCache||!result.actual)return source;
    if(result.actual.date!==task.date||(result.targetDate&&result.targetDate!==task.date))throw new Error('Actual result lookup returned a different date');
    return actualForGame(result.actual,task.type,task.market)!==undefined?{...source,actual:result.actual}:source;
  }
  private async prepareRecentHistory(job:RangeJob) {
    if(!['recent2','recent4','recent6_keep','history_apply','auto_day_recent2','auto_day_recent2_keep'].includes(job.selection)||job.recentHistorySeed===false)return;
    const count=job.selection==='recent6_keep'?6:job.selection==='recent4'?4:2;
    const profile=this.deps.read()?.profiles[job.profileId];if(!profile)throw new Error('Profile was removed');
    // Old First4 checkpoints must not mix cut seeds with untouched scraping history.
    if(job.recentWarmup && job.recentWarmup.seedRule!=='scraped')delete job.recentWarmup;
    if(!job.recentWarmup) {
      const markets=[...new Map(job.tasks.filter(t=>t.type==='ank'&&!['disabled','live','weekday_skip','protected'].includes(t.status)).map(t=>[t.market,t])).values()];
      const tasks:RangeTask[]=[];
      const warmupTargets=job.selection==='history_apply'?job.tasks.filter(t=>t.type==='ank'&&!['disabled','live','weekday_skip','protected'].includes(t.status)):markets;
      const seen=new Set<string>();
      for(const market of warmupTargets)for(let offset=1;offset<(job.selection==='history_apply'?HISTORY_WINDOW_DAYS+1:['recent6_keep','recent4'].includes(job.selection)?91:SOURCE_INDEX_HISTORY_DAYS);offset++) {
        const anchor=job.selection==='history_apply'?market.date:job.from;
        const date=new Date(Date.parse(`${anchor}T00:00:00Z`)-offset*86400000).toISOString().slice(0,10),key=market.market+'|'+date;
        if(seen.has(key))continue;seen.add(key);
        if(job.selection!=='history_apply'&&(!rangeWeekdaySelected(date,job)||!isMarketEnabledForDate(profile.config,profile.dayRecords[date]?.visAnk,market.market,date)))continue;
        tasks.push({date,type:'ank',index:market.index,market:market.market,status:'pending'});
      }
      job.recentWarmup={seedRule:'scraped',tasks,data:{}};this.deps.persist(job);
    }
    // A chart outage affects every date from that URL. Defer the remaining
    // private seeds until Resume instead of repeating the outage 90 times.
    // This set belongs only to this History Apply preparation pass.
    const unavailableSources=new Set<string>();
    for(const task of job.recentWarmup.tasks) {
      if(job.state!=='running')break;
      if(task.status!=='pending')continue;
      const current=this.deps.read()?.profiles[job.profileId];if(!current)throw new Error('Profile was removed');
      if(JSON.stringify(current.config)!==JSON.stringify(job.config))throw new Error('Profile settings changed during history preparation');
      const sourceMode=rangeHistorySource(job.mode,task.market),required=count;
      const history=recentHistoryProfile(current,job);
      if(job.selection!=='history_apply'&&(count===6?recentSixUniqueIndices(history.dayRecords,job.from,task.index,task.market):count===4?recentUniqueSourceIndices(history.dayRecords,job.from,task.index,task.market,4):recentSourceIndices(history.dayRecords,job.from,task.index,task.market,2,true)).length===required) {
        task.status='protected';task.reason='Required prior indices already available';continue;
      }
      // Real saved history always owns its day, including manual/Restore/WAIT records.
      const saved=findHistoricalMarketRecord(current.dayRecords[task.date]?.data,task.index,task.market);
      if(saved&&(job.selection!=='history_apply'||getScrapeSource(saved)?.mode===sourceMode)) {
        task.status='protected';task.reason='Existing history kept';continue;
      }
      const sourceKey=resolveMarketScrapeUrl(job.config,task.market)||task.market;
      if(job.selection==='history_apply'&&unavailableSources.has(sourceKey)) {
        task.status='failed';task.reason='Source unavailable; retry source history with Resume';continue;
      }
      this.currentStartedAt=Date.now();job.current=`PREPARING HISTORY · ${task.date} · ${task.market}`;
      try {
        const json=await this.scrapeWithRetry(rangeScrapeBody(task,job,job.config));
        if(job.selection==='history_apply'&&(json.staleCache||[408,429,502,503,504].includes(json.httpStatus||0)))unavailableSources.add(sourceKey);
        if(json.status!=='success'||json.staleCache)throw new Error(json.message||'Fresh prior-date source unavailable');
        if((json.targetDate&&json.targetDate!==task.date)||(json.actual?.date&&json.actual.date!==task.date))throw new Error('History source returned a different date');
        const source=selectionRecord(undefined,task,json,job);
        // History observes the original scraped selection; no cut/trick/parity
        // or automatic result removal is applied to these private seed records.
        const resolved=await this.withDatedActual(task,job,json);
        const rec=evaluateDatedBacktest(source,'ank',resolved.actual||undefined,task.market);
        if(!rec.backtestResult?.actual||!['PASS','FAIL'].includes(rec.s)) {
          task.status='missing';task.reason='Exact prior-date result unavailable';
        }else {
          job.recentWarmup.data[task.date]={...job.recentWarmup.data[task.date],[task.index]:rec};
          task.status='done';delete task.reason;
        }
      }catch(e:any){
        if(job.selection==='history_apply'&&(e?.rangeTimeout||['ECONNREFUSED','ENETUNREACH','EHOSTUNREACH','ENOTFOUND','EAI_AGAIN','ETIMEDOUT'].includes(e?.code||e?.cause?.code)))unavailableSources.add(sourceKey);
        task.status='failed';task.reason=String(e?.message||e).slice(0,300);
      }
      job.updatedAt=Date.now();this.deps.persist(job);
      await new Promise<void>(resolve=>setTimeout(resolve,0));
    }
    this.deps.persist(job);
  }
  private async scrapeWithRetry(body:Record<string,unknown>){
    const attempt=async()=>{
      let timer:ReturnType<typeof setTimeout>|undefined;
      try{return await Promise.race([this.deps.scrape(body),new Promise<RangeResult>((_,reject)=>{
        timer=setTimeout(()=>reject(Object.assign(new Error('Historical chart request timed out; retry pending cards'),{rangeTimeout:true})),this.deps.scrapeTimeoutMs??45000);
      })]);}finally{if(timer)clearTimeout(timer);}
    };
    let result=await attempt();
    if(this.job?.state==='running'&&result.status!=='success'&&(!result.httpStatus||result.httpStatus===429||result.httpStatus>=500))result=await attempt();
    return result;
  }
}
