import { createContext } from 'react';
import type { AppState } from '../types';

/** Authorized startup snapshot; Admin snapshots are tied to the current writer. */
export const VerifiedStartupState = createContext<{
  profileId: string;
  token: string;
  state: AppState | null;
  stateJson?: string;
  editorId?: string;
  /** Release the one-shot startup payload after App owns its hydrated state. */
  consumeSnapshot?: () => void;
} | null>(null);
