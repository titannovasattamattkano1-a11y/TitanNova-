import {panelAnkDigit} from './panelAnk';
import type {DigitFollowDraw} from './digitFollow';

/** Same-side latest panna reference; matches may occur on either historical side. */
export function selectPannaFollow(draws:DigitFollowDraw[],targetDate:string,side:'open'|'close',observe?:(digit:string,date:string)=>void,observationLimit?:number){
  const validDate=(value:string)=>/^\d{4}-\d{2}-\d{2}$/.test(value)&&Number.isFinite(Date.parse(`${value}T00:00:00Z`))&&new Date(`${value}T00:00:00Z`).toISOString().slice(0,10)===value;
  if(!validDate(targetDate))throw new Error('Panna Follow: invalid target date');
  type Draw={open?:string;close?:string;openDigit?:string;closeDigit?:string};
  const byDate=new Map<string,Draw>(),conflicts=new Set<string>();
  for(const row of draws){
    if(!validDate(row.date)||row.date>=targetDate)continue;
    const open=/^\d{3}$/.test(row.open||'')?row.open:undefined;
    const close=/^\d{3}$/.test(row.close||'')?row.close:undefined;
    const pair=/^\d{2}$/.test(row.jodi||'')?row.jodi:undefined;
    const openDigit=panelAnkDigit(open)||undefined,closeDigit=panelAnkDigit(close)||undefined;
    if(pair&&((openDigit!==undefined&&openDigit!==pair[0])||(closeDigit!==undefined&&closeDigit!==pair[1])))conflicts.add(row.date);
    const next:Draw={open,close,openDigit:pair?.[0]??openDigit,closeDigit:pair?.[1]??closeDigit};
    const old=byDate.get(row.date)||{};
    for(const key of ['open','close','openDigit','closeDigit'] as const){
      if(old[key]!==undefined&&next[key]!==undefined&&old[key]!==next[key])conflicts.add(row.date);
      next[key]??=old[key];
    }
    byDate.set(row.date,next);
  }
  const history=[...byDate].sort(([a],[b])=>a.localeCompare(b));
  const latest=[...history].reverse().find(([date,row])=>!conflicts.has(date)&&row[side]!==undefined);
  if(!latest)throw new Error(`Panna Follow: selected date se pehle ${side.toUpperCase()} panna nahi mila; card unchanged`);
  const reference=latest[1][side]!;
  const timeline:Array<{panna?:string;digit?:string;date:string}>=[];
  for(const [date,row] of history){
    if(conflicts.has(date)){timeline.push({date});continue;}
    if(row.openDigit===undefined&&row.closeDigit===undefined)continue;
    // An unknown half stays in the timeline; it must never be jumped over.
    timeline.push({panna:row.open,digit:row.openDigit,date},{panna:row.close,digit:row.closeDigit,date});
  }
  const digits=new Set<string>();let scanned=0,matches=0;
  for(let i=timeline.length-2;i>=0;i--){
    scanned++;
    const next=timeline[i+1].digit;
    if(timeline[i].panna!==reference||next===undefined)continue;
    matches++;observe?.(next,timeline[i].date);digits.add(next);
    if(observationLimit===undefined?digits.size===10:matches>=observationLimit)break;
  }
  return {digits:[...digits].join(', '),reference,baseDate:latest[0],matches,scanned,complete:digits.size===10};
}
