import type {DayMarketRecord} from '../types';
import type {CombinedCutInputs} from './backtestCombinedCut';
import {getScrapeSource} from './scrapeProvenance';
import {isMirrorProtected} from './adminMirror';
/** Backtest only: six KEEP slots, duplicate candidates use their own mirror. */
export function applyBacktestCombinedKeep(record:DayMarketRecord,inputs:CombinedCutInputs):DayMarketRecord {
  if(record.s==='SKIP'||isMirrorProtected(record)||record.dispatchState||record.deliveryRestoredAt)return record;
  const source=getScrapeSource(record),original=source?.digits.split(', ')||[];
  const audit:NonNullable<DayMarketRecord['backtestCombinedKeep']>={rule:'auto_day_recent2_keep',auto:[...inputs.auto],day:[...inputs.day],indices:[...inputs.indices],indexDigits:inputs.indices.map(i=>original[i-1]).filter(Boolean),kept:[],choices:[]};
  const next={...record,backtestCombinedKeep:audit};
  const skip=(reason:string)=>({...next,s:'SKIP' as const,backtestCombinedKeep:{...audit,kept:[],choices:[],reason}});
  if(!source)return skip('Combined keep: original ten-digit source missing');
  if(inputs.auto.length!==2||inputs.day.length!==2||![...inputs.auto,...inputs.day].every(d=>/^\d$/.test(d)))return skip('Combined keep: AUTO/DAY recent two source digits missing');
  if(inputs.indices.length!==2||!inputs.indices.every(i=>Number.isInteger(i)&&i>=1&&i<=10))return skip('Combined keep: two prior same-side PASS/FAIL result indices required');
  const used=new Set<string>();
  for(const primary of [...inputs.auto,...inputs.day,...audit.indexDigits]) {
    const duplicate=used.has(primary),digit=duplicate?String((Number(primary)+5)%10):primary;
    if(!original.includes(digit)||used.has(digit))return skip('Combined keep: six unique digits impossible; candidate and mirror already used');
    used.add(digit);audit.choices.push({digit,via:duplicate?'mirror':'original'});
  }
  audit.kept=[...used];next.d=audit.kept.join(', ');next.od=source.digits;next.scrapeSource=source;
  delete next.backtestCombinedCut;
  delete next.trick;delete next.positionRule;delete next.weekdaySelectedDigits;delete next.weekdayHitPosition;
  delete next.scrapeResultDigit;delete next.manualResult;delete next.marketModel;
  if(!next.manualRate){delete next.recRate;delete next.prevLoss;delete next.targetProfitWithLoss;delete next.rateFinalizedFrom;delete next.rateFinalizedAt;}
  return next;
}
