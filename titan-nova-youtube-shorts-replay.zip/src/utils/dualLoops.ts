export { getDefaultConfig } from '../data/markets';
import {useRecoveryShareLedger,runtimeRecoveryShareLedger} from './twoCardRecovery';
import type { DayMarketRecord, DayRecordStore, GameType, ProfileConfig, ProtocolConfig, UserProfile } from '../types';
import { normalizeTargetProfit } from './settlement';
import { getEffectiveMarkets, getEffectiveBaseMarkets } from '../data/markets';
import { isMarketEnabledForDate } from './profileMarketToggle';
export type LoopId = 'L1' | 'L2' | 'L3' | 'L4' | 'L5' | 'L6' | 'L7' | 'L8' | 'L9' | 'L10';
export type LoopCount = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;
export interface LoopSettings {
  name?: string;
  capital: number; dayTarget: number; ank: ProtocolConfig; jodi: ProtocolConfig; pannel: ProtocolConfig;
  gameAccounts?: Partial<Record<GameType,{capital:number;dayTarget:number}>>;
}
export const LOOP_GAMES:GameType[]=['ank','jodi','pannel'];
export function gameAccountLimits(account:LoopSettings,type:GameType){
  return account.gameAccounts?.[type]||{capital:account.capital,dayTarget:account.dayTarget};
}
export interface DualLoopConfig {
  independentAccounts?: boolean;
  enabled: boolean; startsOn: string; loopCount?: LoopCount; revision?: number; assignments: Record<string, LoopId>; loops: Record<LoopId, LoopSettings>;
}
export const LOOP_IDS: LoopId[] = ['L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'L7', 'L8', 'L9', 'L10'];
export const activeLoopIds = (config: DualLoopConfig): LoopId[] => LOOP_IDS.slice(0,config.loopCount||2);
export const loopLabel = (config: DualLoopConfig) => activeLoopIds(config).join('/');
export const loopAssignmentKey = (type: string, name: string) => `${type}:${String(name || '').trim().toUpperCase()}`;
const amount = (value: unknown, fallback: number) => Number.isFinite(Number(value)) && Number(value) >= 0 ? Number(value) : fallback;
export const isLoopId = (value: unknown): value is LoopId => typeof value === 'string' && LOOP_IDS.includes(value as LoopId);
export const validLoopDate = (value: unknown): value is string => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) &&
  !Number.isNaN(Date.parse(value)) && new Date(value+'T00:00:00Z').toISOString().slice(0,10) === value;
/** Missing/invalid configuration is OFF, preserving existing profiles exactly. */
export function normalizeDualLoops(value: unknown, base?: Partial<ProfileConfig>): DualLoopConfig | undefined {
  if (!value || typeof value !== 'object') return undefined;
  const raw = value as Partial<DualLoopConfig>;
  if (!validLoopDate(raw.startsOn)) return undefined;
  const inferred=Object.values(raw.assignments||{});
  const inferredCount=Math.max(2,...inferred.filter(isLoopId).map(id=>LOOP_IDS.indexOf(id)+1));
  const loopCount:LoopCount=(Number.isInteger(raw.loopCount) && Number(raw.loopCount)>=1 && Number(raw.loopCount)<=10 ? raw.loopCount : raw.loopCount===undefined ? inferredCount : 2) as LoopCount;
  const assignments: Record<string, LoopId> = {};
  Object.entries(raw.assignments || {}).forEach(([key, loop]) => {
    const colon = key.indexOf(':'); const type = key.slice(0, colon), name = key.slice(colon + 1);
    if (['ank','jodi','pannel'].includes(type) && name.trim() && isLoopId(loop) && LOOP_IDS.slice(0,loopCount).includes(loop)) assignments[loopAssignmentKey(type,name)] = loop;
  });
  const fallbackCapital = amount(base?.capital,0) / loopCount;
  const settings = (id: LoopId): LoopSettings => {
    const source = raw.loops?.[id];
    const capital=amount(source?.capital,!LOOP_IDS.slice(0,loopCount).includes(id)?0:fallbackCapital);
    const dayTarget=amount(source?.dayTarget,amount(base?.dayTarget,0)/loopCount);
    const protocol = (type: GameType): ProtocolConfig => ({ cap: amount(source?.[type]?.cap, amount(base?.[type]?.cap,0) / loopCount),
      tgt: normalizeTargetProfit(source?.[type]?.tgt, normalizeTargetProfit(base?.[type]?.tgt,100)) });
    return { ...(typeof source?.name==='string'&&source.name.trim()?{name:source.name.trim().slice(0,40)}:{}), capital,dayTarget,
      ...(source?.gameAccounts?{gameAccounts:Object.fromEntries(LOOP_GAMES.map(type=>[type,{capital:amount(source.gameAccounts?.[type]?.capital,capital),dayTarget:amount(source.gameAccounts?.[type]?.dayTarget,dayTarget)}]))}:{}),
      ank: protocol('ank'), jodi: protocol('jodi'), pannel: protocol('pannel') };
  };
  return { ...(raw.independentAccounts===true?{independentAccounts:true}:{}), enabled: raw.enabled === true, startsOn: raw.startsOn, loopCount, ...(Number.isSafeInteger(raw.revision) && Number(raw.revision)>0 ? {revision:Number(raw.revision)} : {}), assignments, loops: Object.fromEntries(LOOP_IDS.map(id=>[id,settings(id)])) as Record<LoopId,LoopSettings> };
}
/** Return OFF configurations too, so live sync cannot resurrect a prior ON. */
export function loopSettingsForDate(profile: UserProfile, date: string): DualLoopConfig | undefined {
  const snapshot = normalizeDualLoops(profile.dayRecords?.[date]?.loopConfig, profile.config);
  if(snapshot&&!profile.customLoopChanges)return snapshot;
  const scheduled = normalizeDualLoops(profile.config?.dualLoops, profile.config);
  const fallback=snapshot||(scheduled&&validLoopDate(date)&&date>=scheduled.startsOn?scheduled:undefined);
  if(!profile.customLoopChanges)return fallback;
  let latest='',raw:DualLoopConfig|undefined;
  for(const [from,value] of Object.entries(profile.customLoopChanges)){
    if(from<=date&&from>latest&&validLoopDate(from)&&value?.independentAccounts){latest=from;raw=value;}
  }
  const change=normalizeDualLoops(raw,profile.config);if(!change)return fallback;
  // A later explicitly saved setup wins over a previously auto-pinned date.
  // Actual delivered ownership/rates remain frozen on each card.
  const base=snapshot&&Number(snapshot.revision||0)>=Number(change.revision||0)?snapshot:change;
  return {...base,independentAccounts:true,enabled:change.enabled,startsOn:date,revision:Math.max(Number(base.revision||0),Number(change.revision||0))};
}
export function dayLoopConfig(profile: UserProfile, date: string): DualLoopConfig | undefined {
  const config=loopSettingsForDate(profile,date);
  return config?.enabled?config:undefined;
}
/** Reuse normalization only within one synchronous replay, never across edits. */
export interface ProfileLoopContext {readonly config:DualLoopConfig|undefined}
export function createProfileLoopContext(profile:UserProfile,date:string):ProfileLoopContext {
  return {config:dayLoopConfig(profile,date)};
}
export function assignedLoop(config: DualLoopConfig | undefined, type: string, name: string, rec?: Partial<DayMarketRecord>): LoopId | undefined {
  if (!config?.enabled) return undefined;
  if(isLoopAssignmentFrozen(rec)) {
    if(isLoopId(rec?.sentLoopId))return rec.sentLoopId;
    if(isLoopId(rec?.loopId))return rec.loopId;
  }
  return config.assignments[loopAssignmentKey(type,name)] || 'L1';
}
export function profileRecoveryTrack(profile: UserProfile, date: string, type: GameType, name: string, rec?: Partial<DayMarketRecord>, context?:ProfileLoopContext): string {
  const loop = assignedLoop(context?context.config:dayLoopConfig(profile,date),type,name,rec);
  if (loop) return `${loop}:${type}:ALL`;
  const cfg = (date < new Date().toISOString().slice(0, 10) ? profile?.dayRecords?.[date]?.recoveryConfigSnapshot : undefined) || profile?.config;
  const isSmartOn = !cfg?.fourWaveRelay && (type === 'ank' ? cfg?.ankSplit !== false : type === 'pannel' ? cfg?.panSplit !== false : false);
  if (isSmartOn && cfg?.sameMarketRecovery !== false) {
    const baseMarket = String(name || '').replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
    return `${type}:${baseMarket}`;
  }
  return `${type}:ALL`;
}
export function profileLoopTarget(profile: UserProfile,date: string,type: GameType,name: string,rec?: Partial<DayMarketRecord>, context?:ProfileLoopContext): number {
  const config = context?context.config:dayLoopConfig(profile,date), loop = assignedLoop(config,type,name,rec);
  return normalizeTargetProfit(loop && config ? config.loops[loop][type].tgt : profile.config[type]?.tgt,100);
}
/** Runtime lookup also honors the actual delivered assignment, never a new config guess. */
export function runtimeLoop(profile: any, type: string, name: string, rec?: Partial<DayMarketRecord>): LoopId | undefined {
  const config = normalizeDualLoops(profile?.loopConfig);
  if (!config?.enabled) return undefined;
  const market = (profile.markets || []).find((m: any) => m.type === type && String(m.n || '').trim().toUpperCase() === String(name || '').trim().toUpperCase());
  return assignedLoop(config,type,name,rec || (market ? profile.cards?.[`${type}_${market.index}`] : undefined));
}
export function runtimeRecoveryTrack(profile: any, type: string, name: string): string {
  const loop = runtimeLoop(profile,type,name);
  if (loop) return `${loop}:${type}:ALL`;
  const isSmartOn = type === 'ank'
    ? (profile?.splitMode ? profile.splitMode.ank !== false : profile?.config?.ankSplit !== false)
    : type === 'pannel'
      ? (profile?.splitMode ? profile.splitMode.pannel !== false : profile?.config?.panSplit !== false)
      : false;
  if (!profile?.fourWaveRelay && !profile?.config?.fourWaveRelay && isSmartOn && profile?.sameMarketRecovery !== false && profile?.config?.sameMarketRecovery !== false) {
    const baseMarket = String(name || '').replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
    return `${type}:${baseMarket}`;
  }
  return `${type}:ALL`;
}
export function runtimeTarget(profile: any, type: string, track: string): number {
  const config = normalizeDualLoops(profile?.loopConfig), prefix = track.split(':')[0];
  return normalizeTargetProfit(config?.enabled && isLoopId(prefix) ? config.loops[prefix][type as GameType]?.tgt : profile?.targetProfit?.[type],100);
}
/** Pin the whole day's loop setup. Financial history and unsent predictions are not rewritten. */
export function pinDayLoops(profile: UserProfile,date: string): UserProfile {
  const config = loopSettingsForDate(profile,date);
  if (!config || !config.enabled&&!config.independentAccounts || profile.dayRecords?.[date]?.loopConfig) return profile;
  return { ...profile, dayRecords: { ...profile.dayRecords, [date]: { ...(profile.dayRecords?.[date] || {}), loopConfig: config } } };
}
export function dayHasCommittedPlays(day: DayRecordStore | undefined): boolean {
  return ['data','jodiData','pannelData'].some(key => Object.values(day?.[key as 'data'] || {}).some(rec =>
    rec && (rec.sentRate || rec.sentDigits || rec.dispatchState || rec.manualStatus || ((!rec.backtestResult || rec.manualStatus) && (rec.s === 'PASS' || rec.s === 'FAIL')))));
}

/** Eligibility follows the same dated visibility as cards and recovery calculations. */
export function enabledLoopMembers(profile: UserProfile, config: DualLoopConfig, date: string): Set<LoopId> {
  const members=new Set<LoopId>(),day=profile.dayRecords?.[date];
  for(const type of ['ank','jodi','pannel'] as GameType[]) {
    const markets=type==='jodi'?getEffectiveBaseMarkets(profile.config):getEffectiveMarkets(profile.config);
    const visibility=type==='ank'?day?.visAnk:type==='jodi'?day?.visJodi:day?.visPan;
    for(const market of markets) if(isMarketEnabledForDate(profile.config,visibility,market.n,date)) members.add(config.assignments[loopAssignmentKey(type,market.n)] || 'L1');
  }
  return members;
}

/** Default 28 rounds in time order, dealt L1 → L2 → L3 repeatedly. */
export const THREE_LOOP_ROUND_GROUPS: Record<'L1'|'L2'|'L3', readonly string[]> = {
  L1:['SRIDEVI OPEN','MADHUR DAY OPEN','MILAN DAY OPEN','KALYAN OPEN','SUPREME DAY CLOSE','SRIDEVI NIGHT CLOSE','MILAN NIGHT OPEN','MAIN BAZAR OPEN','MILAN NIGHT CLOSE','MAIN BAZAR CLOSE'],
  L2:['SRIDEVI CLOSE','TIME BAZAR CLOSE','RAJDHANI DAY OPEN','MILAN DAY CLOSE','KALYAN CLOSE','MADHUR NIGHT OPEN','KALYAN NIGHT OPEN','MADHUR NIGHT CLOSE','KALYAN NIGHT CLOSE'],
  L3:['TIME BAZAR OPEN','MADHUR DAY CLOSE','SUPREME DAY OPEN','RAJDHANI DAY CLOSE','SRIDEVI NIGHT OPEN','SUPREME NIGHT OPEN','RAJDHANI NIGHT OPEN','SUPREME NIGHT CLOSE','RAJDHANI NIGHT CLOSE'],
};
/** Replace the preset on explicit Apply; saved date assignments remain authoritative. */
export function threeLoopPreset(config: DualLoopConfig, profileConfig: ProfileConfig): DualLoopConfig {
  const assignments: Record<string, LoopId> = Object.fromEntries(Object.entries(config.assignments).map(([key,id])=>[key,(['L1','L2','L3'] as string[]).includes(id)?id:'L1']));
  for(const type of ['ank','pannel'] as const) for(const m of getEffectiveMarkets(profileConfig)) {
    const id=(['L1','L2','L3'] as const).find(loop=>THREE_LOOP_ROUND_GROUPS[loop].includes(m.n.trim().toUpperCase()));
    if(id)assignments[loopAssignmentKey(type,m.n)]=id;
  }
  // Jodi remains one full-pair card and follows the base market's OPEN round.
  for(const m of getEffectiveBaseMarkets(profileConfig)) {
    const id=(['L1','L2','L3'] as const).find(loop=>THREE_LOOP_ROUND_GROUPS[loop].includes(m.n.trim().toUpperCase()+' OPEN'));
    if(id)assignments[loopAssignmentKey('jodi',m.n)]=id;
  }
  return {...config,loopCount:3,assignments};
}
export function hasCommittedThirdLoop(day: DayRecordStore | undefined): boolean {
  return ['data','jodiData','pannelData'].some(key=>Object.values(day?.[key as 'data']||{}).some(rec=>rec && (rec.sentLoopId==='L3'||rec.loopId==='L3') && isLoopAssignmentFrozen(rec)));
}

/** Delivered identities outside a proposed active set cannot silently disappear. */
export function hasCommittedInactiveLoop(day: DayRecordStore | undefined, config: DualLoopConfig): boolean {
  if(!config.enabled)return false;
  const active=activeLoopIds(config);
  return ['data','jodiData','pannelData'].some(key=>Object.values(day?.[key as 'data']||{}).some(rec=>{
    const id=rec?.sentLoopId || rec?.loopId;
    return isLoopId(id) && !active.includes(id) && isLoopAssignmentFrozen(rec);
  }));
}
/** Exact 28-round grouping verified against the default IST timetable. */
export const FOUR_LOOP_ROUND_GROUPS: Record<'L1'|'L2'|'L3'|'L4', readonly string[]> = {
 L1:['SRIDEVI OPEN','TIME BAZAR CLOSE','SUPREME DAY OPEN','SUPREME DAY CLOSE','MADHUR NIGHT OPEN','RAJDHANI NIGHT OPEN','MILAN NIGHT CLOSE'],
 L2:['SRIDEVI CLOSE','MADHUR DAY CLOSE','KALYAN OPEN','KALYAN CLOSE','SUPREME NIGHT OPEN','MAIN BAZAR OPEN','KALYAN NIGHT CLOSE'],
 L3:['TIME BAZAR OPEN','MILAN DAY OPEN','MILAN DAY CLOSE','SRIDEVI NIGHT OPEN','MILAN NIGHT OPEN','MADHUR NIGHT CLOSE','RAJDHANI NIGHT CLOSE'],
 L4:['MADHUR DAY OPEN','RAJDHANI DAY OPEN','RAJDHANI DAY CLOSE','SRIDEVI NIGHT CLOSE','KALYAN NIGHT OPEN','SUPREME NIGHT CLOSE','MAIN BAZAR CLOSE'],
};
export function fourLoopRoundPreset(config: DualLoopConfig, profileConfig: ProfileConfig): DualLoopConfig {
 const assignments:Record<string,LoopId>=Object.fromEntries(Object.entries(config.assignments).map(([key,id])=>[key,(['L1','L2','L3','L4'] as string[]).includes(id)?id:'L1']));
 for(const type of ['ank','pannel'] as const)for(const market of getEffectiveMarkets(profileConfig)){
  const id=(['L1','L2','L3','L4'] as const).find(loop=>FOUR_LOOP_ROUND_GROUPS[loop].includes(market.n.trim().toUpperCase()));
  if(id)assignments[loopAssignmentKey(type,market.n)]=id;
 }
 // Jodi remains one full-pair card: its existing OPEN recovery follows the OPEN round's loop.
 for(const market of getEffectiveBaseMarkets(profileConfig)){
  const id=(['L1','L2','L3','L4'] as const).find(loop=>FOUR_LOOP_ROUND_GROUPS[loop].includes(market.n.trim().toUpperCase()+' OPEN'));
  if(id)assignments[loopAssignmentKey('jodi',market.n)]=id;
 }
 return {...config,loopCount:4,assignments};
}

/** Derived archive rates/results can replay; actual deliveries and confirmed results cannot. */
export function isLoopAssignmentFrozen(rec?: Partial<DayMarketRecord>): boolean {
 if(!rec)return false;
 if(rec.sentRate || rec.sentDigits || rec.dispatchState)return true;
 return (rec.s==='PASS' || rec.s==='FAIL') && (Boolean(rec.manualStatus) || !rec.backtestResult);
}

/** Financial routing is separate from the existing scraping/result-digit tracks. */
export function profileFinancialRecoveryTrack(profile:UserProfile,date:string,type:GameType,name:string,rec?:Partial<DayMarketRecord>,context?:ProfileLoopContext):string {
  return profileRecoveryTrack(profile,date,type,name,rec,context);
}
export function runtimeFinancialRecoveryTrack(profile:any,type:string,name:string):string {
  return runtimeRecoveryTrack(profile,type,name);
}

export function profileLegacyFinancialTrack(profile:UserProfile,date:string,type:GameType,name:string,rec?:Partial<DayMarketRecord>,context?:ProfileLoopContext):string {
 const loop=assignedLoop(context?context.config:dayLoopConfig(profile,date),type,name,rec);if(loop)return `${loop}:${type}:ALL`;
 const split=profile.config.twoCardRecoveryLegacySplit?.[type as 'ank'|'pannel']??(type==='ank'?profile.config.ankSplit!==false:profile.config.panSplit!==false);
 return `${type}:${split?(/CLOSE/i.test(name)?'CLOSE':'OPEN'):'ALL'}`;
}
