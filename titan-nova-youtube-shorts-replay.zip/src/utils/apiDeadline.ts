/** A deadline never retries a mutation: the server may already have committed it. */
export function apiDeadlineSignal(signal?: AbortSignal | null, timeoutMs = 30000): AbortSignal {
  const timeout = typeof AbortSignal.timeout === 'function' ? AbortSignal.timeout(timeoutMs) : (() => {
    const timerController = new AbortController();
    setTimeout(() => timerController.abort(), timeoutMs);
    return timerController.signal;
  })();
  if (!signal) return timeout;
  if (typeof AbortSignal.any === 'function') return AbortSignal.any([signal, timeout]);
  const controller = new AbortController();
  const abort = () => { controller.abort(); signal.removeEventListener('abort', abort); timeout.removeEventListener('abort', abort); };
  signal.addEventListener('abort', abort, {once:true}); timeout.addEventListener('abort', abort, {once:true});
  if (signal.aborted) abort();
  return controller.signal;
}
