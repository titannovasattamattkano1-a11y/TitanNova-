import type {DayMarketRecord} from '../types';
import {getScrapeSource,getScrapeResultIndex} from './scrapeProvenance';
import {evaluateBacktest,actualForGame,type DatedActual} from './backtestResult';
/** Observe a skipped historical ANK card without placing or settling a wager. */
export function observeSkippedAnk(record:DayMarketRecord,row:DatedActual|undefined,date:string,name:string):DayMarketRecord {
  return observeSkippedAnkActual(record,row?.date===date?actualForGame(row,'ank',name):undefined,date);
}
/** Archive replay may reuse an already checked result without another chart fetch. */
export function observeSkippedAnkActual(record:DayMarketRecord,actual:string|undefined,date:string):DayMarketRecord {
  if(record.s!=='SKIP'||record.sentDigits||record.dispatchState||record.manualStatus||record.deliveryRestoredAt)return record;
  const source=getScrapeSource(record);
  const digit=/^\d$/.test(actual||'')?actual:undefined;
  const index=source&&digit?source.digits.split(', ').indexOf(digit)+1:undefined;
  const hasSelection=(!record.backtestCombinedCut||record.backtestCombinedCut.removed.length===4)&&(!record.backtestCombinedKeep||record.backtestCombinedKeep.kept.length===6);
  const evaluated=digit&&hasSelection?evaluateBacktest({...record,s:'WAIT'},'ank',digit):undefined;
  const status=evaluated&&['PASS','FAIL'].includes(evaluated.s)?evaluated.s as 'PASS'|'FAIL':undefined;
  return {...record,s:'SKIP',scrapeResultDigit:digit,backtestSkipHistory:{date,actual:digit,sourceIndex:index&&index>0?index:undefined,status}};
}
/** Only the range strategy's read-only history view sees a simulated hit/miss. */
export function skippedHistoryRecord(record:DayMarketRecord):DayMarketRecord {
  const history=record.backtestSkipHistory;
  if(record.s!=='SKIP'||!history?.status||getScrapeResultIndex(record)===undefined)return record;
  return {...record,s:history.status,scrapeResultDigit:history.actual,backtestResult:{checked:true,digits:record.d,actual:history.actual}};
}
