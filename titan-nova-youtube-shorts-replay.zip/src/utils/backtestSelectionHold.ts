import type {DayMarketRecord,UserProfile} from '../types';
import {businessDateIST} from './businessDate';
import {modelSourceVersion} from './marketModelCard';
/** Undo may clear result evidence, but must not run source filters on that missing evidence. */
export function holdBacktestSelection(record:DayMarketRecord,date:string|undefined):DayMarketRecord {
  if(!record.d.trim()||!date||!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date||date>=businessDateIST())return record;
  return {...record,backtestSelectionHold:{date,digits:record.d,sourceVersion:modelSourceVersion(record)}};
}
export function isBacktestSelectionHeld(record:DayMarketRecord,date:string):boolean {
  const hold=record.backtestSelectionHold;
  return Boolean(hold&&hold.date===date&&hold.digits===record.d&&hold.sourceVersion===modelSourceVersion(record));
}

/** Only this profile/date is affected; source versions still release individual edits. */
export function holdBacktestDaySelections(profile:UserProfile,date:string,release=false):UserProfile {
  const day=profile.dayRecords?.[date];if(!day)return profile;
  const next={...day};let changed=false;
  for(const dict of ['data','jodiData','pannelData'] as const){
    if(!day[dict])continue;
    const records={...day[dict]};let touched=false;
    for(const [index,record] of Object.entries(records)){
      if(release){if(!record.backtestSelectionHold)continue;const copy={...record};delete copy.backtestSelectionHold;records[index]=copy;}
      else{const copy=holdBacktestSelection(record,date);if(copy===record)continue;records[index]=copy;}
      touched=true;
    }
    if(touched){next[dict]=records;changed=true;}
  }
  return changed?{...profile,dayRecords:{...profile.dayRecords,[date]:next}}:profile;
}
