import {canReplaceLiveCombinedDecision,releaseLiveCombinedDecision} from './liveCombinedDecision';
import type { AppState, DayMarketRecord, UserProfile } from '../types';
import { getEffectiveMarkets, isDayMarket, isNightMarket } from '../data/markets';
import type { MarketScope } from '../types';
import { isMirrorProtected, vipCopiesAdmin } from './adminMirror';
import { isMarketEnabledForDate } from './profileMarketToggle';
import { areSettlementTokensValid } from './settlement';

const tokens = (value: string) => value.split(/[,|\s]+/).filter(Boolean);
const editable = (record: DayMarketRecord | undefined) => Boolean(record && canReplaceLiveCombinedDecision(record) && !isMirrorProtected(record) && !record.dispatchState && record.s !== 'SKIP');

/** Filter the selected digits, keeping their order and multiplicity. */
function selectUnmatched(record: DayMarketRecord, digits: string, name: string): DayMarketRecord {
  if (tokens(record.d).join(', ') === digits) return record;
  const next: DayMarketRecord = { ...record, d: digits, od: record.od || record.d, marketName: name, s: 'WAIT',
    sourceEditedAt: Math.max(Date.now(), Number(record.sourceEditedAt || 0) + 1, Number(record.marketModel?.updatedAt || 0) + 1) };
  releaseLiveCombinedDecision(next);
  delete next.autoRemovedResult;
  delete next.trick; delete next.positionRule; delete next.weekdaySelectedDigits; delete next.weekdayHitPosition;
  delete next.marketModel; delete next.strictPanel30; delete next.backtestResult; delete next.scrapeResultDigit;
  delete next.manualStatus; delete next.manualResult; delete next.manualPanelResult; delete next.manualResultSources;
  delete next.jodiOpenStatus; delete next.jodiOpenResult; delete next.jodiOpenSettledAt;
  if (!next.manualRate) {
    delete next.recRate; delete next.prevLoss; delete next.targetProfitWithLoss;
    delete next.rateFinalizedFrom; delete next.rateFinalizedAt;
  }
  return next;
}

/** Remove common digits from each side using both pre-update selections. Legacy export names remain compatible.
 * One explicit bulk operation; pairs and copied VIP pairs change atomically. */
export function applyOpenCloseMatch(state: AppState, profileId: string, date: string, scope: MarketScope = 'ALL') {
  const source = state.profiles[profileId];
  const result = { state, matchedPairs: 0, changedCards: 0, emptyPairs: 0, skippedPairs: 0, alreadyCommonPairs: 0, missingPairs: 0, protectedPairs: 0, disabledPairs: 0, invalidDigitPairs: 0 };
  if (!source) return result;
  const day = source.dayRecords?.[date];
  if (!day?.data) return result;
  const markets = getEffectiveMarkets(source.config);
  const pairs = new Map<string, { open?: number; close?: number }>();
  markets.forEach((market, index) => {
    const match = /^(.*)\s+(OPEN|CLOSE)$/i.exec(market.n.trim());
    if (!match) return;
    const base = match[1].trim().toUpperCase();
    const pair = pairs.get(base) || {};
    pair[match[2].toUpperCase() === 'OPEN' ? 'open' : 'close'] = index;
    pairs.set(base, pair);
  });
  const data = { ...day.data };
  const changedPairs: Array<[number, number]> = [];
  for (const pair of pairs.values()) {
    const open = pair.open === undefined ? undefined : data[pair.open];
    const close = pair.close === undefined ? undefined : data[pair.close];
    if (pair.open === undefined || pair.close === undefined || !open || !close) {
      result.missingPairs++; result.skippedPairs++; continue;
    }
    if (!editable(open) || !editable(close)) {
      result.protectedPairs++; result.skippedPairs++; continue;
    }
    if (!isMarketEnabledForDate(source.config, day.visAnk, markets[pair.open].n, date) ||
      !isMarketEnabledForDate(source.config, day.visAnk, markets[pair.close].n, date)) {
      result.disabledPairs++; result.skippedPairs++; continue;
    }
    if (!areSettlementTokensValid('ank', open.d) || !areSettlementTokensValid('ank', close.d)) {
      result.invalidDigitPairs++; result.skippedPairs++; continue;
    }
    const openMarket = markets[pair.open];
    const closeMarket = markets[pair.close];
    if (scope === 'DAY' && (!isDayMarket(openMarket.n, openMarket.hr) || !isDayMarket(closeMarket.n, closeMarket.hr))) {
      continue;
    }
    if (scope === 'NIGHT' && (!isNightMarket(openMarket.n, openMarket.hr) || !isNightMarket(closeMarket.n, closeMarket.hr))) {
      continue;
    }
    const openDigits = tokens(open.d), closeDigits = tokens(close.d);
    const openSet = new Set(openDigits), closeSet = new Set(closeDigits);
    const nextOpen = selectUnmatched(open, openDigits.filter(digit => !closeSet.has(digit)).join(', '), markets[pair.open].n);
    const nextClose = selectUnmatched(close, closeDigits.filter(digit => !openSet.has(digit)).join(', '), markets[pair.close].n);
    result.matchedPairs++;
    if (!nextOpen.d || !nextClose.d) result.emptyPairs++;
    if (nextOpen === open && nextClose === close) { result.alreadyCommonPairs++; continue; }
    result.changedCards += Number(nextOpen !== open) + Number(nextClose !== close);
    data[pair.open] = nextOpen; data[pair.close] = nextClose;
    changedPairs.push([pair.open, pair.close]);
  }
  if (!changedPairs.length) return result;
  const profiles = { ...state.profiles, [profileId]: { ...source, dayRecords: { ...source.dayRecords, [date]: { ...day, data } } } };
  if (profileId === 'admin1') {
    for (const [pid, vip] of Object.entries(profiles)) {
      if (pid === 'admin1' || !vipCopiesAdmin(vip)) continue;
      const vipMarkets = getEffectiveMarkets(vip.config);
      const vipDay = vip.dayRecords?.[date] || {};
      const vipData = { ...vipDay.data };
      let copied = false;
      for (const pair of changedPairs) {
        // An unchanged T3 side retains the existing independent-source policy.
        if (pair.some(index => data[index].trick === 'T3')) continue;
        const indices = pair.map(index => vipMarkets.findIndex(market => market.n === markets[index].n));
        if (indices.some(index => index < 0 || (vipData[index] && !editable(vipData[index])))) continue;
        pair.forEach((sourceIndex, side) => {
          const index = indices[side], admin = data[sourceIndex];
          const old = vipData[index] || { s: 'WAIT' as const, d: '', r: '' };
          const next = { ...selectUnmatched(old, admin.d, markets[sourceIndex].n), mirroredFromAdmin: true,
            sourceEditedAt: Math.max(Number(admin.sourceEditedAt || 0), Number(old.sourceEditedAt || 0) + 1) };
          if (admin.od) next.od = admin.od;
          if (admin.sourceMode) next.sourceMode = admin.sourceMode; else delete next.sourceMode;
          if (admin.scrapeSource) next.scrapeSource = { ...admin.scrapeSource }; else delete next.scrapeSource;
          vipData[index] = next; copied = true;
        });
      }
      if (copied) profiles[pid] = { ...vip, dayRecords: { ...vip.dayRecords, [date]: { ...vipDay, data: vipData } } } as UserProfile;
    }
  }
  result.state = { ...state, profiles };
  return result;
}

/** Explain the outcome without weakening pair or delivery protection. */
export function describeOpenCloseMatch(result: ReturnType<typeof applyOpenCloseMatch>): string {
  const reasons: string[] = [];
  if (result.alreadyCommonPairs) reasons.push(`${result.alreadyCommonPairs} pairs ke digits pehle se unmatched hain`);
  if (result.missingPairs) reasons.push(`${result.missingPairs} pairs mein OPEN/CLOSE card missing hai`);
  if (result.protectedPairs) reasons.push(`${result.protectedPairs} pairs sent/queued, settled ya stopped/locked hain`);
  if (result.disabledPairs) reasons.push(`${result.disabledPairs} pairs mein market/side disabled hai`);
  if (result.invalidDigitPairs) reasons.push(`${result.invalidDigitPairs} pairs mein selected digits missing/invalid hain`);
  return reasons.join(' · ') || 'Selected profile/date mein OPEN/CLOSE cards nahi hain.';
}

/** Merge (Union) digits of OPEN and CLOSE boxes of the same market:
 * Example: OPEN card [1,2,3,4] + CLOSE card [3,4,5,6] -> both become [1,2,3,4,5,6] (Unique sorted) */
export function applyOpenCloseUnion(state: AppState, profileId: string, date: string, scope: MarketScope = 'ALL') {
  const source = state.profiles[profileId];
  const result = { state, mergedPairs: 0, changedCards: 0, skippedPairs: 0, alreadyMergedPairs: 0, missingPairs: 0, protectedPairs: 0, disabledPairs: 0, invalidDigitPairs: 0 };
  if (!source) return result;
  const day = source.dayRecords?.[date];
  if (!day?.data) return result;
  const markets = getEffectiveMarkets(source.config);
  const pairs = new Map<string, { open?: number; close?: number }>();
  markets.forEach((market, index) => {
    const match = /^(.*)\s+(OPEN|CLOSE)$/i.exec(market.n.trim());
    if (!match) return;
    const base = match[1].trim().toUpperCase();
    const pair = pairs.get(base) || {};
    pair[match[2].toUpperCase() === 'OPEN' ? 'open' : 'close'] = index;
    pairs.set(base, pair);
  });
  const data = { ...day.data };
  const changedPairs: Array<[number, number]> = [];
  for (const pair of pairs.values()) {
    const open = pair.open === undefined ? undefined : data[pair.open];
    const close = pair.close === undefined ? undefined : data[pair.close];
    if (pair.open === undefined || pair.close === undefined || !open || !close) {
      result.missingPairs++; result.skippedPairs++; continue;
    }
    if (!editable(open) || !editable(close)) {
      result.protectedPairs++; result.skippedPairs++; continue;
    }
    if (!isMarketEnabledForDate(source.config, day.visAnk, markets[pair.open].n, date) ||
      !isMarketEnabledForDate(source.config, day.visAnk, markets[pair.close].n, date)) {
      result.disabledPairs++; result.skippedPairs++; continue;
    }
    if (!areSettlementTokensValid('ank', open.d) || !areSettlementTokensValid('ank', close.d)) {
      result.invalidDigitPairs++; result.skippedPairs++; continue;
    }
    const openMarket = markets[pair.open];
    const closeMarket = markets[pair.close];
    if (scope === 'DAY' && (!isDayMarket(openMarket.n, openMarket.hr) || !isDayMarket(closeMarket.n, closeMarket.hr))) {
      continue;
    }
    if (scope === 'NIGHT' && (!isNightMarket(openMarket.n, openMarket.hr) || !isNightMarket(closeMarket.n, closeMarket.hr))) {
      continue;
    }
    const openDigits = tokens(open.d), closeDigits = tokens(close.d);
    // Combine unique sorted digits from both boxes
    const combinedSet = new Set<string>([...openDigits, ...closeDigits]);
    const mergedList = Array.from(combinedSet).sort((a, b) => Number(a) - Number(b));
    const mergedStr = mergedList.join(', ');

    const nextOpen = selectUnmatched(open, mergedStr, markets[pair.open].n);
    const nextClose = selectUnmatched(close, mergedStr, markets[pair.close].n);
    result.mergedPairs++;
    if (nextOpen.d === open.d && nextClose.d === close.d) {
      result.alreadyMergedPairs++;
      continue;
    }
    result.changedCards += Number(nextOpen.d !== open.d) + Number(nextClose.d !== close.d);
    data[pair.open] = nextOpen;
    data[pair.close] = nextClose;
    changedPairs.push([pair.open, pair.close]);
  }
  if (!changedPairs.length) return result;
  const profiles = { ...state.profiles, [profileId]: { ...source, dayRecords: { ...source.dayRecords, [date]: { ...day, data } } } };
  if (profileId === 'admin1') {
    for (const [pid, vip] of Object.entries(profiles)) {
      if (pid === 'admin1' || !vipCopiesAdmin(vip)) continue;
      const vipMarkets = getEffectiveMarkets(vip.config);
      const vipDay = vip.dayRecords?.[date] || {};
      const vipData = { ...vipDay.data };
      let copied = false;
      for (const pair of changedPairs) {
        if (pair.some(index => data[index].trick === 'T3')) continue;
        const indices = pair.map(index => vipMarkets.findIndex(market => market.n === markets[index].n));
        if (indices.some(index => index < 0 || (vipData[index] && !editable(vipData[index])))) continue;
        pair.forEach((sourceIndex, side) => {
          const index = indices[side], admin = data[sourceIndex];
          const old = vipData[index] || { s: 'WAIT' as const, d: '', r: '' };
          const next = { ...selectUnmatched(old, admin.d, markets[sourceIndex].n), mirroredFromAdmin: true,
            sourceEditedAt: Math.max(Number(admin.sourceEditedAt || 0), Number(old.sourceEditedAt || 0) + 1) };
          if (admin.od) next.od = admin.od;
          if (admin.sourceMode) next.sourceMode = admin.sourceMode; else delete next.sourceMode;
          if (admin.scrapeSource) next.scrapeSource = { ...admin.scrapeSource }; else delete next.scrapeSource;
          vipData[index] = next; copied = true;
        });
      }
      if (copied) profiles[pid] = { ...vip, dayRecords: { ...vip.dayRecords, [date]: { ...vipDay, data: vipData } } } as UserProfile;
    }
  }
  result.state = { ...state, profiles };
  return result;
}

export function describeOpenCloseUnion(result: ReturnType<typeof applyOpenCloseUnion>): string {
  const reasons: string[] = [];
  if (result.alreadyMergedPairs) reasons.push(`${result.alreadyMergedPairs} pairs ke digits pehle se fully mixed/same hain`);
  if (result.missingPairs) reasons.push(`${result.missingPairs} pairs mein OPEN/CLOSE card missing hai`);
  if (result.protectedPairs) reasons.push(`${result.protectedPairs} pairs sent/queued, settled ya stopped/locked hain`);
  if (result.disabledPairs) reasons.push(`${result.disabledPairs} pairs mein market/side disabled hai`);
  if (result.invalidDigitPairs) reasons.push(`${result.invalidDigitPairs} pairs mein selected digits missing/invalid hain`);
  return reasons.join(' · ') || 'Selected profile/date mein OPEN/CLOSE cards nahi hain.';
}

