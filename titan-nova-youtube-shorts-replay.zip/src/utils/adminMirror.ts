import { isEditableSourceSkip, modelSourceVersion } from './marketModelCard';
import type { DayMarketRecord, UserProfile } from '../types';

export const vipCopiesAdmin = (profile: UserProfile | undefined): boolean =>
  Boolean(profile) && profile?.vipCopyAdmin !== false;

export const isMirrorProtected = (record: DayMarketRecord | undefined): boolean => Boolean(
  record?.sentRate || record?.sentDigits || record?.dispatchState === 'QUEUED' || record?.dispatchState === 'SENT' ||
  record?.dispatchState === 'SETTLED' || String(record?.dispatchState) === 'SENDING' || ((!record?.backtestResult || record?.manualStatus) && (record?.s === 'PASS' || record?.s === 'FAIL'))
);

/** Copy only Admin source identity; VIP rate/recovery/delivery fields stay untouched. */
export function projectAdminSource(
  target: DayMarketRecord | undefined,
  admin: DayMarketRecord,
  marketName: string,
  archiveCompleted = false,
  forceSourceCopy = false,
): DayMarketRecord | undefined {
  const carryPolicy=Boolean(admin?.carryResultSix&&admin.d===admin.carryResultSix.output&&admin.carryResultSix.outputVersion===modelSourceVersion(admin));
  // This new source policy cannot revive a manually/stopped card or rewrite a
  // reserved delivery. Explicit force-copy remains an intentional Admin action.
  if((admin?.liveCombinedCut||carryPolicy)&&!forceSourceCopy&&target&&(target.manualStatus||target.vipAutoStopSkipped||target.dispatchState||target.deliveryRestoredAt||(target.s==='SKIP'&&!isEditableSourceSkip(target))))return target;
  const emptyFirstCut=admin.positionRule==='FIRST_CUT'&&admin.d===''&&Boolean(admin.od)&&Number(admin.sourceEditedAt)>0;
  if ((!admin?.d && !isEditableSourceSkip(admin)&&!carryPolicy&&!emptyFirstCut) || (!forceSourceCopy && (admin.trick === 'T3' || isMirrorProtected(target)))) return target;
  // Backfill/rate polling must not undo a newer explicit VIP Clear. A fresh
  // Admin source edit still resumes the existing copy pipeline normally.
  if (!forceSourceCopy && target?.d === '' && target.sourceMode === 'MANUAL' && modelSourceVersion(target) > modelSourceVersion(admin)) return target;
  const next: DayMarketRecord = {
    ...(forceSourceCopy ? { s: 'WAIT' as const, d: '', r: '', loopId: target?.loopId, schTime: target?.schTime, schTargets: target?.schTargets, cardGeneration: target?.cardGeneration } : target || { s: 'WAIT', d: '', r: '' }),
    d: String(admin.d),
    marketName: String(marketName || admin.marketName || '').trim().toUpperCase(),
    mirroredFromAdmin: true,
    sourceEditedAt: forceSourceCopy
      ? Math.max(Date.now(), modelSourceVersion(admin), modelSourceVersion(target) + 1)
      : Math.max(modelSourceVersion(admin), modelSourceVersion(target)) || undefined,
  };
  if(admin.smartSelection&&admin.smartSelection.digits===admin.d)next.smartSelection={...admin.smartSelection,sourceVersion:Number(next.sourceEditedAt||0)};else delete next.smartSelection;
  if(admin.sourceMode==='MSSD'&&admin.mssdState&&admin.mssdState.output===admin.d)next.mssdState={...structuredClone(admin.mssdState),outputVersion:Number(next.sourceEditedAt||0)};else delete next.mssdState;
  if (admin.positionRule === 'FCUT' || admin.positionRule === 'LCUT' || admin.positionRule === 'CENTER' || admin.positionRule === 'FIRST_CUT' || admin.positionRule === 'CUT2' || admin.positionRule === 'RECENT2' || admin.positionRule === 'RECENT6' || admin.positionRule === 'RECENT4' || admin.positionRule === 'LAST_ACTUAL_MIRROR' || admin.positionRule === 'FIRST_DIGIT_MIRROR' || admin.positionRule === 'SSD' || admin.positionRule === 'FLOW_3_1' || admin.positionRule === 'TRI_CUT' || admin.positionRule === 'SNIPER_1' || admin.positionRule === 'TESLA_369') next.positionRule = admin.positionRule;
  else if (next.positionRule === 'FCUT' || next.positionRule === 'LCUT' || next.positionRule === 'CENTER' || next.positionRule === 'FIRST_CUT' || next.positionRule === 'CUT2' || next.positionRule === 'RECENT2' || next.positionRule === 'RECENT6' || next.positionRule === 'RECENT4' || next.positionRule === 'LAST_ACTUAL_MIRROR' || next.positionRule === 'FIRST_DIGIT_MIRROR' || next.positionRule === 'SSD' || next.positionRule === 'FLOW_3_1' || next.positionRule === 'TRI_CUT' || next.positionRule === 'SNIPER_1' || next.positionRule === 'TESLA_369') delete next.positionRule;
  if (admin.masterFlow) next.masterFlow = structuredClone(admin.masterFlow); else delete next.masterFlow;
  if(admin.positionRule==='FIRST_DIGIT_MIRROR'&&admin.firstDigitMirrorCut?.output===admin.d)next.firstDigitMirrorCut={...admin.firstDigitMirrorCut,outputVersion:next.sourceEditedAt||0};
  else delete next.firstDigitMirrorCut;
  delete next.triCut;
  delete next.sniperOne;
  delete next.tesla369;
  if(admin.positionRule==='TRI_CUT'&&admin.triCut?.output===admin.d)next.triCut={...structuredClone(admin.triCut),outputVersion:Number(next.sourceEditedAt||0)};
  else delete next.triCut;
  delete next.sniperOne;
  delete next.tesla369;
  if(admin.positionRule==='SNIPER_1'&&admin.sniperOne?.output===admin.d)next.sniperOne={...structuredClone(admin.sniperOne),outputVersion:Number(next.sourceEditedAt||0)};
  else delete next.sniperOne;
  delete next.tesla369;
  if(admin.positionRule==='TESLA_369'&&admin.tesla369?.output===admin.d)next.tesla369={...structuredClone(admin.tesla369),outputVersion:Number(next.sourceEditedAt||0)};
  else delete next.tesla369;
  if(admin.carryResultSix&&admin.d===admin.carryResultSix.output&&admin.carryResultSix.outputVersion===modelSourceVersion(admin))next.carryResultSix={...admin.carryResultSix,outputVersion:next.sourceEditedAt||0};else delete next.carryResultSix;
  delete next.autoResultParity;
  if(admin.liveCombinedCut){next.liveCombinedCut=structuredClone(admin.liveCombinedCut);next.s=admin.liveCombinedCut.reason?'SKIP':'WAIT';}
  else delete next.liveCombinedCut;
  if (admin.autoRemovedResult && admin.d === admin.autoRemovedResult.output && (admin.autoRemovedResult.outputVersion === undefined || admin.autoRemovedResult.outputVersion === modelSourceVersion(admin))) next.autoRemovedResult = { ...admin.autoRemovedResult, outputVersion: next.sourceEditedAt || 0 };
  else delete next.autoRemovedResult;
  if (admin.od) next.od = String(admin.od); else delete next.od;
  if (admin.trick === 'T1' || admin.trick === 'T2' || (forceSourceCopy && admin.trick === 'T3')) next.trick = admin.trick; else delete next.trick;
  if (admin.sourceMode) next.sourceMode = admin.sourceMode; else delete next.sourceMode;
  delete next.marketModel;
  delete next.strictPanel30;
  if (admin.marketModel) { next.marketModel = { ...admin.marketModel, windows: [...admin.marketModel.windows] }; next.s = admin.marketModel.decision === 'SKIP' ? 'SKIP' : 'WAIT'; }
  else { if (isEditableSourceSkip(target)&&!admin.liveCombinedCut?.reason) next.s = 'WAIT'; delete next.marketModel; }
  if (admin.sourceMode === 'SP_SKIP30' && admin.strictPanel30) { next.strictPanel30 = structuredClone(admin.strictPanel30); next.s = admin.strictPanel30.decision === 'SKIP' ? 'SKIP' : 'WAIT'; }
  if (admin.scrapeSource) next.scrapeSource = { ...admin.scrapeSource }; else delete next.scrapeSource;
  delete next.scrapeResultDigit;
  delete next.manualResult;
  if (!forceSourceCopy && archiveCompleted && isMirrorProtected(admin)) next.s = 'SKIP';

  if (String(target?.d || '') !== next.d && !next.manualRate && !next.sentRate) {
    delete next.recRate;
    delete next.prevLoss;
    delete next.targetProfitWithLoss;
    delete next.rateFinalizedFrom;
    delete next.rateFinalizedAt;
  }
  return next;
}

/** Clear only unsent source fields previously copied from Admin. */
export function clearProjectedAdminSource(record: DayMarketRecord | undefined): DayMarketRecord | undefined {
  if (!record?.mirroredFromAdmin || isMirrorProtected(record)) return record;
  if (record.s === 'SKIP') return undefined;
  const next = { ...record, d: '' };
  if (next.positionRule === 'FCUT' || next.positionRule === 'LCUT' || next.positionRule === 'CENTER' || next.positionRule === 'FIRST_CUT' || next.positionRule === 'RECENT2' || next.positionRule === 'RECENT6' || next.positionRule === 'RECENT4' || next.positionRule === 'LAST_ACTUAL_MIRROR' || next.positionRule === 'FIRST_DIGIT_MIRROR' || next.positionRule === 'SSD' || next.positionRule === 'FLOW_3_1' || next.positionRule === 'TRI_CUT' || next.positionRule === 'SNIPER_1' || next.positionRule === 'TESLA_369') delete next.positionRule;
  delete next.masterFlow;
  delete next.firstDigitMirrorCut;
  delete next.triCut;
  delete next.sniperOne;
  delete next.tesla369;
  delete next.mssdState;
  delete next.carryResultSix;
  delete next.autoResultParity;
  delete next.autoRemovedResult;
  delete next.liveCombinedCut;
  delete next.od;
  delete next.trick;
  delete next.sourceMode;
  delete next.strictPanel30;
  delete next.marketModel;
  delete next.scrapeSource;
  delete next.scrapeResultDigit;
  delete next.manualResult;
  delete next.mirroredFromAdmin;
  delete next.recRate;
  delete next.prevLoss;
  delete next.targetProfitWithLoss;
  delete next.rateFinalizedFrom;
  delete next.rateFinalizedAt;
  return next;
}
