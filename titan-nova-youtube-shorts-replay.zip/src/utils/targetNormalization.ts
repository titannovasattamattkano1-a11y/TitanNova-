export type TargetKind = 'group' | 'phone' | 'channel' | 'auto';

export const isTelegramTarget = (value: unknown): boolean => /^tg:(group|channel|user):-?[1-9]\d*$/.test(String(value || ''));
export const isGroupTarget = (value: string): boolean => value.endsWith('@g.us') || /^tg:group:-[1-9]\d*$/.test(value);
export const isChannelTarget = (value: string): boolean => value.endsWith('@newsletter') || /^tg:channel:-[1-9]\d*$/.test(value);

/**
 * Normalize user-entered WhatsApp destinations before they enter app state.
 * Group ids use `@g.us`, Channels use `@newsletter`, and phone numbers use `@s.whatsapp.net`.
 */
export function normalizeTargetJid(raw: unknown, kind: TargetKind = 'auto'): string | null {
  const clean = String(raw ?? '').trim();
  if (!clean) return null;
  if (clean.startsWith('tg:')) {
    if (!isTelegramTarget(clean)) return null;
    const type = clean.split(':')[1];
    if ((type === 'user') !== !clean.split(':')[2].startsWith('-')) return null;
    return kind === 'auto' || kind === (type === 'user' ? 'phone' : type) ? clean : null;
  }

  const lower = clean.toLowerCase();
  if (lower.endsWith('@newsletter')) {
    return (kind === 'auto' || kind === 'channel') && /^\d{8,}@newsletter$/.test(lower) ? lower : null;
  }
  if (lower.endsWith('@g.us')) {
    return kind === 'auto' || kind === 'group' ? lower : null;
  }
  if (lower.endsWith('@s.whatsapp.net') || lower.endsWith('@lid')) {
    return kind === 'auto' || kind === 'phone' ? lower : null;
  }

  if (/^\d{8,}-\d{4,}$/.test(clean)) {
    return kind === 'auto' || kind === 'group' ? `${clean}@g.us` : null;
  }

  const digits = clean.replace(/[^0-9]/g, '');
  if (!digits) return null;

  if (kind === 'group') {
    return /^\d{8,}-\d{4,}$/.test(clean) ? `${clean}@g.us` : null;
  }

  // BUG FIX: A bare numeric value is ambiguous and must never silently become a Channel.
  if (kind === 'channel') return null;

  return digits.length >= 8 ? `${digits}@s.whatsapp.net` : null;
}

export function normalizeTargetList(values: unknown, kind: TargetKind = 'auto'): string[] {
  if (!Array.isArray(values)) return [];
  return [...new Set(values.map((value) => normalizeTargetJid(value, kind)).filter((value): value is string => Boolean(value)))];
}

/** Income result sources are chats that can publish market results. */
export function normalizeIncomeSourceList(values: unknown): string[] {
  return normalizeTargetList(values).filter(
    (jid) => isGroupTarget(jid) || isChannelTarget(jid),
  );
}
