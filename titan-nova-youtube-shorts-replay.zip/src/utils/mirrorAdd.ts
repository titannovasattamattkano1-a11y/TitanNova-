import type {AppState,DayMarketRecord} from '../types';
import {getEffectiveMarkets, isDayMarket, isNightMarket} from '../data/markets';
import type {MarketScope} from '../types';
import {getScrapeSource} from './scrapeProvenance';
import {modelSourceVersion} from './marketModelCard';
import {vipCopiesAdmin,projectAdminSource} from './adminMirror';
import {isMarketEnabledForDate} from './profileMarketToggle';
import {vipLiveMarketEligible} from './vipLiveStart';

const editable=(r:DayMarketRecord|undefined)=>Boolean(r&&r.s==='WAIT'&&!r.manualStatus&&!r.sentDigits&&!r.sentRate&&!r.dispatchState&&!r.deliveryRestoredAt);
/** Expand only current selected digits, preserving first-seen digit/mirror order. */
export function addSelectedMirrors(record:DayMarketRecord|undefined):DayMarketRecord|undefined {
  if(!editable(record))return;
  const rec=record!,current=rec.d.split(/[,|\s]+/).filter(Boolean);
  if(!current.length||!current.every(d=>/^\d$/.test(d)))return;
  const output=[...new Set(current.flatMap(d=>[d,String((Number(d)+5)%10)]))].join(', ');
  if(output===current.join(', '))return;
  const source=getScrapeSource(rec);
  const next:DayMarketRecord={...rec,d:output,sourceEditedAt:Math.max(Date.now(),modelSourceVersion(rec)+1)};
  if(source){next.scrapeSource=source;next.od=source.digits;}
  delete next.trick;delete next.positionRule;delete next.firstDigitMirrorCut;delete next.tesla369;delete next.triCut;delete next.sniperOne;
  delete next.weekdaySelectedDigits;delete next.weekdayHitPosition;
  delete next.autoRemovedResult;delete next.autoResultParity;delete next.carryResultSix;
  delete next.marketModel;delete next.strictPanel30;delete next.liveCombinedCut;
  delete next.scrapeResultDigit;delete next.backtestResult;delete next.manualResult;delete next.manualResultSources;
  delete next.rateFinalizedFrom;delete next.rateFinalizedAt;
  if(!next.manualRate){delete next.recRate;delete next.prevLoss;delete next.targetProfitWithLoss;}
  return next;
}

/** Single date/profile commit; copied VIPs retain their existing copy policy. */
export function applyBulkMirrorAdd(state:AppState,profileId:string,date:string,scope:MarketScope='ALL'){
  const source=state.profiles[profileId],day=source?.dayRecords?.[date];
  const result={state,changedCards:0,copiedCards:0};if(!source||!day?.data)return result;
  const markets=getEffectiveMarkets(source.config),data={...day.data};
  const changed:Array<{index:number;name:string}>=[];
  markets.forEach((m,index)=>{
    const rec=data[index];
    const inScope = scope === 'ALL' ? true : scope === 'DAY' ? isDayMarket(m.n, m.hr) : isNightMarket(m.n, m.hr);
    if(!inScope)return;
    if(!isMarketEnabledForDate(source.config,day.visAnk,m.n,date)||!vipLiveMarketEligible(source,date,'ank',m.n)||
       (rec?.marketName&&rec.marketName.trim().toUpperCase()!==m.n.trim().toUpperCase()))return;
    const next=addSelectedMirrors(rec);if(!next)return;
    data[index]={...next,marketName:m.n};changed.push({index,name:m.n});
  });
  if(!changed.length)return result;
  const profiles={...state.profiles,[profileId]:{...source,dayRecords:{...source.dayRecords,[date]:{...day,data}}}};
  if(profileId==='admin1')for(const [pid,vip] of Object.entries(profiles)){
    if(pid===profileId||!vipCopiesAdmin(vip))continue;
    const vipMarkets=getEffectiveMarkets(vip.config),vipDay=vip.dayRecords[date]||{},vipData={...vipDay.data};let copied=false;
    for(const {index,name} of changed){
      const vi=vipMarkets.findIndex(m=>m.n.trim().toUpperCase()===name.trim().toUpperCase()),target=vipData[vi];
      if(vi<0||(target&&!editable(target))||!isMarketEnabledForDate(vip.config,vipDay.visAnk,name,date)||!vipLiveMarketEligible(vip,date,'ank',name)||
         (target?.marketName&&target.marketName.trim().toUpperCase()!==name.trim().toUpperCase()))continue;
      const next=projectAdminSource(target,data[index],name);if(!next||next===target)continue;
      delete next.firstDigitMirrorCut;delete next.tesla369;delete next.triCut;delete next.sniperOne;delete next.backtestResult;
      vipData[vi]=next;copied=true;result.copiedCards++;
    }
    if(copied)profiles[pid]={...vip,dayRecords:{...vip.dayRecords,[date]:{...vipDay,data:vipData}}};
  }
  result.changedCards=changed.length;result.state={...state,profiles};return result;
}
