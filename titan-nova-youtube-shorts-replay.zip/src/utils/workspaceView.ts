import type { MainNavTab } from '../components/BottomNav';
import type { GameType } from '../types';

/** Per-document view only; fresh writer recovery still reloads all server data. */
export const workspaceView: { mainNav: MainNavTab; activeTab: GameType | 'market_manager' | 'setup' | 'backtest' } = {
  mainNav: 'ledger', activeTab: 'ank',
};
