import {getScrapeSource} from './scrapeProvenance';
import type {DayMarketRecord} from '../types';
import {applyBacktestCombinedCut, type CombinedCutInputs} from './backtestCombinedCut';
import {autoRemovalInput} from './autoRemoveResult';
import {isMirrorProtected} from './adminMirror';

export function hasLiveCombinedCut(record:DayMarketRecord|undefined, position: 'first' | 'last' = 'first'):boolean {
  const audit=record?.liveCombinedCut;
  if(!audit||!record)return false;
  const matchPos = !audit.position || audit.position === position;
  return matchPos && ((record.d===audit.output&&Number(record.sourceEditedAt||0)>=audit.updatedAt)||Boolean(record.autoRemovedResult&&record.autoRemovedResult.input===audit.output&&record.autoRemovedResult.output===record.d&&record.autoRemovedResult.outputVersion===record.sourceEditedAt));
}

/** Live combined cut: direct 4-digit cut (first 2 or last 2), direct SKIP on duplicates or missing digits. */
export function applyLiveCombinedCut(record:DayMarketRecord|undefined,inputs:CombinedCutInputs):DayMarketRecord|undefined {
  if(!record||record.s!=='WAIT'||record.manualStatus||isMirrorProtected(record)||record.dispatchState||record.deliveryRestoredAt)return record;
  if(hasLiveCombinedCut(record, inputs.position || 'first'))return record;
  const applied=applyBacktestCombinedCut({...record,d:autoRemovalInput(record)},inputs);
  if(applied===record||!applied.backtestCombinedCut)return record;
  const next={...applied};
  const updatedAt=Math.max(Date.now(),Number(record.sourceEditedAt||0)+1);
  next.sourceEditedAt=updatedAt;
  next.liveCombinedCut={...applied.backtestCombinedCut,output:applied.s==='SKIP'?'':applied.d,updatedAt};
  if(next.s==='SKIP')next.d='';
  delete next.backtestCombinedCut;
  delete next.autoRemovedResult;
  return next;
}

/** A no-bet result is source history only, never financial settlement. */
export function observeLiveCombinedSkip(record:DayMarketRecord,actual:string|undefined,date:string):DayMarketRecord {
  if(record.s!=='SKIP'||!record.liveCombinedCut?.reason||record.manualStatus||record.sentRate||record.sentDigits||record.dispatchState||!/^\d$/.test(actual||''))return record;
  const source=getScrapeSource(record),sourceIndex=source?source.digits.split(', ').indexOf(actual!)+1:0;
  if(sourceIndex<1)return record;
  const observation={date,actual:actual!,sourceIndex};
  if(JSON.stringify(record.liveCombinedCut.observation)===JSON.stringify(observation))return record;
  return {...record,liveCombinedCut:{...record.liveCombinedCut,observation}};
}
