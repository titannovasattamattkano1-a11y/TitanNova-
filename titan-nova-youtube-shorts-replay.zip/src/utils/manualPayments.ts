/** Manual UPI verification only: these checks never assert bank receipt. */
export const PAYMENT_PLANS = {
 '1 Day - ₹500': {amount:500,days:1},
 'Weekly - ₹1,500': {amount:1500,days:7},
 'Monthly - ₹4,000': {amount:4000,days:30},
} as const;
export const normalizePaymentUtr=(value:unknown)=>String(value||'').trim().toUpperCase();
export function validatePaymentProof(body:any){
 const plan=PAYMENT_PLANS[body?.planLabel as keyof typeof PAYMENT_PLANS];
 if(!plan||body.amount!==plan.amount)throw new Error('Amount must match the selected plan');
 const utr=normalizePaymentUtr(body.utr);
 if(!/^[A-Z0-9]{12}$/.test(utr))throw new Error('Enter a valid 12-character UPI UTR/reference number');
 const image=body.image||'';
 if(typeof image!=='string'||image.length>2800000||image&&!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(image))throw new Error('Screenshot must be PNG, JPEG or WebP, maximum 2 MB');
 if(image){
  let bytes:string;try{bytes=atob(image.split(',')[1]);}catch{throw new Error('Screenshot contains invalid image data');}
  const mime=image.slice(5,image.indexOf(';'));
  const valid=mime==='image/png'?bytes.startsWith('\x89PNG\r\n\x1a\n'):mime==='image/jpeg'?bytes.startsWith('\xff\xd8\xff'):bytes.startsWith('RIFF')&&bytes.slice(8,12)==='WEBP';
  if(bytes.length>2*1024*1024||!valid)throw new Error('Screenshot must contain a valid PNG, JPEG or WebP, maximum 2 MB');
 }
 return {amount:plan.amount,planLabel:body.planLabel as string,utr,image};
}
export function extendPaymentExpiry(expiry:string|undefined,today:string,days:number){
 if(!Number.isInteger(days)||days<1||days>3660)throw new Error('Access days must be an integer from 1 to 3660');
 const valid=typeof expiry==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(expiry)&&Number.isFinite(Date.parse(expiry))&&new Date(expiry).toISOString().slice(0,10)===expiry;
 const base=valid&&expiry&&expiry>today?expiry:today;
 return new Date(Date.parse(base+'T00:00:00Z')+days*86400000).toISOString().slice(0,10);
}
/** Old dashboard uploads cannot erase server-received proofs or roll back reviews. */
export function preserveServerPayments(incoming:any,stored:any){
 if(!stored)return incoming;
 const payments=Array.isArray(stored.payments)?stored.payments:[];
 const next={...incoming,payments,profiles:{...incoming.profiles},...(stored.paymentSettingsManaged?{paymentMethods:stored.paymentMethods,paymentSettingsManaged:true}:{})};
 for(const [id,profile] of Object.entries(stored.profiles||{}) as any){
  if(!next.profiles[id])continue;
  const reviews=payments.filter((p:any)=>p.userId===id&&p.reviewedAt);
  if(reviews.some((p:any)=>!incoming.payments?.some((q:any)=>q.id===p.id&&q.reviewedAt===p.reviewedAt))){
   next.profiles[id]={...next.profiles[id],expiryDate:profile.expiryDate};
  }
 }
 return next;
}
