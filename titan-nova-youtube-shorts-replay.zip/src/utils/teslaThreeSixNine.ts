import type { DayMarketRecord, UserProfile } from '../types';
import { isMirrorProtected } from './adminMirror';
import { getScrapeSource } from './scrapeProvenance';
import { modelSourceVersion } from './marketModelCard';
import { canReplaceLiveCombinedDecision, releaseLiveCombinedDecision } from './liveCombinedDecision';
import { confirmedAnkResult } from './autoRemoveResult';
import { getEffectiveMarkets } from '../data/markets';
import { findReferenceJodiForMarket } from './lifetimeJodiFormula';
import { collectMarketSettledHistory, getPrecedingMarketActual } from './sniperOne';

const dateValid = (d: string) => /^\d{4}-\d{2}-\d{2}$/.test(d) && Number.isFinite(Date.parse(d));

export interface Tesla369Details {
  actual?: string;
  triad: string[];
  mirrors: string[];
  selectedDigits: string[];
  input: string;
  output: string;
  outputVersion: number;
  summary: string;
}

/**
 * Resolves the recent draw digit for a given market:
 * - If OPEN card: returns the OPEN digit of the preceding settled draw of this base market (e.g. Jodi 24 -> Open: 2).
 * - If CLOSE card: returns the CLOSE digit of the preceding settled draw of this base market (e.g. Jodi 24 -> Close: 4).
 * - Supports 2-digit Jodi charts, settled ANK history, and preceding actual fallback.
 */
export function getTeslaRecentDrawDigit(
  profile: UserProfile,
  date: string,
  index: number,
  marketName: string,
  record?: DayMarketRecord,
): { digit?: string; sourceDesc?: string; refJodi?: string; session: 'OPEN' | 'CLOSE' } {
  const isClose = /\s+CLOSE$/i.test(marketName);
  const session: 'OPEN' | 'CLOSE' = isClose ? 'CLOSE' : 'OPEN';
  const baseMarket = String(marketName || '').replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();

  // 1. Search backwards across settled dates for this base market
  const sortedDates = Object.keys(profile.dayRecords || {})
    .filter(d => dateValid(d) && d <= date)
    .sort((a, b) => b.localeCompare(a));

  for (const d of sortedDates) {
    const day = profile.dayRecords[d];
    if (!day) continue;

    // A. Check jodiData for explicit 2-digit Jodi (e.g. "24")
    if (day.jodiData) {
      for (const [idxStr, jRec] of Object.entries(day.jodiData)) {
        if (d === date && Number(idxStr) >= index) continue;
        const jName = String(jRec?.marketName || '').replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
        if (baseMarket && jName && jName !== baseMarket) continue;

        const candJodi = jRec?.manualResult || jRec?.scrapeResultDigit || (jRec?.backtestResult as any)?.actual?.jodi || (jRec?.backtestResult as any)?.actual;
        const jodiDigits = String(candJodi || '').replace(/\D/g, '');
        if (jodiDigits.length >= 2) {
          const o = jodiDigits[0];
          const c = jodiDigits[1];
          const chosen = session === 'OPEN' ? o : c;
          return {
            digit: chosen,
            sourceDesc: `${d} Jodi ${jodiDigits.slice(0, 2)} (${session}: ${chosen})`,
            refJodi: jodiDigits.slice(0, 2),
            session,
          };
        }
      }
    }

    // B. Check ANK records (data)
    if (day.data) {
      const ankMarkets = getEffectiveMarkets(profile.config);
      const openName = `${baseMarket} OPEN`;
      const closeName = `${baseMarket} CLOSE`;

      let openDigit: string | undefined;
      let closeDigit: string | undefined;

      for (const [idxStr, aRec] of Object.entries(day.data)) {
        const i = Number(idxStr);
        if (d === date && i >= index) continue;
        const name = (aRec?.marketName || ankMarkets[i]?.n || '').trim().toUpperCase();
        if (name === openName) {
          const act = confirmedAnkResult(aRec) || (aRec?.manualStatus ? aRec.manualResult : aRec?.scrapeResultDigit || (aRec?.backtestResult as any)?.actual?.open || (aRec?.backtestResult as any)?.actual);
          if (act !== undefined && /^\d$/.test(String(act))) {
            openDigit = String(act);
          }
        } else if (name === closeName) {
          const act = confirmedAnkResult(aRec) || (aRec?.manualStatus ? aRec.manualResult : aRec?.scrapeResultDigit || (aRec?.backtestResult as any)?.actual?.close || (aRec?.backtestResult as any)?.actual);
          if (act !== undefined && /^\d$/.test(String(act))) {
            closeDigit = String(act);
          }
        }
      }

      const chosen = session === 'OPEN' ? openDigit : closeDigit;
      if (chosen !== undefined) {
        return {
          digit: chosen,
          sourceDesc: `${d} ${session} result (${chosen})`,
          refJodi: openDigit && closeDigit ? `${openDigit}${closeDigit}` : undefined,
          session,
        };
      }
    }
  }

  // 2. Check reference Jodi helper from lifetimeJodiFormula
  try {
    const ref = findReferenceJodiForMarket({
      profile,
      currentDate: date,
      baseMarketName: baseMarket,
      fallbackIndex: index,
    });
    if (ref && /^\d{2}$/.test(ref.refJodi)) {
      const chosen = session === 'OPEN' ? ref.refJodi[0] : ref.refJodi[1];
      return {
        digit: chosen,
        sourceDesc: `${ref.sourceDesc} (${ref.refJodi})`,
        refJodi: ref.refJodi,
        session,
      };
    }
  } catch {}

  // 3. Check settled history for this base market
  try {
    const hist = collectMarketSettledHistory(profile, date, marketName, index, 10);
    const targetSuffix = session === 'OPEN' ? 'OPEN' : 'CLOSE';
    const match = [...hist].reverse().find(h => new RegExp(`\\s+${targetSuffix}$`, 'i').test(h.marketName));
    if (match?.actual && /^\d$/.test(match.actual)) {
      return {
        digit: match.actual,
        sourceDesc: `${match.date} ${session} history (${match.actual})`,
        session,
      };
    }
  } catch {}

  // 4. Fallback to generic preceding actual
  const fallback = getPrecedingMarketActual(profile, date, index, marketName, record);
  if (fallback && /^\d$/.test(fallback)) {
    return {
      digit: fallback,
      sourceDesc: `Preceding actual (${fallback})`,
      session,
    };
  }

  return { session };
}

/**
 * Nikola Tesla 3-6-9 Delta Jump & Trinity Harmonics Engine:
 * - Takes recent draw digit (A):
 *   OPEN uses recent draw's OPEN digit (e.g. Jodi 24 -> 2)
 *   CLOSE uses recent draw's CLOSE digit (e.g. Jodi 24 -> 4)
 * - Jumps: (A + 3) mod 10, (A + 6) mod 10, (A + 9) mod 10.
 *   e.g. Open 2 -> 2+3=5, 2+6=8, 2+9=1 => [5, 8, 1]
 *   e.g. Close 4 -> 4+3=7, 4+6=0, 4+9=3 => [7, 0, 3]
 * - Returns exactly 3 Ank.
 */
export function applyTesla369Formula(
  rawInput?: string,
  lastActual?: string,
  session: 'OPEN' | 'CLOSE' = 'OPEN',
): { formatted: string; details: Omit<Tesla369Details, 'outputVersion'> } | null {
  let triad: string[];
  let mirrors: string[];
  let summary: string;

  if (lastActual !== undefined && /^\d$/.test(String(lastActual).trim())) {
    const act = Number(lastActual);
    const j3 = String((act + 3) % 10);
    const j6 = String((act + 6) % 10);
    const j9 = String((act + 9) % 10);
    triad = [j3, j6, j9];

    const m3 = String((act + 8) % 10);
    const m6 = String((act + 1) % 10);
    const m9 = String((act + 4) % 10);
    mirrors = [m3, m6, m9];

    summary = `⚡ 3-6-9 Jump [${triad.join(', ')}] (Recent ${session} ${act}: +3, +6, +9)`;
  } else {
    // Fallback to Universal Tesla Trinity Core: {3, 6, 9}
    triad = ['3', '6', '9'];
    mirrors = ['8', '1', '4'];
    summary = `⚡ 3-6-9 Universal Tesla Core [3, 6, 9]`;
  }

  const output = triad.join(', ');
  const inputStr = rawInput && rawInput.trim() ? rawInput.trim() : output;

  return {
    formatted: output,
    details: {
      actual: lastActual !== undefined && /^\d$/.test(String(lastActual).trim()) ? String(lastActual).trim() : undefined,
      triad,
      mirrors,
      selectedDigits: triad,
      input: inputStr,
      output,
      summary,
    },
  };
}

/**
 * Apply Tesla 3-6-9 filter to an individual DayMarketRecord.
 */
export function applyTesla369(
  record: DayMarketRecord | undefined,
  profile: UserProfile,
  date: string,
  index: number,
  marketName?: string,
): DayMarketRecord | undefined {
  const mName = marketName || record?.marketName || '';
  const existing: DayMarketRecord = record || { s: 'WAIT', d: '', r: '', marketName: mName };
  if (existing.s !== 'WAIT' || existing.manualStatus || existing.deliveryRestoredAt || existing.dispatchState || isMirrorProtected(existing) || !canReplaceLiveCombinedDecision(existing)) {
    return undefined;
  }

  const source = getScrapeSource(existing);
  const raw = String(existing.od || source?.digits || existing.d || '').trim();

  const recentDraw = getTeslaRecentDrawDigit(profile, date, index, mName, existing);
  const result = applyTesla369Formula(raw, recentDraw.digit, recentDraw.session);
  if (!result) return undefined;

  const version = Math.max(Date.now(), modelSourceVersion(existing) + 1);
  const next: DayMarketRecord = {
    ...existing,
    marketName: mName,
    d: result.formatted,
    od: existing.od || source?.digits || (raw && raw !== result.formatted ? raw : result.formatted),
    positionRule: 'TESLA_369',
    tesla369: {
      ...result.details,
      outputVersion: version,
    },
    sourceEditedAt: version,
  };

  releaseLiveCombinedDecision(next);
  delete next.trick;
  delete next.triCut;
  delete next.sniperOne;
  delete next.firstDigitMirrorCut;
  delete next.weekdaySelectedDigits;
  delete next.weekdayHitPosition;
  delete next.scrapeResultDigit;
  delete next.manualResult;
  delete next.manualResultSources;
  delete next.backtestResult;
  delete next.marketModel;
  delete next.autoRemovedResult;
  delete next.autoResultParity;
  delete next.smartSelection;

  if (!next.manualRate) {
    delete next.recRate;
    delete next.prevLoss;
    delete next.targetProfitWithLoss;
    delete next.rateFinalizedFrom;
    delete next.rateFinalizedAt;
  }

  return next;
}
