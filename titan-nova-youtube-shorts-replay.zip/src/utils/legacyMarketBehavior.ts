/** Market-specific ANK ensemble. Inputs are dated observations, oldest first. */
export type BehaviorSide = 'open' | 'close';
export interface BehaviorDraw { date: string; jodi: string }
export type BehaviorExpert = 'frequency_30' | 'frequency_90' | 'frequency_240' | 'decay_15' | 'decay_45' | 'weekday';
const EXPERTS: BehaviorExpert[] = ['frequency_30', 'frequency_90', 'frequency_240', 'decay_15', 'decay_45', 'weekday'];
const DIGITS = Array.from({ length: 10 }, (_, index) => String(index));
const MIN_HISTORY = 30;
const MAX_HISTORY = 600;
const PRIOR_MASS = 10;
const LEARNING_RATE = 1;
const DISCOUNT = 0.985;
interface Observation { date: string; digit: string; weekday: number }
export interface MarketBehaviorPrediction {
  engine: 'market_behavior_v1';
  market: string;
  side: BehaviorSide;
  targetDate: string;
  historySize: number;
  lastTrainingDate: string;
  digits: string[];
  eliminatedDigits: string[];
  sourceDigits: string[];
  selection: {
    method: 'retain_top_6_eliminate_bottom_4';
    boundaryProbabilityGap: number;
    retainedProbabilityMass: number;
    targetPassingPercent: 90;
    targetSupportedInPastSample: boolean;
  };
  freshness: { lastTrainingDate: string; calendarGapDays: number; status: 'recent' | 'check_latest_result' };
  probabilities: Record<string, number>;
  confidence: 'insufficient' | 'low' | 'medium' | 'high';
  evidence: 'unproven' | 'above_uniform_baseline';
  experts: Array<{ method: BehaviorExpert; weight: number; samples: number }>;
  behavior: { recentFrequencyShift: number; dominantExpert: BehaviorExpert };
  evaluation: {
    samples: number; hits: number; hitPercent: number; randomBaselinePercent: 60;
    frequencyHitPercent: number; brierScore: number | null;
    uniformBrierScore: number | null; frequencyBrierScore: number | null;
    maxMissStreak: number; lowerHitBound: number | null;
    recent30HitPercent: number | null; recent60HitPercent: number | null;
    setComparisons: number; setChanges: number; setChangePercent: number;
    maxSameSetStreak: number;
    scope: 'past_only_online_walk_forward';
  };
}
const isDate = (value: string) => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
};
const weekday = (date: string) => new Date(`${date}T00:00:00Z`).getUTCDay();
const round = (value: number) => Number(value.toFixed(6));
function distribution(history: Observation[], expert: BehaviorExpert, targetDay: number) {
  let observations = history;
  if (expert.startsWith('frequency_')) observations = history.slice(-Number(expert.split('_')[1]));
  if (expert === 'weekday') observations = history.filter(row => row.weekday === targetDay).slice(-60);
  // An under-supported weekday expert supplies no independent evidence.
  const active = expert !== 'weekday' || observations.length >= 12;
  if (!active) observations = history.slice(-90);
  const counts = Array<number>(10).fill(PRIOR_MASS / 10);
  let mass = PRIOR_MASS;
  const halfLife = expert.startsWith('decay_') ? Number(expert.split('_')[1]) : 0;
  observations.forEach((row, index) => {
    const weight = halfLife ? Math.pow(0.5, (observations.length - index - 1) / halfLife) : 1;
    counts[Number(row.digit)] += weight;
    mass += weight;
  });
  return { probabilities: counts.map(count => count / mass), samples: observations.length, active };
}
function weights(losses: number[], active: boolean[]) {
  const available = losses.filter((_, index) => active[index]);
  const best = Math.min(...available);
  const scores = losses.map((loss, index) => active[index] ? Math.exp(-LEARNING_RATE * (loss - best)) : 0);
  const total = scores.reduce((sum, value) => sum + value, 0);
  // A modest uniform expert prior limits abrupt switches after lucky streaks.
  const count = available.length;
  return scores.map((score, index) => active[index] ? 0.9 * score / total + 0.1 / count : 0);
}
function rank(probabilities: number[]) {
  return [...DIGITS].sort((a, b) => probabilities[Number(b)] - probabilities[Number(a)] || a.localeCompare(b)).slice(0, 6);
}
const brier = (probabilities: number[], actual: string) => probabilities.reduce((sum, p, index) => sum + Math.pow(p - (index === Number(actual) ? 1 : 0), 2), 0);
function lowerWilson(hits: number, samples: number) {
  if (!samples) return null;
  const p = hits / samples, z = 1.96, z2 = z * z;
  return (p + z2 / (2 * samples) - z * Math.sqrt(p * (1 - p) / samples + z2 / (4 * samples * samples))) / (1 + z2 / samples);
}
/**
 * Never learns from the target date or a future result. Conflicting duplicates
 * are excluded, not silently chosen. Each call trains only this market/side.
 * Evaluation predicts first, then observes the outcome and updates weights.
 */
export function buildMarketBehaviorPrediction(
  draws: BehaviorDraw[], market: string, side: BehaviorSide, targetDate: string,
): MarketBehaviorPrediction | null {
  if (!isDate(targetDate)) return null;
  const byDate = new Map<string, Set<string>>();
  for (const draw of draws) {
    if (!isDate(draw.date) || draw.date >= targetDate || !/^\d{2}$/.test(draw.jodi)) continue;
    if (!byDate.has(draw.date)) byDate.set(draw.date, new Set());
    byDate.get(draw.date)!.add(draw.jodi);
  }
  const sideIndex = side === 'open' ? 0 : 1;
  const history: Observation[] = [...byDate].filter(([, pairs]) => pairs.size === 1)
    .sort(([a], [b]) => a.localeCompare(b)).slice(-MAX_HISTORY)
    .map(([date, pairs]) => ({ date, digit: [...pairs][0][sideIndex], weekday: weekday(date) }));
  if (history.length < MIN_HISTORY) return null;
  const losses = EXPERTS.map(() => 0);
  const evaluation: Array<{ hit: boolean; frequencyHit: boolean; loss: number; frequencyLoss: number; set: string }> = [];
  for (let index = MIN_HISTORY; index < history.length; index++) {
    const prior = history.slice(0, index);
    const actual = history[index];
    const experts = EXPERTS.map(expert => distribution(prior, expert, actual.weekday));
    const mixWeights = weights(losses, experts.map(expert => expert.active));
    const prediction = DIGITS.map((_, digit) => experts.reduce((sum, expert, i) => sum + mixWeights[i] * expert.probabilities[digit], 0));
    const frequency = distribution(prior, 'frequency_90', actual.weekday).probabilities;
    const selected = rank(prediction);
    evaluation.push({ hit: selected.includes(actual.digit), frequencyHit: rank(frequency).includes(actual.digit), loss: brier(prediction, actual.digit), frequencyLoss: brier(frequency, actual.digit), set: [...selected].sort().join('') });
    experts.forEach((expert, i) => {
      const logLoss = -Math.log(Math.max(1e-9, expert.probabilities[Number(actual.digit)]));
      losses[i] = DISCOUNT * losses[i] + (expert.active ? logLoss : -Math.log(0.1));
    });
  }
  const experts = EXPERTS.map(expert => distribution(history, expert, weekday(targetDate)));
  const mixWeights = weights(losses, experts.map(expert => expert.active));
  const probabilities = DIGITS.map((_, digit) => experts.reduce((sum, expert, i) => sum + mixWeights[i] * expert.probabilities[digit], 0));
  const recentEvaluation = evaluation.slice(-120);
  const samples = recentEvaluation.length;
  const hits = recentEvaluation.filter(row => row.hit).length;
  const mean = (field: 'loss' | 'frequencyLoss') => samples ? recentEvaluation.reduce((sum, row) => sum + row[field], 0) / samples : null;
  const lower = lowerWilson(hits, samples);
  const evidence = samples >= 100 && lower !== null && lower > 0.6 && (mean('loss') ?? 1) < 0.9;
  let missStreak = 0, maxMissStreak = 0;
  recentEvaluation.forEach(row => { missStreak = row.hit ? 0 : missStreak + 1; maxMissStreak = Math.max(maxMissStreak, missStreak); });
  let setChanges = 0, sameSetStreak = 0, maxSameSetStreak = 0;
  recentEvaluation.forEach((row, index) => {
    const same = index > 0 && row.set === recentEvaluation[index - 1].set;
    if (index > 0 && !same) setChanges++;
    sameSetStreak = same ? sameSetStreak + 1 : 1;
    maxSameSetStreak = Math.max(maxSameSetStreak, sameSetStreak);
  });
  const setComparisons = Math.max(0, samples - 1);
  const recentHit = (count: number) => samples >= count
    ? round(100 * recentEvaluation.slice(-count).filter(row => row.hit).length / count) : null;
  const selectedDigits = rank(probabilities);
  const excludedDigits = DIGITS.filter(digit => !selectedDigits.includes(digit))
    .sort((a, b) => probabilities[Number(a)] - probabilities[Number(b)] || a.localeCompare(b));
  const lastTrainingDate = history.at(-1)!.date;
  const calendarGapDays = Math.round((Date.parse(targetDate + 'T00:00:00Z') - Date.parse(lastTrainingDate + 'T00:00:00Z')) / 86400000);
  const recent = distribution(history, 'frequency_30', weekday(targetDate)).probabilities;
  const older = distribution(history.slice(0, -30), 'frequency_90', weekday(targetDate)).probabilities;
  const dominant = EXPERTS.reduce((best, method, index) => mixWeights[index] > mixWeights[EXPERTS.indexOf(best)] ? method : best, EXPERTS[0]);
  return {
    engine: 'market_behavior_v1', market: market.trim().toUpperCase(), side, targetDate,
    historySize: history.length, lastTrainingDate,
    sourceDigits: [...DIGITS].sort((a, b) => probabilities[Number(b)] - probabilities[Number(a)] || a.localeCompare(b)),
    digits: selectedDigits, eliminatedDigits: excludedDigits,
    selection: { method: 'retain_top_6_eliminate_bottom_4',
      boundaryProbabilityGap: round(probabilities[Number(selectedDigits.at(-1)!)] - probabilities[Number(excludedDigits.at(-1)!)]),
      retainedProbabilityMass: round(selectedDigits.reduce((sum, digit) => sum + probabilities[Number(digit)], 0)),
      targetPassingPercent: 90, targetSupportedInPastSample: samples >= 100 && lower !== null && lower > 0.9 && evidence },
    freshness: { lastTrainingDate, calendarGapDays, status: calendarGapDays > 3 ? 'check_latest_result' : 'recent' },
    probabilities: Object.fromEntries(DIGITS.map((digit, index) => [digit, round(probabilities[index])])),
    confidence: samples < 50 ? 'insufficient' : evidence ? (lower! > 0.7 ? 'high' : 'medium') : 'low',
    evidence: evidence ? 'above_uniform_baseline' : 'unproven',
    experts: EXPERTS.map((method, index) => ({ method, weight: round(mixWeights[index]), samples: experts[index].active ? experts[index].samples : 0 })),
    behavior: { recentFrequencyShift: round(recent.reduce((sum, p, digit) => sum + Math.abs(p - older[digit]), 0) / 2), dominantExpert: dominant },
    evaluation: { samples, hits, hitPercent: samples ? round(100 * hits / samples) : 0, randomBaselinePercent: 60,
      frequencyHitPercent: samples ? round(100 * recentEvaluation.filter(row => row.frequencyHit).length / samples) : 0,
      brierScore: mean('loss') === null ? null : round(mean('loss')!), uniformBrierScore: samples ? 0.9 : null,
      frequencyBrierScore: mean('frequencyLoss') === null ? null : round(mean('frequencyLoss')!),
      maxMissStreak, lowerHitBound: lower === null ? null : round(lower),
      recent30HitPercent: recentHit(30), recent60HitPercent: recentHit(60),
      setComparisons, setChanges, setChangePercent: setComparisons ? round(100 * setChanges / setComparisons) : 0,
      maxSameSetStreak, scope: 'past_only_online_walk_forward' },
  };
}
