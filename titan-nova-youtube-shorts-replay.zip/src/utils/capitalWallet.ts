import type { DayMarketRecord, GameType } from '../types';
import { calculateSettlement } from './settlement';

/** Replay actual stakes and payouts. Only a cash shortfall adds own capital.
 * Old records without timestamps fall back to their saved market order.
 * Pending stakes are assets, never profit or a second capital contribution.
 */
export function calculateCapitalWallet(type: GameType, cards: Record<string, DayMarketRecord>, includeBacktests = false) {
  const events: Array<{ at: number; order: number; cash: number }> = [];
  let pending = 0, turnover = 0;
  const entries = Object.entries(cards);
  entries.forEach(([, card], index) => {
    if (!card || card.s === 'SKIP') return;
    const settled = card.s === 'PASS' || card.s === 'FAIL';
    const delivered = Boolean(card.sentRate || card.sentDigits || card.dispatchState === 'SENT' || card.dispatchState === 'SETTLED');
    if (!settled && !delivered) return;
    if (card.backtestResult && !delivered && !includeBacktests) return;
    const winDigit = card.manualResult || card.scrapeResultDigit || card.backtestResult?.actual?.open || card.backtestResult?.actual?.close;
    const value = calculateSettlement({ type, digits: card.sentAt ? (card.sentDigits || card.d) : card.d, rate: card.r || card.recRate, sentRate: card.sentAt ? card.sentRate : undefined, sentInvest: card.sentAt ? card.sentInvest : undefined, smartStaking: card.smartStaking, winningDigit: winDigit });
    if (value.invest <= 0) return;
    const fallback = (index - entries.length) * 2;
    const sentAt = Number(card.sentAt) || Number(card.settledAt) || fallback;
    events.push({ at: sentAt, order: index * 2, cash: -value.invest });
    turnover += value.invest;
    if (settled) {
      const settledAt = Math.max(sentAt, Number(card.settledAt) || sentAt);
      events.push({ at: settledAt, order: index * 2 + 1, cash: card.s === 'PASS' ? value.payout : 0 });
    } else pending += value.invest;
  });
  events.sort((a, b) => a.at - b.at || a.order - b.order);
  let invested = 0, balance = 0;
  for (const event of events) {
    if (event.cash < 0 && balance + event.cash < 0) {
      const shortfall = -(balance + event.cash);
      invested += shortfall;
      balance += shortfall;
    }
    balance += event.cash;
  }
  return { invested, balance, pending, turnover };
}
