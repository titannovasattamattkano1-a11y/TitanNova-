/** Compare human edit inputs separately from backend calculations. This module
 * does not calculate settlements or authorize changes to committed plays. */
const plain=(v:any):v is Record<string,any>=>v!==null&&typeof v==='object'&&!Array.isArray(v);
type Equal=(a:any,b:any)=>boolean;
const derived=new Set([
 'sourceEditedAt','manualOverrideAt','recRate','prevLoss','targetProfitWithLoss','rateFinalizedAt','rateFinalizedFrom',
 'loopId','twoCardRecoveryShares','twoCardRecoveryStrategy','loopAccountSkipped','loopAccountReason','loopAccountReservation',
 'vipAutoStopSkipped','vipAutoStopResumeEligible','closeZeroAutoSkipped','backtestResult','scrapeResultDigit','weekdayHitPosition',
 'autoResultParity','autoRemovedResult','openCloseCut','carryResultSix','marketModel','strictPanel30','smartSelection','mssdState','masterFlow','smartStaking',
 'liveCombinedCut','backtestCombinedCut','backtestCombinedKeep','backtestSkipHistory','backtestRecoveryReset',
 'backtestStakeLimitSkipped','backtestDailyStopLossSkipped','backtestDailyStopLossSourceSkipped',
 'backtestDailyProfitSkipped','backtestDailyProfitSourceSkipped','bulkBacktestJobId','bulkBacktestVersion',
 'dispatchState','dispatchKey','queuedAt','settledAt','jodiOpenStatus','jodiOpenResult','jodiOpenSettledAt',
 'deliveryMissedAt','deliveryMissedReason','deliveryPartial',
]);
const sourceKeys=['d','od','sourceMode','scrapeSource','trick','positionRule','weekdaySelectedDigits','weekdayHitPosition',
 'firstDigitMirrorCut','tesla369','triCut','sniperOne','mssdState','masterFlow','marketModel','strictPanel30','smartSelection','autoResultParity','autoRemovedResult','carryResultSix',
 'liveCombinedCut','sourceEditedAt'] as const;
const version=(r:any)=>Math.max(Number(r?.sourceEditedAt||0),Number(r?.marketModel?.updatedAt||0));
const tokens=(v:any)=>typeof v==='string'?v.split(/[,|\s]+/).filter(Boolean).join(', '):v;
export function hasAutomaticRate(...records:any[]):boolean{return records.some(r=>r&&(r.recRate!==undefined||r.rateFinalizedAt||r.backtestResult));}
export function adminCardIntent(record:any,automaticRate=false):any {
 if(!plain(record))return record;
 let input={...record},trusted=false;
 for(const field of ['openCloseCut','carryResultSix'] as const){
  const overlay=input[field];
  if(!overlay?.input||input.d!==overlay.output||(!trusted&&overlay.outputVersion!==undefined&&overlay.outputVersion!==version(input)))continue;
  const next={...input};for(const key of sourceKeys)delete next[key];
  for(const key of sourceKeys)if(overlay.input[key]!==undefined)next[key]=overlay.input[key];
  delete next[field];input=next;trusted=true;
 }
 const removal=input.autoRemovedResult;
 const removalActive=Boolean(removal&&input.d===removal.output&&(trusted||removal.outputVersion===undefined||removal.outputVersion===version(input)));
 if(removalActive)input.d=removal.input;
 const cut=input.autoResultParity;
 if(cut&&input.d===cut.output&&(trusted||cut.outputVersion===version(input)||removalActive&&removal.input===cut.output)){
  input.d=cut.input;input.trick=cut.inputTrick;
  if(cut.rule==='OPEN_LOOP_CUT')input.positionRule=cut.inputPositionRule;
 }
 const result:any=Object.create(null);
 for(const [key,value]of Object.entries(input)){
  if(value===undefined||derived.has(key)||key.startsWith('sent'))continue;
  if(key==='s'&&input.manualStatus!==true)continue;
  if((key==='manualStatus'||key==='manualRate')&&value!==true)continue;
  if(key==='r'&&automaticRate&&input.manualRate!==true)continue;
  if(['d','od','weekdaySelectedDigits'].includes(key))result[key]=tokens(value);
  else if(key==='scrapeSource'&&plain(value))result[key]={...value,digits:tokens(value.digits)};
  else if(key==='r'&&String(value).trim()&&Number.isFinite(Number(value)))result[key]=Number(value);
  else result[key]=value;
 }
 return result;
}
function committed(r:any){return Boolean(r?.sentRate||r?.sentDigits||r?.sentAt||r?.dispatchState||r?.loopAccountReservation||
 (['PASS','FAIL'].includes(r?.s)&&(r?.manualStatus||!r?.backtestResult)));}
export type ConflictMerge={kind:'keep'}|{kind:'set';value:any}|{kind:'conflict'};
export function mergeCardConflict(before:any,current:any,desired:any,equal:Equal):ConflictMerge {
 if(!plain(before)||!plain(current)||!plain(desired))return {kind:'conflict'};
 // If desired is an explicit card clear (d === '' && sourceMode === 'MANUAL'), accept it unless current is already cleared at a newer timestamp
 if(String(desired.d||'').trim()===''&&desired.sourceMode==='MANUAL'&&!committed(current)){
  return {kind:'set',value:{...desired,cardGeneration:Math.max(Number(current.cardGeneration||0),Number(desired.cardGeneration||0))||undefined,sourceEditedAt:Math.max(Number(desired.sourceEditedAt||0),version(current)+1)}};
 }
 // If current was explicitly cleared on server (via /api/bot/ledger_set_card or /api/bot/ledger_clear_cards)
 // and desired is a stale pre-clear snapshot (same d as before), keep the server's cleared card instead of throwing conflict!
 if(String(current.d||'').trim()===''&&current.sourceMode==='MANUAL'&&Number(current.sourceEditedAt||0)>Number(before.sourceEditedAt||0)&&Number(desired.sourceEditedAt||0)<=Number(current.sourceEditedAt||0)){
  if(tokens(desired.d)===tokens(before.d))return {kind:'keep'};
 }
 const automatic=hasAutomaticRate(before,current,desired),base=adminCardIntent(before,automatic),remote=adminCardIntent(current,automatic),local=adminCardIntent(desired,automatic);
 if(equal(base,local)||equal(remote,local))return {kind:'keep'};
 if(committed(current)){
  return {kind:'keep'};
 }
 // Only schedules changed: retain the current backend selection and rates.
 const strip=(r:any)=>Object.fromEntries(Object.entries(r).filter(([key])=>!['schTime','schTargets'].includes(key)));
 if(equal(strip(base),strip(local))){
  const next={...current};for(const key of ['schTime','schTargets'])if(!equal(before[key],desired[key])){if(desired[key]===undefined)delete next[key];else next[key]=desired[key];}
  return {kind:'set',value:next};
 }
 // Retain the explicit Admin source/trick/scrape edit atomically and let the backend calculator rebuild rates.
 const next:Record<string,any>={
  ...desired,
  cardGeneration:Math.max(Number(current.cardGeneration||0),Number(desired.cardGeneration||0))||undefined,
  sourceEditedAt:Math.max(Number(desired.sourceEditedAt||0),version(current)+1),
 };
 if(automatic){
  for(const key of ['recRate','prevLoss','targetProfitWithLoss','rateFinalizedAt','rateFinalizedFrom','twoCardRecoveryShares','twoCardRecoveryStrategy'])delete next[key];
  if(!desired.manualRate)next.r='';
 }
 return {kind:'set',value:next};
}
/** Different top-level settings merge; dependent objects such as ANK limits or
 * a custom loop setup stay indivisible when two writers edit that same object. */
export function mergeConfigConflict(before:any,current:any,desired:any,equal:Equal):ConflictMerge {
 if(!plain(before)||!plain(current)||!plain(desired))return {kind:'conflict'};
 const next={...current};
 for(const key of new Set([...Object.keys(before),...Object.keys(desired)])){
  if(equal(before[key],desired[key]))continue;
  if(desired[key]===undefined)delete next[key];else Object.defineProperty(next,key,{value:desired[key],writable:true,enumerable:true,configurable:true});
 }
 return equal(next,current)?{kind:'keep'}:{kind:'set',value:next};
}
