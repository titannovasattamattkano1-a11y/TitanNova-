/**
 * Select the first unique single digits from a chart stream that is already
 * ordered newest/recent first. No ranking, sorting, padding, or deduplication
 * beyond first-seen uniqueness is applied.
 */
export function selectRecentUniqueDigits(values: unknown[], limit = 10): string[] {
  const seen = new Set<string>();
  const result: string[] = [];
  const max = Math.max(0, Math.min(10, Math.floor(limit)));

  for (const value of values) {
    const digit = String(value ?? '').trim();
    if (!/^\d$/.test(digit) || seen.has(digit)) continue;
    seen.add(digit);
    result.push(digit);
    if (result.length >= max) break;
  }

  return result;
}

/**
 * Historical backtest source for normal Recent→Old / Combo ANK scraping.
 * Returns only completed rows strictly before targetDate, newest first.
 * This keeps the selected date and all future results out of the prediction.
 */
export function selectPreTargetRecentJodis(
  draws: Array<{ date?: unknown; jodi?: unknown; order?: unknown }>,
  targetDate: string,
): string[] {
  const target = String(targetDate || '').trim();
  const parsed = new Date(`${target}T00:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(target) || Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== target) {
    return [];
  }

  return draws
    .map((draw) => ({
      date: String(draw?.date || '').trim(),
      jodi: String(draw?.jodi || '').trim(),
      order: Number(draw?.order || 0),
    }))
    .filter((draw) => /^\d{4}-\d{2}-\d{2}$/.test(draw.date) && /^\d{2}$/.test(draw.jodi) && draw.date < target)
    .sort((a, b) => b.date.localeCompare(a.date) || b.order - a.order)
    .map((draw) => draw.jodi);
}

