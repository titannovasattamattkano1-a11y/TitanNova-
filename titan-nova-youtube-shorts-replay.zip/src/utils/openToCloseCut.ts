import {businessDateIST} from './businessDate';
import {evaluateBacktest} from './backtestResult';
import type {DayMarketRecord,UserProfile} from '../types';
import {getEffectiveMarkets} from '../data/markets';
import {isMarketEnabledForDate} from './profileMarketToggle';
import {confirmedAnkResult} from './autoRemoveResult';
import {isBacktestSelectionHeld} from './backtestSelectionHold';
import {cutCurrentSourceDigits} from './cumulativeSourceCut';
import {modelSourceVersion} from './marketModelCard';
import {getScrapeSource} from './scrapeProvenance';
const inputKeys=['d','od','sourceMode','scrapeSource','trick','positionRule','marketModel','strictPanel30','autoRemovedResult','autoResultParity','firstDigitMirrorCut','triCut','sniperOne','liveCombinedCut','carryResultSix','weekdaySelectedDigits','weekdayHitPosition','sourceEditedAt'] as const;
const protectedCard=(r:DayMarketRecord)=>Boolean(r.sentDigits||r.sentRate||r.dispatchState||r.manualStatus||r.deliveryRestoredAt||((r.s==='PASS'||r.s==='FAIL')&&!r.backtestResult));
/** Peel only our still-current layer; a later scrape/manual selection wins. */
export function restoreOpenCloseInput(record:DayMarketRecord,edited=false):DayMarketRecord {
 const old=record.openCloseCut;if(!old||protectedCard(record))return record;
 if(record.d!==old.output||modelSourceVersion(record)!==old.outputVersion){const next={...record};delete next.openCloseCut;return next;}
 let next={...record};
 for(const key of inputKeys)delete (next as any)[key];
 Object.assign(next,old.input);delete next.openCloseCut;
 if(edited){
  next.sourceEditedAt=Math.max(Date.now(),modelSourceVersion(record)+1);
  for(const key of ['autoRemovedResult','autoResultParity','firstDigitMirrorCut','triCut','sniperOne','carryResultSix'] as const)if(next[key])(next as any)[key]={...next[key],outputVersion:next.sourceEditedAt};
  delete next.backtestSelectionHold;
 }
 if(record.backtestResult){const trial=record.backtestResult;next.s='WAIT';delete next.backtestResult;next=next.d?evaluateBacktest(next,'ank',trial.actual):{...next,backtestResult:{...trial,digits:next.d}};}
 delete next.rateFinalizedAt;delete next.rateFinalizedFrom;
 if(!next.manualRate){delete next.recRate;delete next.prevLoss;delete next.targetProfitWithLoss;}
 return next;
}
const name=(s:string)=>s.trim().toUpperCase().replace(/\s+/g,' ');
/** Exact same-market OPEN actual only; never another track, another date or a predicted digit. */
export function sameMarketOpenActual(markets:Array<{n:string;index:number}>,cards:Record<string,DayMarketRecord>,closeName:string):string|undefined{
 const close=name(closeName);if(!/ CLOSE$/.test(close))return;
 const open=close.replace(/ CLOSE$/,' OPEN'),matches=markets.filter(m=>name(m.n)===open);
 if(matches.length!==1)return;
 const record=cards[String(matches[0].index)];
 if(record?.marketName&&name(record.marketName)!==open)return;
 return confirmedAnkResult(record);
}
export function cutOpenActual(record:DayMarketRecord|undefined,actual:string|undefined,date?:string):DayMarketRecord|undefined{
 if(!record||!/^\d$/.test(actual||''))return record;
 const trial=record.backtestResult;
 const parsedDate=date?new Date(`${date}T00:00:00Z`):undefined;
 const pastTrial=Boolean(date&&/^\d{4}-\d{2}-\d{2}$/.test(date)&&parsedDate&&Number.isFinite(parsedDate.getTime())&&parsedDate.toISOString().slice(0,10)===date&&date<businessDateIST()&&
   (record.s==='PASS'||record.s==='FAIL')&&trial?.checked&&trial.digits===record.d&&/^\d$/.test(trial.actual||'')&&!record.manualStatus);
 if(record.s!=='WAIT'&&!pastTrial)return record;
 const input=restoreOpenCloseInput(record);
 let next=cutCurrentSourceDigits(input,[actual!]);
 if(!next||next===record)return record;
 if(next===input)return record;
  // This is an additional result filter on the O/D selection, not a new cut
  // decision. Its settled result must retain the loop's requested side.
  if(input.autoResultParity?.rule==='OPEN_LOOP_CUT'){
    next.autoResultParity=input.autoResultParity;next.positionRule=input.positionRule;
  }
 next={...next,openCloseCut:{input:Object.fromEntries(inputKeys.filter(k=>input[k]!==undefined).map(k=>[k,input[k]])),output:next.d,outputVersion:modelSourceVersion(next),actual:actual!}};
 if(record.openCloseCut&&record.d===next.d&&record.openCloseCut.actual===actual&&JSON.stringify(record.openCloseCut.input)===JSON.stringify(next.openCloseCut!.input))return record;
 // Simulated results are editable on a past date; delivered/manual results remain protected by the shared cut guard.
 if(pastTrial&&trial){
   const updatedAt=Math.max(Date.now(),Number(trial.updatedAt||0)+1);
   if(next.d)return evaluateBacktest({...next,backtestResult:{...trial,updatedAt}},'ank',trial.actual);
   return {...next,backtestResult:{...trial,digits:next.d,updatedAt}};
 }
 return next;
}
export function applyOpenToCloseCut(profile:UserProfile,date:string):UserProfile{
 const day=profile.dayRecords[date];if(day?.openToCloseCut!==true)return profile;
 const markets=getEffectiveMarkets(profile.config).map((m,index)=>({...m,index})),data=day.data||{};
 let nextData=data;
 for(const market of markets){
  if(!/ CLOSE$/.test(name(market.n))||!isMarketEnabledForDate(profile.config,day.visAnk,market.n,date))continue;
  const record=data[market.index];if(!record||isBacktestSelectionHeld(record,date)||(record.marketName&&name(record.marketName)!==name(market.n)))continue;
  const next=cutOpenActual(record,sameMarketOpenActual(markets,data,market.n),date);
  if(next!==record){if(nextData===data)nextData={...data};nextData[market.index]=next!;}
 }
 return nextData===data?profile:{...profile,dayRecords:{...profile.dayRecords,[date]:{...day,data:nextData}}};
}
export function toggleOpenToCloseCut(profile:UserProfile,date:string):UserProfile{
 const day=profile.dayRecords[date]||{},enabled=day.openToCloseCut!==true;
 let data=day.data;
 // An explicit ON is a new selection action; release only this date's CLOSE Undo holds.
 if(enabled&&data){
  const markets=getEffectiveMarkets(profile.config);
  data=Object.fromEntries(Object.entries(data).map(([index,record])=>{
   const market=markets[Number(index)];
   if(!market||!/ CLOSE$/.test(name(market.n))||record.sentDigits||record.sentRate||record.dispatchState||record.manualStatus||record.deliveryRestoredAt||record.s==='SKIP'||!isBacktestSelectionHeld(record,date)||
      (record.marketName&&name(record.marketName)!==name(market.n)))return [index,record];
   const next={...record};delete next.backtestSelectionHold;return [index,next];
  }));
 }
 if(!enabled&&data){
  const markets=getEffectiveMarkets(profile.config).map((m,index)=>({...m,index}));
  data=Object.fromEntries(Object.entries(data).map(([index,record])=>{
   if(record.openCloseCut)return [index,restoreOpenCloseInput(record,true)];
   // Upgrade the unambiguous old format (saved source minus this one digit).
   // Never reconstruct a compound/unknown selection from a full chart ranking.
   const market=markets[Number(index)],actual=market&&sameMarketOpenActual(markets,data!,market.n),source=getScrapeSource(record);
   const tokens=source?.digits.split(/[,|\s]+/).filter(Boolean)||[],current=record.d.split(/[,|\s]+/).filter(Boolean);
   if(!actual||!source||!record.od||protectedCard(record)||record.trick||record.positionRule||record.autoRemovedResult||record.autoResultParity||record.carryResultSix||
      !tokens.includes(actual)||current.join(',')!==tokens.filter(d=>d!==actual).join(','))return [index,record];
   let next:DayMarketRecord={...record,d:source.digits,sourceEditedAt:Math.max(Date.now(),modelSourceVersion(record)+1)};
   if(record.backtestResult)next=evaluateBacktest({...next,s:'WAIT'},'ank',record.backtestResult.actual);
   return [index,next];
  }));
 }
 const revision=Math.max(Date.now(),Number(day.backtestRevision||0)+1);
 return applyOpenToCloseCut({...profile,dayRecords:{...profile.dayRecords,[date]:{...day,...(data?{data}:{}),openToCloseCut:enabled,backtestRevision:revision}}},date);
}
