export interface ScrapeReply {status:string;httpStatus?:number;message?:string;cancelled?:boolean;retryAfterMs?:number;[key:string]:any}
export function retryDelay(value:string|null,now=Date.now()):number|undefined{
 if(!value)return undefined;const seconds=Number(value);
 const delay=Number.isFinite(seconds)?seconds*1000:Date.parse(value)-now;
 return Number.isFinite(delay)?Math.max(0,delay):undefined;
}
export function waitForRetry(ms:number,signal?:AbortSignal):Promise<void>{
 return new Promise((resolve,reject)=>{
  const abort=()=>{clearTimeout(timer);signal?.removeEventListener('abort',abort);reject(new DOMException('Cancelled','AbortError'));};
  const timer=setTimeout(()=>{signal?.removeEventListener('abort',abort);resolve();},ms);
  signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();
 });
}
/** Transport retries only. Source formulas, policy decisions and output stay untouched. */
export async function requestScrape(options:{url:string;body:Record<string,unknown>;signal?:AbortSignal;fetcher?:typeof fetch;timeoutMs?:number;maxAttempts?:1|2;wait?:(ms:number,signal?:AbortSignal)=>Promise<void>}):Promise<ScrapeReply>{
 // Leave time for the bounded upstream fetch plus parsing and tunnel transit.
 const {signal}=options,timeoutMs=options.timeoutMs??25000;
 const cancelled=():ScrapeReply=>({status:'error',cancelled:true,message:'Scrape cancelled'});
 let reply:ScrapeReply={status:'error',message:'Chart unavailable'};
 for(let attempt=0;attempt<(options.maxAttempts===1?1:2);attempt++){
  if(signal?.aborted)return cancelled();
  const controller=new AbortController(),abort=()=>controller.abort();
  signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();
  const timer=setTimeout(abort,timeoutMs);let retryable=false;
  try{
   const response=await (options.fetcher??fetch)(options.url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...options.body,requestTimeoutMs:timeoutMs}),signal:controller.signal});
   const raw=await response.text();
   try{const parsed=JSON.parse(raw);if(!parsed||typeof parsed!=='object'||Array.isArray(parsed)||!['success','error','unchanged'].includes(parsed.status))throw new Error('Invalid scrape protocol');reply={...parsed,httpStatus:response.status};}
   catch{reply={status:'error',httpStatus:response.status,message:`Invalid chart server response (HTTP ${response.status})`};retryable=response.ok;}
   // An HTTP error can never become a successful card through its JSON body.
   if(!response.ok)reply={...reply,status:'error'};
   const after=retryDelay(response.headers.get('Retry-After'))??reply.retryAfterMs;
   if(after!==undefined&&Number.isFinite(after)&&after>=0)reply.retryAfterMs=after;
   retryable=retryable||response.status===408||response.status===429||response.status>=500;
  }catch(error:any){
   if(signal?.aborted)return cancelled();
   reply={status:'error',httpStatus:error?.name==='AbortError'?408:503,message:error?.name==='AbortError'?'Scraping timeout: server response pending':'Network request failed'};retryable=true;
  }finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);}
  if(signal?.aborted)return cancelled();
  if(reply.status==='success'||!retryable||attempt+1>=(options.maxAttempts===1?1:2))return reply;
  const delay=Math.max(500,Number(reply.retryAfterMs)||0);
  // Long provider cooldowns are reported rather than retried too early.
  if(delay>5000)return reply;
  try{await (options.wait??waitForRetry)(delay,signal);}catch{return cancelled();}
 }
 return reply;
}
