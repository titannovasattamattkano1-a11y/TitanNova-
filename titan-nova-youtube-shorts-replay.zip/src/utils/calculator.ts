import { evaluateFourWaveDay, getCardFourWaveStateForProfile, isFourWaveRelayActive, type WaveId } from './fourWaveRelay';
import {TwoCardRecovery, useTwoCardRecovery, useRecoveryShareLedger, recoverySharesForCard, shareTotal, recoveryCardFrozen} from './twoCardRecovery';
import {archivedRecoveryProfile} from './archiveRecoverySnapshot';
import { assignedLoop, dayLoopConfig, profileFinancialRecoveryTrack, profileLegacyFinancialTrack, profileLoopTarget, type LoopId } from './dualLoops';
import { GameType, UserProfile, GlobalStats, TrickType, DayMarketRecord, MarketItem } from '../types';
import { MARKETS, BASE_MARKETS, getEffectiveMarkets, getEffectiveBaseMarkets, isMarketEnabled, getDefaultConfig } from '../data/markets';
import { calculateRecoveryRate, calculateSmartStakingRates, calculateSettlement, isRecoveryRatePossible } from './settlement';
import { buildPremiumPlayCard, buildPremiumResultCard } from './messageTemplates';
import { auditDigitsRows, auditGameTitle, formatAuditTextDate, renderAuditTextBox } from './auditTextLayout';
import { extractResultNumbers, resolveAmbiguousMarketByIST } from './resultMonitoring';
import { businessDateIST } from './businessDate';
import { jodiOpenSideStatus } from './recoveryLedger';
import { calculateCapitalWallet } from './capitalWallet';
import {isMarketEnabledForDate} from './profileMarketToggle';
import {isRecordedPlay} from './financialHistory';
import {recoveryMarketOrder} from './recoveryMarketOrder';

export function titanLocalDateISO(dateObj = new Date(), checkCutoff = true): string {
  return businessDateIST(dateObj, checkCutoff);
}

export function getBaseNameForMarket(fullMarketName: string): string | null {
  if (!fullMarketName) return null;
  const sorted = [...BASE_MARKETS].sort((a, b) => b.n.length - a.n.length);
  for (const bm of sorted) {
    if (fullMarketName.includes(bm.n)) return bm.n;
  }
  return null;
}

export function getHistoricalMultiplier(
  type: GameType,
  idx: number,
  currentDateStr: string,
  profiles: Record<string, UserProfile>
): number {
  const admin1 = profiles['admin1'];
  if (!admin1 || !admin1.dayRecords) return 1.0;

  const mRecs = admin1.dayRecords;
  const dates = Object.keys(mRecs).sort();
  const currPos = dates.indexOf(currentDateStr);
  const dictName = type === 'ank' ? 'data' : (type === 'jodi' ? 'jodiData' : 'pannelData');

  let dailyBoost = 0;
  if (currPos > 0) {
    let consecutiveFails = 0;
    for (let j = currPos - 1; j >= 0; j--) {
      const rec = mRecs[dates[j]]?.[dictName]?.[idx];
      if (!rec) continue;
      if (rec.s === 'FAIL') consecutiveFails++;
      else if (rec.s === 'PASS') break;
    }
    dailyBoost = consecutiveFails * 0.20;
  }

  let weeklyBoost = 0;
  const currObj = new Date(currentDateStr);
  currObj.setDate(currObj.getDate() - 7);
  const yyyy = currObj.getFullYear();
  const mm = String(currObj.getMonth() + 1).padStart(2, '0');
  const dd = String(currObj.getDate()).padStart(2, '0');
  const lastWeekRec = mRecs[`${yyyy}-${mm}-${dd}`]?.[dictName]?.[idx];
  if (lastWeekRec && lastWeekRec.s === 'FAIL') weeklyBoost = 0.10;

  return 1.0 + dailyBoost + weeklyBoost;
}

/**
 * Matka chart-style tricks (10 digits as 2 rows):
 *   Row A: 0 1 2 3 4
 *   Row B: 5 6 7 8 9
 *  T1 → positions 2,4,7,9,5,10
 *  T2 → positions 1,3,6,8,5,10
 *  T3 → 1,2, 6,7   independent centre-band pairs (exactly 4 digits)
 * Example 1,2,3,4,5,6,7,8,9,0 → T1:2,4,7,9,5,0 | T2:1,3,6,8,5,0 | T3:2,3,7,8
 */
export function isStrongWeekSource(rawInput: string): boolean {
  const digits = rawInput.match(/\d/g) || [];
  if (digits.length < 10) return false;
  const counts = new Map<string, number>();
  for (const digit of digits.slice(0, 10)) {
    counts.set(digit, (counts.get(digit) || 0) + 1);
  }
  // Conservative, deterministic strong-week guard: a source week with the
  // same digit appearing 3+ times is skipped for T3 only.
  return Math.max(...counts.values()) >= 3;
}

export function applyTrickFormula(rawInput: string, trickNum: 1 | 2 | 3): { formatted: string; trick: TrickType } | null {
  const digits = rawInput.match(/\d/g);
  if (!digits || digits.length < 1) return null;
  if (trickNum === 3 && isStrongWeekSource(rawInput)) return null;

  // Positions are one-based in the original source, never digit values.
  // UI position 0 denotes the tenth source slot for T2.
  const res = trickNum === 1 || trickNum === 2
    ? digits.slice(0, 10).filter((_digit, index) => index % 2 === (trickNum === 1 ? 0 : 1))
    : [digits[1], digits[2], digits[6], digits[7]];

  // Do not deduplicate: repeated digits are valid chart candidates and their
  // multiplicity must survive the Trick 1/2/3 pipeline.
  const output = res.filter(Boolean);
  if(!output.length)return null;
  return {
    formatted: output.join(', '),
    trick: (`T${trickNum}` as TrickType)
  };
}

function emptyProtoStats(): GlobalStats['ank'] {
  return { spent: 0, win: 0, pl: 0, port: 0, maxLoss: 0 };
}


function aggregateTrackDebt(debt: Record<string, number>): number {
  return Object.values(debt).reduce((total, amount) => total + Math.max(0, Number(amount) || 0), 0);
}

/**
 * ONE protocol wallet — Ank / Jodi / Panel never mix.
 *
 * Matka P/L rules (per settled card only — WAIT/SKIP ignored):
 *   invest = digitCount × rate
 *   PASS return = rate × multiplier   (Ank 9.5 / Jodi 95 / Panel 150)
 *   PASS net  = return − invest
 *   FAIL net  = −invest
 *   Day Net P/L = sum of card nets = totalReturn − totalInvest
 *
 * Example Ank PASS: 6 digits × ₹80 = ₹480 invest, return ₹80×9.5=₹760 → net +₹280
 */
/**
 * Multi-Day Base-Market Unsettled Debt Tracker
 * Traces backwards across preceding dates for the same base market:
 * - If last settled outcome of this market was PASS -> debt is 0 (reset).
 * - If last settled outcome was FAIL -> accumulates unsettled losses in the active fail streak.
 */
const baseMarketUnsettledCache = new WeakMap<UserProfile, { dayRecords: unknown; config: unknown; dayCount: number; map: Map<string, { debt: number; consecutiveFails: number; pendingProfit: number }> }>();

export function getBaseMarketUnsettledState(
  profile: UserProfile | undefined,
  currentDate: string,
  type: GameType,
  baseMarketName: string,
  resetAfterThreeFails?: boolean
): { debt: number; consecutiveFails: number; pendingProfit: number } {
  if (!profile?.dayRecords) return { debt: 0, consecutiveFails: 0, pendingProfit: 0 };
  const dayCount = Object.keys(profile.dayRecords).length;
  let uEntry = baseMarketUnsettledCache.get(profile);
  if (!uEntry || uEntry.dayRecords !== profile.dayRecords || uEntry.config !== profile.config || uEntry.dayCount !== dayCount) {
    uEntry = { dayRecords: profile.dayRecords, config: profile.config, dayCount, map: new Map() };
    baseMarketUnsettledCache.set(profile, uEntry);
  }
  const uKey = `${currentDate}|${type}|${baseMarketName}|${resetAfterThreeFails ? 1 : 0}`;
  const uHit = uEntry.map.get(uKey);
  if (uHit) return uHit;
  const baseName = String(baseMarketName || '').replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
  if (!baseName) return { debt: 0, consecutiveFails: 0, pendingProfit: 0 };

  const sortedDates = Object.keys(profile.dayRecords)
    .filter((d) => d < currentDate && /^\d{4}-\d{2}-\d{2}$/.test(d))
    .sort((a, b) => a.localeCompare(b));
  if (!sortedDates.length) return { debt: 0, consecutiveFails: 0, pendingProfit: 0 };

  const cfg = profile.config || getDefaultConfig();
  const resetEnabled = resetAfterThreeFails ?? cfg.liveThreeFailReset === true;
  const markets = type === 'jodi' ? getEffectiveBaseMarkets(cfg) : getEffectiveMarkets(cfg);
  const openName = `${baseName} OPEN`;
  const closeName = `${baseName} CLOSE`;
  const openIdx = (type === 'ank' || type === 'pannel') ? markets.findIndex(m => m.n.trim().toUpperCase() === openName) : -1;
  const closeIdx = (type === 'ank' || type === 'pannel') ? markets.findIndex(m => m.n.trim().toUpperCase() === closeName) : -1;
  const jodiIdx = type === 'jodi' ? markets.findIndex(m => m.n.trim().toUpperCase() === baseName) : -1;

  // Backward scan: locate the most recent PASS day so we only replay the active fail chain
  // instead of scanning all 100+ historical days on every card render.
  let startIdx = 0;
  const getStepStatus = (rec: DayMarketRecord | undefined): string => {
    if (!rec) return '';
    const st = type === 'jodi' && (rec.jodiOpenStatus === 'PASS' || rec.jodiOpenStatus === 'FAIL')
      ? rec.jodiOpenStatus
      : String(rec.s || '').toUpperCase().trim();
    if (st !== 'PASS' && st !== 'FAIL') return '';
    const digits = String(rec.sentAt ? (rec.sentDigits || rec.d) : rec.d || '').trim();
    if (!digits) return '';
    return st;
  };
  for (let i = sortedDates.length - 1; i >= 0; i--) {
    const day = profile.dayRecords[sortedDates[i]];
    if (!day) continue;
    const store = type === 'ank' ? day.data : type === 'jodi' ? day.jodiData : day.pannelData;
    if (!store) continue;
    if (type === 'ank' || type === 'pannel') {
      const cRec = closeIdx >= 0 ? store[closeIdx] : Object.values(store).find(r => String(r?.marketName || '').trim().toUpperCase() === closeName);
      if (getStepStatus(cRec) === 'PASS') {
        startIdx = i;
        break;
      }
      const oRec = openIdx >= 0 ? store[openIdx] : Object.values(store).find(r => String(r?.marketName || '').trim().toUpperCase() === openName);
      if (getStepStatus(oRec) === 'PASS') {
        startIdx = i;
        break;
      }
    } else {
      const jRec = jodiIdx >= 0 ? store[jodiIdx] : Object.values(store).find(r => String(r?.marketName || '').trim().toUpperCase() === baseName);
      if (getStepStatus(jRec) === 'PASS') {
        startIdx = i;
        break;
      }
    }
  }

  let debt = 0;
  let consecutiveFails = 0;
  let pendingProfit = 0;

  const evaluateCardStep = (rec: DayMarketRecord | undefined, cardMarketName: string, dateStr: string, dayCfg: any, isOpenPassForClose = false) => {
    if (!rec) return;
    const status = type === 'jodi' && (rec.jodiOpenStatus === 'PASS' || rec.jodiOpenStatus === 'FAIL')
      ? rec.jodiOpenStatus
      : String(rec.s || '').toUpperCase().trim();
    if (status !== 'PASS' && status !== 'FAIL') return;

    const target = dayLoopConfig(profile, dateStr)
      ? profileLoopTarget(profile, dateStr, type, cardMarketName, rec)
      : (parseFloat(String(dayCfg?.[type]?.tgt || cfg?.[type]?.tgt)) || 100);
    const isProfitCarry = Boolean(dayCfg?.profitCarry === true || cfg?.profitCarry === true || profile?.profitCarry === true);

    if (isOpenPassForClose) {
      if (status === 'FAIL') {
        if (isProfitCarry) pendingProfit += target;
      } else if (status === 'PASS') {
        pendingProfit = 0;
      }
      return;
    }

    const digits = rec.sentAt ? (rec.sentDigits || rec.d) : rec.d;
    const isGenuineManualRate = Boolean(rec.manualRate && !rec.manualStatus && Number(rec.r) > 0);
    const isSmart = (type === 'ank' || type === 'pannel') && useTwoCardRecovery(dayCfg || cfg, dateStr, type) && !isGenuineManualRate;
    const effectiveTarget = target + (isProfitCarry ? pendingProfit : 0);
    const smart = isSmart
      ? calculateSmartStakingRates(type, digits, debt, effectiveTarget, rec.smartSelection?.strongDigits, rec.smartSelection?.supportDigits)
      : undefined;
    const fallbackRate = isGenuineManualRate ? rec.r : (calculateRecoveryRate(type, digits, debt, effectiveTarget) || rec.r || rec.recRate);
    const winDigit = rec.manualResult || rec.scrapeResultDigit || (/CLOSE/i.test(cardMarketName) ? rec.backtestResult?.actual?.close : rec.backtestResult?.actual?.open);
    const settlement = calculateSettlement({
      type,
      digits,
      rate: fallbackRate,
      sentRate: rec.sentAt ? rec.sentRate : undefined,
      sentInvest: rec.sentAt ? rec.sentInvest : undefined,
      smartStaking: smart?.isSmartStaking ? smart : undefined,
      winningDigit: winDigit,
    });

    if (settlement.tokenCount <= 0) return;

    if (status === 'FAIL') {
      debt += settlement.invest;
      if (isProfitCarry) {
        pendingProfit += target;
      }
      consecutiveFails += 1;
      if (resetEnabled && consecutiveFails >= 3) {
        debt = 0;
        pendingProfit = 0;
        consecutiveFails = 0;
      }
    } else if (status === 'PASS') {
      debt = 0;
      pendingProfit = 0;
      consecutiveFails = 0;
    }
  };

  for (let i = startIdx; i < sortedDates.length; i++) {
    const date = sortedDates[i];
    const day = profile.dayRecords[date];
    if (!day) continue;
    const store = type === 'ank' ? day.data : type === 'jodi' ? day.jodiData : day.pannelData;
    if (!store) continue;
    const dayCfg = day.recoveryConfigSnapshot || cfg;

    if (type === 'ank' || type === 'pannel') {
      const openRec = openIdx >= 0 ? store[openIdx] : Object.values(store).find(r => String(r?.marketName || '').trim().toUpperCase() === openName);
      const closeRec = closeIdx >= 0 ? store[closeIdx] : Object.values(store).find(r => String(r?.marketName || '').trim().toUpperCase() === closeName);

      evaluateCardStep(openRec, openName, date, dayCfg);
      const isOpenPassCloseZero = Boolean(dayCfg?.openPassCloseZero || cfg?.openPassCloseZero || profile?.openPassCloseZero);
      const openPassed = String(openRec?.s || '').toUpperCase().trim() === 'PASS';
      evaluateCardStep(closeRec, closeName, date, dayCfg, isOpenPassCloseZero && openPassed);
    } else {
      const jodiRec = jodiIdx >= 0 ? store[jodiIdx] : Object.values(store).find(r => String(r?.marketName || '').trim().toUpperCase() === baseName);
      evaluateCardStep(jodiRec, baseName, date, dayCfg);
    }
  }

  const res = { debt: Math.round(debt * 100) / 100, consecutiveFails, pendingProfit: Math.round(pendingProfit * 100) / 100 };
  uEntry.map.set(uKey, res);
  return res;
}

export function getBaseMarketUnsettledDebt(
  profile: UserProfile | undefined,
  currentDate: string,
  type: GameType,
  baseMarketName: string,
  resetAfterThreeFails?: boolean
): number {
  return getBaseMarketUnsettledState(profile, currentDate, type, baseMarketName, resetAfterThreeFails).debt;
}

/**
 * Exact live/backtest Same-Market Recovery state for a specific card on currentDate:
 * - For OPEN (or JODI): returns prior days' unsettled debt for this base market.
 * - For CLOSE: applies today's OPEN outcome of the same base market:
 *   - If today's OPEN is FAIL -> returns priorDebt + todayOpenInvest.
 *   - If today's OPEN is PASS -> returns 0 (recovery reset!).
 *   - If today's OPEN is WAIT (with digits) -> today's OPEN holds the priorDebt recovery slot, so CLOSE starts at 0 until OPEN settles.
 */
export function getCardSameMarketRecoveryState(
  profile: UserProfile | undefined,
  currentDate: string,
  type: GameType,
  index: number,
  marketName: string
): { debt: number; consecutiveFails: number; waveId?: WaveId; pendingProfit: number } {
  if (!profile) return { debt: 0, consecutiveFails: 0, pendingProfit: 0 };
  const baseName = String(marketName || '').replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
  const day = profile.dayRecords?.[currentDate];
  const cfg = (currentDate < businessDateIST() ? day?.recoveryConfigSnapshot : undefined) || profile.config || getDefaultConfig();
  const resetEnabled = currentDate < businessDateIST()
    ? day?.backtestRecoveryPolicy?.resetAfterThreeFails === true
    : cfg.liveThreeFailReset === true;
  const isSmart = (type === 'ank' || type === 'pannel') && useTwoCardRecovery(cfg, currentDate, type);

  const loopCfg = dayLoopConfig(profile, currentDate);
  if (isFourWaveRelayActive(cfg, Boolean(loopCfg?.enabled))) {
    const fw = getCardFourWaveStateForProfile(profile, currentDate, type, index);
    return { debt: fw.debt, consecutiveFails: fw.consecutiveFails, waveId: fw.waveId, pendingProfit: fw.pendingProfit || 0 };
  }
  const isSameMarket = !loopCfg?.enabled && cfg.sameMarketRecovery !== false && (
    type === 'ank' ? cfg.ankSplit !== false : type === 'pannel' ? cfg.panSplit !== false : false
  );

  if (isSameMarket) {
    const prior = getBaseMarketUnsettledState(profile, currentDate, type, baseName, resetEnabled);
    let debt = prior.debt;
    let consecutiveFails = prior.consecutiveFails;
    let pendingProfit = prior.pendingProfit || 0;

    if ((type === 'ank' || type === 'pannel') && /\s+CLOSE$/i.test(String(marketName || '').trim())) {
      const store = type === 'ank' ? day?.data : day?.pannelData;
      if (store) {
        const markets = getEffectiveMarkets(cfg);
        const openName = `${baseName} OPEN`;
        const openIdx = markets.findIndex(m => m.n.trim().toUpperCase() === openName);
        const openRec = openIdx >= 0 ? store[openIdx] : Object.values(store).find(r => String(r?.marketName || '').trim().toUpperCase() === openName);
        if (openRec) {
          const openStatus = String(openRec.s || 'WAIT').toUpperCase().trim();
          const openDigits = String(openRec.sentDigits || openRec.d || '').trim();
          if (openStatus === 'PASS') {
            debt = 0;
            consecutiveFails = 0;
            const isOpenPassCloseZero = Boolean(cfg?.openPassCloseZero || profile?.openPassCloseZero);
            const isProfitCarry = Boolean(cfg?.profitCarry === true || profile?.profitCarry === true);
            const currentClose = store[index];
            const currentCloseStatus = String(currentClose?.s || 'WAIT').toUpperCase().trim();
            if (isOpenPassCloseZero && isProfitCarry && currentCloseStatus === 'FAIL') {
              const target = loopCfg?.enabled
                ? profileLoopTarget(profile, currentDate, type, marketName, currentClose)
                : (parseFloat(String(cfg?.[type]?.tgt)) || 100);
              pendingProfit = target;
            } else {
              pendingProfit = 0;
            }
          } else if (openStatus === 'FAIL') {
            const target = loopCfg?.enabled
              ? profileLoopTarget(profile, currentDate, type, openName, openRec)
              : (parseFloat(String(cfg?.[type]?.tgt)) || 100);
            const isGenuineManualRate = Boolean(openRec.manualRate && !openRec.manualStatus && Number(openRec.r) > 0);
            const isProfitCarry = Boolean(cfg?.profitCarry === true || profile?.profitCarry === true);
            const openEffectiveTarget = target + (isProfitCarry ? pendingProfit : 0);
            const smart = isSmart && !isGenuineManualRate
              ? calculateSmartStakingRates(type, openDigits, debt, openEffectiveTarget, openRec.smartSelection?.strongDigits, openRec.smartSelection?.supportDigits)
              : undefined;
            const fallbackRate = isGenuineManualRate ? openRec.r : (calculateRecoveryRate(type, openDigits, debt, openEffectiveTarget) || openRec.r || openRec.recRate);
            const openSettlement = calculateSettlement({
              type,
              digits: openDigits,
              rate: fallbackRate,
              sentRate: openRec.sentAt ? openRec.sentRate : undefined,
              sentInvest: openRec.sentAt ? openRec.sentInvest : undefined,
              smartStaking: smart?.isSmartStaking ? smart : undefined,
            });
            if (openSettlement.tokenCount > 0 && openSettlement.invest > 0) {
              debt += openSettlement.invest;
              if (isProfitCarry) {
                pendingProfit += target;
              }
              consecutiveFails += 1;
              if (resetEnabled && consecutiveFails >= 3) {
                debt = 0;
                consecutiveFails = 0;
                pendingProfit = 0;
              }
            }
          } else if (openStatus === 'WAIT' && openDigits.length > 0) {
            debt = 0;
            pendingProfit = 0;
          }
        }
      }
    }
    return { debt: Math.round(debt * 100) / 100, consecutiveFails, pendingProfit: Math.round(pendingProfit * 100) / 100 };
  }

  // Normal Mode (Smart Stake OFF) or Custom Loop Mode -> Daily Next-Card to Next-Card Recovery
  const store = (type === 'ank' ? day?.data : type === 'jodi' ? day?.jodiData : day?.pannelData) || {};
  const visDict = type === 'ank' ? day?.visAnk : type === 'jodi' ? day?.visJodi : day?.visPan;
  const markets = type === 'jodi' ? getEffectiveBaseMarkets(cfg) : getEffectiveMarkets(cfg);
  const marginMultiplier = type === 'ank' ? 9.5 : type === 'jodi' ? 95.0 : 150.0;
  const currentRec = store[index];
  const targetTrack = profileFinancialRecoveryTrack(profile, currentDate, type, marketName, currentRec);

  const trackEntries = recoveryMarketOrder(
    markets.map((m, idx) => ({ ...m, index: idx }))
  ).filter((m) => {
    const rec = store[m.index];
    const settled = rec?.s === 'PASS' || rec?.s === 'FAIL' || (type === 'jodi' && (rec?.jodiOpenStatus === 'PASS' || rec?.jodiOpenStatus === 'FAIL'));
    const enabled = isMarketEnabledForDate(cfg, visDict, m.n, currentDate);
    if (!enabled && !settled) return false;
    return profileFinancialRecoveryTrack(profile, currentDate, type, m.n, rec) === targetTrack;
  });

  let lastSettledPos = -1;
  trackEntries.forEach((m, pos) => {
    const rec = store[m.index];
    const status = type === 'jodi' && (rec?.jodiOpenStatus === 'PASS' || rec?.jodiOpenStatus === 'FAIL')
      ? rec.jodiOpenStatus
      : String(rec?.s || 'WAIT').toUpperCase().trim();
    if (status === 'PASS' || status === 'FAIL') {
      lastSettledPos = pos;
    }
  });

  let debt = 0;
  let consecutiveFails = 0;
  let pendingProfit = 0;
  let recoveryAssigned = false;

  for (let pos = 0; pos < trackEntries.length; pos++) {
    const m = trackEntries[pos];
    const rec = store[m.index] || { s: 'WAIT', d: '', r: '' };
    const status = type === 'jodi' && (rec.jodiOpenStatus === 'PASS' || rec.jodiOpenStatus === 'FAIL')
      ? rec.jodiOpenStatus
      : String(rec.s || 'WAIT').toUpperCase().trim();
    const isSettled = status === 'PASS' || status === 'FAIL';

    if (m.index === index) {
      if (isSettled) {
        return { debt: Math.round(debt * 100) / 100, consecutiveFails, pendingProfit: Math.round(pendingProfit * 100) / 100 };
      }
      if (pos < lastSettledPos && !rec.sentAt) {
        return { debt: 0, consecutiveFails: 0, pendingProfit: 0 };
      }
      return {
        debt: Math.round((recoveryAssigned ? 0 : debt) * 100) / 100,
        consecutiveFails,
        pendingProfit: Math.round((recoveryAssigned ? 0 : pendingProfit) * 100) / 100,
      };
    }

    const digits = String(rec.sentAt ? (rec.sentDigits || rec.d) : rec.d || '').trim();
    const count = digits ? digits.split(/[,|\s]+/).filter(Boolean).length : 0;
    const margin = marginMultiplier - count;

    if (isSettled) {
      const target = loopCfg?.enabled
        ? profileLoopTarget(profile, currentDate, type, m.n, rec)
        : (parseFloat(String(cfg?.[type]?.tgt)) || 100);
      const isGenuineManualRate = Boolean(rec.manualRate && !rec.manualStatus && Number(rec.r) > 0);
      const isProfitCarry = Boolean(cfg?.profitCarry === true || profile?.profitCarry === true);
      const isOpenPassCloseZero = Boolean(cfg?.openPassCloseZero || profile?.openPassCloseZero);
      let isOpenPassForClose = false;
      if (isOpenPassCloseZero && (type === 'ank' || type === 'pannel') && /\s+CLOSE$/i.test(m.n)) {
        const bName = m.n.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
        const oName = `${bName} OPEN`;
        const oIdx = markets.findIndex(item => item.n.trim().toUpperCase() === oName);
        const oRec = oIdx >= 0 ? store[oIdx] : undefined;
        isOpenPassForClose = oRec?.s === 'PASS';
      }

      if (isOpenPassForClose) {
        if (status === 'FAIL') {
          if (isProfitCarry) pendingProfit += target;
        } else if (status === 'PASS') {
          pendingProfit = 0;
        }
        recoveryAssigned = false;
        continue;
      }

      const effectiveTarget = target + (isProfitCarry ? pendingProfit : 0);
      const cardRate = rec.sentAt
        ? (rec.sentRate || rec.r)
        : (isGenuineManualRate ? rec.r : (calculateRecoveryRate(type, digits, debt, effectiveTarget) || rec.r || rec.recRate));
      const settlement = calculateSettlement({
        type,
        digits,
        rate: cardRate,
        sentRate: rec.sentAt ? rec.sentRate : undefined,
        sentInvest: rec.sentInvest ? rec.sentInvest : undefined,
        smartStaking: rec.smartStaking,
      });
      if (settlement.tokenCount > 0 && settlement.invest > 0) {
        if (status === 'FAIL') {
          debt += settlement.invest;
          if (isProfitCarry) {
            pendingProfit += target;
          }
          consecutiveFails += 1;
          if (resetEnabled && consecutiveFails >= 3) {
            debt = 0;
            consecutiveFails = 0;
            pendingProfit = 0;
          }
        } else if (status === 'PASS') {
          debt = 0;
          consecutiveFails = 0;
          pendingProfit = 0;
        }
      }      recoveryAssigned = false;
    } else if (pos > lastSettledPos || rec.sentAt || rec.dispatchState === 'SENT') {
      if (rec.sentAt || rec.dispatchState === 'SENT' || (count > 0 && margin > 0)) {
        recoveryAssigned = true;
      }
    }
  }

  return { debt: 0, consecutiveFails: 0, pendingProfit: 0 };
}

export function calculateProtocolStats(
  type: GameType,
  profile: UserProfile,
  currentDate: string,
  loopFilter?: LoopId
): GlobalStats['ank'] {
  const out = emptyProtoStats();
  if (!profile?.dayRecords?.[currentDate] || !profile.config) return out;

  const catalog=profile.config;
  profile=archivedRecoveryProfile(profile,currentDate);
  const record = profile.dayRecords[currentDate];
  const dataDict: Record<string, DayMarketRecord> | undefined =
    type === 'ank' ? record.data : type === 'jodi' ? record.jodiData : record.pannelData;
  if (!dataDict) return out;

  const arr: MarketItem[] =
    type === 'jodi'
      ? getEffectiveBaseMarkets(profile.config)
      : getEffectiveMarkets(profile.config);

  const trackDebt: Record<string, number> = {};
  const splitQueues:Record<string,TwoCardRecovery>={};
  const splitTwo=useRecoveryShareLedger(profile.config,currentDate,type);
  const activeNames=new Set((type==='jodi'?getEffectiveBaseMarkets(catalog):getEffectiveMarkets(catalog)).map(m=>m.n));
  const visibility=record[type==='ank'?'visAnk':type==='jodi'?'visJodi':'visPan'];
  let peakPendingLoss = 0;

  const known=type==='jodi'?getEffectiveBaseMarkets({...catalog,deletedMarketNames:[]}):getEffectiveMarkets({...catalog,deletedMarketNames:[]});
  const entries=Object.entries(dataDict).map(([i,src])=>{
    const n=src?.marketName,market=n?arr.find(m=>m.n===n)||known.find(m=>m.n===n):arr[Number(i)];
    return {i,src,index:Number(i),hr:market?.hr,min:market?.min};
  });
  recoveryMarketOrder(entries).forEach(({i,src}) => {
    if (!src) return;
    const marketName = src.marketName || arr[Number(i)]?.n;
    if (!marketName) return;
    if(!isRecordedPlay(src)&&(!activeNames.has(marketName)||!isMarketEnabledForDate(profile.config,visibility,marketName,currentDate)))return;
    if (loopFilter && assignedLoop(dayLoopConfig(profile,currentDate),type,marketName,src) !== loopFilter) return;

    // Normalize status — only PASS / FAIL settle into wallet
    const status = String(src.s || 'WAIT').toUpperCase().trim();
    if (status !== 'PASS' && status !== 'FAIL') return; // WAIT / SKIP / empty → ₹0
    const isProtoOpenPassCloseZero = Boolean(profile?.config?.openPassCloseZero || profile?.openPassCloseZero);
    if (isProtoOpenPassCloseZero && (type === 'ank' || type === 'pannel') && /\s+CLOSE$/i.test(marketName) && !src.sentAt && !(src.manualRate && !src.manualStatus && Number(src.r) > 0)) {
      const bName = marketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
      const oName = `${bName} OPEN`;
      const oIdx = arr.findIndex(item => item.n.trim().toUpperCase() === oName);
      const oRec = oIdx >= 0 ? dataDict[oIdx] : Object.values(dataDict).find(r => String(r?.marketName || '').trim().toUpperCase() === oName);
      if (oRec?.s === 'PASS') return; // Close Zero Skip -> ₹0 invest, ₹0 win/loss!
    }

    const winDigit = src.manualResult || src.scrapeResultDigit || (/CLOSE/i.test(marketName) ? src.backtestResult?.actual?.close : src.backtestResult?.actual?.open);
    const settlement = calculateSettlement({
      type,
      digits: src.sentAt ? (src.sentDigits || src.d) : src.d,
      rate: src.r || src.recRate,
      sentRate: src.sentAt ? src.sentRate : undefined,
      sentInvest: src.sentAt ? src.sentInvest : undefined,
      smartStaking: src.smartStaking,
      winningDigit: winDigit,
    });
    const rate = settlement.rate;
    const invest = settlement.invest;
    if (settlement.tokenCount <= 0) return;
    const baseMarket = marketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
    const sameMarketTrack = `${type}:${baseMarket}`;
    const loopCfg = dayLoopConfig(profile, currentDate);
    const isFourWave = isFourWaveRelayActive(profile.config, Boolean(loopCfg?.enabled));
    const isSameMarket = !isFourWave && !loopCfg?.enabled && profile.config.sameMarketRecovery !== false && (
      type === 'ank' ? profile.config.ankSplit !== false : type === 'pannel' ? profile.config.panSplit !== false : false
    );
    const trackKey = isSameMarket
      ? sameMarketTrack
      : profileFinancialRecoveryTrack(profile,currentDate,type,marketName,src);
    if (trackDebt[trackKey] === undefined) {
      trackDebt[trackKey] = isSameMarket
        ? getBaseMarketUnsettledDebt(profile, currentDate, type, baseMarket)
        : 0;
    }

    if(splitTwo){
      const queue=splitQueues[trackKey] ||= new TwoCardRecovery();
      const before=queue.debt;
      const legacy=queue.legacySettlement(`${type}_${i}`,profileLegacyFinancialTrack(profile,currentDate,type,marketName,src),status,invest,recoveryCardFrozen(src)||!src.backtestResult||Array.isArray(src.twoCardRecoveryShares),src.twoCardRecoveryShares);
      const shares=legacy?[]:recoverySharesForCard(queue,src,useTwoCardRecovery(profile.config,currentDate,type),recoveryCardFrozen(src)||!src.backtestResult||Array.isArray(src.twoCardRecoveryShares));
      if(status==='FAIL'&&!legacy)queue.fail(`${type}_${i}`,invest,shares);
      out.spent+=invest;
      if(status==='PASS')out.win+=settlement.payout;
      trackDebt[trackKey]=queue.debt;
      peakPendingLoss=Math.max(peakPendingLoss,aggregateTrackDebt(trackDebt),aggregateTrackDebt(trackDebt)-queue.debt+before+invest);
      return;
    }
    if (status === 'FAIL') {
      out.spent += invest;
      trackDebt[trackKey] += invest;
      peakPendingLoss = Math.max(peakPendingLoss, aggregateTrackDebt(trackDebt));
      return;
    }

    // PASS: return is rate × multiplier (winning number pays once — not × digit count)
    const payout = settlement.payout;
    out.spent += invest;
    out.win += payout;
    peakPendingLoss = Math.max(peakPendingLoss, aggregateTrackDebt(trackDebt) + invest);
    trackDebt[trackKey] = 0;
  });

  out.pl = out.win - out.spent;
  const loopCfgForStats = dayLoopConfig(profile, currentDate);
  if (!loopFilter && isFourWaveRelayActive(profile.config, Boolean(loopCfgForStats?.enabled))) {
    const wallet = calculateCapitalWallet(type, dataDict, true);
    const fw = evaluateFourWaveDay({
      type,
      markets: arr,
      store: dataDict,
      cfg: profile.config,
      visDict: visibility,
      resetEnabled: currentDate < businessDateIST()
        ? record.backtestRecoveryPolicy?.resetAfterThreeFails === true
        : profile.config.liveThreeFailReset === true,
      targetGetter: (_m, _rec) => parseFloat(String(profile.config[type]?.tgt)) || 100,
    });
    peakPendingLoss = wallet.invested > 0 ? wallet.invested : fw.peakPendingLoss;
  }
  // Max risk includes the stake on the PASS that ends a loss chain.
  out.maxLoss = peakPendingLoss;
  out.port = out.maxLoss + Math.max(0, out.pl);
  return out;
}

/** Three isolated wallets */
export function calculateGlobalStats(
  profile: UserProfile,
  currentDate: string,
  _profiles?: Record<string, UserProfile>
): GlobalStats {
  return {
    ank: calculateProtocolStats('ank', profile, currentDate),
    jodi: calculateProtocolStats('jodi', profile, currentDate),
    pannel: calculateProtocolStats('pannel', profile, currentDate),
  };
}

/**
 * Apply target-based auto rates onto WAIT cards that have digits.
 * Safe to call outside render (writes a NEW day store — does not mutate input).
 * Formula: rate = ceil_10((pending actual loss + one target) / net margin).
 * Unified mode assigns debt once; Split 2 distributes bounded per-FAIL shares.
 */
export function applyAutoRatesToDayStore(
  profile: UserProfile,
  currentDate: string,
  _profiles: Record<string, UserProfile>
): { data?: Record<string, DayMarketRecord>; jodiData?: Record<string, DayMarketRecord>; pannelData?: Record<string, DayMarketRecord>; visAnk?: any; visJodi?: any; visPan?: any } | null {
  if (!profile?.dayRecords?.[currentDate] || !profile.config) return null;

  const day = profile.dayRecords[currentDate];
  const nextData: Record<string, DayMarketRecord> = { ...(day.data || {}) };
  const nextJodi: Record<string, DayMarketRecord> = { ...(day.jodiData || {}) };
  const nextPan: Record<string, DayMarketRecord> = { ...(day.pannelData || {}) };
  let changed = false;

  const run = (
    type: GameType,
    dataDict: Record<string, DayMarketRecord>,
    arr: MarketItem[],
    marginMultiplier: number,
    trackPrefix: string
  ) => {

    const visDict = type === 'ank' ? day.visAnk : type === 'jodi' ? day.visJodi : day.visPan;

    const splitTwo = useRecoveryShareLedger(profile.config,currentDate,type);
    const splitMode=useTwoCardRecovery(profile.config,currentDate,type);
    const splitQueues: Record<string,TwoCardRecovery> = {};
    const debt: Record<string, number> = {};
    const pendingProfits: Record<string, number> = {};
    const failures:Record<string,number>={};
    const liveReset=profile.config.liveThreeFailReset===true&&currentDate===businessDateIST();
    const recoveryAssigned: Record<string, boolean> = {};
    const loopCfg = dayLoopConfig(profile, currentDate);
    const isFourWave = isFourWaveRelayActive(profile.config, Boolean(loopCfg?.enabled));
    const fourWaveEval = isFourWave
      ? evaluateFourWaveDay({
          type,
          markets: arr,
          store: dataDict,
          cfg: profile.config,
          visDict,
          resetEnabled: liveReset,
          targetGetter: () => parseFloat(String(profile.config[type]?.tgt)) || 0,
          isArchiveOrBacktest: currentDate < businessDateIST(),
        })
      : undefined;
    const isSameMarket = !isFourWave && !loopCfg?.enabled && profile.config.sameMarketRecovery !== false && (
      type === 'ank' ? profile.config.ankSplit !== false : type === 'pannel' ? profile.config.panSplit !== false : false
    );
    const getTrackKey = (m: MarketItem, src: DayMarketRecord) => {
      const baseMarket = m.n.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
      return isSameMarket
        ? `${type}:${baseMarket}`
        : (loopCfg?.enabled ? profileFinancialRecoveryTrack(profile,currentDate,type,m.n,src) : `${trackPrefix}Unified`);
    };
    const lastSettledIdxByTrack: Record<string, number> = {};
    arr.forEach((m, i) => {
      const src = dataDict[i];
      if (!src) return;
      const settled = src.s === 'PASS' || src.s === 'FAIL' || (type === 'jodi' && (src.jodiOpenStatus === 'PASS' || src.jodiOpenStatus === 'FAIL'));
      if (settled) {
        const tk = getTrackKey(m, src);
        lastSettledIdxByTrack[tk] = i;
      }
    });

    arr.forEach((m, i) => {
      const src = dataDict[i] || { s: 'WAIT', d: '', r: '' };
      const actualOutcome=src.s==='PASS'||src.s==='FAIL'||(type==='jodi'&&(src.jodiOpenStatus==='PASS'||src.jodiOpenStatus==='FAIL'));
      const enabled=isMarketEnabledForDate(profile.config,visDict,m.n,currentDate);
      if(!enabled&&!((liveReset||splitTwo)&&actualOutcome))return;
      const targetProf = loopCfg?.enabled ? profileLoopTarget(profile,currentDate,type,m.n,src) : parseFloat(String(profile.config[type]?.tgt)) || 0;
      if (targetProf <= 0 && !loopCfg?.enabled&&!liveReset) return;
      const baseMarket = m.n.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
      const trackKey = getTrackKey(m, src);
      if (debt[trackKey] === undefined) {
        if (isSameMarket) {
          const prior = getBaseMarketUnsettledState(profile, currentDate, type, baseMarket, liveReset);
          debt[trackKey] = prior.debt;
          failures[trackKey] = prior.consecutiveFails;
          pendingProfits[trackKey] = prior.pendingProfit || 0;
        } else {
          debt[trackKey] = 0;
          pendingProfits[trackKey] = 0;
        }
      }
      if (recoveryAssigned[trackKey] === undefined) recoveryAssigned[trackKey] = false;
      const count = (src.d ? String(src.d) : '').split(/[,|\s]+/).filter((x) => x.trim()).length;
      const genuinelyDelivered = Boolean(src.sentAt || src.dispatchState === 'SENT');
      const isGenuineManualRate = Boolean(src.manualRate && !src.manualStatus && Number(src.r) > 0);
      const settled = src.s === 'PASS' || src.s === 'FAIL';
      const lastSettledIdx = lastSettledIdxByTrack[trackKey] ?? -1;
      const bypassedWait = !settled && !genuinelyDelivered && i < lastSettledIdx;

      const isCloseMarket = (type === 'ank' || type === 'pannel') && /\s+CLOSE$/i.test(m.n);
      const isOpenPassCloseZero = Boolean(profile?.config?.openPassCloseZero || profile?.openPassCloseZero);
      let isOpenPassForClose = false;
      if (isOpenPassCloseZero && isCloseMarket) {
        const baseName = m.n.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
        const openName = `${baseName} OPEN`;
        const openIdx = arr.findIndex(item => item.n.trim().toUpperCase() === openName);
        const openRec = openIdx >= 0 ? dataDict[openIdx] : undefined;
        isOpenPassForClose = openRec?.s === 'PASS';
      }

      let activeRecord: DayMarketRecord = src;
      const margin = marginMultiplier - count;
      if (src.s === 'SKIP' && !isOpenPassForClose && !genuinelyDelivered) {
        if (src.r !== '0' || src.recRate !== '0' || src.smartStaking || src.sentRate || Number(src.sentInvest || 0) !== 0) {
          dataDict[i] = {
            ...src,
            r: '0',
            recRate: '0',
            prevLoss: 0,
            targetProfitWithLoss: 0,
            smartStaking: undefined,
            sentRate: undefined,
            sentInvest: 0,
          };
          changed = true;
        }
        recoveryAssigned[trackKey] = false;
        return;
      }
      const alreadySettledWithRate = settled && (Boolean(src.sentRate) || Number(src.r) > 0) && !isOpenPassForClose;
      if (!genuinelyDelivered && !alreadySettledWithRate && count > 0 && margin > 0) {
        if (isOpenPassForClose) {
          const nextRate = isGenuineManualRate ? String(src.r) : '0';
          const shouldAutoSkip = !isGenuineManualRate && !src.manualStatus;
          const updated: DayMarketRecord = {
            ...src,
            ...(assignedLoop(dayLoopConfig(profile,currentDate),type,m.n,src) ? {loopId: assignedLoop(dayLoopConfig(profile,currentDate),type,m.n,src)} : {}),
            s: shouldAutoSkip ? 'SKIP' : (src.s || 'WAIT'),
            ...(shouldAutoSkip ? { closeZeroAutoSkipped: true } : {}),
            smartStaking: undefined,
            prevLoss: 0,
            targetProfitWithLoss: 0,
            recRate: '0',
            r: nextRate,
            ...(settled && !src.sentAt ? {
              sentRate: nextRate,
              sentInvest: 0,
            } : {}),
            ...(isGenuineManualRate ? {} : { manualRate: undefined }),
          };
          if (
            src.s !== updated.s ||
            src.r !== updated.r ||
            src.recRate !== updated.recRate ||
            src.prevLoss !== updated.prevLoss ||
            src.targetProfitWithLoss !== updated.targetProfitWithLoss ||
            src.sentRate !== updated.sentRate ||
            src.sentInvest !== updated.sentInvest
          ) {
            dataDict[i] = updated;
            activeRecord = updated;
            changed = true;
          }
        } else {
          const restoredFromCloseZero = (src as any).closeZeroAutoSkipped === true && src.s === 'SKIP';
          const fwState = isFourWave ? fourWaveEval?.byIndex.get(i) : undefined;
          const recoveryDebt = isFourWave
            ? (fwState?.debt ?? 0)
            : (bypassedWait ? 0 : (settled ? debt[trackKey] : (recoveryAssigned[trackKey] ? 0 : debt[trackKey])));
          const isProfitCarry = Boolean(profile?.config?.profitCarry === true || profile?.profitCarry === true);
          const carriedProfit = isProfitCarry
            ? (isFourWave ? (fwState?.pendingProfit ?? 0) : (bypassedWait ? 0 : (settled ? (pendingProfits[trackKey] || 0) : (recoveryAssigned[trackKey] ? 0 : (pendingProfits[trackKey] || 0)))))
            : 0;
          const effectiveTarget = targetProf + carriedProfit;
          const totalRequiredProfit = recoveryDebt + effectiveTarget;
          const recRate = calculateRecoveryRate(type, src.d, recoveryDebt, effectiveTarget);
          const nextRate = isGenuineManualRate ? String(src.r) : recRate;
          const smartStaking = splitMode && (type === 'ank' || type === 'pannel') && !isGenuineManualRate
            ? calculateSmartStakingRates(type, src.d, recoveryDebt, effectiveTarget, src.smartSelection?.strongDigits, src.smartSelection?.supportDigits)
            : undefined;
          const updated: DayMarketRecord = {
            ...src,
            ...(assignedLoop(dayLoopConfig(profile,currentDate),type,m.n,src) ? {loopId: assignedLoop(dayLoopConfig(profile,currentDate),type,m.n,src)} : {}),
            s: restoredFromCloseZero ? 'WAIT' : (src.s || 'WAIT'),
            ...(restoredFromCloseZero ? { closeZeroAutoSkipped: undefined } : {}),
            ...(smartStaking?.isSmartStaking ? {smartStaking} : {smartStaking: undefined}),
            prevLoss: recoveryDebt,
            targetProfitWithLoss: totalRequiredProfit,
            recRate,
            r: nextRate,
            ...(settled && !src.sentAt ? {
              sentRate: nextRate,
              sentInvest: smartStaking?.isSmartStaking ? smartStaking.totalInvest : count * (parseFloat(nextRate) || 0),
            } : {}),
            ...(isGenuineManualRate ? {} : { manualRate: undefined }),
          };
          if (
            JSON.stringify(src.smartStaking) !== JSON.stringify(updated.smartStaking) ||
            src.r !== updated.r ||
            src.recRate !== updated.recRate ||
            src.prevLoss !== updated.prevLoss ||
            src.targetProfitWithLoss !== updated.targetProfitWithLoss ||
            src.sentRate !== updated.sentRate ||
            src.sentInvest !== updated.sentInvest
          ) {
            dataDict[i] = updated;
            activeRecord = updated;
            changed = true;
          }
        }
      }

      const isProfitCarryActive = Boolean(profile?.config?.profitCarry === true || profile?.profitCarry === true);
      const fallbackSettledRate = activeRecord.r || activeRecord.recRate || calculateRecoveryRate(type, activeRecord.sentDigits || activeRecord.d, activeRecord.prevLoss ?? debt[trackKey], targetProf + (isProfitCarryActive ? (pendingProfits[trackKey] || 0) : 0));
      const actualSettlement = calculateSettlement({
        type,
        digits: activeRecord.sentAt ? (activeRecord.sentDigits || activeRecord.d) : activeRecord.d,
        rate: fallbackSettledRate,
        sentRate: activeRecord.sentAt ? activeRecord.sentRate : undefined,
        sentInvest: activeRecord.sentAt ? activeRecord.sentInvest : undefined,
        smartStaking: activeRecord.smartStaking,
      });

      const recoveryStatus = liveReset && type === 'jodi' && (activeRecord.jodiOpenStatus === 'PASS' || activeRecord.jodiOpenStatus === 'FAIL')
        ? activeRecord.jodiOpenStatus
        : activeRecord.s;

      if (recoveryStatus === 'FAIL') {
        const isProfitCarry = Boolean(profile?.config?.profitCarry === true || profile?.profitCarry === true);
        if (isOpenPassForClose) {
          if (isProfitCarry) {
            pendingProfits[trackKey] = (pendingProfits[trackKey] || 0) + targetProf;
          }
        } else if (actualSettlement.invest > 0) {
          debt[trackKey] += actualSettlement.invest;
          if (isProfitCarry) {
            pendingProfits[trackKey] = (pendingProfits[trackKey] || 0) + targetProf;
          }
          if (liveReset) {
            failures[trackKey] = (failures[trackKey] || 0) + 1;
            if (failures[trackKey] >= 3) {
              debt[trackKey] = 0;
              failures[trackKey] = 0;
              pendingProfits[trackKey] = 0;
            }
          }
        }
        recoveryAssigned[trackKey] = false;
      } else if (recoveryStatus === 'PASS') {
        if (isOpenPassForClose) {
          pendingProfits[trackKey] = 0;
        } else if (actualSettlement.invest > 0) {
          debt[trackKey] = 0;
          failures[trackKey] = 0;
          pendingProfits[trackKey] = 0;
        }
        recoveryAssigned[trackKey] = false;
      } else if (activeRecord.s === 'WAIT' || !activeRecord.s) {
        if (genuinelyDelivered || (!bypassedWait && count > 0 && margin > 0)) {
          recoveryAssigned[trackKey] = true;
        }
      }
    });
  };

  run('ank', nextData, getEffectiveMarkets(profile.config), 9.5, 'ank');
  run('jodi', nextJodi, getEffectiveBaseMarkets(profile.config), 95.0, 'jodi');
  run('pannel', nextPan, getEffectiveMarkets(profile.config), 150.0, 'pan');

  if (!changed) return null;
  return {
    ...day,
    data: nextData,
    jodiData: nextJodi,
    pannelData: nextPan,
  };
}

export function getWeekStats(profile: UserProfile, currDateStr: string) {
  // These are saved calendar dates, not instants in the browser's timezone.
  const d = new Date(`${currDateStr}T00:00:00Z`);
  const day = d.getUTCDay();
  const diff = d.getUTCDate() - day + (day === 0 ? -6 : 1);
  const monday = new Date(d);
  monday.setUTCDate(diff);

  const stats: Record<GameType, Record<string, { rounds: number; pass: number; fail: number; invest: number; win: number }>> = {
    ank: {},
    jodi: {},
    pannel: {}
  };

  BASE_MARKETS.forEach(bm => {
    stats.ank[bm.n] = { rounds: 0, pass: 0, fail: 0, invest: 0, win: 0 };
    stats.jodi[bm.n] = { rounds: 0, pass: 0, fail: 0, invest: 0, win: 0 };
    stats.pannel[bm.n] = { rounds: 0, pass: 0, fail: 0, invest: 0, win: 0 };
  });

  const totals: Record<GameType, { invest: number; win: number; runningPL: number; maxLoss: number; pendingLoss: number }> = {
    ank: { invest: 0, win: 0, runningPL: 0, maxLoss: 0, pendingLoss: 0 },
    jodi: { invest: 0, win: 0, runningPL: 0, maxLoss: 0, pendingLoss: 0 },
    pannel: { invest: 0, win: 0, runningPL: 0, maxLoss: 0, pendingLoss: 0 }
  };

  for (let i = 0; i < 7; i++) {
    const loopDate = new Date(monday);
    loopDate.setUTCDate(monday.getUTCDate() + i);
    const dateStr = loopDate.toISOString().slice(0, 10);
    if (dateStr > currDateStr) break;
    totals.ank.pendingLoss = 0;
    totals.jodi.pendingLoss = 0;
    totals.pannel.pendingLoss = 0;
    const record = profile.dayRecords?.[dateStr];
    if (!record) continue;
    // Backend recovery state resets at each 6-AM business-day boundary.
    const dayTrackDebt: Record<GameType, Record<string, number>> = { ank: {}, jodi: {}, pannel: {} };
    const splitQueues:Record<string,TwoCardRecovery>={};
    const datedProfile=archivedRecoveryProfile(profile,dateStr);

    const processItem = (
      type: GameType,
      dataDict: Record<string, DayMarketRecord> | undefined,
      arr: typeof MARKETS | typeof BASE_MARKETS,
    ) => {
      if (!dataDict) return;
      Object.entries(dataDict).sort((a,b)=>Number(a[0])-Number(b[0])).forEach(([idx, dObj]) => {
        if (!dObj || (dObj.s !== 'PASS' && dObj.s !== 'FAIL')) return;
        // Saved names preserve historical identity after configuration reorders.
        const marketName = dObj.marketName || arr[Number(idx)]?.n;
        if (!marketName) return;
        const isWeekOpenPassCloseZero = Boolean(datedProfile?.config?.openPassCloseZero || datedProfile?.openPassCloseZero);
        if (isWeekOpenPassCloseZero && (type === 'ank' || type === 'pannel') && /\s+CLOSE$/i.test(marketName) && !dObj.sentAt && !(dObj.manualRate && !dObj.manualStatus && Number(dObj.r) > 0)) {
          const oName = `${marketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase()} OPEN`;
          const oIdx = arr.findIndex(item => item.n.trim().toUpperCase() === oName);
          const oRec = oIdx >= 0 ? dataDict[oIdx] : Object.values(dataDict).find(r => String(r?.marketName || '').trim().toUpperCase() === oName);
          if (oRec?.s === 'PASS') return;
        }
        const bmName = marketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();

        const winDigit = dObj.manualResult || dObj.scrapeResultDigit || (/CLOSE/i.test(marketName) ? dObj.backtestResult?.actual?.close : dObj.backtestResult?.actual?.open);
        const settlement = calculateSettlement({
          type,
          digits: dObj.sentAt ? (dObj.sentDigits || dObj.d) : dObj.d,
          rate: dObj.r || dObj.recRate,
          sentRate: dObj.sentAt ? dObj.sentRate : undefined,
          sentInvest: dObj.sentAt ? dObj.sentInvest : undefined,
          smartStaking: dObj.smartStaking,
          winningDigit: winDigit,
        });
        const invest = settlement.invest;
        // A settled zero-invest card (for example an explicitly enabled CLOSE-zero card)
        // is still a completed round and must contribute to PASS/FAIL counts.
        if (settlement.tokenCount <= 0) return;
        stats[type][bmName] ||= { rounds: 0, pass: 0, fail: 0, invest: 0, win: 0 };
        const trackKey = profileFinancialRecoveryTrack(datedProfile,dateStr,type,marketName,dObj);
        const debt = dayTrackDebt[type];
        if (debt[trackKey] === undefined) debt[trackKey] = 0;

        const splitTwo=useRecoveryShareLedger(datedProfile.config,dateStr,type);
        if(splitTwo){
          const queue=splitQueues[trackKey] ||= new TwoCardRecovery();
          const before=queue.debt;
          const frozen=recoveryCardFrozen(dObj)||!dObj.backtestResult||Array.isArray(dObj.twoCardRecoveryShares);
          const legacy=queue.legacySettlement(`${type}_${idx}`,profileLegacyFinancialTrack(datedProfile,dateStr,type,marketName,dObj),dObj.s,invest,frozen,dObj.twoCardRecoveryShares);
          if(!legacy){const shares=recoverySharesForCard(queue,dObj,useTwoCardRecovery(datedProfile.config,dateStr,type),frozen);if(dObj.s==='FAIL')queue.fail(`${type}_${idx}`,invest,shares);}
          debt[trackKey]=queue.debt;
          totals[type].maxLoss=Math.max(totals[type].maxLoss,aggregateTrackDebt(debt),aggregateTrackDebt(debt)-queue.debt+before+invest);
        }
        if (dObj.s === 'FAIL') {
          totals[type].runningPL -= invest;
          if(!splitTwo)debt[trackKey] += invest;
          totals[type].pendingLoss = aggregateTrackDebt(debt);
          totals[type].maxLoss = Math.max(totals[type].maxLoss, totals[type].pendingLoss);
        } else if (dObj.s === 'PASS') {
          totals[type].runningPL += settlement.net;
          totals[type].maxLoss = Math.max(totals[type].maxLoss, aggregateTrackDebt(debt) + invest);
          if(!splitTwo)debt[trackKey] = 0;
          totals[type].pendingLoss = aggregateTrackDebt(debt);
        }

        stats[type][bmName].rounds++;
        stats[type][bmName].invest += invest;
        totals[type].invest += invest;

        if (dObj.s === 'PASS') {
          stats[type][bmName].pass++;
          stats[type][bmName].win += settlement.payout;
          totals[type].win += settlement.payout;
        } else if (dObj.s === 'FAIL') {
          stats[type][bmName].fail++;
        }
      });
    };

    processItem('ank', record.data, getEffectiveMarkets(profile.config));
    processItem('jodi', record.jodiData, getEffectiveBaseMarkets(profile.config));
    processItem('pannel', record.pannelData, getEffectiveMarkets(profile.config));
    if (isFourWaveRelayActive(datedProfile.config, Boolean(dayLoopConfig(datedProfile, dateStr)?.enabled))) {
      for (const gType of ['ank', 'jodi', 'pannel'] as GameType[]) {
        const storeDict = gType === 'ank' ? record.data : gType === 'jodi' ? record.jodiData : record.pannelData;
        if (!storeDict) continue;
        const fw = evaluateFourWaveDay({
          type: gType,
          markets: gType === 'jodi' ? getEffectiveBaseMarkets(datedProfile.config) : getEffectiveMarkets(datedProfile.config),
          store: storeDict,
          cfg: datedProfile.config,
          visDict: gType === 'ank' ? record.visAnk : gType === 'jodi' ? record.visJodi : record.visPan,
          resetEnabled: dateStr < businessDateIST()
            ? record.backtestRecoveryPolicy?.resetAfterThreeFails === true
            : datedProfile.config.liveThreeFailReset === true,
          targetGetter: () => parseFloat(String(datedProfile.config[gType]?.tgt)) || 100,
        });
        totals[gType].pendingLoss = fw.totalPendingLoss;
      }
    }
  }

  return { monday, stats, totals };
}

/**
 * Compact WhatsApp-friendly daily result report: status + market + digits,
 * followed by the same wallet-backed Max Risk and Profit used by Daily Audit.
 */
export function generateNormalDailyReport(
  profile: UserProfile,
  currentDate: string,
  targetTab: 'ank' | 'jodi' | 'pannel' | 'all',
): string {
  const header = formatAuditTextDate(currentDate);
  const reportTitle = `📋 DAILY AUDIT • ${auditGameTitle(targetTab)} • NORMAL`;
  const day = profile?.dayRecords?.[currentDate];
  if (!day) return `${header}\n${renderAuditTextBox(reportTitle, ['⚠️ Aaj ka ledger empty hai!'])}`;

  const cfg = profile.config;
  const tabs: GameType[] = targetTab === 'all' ? ['ank', 'jodi', 'pannel'] : [targetTab];
  const lines: string[] = [];
  let pass = 0;
  let fail = 0;

  tabs.forEach((type) => {
    const markets = type === 'jodi' ? getEffectiveBaseMarkets(cfg) : getEffectiveMarkets(cfg);
    const dictName = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
    const cards = day[dictName] || {};
    Object.entries(cards).forEach(([index, card]) => {
      if (!card || (card.s !== 'PASS' && card.s !== 'FAIL')) return;
      const marketName = card.marketName || markets[Number(index)]?.n;
      if (!marketName) return;
      const value = calculateSettlement({ type, digits: card.sentDigits || card.d, rate: card.r || card.recRate, sentRate: card.sentRate, sentInvest: card.sentInvest });
      if (value.tokenCount <= 0) return;
      if (card.s === 'PASS') pass += 1;
      else fail += 1;
      const status = card.s === 'PASS' ? '✅ PASS' : '❌ FAIL';
      const digits = String(card.sentDigits || card.d || '').trim() || '---';
      lines.push(renderAuditTextBox(`📊 ${marketName}`, [status, ...auditDigitsRows(type, digits)]));
    });
  });

  const total = pass + fail;
  if (!total) {
    return `${header}\n${renderAuditTextBox(reportTitle, ['⏳ Abhi koi PASS/FAIL card nahi hai.'])}\nMera Style Se Play Karo Daily Profit Milega`;
  }

  // Reuse the ledger's single-source-of-truth calculation. This keeps the
  // compact template aligned with Wallet HUD and the detailed Hisab report.
  const financial = tabs.map((type) => calculateProtocolStats(type, profile, currentDate));
  const maxRisk = financial.reduce((peak, stats) => Math.max(peak, stats.maxLoss), 0);
  const profit = financial.reduce((sum, stats) => sum + stats.pl, 0);
  const formatInr = (value: number) => `₹${Math.round(value).toLocaleString('en-IN')}`;

  const summary = renderAuditTextBox(reportTitle, [
    `🧾 TOTAL MARKET - ${total}`,
    `✅ PASSING MARKET - ${pass}`,
    `❌ FAIL MARKET - ${fail}`,
    `⚡ MAX RISK - ${formatInr(maxRisk)}`,
    `💰 PROFIT - ${profit >= 0 ? '+' : '-'}${formatInr(Math.abs(profit))}`,
  ]);
  return `${header}\n\n${lines.join('\n\n')}\n\n${summary}\nMera Style Se Play Karo Daily Profit Milega`;
}

/**
 * Daily Hisab report — clean per-card invest / profit / loss + totals.
 */
export function generateDailyAuditReport(
  profile: UserProfile,
  currentDate: string,
  targetTab: 'ank' | 'jodi' | 'pannel' | 'all',
  _profiles: Record<string, UserProfile>
): string {
  const inr = (n: number) => `₹${Math.round(n).toLocaleString('en-IN')}`;
  if (!profile || !profile.dayRecords || !profile.dayRecords[currentDate]) {
    return `${formatAuditTextDate(currentDate)}\n${renderAuditTextBox(`📋 DAILY AUDIT • ${auditGameTitle(targetTab)}`, ['⚠️ Aaj ka ledger empty hai!'])}`;
  }

  profile=archivedRecoveryProfile(profile,currentDate);
  const record = profile.dayRecords[currentDate];
  const tabsToProcess: GameType[] = targetTab === 'all' ? ['ank', 'jodi', 'pannel'] : [targetTab];
  const cfg = profile.config;

  let totalSpent = 0;
  let totalReturn = 0;
  let overallPass = 0;
  let overallFail = 0;
  const reportTrackDebt: Record<GameType, Record<string, number>> = { ank: {}, jodi: {}, pannel: {} };
  let maxRisk = 0;
  const cards: Array<{ title: string; rows: string[] }> = [];

  tabsToProcess.forEach((gType) => {
    const list = gType === 'jodi' ? getEffectiveBaseMarkets(cfg) : getEffectiveMarkets(cfg);
    const dictName = gType === 'ank' ? 'data' : gType === 'jodi' ? 'jodiData' : 'pannelData';
    const dataDict = record[dictName] || {};
    const isFourWaveAudit = isFourWaveRelayActive(profile.config, Boolean(dayLoopConfig(profile, currentDate)?.enabled));
    const splitTwo=useRecoveryShareLedger(profile.config,currentDate,gType) || isFourWaveAudit;
    if(splitTwo)maxRisk=Math.max(maxRisk,calculateProtocolStats(gType,profile,currentDate).maxLoss);
    Object.entries(dataDict).forEach(([idx, rec]) => {
      if (!rec) return;
      if (rec.s !== 'PASS' && rec.s !== 'FAIL') return;
      const marketName = rec.marketName || list[Number(idx)]?.n;
      if (!marketName) return;

      const digitsStr = String(rec.sentDigits || rec.d || '').trim();
      const winDigit = rec.manualResult || rec.scrapeResultDigit || (/CLOSE/i.test(marketName) ? rec.backtestResult?.actual?.close : rec.backtestResult?.actual?.open);
      const settlement = calculateSettlement({
        type: gType,
        digits: digitsStr,
        rate: rec.r || rec.recRate,
        sentRate: rec.sentAt ? rec.sentRate : undefined,
        sentInvest: rec.sentAt ? rec.sentInvest : undefined,
        smartStaking: rec.smartStaking,
        winningDigit: winDigit,
      });
      const { tokenCount: count, rate: rateVal, invest } = settlement;
      if (count <= 0) return;
      const trackKey = profileFinancialRecoveryTrack(profile,currentDate,gType,marketName,rec);
      const debt = reportTrackDebt[gType];
      if (debt[trackKey] === undefined) debt[trackKey] = 0;

      if (rec.s === 'PASS') {
        overallPass++;
        const payout = settlement.payout;
        const cardNet = settlement.net;
        totalSpent += invest;
        totalReturn += payout;
        if(!splitTwo)maxRisk = Math.max(maxRisk, aggregateTrackDebt(debt) + invest);
        debt[trackKey] = 0;

        cards.push({
          title: `📊 ${marketName}`,
          rows: [
            '✅ PASS',
            ...auditDigitsRows(gType, digitsStr),
            `💰 Rate   : ${inr(rateVal)} × ${count}`,
            `🏆 Return : ${inr(payout)}`,
            `📊 Profit : ${cardNet >= 0 ? '+' : '-'}${inr(Math.abs(cardNet))}`,
          ],
        });
      } else {
        overallFail++;
        totalSpent += invest;
        debt[trackKey] += invest;
        if(!splitTwo)maxRisk = Math.max(maxRisk, aggregateTrackDebt(debt));

        cards.push({
          title: `📊 ${marketName}`,
          rows: [
            '❌ FAIL',
            ...auditDigitsRows(gType, digitsStr),
            `💰 Rate   : ${inr(rateVal)} × ${count}`,
            `📉 Loss   : -${inr(invest)}`,
          ],
        });
      }
    });
  });

  const totalRounds = overallPass + overallFail;
  const finalNet = totalReturn - totalSpent;

  if (totalRounds === 0) {
    return (
      `${formatAuditTextDate(currentDate)}\n\n` +
      `${renderAuditTextBox(`📋 DAILY AUDIT • ${auditGameTitle(targetTab)}`, ['⏳ Abhi koi PASS/FAIL card nahi hai.'])}\n\n` +
      `👑 Mera Style Se Play Karo\n` +
      `📈 Daily Profit Milega`
    );
  }

  const wallets = tabsToProcess.map(type => calculateCapitalWallet(type, record[type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData'] || {}, true));
  const totalRows = [
    `🧾 Total Market : ${totalRounds}`,
    `✅ Total Pass   : ${overallPass}`,
    `❌ Total Fail   : ${overallFail}`,
    `💸 Total Stakes : ${inr(totalSpent)}`,
    `🏆 Total Return : ${inr(totalReturn)}`,
    `👛 Own Capital  : ${inr(wallets.reduce((sum, wallet) => sum + wallet.invested, 0))}`,
    `💳 Wallet       : ${inr(wallets.reduce((sum, wallet) => sum + wallet.balance, 0))}`,
    `⏳ Pending      : ${inr(wallets.reduce((sum, wallet) => sum + wallet.pending, 0))}`,
    `⚡ Max Risk     : ${inr(maxRisk)}`,
    `💰 Profit       : ${finalNet >= 0 ? '+' : '-'}${inr(Math.abs(finalNet))}`,
  ];
  const totalTitle = `📋 TOTAL HISAB • ${auditGameTitle(targetTab)}`;
  const cardBlocks = cards.map((card) => renderAuditTextBox(card.title, card.rows));
  const totalBlock = renderAuditTextBox(totalTitle, totalRows);
  const finalLabel = finalNet >= 0 ? '💰 FINAL PROFIT' : '📉 FINAL LOSS';

  return (
    `${formatAuditTextDate(currentDate)}\n\n` +
    `${cardBlocks.join('\n\n')}\n\n` +
    `${totalBlock}\n\n` +
    `🏆 ${overallPass} PASS • ${overallFail} FAIL\n\n` +
    `${finalLabel} : ${finalNet >= 0 ? '+' : '-'}${inr(Math.abs(finalNet))}\n\n` +
    `👑 Mera Style Se Play Karo\n` +
    `📈 Daily Profit Milega`
  );
}

/**
 * Simple WhatsApp follow-up after result — PASS / FAIL + optional result digit.
 */
export function buildResultFollowUpMessage(opts: {
  marketName: string;
  type: GameType;
  status: 'PASS' | 'FAIL';
  rec?: DayMarketRecord | null;
  config?: ProfileConfigLike;
  /** Drawn result e.g. "6" (ank) or "36" (jodi) or panel "128" */
  resultDigit?: string | null;
  fullResult?: string | null;
  detailedMessage?: boolean;
}): string {
  const { marketName, type, status, rec, config, resultDigit, fullResult, detailedMessage = true } = opts;
  if (!detailedMessage) {
    return buildPremiumResultCard({
      marketName, status, resultDigit, fullResult, detailed: false,
    });
  }
  // Prefer FROZEN schedule-send values so FAIL/PASS matches the WhatsApp card that was sent
  const digitsStr = String(rec?.sentDigits || rec?.d || '').trim();
  const settlement = calculateSettlement({
    type,
    digits: digitsStr,
    rate: parseFloat(getEffectiveCardRate(rec, type, config)) || 0,
    sentRate: rec?.sentRate,
    sentInvest: rec?.sentInvest,
    winningDigit: resultDigit,
    smartStaking: rec?.smartStaking,
  });
  const { invest } = settlement;
  const inr = (n: number) => `₹${Math.round(n).toLocaleString('en-IN')}`;
  if (status === 'PASS') {
    const payout = settlement.payout;
    const net = settlement.net;
    return buildPremiumResultCard({
      marketName, status, resultDigit, fullResult, detailed: true,
      payout: inr(payout),
      net: `${net >= 0 ? '+' : ''}${inr(net)}`,
    });
  }

  return buildPremiumResultCard({
    marketName, status, resultDigit, fullResult, detailed: true,
    loss: inr(invest),
  });
}

/**
 * Resolve the effective rate shown on the card UI.
 * Prefer stored r, then recommended recRate, then type default, then 10.
 * This matches what LedgerCard displays after calculateGlobalStats runs.
 */
export function getEffectiveCardRate(
  rec: DayMarketRecord | undefined | null,
  type: GameType,
  config?: { ankDefaultRate?: string; jodiDefaultRate?: string; pannelDefaultRate?: string }
): string {
  if (rec?.d && !isRecoveryRatePossible(type, rec.d)) return '';
  // V4 SSOT: history must show the frozen delivery rate. A backend-finalized
  // future r must never rewrite what a PASS/FAIL card was actually sent at.
  const frozen = rec?.sentRate != null && String(rec.sentRate).trim() !== '' ? String(rec.sentRate).trim() : '';
  // A sent WAIT card is already financially committed. Show its frozen delivery
  // rate before as well as after PASS/FAIL so UI and settlement can never differ.
  if (frozen && parseFloat(frozen) > 0) return frozen;
  const stored = rec?.r != null && String(rec.r).trim() !== '' ? String(rec.r).trim() : '';
  const recommended = rec?.recRate != null && String(rec.recRate).trim() !== '' ? String(rec.recRate).trim() : '';
  if (stored && parseFloat(stored) > 0) return stored;
  if (recommended && parseFloat(recommended) > 0) return recommended;
  if (type === 'ank' && config?.ankDefaultRate) return String(config.ankDefaultRate);
  if (type === 'jodi' && config?.jodiDefaultRate) return String(config.jodiDefaultRate);
  if (type === 'pannel' && config?.pannelDefaultRate) return String(config.pannelDefaultRate);
  return '10';
}

/**
 * Card message for WhatsApp.
 * mode 'customer' (default) = simple play info customers understand.
 * mode 'full' = internal ledger detail for admin copy/audit.
 * Rate always matches UI via getEffectiveCardRate.
 */
export function buildCardIntelMessage(opts: {
  marketName: string;
  type: GameType;
  rec?: DayMarketRecord | null;
  config?: ProfileConfigLike;
  includeFooter?: boolean;
  mode?: 'customer' | 'full';
  detailedMessage?: boolean;
  cardDate?: string;
}): string {
  const { marketName, type, rec, config, includeFooter = true, mode = 'customer', detailedMessage = true, cardDate } = opts;
  const digitsStr = rec?.d ? String(rec.d).trim() : '';
  const count = digitsStr ? digitsStr.split(/[, ]+/).filter((x) => x.trim()).length : 0;
  const rateVal = getEffectiveCardRate(rec, type, config);
  const rateNum = parseFloat(rateVal) || 0;
  const invest = count * rateNum;

  if (!detailedMessage) {
    return buildPremiumPlayCard({
      marketName, digits: digitsStr, type, detailed: false, date: cardDate,
    });
  }

  // Customer-friendly WhatsApp card (ONLY this goes to customers)
  if (mode !== 'full') {
    return buildPremiumPlayCard({
      marketName, digits: digitsStr, type, detailed: true, rate: rateVal, total: rec?.smartStaking?.isSmartStaking ? rec.smartStaking.totalInvest : invest, date: cardDate, smartStaking: rec?.smartStaking,
    });
  }

  // Full internal Intel (admin)
  const status = (rec?.s || 'WAIT').toUpperCase();
  const trick = rec?.trick ? String(rec.trick) : '';
  const prevLoss = typeof rec?.prevLoss === 'number' ? rec.prevLoss : 0;
  const targetWithLoss = typeof rec?.targetProfitWithLoss === 'number' ? rec.targetProfitWithLoss : 0;
  const schTime = rec?.schTime ? String(rec.schTime).trim() : '';
  const typeLabel = type === 'ank' ? 'ANK' : type === 'jodi' ? 'JODI' : 'PANEL';

  let msg = `📊 *${marketName}*`;
  msg += `\n🏷️ Type: ${typeLabel}`;
  msg += `\n📝 Status: *${status}*`;
  if (trick) msg += `\n✨ Trick: ${trick}`;
  msg += `\n🎯 Digits: ${digitsStr || '---'}`;
  msg += `\n🔢 Count: ${count}`;
  msg += `\n💰 Rate: ₹${rateVal} / digit`;
  msg += `\n💵 Total Invest: ₹${invest.toLocaleString('en-IN')}`;
  if (prevLoss > 0) {
    msg += `\n📉 Prev Loss (debt): ₹${prevLoss.toLocaleString('en-IN')}`;
  }
  if (targetWithLoss > 0) {
    msg += `\n🎯 Target (with loss): ₹${Math.round(targetWithLoss).toLocaleString('en-IN')}`;
  }
  if (schTime) {
    msg += `\n⏰ Schedule: ${schTime}`;
  }
  if (includeFooter) {
    msg += `\n━━━━━━━━━━━━━━━━━━━━━`;
    msg += `\n📲 *Titan Nova — Live Card Intel*`;
  }
  return msg;
}

// Minimal config shape to avoid circular import issues
type ProfileConfigLike = {
  ankDefaultRate?: string;
  jodiDefaultRate?: string;
  pannelDefaultRate?: string;
};

// ─── Result parse + Pass/Fail audit engine ───────────────────────────────────

export interface ParsedMarketResult {
  raw: string;
  marketBase: string;       // e.g. "KALYAN"
  marketHint: string;       // full matched phrase if any
  session: 'OPEN' | 'CLOSE' | 'FULL';
  openPanel: string;
  openAnk: string;
  jodi: string;
  closeAnk: string;
  closePanel: string;
}

export interface AuditUpdate {
  type: GameType;
  index: number;
  marketName: string;
  status: 'PASS' | 'FAIL';
  winning: string;
  digits: string;
}

/** Normalize ank digit to single 0-9 char */
function normAnk(d: string): string {
  const s = String(d || '').replace(/\D/g, '');
  if (!s) return '';
  return s.length === 1 ? s : s[s.length - 1]; // last digit if multi
}

/** Normalize jodi to 2-digit string */
function normJodi(d: string): string {
  const s = String(d || '').replace(/\D/g, '');
  if (s.length >= 2) return s.slice(0, 2);
  if (s.length === 1) return `0${s}`;
  return '';
}

/** Normalize panel — sorted digits so 182 == 128 */
function normPanel(d: string): string {
  const s = String(d || '').replace(/\D/g, '');
  if (s.length < 3) return s;
  return s.slice(0, 3).split('').sort().join('');
}

/**
 * Parse free-text WhatsApp / chart result into structured fields.
 * Handles: "KALYAN 123-45-678", "KALYAN OPEN 123-4", "KALYAN CLOSE 5-678", etc.
 * Ignores schedule-card noise (Rate/Total) and does NOT greedily grab any 2-digit number.
 */
export function parseMarketResultText(textRaw: string): ParsedMarketResult {
  const raw = String(textRaw || '').trim();
  // Strip schedule-card lines so Rate/Total/Digits don't poison parsing
  const cleanedLines = raw
    .split(/\n/)
    .filter((ln) => !/^\s*(digits|rate|total|return|net|loss|played)\s*:/i.test(ln))
    .join(' ');
  // Strip WhatsApp markdown stars: *SRIDEVI* *466-65-249* → SRIDEVI 466-65-249
  const upper = cleanedLines
    .toUpperCase()
    .replace(/[–—]/g, '-')
    .replace(/\*/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  // Longest market name match first (KALYAN NIGHT before KALYAN)
  const allNames = [
    ...MARKETS.map((m) => m.n.toUpperCase()),
    ...BASE_MARKETS.map((m) => m.n.toUpperCase()),
  ].sort((a, b) => b.length - a.length);

  let marketHint = '';
  for (const name of allNames) {
    if (upper.includes(name)) {
      marketHint = name;
      break;
    }
  }

  // Base without OPEN/CLOSE — longest names first so NIGHT/DAY never collapse to bare name
  let marketBase = marketHint.replace(/\s+(OPEN|CLOSE)$/i, '').trim();
  if (marketBase === 'SRIDEVI' && marketHint === 'SRIDEVI' && /\bNIGHT\b/.test(upper) && !/\bDAY\b/.test(upper)) {
    marketBase = 'SRIDEVI NIGHT';
  }
  if (!marketBase) {
    const bases = [
      'SRIDEVI NIGHT', 'SRIDEVI DAY', 'SRIDEV NIGHT', 'SRIDEV DAY', 'SHRIDEVI NIGHT', 'SHRIDEVI DAY',
      'MADHUR NIGHT', 'MADHUR DAY',
      'MILAN NIGHT', 'MILAN DAY', 'RAJDHANI NIGHT', 'RAJDHANI DAY',
      'SUPREME NIGHT', 'SUPREME DAY', 'KALYAN NIGHT', 'TIME BAZAR',
      'MAIN BAZAR', 'KALYAN',
      // bare names ONLY if no DAY/NIGHT sibling word in text
      'SRIDEVI', 'SRIDEV', 'SHRIDEVI', 'MADHUR', 'MILAN', 'RAJDHANI', 'SUPREME',
    ];
    for (const b of bases) {
      if (!upper.includes(b)) continue;
      // Bare "SRIDEVI" must not win when text also has NIGHT or DAY qualifier nearby
      if (b === 'SRIDEVI' || b === 'SRIDEV' || b === 'SHRIDEVI' || b === 'MADHUR' || b === 'MILAN' || b === 'RAJDHANI' || b === 'SUPREME') {
        if (upper.includes(b + ' NIGHT') || upper.includes(b + ' DAY')) continue;
        if (/\bNIGHT\b/.test(upper) && !/\bDAY\b/.test(upper)) {
          // prefer night variant if only night context
          const nightName = `${b} NIGHT`;
          if (bases.includes(nightName) || true) {
            marketBase = nightName;
            break;
          }
        }
      }
      marketBase = b;
      break;
    }
  }
  // Normalize aliases
  if (marketBase === 'SRIDEV NIGHT' || marketBase === 'SHRIDEVI NIGHT') marketBase = 'SRIDEVI NIGHT';
  if (marketBase === 'SRIDEVI DAY' || marketBase === 'SRIDEV DAY' || marketBase === 'SHRIDEVI DAY' || marketBase === 'SRIDEV' || marketBase === 'SHRIDEVI') marketBase = 'SRIDEVI';

  // Bare family names resolve only after that market's actual NIGHT start time.
  marketBase = resolveAmbiguousMarketByIST(marketBase);

  let openPanel = '';
  let openAnk = '';
  let jodi = '';
  let closeAnk = '';
  let closePanel = '';
  let session: 'OPEN' | 'CLOSE' | 'FULL' = 'FULL';

  const structural = extractResultNumbers(raw);
  if (structural) {
    ({ openPanel, openAnk, jodi, closeAnk, closePanel, session } = structural);
  }

  // Prefer the LAST full result in the message (latest declaration)
  const fullAll = structural ? [] : [...upper.matchAll(/(\d{3})\s*[-:]\s*(\d{2})\s*[-:]\s*(\d{3})/g)];
  const fullMatch = fullAll.length ? fullAll[fullAll.length - 1] : null;
  if (fullMatch) {
    openPanel = fullMatch[1];
    openAnk = fullMatch[2][0];
    closeAnk = fullMatch[2][1];
    jodi = fullMatch[2];
    closePanel = fullMatch[3];
    session = 'FULL';
  } else if (!structural) {
    // Spaced form: 123 45 678
    const spacedAll = [...upper.matchAll(/\b(\d{3})\s+(\d{2})\s+(\d{3})\b/g)];
    const spaced = spacedAll.length ? spacedAll[spacedAll.length - 1] : null;
    if (spaced) {
      openPanel = spaced[1];
      openAnk = spaced[2][0];
      closeAnk = spaced[2][1];
      jodi = spaced[2];
      closePanel = spaced[3];
      session = 'FULL';
    } else {
      const openAll = [...upper.matchAll(/(\d{3})\s*[-:]\s*(\d)\b/g)];
      const openMatch = openAll.length ? openAll[openAll.length - 1] : null;
      if (openMatch) {
        openPanel = openMatch[1];
        openAnk = openMatch[2];
        session = 'OPEN';
      }
      const closeAll = [...upper.matchAll(/\b(\d)\s*[-:]\s*(\d{3})\b/g)];
      const closeMatch = closeAll.length ? closeAll[closeAll.length - 1] : null;
      if (closeMatch) {
        closeAnk = closeMatch[1];
        closePanel = closeMatch[2];
        session = openAnk ? 'FULL' : 'CLOSE';
      }
      // Jodi ONLY from explicit "jodi" label or xx between panels — never any random 2-digit
      if (!jodi && openAnk && closeAnk) {
        jodi = `${openAnk}${closeAnk}`;
      } else if (!jodi) {
        const jodiLabel = upper.match(/JODI\s*[:\-]?\s*(\d{2})\b/);
        if (jodiLabel) {
          jodi = jodiLabel[1];
          if (!openAnk) openAnk = jodi[0];
          if (!closeAnk) closeAnk = jodi[1];
        }
      }
    }
  }

  // Plain forms: "KALYAN OPEN 6" / "OPEN : 6"
  if (!openAnk) {
    const openPlain = upper.match(/\bOPEN\b[^0-9]{0,12}(\d)\b/);
    if (openPlain) {
      openAnk = openPlain[1];
      if (!fullMatch) session = 'OPEN';
    }
  }
  if (!closeAnk) {
    const closePlain = upper.match(/\bCLOSE\b[^0-9]{0,12}(\d)\b/);
    if (closePlain) {
      closeAnk = closePlain[1];
      if (!fullMatch) session = openAnk ? 'FULL' : 'CLOSE';
    }
  }
  if (!openAnk && !closeAnk && marketBase) {
    const after = upper.split(marketBase)[1] || '';
    const lone = after.match(/\b(\d)\b/);
    if (lone) {
      if (upper.includes('CLOSE') && !upper.includes('OPEN')) {
        closeAnk = lone[1];
        session = 'CLOSE';
      } else {
        openAnk = lone[1];
        session = upper.includes('CLOSE') ? 'FULL' : 'OPEN';
      }
    }
  }

  if (openAnk && closeAnk) jodi = `${openAnk}${closeAnk}`;

  // Session override from text keywords (when not a full 3-part result)
  if (!fullMatch) {
    if (upper.includes('CLOSE') && !upper.includes('OPEN')) session = 'CLOSE';
    else if (upper.includes('OPEN') && !upper.includes('CLOSE')) session = 'OPEN';
  }

  return {
    raw,
    marketBase: marketBase || marketHint || '',
    marketHint,
    session,
    openPanel,
    openAnk,
    jodi,
    closeAnk,
    closePanel,
  };
}

function cardTokens(digitsStr: string): string[] {
  return String(digitsStr || '')
    .split(/[,|\s]+/)
    .map((x) => x.trim())
    .filter(Boolean);
}

function ankHit(cardDigits: string, winning: string): boolean {
  const w = normAnk(winning);
  if (!w) return false;
  return cardTokens(cardDigits).some((t) => normAnk(t) === w);
}

function jodiHit(cardDigits: string, winning: string): boolean {
  const w = normJodi(winning);
  if (!w) return false;
  return cardTokens(cardDigits).some((t) => normJodi(t) === w);
}

function panelHit(cardDigits: string, winning: string): boolean {
  const w = normPanel(winning);
  if (!w || w.length < 3) return false;
  return cardTokens(cardDigits).some((t) => normPanel(t) === w);
}

/**
 * Strict market identity — SRIDEVI ≠ SRIDEVI NIGHT ≠ KALYAN ≠ KALYAN NIGHT.
 * No loose includes() that lets short names hit sibling markets.
 */
export function marketsEqual(resultBase: string, cardName: string): boolean {
  const rb = String(resultBase || '')
    .toUpperCase()
    .replace(/\s+(OPEN|CLOSE)$/i, '')
    .replace(/\s+/g, ' ')
    .trim();
  const cb = String(cardName || '')
    .toUpperCase()
    .replace(/\s+(OPEN|CLOSE)$/i, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!rb || !cb) return false;

  // Alias normalize
  const norm = (s: string) =>
    s
      .replace(/^(?:SHRIDEVI|SRIDEVI|SRIDEV)\s+DAY\b/, 'SRIDEVI')
      .replace(/^SRIDEV\b/, 'SRIDEVI')
      .replace(/^SHRIDEVI\b/, 'SRIDEVI')
      .trim();
  const a = norm(rb);
  const b = norm(cb);
  if (a === b) return true;

  // Bare "KALYAN" matches only exact KALYAN (not KALYAN NIGHT)
  // Bare "SRIDEVI" matches nothing with DAY/NIGHT — must be exact after norm
  return false;
}

/**
 * Compute PASS/FAIL updates for a day store given a parsed result.
 * Uses getEffectiveMarkets indices (must match UI card indices).
 * - FULL session → marks both OPEN and CLOSE cards when present
 * - Only WAIT cards are updated
 * - Digit match is normalized (ank/jodi/panel)
 */
export function computePassFailUpdates(
  result: ParsedMarketResult,
  dayStore: {
    data?: Record<string, DayMarketRecord>;
    jodiData?: Record<string, DayMarketRecord>;
    pannelData?: Record<string, DayMarketRecord>;
  },
  config: any
): AuditUpdate[] {
  const updates: AuditUpdate[] = [];
  if (!result.marketBase) return updates;

  const effective = getEffectiveMarkets(config);
  const effectiveBase = getEffectiveBaseMarkets(config);
  const baseUpper = result.marketBase.toUpperCase();

  const session = result.session;
  const markOpen = session === 'OPEN' || session === 'FULL';
  const markClose = session === 'CLOSE' || session === 'FULL';

  // ── ANK ──
  effective.forEach((m, idx) => {
    const n = m.n.toUpperCase();
    if (!marketsEqual(baseUpper, n)) return;
    if (n.includes('OPEN') && !markOpen) return;
    if (n.includes('CLOSE') && !markClose) return;
    // If market name has neither OPEN nor CLOSE, treat as single session card
    const isOpenCard = n.includes('OPEN');
    const isCloseCard = n.includes('CLOSE');
    if (isOpenCard && !markOpen) return;
    if (isCloseCard && !markClose) return;

    const rec = dayStore.data?.[idx];
    if (!rec || !rec.d) return;
    if (rec.s === 'PASS' || rec.s === 'FAIL' || rec.s === 'SKIP') return;
    if (config?.openPassCloseZero && isCloseCard && !rec.sentAt && !(rec.manualRate && !rec.manualStatus && Number(rec.r) > 0)) {
      const oName = `${n.replace(/\s+(OPEN|CLOSE)$/i, '').trim()} OPEN`;
      const oIdx = effective.findIndex(item => item.n.trim().toUpperCase() === oName);
      const oRec = oIdx >= 0 ? dayStore.data?.[oIdx] : Object.values(dayStore.data || {}).find((r: any) => String(r?.marketName || '').trim().toUpperCase() === oName);
      if (oRec?.s === 'PASS') return;
    }

    const winning = isCloseCard
      ? (result.closeAnk || result.openAnk)
      : (result.openAnk || result.closeAnk);
    if (!winning) return;

    const isHit = ankHit(rec.d, winning);
    const status: 'PASS' | 'FAIL' = isHit ? 'PASS' : 'FAIL';
    updates.push({
      type: 'ank',
      index: idx,
      marketName: m.n,
      status,
      winning: normAnk(winning),
      digits: rec.d,
    });
  });

  // ── JODI (base markets only; needs both ank for full jodi) ──
  if (result.jodi || (result.openAnk && result.closeAnk)) {
    const winningJodi = result.jodi || `${result.openAnk}${result.closeAnk}`;
    effectiveBase.forEach((bm, idx) => {
      const n = bm.n.toUpperCase();
      if (!marketsEqual(baseUpper, n)) return;
      const rec = dayStore.jodiData?.[idx];
      if (!rec || !rec.d) return;
      if (rec.s === 'PASS' || rec.s === 'FAIL' || rec.s === 'SKIP') return;

      const isHit = jodiHit(rec.d, winningJodi);
      const status: 'PASS' | 'FAIL' = isHit ? 'PASS' : 'FAIL';
      updates.push({
        type: 'jodi',
        index: idx,
        marketName: bm.n,
        status,
        winning: normJodi(winningJodi),
        digits: rec.d,
      });
    });
  }

  if(markOpen&&result.openAnk&&!result.jodi&&!result.closeAnk){
    effectiveBase.forEach((bm,idx)=>{const rec=dayStore.jodiData?.[idx];
      if(!marketsEqual(baseUpper,bm.n)||!rec||rec.s!=='WAIT'||jodiOpenSideStatus(rec.sentDigits||rec.d,result.openAnk)!=='FAIL')return;
      updates.push({type:'jodi',index:idx,marketName:bm.n,status:'FAIL',winning:`OPEN ${result.openAnk}`,digits:rec.sentDigits||rec.d});
    });
  }

  // ── PANEL ──
  effective.forEach((m, idx) => {
    const n = m.n.toUpperCase();
    if (!marketsEqual(baseUpper, n)) return;
    const isOpenCard = n.includes('OPEN');
    const isCloseCard = n.includes('CLOSE');
    if (isOpenCard && !markOpen) return;
    if (isCloseCard && !markClose) return;

    const rec = dayStore.pannelData?.[idx];
    if (!rec || !rec.d) return;
    if (rec.s === 'PASS' || rec.s === 'FAIL' || rec.s === 'SKIP') return;
    if (config?.openPassCloseZero && isCloseCard && !rec.sentAt && !(rec.manualRate && !rec.manualStatus && Number(rec.r) > 0)) {
      const oName = `${n.replace(/\s+(OPEN|CLOSE)$/i, '').trim()} OPEN`;
      const oIdx = effective.findIndex(item => item.n.trim().toUpperCase() === oName);
      const oRec = oIdx >= 0 ? dayStore.pannelData?.[oIdx] : Object.values(dayStore.pannelData || {}).find((r: any) => String(r?.marketName || '').trim().toUpperCase() === oName);
      if (oRec?.s === 'PASS') return;
    }

    const winning = isCloseCard
      ? (result.closePanel || result.openPanel)
      : (result.openPanel || result.closePanel);
    if (!winning) return;

    const isHit = panelHit(rec.d, winning);
    const status: 'PASS' | 'FAIL' = isHit ? 'PASS' : 'FAIL';
    updates.push({
      type: 'pannel',
      index: idx,
      marketName: m.n,
      status,
      winning: normPanel(winning),
      digits: rec.d,
    });
  });

  return updates;
}

/**
 * Apply audit statuses into a dayStore copy. Rate assignment is handled only
 * by applyAutoRatesToDayStore after the batch is committed.
 */
export function applyAuditUpdatesToDayStore(
  dayStore: any,
  updates: AuditUpdate[],
  _config: any
): any {
  const store = {
    ...dayStore,
    data: { ...(dayStore.data || {}) },
    jodiData: { ...(dayStore.jodiData || {}) },
    pannelData: { ...(dayStore.pannelData || {}) },
  };

  updates.forEach((u) => {
    const dictName = u.type === 'ank' ? 'data' : u.type === 'jodi' ? 'jodiData' : 'pannelData';
    const dict = { ...store[dictName] };
    const rec = { ...(dict[u.index] || { s: 'WAIT', d: '', r: '' }) };
    rec.s = u.status;
    dict[u.index] = rec;

    store[dictName] = dict;
  });

  return store;
}
