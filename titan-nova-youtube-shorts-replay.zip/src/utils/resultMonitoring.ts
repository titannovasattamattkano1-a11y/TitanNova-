export interface MonitorResultShape {
  marketBase?: string;
  session?: 'OPEN' | 'CLOSE' | 'FULL' | string;
  openPanel?: string;
  openAnk?: string;
  jodi?: string;
  closeAnk?: string;
  closePanel?: string;
}

export type ResultStage = 'OPEN_ONLY' | 'FULL' | 'CLOSE_ONLY' | 'UNKNOWN';

export interface ExtractedResultNumbers {
  session: 'OPEN' | 'CLOSE' | 'FULL';
  openPanel: string;
  openAnk: string;
  jodi: string;
  closeAnk: string;
  closePanel: string;
}

/**
 * Template-independent numeric result extractor shared by UI and backend.
 * Decorative WhatsApp headings/emojis/markdown are intentionally ignored.
 */
export function extractResultNumbers(textRaw: string): ExtractedResultNumbers | null {
  const text = String(textRaw || '')
    .toUpperCase()
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .replace(/[–—−]/g, '-')
    .replace(/\*/g, ' ');

  // Primary strategy: understand digit groups on each line instead of a fixed
  // publisher template. Thus 690-56-349, 690/56/349, 690 : 56 : 349 and
  // "Result 690 56 349" are equivalent. Read bottom-up because forwarded
  // messages can contain an older quoted result above the latest declaration.
  const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  for (let i = lines.length - 1; i >= 0; i--) {
    const groups = lines[i].match(/\d+/g) || [];
    for (let p = groups.length - 3; p >= 0; p--) {
      if (groups[p].length === 3 && groups[p + 1]?.length === 2 && groups[p + 2]?.length === 3) {
        const pair = groups[p + 1];
        return {
          session: 'FULL', openPanel: groups[p], openAnk: pair[0], jodi: pair,
          closeAnk: pair[1], closePanel: groups[p + 2],
        };
      }
    }
    for (let p = groups.length - 2; p >= 0; p--) {
      if (groups[p].length === 3 && groups[p + 1]?.length === 1) {
        return {
          session: 'OPEN', openPanel: groups[p], openAnk: groups[p + 1],
          jodi: '', closeAnk: '', closePanel: '',
        };
      }
      if (groups[p].length === 1 && groups[p + 1]?.length === 3) {
        return {
          session: 'CLOSE', openPanel: '', openAnk: '', jodi: '',
          closeAnk: groups[p], closePanel: groups[p + 1],
        };
      }
    }
  }

  // Fallback for a result whose digit groups were split over line boundaries.
  const full = [...text.matchAll(/(?:^|\D)(\d{3})\s*[-:]\s*(\d{2})\s*[-:]\s*(\d{3})(?=\D|$)/g)].pop();
  if (full) {
    return {
      session: 'FULL', openPanel: full[1], openAnk: full[2][0], jodi: full[2],
      closeAnk: full[2][1], closePanel: full[3],
    };
  }

  const spaced = [...text.matchAll(/(?:^|\D)(\d{3})\s+(\d{2})\s+(\d{3})(?=\D|$)/g)].pop();
  if (spaced) {
    return {
      session: 'FULL', openPanel: spaced[1], openAnk: spaced[2][0], jodi: spaced[2],
      closeAnk: spaced[2][1], closePanel: spaced[3],
    };
  }

  const open = [...text.matchAll(/(?:^|\D)(\d{3})\s*[-:]\s*(\d)(?=\D|$)/g)].pop();
  if (open) {
    return { session: 'OPEN', openPanel: open[1], openAnk: open[2], jodi: '', closeAnk: '', closePanel: '' };
  }

  const close = [...text.matchAll(/(?:^|\D)(\d)\s*[-:]\s*(\d{3})(?=\D|$)/g)].pop();
  if (close) {
    return { session: 'CLOSE', openPanel: '', openAnk: '', jodi: '', closeAnk: close[1], closePanel: close[2] };
  }
  return null;
}

const NIGHT_START_MINUTES: Record<string, number> = {
  SRIDEVI: 19 * 60,
  MADHUR: 20 * 60 + 30,
  SUPREME: 20 * 60 + 45,
  MILAN: 21 * 60,
  RAJDHANI: 21 * 60 + 35,
};

/** Resolve a bare DAY/NIGHT family only when its real NIGHT session has begun. */
export function resolveAmbiguousMarketByIST(base: string, now?: Date): string {
  const normalized = String(base || '')
    .toUpperCase()
    .trim()
    .replace(/\s+/g, ' ')
    .replace(/^(?:SHRIDEVI|SRIDEV)\b/, 'SRIDEVI');
  // SRIDEVI is the official daytime market identity; never emit SRIDEVI DAY.
  // Explicit SRIDEVI NIGHT remains distinct, and when no explicit clock override
  // is supplied, canonical SRIDEVI stays SRIDEVI even after 19:00 IST.
  if (normalized === 'SRIDEVI DAY') return 'SRIDEVI';
  if (normalized === 'SRIDEVI' && now === undefined) return 'SRIDEVI';
  if (!normalized || /\b(DAY|NIGHT)\b/.test(normalized)) return normalized;
  const nightStart = NIGHT_START_MINUTES[normalized];
  if (nightStart === undefined) return normalized;
  const effectiveNow = now ?? new Date();
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
  }).formatToParts(effectiveNow);
  const hour = Number(parts.find((part) => part.type === 'hour')?.value || 0);
  const minute = Number(parts.find((part) => part.type === 'minute')?.value || 0);
  return hour * 60 + minute >= nightStart ? `${normalized} NIGHT`
    : normalized === 'SRIDEVI' ? 'SRIDEVI' : `${normalized} DAY`;
}

export function classifyResultStage(result: MonitorResultShape): ResultStage {
  const hasOpen = Boolean(result.openPanel && result.openAnk);
  const hasFull = Boolean(result.openPanel && result.jodi && result.closePanel);
  const hasClose = Boolean(result.closeAnk && result.closePanel);

  if (hasFull || result.session === 'FULL' && result.openAnk && result.closeAnk && result.closePanel) {
    return 'FULL';
  }
  if (hasOpen && !result.closeAnk && !result.closePanel && !result.jodi) {
    return 'OPEN_ONLY';
  }
  if (hasClose && !result.openAnk && !result.openPanel && !result.jodi) {
    return 'CLOSE_ONLY';
  }
  return 'UNKNOWN';
}

export function resultMergeKey(businessDate: string, result: MonitorResultShape): string {
  return `${String(businessDate || '').trim()}|${String(result.marketBase || '').toUpperCase().trim()}`;
}

export function resultSignature(result: MonitorResultShape): string {
  const stage = classifyResultStage(result);
  return [
    stage,
    result.marketBase || '',
    result.openPanel || '',
    result.openAnk || '',
    result.jodi || '',
    result.closeAnk || '',
    result.closePanel || '',
  ].join('|').toUpperCase();
}
