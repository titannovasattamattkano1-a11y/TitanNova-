import {evaluateLoopAccounts} from './loopAccounts';
import {businessDateIST} from './businessDate';
import {useRecoveryShareLedger,useTwoCardRecovery,replayTwoCardRecovery} from './twoCardRecovery';
import {archivedRecoveryProfile} from './archiveRecoverySnapshot';
import type { GameType, UserProfile } from '../types';
import {buildFinancialLedger,isRecordedPlay} from './financialHistory';
import {recoveryMarketOrder} from './recoveryMarketOrder';
import { calculateProtocolStats } from './calculator';
import { calculateSettlement } from './settlement';
import { jodiOpenSideStatus } from './recoveryLedger';
import { assignedLoop, dayLoopConfig, activeLoopIds, profileFinancialRecoveryTrack,gameAccountLimits } from './dualLoops';
/** A wallet reports one game only; other games cannot fund or stop it. */
export function calculateLoopWallets(profile: UserProfile,date: string,selectedType:GameType='ank') {
  const originalProfile=profile,catalog=profile.config;
  profile=archivedRecoveryProfile(profile,date);
  const config=dayLoopConfig(profile,date);if(!config)return [];
  const day=profile.dayRecords[date],{cards,markets}=buildFinancialLedger(profile,date,catalog);
  const accounts=config.independentAccounts?evaluateLoopAccounts(config,{cards,markets},date,day?.loopAccountStops,{liveOnly:date===businessDateIST()}).states:undefined;
  return activeLoopIds(config).map(id=>{
    const protocols={ank:calculateProtocolStats('ank',originalProfile,date,id),jodi:calculateProtocolStats('jodi',originalProfile,date,id),pannel:calculateProtocolStats('pannel',originalProfile,date,id)};
    const debt:Record<GameType,number>={ank:0,jodi:0,pannel:0};let pendingInvest=0;
    for(const type of ['ank','jodi','pannel'] as GameType[]){
      const members=recoveryMarketOrder(markets.filter(m=>m.type===type));
      members.forEach(m=>{
        const rec=cards[`${type}_${m.index}`];if(!rec||assignedLoop(config,type,m.n,rec)!==id||rec.s==='SKIP')return;
        if(!m.enabled&&!isRecordedPlay(rec))return;
        const winDigit = rec.manualResult || rec.scrapeResultDigit || (/CLOSE/i.test(m.n) ? rec.backtestResult?.actual?.close : rec.backtestResult?.actual?.open);
        const stake=calculateSettlement({type,digits:rec.sentAt?(rec.sentDigits||rec.d):rec.d,rate:rec.r||rec.recRate,sentRate:rec.sentAt?rec.sentRate:undefined,sentInvest:rec.sentAt?rec.sentInvest:undefined,smartStaking:rec.smartStaking,winningDigit:winDigit});
        if(stake.invest<=0)return;
        const fullStatus=rec.s;
        if(type===selectedType&&fullStatus==='WAIT'&&(rec.sentDigits||rec.sentRate||rec.dispatchState==='SENT'))pendingInvest+=stake.invest;
        let recoveryStatus=fullStatus;
        if(type==='jodi'){
          const actual=rec.backtestResult?.digits===rec.d&&rec.backtestResult.checked?(rec.backtestResult.openActual||rec.backtestResult.actual?.[0]):undefined;
          const openStatus=actual?jodiOpenSideStatus(rec.sentDigits||rec.d,actual):rec.backtestResult?undefined:rec.jodiOpenStatus;
          if(openStatus)recoveryStatus=openStatus;
        }
        if(recoveryStatus==='FAIL')debt[type]+=stake.invest;else if(recoveryStatus==='PASS')debt[type]=0;
      });
      if(useRecoveryShareLedger(profile.config,date,type)){
        const eligible=Object.fromEntries(members.flatMap(m=>{const key=`${type}_${m.index}`,r=cards[key];return r&&(m.enabled||isRecordedPlay(r))?[[key,r]]:[];}));
        debt[type]=replayTwoCardRecovery(type,members,eligible,`${id}:${type}:ALL`,name=>{
          const market=members.find(m=>m.n===name);
          return profileFinancialRecoveryTrack(profile,date,type,name,market?cards[`${type}_${market.index}`]:undefined);
        },Infinity,{split:useTwoCardRecovery(profile.config,date,type),legacySplit:profile.config.twoCardRecoveryLegacySplit?.[type as 'ank'|'pannel']??(type==='ank'?profile.config.ankSplit!==false:profile.config.panSplit!==false)}).debt;
      }
    }
    const pl=protocols[selectedType].pl,spent=protocols[selectedType].spent;
    const account=accounts?.find(a=>a.id===id&&a.type===selectedType),limits=gameAccountLimits(config.loops[id],selectedType);
    return {id,type:selectedType,name:config.loops[id].name||id,status:account?.reason||'ACTIVE',capital:limits.capital,dayTarget:limits.dayTarget,targets:{ank:config.loops[id].ank.tgt,jodi:config.loops[id].jodi.tgt,pannel:config.loops[id].pannel.tgt},
      pl:account?.profit??pl,spent:account?.spent??spent,debt,pendingInvest:account?.pending??pendingInvest,availableCapital:account?.available??limits.capital+pl-pendingInvest,protocols};
  });
}
