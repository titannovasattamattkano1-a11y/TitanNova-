export type PremiumPlayCardOptions = {
  marketName: string;
  digits: string;
  type?: 'ank' | 'jodi' | 'pannel' | 'panel';
  detailed: boolean;
  rate?: string | number;
  total?: string | number;
  date?: string;
  smartStaking?: import('./settlement').SmartStakingInfo;
};

export type PremiumResultCardOptions = {
  marketName: string;
  status: 'PASS' | 'FAIL';
  resultDigit?: string | null;
  fullResult?: string | null;
  detailed: boolean;
  payout?: string;
  net?: string;
  loss?: string;
};

/**
 * Telegram/WhatsApp-safe premium text card.
 *
 * Keep this formatter transport-agnostic: WhatsApp renders *bold* itself and
 * telegram-gateway.ts converts the same *bold* spans into Telegram entities.
 * Unicode box characters are plain text, so no HTML/Markdown parse mode is
 * required and the same payload can be queued for both transports.
 */
export function buildPremiumPlayCard(opts: PremiumPlayCardOptions): string {
  const marketName = normalizeLabel(opts.marketName || 'CARD');
  const digits = String(opts.digits || '').trim() || '---';
  const rows = buildPlayRows(opts.type, digits);

  if (opts.detailed) {
    rows.push(`💰 Rate: ₹${formatNumberLike(opts.rate)}`);
    rows.push(`💵 Total: ₹${formatNumberLike(opts.total)}`);
  }

  // Only the outgoing PLAY text card changes. Result/follow-up formatting,
  // business calculations and transport routing remain untouched.
  return renderPlayCardBox(`📊 ${marketName}`, rows, formatCardDate(opts.date));
}

export function buildPremiumResultCard(opts: PremiumResultCardOptions): string {
  const marketName = normalizeLabel(opts.marketName || 'CARD');
  const result = opts.fullResult
    ? cleanDrawResult(opts.fullResult)
    : String(opts.resultDigit || '').trim();
  const isPass = opts.status === 'PASS';
  const title = isPass ? '🎉 *Congratulations dosto!*' : '😔 *Bad luck dosto!*';
  const rows: string[] = [
    isPass ? `✅ *${marketName} — PASS hua!*` : `❌ *${marketName} — FAIL hua*`,
  ];

  if (result) rows.push(opts.fullResult ? `🎯 Result : ${result}` : `🎯 Result : *${result}*`);

  if (opts.detailed) {
    if (isPass) {
      rows.push(`🏆 Return : ${opts.payout || '₹0'}`);
      rows.push(`📊 Net    : ${opts.net || '₹0'}`);
    } else {
      // Preserve the existing friendly FAIL wording while changing only the
      // visual presentation around it.
      rows.push('🔥 Next time dhamaka karte hai!');
      rows.push(`📉 Loss   : -${stripLeadingMinus(opts.loss || '₹0')}`);
    }
  }

  // Plain follow-up text only; preserve every result/status/financial field.
  return [title, '', ...rows].join('\n');
}

function buildPlayRows(type: PremiumPlayCardOptions['type'], digits: string): string[] {
  const normalized = type === 'panel' ? 'pannel' : type;
  if (normalized !== 'jodi' && normalized !== 'pannel') {
    // Display-only compact commas: preserve digit order and values.
    const compactDigits = String(digits).split(',').map((part) => part.trim()).join(',');
    return [`🎯 Digits:${compactDigits}`];
  }

  const tokens = String(digits || '')
    .split(/[,|\s]+/)
    .map((token) => token.trim())
    .filter(Boolean);

  if (tokens.length === 0) {
    return [normalized === 'jodi' ? '🎯 Jodi : ---' : '🎯 Panel : ---'];
  }

  // Keep each visual row near the existing ANK card width. JODI tokens are
  // 2 digits, so 6 fit cleanly; PANEL tokens are 3 digits, so 5 fit cleanly.
  const perRow = normalized === 'jodi' ? 6 : 5;
  const label = normalized === 'jodi' ? `🎯 Jodi (${tokens.length})` : `🎯 Panel (${tokens.length})`;
  const rows = [label];
  for (let i = 0; i < tokens.length; i += perRow) {
    rows.push(tokens.slice(i, i + perRow).join(' • '));
  }
  return rows;
}

function normalizeLabel(value: string): string {
  return String(value || '').trim().replace(/\s+/g, ' ');
}

function formatNumberLike(value: string | number | undefined): string {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return Math.round(value).toLocaleString('en-IN');
  }
  const raw = String(value ?? '').trim();
  if (!raw) return '0';
  const numeric = Number(raw.replace(/,/g, ''));
  return Number.isFinite(numeric) ? Math.round(numeric).toLocaleString('en-IN') : raw.replace(/^₹\s*/, '');
}

function stripLeadingMinus(value: string): string {
  return String(value || '').replace(/^\s*-\s*/, '');
}

/** The plain-text play card layout requested for Normal and Details modes. */
function renderPlayCardBox(title: string, rows: string[], dateLine = ''): string {
  const content = [title, ...rows];
  const innerWidth = Math.max(23, ...content.map(displayWidth));
  const top = `╭${'─'.repeat(innerWidth)}╮`;
  const bottom = `╰${'─'.repeat(innerWidth)}╯`;
  const line = (value: string) => `│${value}${' '.repeat(Math.max(0, innerWidth - displayWidth(value)))}│`;
  return [...(dateLine ? [dateLine] : []), top, ...content.map(line), bottom].join('\n');
}

function formatCardDate(value?: string): string {
  const raw = String(value || '').trim();
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(raw);
  if (!match) return '';
  const [, year, month, day] = match;
  const date = new Date(`${year}-${month}-${day}T12:00:00Z`);
  if (Number.isNaN(date.getTime())) return '';
  const weekday = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'][date.getUTCDay()];
  return `${weekday} / ${day} / ${year}`;
}

function displayWidth(value: string): number {
  // Asterisks are formatting markers, not visible glyphs on either transport.
  const raw = String(value || '').replace(/\*/g, '');
  let width = 0;
  for (const char of Array.from(raw)) {
    const cp = char.codePointAt(0) || 0;
    // Variation selectors / zero-width joiners / combining marks.
    if (cp === 0xfe0f || cp === 0x200d || (cp >= 0x0300 && cp <= 0x036f)) continue;
    width += isWideCodePoint(cp) ? 2 : 1;
  }
  return width;
}

function isWideCodePoint(cp: number): boolean {
  return (
    cp >= 0x1100 && (
      cp <= 0x115f ||
      cp === 0x2329 || cp === 0x232a ||
      (cp >= 0x2e80 && cp <= 0xa4cf && cp !== 0x303f) ||
      (cp >= 0xac00 && cp <= 0xd7a3) ||
      (cp >= 0xf900 && cp <= 0xfaff) ||
      (cp >= 0xfe10 && cp <= 0xfe19) ||
      (cp >= 0xfe30 && cp <= 0xfe6f) ||
      (cp >= 0xff00 && cp <= 0xff60) ||
      (cp >= 0xffe0 && cp <= 0xffe6) ||
      (cp >= 0x1f300 && cp <= 0x1faff)
    )
  );
}

/** Display only: omit unknown result slots; never changes settlement. */
function cleanDrawResult(value: string): string {
  return value.replace(/\*/g, '').split('-').map(part => part.trim()).filter(Boolean).join('-');
}

export function formatFullDrawResult(parts: {
  openPanel?: string; openAnk?: string; jodi?: string; closeAnk?: string; closePanel?: string;
}): string {
  const valid = (value: string | undefined, size: number, mask: string) =>
    new RegExp(`^\\d{${size}}$`).test(value || '') ? value! : mask;
  const pair = valid(parts.jodi, 2, '');
  return cleanDrawResult(`${valid(parts.openPanel, 3, '***')}-${valid(parts.openAnk || pair[0], 1, '*')}${valid(parts.closeAnk || pair[1], 1, '*')}-${valid(parts.closePanel, 3, '***')}`);
}
