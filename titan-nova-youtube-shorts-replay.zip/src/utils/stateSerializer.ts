import {createStateSerializationPatch} from './stateSerializationPatch';
import {writeStartupSnapshotJson} from './startupSnapshotStore';
interface SerializationWorker {postMessage(value:unknown):void;terminate():void;onmessage:((event:MessageEvent)=>void)|null;onerror:((event:ErrorEvent)=>void)|null;}
interface Job {id:number;state:unknown;cacheKey?:string;resolve:(json:string)=>void;reject:(error:Error)=>void;}
export class SerializationSuperseded extends Error{}
/** One active snapshot plus the newest waiting snapshot; never accumulate whole archives. */
export class StateSerializer {
 private worker:SerializationWorker|undefined;private disabled=false;private suspended=false;private active:Job|undefined;private pending:Job|undefined;private id=0;private stopped=false;private timer:ReturnType<typeof setTimeout>|undefined;private base:{id:number;state:unknown}|undefined;private bodies=new Map<string,ArrayBuffer>();private snapshots=new Map<string,unknown>();
 constructor(private readonly factory:()=>SerializationWorker=()=>new Worker(new URL('../workers/serializeState.worker.ts',import.meta.url),{type:'module'}),private readonly timeoutMs=15000){}
 serialize(state:unknown,cacheKey?:string):Promise<string>{
  if(this.stopped)return Promise.reject(new Error('State serializer closed'));
  // An explicit operation may still need to finish saving while hidden. It
  // must not recreate a whole-archive worker after suspension.
  if(this.suspended){try{const json=JSON.stringify(state);this.snapshots.clear();this.snapshots.set(json,state);if(cacheKey)void writeStartupSnapshotJson(cacheKey,json);return Promise.resolve(json);}catch(error){return Promise.reject(error);}}
  return new Promise((resolve,reject)=>{const job={id:++this.id,state,cacheKey,resolve,reject};if(this.active){this.pending?.reject(new SerializationSuperseded('Newer snapshot queued'));this.pending=job;}else this.start(job);});
 }
 private start(job:Job){
  this.active=job;
  try{
   if(this.disabled)throw Error('Worker unavailable');
   if(!this.worker){this.worker=this.factory();this.worker.onmessage=event=>{if(event.data.id!==this.active?.id)return;if(typeof event.data.json==='string'){if(event.data.body instanceof ArrayBuffer){this.bodies.set(event.data.json,event.data.body);while(this.bodies.size>2)this.bodies.delete(this.bodies.keys().next().value!);}this.base={id:this.active!.id,state:this.active!.state};this.finish(undefined,event.data.json);}else this.fallback();};this.worker.onerror=event=>{event.preventDefault?.();this.fallback();};}
   this.timer=setTimeout(()=>this.fallback(),this.timeoutMs);
   const patch=this.base?createStateSerializationPatch(this.base.state,job.state):undefined;
   this.worker.postMessage(patch?{id:job.id,baseId:this.base!.id,patch,cacheKey:job.cacheKey}:{id:job.id,state:job.state,cacheKey:job.cacheKey});
  }catch{this.fallback();}
 }
 private fallback(){
  this.disabled=true;this.base=undefined;this.worker?.terminate();this.worker=undefined;
  if(!this.active)return;
  try{const json=JSON.stringify(this.active.state);if(this.active.cacheKey)void writeStartupSnapshotJson(this.active.cacheKey,json);this.finish(undefined,json);}catch(error){this.finish(error instanceof Error?error:new Error('Serialization failed'));}
 }
 private finish(error?:Error,json?:string){
  clearTimeout(this.timer);this.timer=undefined;const job=this.active;
  // Only the newest completed snapshot is needed by the next save. An active
  // save already owns its submitted snapshot; retaining old JSON keys also
  // pins their full archives on memory-constrained browsers.
  if(!error&&json!==undefined&&job){this.snapshots.clear();this.snapshots.set(json,job.state);}this.active=undefined;if(error)job?.reject(error);else job?.resolve(json!);
  const next=this.pending;this.pending=undefined;if(next)this.start(next);
 }
 seed(state:unknown,json:string){if(!this.stopped){this.snapshots.clear();this.snapshots.set(json,state);}}
 snapshotFor(json:string):unknown{return this.snapshots.get(json);}
 requestBody(json:string):BodyInit{return this.bodies.get(json)||'{"state":'+json+'}';}
 /** Drop disposable worker/cache copies when Android backgrounds the page.
  * Live App state and the reliable save queue remain owned by their callers. */
 suspend(){
  this.suspended=true;
  clearTimeout(this.timer);this.timer=undefined;if(this.worker){this.worker.onmessage=null;this.worker.onerror=null;this.worker.terminate();}this.worker=undefined;this.base=undefined;this.bodies.clear();this.snapshots.clear();
  const active=this.active,pending=this.pending;this.active=undefined;this.pending=undefined;
  active?.reject(new SerializationSuperseded('Workspace backgrounded'));pending?.reject(new SerializationSuperseded('Workspace backgrounded'));
 }
 resume(){this.suspended=false;}
 dispose(){this.stopped=true;this.base=undefined;this.bodies.clear();this.snapshots.clear();clearTimeout(this.timer);this.timer=undefined;this.worker?.terminate();this.worker=undefined;this.active?.reject(new Error('State serializer closed'));this.pending?.reject(new Error('State serializer closed'));this.active=undefined;this.pending=undefined;}
}
