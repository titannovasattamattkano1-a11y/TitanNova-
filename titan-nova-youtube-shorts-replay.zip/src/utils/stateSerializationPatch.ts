type Fields={set:Record<string,unknown>;remove:string[]};
export interface StateSerializationPatch {root:Fields;profiles:{remove:string[];set:Record<string,{replace?:unknown;fields?:Fields;days?:Fields}>};}
const plain=(value:any)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.getPrototypeOf(value)===Object.prototype;
const own=(value:any,key:string)=>Object.prototype.hasOwnProperty.call(value,key);
/** Preserve JSON property order too, otherwise send the full replacement. */
function ordered(before:any,after:any){const a=Object.keys(before),b=Object.keys(after),expected=[...a.filter(k=>own(after,k)),...b.filter(k=>!own(before,k))];return expected.length===b.length&&expected.every((k,i)=>k===b[i]);}
function fields(before:any,after:any,exclude?:string):Fields {const set:Record<string,unknown>=Object.create(null);for(const key of Object.keys(after))if(key!==exclude&&!Object.is(before[key],after[key]))set[key]=after[key];return{set,remove:Object.keys(before).filter(k=>k!==exclude&&!own(after,k))};}
/** React snapshots are immutable. Transfer only replaced day stores after the first full seed. */
export function createStateSerializationPatch(before:any,after:any):StateSerializationPatch|undefined{
 if(!plain(before)||!plain(after)||!plain(before.profiles)||!plain(after.profiles)||!ordered(before,after)||!ordered(before.profiles,after.profiles))return;
 const changed:StateSerializationPatch={root:fields(before,after,'profiles'),profiles:{remove:Object.keys(before.profiles).filter(k=>!own(after.profiles,k)),set:Object.create(null)}};
 for(const id of Object.keys(after.profiles)){
  const a=before.profiles[id],b=after.profiles[id];if(a===b)continue;
  if(!plain(a)||!plain(b)||!ordered(a,b)){changed.profiles.set[id]={replace:b};continue;}
  const update:{fields:Fields;days?:Fields}={fields:fields(a,b,'dayRecords')};
  if(a.dayRecords!==b.dayRecords){
   if(plain(a.dayRecords)&&plain(b.dayRecords)&&ordered(a.dayRecords,b.dayRecords))update.days=fields(a.dayRecords,b.dayRecords);
   else if(own(b,'dayRecords'))update.fields.set.dayRecords=b.dayRecords;else update.fields.remove.push('dayRecords');
  }
  changed.profiles.set[id]=update;
 }
 return changed;
}
function applyFields(target:any,patch:Fields){for(const key of patch.remove)delete target[key];for(const [key,value] of Object.entries(patch.set))Object.defineProperty(target,key,{value,writable:true,enumerable:true,configurable:true});}
/** Used only inside the serializer worker, never to mutate live app or server state. */
export function applyStateSerializationPatch(snapshot:any,patch:StateSerializationPatch){
 applyFields(snapshot,patch.root);for(const id of patch.profiles.remove)delete snapshot.profiles[id];
 for(const [id,update] of Object.entries(patch.profiles.set)){
  if(own(update,'replace'))Object.defineProperty(snapshot.profiles,id,{value:update.replace,writable:true,enumerable:true,configurable:true});
  else{if(update.fields)applyFields(snapshot.profiles[id],update.fields);if(update.days)applyFields(snapshot.profiles[id].dayRecords,update.days);}
 }return snapshot;
}
