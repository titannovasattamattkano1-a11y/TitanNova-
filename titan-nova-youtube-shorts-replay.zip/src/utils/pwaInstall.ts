import {useSyncExternalStore} from 'react';
interface InstallPrompt extends Event{prompt:()=>Promise<void>;userChoice:Promise<{outcome:'accepted'|'dismissed'}>}
interface PwaState{installed:boolean;installing:boolean;prompt:InstallPrompt|null;secure:boolean;ios:boolean;embedded:boolean;temporaryDomain:boolean;error:string;notice:string;updateAvailable:boolean;checking:boolean;workerReady:boolean}
const browser=typeof window!=='undefined';
const initial:PwaState={installed:false,installing:false,prompt:null,secure:false,ios:false,embedded:false,temporaryDomain:false,error:'',notice:'',updateAvailable:false,checking:false,workerReady:false};
let state=initial,registration:ServiceWorkerRegistration|undefined,started=false,lastCheck=0;
const listeners=new Set<()=>void>();
const set=(patch:Partial<PwaState>)=>{state={...state,...patch};for(const listener of listeners)listener();};
const subscribe=(listener:()=>void)=>{listeners.add(listener);return()=>listeners.delete(listener);};
function standalone(){return window.matchMedia('(display-mode: standalone)').matches||window.matchMedia('(display-mode: fullscreen)').matches||(navigator as Navigator&{standalone?:boolean}).standalone===true;}
export async function checkPwaUpdate(){
 if(!registration||state.checking)return;
 set({checking:true,error:''});try{await registration.update();lastCheck=Date.now();set({updateAvailable:Boolean(registration.waiting),notice:registration.waiting?'An update is ready.':'Update check complete. The latest screen loads when you reopen.'});}catch{set({error:'Could not check for updates. Check your connection and retry.'});}finally{set({checking:false});}
}
export function activatePwaUpdate(){
 if(!registration?.waiting)return;
 registration.waiting.postMessage({type:'TITAN_ACTIVATE_UPDATE'});
 set({updateAvailable:false,notice:'Update activated. Reopen when convenient to load the latest screen. Your current page was not reloaded.'});
}
export async function installPwa(){
 if(state.installing)return;
 const prompt=state.prompt;
 if(!prompt){set({notice:'Use the browser installation steps below.'});return;}
 set({installing:true,prompt:null,error:'',notice:''});
 try{
  await prompt.prompt();const choice=await prompt.userChoice;
  if(!state.installed)set({notice:choice.outcome==='accepted'?'Installation accepted. Follow the device prompt; the app will confirm when installed.':'Installation cancelled. You can use the browser menu to install later.'});
 }catch{set({error:'Install prompt could not open. Try the browser menu steps below.'});}
 finally{set({installing:false});}
}
export function startPwaRuntime(){
 if(!browser||started)return;started=true;
 const ua=navigator.userAgent;
 set({installed:standalone(),secure:window.isSecureContext,ios:/iPad|iPhone|iPod/.test(ua)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1),embedded:/FBAN|FBAV|Instagram|; wv\)|WhatsApp|Line\//i.test(ua),temporaryDomain:location.hostname.endsWith('.trycloudflare.com')});
 window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();if(!state.installed)set({prompt:event as InstallPrompt,error:'',notice:''});});
 window.addEventListener('appinstalled',()=>set({installed:true,prompt:null,installing:false,error:'',notice:'Titan Nova is installed. Open it from your Home Screen.'}));
 const mode=window.matchMedia('(display-mode: standalone)');mode.addEventListener('change',()=>{if(standalone())set({installed:true,prompt:null});});
 // Install prompt is captured before authentication/hydration mounts App.
 if(!window.isSecureContext||!('serviceWorker' in navigator)||import.meta.env?.PROD!==true)return;
 const register=async()=>{
  try{
   registration=await navigator.serviceWorker.register('/sw.js',{scope:'/',updateViaCache:'none'});
   set({updateAvailable:Boolean(registration.waiting),workerReady:true});
   registration.addEventListener('updatefound',()=>{
    const worker=registration?.installing;
    worker?.addEventListener('statechange',()=>{if(worker.state==='installed'&&navigator.serviceWorker.controller)set({updateAvailable:Boolean(registration?.waiting)});});
   });
   document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&Date.now()-lastCheck>30*60*1000)void checkPwaUpdate();});
  }catch{set({error:'App installation support could not load. Check your connection, then reopen this panel.'});}
 };
 if(document.readyState==='complete')void register();else window.addEventListener('load',()=>void register(),{once:true});
}
if(browser)startPwaRuntime();
export function usePwaInstall(){return {...useSyncExternalStore(subscribe,()=>state,()=>initial),install:installPwa,checkUpdate:checkPwaUpdate,activateUpdate:activatePwaUpdate};}
