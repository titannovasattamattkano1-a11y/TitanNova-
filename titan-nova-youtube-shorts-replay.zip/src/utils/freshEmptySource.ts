import {areSettlementTokensValid} from './settlement';
import {normalizeScrapeSource,getScrapeSource} from './scrapeProvenance';
import {hasSimulatedSourceResult} from './scrapeCommitGuard';
import {modelSourceVersion,isEditableSourceSkip} from './marketModelCard';
import {CARD_SOURCE_MODES,type GameType} from '../types';
const object=(v:any):v is Record<string,any>=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const norm=(v:any)=>String(v||'').trim().toUpperCase();
const sourceFields=['d','od','sourceMode','sourceEditedAt','scrapeSource','trick','positionRule','weekdaySelectedDigits','weekdayHitPosition','firstDigitMirrorCut','tesla369','triCut','sniperOne','mssdState','marketModel','strictPanel30','smartSelection','liveCombinedCut','carryResultSix','autoRemovedResult','autoResultParity','openCloseCut','selfLearning','mirroredFromAdmin'] as const;
/** A backend-created blank is not a competing source edit. Accept a
 * later selection or trick edit for an empty, uncommitted card. */
export function freshSourceOverEmpty(current:any,desired:any,type:GameType):any|undefined {
 if(!object(current)||!object(desired)||String(current.d||'').trim()||!areSettlementTokensValid(type,desired.d))return;
 if(current.manualStatus||current.sentRate||current.sentDigits||current.sentAt||current.settledAt||current.dispatchState||current.deliveryRestoredAt||current.loopAccountReservation)return;
 if(current.s&&current.s!=='WAIT'&&!isEditableSourceSkip(current)&&!current.loopAccountSkipped&&!current.vipAutoStopSkipped)return;
 if(desired.sentRate||desired.sentDigits||desired.sentAt||desired.dispatchState||desired.manualStatus||desired.deliveryRestoredAt)return;
 const version=Math.max(Number(desired.sourceEditedAt||0),Date.now());
 if(desired.bulkBacktestJobId!==current.bulkBacktestJobId||Number(desired.bulkBacktestVersion||0)!==Number(current.bulkBacktestVersion||0))return;
 if(desired.marketName&&current.marketName&&norm(desired.marketName)!==norm(current.marketName))return;
 const next:any={...current};
 for(const key of sourceFields){if(desired[key]===undefined)delete next[key];else next[key]=desired[key];}
 next.sourceEditedAt=Math.max(version,modelSourceVersion(current)+1,Number(current.manualOverrideAt||0)+1,Number(current.cardGeneration||0)+1);
 next.cardGeneration=Math.max(Number(current.cardGeneration||0),Number(desired.cardGeneration||0))||undefined;
 next.marketName=norm(desired.marketName||current.marketName);
 if(!current.loopAccountSkipped&&!current.vipAutoStopSkipped){
  next.s=desired.s==='SKIP'&&isEditableSourceSkip(desired)?'SKIP':'WAIT';
  for(const key of ['backtestResult','scrapeResultDigit','manualResult','manualResultSources','manualPanelResult','backtestSelectionHold'])delete next[key];
  if(desired.backtestResult?.checked&&desired.backtestResult.digits===desired.d&&areSettlementTokensValid(type,desired.backtestResult.actual)&&['WAIT','PASS','FAIL'].includes(desired.s)){next.backtestResult=desired.backtestResult;next.scrapeResultDigit=desired.scrapeResultDigit;next.s=desired.s;}
 }
 if(!current.manualRate){for(const key of ['recRate','prevLoss','targetProfitWithLoss','rateFinalizedAt','rateFinalizedFrom','twoCardRecoveryShares','twoCardRecoveryStrategy'])delete next[key];next.r='';}
 return next;
}
/** Replace a known scraped or manual source with a newer explicit source,
 * trick edit, or manual clear on an uncommitted card. */
export function freshSourceReplacement(current:any,desired:any,type:GameType):any|undefined {
 if(!object(current)||!object(desired))return;
 if(current.s!=='WAIT'&&!hasSimulatedSourceResult(current))return;
 if(current.loopAccountSkipped||current.vipAutoStopSkipped)return;
 // Allow explicit clear (desired.d === '' && desired.sourceMode === 'MANUAL')
 if(String(desired.d||'').trim()===''&&desired.sourceMode==='MANUAL'&&!current.sentRate&&!current.sentDigits&&!current.sentAt&&!current.dispatchState){
  const cleared:any={...current,s:'WAIT',d:'',od:'',sourceMode:'MANUAL',r:'',sourceEditedAt:Math.max(Number(desired.sourceEditedAt||0),modelSourceVersion(current)+1,Date.now())};
  for(const key of ['trick','positionRule','scrapeSource','recRate','prevLoss','targetProfitWithLoss','rateFinalizedAt','rateFinalizedFrom','manualRate','manualStatus','backtestResult','scrapeResultDigit','manualResult','manualResultSources','manualPanelResult','smartStaking','smartSelection'])delete cleared[key];
  return cleared;
 }
 if(!String(current.d||'').trim())return freshSourceOverEmpty(current,desired,type);
 if(!areSettlementTokensValid(type,desired.d))return;
 return freshSourceOverEmpty({...current,s:'WAIT',d:''},desired,type);
}
/** First-date/dictionary saves may meet a backend-created branch. Preserve its
 * unrelated settings/cards and descend only into the new selection slots. */
export function mergeMaterializedDay(path:string[],current:any,desired:any):any|undefined {
 if(path[0]!=='profiles'||path[2]!=='dayRecords'||!object(current)||!object(desired)||![4,5,6].includes(path.length))return;
 const games:Record<string,GameType>={data:'ank',jodiData:'jodi',pannelData:'pannel'};
 if(path.length===6)return games[path[4]]?freshSourceOverEmpty(current,desired,games[path[4]]):undefined;
 if(path.length===5&&!games[path[4]])return;
 let next=current;
 for(const [key,value]of Object.entries(desired)){
  if(['__proto__','constructor','prototype'].includes(key))throw new Error('Invalid workspace key');
  let merged:any;
  if(current[key]===undefined)merged=value;
  else if((path.length===4&&games[key])||path.length===5)merged=mergeMaterializedDay([...path,key],current[key],value);
  if(merged!==undefined&&merged!==current[key]){if(next===current)next={...current};Object.defineProperty(next,key,{value:merged,enumerable:true,writable:true,configurable:true});}
 }
 return next===current?undefined:next;
}
