import { isFourWaveRelayActive } from './fourWaveRelay';
import {restoreLoopAccountSkips,applyBacktestLoopAccounts} from './backtestLoopAccounts';
import {dayLoopConfig} from './dualLoops';
import {cutOpenActual,sameMarketOpenActual,restoreOpenCloseInput} from './openToCloseCut';
import {isBacktestSelectionHeld} from './backtestSelectionHold';
import {TwoCardRecovery,useTwoCardRecovery,useRecoveryShareLedger,recoverySharesForCard,shareTotal,recoveryCardFrozen} from './twoCardRecovery';
import {pinRecoverySettings,archivedRecoveryProfile} from './archiveRecoverySnapshot';
import {applyCarryResultSix,carryResultSixHistory,findPrecedingLoopCard,findLoopFailStreak,analyzeHistoricalCardTransitions,collectCarryTenWindowAnalysis} from './carryResultSix';
import {applyResultParity,createCutResolver} from './resultParity';
import {refineDynamic4AnkWithLoopFlow} from './masterFlow';
import {backtestMarketSelected} from './backtestMarketSelection';
import {observeSkippedAnkActual} from './backtestSkipHistory';
import { evaluateBacktest } from './backtestResult';
import { datedResultRemovalSettings, autoRemovalInput, confirmedAnkResult, removePreviousResult } from './autoRemoveResult';
import { profileRecoveryTrack, profileFinancialRecoveryTrack, profileLegacyFinancialTrack, profileLoopTarget, createProfileLoopContext, assignedLoop, isLoopAssignmentFrozen } from './dualLoops';
import type { DayMarketRecord, GameType, UserProfile } from '../types';
import { getEffectiveMarkets, getEffectiveBaseMarkets } from '../data/markets';
import { isMarketEnabledForDate } from './profileMarketToggle';
import { areSettlementTokensValid, calculateRecoveryRate, calculateSmartStakingRates, calculateSettlement, isRecoveryRatePossible } from './settlement';
import { getBaseMarketUnsettledState } from './calculator';
import { jodiOpenSideStatus } from './recoveryLedger';
import { businessDateIST } from './businessDate';
import {buildFinancialLedger,isRecordedPlay} from './financialHistory';
import {recoveryMarketOrder} from './recoveryMarketOrder';
import {sameAdminValue} from './adminStatePatch';

/** Historical settled net only; daily target is independent for each game. */
function backtestDailyLimitReached(profile:UserProfile,date:string,type:GameType,target:number,runId?:string,beforeIndex=Infinity,loss=false):boolean {
  if(!(target>0)||date>=businessDateIST())return false;
  const day=profile.dayRecords[date],ledger=buildFinancialLedger(profile,date);
  const markets=ledger.markets.filter(m=>m.type===type);
  const boundary=markets.find(m=>m.index===beforeIndex);
  const ordered=recoveryMarketOrder([...markets.filter(m=>m.index!==beforeIndex),...(boundary?[{...boundary,boundary:true}]:[])]);
  let profit=0;
  for(const market of ordered){
    if('boundary' in market&&market.boundary)break;
    if(!boundary&&market.index>=beforeIndex)continue;
    const rec=ledger.cards[`${type}_${market.index}`];if(!rec||!['PASS','FAIL'].includes(rec.s))continue;
    if(!isRecordedPlay(rec)&&(!market.enabled||!backtestMarketSelected(market.n,day?.backtestRecoveryPolicy?.selectedMarkets)))continue;
    if(runId&&rec.bulkBacktestJobId!==runId&&!isRecordedPlay(rec)&&rec.backtestResult)continue;
    const settlement=calculateSettlement({type,digits:rec.sentDigits||rec.d,rate:rec.r||rec.recRate,sentRate:rec.sentRate,sentInvest:rec.sentInvest});
    profit+=(rec.s==='PASS'?settlement.payout:0)-settlement.invest;
    if(loss?profit<=-target:profit>=target)return true;
  }
  return false;
}

export const backtestDailyTargetReached=(profile:UserProfile,date:string,type:GameType,target:number,runId?:string,beforeIndex=Infinity)=>backtestDailyLimitReached(profile,date,type,target,runId,beforeIndex);
export const backtestDailyStopLossReached=(profile:UserProfile,date:string,type:GameType,limit:number,runId?:string,beforeIndex=Infinity)=>backtestDailyLimitReached(profile,date,type,limit,runId,beforeIndex,true);

/** Replay archive bets in market order. Never updates live runtime or delivery snapshots. */
function calculateBacktestRecoveryBase(profile: UserProfile, date: string): UserProfile {
  if (date >= businessDateIST(new Date()) || !profile.dayRecords[date]) return profile;
  const originalProfile=profile,liveConfig=profile.config;
  const pinned=pinRecoverySettings(profile,date);
  profile=archivedRecoveryProfile(pinned,date);
  const day=profile.dayRecords[date];
  const loopContext=createProfileLoopContext(profile,date);
  const loopContexts=new Map([[date,loopContext]]);
  const policy=day.backtestRecoveryPolicy;
  const resultRemoval=datedResultRemovalSettings(profile,date);
  const carryEnabled=policy?.autoCarryResultSix??(policy?.runId?false:profile.config.autoCarryResultSix===true);
  const resetEnabled=policy?.resetAfterThreeFails===true;
  const maxStake=resetEnabled?Math.max(0,Number(policy?.maxStake)||0):0;
  let nextDay=day, changed=pinned!==originalProfile;
  for (const type of ['ank','jodi','pannel'] as GameType[]) {
    const dictName=type==='ank' ? 'data' : type==='jodi' ? 'jodiData' : 'pannelData';
    const visibility=type==='ank' ? day.visAnk : type==='jodi' ? day.visJodi : day.visPan;
    const markets=type==='jodi' ? getEffectiveBaseMarkets(profile.config) : getEffectiveMarkets(profile.config);
    const dict={...day[dictName]};
    const activeNames=new Set((type==='jodi'?getEffectiveBaseMarkets(liveConfig):getEffectiveMarkets(liveConfig)).map(m=>m.n));
    const known=type==='jodi'?getEffectiveBaseMarkets({...liveConfig,deletedMarketNames:[]}):getEffectiveMarkets({...liveConfig,deletedMarketNames:[]});
    const entries=[...new Set([...markets.map((_m,i)=>i),...Object.keys(dict).map(Number).filter(Number.isInteger)])]
      .map(index=>{const identity=dict[index]?.marketName,market=identity?markets.find(m=>m.n===identity)||known.find(m=>m.n===identity)||{n:identity}:markets[index];return market?{...market,index}:undefined;}).filter(Boolean);
    const indexedMarkets=recoveryMarketOrder(entries).map(m=>({index:m.index,market:m}));
    const cutResolver=type==='ank'?createCutResolver({profile,date,cards:dict,selectedMarkets:policy?.selectedMarkets,
      markets:indexedMarkets.map(({market,index})=>({...market,index,enabled:activeNames.has(market.n)&&isMarketEnabledForDate(profile.config,visibility,market.n,date)})),
      track:(n,r)=>profileRecoveryTrack(profile,date,'ank',n,r,loopContext)}):undefined;
    const splitTwo=useRecoveryShareLedger(profile.config,date,type);
    const splitMode=useTwoCardRecovery(profile.config,date,type);
    const splitQueues:Record<string,TwoCardRecovery>={};
    const debt:Record<string,number>={}, reserved:Record<string,boolean>={}, failures:Record<string,number>={}, pendingProfits:Record<string,number>={};

    const removalAssigned: Record<string,boolean> = {};
    const logicReserved:Record<string,boolean>={};
    const previous: Record<string,{ actual?: string; key: string }> = {};
    let dictChanged=false, dailyProfit=0, targetReached=false, lossReached=false;
    const dailyTarget=!policy?.dailyTargetGames||policy.dailyTargetGames.includes(type)?Math.max(0,Number(policy?.dailyProfitTarget)||0):0;
    const dailyStopLoss=!policy?.dailyTargetGames||policy.dailyTargetGames.includes(type)?Math.max(0,Number(policy?.dailyStopLoss)||0):0;
    const isFourWave = isFourWaveRelayActive(profile.config, Boolean(loopContext.config?.enabled));
    const isSameMarket = !isFourWave && !loopContext.config?.enabled && profile.config?.sameMarketRecovery !== false && (
      type === 'ank' ? profile.config?.ankSplit !== false : type === 'pannel' ? profile.config?.panSplit !== false : false
    );
    let lastSettledOverallPos = -1;
    const lastSettledPosByTrack: Record<string, number> = {};
    indexedMarkets.forEach(({market, index}, pos) => {
      const rec = dict[index];
      if (!rec) return;
      const settled = rec.s === 'PASS' || rec.s === 'FAIL' || (type === 'jodi' && (rec.jodiOpenStatus === 'PASS' || rec.jodiOpenStatus === 'FAIL'));
      if (settled) {
        lastSettledOverallPos = pos;
        const tk = profileFinancialRecoveryTrack(profile, date, type, market.n, rec, loopContext);
        lastSettledPosByTrack[tk] = pos;
      }
    });
    const wavePosByIndex = new Map<number, number>();
    const fourWaveMeta: Array<{ index: number; settledOrSent: boolean; checkedWait: boolean }> = [];
    let lastSettledWavePos = -1;
    let carryHandoff = 0, carryProfitHandoff = 0, carryFails = 0, carryReserved = false;
    if (isFourWave) {
      indexedMarkets.forEach(({market, index}, pos) => {
        const original = dict[index];
        const recorded = isRecordedPlay(original);
        if (!recorded && !backtestMarketSelected(market.n, policy?.selectedMarkets)) return;
        if (!recorded && original?.backtestDailyStopLossSourceSkipped && dailyStopLoss > 0) return;
        if (!recorded && original?.backtestDailyProfitSourceSkipped && (Number(policy?.dailyProfitTarget) || 0) > 0) return;
        if (!original || (original.s === 'SKIP' && !original.backtestStakeLimitSkipped && !original.backtestDailyProfitSkipped && !original.backtestDailyStopLossSkipped) ||
          (!recorded && (!activeNames.has(market.n) || !isMarketEnabledForDate(profile.config, visibility, market.n, date)))) return;
        const restoredSettled = Boolean(
          (original.backtestDailyProfitSkipped || original.backtestDailyStopLossSkipped || original.backtestStakeLimitSkipped) &&
          (original.backtestResult?.checked || original.backtestSkipHistory?.actual)
        );
        const settled = original.s === 'PASS' || original.s === 'FAIL' || (type === 'jodi' && (original.jodiOpenStatus === 'PASS' || original.jodiOpenStatus === 'FAIL')) || restoredSettled;
        const delivered = Boolean(original.sentAt || original.dispatchState === 'SENT');
        const checkedWait = !settled && !delivered && Boolean(original.backtestResult?.checked && !original.manualStatus);
        const hasDigits = isRecoveryRatePossible(type, original.sentAt ? (original.sentDigits || original.d) : original.d);
        if (!settled && !delivered && (pos < lastSettledOverallPos || !hasDigits || checkedWait)) return;
        const wPos = fourWaveMeta.length;
        wavePosByIndex.set(index, wPos);
        fourWaveMeta.push({ index, settledOrSent: settled || delivered, checkedWait });
        if (settled || delivered) lastSettledWavePos = wPos;
      });
    }
    indexedMarkets.forEach(({market,index}, pos) => {
      const original=dict[index];
      const recorded=isRecordedPlay(original);
      if(!recorded&&!backtestMarketSelected(market.n,policy?.selectedMarkets))return;
      if(!recorded&&original?.backtestDailyStopLossSourceSkipped && dailyStopLoss>0)return;
      if (!recorded&&original?.backtestDailyProfitSourceSkipped && (Number(policy?.dailyProfitTarget)||0)>0)return;
      if (!original || (original.s==='SKIP' && !original.backtestStakeLimitSkipped && !original.backtestDailyProfitSkipped && !original.backtestDailyStopLossSkipped) ||
        (!recorded&&(!activeNames.has(market.n)||!isMarketEnabledForDate(profile.config,visibility,market.n,date)))) return;
      const protectedCard=Boolean(original.sentDigits||original.sentRate||original.dispatchState||original.manualStatus||original.deliveryRestoredAt||((original.s==='PASS'||original.s==='FAIL')&&!original.backtestResult));
      if((targetReached||lossReached)&&!protectedCard){
        let skipped={...original,s:'SKIP' as const,...(lossReached?{backtestDailyStopLossSkipped:true}:{backtestDailyProfitSkipped:true})};
        if(type==='ank'&&original.backtestResult?.checked)skipped=observeSkippedAnkActual(skipped,original.backtestResult.actual,date) as typeof skipped;
        if(JSON.stringify(skipped)!==JSON.stringify(original)){dict[index]=skipped;dictChanged=true;}
        return;
      }
      const wavePos = isFourWave ? wavePosByIndex.get(index) : undefined;
      const track = (isFourWave && wavePos !== undefined)
        ? `${type}:W${(wavePos % 4) + 1}`
        : profileFinancialRecoveryTrack(profile,date,type,market.n,original,loopContext);
      const logicTrack=profileRecoveryTrack(profile,date,type,market.n,original,loopContext);
      const target=profileLoopTarget(profile,date,type,market.n,original,loopContext);
      if (debt[track] === undefined) {
        if (isSameMarket) {
          const prior = getBaseMarketUnsettledState(profile, date, type, market.n, resetEnabled);
          debt[track] = prior.debt;
          failures[track] = prior.consecutiveFails;
          pendingProfits[track] = prior.pendingProfit || 0;
        } else {
          debt[track] = 0;
          failures[track] = 0;
          pendingProfits[track] = 0;
        }
      }
      const isCardSettled = original.s === 'PASS' || original.s === 'FAIL' || (type === 'jodi' && (original.jodiOpenStatus === 'PASS' || original.jodiOpenStatus === 'FAIL'));
      const lastSettledPos = isFourWave ? lastSettledOverallPos : (lastSettledPosByTrack[track] ?? -1);
      const bypassedWait = !isCardSettled && !original.sentAt && pos < lastSettledPos;
      let pending = bypassedWait ? 0 : (isCardSettled ? (debt[track] || 0) : (reserved[track] ? 0 : (debt[track] || 0)));
      if (isFourWave && wavePos !== undefined) {
        if (isCardSettled) {
          pending = Math.round(((debt[track] || 0) + carryHandoff) * 100) / 100;
          if (carryHandoff > 0) failures[track] = Math.max(failures[track] || 0, carryFails);
        } else {
          const canTakeWave = !bypassedWait && !reserved[track];
          const canTakeCarry = canTakeWave && !carryReserved && carryHandoff > 0;
          pending = canTakeWave ? Math.round(((debt[track] || 0) + (canTakeCarry ? carryHandoff : 0)) * 100) / 100 : 0;
        }
      }
      let rec:DayMarketRecord={...original};
      if(type==='ank'&&!isBacktestSelectionHeld(rec,date))rec=restoreOpenCloseInput(rec,day.openToCloseCut!==true);
      delete rec.backtestRecoveryReset;
      if(rec.backtestDailyProfitSkipped||rec.backtestDailyStopLossSkipped){
        delete rec.backtestDailyStopLossSkipped;delete rec.backtestDailyStopLossSourceSkipped;
        delete rec.backtestDailyProfitSkipped;rec.s='WAIT';
        if(rec.backtestResult?.checked)rec=evaluateBacktest(rec,type,rec.backtestResult.actual,rec.backtestResult.openActual);
        else if(type==='ank'&&rec.backtestSkipHistory?.actual)rec=evaluateBacktest(rec,type,rec.backtestSkipHistory.actual);
        delete rec.backtestSkipHistory;
      }
      if(rec.backtestStakeLimitSkipped){rec.s='WAIT';delete rec.backtestStakeLimitSkipped;delete rec.backtestSkipHistory;}
      const selectionHeld=isBacktestSelectionHeld(rec,date);
      const isFlow4Ank = type === 'ank' && (rec.sourceMode === 'FLOW_3_1' || rec.positionRule === 'FLOW_3_1');
      if (!selectionHeld && isFlow4Ank) {
        const histProfile = {...profile,dayRecords:{...profile.dayRecords,[date]:{...day,data:dict}}};
        const recentTwo = carryResultSixHistory(histProfile, date, index, market.n, rec, 2, loopContexts);
        const openAct = sameMarketOpenActual(indexedMarkets.map(({market,index})=>({...market,index})), dict, market.n);
        const prevDigits = rec.d;
        rec = refineDynamic4AnkWithLoopFlow(
          rec,
          market.n,
          openAct,
          recentTwo[0]?.actual,
          recentTwo[1]?.actual,
          failures[track] || 0,
        );
        if (rec.d !== prevDigits && rec.backtestResult?.checked && rec.backtestResult.actual && !rec.manualStatus) {
          rec = evaluateBacktest(rec, 'ank', rec.backtestResult.actual, rec.backtestResult.openActual);
        }
      }
      if(!selectionHeld&&type==='ank'&&!isFlow4Ank&&(carryEnabled||!rec.mirroredFromAdmin)){
        const histProfile = {...profile,dayRecords:{...profile.dayRecords,[date]:{...day,data:dict}}};
        const cHist = carryEnabled ? carryResultSixHistory(histProfile,date,index,market.n,rec,10,loopContexts) : [];
        const streakInfo = carryEnabled ? findLoopFailStreak(histProfile,date,index,market.n,rec,loopContexts) : { streakCount: 0, failedCards: [], lastSettledCard: null };
        const transitions = carryEnabled && streakInfo.lastSettledCard ? analyzeHistoricalCardTransitions(histProfile, date, index, market.n, rec, streakInfo.lastSettledCard, loopContexts) : undefined;
        const cWin = carryEnabled ? collectCarryTenWindowAnalysis(histProfile, date, index, market.n, rec, loopContexts) : undefined;
        rec=applyCarryResultSix(rec,cHist,carryEnabled,streakInfo.lastSettledCard,streakInfo.streakCount,streakInfo.failedCards,transitions,cWin);
      }
      if (!selectionHeld && type === 'ank' && !isFlow4Ank && !carryEnabled && rec.sourceMode!=='RESULT_CARRY6') {
        const parityEnabled=policy?.autoResultParity??profile.config.autoResultParity===true;
        rec=applyResultParity(rec,parityEnabled?cutResolver?.(index,rec):undefined,parityEnabled);
        const candidate = areSettlementTokensValid('ank', autoRemovalInput(rec));
        const uniqueHistory=resultRemoval.autoRemoveResultDigit&&resultRemoval.autoRemoveResultUnique3&&!logicReserved[logicTrack]&&!removalAssigned[logicTrack]?carryResultSixHistory({...profile,dayRecords:{...profile.dayRecords,[date]:{...day,data:dict}}},date,index,market.n,rec,5,loopContexts):undefined;
        rec = removePreviousResult(rec, logicReserved[logicTrack] || removalAssigned[logicTrack] ? undefined : previous[logicTrack]?.actual, uniqueHistory?uniqueHistory.map(h=>h.key).join('|'):previous[logicTrack]?.key || '', resultRemoval.autoRemoveResultDigit === true, resultRemoval.autoRemoveResultMirror === true,uniqueHistory?.map(h=>h.actual));
        if (candidate) removalAssigned[logicTrack] = true;
      }
      if(!selectionHeld&&type==='ank'&&!isFlow4Ank&&day.openToCloseCut===true){
        const filtered=cutOpenActual(rec,sameMarketOpenActual(indexedMarkets.map(({market,index})=>({...market,index})),dict,market.n),date);
        if(filtered)rec=filtered;
        // Replaying automatic filters must not bump the source clock when the final digits stay identical.
        if(rec.d===original.d){
          rec.sourceEditedAt=original.sourceEditedAt;
          if(rec.openCloseCut)rec.openCloseCut={...rec.openCloseCut,outputVersion:Number(original.sourceEditedAt||0)};
          if(rec.backtestResult?.actual===original.backtestResult?.actual&&rec.backtestResult)rec.backtestResult={...rec.backtestResult,updatedAt:original.backtestResult?.updatedAt};
        }
      }
      const loop=assignedLoop(loopContext.config,type,market.n,rec);
      if(loop) rec.loopId=loop;
      else if (!isLoopAssignmentFrozen(rec)) { delete rec.loopId; delete rec.sentLoopId; }
      const genuinelySent = Boolean(rec.sentAt || rec.dispatchState === 'SENT');
      const isGenuineManualRate = Boolean(rec.manualRate && !rec.manualStatus && Number(rec.r) > 0);
      if (!genuinelySent && rec.backtestResult && !rec.manualStatus && rec.backtestResult.digits!==rec.d) rec.s='WAIT';
      if (isFourWave && wavePos !== undefined) {
        const settledAfterEval = rec.s === 'PASS' || rec.s === 'FAIL' || (type === 'jodi' && (rec.jodiOpenStatus === 'PASS' || rec.jodiOpenStatus === 'FAIL'));
        if (settledAfterEval) {
          pending = Math.round(((debt[track] || 0) + carryHandoff) * 100) / 100;
          if (carryHandoff > 0) failures[track] = Math.max(failures[track] || 0, carryFails);
        } else {
          const canTakeWave = !bypassedWait && !reserved[track];
          const canTakeCarry = canTakeWave && !carryReserved && carryHandoff > 0;
          pending = canTakeWave ? Math.round(((debt[track] || 0) + (canTakeCarry ? carryHandoff : 0)) * 100) / 100 : 0;
        }
      }
      const manuallySettledWithRate = Boolean((rec.s === 'PASS' || rec.s === 'FAIL') && rec.manualStatus && (rec.sentRate || Number(rec.r) > 0));
      const editable = !genuinelySent && !manuallySettledWithRate;
      const splitQueue=splitQueues[track] ||= new TwoCardRecovery();
      const splitFrozen=genuinelySent;
      const splitLegacy=splitTwo&&splitQueue.legacySettlement(`${type}_${index}`,profileLegacyFinancialTrack(profile,date,type,market.n,rec,loopContext),rec.s,calculateSettlement({type,digits:rec.sentDigits||rec.d,rate:rec.r||rec.recRate,sentRate:rec.sentRate,sentInvest:rec.sentInvest,smartStaking:rec.smartStaking}).invest,splitFrozen,rec.twoCardRecoveryShares);
      const splitShares=splitTwo&&!splitLegacy&&(splitFrozen||isRecoveryRatePossible(type,rec.d))
        ? recoverySharesForCard(splitQueue,rec,splitMode,splitFrozen,true):[];
      if(splitTwo)pending=shareTotal(splitShares);
      const isClose = (type === 'ank' || type === 'pannel') && /\s+CLOSE$/i.test(market.n);
      const isOpenPassCloseZero = Boolean(profile?.config?.openPassCloseZero || policy?.openPassCloseZero || profile?.openPassCloseZero);
      let isOpenPassForClose = false;
      if (isOpenPassCloseZero && isClose) {
        const baseName = market.n.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
        const openName = `${baseName} OPEN`;
        const openIdx = indexedMarkets.findIndex(item => item.market.n.trim().toUpperCase() === openName);
        const openRec = openIdx >= 0 ? dict[openIdx] : undefined;
        isOpenPassForClose = openRec?.s === 'PASS';
      }

      if (editable) {
        if(splitTwo){rec.twoCardRecoveryShares=splitShares;rec.twoCardRecoveryStrategy=splitMode?'TWO':'ALL';}
        if (isOpenPassForClose) {
          const nextRate = isGenuineManualRate ? String(rec.r) : '0';
          if (!isGenuineManualRate && !rec.manualStatus) {
            rec.s = 'SKIP';
            (rec as any).closeZeroAutoSkipped = true;
          }
          rec.recRate = '0';
          rec.r = nextRate;
          delete rec.smartStaking;
          rec.prevLoss = 0;
          rec.targetProfitWithLoss = 0;
          if ((rec.s === 'PASS' || rec.s === 'FAIL') && !rec.sentAt) {
            rec.sentRate = nextRate;
            rec.sentInvest = 0;
          }
        } else {
          const isProfitCarry = Boolean(profile?.config?.profitCarry === true || policy?.profitCarry === true || profile?.profitCarry === true);
          const carriedProfit = isProfitCarry ? (pendingProfits[track] || 0) : 0;
          const effectiveTarget = target + carriedProfit;
          const suggested=calculateRecoveryRate(type,rec.d,pending,effectiveTarget);
          rec.recRate=suggested;
          const nextRate = isGenuineManualRate ? String(rec.r) : suggested;
          rec.r = nextRate;
          if (!isGenuineManualRate) delete rec.manualRate;
          const smartStaking = splitMode && (type === 'ank' || type === 'pannel') && !isGenuineManualRate
            ? calculateSmartStakingRates(type, rec.d, pending, effectiveTarget, rec.smartSelection?.strongDigits, rec.smartSelection?.supportDigits)
            : undefined;
          if (smartStaking?.isSmartStaking) {
            rec.smartStaking = smartStaking;
          } else {
            delete rec.smartStaking;
          }
          if ((rec.s === 'PASS' || rec.s === 'FAIL') && !rec.sentAt) {
            rec.sentRate = nextRate;
            const tokenCnt = String(rec.d || '').split(/[,|\s]+/).filter(Boolean).length;
            rec.sentInvest = smartStaking?.isSmartStaking ? smartStaking.totalInvest : tokenCnt * (parseFloat(nextRate) || 0);
          }
          rec.prevLoss=pending;
          rec.targetProfitWithLoss=pending+effectiveTarget;
        }
      }
      if(original.backtestStakeLimitSkipped && rec.backtestResult?.checked && rec.backtestResult.digits===rec.d) {
        rec=evaluateBacktest(rec,type,rec.backtestResult.actual,rec.backtestResult.openActual);
      }
      const winDigit = rec.manualResult || rec.scrapeResultDigit || (/CLOSE/i.test(market.n) ? rec.backtestResult?.actual?.close : rec.backtestResult?.actual?.open);
      const settlement=calculateSettlement({type,digits:rec.sentAt ? (rec.sentDigits || rec.d) : rec.d,rate:rec.r || rec.recRate,sentRate:rec.sentAt ? rec.sentRate : undefined,sentInvest:rec.sentAt ? rec.sentInvest : undefined,smartStaking:rec.smartStaking,winningDigit:winDigit});
      if(maxStake>0 && editable && settlement.invest>maxStake){
        rec.s='SKIP';rec.backtestStakeLimitSkipped=true;
        if(type==='ank'&&rec.backtestResult?.checked)rec=observeSkippedAnkActual(rec,rec.backtestResult.actual,date);
        if(type==='ank')removalAssigned[logicTrack]=false;
        if(JSON.stringify(rec)!==JSON.stringify(original)){dict[index]=rec;dictChanged=true;}
        // No bet was placed: skipped cards do not change the fail counter or debt.
        return;
      }
      if(splitTwo&&!splitLegacy&&settlement.rate>0&&settlement.invest>0&&(splitFrozen||isRecoveryRatePossible(type,rec.d)))recoverySharesForCard(splitQueue,rec,splitMode,splitFrozen);
      if(rec.s==='PASS'||rec.s==='FAIL'){
        dailyProfit+=(rec.s==='PASS'?settlement.payout:0)-settlement.invest;
        if(dailyTarget>0&&dailyProfit>=dailyTarget)targetReached=true;
        if(dailyStopLoss>0&&dailyProfit<=-dailyStopLoss)lossReached=true;
      }
      let status=rec.s;
      if (type==='jodi') {
        const open=rec.backtestResult?.digits===rec.d && rec.backtestResult.checked ? (rec.backtestResult.openActual||rec.backtestResult.actual?.[0]) : undefined;
        const openStatus=open ? jodiOpenSideStatus(rec.sentDigits || rec.d,open) : rec.backtestResult?undefined:rec.jodiOpenStatus;
        if (openStatus==='PASS' || openStatus==='FAIL') status=openStatus;
      }
      if (isOpenPassForClose) {
        if (status === 'PASS' || status === 'FAIL') {
          const isProfitCarry = Boolean(profile?.config?.profitCarry === true || policy?.profitCarry === true || profile?.profitCarry === true);
          if (status === 'FAIL') {
            if (isProfitCarry) pendingProfits[track] = (pendingProfits[track] || 0) + target;
          } else {
            pendingProfits[track] = 0;
          }
          reserved[track]=false;logicReserved[logicTrack]=false;
          if (type === 'ank') { previous[logicTrack] = { actual: confirmedAnkResult(rec), key: `${date}:ank_${index}` }; removalAssigned[logicTrack] = false; }
        }
      } else if (settlement.rate>0 && settlement.invest>0) {
        if (status==='PASS' || status==='FAIL') {
          if (isFourWave && wavePos !== undefined) {
            carryHandoff = 0; carryProfitHandoff = 0; carryFails = 0; carryReserved = false;
            debt[track] = status === 'FAIL' ? Math.round((pending + settlement.invest) * 100) / 100 : 0;
          } else if(splitTwo){if(status==='FAIL'&&!splitLegacy)splitQueue.fail(`${type}_${index}`,settlement.invest,splitShares);debt[track]=splitQueue.debt;}
          else debt[track]=status==='FAIL' ? (debt[track] || 0)+settlement.invest : 0;
          const isProfitCarry = Boolean(profile?.config?.profitCarry === true || policy?.profitCarry === true || profile?.profitCarry === true);
          pendingProfits[track] = (isProfitCarry && status === 'FAIL') ? (pendingProfits[track] || 0) + target : 0;
          failures[track]=status==='FAIL' ? (failures[track]||0)+1 : 0;
          if(resetEnabled && failures[track]>=3){
            if(editable && !rec.manualStatus)rec.backtestRecoveryReset={fails:3,debtCleared:debt[track],track};
            debt[track]=0;failures[track]=0;pendingProfits[track]=0;if(splitTwo)splitQueue.clearPending();
          }
          if (isFourWave && wavePos !== undefined && status === 'FAIL' && debt[track] > 0) {
            const w = wavePos % 4;
            const hasSettledInWaveAfter = fourWaveMeta.slice(wavePos + 1).some((m, idx) => ((wavePos + 1 + idx) % 4 === w) && m.settledOrSent);
            const hasUpcomingWaitInWaveAfter =
              wavePos + 4 > lastSettledWavePos &&
              wavePos + 4 < fourWaveMeta.length &&
              !fourWaveMeta[wavePos + 4].checkedWait;
            const hasNextInWave = hasSettledInWaveAfter || hasUpcomingWaitInWaveAfter;
            const hasAnyAfter =
              wavePos < lastSettledWavePos ||
              (wavePos + 1 < fourWaveMeta.length && !fourWaveMeta[wavePos + 1].checkedWait);
            if (!hasNextInWave && hasAnyAfter) {
              carryHandoff = Math.round((carryHandoff + debt[track]) * 100) / 100;
              if (isProfitCarry) carryProfitHandoff = Math.round((carryProfitHandoff + (pendingProfits[track] || 0)) * 100) / 100;
              carryFails = Math.max(carryFails, failures[track] || 0);
              debt[track] = 0;
              pendingProfits[track] = 0;
              failures[track] = 0;
            }
          }
          reserved[track]=false;logicReserved[logicTrack]=false;
          if (type === 'ank') { previous[logicTrack] = { actual: confirmedAnkResult(rec), key: `${date}:ank_${index}` }; removalAssigned[logicTrack] = false; }
        } else if (rec.s==='WAIT' && !bypassedWait) {
          if (isFourWave && !reserved[track] && carryHandoff > 0) carryReserved = true;
          reserved[track]=true;logicReserved[logicTrack]=true;
        }
      }
      if (!sameAdminValue(rec,original)) {dict[index]=rec;dictChanged=true;}
    });
    if (dictChanged) {nextDay={...nextDay,[dictName]:dict};changed=true;}
  }
  return changed ? {...profile,config:liveConfig,dayRecords:{...profile.dayRecords,[date]:nextDay}} : originalProfile;
}

/** Opt-in custom accounts enforce each game’s own budget chronologically. */
function calculateSingleDateBacktestRecovery(profile:UserProfile,date:string):UserProfile {
 if(date>=businessDateIST()||!profile.dayRecords[date])return profile;
 const day=profile.dayRecords[date],raw=day.loopConfig||(day.recoveryConfigSnapshot||profile.config).dualLoops;
 if(!raw?.independentAccounts&&!profile.customLoopChanges&&!day.loopAccountStops)return calculateBacktestRecoveryBase(profile,date);
 const restored=restoreLoopAccountSkips(profile,date);
 const replay=calculateBacktestRecoveryBase(restored,date);
 const config=dayLoopConfig(archivedRecoveryProfile(replay,date),date);
 if(!config?.independentAccounts)return replay;
 const limited=applyBacktestLoopAccounts(replay,date);
 if(limited!==profile&&JSON.stringify(limited.dayRecords[date])===JSON.stringify(profile.dayRecords[date]))return profile;
 return limited;
}

export function calculateBacktestRecovery(profile:UserProfile,date:string):UserProfile {
 if(date>=businessDateIST()||!profile.dayRecords?.[date])return profile;
 const today = businessDateIST();
 const datesToReplay = Object.keys(profile.dayRecords)
   .filter(d => d >= date && d < today && /^\d{4}-\d{2}-\d{2}$/.test(d))
   .sort((a, b) => a.localeCompare(b));
 let current = profile;
 for (const d of datesToReplay) {
   const prevDay = current.dayRecords[d];
   const next = calculateSingleDateBacktestRecovery(current, d);
   if (d > date && next.dayRecords[d] === prevDay) {
     // Early convergence: if a subsequent day's records, rates and debt did not change,
     // all later days' inputs remain identical as well.
     break;
   }
   current = next;
 }
 return current;
}
