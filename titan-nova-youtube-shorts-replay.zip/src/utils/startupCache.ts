import {readStartupSnapshotJson} from './startupSnapshotStore';
import type { AppState } from '../types';

export type StartupCache = { json: string; hash: string };

/** A cached archive is only a candidate; the authenticated server must match it. */
export async function readStartupCache(key: string): Promise<StartupCache | null> {
  try {
    if (!globalThis.crypto?.subtle) return null;
    const json = await readStartupSnapshotJson(key);
    if (!json) return null;
    const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(json));
    return { json, hash: Array.from(new Uint8Array(bytes), byte => byte.toString(16).padStart(2, '0')).join('') };
  } catch { return null; }
}

export function verifiedCachedState(data: any, cache: StartupCache | null): AppState | null {
  if (data?.state?.profiles) return data.state;
  if (!data?.unchanged || !cache || data.stateHash !== cache.hash) return null;
  try {
    const state = JSON.parse(cache.json);
    return state?.profiles && typeof state.profiles === 'object' ? state : null;
  } catch { return null; }
}
