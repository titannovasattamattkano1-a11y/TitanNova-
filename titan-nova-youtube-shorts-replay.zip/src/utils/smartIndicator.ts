import type {DayMarketRecord} from '../types';
import {getScrapeSource} from './scrapeProvenance';
import {modelSourceVersion} from './marketModelCard';
const digits=(value:string)=>value.split(/[,|\s]+/).filter(Boolean);
/** Display saved applied evidence, never guess the historical choice from a current chart. */
export function smartIndicator(record:DayMarketRecord,date:string){
 const meta=record.smartSelection,source=getScrapeSource(record);
 if(!meta||meta.date!==date||!source||source.digits!==digits(meta.sourceDigits).join(', ')||!['TOP','REVERSE'].includes(meta.decision)||meta.samples<5||Number(meta.sourceVersion||0)>modelSourceVersion(record))return undefined;
 const output=digits(meta.digits),current=digits(record.d||'');
 if(output.length<4||output.length>6||new Set(output).size!==output.length||!output.every(d=>/^\d$/.test(d)&&source.digits.split(', ').includes(d))||!current.length||!current.every(d=>output.includes(d))||new Set(current).size!==current.length)return undefined;
 const filtered=current.length<output.length;
 const baseLabel=meta.decision==='REVERSE'?'RSMART':'SMART';
 const label=meta.digitCount?`${baseLabel} · ${meta.digitCount}D`:output.length>4?`${baseLabel} · ${output.length}D`:baseLabel;
 return {
  label,
  decision:meta.decision,
  filtered,
  samples:meta.samples,
  topHits:meta.topHits,
  reverseHits:meta.reverseHits,
  digitCount:output.length as 4|5|6,
  strongDigits:meta.strongDigits,
  supportDigits:meta.supportDigits,
  recommendedFilter:meta.recommendedFilter,
 };
}
