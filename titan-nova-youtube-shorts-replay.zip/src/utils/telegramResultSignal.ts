/** Same loose market-result acceptance and card/reply exclusion as the WA gateway. */
export function telegramResultSignal(text: string): boolean {
  return text.length > 5 && text.length < 500 && /\d/.test(text) &&
    /sridevi|kalyan|time\s*bazar|milan|rajdhani|main\s*bazar|supreme|madhur/i.test(text) &&
    !/digits\s*:|rate\s*:|total\s*:|congratulations dosto|bad luck dosto|pass\*?\s*hua|fail\*?\s*hua|next time dhamaka/i.test(text);
}
