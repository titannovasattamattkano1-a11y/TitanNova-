import {adminChanges,type AdminChange} from './adminStatePatch';
/** Compare serialized archives outside the UI thread; exact existing patch semantics. */
export class AdminPatchWorker {
 private worker:Worker|undefined;private disabled=false;private sequence=0;
 private pending=new Map<number,{resolve:(patch:AdminChange[])=>void;reject:(error:Error)=>void;timer:ReturnType<typeof setTimeout>}>();
 async compare(before:string,after:string):Promise<AdminChange[]>{
  if(before===after)return [];
  if(this.disabled)return adminChanges(JSON.parse(before),JSON.parse(after));
  if(!this.worker){
   try{
    this.worker=new Worker(new URL('../workers/adminPatch.worker.ts',import.meta.url),{type:'module'});
    this.worker.onmessage=event=>{const job=this.pending.get(event.data.id);if(!job)return;clearTimeout(job.timer);this.pending.delete(event.data.id);if(Array.isArray(event.data.patch))job.resolve(event.data.patch);else job.reject(new Error(event.data.error||'Workspace comparison failed'));};
    this.worker.onerror=event=>{event.preventDefault();this.dispose();};
   }catch{this.disabled=true;return adminChanges(JSON.parse(before),JSON.parse(after));}
  }
  const id=++this.sequence;
  return new Promise((resolve,reject)=>{
   const timer=setTimeout(()=>{this.pending.delete(id);reject(new Error('Workspace comparison timed out; retry save'));},15000);
   this.pending.set(id,{resolve,reject,timer});
   try{this.worker!.postMessage({id,before,after});}catch(error){clearTimeout(timer);this.pending.delete(id);reject(error instanceof Error?error:new Error('Workspace comparison failed'));}
  });
 }
 dispose(){this.worker?.terminate();this.worker=undefined;this.disabled=true;for(const job of this.pending.values()){clearTimeout(job.timer);job.reject(new Error('Workspace comparison interrupted; retry save'));}this.pending.clear();}
}
