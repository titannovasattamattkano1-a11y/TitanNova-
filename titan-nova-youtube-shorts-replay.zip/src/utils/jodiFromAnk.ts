import { normalizeAnkDigits } from './ankDigits';
export { normalizeAnkDigits } from './ankDigits';

/** Build the ordered Cartesian product: every OPEN ANK × every CLOSE ANK. */
export function buildJodisFromAnk(openRaw: unknown, closeRaw: unknown): string[] {
  const openDigits = normalizeAnkDigits(openRaw);
  const closeDigits = normalizeAnkDigits(closeRaw);
  const jodis: string[] = [];

  for (const openDigit of openDigits) {
    for (const closeDigit of closeDigits) {
      jodis.push(`${openDigit}${closeDigit}`);
    }
  }

  return jodis;
}
