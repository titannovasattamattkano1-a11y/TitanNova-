import { isSinglePatti, normalizePanelPatti } from './panelAnk';

export type SettlementType = 'ank' | 'jodi' | 'pannel' | 'panel';

export interface SettlementInput {
  type: SettlementType | string;
  /** Digits/tokens sent on the card, for example "4, 8, 0, 6, 9, 5". */
  digits?: unknown;
  /** Current card rate; used only when no frozen sentRate exists. */
  rate?: unknown;
  /** Rate frozen at the time the WhatsApp card was delivered. */
  sentRate?: unknown;
  /** Total investment frozen at delivery: token count × sentRate. */
  sentInvest?: unknown;
  winningDigit?: unknown;
  smartStaking?: SmartStakingInfo;
}

export interface SettlementResult {
  tokenCount: number;
  rate: number;
  invest: number;
  margin: number;
  payout: number;
  net: number;
}

export function settlementMargin(type: SettlementType | string): number {
  const normalized = String(type || '').toLowerCase();
  if (normalized === 'ank') return 9.5;
  if (normalized === 'jodi') return 95;
  return 150;
}

function rawSettlementTokens(digits: unknown): string[] {
  const raw = String(digits ?? '').trim();
  return raw ? raw.split(/[,|\s]+/).map((token) => token.trim()).filter(Boolean) : [];
}

export function normalizeSettlementTokens(type: SettlementType | string, digits: unknown): string[] {
  const normalized = String(type || '').toLowerCase();
  const pattern = normalized === 'ank' ? /^\d$/ : normalized === 'jodi' ? /^\d{2}$/ : /^\d{3}$/;
  return rawSettlementTokens(digits).filter((token) => {
    if (!pattern.test(token)) return false;
    if (normalized === 'pannel' || normalized === 'panel') return isSinglePatti(token);
    return true;
  });
}

export function areSettlementTokensValid(type: SettlementType | string, digits: unknown): boolean {
  const raw = rawSettlementTokens(digits);
  return raw.length > 0 && normalizeSettlementTokens(type, digits).length === raw.length;
}

export function countSettlementTokens(digits: unknown, type?: SettlementType | string): number {
  return type ? normalizeSettlementTokens(type, digits).length : rawSettlementTokens(digits).length;
}

/** Strict PASS matcher: ANK=1 digit, JODI=2-digit pair, PANEL=valid 3-digit Patti. */
export function settlementTokenHit(type: SettlementType | string, cardDigits: unknown, winning: unknown): boolean {
  const normalizedType = String(type || '').toLowerCase();
  const value = String(winning ?? '').trim();
  if (normalizedType === 'ank') {
    return /^\d$/.test(value) && normalizeSettlementTokens('ank', cardDigits).includes(value);
  }
  if (normalizedType === 'jodi') {
    return /^\d{2}$/.test(value) && normalizeSettlementTokens('jodi', cardDigits).includes(value);
  }
  if (!/^\d{3}$/.test(value)) return false;
  const winningPatti = normalizePanelPatti(value);
  return winningPatti !== null && normalizeSettlementTokens('pannel', cardDigits)
    .some((token) => normalizePanelPatti(token) === winningPatti);
}

/** Preserve an explicit zero target; fallback only for missing/invalid values. */
export function normalizeTargetProfit(value: unknown, fallback = 100): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.max(0, parsed) : Math.max(0, fallback);
}

export function isRecoveryRatePossible(type: SettlementType | string, digits: unknown): boolean {
  const tokenCount = countSettlementTokens(digits, type);
  return tokenCount > 0 && settlementMargin(type) > tokenCount;
}

function positiveNumber(value: unknown): number {
  const n = typeof value === 'number' ? value : Number.parseFloat(String(value ?? ''));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

/**
 * Single source of truth for PASS settlement.
 *
 * A card's rate is per selected token. The winning payout is one winning token
 * multiplied by the game margin; the full investment is tokenCount × rate.
 * sentRate/sentInvest take precedence so later UI edits cannot change a past
 * WhatsApp result message.
 */
export function calculateSettlement(input: SettlementInput): SettlementResult {
  const tokenCount = countSettlementTokens(input.digits, input.type);
  const baseRate = positiveNumber(input.sentRate) || positiveNumber(input.rate);
  const frozenInvest = positiveNumber(input.sentInvest);
  const margin = settlementMargin(input.type);

  // Every digit always carries the same unified flat rate (never divided into Strong/Support rates)
  const rate = baseRate || positiveNumber(input.smartStaking?.strongRate);
  const invest = frozenInvest || tokenCount * rate;
  const payout = rate * margin;
  return {
    tokenCount,
    rate,
    invest,
    margin,
    payout,
    net: payout - invest,
  };
}

/** Shared target + pending-loss recovery formula used by UI and backend. */
export function calculateRecoveryRate(
  type: SettlementType | string,
  digits: unknown,
  pendingLoss: unknown = 0,
  targetProfit: unknown = 100,
): string {
  if (!areSettlementTokensValid(type, digits)) return '';
  const tokenCount = countSettlementTokens(digits, type);
  const netMargin = settlementMargin(type) - tokenCount;
  if (netMargin <= 0) return '';
  const debt = Math.max(0, Number(pendingLoss) || 0);
  const target = normalizeTargetProfit(targetProfit, 0);
  return String(Math.max(10, Math.ceil(((debt + target) / netMargin) / 10) * 10));
}

export interface SmartStakingInfo {
  isSmartStaking: boolean;
  strongDigits: string[];
  supportDigits: string[];
  strongRate: number;
  supportRate: number;
  totalInvest: number;
  summary: string;
}

export function calculateSmartStakingRates(
  type: SettlementType | string,
  digits: unknown,
  pendingLoss: unknown,
  targetProfit: unknown,
  _preferredStrong?: string[],
  _preferredSupport?: string[],
): SmartStakingInfo {
  if (!areSettlementTokensValid(type, digits)) {
    return { isSmartStaking: false, strongDigits: [], supportDigits: [], strongRate: 0, supportRate: 0, totalInvest: 0, summary: '' };
  }
  const allTokens = normalizeSettlementTokens(type, digits);
  const flat = Number(calculateRecoveryRate(type, digits, pendingLoss, targetProfit)) || 10;
  return {
    isSmartStaking: false,
    strongDigits: allTokens,
    supportDigits: [],
    strongRate: flat,
    supportRate: flat,
    totalInvest: allTokens.length * flat,
    summary: `Flat ₹${flat}`,
  };
}
