import type { DayMarketRecord } from '../types';
import {getScrapeSource} from './scrapeProvenance';
import {cutCurrentSourceDigits} from './cumulativeSourceCut';

/** Cut source positions 1–4 only where their digits remain in the current box. */
export function removeFirstFourSourceIndices(record:DayMarketRecord|undefined,noOpAsRecord=false):DayMarketRecord|undefined {
  const source=getScrapeSource(record);
  return source?cutCurrentSourceDigits(record,source.digits.split(', ').slice(0,4),'FCUT',noOpAsRecord):undefined;
}
