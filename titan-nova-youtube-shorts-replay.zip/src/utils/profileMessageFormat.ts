import {businessDateIST} from './businessDate';
/** Update the WhatsApp format for exactly one profile without touching peers. */
import { reconcileVipAutoStopCard } from './vipAutoStop';
import {reconcileArchiveDayRevision} from './archiveSourceReconciliation';
import type {AdminChange} from './adminStatePatch';

/** Accepted Admin visibility edits are deliberate writes, not stale snapshots.
 * Keep them authoritative through archive/preference reconciliation too. */
export function acceptedVisibilityPreferences(stored:any,accepted:any,changes:AdminChange[]):any {
  if(!stored?.profiles||!Array.isArray(changes))return stored;
  let next=stored;
  for(const change of changes){
    const p=change.path;
    if(p[0]!=='profiles'||p[2]!=='dayRecords'||p.length<4||p.length>6)continue;
    const [pid,date]=[p[1],p[3]],day=accepted?.profiles?.[pid]?.dayRecords?.[date];
    if(!day||!stored.profiles[pid])continue;
    for(const track of ['visAnk','visJodi','visPan']){
      if(p.length>4&&p[4]!==track)continue;
      const incoming=day[track];if(!incoming||typeof incoming!=='object')continue;
      const old=next.profiles[pid],oldDay=old.dayRecords?.[date]||{};
      const visibility=p.length===6?{...oldDay[track]}:{...incoming};
      if(p.length===6){if(typeof incoming[p[5]]==='boolean')visibility[p[5]]=incoming[p[5]];else delete visibility[p[5]];}
      next={...next,profiles:{...next.profiles,[pid]:{...old,dayRecords:{...old.dayRecords,[date]:{...oldDay,[track]:visibility}}}}};
    }
  }
  return next;
}

/** Atomic custom controls own these fields. Rebase a background config patch
 * before conflict detection, rather than reporting our own save as a conflict. */
export function protectCustomLoopChanges(changes:AdminChange[],stored:any):AdminChange[]{
  if(!Array.isArray(changes))return changes;
  return changes.flatMap(change=>{
    const p=change?.path,profile=Array.isArray(p)&&p[0]==='profiles'?stored?.profiles?.[p[1]]:undefined;
    if(!profile?.customLoopChanges)return [change];
    if(p[2]==='customLoopChanges'||p[2]==='dayRecords'&&p[4]==='loopConfig'&&profile.dayRecords?.[p[3]]?.loopConfig)return [];
    if(p.length===3&&p[2]==='config')return [{...change,
      ...(change.beforeExists?{before:{...change.before,dualLoops:profile.config.dualLoops}}:{}),
      ...(change.exists?{value:{...change.value,dualLoops:profile.config.dualLoops}}:{}),
    }];
    return [change];
  });
}

export function applyProfileMessageFormat<T extends { profiles?: Record<string, any> }>(
  input: T,
  profileId: string,
  detailedMessage: boolean,
): T {
  const pid = String(profileId || '').trim();
  const sourceProfile = input?.profiles?.[pid];
  if (!pid || !sourceProfile) throw new Error('valid profile required');

  return {
    ...input,
    profiles: {
      ...(input.profiles || {}),
      [pid]: {
        ...sourceProfile,
        config: {
          ...(sourceProfile.config || {}),
          detailedMessage,
        },
      },
    },
  };
}

/**
 * A complete Admin dashboard save may be based on an older browser snapshot.
 * Preferences written through atomic profile endpoints must win over that
 * stale payload, while deliberate Admin scheduleTypeEnabled/marketEnabled changes
 * in incomingConfig are preserved and never overwritten by stale stored values.
 */
export function preserveAtomicProfilePreferences<T extends { profiles?: Record<string, any> }>(
  incoming: T,
  stored: T | null | undefined,
): T {
  if (!incoming?.profiles || !stored?.profiles) return incoming;
  const profiles = { ...incoming.profiles };

  for (const [pid, incomingProfile] of Object.entries(profiles)) {
    const storedProfile = stored.profiles[pid];
    if (!incomingProfile || !storedProfile) continue;

    const storedConfig = storedProfile.config || {};
    const incomingConfig = incomingProfile.config || {};
    const config = {
      ...incomingConfig,
      ...(storedProfile.customLoopChanges?{dualLoops:storedConfig.dualLoops}:{}),
      ...((storedConfig.cardSenderFormat==='text'||storedConfig.cardSenderFormat==='png'||storedConfig.cardSenderFormats)?{cardSenderFormat:storedConfig.cardSenderFormat,cardSenderFormats:storedConfig.cardSenderFormats?{...storedConfig.cardSenderFormats}:undefined}:{}),
      ...(typeof storedConfig.autoResultParity==='boolean'?{autoResultParity:storedConfig.autoResultParity}:{}),
      ...(typeof storedConfig.detailedMessage === 'boolean'
        ? { detailedMessage: storedConfig.detailedMessage }
        : {}),
      ...(storedConfig.marketEnabled || incomingConfig.marketEnabled
        ? { marketEnabled: { ...(storedConfig.marketEnabled || {}), ...(incomingConfig.marketEnabled || {}) } }
        : {}),
      ...(storedConfig.scheduleTypeEnabled || incomingConfig.scheduleTypeEnabled
        ? {
            scheduleTypeEnabled: {
              ...(storedConfig.scheduleTypeEnabled || {}),
              ...(incomingConfig.scheduleTypeEnabled || {}),
            },
          }
        : {}),
    };

    const dayRecords = { ...(incomingProfile.dayRecords || {}) };
    if(storedProfile.customLoopChanges)for(const [date,day] of Object.entries(storedProfile.dayRecords||{}) as [string,any][]){
      if(day.loopConfig)dayRecords[date]={...(dayRecords[date]||day),loopConfig:day.loopConfig};
    }
    for (const [date, storedDay] of Object.entries(storedProfile.dayRecords || {}) as Array<[string, any]>) {
      const incomingDay = dayRecords[date];
      if (Number(storedDay?.backtestRevision || 0) > Number(incomingDay?.backtestRevision || 0)) {
        dayRecords[date] = reconcileArchiveDayRevision(incomingDay,storedDay,incomingConfig,storedConfig,date);
        continue;
      }
      if (!incomingDay || !storedDay) {if(date===businessDateIST()&&storedDay?.loopAccountStops)dayRecords[date]={...storedDay};continue;}
      const reconciledDay = { ...incomingDay };
      for (const dictName of ['data', 'jodiData', 'pannelData']) {
        if (!incomingDay[dictName]) continue;
        reconciledDay[dictName] = { ...incomingDay[dictName] };
        for (const [index, record] of Object.entries(incomingDay[dictName])) {
          reconciledDay[dictName][index] = reconcileVipAutoStopCard(record, storedDay[dictName]?.[index]);
        }
      }
      dayRecords[date] = {
        ...reconciledDay,
        ...(date===businessDateIST()&&storedDay.loopAccountStops?{loopAccountStops:storedDay.loopAccountStops}:{}),
        visAnk: { ...(incomingDay.visAnk || {}), ...(storedDay.visAnk || {}) },
        visJodi: { ...(incomingDay.visJodi || {}), ...(storedDay.visJodi || {}) },
        visPan: { ...(incomingDay.visPan || {}), ...(storedDay.visPan || {}) },
      };
    }

    profiles[pid] = {
      ...incomingProfile,
      ...(storedProfile.customLoopChanges?{customLoopChanges:storedProfile.customLoopChanges}:{}),
      ...(typeof storedProfile.profitMilestoneNotificationsEnabled === 'boolean' ? { profitMilestoneNotificationsEnabled: storedProfile.profitMilestoneNotificationsEnabled } : {}),
      ...(storedProfile.vipGameRuns ? { vipGameRuns: structuredClone(storedProfile.vipGameRuns) } : {}),
      config,
      dayRecords,
      ...(storedProfile.vipScheduleEnabled || incomingProfile.vipScheduleEnabled
        ? {
            vipScheduleEnabled: {
              ...(storedProfile.vipScheduleEnabled || {}),
              ...(incomingProfile.vipScheduleEnabled || {}),
            },
          }
        : {}),
    };
  }

  return { ...incoming, profiles };
}

export function applyProfileCardSenderFormat<T extends {profiles?:Record<string,any>}>(input:T,profileId:string,format:'text'|'png',platform?:'whatsapp'|'telegram'):T {
 if(format!=='text'&&format!=='png')throw new Error('Invalid sender format');
 if(platform!==undefined&&platform!=='whatsapp'&&platform!=='telegram')throw new Error('Invalid sender platform');
 const profile=input.profiles?.[profileId];if(!profile)throw new Error('valid profile required');
 return {...input,profiles:{...input.profiles,[profileId]:{...profile,config:{...profile.config,...(platform?{cardSenderFormats:{...profile.config?.cardSenderFormats,[platform]:format}}:{cardSenderFormat:format,cardSenderFormats:undefined})}}}};
}
