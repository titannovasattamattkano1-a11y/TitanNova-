import {resolveLoopAccountConfig} from './loopAccounts';
import { reconcileCardRestore } from './cardRestore';
import type { GameType, UserProfile } from '../types';
import { calculateSettlement } from './settlement';
import { activeLoopIds, normalizeDualLoops } from './dualLoops';

export interface VipGameRun {
  date: string;
  on: boolean;
  baseProfit: number;
  baseInvest: number;
  baselineCards?: Record<string, { profit: number; invest: number }>;
  reason?: 'TARGET_REACHED' | 'CAPITAL_LIMIT' | 'MANUAL_OFF';
  updatedAt: number;
}
export type VipGameRuns = Partial<Record<GameType, VipGameRun>>;

/** Only real live settlements and reserved/delivered stakes count. */
export function vipGameTotals(runtime: any, type: GameType, excludeQueuedKey?: string) {
  let profit = 0, invest = 0;
  for (const [key, card] of Object.entries(runtime?.cards || {}) as Array<[string, any]>) {
    if (!card || typeof card !== 'object') continue;
    if (!key.startsWith(`${type}_`) || card.s === 'SKIP') continue;
    const settled = card.s === 'PASS' || card.s === 'FAIL';
    const delivered = Boolean(card.sentRate || card.sentDigits || card.dispatchState === 'SENT' || card.dispatchState === 'SETTLED');
    if (card.backtestResult && !delivered) continue;
    const reserved = card.dispatchState === 'QUEUED' && key !== excludeQueuedKey && excludeQueuedKey !== '*';
    if (!settled && !delivered && !reserved) continue;
    const winDigit = card.manualResult || card.scrapeResultDigit;
    const value = calculateSettlement({ type, digits: card.sentAt ? (card.sentDigits || card.d) : card.d, rate: card.r || card.recRate, sentRate: card.sentAt ? card.sentRate : undefined, sentInvest: card.sentAt ? card.sentInvest : undefined, smartStaking: card.smartStaking, winningDigit: winDigit });
    if (value.invest <= 0) continue;
    invest += value.invest;
    if (settled) profit += (card.s === 'PASS' ? value.payout : 0) - value.invest;
  }
  return { profit, invest };
}

/** Cash still tied up in sent cards or queue reservations, excluding a job's own reservation. */
export function vipPendingInvest(runtime: any, type: GameType, excludeQueuedKey?: string) {
  const cards = Object.fromEntries(Object.entries(runtime?.cards || {}).filter(([, card]: [string, any]) => card && card.s !== 'PASS' && card.s !== 'FAIL'));
  return vipGameTotals({ cards }, type, excludeQueuedKey).invest;
}

export function vipBaselineCards(runtime: any, type: GameType) {
  const baseline: Record<string, { profit: number; invest: number }> = {};
  for (const [key, card] of Object.entries(runtime?.cards || {})) {
    if (!key.startsWith(`${type}_`)) continue;
    const totals = vipGameTotals({ cards: { [key]: card } }, type, '*');
    if (totals.invest > 0) baseline[key] = totals;
  }
  return baseline;
}

/** Daily budget settings; protocol targets remain exclusively per-card recovery inputs. */
export function vipGameLimits(saved: UserProfile | undefined, runtime: any) {
  const cfg = saved?.config;
  const loops = normalizeDualLoops(runtime?.loopConfig, cfg);
  const target = loops?.enabled
    ? activeLoopIds(loops).reduce((sum, id) => sum + loops.loops[id].dayTarget, 0)
    : Number(cfg?.dayTarget || 0);
  const capital = loops?.enabled
    ? activeLoopIds(loops).reduce((sum, id) => sum + loops.loops[id].capital, 0)
    : Number(cfg?.capital || 0);
  return { target: Math.max(0, target), capital: Math.max(0, capital) };
}

export function vipStopReason(pid: string, date: string, saved: UserProfile | undefined, runtime: any, type: GameType, nextInvest = 0, excludeQueuedKey?: string): VipGameRun['reason'] | undefined {
  if (pid === 'admin1' || !saved || !runtime) return undefined;
  const run = saved.vipGameRuns?.[type];
  const independent=resolveLoopAccountConfig(saved,runtime,date);
  if(run&&!run.on&&(!independent||!run.reason||run.reason==='MANUAL_OFF'))return run.reason||'MANUAL_OFF';
  if(independent)return undefined;
  const ownCard = excludeQueuedKey ? runtime.cards?.[excludeQueuedKey] : undefined;
  if (ownCard?.sentRate || ownCard?.sentDigits) nextInvest = 0;
  const totals = vipGameTotals(runtime, type, nextInvest > 0 ? excludeQueuedKey : '*');
  const limits = vipGameLimits(saved, runtime);
  const profit = totals.profit - (run?.date === date ? run.baseProfit : 0);
  const pending = vipPendingInvest(runtime, type, nextInvest > 0 ? excludeQueuedKey : '*');
  if (limits.target > 0 && profit >= limits.target) return 'TARGET_REACHED';
  // Settled profit is reusable cash; sent/queued stakes remain reserved.
  // Exact-capital pending stakes must be allowed to settle before latching OFF.
  if (limits.capital > 0 && pending + Math.max(0, nextInvest) > limits.capital + profit) return 'CAPITAL_LIMIT';
  return undefined;
}

export function skipVipUnsentCards(runtime: any, type: GameType): number {
  let count = 0;
  for (const [key, card] of Object.entries(runtime?.cards || {}) as Array<[string, any]>) {
    if (!card || typeof card !== 'object') continue;
    if (!key.startsWith(`${type}_`) || (card.s && card.s !== 'WAIT') || card.sentRate || card.sentDigits || card.dispatchState === 'SENT' || card.dispatchState === 'SETTLED') continue;
    card.s = 'SKIP';
    card.vipAutoStopSkipped = true;
    delete card.dispatchState; delete card.dispatchKey; delete card.queuedAt;
    count++;
  }
  return count;
}

/** Server-owned pause markers must not be resurrected by an old browser tab. */
export function reconcileVipAutoStopCard(incoming: any, current: any): any {
  incoming = reconcileCardRestore(incoming, current);
  if (incoming?.vipAutoStopSkipped && current && !current.vipAutoStopSkipped) {
    return { ...incoming, s: current.s || 'WAIT', vipAutoStopSkipped: undefined };
  }
  return incoming;
}

/** An unsent queue lock without a live job is not a real capital reservation. */
export function clearVipOrphanedReservations(runtime: any, pid: string, pending: any[], sentSchedules: Record<string, boolean>): number {
  let cleared = 0;
  for (const [key, card] of Object.entries(runtime?.cards || {}) as Array<[string, any]>) {
    if (!card || card.dispatchState !== 'QUEUED' || card.sentRate || card.sentDigits) continue;
    const live = pending.some(job => job?.status === 'pending' && job.broadcastKind === 'vip-auto-card' &&
      String(job.profileId) === pid && `${job.cardType}_${Number(job.index)}` === key);
    if (live || (card.dispatchKey && sentSchedules[card.dispatchKey])) continue;
    delete card.dispatchState; delete card.dispatchKey; delete card.queuedAt; cleared++;
  }
  return cleared;
}
