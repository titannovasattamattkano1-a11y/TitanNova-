import type {DayMarketRecord} from '../types';
import {getScrapeSource} from './scrapeProvenance';
import {cutCurrentSourceDigits} from './cumulativeSourceCut';
/** Original source positions 7–10 are cut from the current box; never rebuild it. */
export function removeLastFourSourceIndices(record:DayMarketRecord|undefined):DayMarketRecord|undefined {
  const source=getScrapeSource(record);
  if(!source)return;
  const next=cutCurrentSourceDigits(record,source.digits.split(', ').slice(6));
  return next?{...next,positionRule:'LCUT'}:undefined;
}
