import {adminCardIntent,hasAutomaticRate,mergeCardConflict,mergeConfigConflict} from './adminConflictMerge';
import {freshSourceOverEmpty,freshSourceReplacement,mergeMaterializedDay} from './freshEmptySource';
/** Optimistic workspace edits. Real competing card edits stay indivisible. */
export interface AdminChange { path: string[]; beforeExists: boolean; before?: any; exists: boolean; value?: any }
const plain=(v:any)=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const own=(v:any,k:string)=>plain(v)&&Object.prototype.hasOwnProperty.call(v,k)&&v[k]!==undefined;
const forbidden=new Set(['__proto__','constructor','prototype']);
export function sameAdminValue(a:any,b:any):boolean {
 if(a===b)return true;
 if(Array.isArray(a)||Array.isArray(b))return Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((v,i)=>sameAdminValue(v,b[i]));
 if(!plain(a)||!plain(b))return false;
 const keys=Object.keys(a).filter(k=>a[k]!==undefined);return keys.length===Object.keys(b).filter(k=>b[k]!==undefined).length&&keys.every(k=>own(b,k)&&sameAdminValue(a[k],b[k]));
}
function atomic(path:string[]):boolean {
 return path[0]==='profiles'&&((path.length===6&&path[2]==='dayRecords'&&['data','jodiData','pannelData'].includes(path[4]))||path[2]==='config');
}
function syncClock(path:string[]):boolean {
 return path[0]==='profiles'&&(
  path[2]==='dayRecords'&&(path.length===5&&path[4]==='backtestRevision'||path.length===6&&path[4]==='backtestRecoveryPolicy'&&path[5]==='updatedAt')||
  path[2]==='customLoopChanges'&&path.length===5&&path[4]==='revision'||
  path[2]==='dayRecords'&&path.length===6&&path[4]==='loopConfig'&&path[5]==='revision');
}
export function adminChanges(before:any,after:any):AdminChange[]{
 const changes:AdminChange[]=[];
 const visit=(a:any,b:any,path:string[],ae:boolean,be:boolean)=>{
  if(ae===be&&a===b)return;
  if(ae&&be&&plain(a)&&plain(b)&&!atomic(path)){
   for(const k of new Set([...Object.keys(a),...Object.keys(b)])){
    if(!own(a,k)&&!own(b,k))continue;
    if(!path.length&&k==='activeId')continue; // Device navigation is local.
    if(forbidden.has(k))throw new Error('Invalid workspace key');
    visit(a[k],b[k],[...path,k],own(a,k),own(b,k));
   }
  }else if(ae!==be||!sameAdminValue(a,b)) changes.push({path,beforeExists:ae,...(ae?{before:a}:{}),exists:be,...(be?{value:b}:{})});
 };
 visit(before,after,[],true,true);return changes;
}
export function applyAdminChanges(current:any,changes:AdminChange[],keepNonConflicting=false):{state:any;conflicts:string[]} {
 if(!Array.isArray(changes)||changes.length>50000)throw new Error('Invalid workspace patch');
 const conflicts:string[]=[];const accepted:AdminChange[]=[];const seen=new Set<string>();const ancestors=new Set<string>();
 for(const c of changes){
  if(!c||!Array.isArray(c.path)||!c.path.length||c.path.length>16||c.path.some(k=>typeof k!=='string'||!k||forbidden.has(k))||typeof c.exists!=='boolean'||typeof c.beforeExists!=='boolean')throw new Error('Invalid workspace patch path');
  if(c.path[0]==='activeId')continue;
  const id=JSON.stringify(c.path);
  if(seen.has(id)||ancestors.has(id)||c.path.some((_,i)=>i>0&&seen.has(JSON.stringify(c.path.slice(0,i)))))throw new Error('Overlapping workspace patch');
  seen.add(id);for(let i=1;i<c.path.length;i++)ancestors.add(JSON.stringify(c.path.slice(0,i)));
  let parent=current;let missing=false;
  for(const key of c.path.slice(0,-1)){if(!own(parent,key)||!plain(parent[key])){missing=true;break;}parent=parent[key];}
  const key=c.path[c.path.length-1],exists=!missing&&own(parent,key),value=exists?parent[key]:undefined;
  if(!missing&&exists===c.exists&&(!exists||sameAdminValue(value,c.value)))continue; // Safe retry after lost response.
  if(missing||exists!==c.beforeExists||(exists&&!sameAdminValue(value,c.before))){
   if(!missing&&exists&&c.exists&&c.path[0]==='profiles'&&c.path[2]==='dayRecords'){
    if(!c.beforeExists&&c.path.length===5&&['visAnk','visJodi','visPan'].includes(c.path[4])&&plain(value)&&plain(c.value)&&Object.values(c.value).every(v=>typeof v==='boolean')){
     accepted.push({...c,value:{...value,...c.value}});continue;
    }
    const type=c.path[4]==='data'?'ank':c.path[4]==='jodiData'?'jodi':c.path[4]==='pannelData'?'pannel':undefined;
    const fresh=!c.beforeExists?mergeMaterializedDay(c.path,value,c.value)
     :c.path.length===6&&type?(freshSourceReplacement(value,c.value,type)||freshSourceOverEmpty(value,c.value,type)):undefined;
    if(fresh!==undefined){accepted.push({...c,value:fresh});continue;}
   }
   if(!missing&&exists&&c.exists&&syncClock(c.path)&&typeof value==='number'&&Number.isFinite(value)&&typeof c.value==='number'&&Number.isFinite(c.value)){
    if(c.value>value)accepted.push(c);continue;
   }
   if(!missing&&exists&&c.beforeExists&&c.exists&&c.path[0]==='profiles'){
    const merged=c.path.length===3&&c.path[2]==='config'?mergeConfigConflict(c.before,value,c.value,sameAdminValue)
     :c.path.length===6&&c.path[2]==='dayRecords'&&['data','jodiData','pannelData'].includes(c.path[4])?mergeCardConflict(c.before,value,c.value,sameAdminValue):{kind:'conflict' as const};
    if(merged.kind==='keep')continue;
    if(merged.kind==='set'){accepted.push({...c,value:merged.value});continue;}
   }
   conflicts.push(c.path.join('/'));
  }else accepted.push(c);
 }
 if(conflicts.length&&!keepNonConflicting)return {state:current,conflicts};
 // Copy each changed ancestor once per transaction. Bulk card patches share
 // large day dictionaries; copying them for every card makes work quadratic.
 // Only objects created here may be mutated, never the input or patch values.
 let state=current;
 const copied=new WeakSet<object>();
 for(const c of accepted){
  if(!copied.has(state)){state={...state};copied.add(state);}
  let next=state;
  for(const key of c.path.slice(0,-1)){
   if(!copied.has(next[key])){next[key]={...next[key]};copied.add(next[key]);}
   next=next[key];
  }
  const key=c.path[c.path.length-1];if(c.exists)next[key]=c.value;else delete next[key];
 }
 return {state,conflicts};
}

/** Fingerprint only the conflicting edit inputs, not an entire volatile archive. */
export function adminConflictFingerprint(remote:any,changes:AdminChange[],conflicts:string[]):string {
 const paths=new Set(conflicts);
 const rows=changes.filter(c=>paths.has(c.path.join('/'))).map(c=>{
  const current=c.path.reduce((value,key)=>value?.[key],remote);
  if(c.path.length===6&&c.path[2]==='dayRecords'){
   const automatic=hasAutomaticRate(c.before,c.value,current);
   return {path:c.path,local:adminCardIntent(c.value,automatic),remote:adminCardIntent(current,automatic)};
  }
  if(c.path.length===3&&c.path[2]==='config'){
   const keys=[...new Set([...Object.keys(c.before||{}),...Object.keys(c.value||{})])].filter(k=>!sameAdminValue(c.before?.[k],c.value?.[k]));
   return {path:c.path,local:Object.fromEntries(keys.map(k=>[k,c.value?.[k]])),remote:Object.fromEntries(keys.map(k=>[k,current?.[k]]))};
  }
  return {path:c.path,local:c.value,remote:current};
 });
 return JSON.stringify(rows,(_key,value)=>plain(value)?Object.fromEntries(Object.keys(value).sort().filter(k=>value[k]!==undefined).map(k=>[k,value[k]])):value);
}

/** Reuse unchanged JSON branches after a remote refresh so memoized consumers stay stable.
 * Own undefined object fields are equivalent to absent fields, as in workspace patches.
 */
export function shareAdminSnapshot(previous:any,incoming:any):any {
 if(previous===incoming)return previous;
 if(Array.isArray(previous)&&Array.isArray(incoming)){
  let same=previous.length===incoming.length;
  const next=incoming.map((value,i)=>{const shared=shareAdminSnapshot(previous[i],value);if(shared!==previous[i])same=false;return shared;});
  return same?previous:next;
 }
 if(!plain(previous)||!plain(incoming))return incoming;
 const keys=Object.keys(incoming).filter(k=>incoming[k]!==undefined);
 let same=keys.length===Object.keys(previous).filter(k=>previous[k]!==undefined).length;
 const next:any={};
 for(const key of keys){
  const shared=shareAdminSnapshot(previous[key],incoming[key]);
  Object.defineProperty(next,key,{value:shared,enumerable:true,writable:true,configurable:true});
  if(!own(previous,key)||shared!==previous[key])same=false;
 }
 return same?previous:next;
}
