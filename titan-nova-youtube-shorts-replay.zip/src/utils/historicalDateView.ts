/** Background archive replay is an edit-side effect, not a date-view side effect.
 * Every date/profile visit starts with a fresh key; its saved cards are read as-is.
 * Once on that same day, explicit state changes may request a recomputation.
 */
export interface HistoricalViewState {
  key: string;
  signature: string;
  carryMode?: string;
}
export function shouldReplayHistoricalDay(
  previous: HistoricalViewState | null,
  current: HistoricalViewState,
  carryModeChanged: boolean,
): boolean {
  return Boolean(previous && previous.key === current.key &&
    (previous.signature !== current.signature || carryModeChanged));
}
