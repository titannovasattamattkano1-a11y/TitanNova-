import type {DayMarketRecord,CardSourceMode,UserProfile} from '../types';
import evidence from '../data/marketHistoryChoices';
import {getFullScrapeSource as getScrapeSource,getScrapeResultIndex} from './scrapeProvenance';
import {findHistoricalMarketRecord} from './cardHistory';
import {actualForGame,evaluateBacktest,type DatedActual} from './backtestResult';
export type MarketHistoryMode='keep6'|'remove4';
export type MarketHistorySource='AUTO'|'WEEKDAY'|'COMBO'|'DAY_COMBO';
export const MARKET_HISTORY_CUTOFF=evidence.cutoff; // Legacy report metadata only; never used to choose live/range Apply.
export const HISTORY_WINDOW_DAYS=30;
export const HISTORY_CHOICE_POLICY='rolling-30-weighted-321-v1';
export function historyWindowStart(date:string):string {
 const parsed=new Date(date+'T00:00:00Z');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(parsed.getTime())||parsed.toISOString().slice(0,10)!==date)throw new Error('Valid History Apply date required');
 parsed.setUTCDate(parsed.getUTCDate()-HISTORY_WINDOW_DAYS);return parsed.toISOString().slice(0,10);
}
export const marketHistorySourceLabel=(mode:CardSourceMode)=>({AUTO:'Auto',WEEKDAY:'Day',COMBO:'Combo',DAY_COMBO:'Day Mix',PAIR_FOLLOW:'Pair Follow',PAIR_COMBO:'Pair Combo',MSSD:'MSSD',DIGIT_FOLLOW:'Digit Follow',PANNA_FOLLOW:'Panna Follow'} as Partial<Record<CardSourceMode,string>>)[mode];
const normalize=(name:string)=>String(name||'').trim().replace(/\s+/g,' ').toUpperCase();
const byMarket=new Map<string,(typeof evidence.choices)[number]>(evidence.choices.map(choice=>[choice.sourceMode+':'+choice.market,Object.freeze(choice)]));
/** O/C stores AUTO for OPEN and WEEKDAY for CLOSE, so its evidence follows the actual source. */
export function marketHistoryChoice(name:string,sourceMode:CardSourceMode='AUTO'){return byMarket.get(sourceMode+':'+normalize(name));}
export const supportsMarketHistorySource=(name:string,mode:CardSourceMode)=>byMarket.has(mode+':'+normalize(name));
export function canApplyMarketHistoryChoice(record:DayMarketRecord|undefined,name:string):boolean{
 const source=getScrapeSource(record);
 return Boolean(source&&supportsMarketHistorySource(name,source.mode)&&record&&record.s==='WAIT'&&!record.manualStatus&&!record.sentDigits&&!record.sentRate&&!record.dispatchState&&!record.deliveryRestoredAt&&!record.vipAutoStopSkipped&&(!record.marketName||normalize(record.marketName)===normalize(name)));
}
/** Never mix position indices from another scraping formula. Seed remains private, not an archive edit. */
export function sourceHistoryIndices(days:UserProfile['dayRecords'],date:string,index:number,name:string,mode:CardSourceMode,count:4|6,seed:UserProfile['dayRecords']={},notBefore=historyWindowStart(date)){
 const found:number[]=[];
 const dates=[...new Set([...Object.keys(days),...Object.keys(seed)])].filter(d=>/^\d{4}-\d{2}-\d{2}$/.test(d)&&d>=notBefore&&d<date&&Number.isFinite(Date.parse(d))&&new Date(d).toISOString().slice(0,10)===d).sort().reverse();
 for(const d of dates){
  const saved=findHistoricalMarketRecord(days[d]?.data,index,name),prior=findHistoricalMarketRecord(seed[d]?.data,index,name);
  const rec=getScrapeSource(saved)?.mode===mode?saved:getScrapeSource(prior)?.mode===mode?prior:undefined;
  if(rec?.s!=='PASS'&&rec?.s!=='FAIL')continue;
  const position=getScrapeResultIndex(rec);
  if(position!==undefined&&!found.includes(position))found.push(position);
  if(found.length===count)break;
 }
 return found;
}
export interface RollingHistoryChoice {
 mode?:MarketHistoryMode; keepHits:number; removeHits:number; keepWeight:number; removeWeight:number; samples:number;
 startDate:string; endDate:string; reason?:string;
}
/** Matched walk-forward comparison. Each trial uses only earlier positions inside this same 30-day window. */
export function rollingHistoryChoice(days:UserProfile['dayRecords'],date:string,index:number,name:string,mode:CardSourceMode,seed:UserProfile['dayRecords']={}):RollingHistoryChoice {
 const startDate=historyWindowStart(date),endDate=new Date(Date.parse(date+'T00:00:00Z')-86400000).toISOString().slice(0,10);
 let keepHits=0,removeHits=0,keepWeight=0,removeWeight=0,samples=0;
 const dates=[...new Set([...Object.keys(days),...Object.keys(seed)])].filter(d=>/^\d{4}-\d{2}-\d{2}$/.test(d)&&d>=startDate&&d<date&&Number.isFinite(Date.parse(d))&&new Date(d).toISOString().slice(0,10)===d).sort();
 // Inner walk-forward comparisons already exclude everything outside this exact
 // window. Slice once so each trial does not re-enumerate the full archive.
 const windowDays:UserProfile['dayRecords']={},windowSeed:UserProfile['dayRecords']={};
 for(const day of dates){if(days[day])windowDays[day]=days[day];if(seed[day])windowSeed[day]=seed[day];}
 for(const day of dates){
  const saved=findHistoricalMarketRecord(days[day]?.data,index,name),prior=findHistoricalMarketRecord(seed[day]?.data,index,name);
  const rec=getScrapeSource(saved)?.mode===mode?saved:getScrapeSource(prior)?.mode===mode?prior:undefined;
  if(rec?.s!=='PASS'&&rec?.s!=='FAIL')continue;
  const actualIndex=getScrapeResultIndex(rec);if(actualIndex===undefined)continue;
  const earlier=sourceHistoryIndices(windowDays,day,index,name,mode,6,windowSeed,startDate);
  if(earlier.length!==6)continue; // Both methods must be evaluated on exactly the same eligible dates.
  const age=Math.round((Date.parse(date)-Date.parse(day))/86400000),weight=age<=10?3:age<=20?2:1;
  samples++;if(earlier.includes(actualIndex)){keepHits++;keepWeight+=weight;}
  if(!earlier.slice(0,4).includes(actualIndex)){removeHits++;removeWeight+=weight;}
 }
 const result={keepHits,removeHits,keepWeight,removeWeight,samples,startDate,endDate};
 if(!supportsMarketHistorySource(name,mode))return {...result,reason:'Unsupported market/source'};
 if(samples<5)return {...result,reason:`Only ${samples}/5 comparable same-source results in the previous 30 days`};
 if(keepWeight===removeWeight)return {...result,reason:'Keep6 and Remove4 weighted scores tied in the previous 30 days; card unchanged'};
 return {...result,mode:keepWeight>removeWeight?'keep6':'remove4'};
}
/** New Apply only: preserve protected VIP cards while retaining ordinary editable source mirroring. */
export function canProjectMarketHistorySource(record:DayMarketRecord|undefined,name:string){
 return !record||Boolean(record.s==='WAIT'&&!record.manualStatus&&!record.sentDigits&&!record.sentRate&&!record.dispatchState&&!record.deliveryRestoredAt&&!record.vipAutoStopSkipped&&(!record.marketName||normalize(record.marketName)===normalize(name)));
}
interface HistoryReply{status:string;staleCache?:boolean;message?:string;targetDate?:string;digits?:string;sourceDigits?:Partial<Record<CardSourceMode,string>>;actual?:DatedActual|null}
function checkedHistoryActual(actual:DatedActual|null|undefined,date:string){
 if(!actual)return undefined;
 if(actual.date!==date)throw new Error('Prior result returned a different date');
 for(const [field,pattern] of [['jodi',/^\d{2}$/],['open',/^\d{3}$/],['close',/^\d{3}$/]] as const){
  const value=actual[field];if(value!==undefined&&(typeof value!=='string'||!pattern.test(value)))throw new Error('Invalid dated '+field+' result');
 }
 return actual;
}
export async function prepareSourceHistory(options:{days:UserProfile['dayRecords'];date:string;index:number;market:string;mode:MarketHistorySource;count:4|6;completeWindow?:boolean;scrape:(body:Record<string,unknown>)=>Promise<HistoryReply>;isCurrent:()=>boolean}){
 const {days,date,index,market,mode,count}=options,seed:UserProfile['dayRecords']={};
 const assertCurrent=()=>{if(!options.isCurrent())throw new Error('Card changed; apply cancelled');};
 const fetchDate=async(offset:number)=>{
  assertCurrent();
  const priorDate=new Date(Date.parse(date+'T00:00:00Z')-offset*86400000).toISOString().slice(0,10);
  // Preserve real same-source WAIT/manual/restore history; it owns its day.
  if(getScrapeSource(findHistoricalMarketRecord(days[priorDate]?.data,index,market))?.mode===mode)return;
  const body={market,type:'ank',backtest:true,targetDate:priorDate,isCombo:mode==='COMBO'||mode==='DAY_COMBO',selectionMode:mode==='DAY_COMBO'?'same_weekday_vertical_combo':mode==='WEEKDAY'?'same_weekday_vertical':'pre_target_recent'};
  const response=await options.scrape(body);assertCurrent();
  if(response.status!=='success'||response.staleCache)throw new Error(response.message||'Fresh prior-date source unavailable');
  if(response.targetDate!==priorDate||(response.actual&&response.actual.date!==priorDate))throw new Error('Prior source returned a different date');
  const digits=response.sourceDigits?.[mode];
  if(typeof digits!=='string'||!digits)throw new Error('Original source provenance missing for '+marketHistorySourceLabel(mode));
  const rec:DayMarketRecord={s:'WAIT',d:digits,r:'',marketName:market,sourceMode:mode,scrapeSource:{mode,digits}};
  if(!getScrapeSource(rec))throw new Error('Invalid original ten-digit source provenance');
  let actual=checkedHistoryActual(response.actual,priorDate);
  if(actualForGame(actual||undefined,'ank',market)===undefined){
   const result=await options.scrape({...body,resultOnly:true});assertCurrent();
   if(result.status==='success'&&!result.staleCache){if(result.targetDate!==priorDate||(result.actual&&result.actual.date!==priorDate))throw new Error('Prior result returned a different date');actual=checkedHistoryActual(result.actual,priorDate);}
  }
  const digit=actualForGame(actual||undefined,'ank',market);if(digit===undefined)return;
  seed[priorDate]={data:{[index]:evaluateBacktest(rec,'ank',digit)}};
 };
 if(options.completeWindow){
  // Bound date requests, not markets. Each worker retains independent date/source
  // validation; the server's existing run-scoped raw-chart snapshot is shared.
  let nextOffset=1,failed=false,failure:unknown;
  await Promise.all(Array.from({length:4},async()=>{
   while(!failed&&nextOffset<=HISTORY_WINDOW_DAYS){
    const offset=nextOffset++;
    try{await fetchDate(offset);}catch(error){if(!failed){failed=true;failure=error;}}
   }
  }));
  // Drain already-started requests before rejecting; never return a partial seed.
  if(failed)throw failure;
 }else{
  for(let offset=1;offset<=HISTORY_WINDOW_DAYS;offset++){
   assertCurrent();
   if(sourceHistoryIndices(days,date,index,market,mode,count,seed).length===count)return seed;
   await fetchDate(offset);
  }
 }
 assertCurrent();
 if(!options.completeWindow&&sourceHistoryIndices(days,date,index,market,mode,count,seed).length!==count)throw new Error(`Not enough ${marketHistorySourceLabel(mode)} source indices in prior 30 days`);
 return Object.fromEntries(Object.entries(seed).sort(([a],[b])=>b.localeCompare(a)));
}
