import {parseDatedActuals, type DatedActual} from './backtestResult';

/** Cache parsing only for an exact HTML snapshot, within its existing batch.
 * Lazy so ordinary live source-only requests do not pay for unused dated rows.
 * Consumers must treat the returned rows as immutable.
 */
export function chartRowsReader(html:string, cache?:Map<string,DatedActual[]>, parse= parseDatedActuals):()=>DatedActual[] {
 let rows:DatedActual[]|undefined;
 return ()=>{
  if(rows)return rows;
  rows=cache?.get(html);
  if(!rows){rows=parse(html);cache?.set(html,rows);}
  return rows;
 };
}
