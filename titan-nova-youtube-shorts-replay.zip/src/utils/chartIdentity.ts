/** Accept only a chart page whose heading explicitly identifies the requested market.
 * PlayMatka has "MARKET Panel Chart Today" and "MARKET Panel Result Chart Records"
 * headings. Never match substrings: KALYAN and KALYAN NIGHT, SRIDEVI and SRIDEVI NIGHT,
 * MADHUR DAY and MADHUR NIGHT are different chart histories.
 */
export function chartMatchesMarket(html: string, marketName: string): boolean {
  const base = String(marketName || '').trim().toUpperCase().replace(/\s+(OPEN|CLOSE)$/i, '')
    .replace(/[^A-Z0-9]+/g, ' ').trim();
  if (!base) return false;
  for (const headingTag of html.matchAll(/<h[1-6]\b[^>]*>([\s\S]*?)<\/h[1-6]\s*>/gi)) {
    const heading = headingTag[1].replace(/<[^>]+>/g, ' ').replace(/&nbsp;|&#160;/gi, ' ')
      .toUpperCase().replace(/[^A-Z0-9]+/g, ' ').trim();
    if (heading === base) return true;
    // First-party chart headings; unlike arbitrary substring matching, this
    // captures the *whole* identity before a known exact title suffix.
    const chartTitle = heading.match(/^(.+?)\s+P(?:A|E)N(?:E|A)L(?:\s+RESULT)?\s+CHART(?:\s+(?:TODAY|RECORDS))?$/);
    if (chartTitle?.[1] === base) return true;
  }
  return false;
}
