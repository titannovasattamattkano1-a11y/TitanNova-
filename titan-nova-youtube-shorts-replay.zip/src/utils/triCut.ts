import type { DayMarketRecord, UserProfile } from '../types';
import { isMirrorProtected } from './adminMirror';
import { getScrapeSource } from './scrapeProvenance';
import { modelSourceVersion } from './marketModelCard';
import { canReplaceLiveCombinedDecision, releaseLiveCombinedDecision } from './liveCombinedDecision';
import { getPrecedingMarketActual } from './sniperOne';

export interface TriCutDetails {
  actual?: string;
  mirror?: string;
  padosi: string[];
  centerCut: string[];
  input: string;
  output: string;
  outputVersion: number;
}

/**
 * 3-in-1 Combo Filter Formula:
 * 1. Last Actual Mirror Cut: (A + 5) % 10
 * 2. Delta Neighbor Cut: (A - 1 + 10) % 10 and (A + 1) % 10
 * 3. Center Cut: Middle 2 digits of the card's scraped digits
 *
 * Preserves the card's unique scraped source order instead of collapsing into static global sorted numbers!
 */
export function applyTriCutFormula(rawInput: string, lastActual?: string): { formatted: string; details: Omit<TriCutDetails, 'outputVersion'> } | null {
  const digits = rawInput.match(/\d/g);
  if (!digits || digits.length < 2) return null;

  // Preserve unique digits in their original scraped order
  const ordered: string[] = [];
  const seen = new Set<string>();
  for (const d of digits) {
    if (!seen.has(d)) {
      seen.add(d);
      ordered.push(d);
    }
  }

  if (ordered.length < 2) return null;

  let mirror: string | undefined;
  const padosi: string[] = [];
  const cuts = new Set<string>();

  // 1. Mirror + Delta Neighbor Cuts of this market's preceding actual
  if (lastActual !== undefined && /^\d$/.test(String(lastActual).trim())) {
    const act = Number(lastActual);
    mirror = String((act + 5) % 10);
    const left = String((act - 1 + 10) % 10);
    const right = String((act + 1) % 10);
    padosi.push(left, right);
    cuts.add(mirror);
    cuts.add(left);
    cuts.add(right);
  }

  // 2. Center Cut (Middle 2 Digits Cut of this card's scraped digits)
  const centerCut: string[] = [];
  if (ordered.length >= 4) {
    const len = ordered.length;
    const mid1 = Math.floor(len / 2) - 1;
    const mid2 = Math.floor(len / 2);
    if (ordered[mid1] !== undefined) {
      centerCut.push(ordered[mid1]);
      cuts.add(ordered[mid1]);
    }
    if (ordered[mid2] !== undefined && ordered[mid2] !== ordered[mid1]) {
      centerCut.push(ordered[mid2]);
      cuts.add(ordered[mid2]);
    }
  }

  // 3. Filter while preserving original scraped source order
  let remaining = ordered.filter(d => !cuts.has(d));

  // Safety fallback if too many digits were cut
  if (remaining.length < 2) {
    remaining = ordered.slice(0, 5);
  }

  const output = remaining.join(', ');
  if (!output) return null;

  return {
    formatted: output,
    details: {
      actual: lastActual,
      mirror,
      padosi,
      centerCut,
      input: rawInput,
      output,
    },
  };
}

/**
 * Apply Tri-Cut filter to an individual DayMarketRecord using its scraping source and market-specific actual.
 */
export function applyTriCut(
  record: DayMarketRecord | undefined,
  profile: UserProfile,
  date: string,
  index: number,
  marketName?: string,
): DayMarketRecord | undefined {
  if (!record || record.s !== 'WAIT' || record.manualStatus || record.deliveryRestoredAt || record.dispatchState || isMirrorProtected(record) || !canReplaceLiveCombinedDecision(record)) {
    return undefined;
  }

  // Base must have scraped digits
  const source = getScrapeSource(record);
  const raw = String(record.od || source?.digits || record.d || '').trim();
  const digits = raw.match(/\d/g);
  if (!digits || digits.length < 2) return undefined;

  const mName = marketName || record.marketName || '';
  const lastActual = getPrecedingMarketActual(profile, date, index, mName, record);

  const result = applyTriCutFormula(raw, lastActual);
  if (!result) return undefined;

  const version = Math.max(Date.now(), modelSourceVersion(record) + 1);
  const next: DayMarketRecord = {
    ...record,
    d: result.formatted,
    od: record.od || source?.digits || raw,
    positionRule: 'TRI_CUT',
    triCut: {
      ...result.details,
      outputVersion: version,
    },
    sourceEditedAt: version,
  };

  releaseLiveCombinedDecision(next);
  delete next.trick;
  delete next.sniperOne;
  delete next.tesla369;
  delete next.firstDigitMirrorCut;
  delete next.weekdaySelectedDigits;
  delete next.weekdayHitPosition;
  delete next.scrapeResultDigit;
  delete next.manualResult;
  delete next.manualResultSources;
  delete next.backtestResult;
  delete next.marketModel;
  delete next.autoRemovedResult;
  delete next.autoResultParity;
  delete next.smartSelection;

  if (!next.manualRate) {
    delete next.recRate;
    delete next.prevLoss;
    delete next.targetProfitWithLoss;
    delete next.rateFinalizedFrom;
    delete next.rateFinalizedAt;
  }

  return next;
}
