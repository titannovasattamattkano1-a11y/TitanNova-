import type { ProfileConfig } from '../types';
import { getDefaultConfig, getEffectiveMarkets } from '../data/markets';

/** Copy the complete admin setup once, then apply new-VIP delivery rules. */
export function createNewVipConfig(adminConfig?: ProfileConfig): ProfileConfig {
  const defaults = getDefaultConfig();
  // Config is persisted as JSON. Deep-copy it so nested loop wallets, market
  // settings and future config fields cannot share mutable state with admin.
  const inherited: ProfileConfig = JSON.parse(JSON.stringify({
    ...defaults,
    ...adminConfig,
    ank: { ...defaults.ank, ...adminConfig?.ank },
    jodi: { ...defaults.jodi, ...adminConfig?.jodi },
    pannel: { ...defaults.pannel, ...adminConfig?.pannel },
  }));
  return {
    ...inherited,
    // New VIP split controls start OFF under the existing creation rules.
    ankSplit: adminConfig?.ankSplit !== false,
    panSplit: adminConfig?.panSplit !== false,
    // VIP delivery uses its own destination and is event-driven.
    marketScheduleTimes: {},
    marketScheduleTargets: {},
    marketEnabled: Object.fromEntries(
      getEffectiveMarkets(inherited).map(market => [market.n.toUpperCase(), true]),
    ),
    scheduleTypeEnabled: { ank: false, jodi: false, pannel: false },
  };
}
