import {isMarketEnabledForDate} from './profileMarketToggle';
import type {DayMarketRecord,UserProfile} from '../types';
import {confirmedAnkResult} from './autoRemoveResult';
import {type ProfileLoopContext} from './dualLoops';
import {getEffectiveMarkets} from '../data/markets';
import {modelSourceVersion} from './marketModelCard';
import {evaluateBacktest} from './backtestResult';

export type CarryActual = {actual:string;key:string};
export const ALL_DIGITS = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
export const mirrorDigit = (d: string) => String((Number(d) + 5) % 10);
export const digitFamily = (d: string) => (parseInt(d, 10) % 5 + 5) % 5;

const dateValid=(d:string)=>/^\d{4}-\d{2}-\d{2}$/.test(d)&&Number.isFinite(Date.parse(d))&&new Date(d).toISOString().slice(0,10)===d;

/** 
 * Build full 0-9 recency spectrum from history:
 * Running seen digits in exact arrival order, followed by cold unplayed digits.
 */
export function carryResultTenSpectrum(history: CarryActual[]): string[] {
  const seen: string[] = [];
  for (const item of history) {
    const d = item.actual;
    if (/^\d$/.test(d) && !seen.includes(d)) {
      seen.push(d);
      if (seen.length === 10) break;
    }
  }
  for (const d of ALL_DIGITS) {
    if (!seen.includes(d)) {
      seen.push(d);
    }
  }
  return seen;
}

export interface PrecedingLoopCard {
  actual: string;
  status: 'PASS' | 'FAIL';
  predicted: string[];
  marketName: string;
  date: string;
  index: number;
}

export interface LoopFailStreak {
  streakCount: number;
  failedCards: PrecedingLoopCard[];
  lastSettledCard: PrecedingLoopCard | null;
}

/** 
 * Trace back consecutive failures in the same recovery track across all preceding dates.
 */
export function findLoopFailStreak(
  profile: UserProfile,
  date: string,
  index: number,
  name?: string,
  record?: DayMarketRecord,
  _loopContexts = new Map<string, ProfileLoopContext>(),
): LoopFailStreak {
  if (!dateValid(date) || !Number.isInteger(index) || index < 0) {
    return { streakCount: 0, failedCards: [], lastSettledCard: null };
  }
  const markets = getEffectiveMarkets(profile.config);

  let lastSettledCard: PrecedingLoopCard | null = null;
  const failedCards: PrecedingLoopCard[] = [];

  for (const d of Object.keys(profile.dayRecords || {}).filter(d => dateValid(d) && d <= date).sort().reverse()) {
    for (const [i, rec] of Object.entries(profile.dayRecords[d]?.data || {}).sort((a, b) => Number(b[0]) - Number(a[0]))) {
      if (!Number.isInteger(Number(i)) || Number(i) < 0 || (d === date && Number(i) >= index)) continue;
      const market = rec.marketName || markets[Number(i)]?.n;
      if (!market) continue;

      let actual = confirmedAnkResult(rec);
      if (!actual && (rec.s === 'PASS' || rec.s === 'FAIL')) {
        const cand = rec.manualStatus ? rec.manualResult : rec.scrapeResultDigit || (rec.backtestResult?.checked && rec.backtestResult.digits === rec.d ? rec.backtestResult.actual : undefined);
        if (/^\d$/.test(String(cand || ''))) {
          actual = String(cand);
        }
      }

      if (actual !== undefined && /^\d$/.test(actual)) {
        const status = ((rec.backtestResult as any)?.status || rec.s) as 'PASS' | 'FAIL';
        if (status === 'PASS' || status === 'FAIL') {
          const predicted = String(rec.d || '').split(/[,|\s]+/).filter(x => /^\d$/.test(x));
          const card: PrecedingLoopCard = { actual, status, predicted, marketName: market, date: d, index: Number(i) };
          if (!lastSettledCard) {
            lastSettledCard = card;
          }
          if (status === 'FAIL') {
            failedCards.push(card);
          } else {
            return { streakCount: failedCards.length, failedCards, lastSettledCard };
          }
        }
      }
    }
  }
  return { streakCount: failedCards.length, failedCards, lastSettledCard };
}

/** 
 * Find the most recent settled card (PASS or FAIL) in this recovery track.
 */
export function findPrecedingLoopCard(
  profile: UserProfile,
  date: string,
  index: number,
  name: string,
  record?: DayMarketRecord,
  loopContexts = new Map<string, ProfileLoopContext>(),
): PrecedingLoopCard | null {
  const streak = findLoopFailStreak(profile, date, index, name, record, loopContexts);
  return streak.lastSettledCard;
}

export interface HistoricalCardTransitionSummary {
  matchedTransitions: number;
  nextDigitFrequency: Record<string, number>;
  mirrorCutHitCount: number;
  repeatHitCount: number;
  deltaNeighborCount: number;
}

/**
 * Collect all historical settled cards in this recovery track in chronological order.
 */
const trackSettledCache = new WeakMap<object, { date: string; dayDataRef: unknown; cards: PrecedingLoopCard[] }>();

export function collectTrackSettledCards(
  profile: UserProfile,
  date: string,
  index: number,
  name?: string,
  record?: DayMarketRecord,
  _loopContexts = new Map<string, ProfileLoopContext>(),
): PrecedingLoopCard[] {
  if (!dateValid(date) || !Number.isInteger(index) || index < 0) return [];
  const dayRecordsRef = profile.dayRecords;
  const dayDataRef = dayRecordsRef?.[date]?.data;
  if (dayRecordsRef && typeof dayRecordsRef === "object") {
    const cached = trackSettledCache.get(dayRecordsRef);
    if (cached && cached.date === date && cached.dayDataRef === dayDataRef) {
      return cached.cards.filter(c => c.date < date || (c.date === date && c.index < index));
    }
  }
  const markets = getEffectiveMarkets(profile.config);
  const allCards: PrecedingLoopCard[] = [];

  const dates = Object.keys(profile.dayRecords || {}).filter(d => dateValid(d) && d <= date).sort();
  for (const d of dates) {
    const entries = Object.entries(profile.dayRecords[d]?.data || {}).sort((a, b) => Number(a[0]) - Number(b[0]));
    for (const [i, rec] of entries) {
      if (!Number.isInteger(Number(i)) || Number(i) < 0) continue;
      const market = rec.marketName || markets[Number(i)]?.n;
      if (!market) continue;

      let actual = confirmedAnkResult(rec);
      if (!actual && (rec.s === 'PASS' || rec.s === 'FAIL')) {
        const cand = rec.manualStatus ? rec.manualResult : rec.scrapeResultDigit || (rec.backtestResult?.checked && rec.backtestResult.digits === rec.d ? rec.backtestResult.actual : undefined);
        if (/^\d$/.test(String(cand || ''))) {
          actual = String(cand);
        }
      }

      if (actual !== undefined && /^\d$/.test(actual)) {
        const status = ((rec.backtestResult as any)?.status || rec.s) as 'PASS' | 'FAIL';
        if (status === 'PASS' || status === 'FAIL') {
          const predicted = String(rec.d || '').split(/[,|\s]+/).filter(x => /^\d$/.test(x));
          allCards.push({ actual, status, predicted, marketName: market, date: d, index: Number(i) });
        }
      }
    }
  }
  if (dayRecordsRef && typeof dayRecordsRef === "object") {
    trackSettledCache.set(dayRecordsRef, { date, dayDataRef, cards: allCards });
  }
  return allCards.filter(c => c.date < date || (c.date === date && c.index < index));
}

/**
 * Deep scan across all historical card transitions (Card[k] -> Card[k+1])
 * where Card[k].status matches baseCard.status to derive empirical transition conditional statistics.
 */
export function analyzeHistoricalCardTransitions(
  profile: UserProfile,
  date: string,
  index: number,
  name: string,
  record?: DayMarketRecord,
  baseCard?: PrecedingLoopCard | null,
  loopContexts = new Map<string, ProfileLoopContext>(),
): HistoricalCardTransitionSummary {
  if (!baseCard) {
    return {
      matchedTransitions: 0,
      nextDigitFrequency: {},
      mirrorCutHitCount: 0,
      repeatHitCount: 0,
      deltaNeighborCount: 0,
    };
  }

  const cards = collectTrackSettledCards(profile, date, index, name, record, loopContexts);
  const nextDigitFrequency: Record<string, number> = {};
  let matchedTransitions = 0;
  let mirrorCutHitCount = 0;
  let repeatHitCount = 0;
  let deltaNeighborCount = 0;

  for (let k = 0; k < cards.length - 1; k++) {
    const cardA = cards[k];
    const cardB = cards[k + 1];
    if (cardA.status === baseCard.status) {
      matchedTransitions++;
      const nextActual = cardB.actual;
      nextDigitFrequency[nextActual] = (nextDigitFrequency[nextActual] || 0) + 1;
      if (nextActual === cardA.actual) repeatHitCount++;
      if (nextActual === mirrorDigit(cardA.actual)) mirrorCutHitCount++;
      const diff = Math.abs(Number(nextActual) - Number(cardA.actual));
      if (diff === 1 || diff === 9) deltaNeighborCount++;
    }
  }

  return {
    matchedTransitions,
    nextDigitFrequency,
    mirrorCutHitCount,
    repeatHitCount,
    deltaNeighborCount,
  };
}

export type FailDiagnosisKind = 'CUT_TRAP' | 'COLD_SHIFT' | 'DELTA_JUMP' | 'RECOVERY_HEDGE' | 'TREND_FLOW' | 'TRAP_INVERSION' | 'FAMILY_SATURATION_LOCK';

export interface FailDiagnosisResult {
  kind: FailDiagnosisKind;
  details: string;
  targetDigits: string[];
}

/**
 * 5-Digit Index Adaptive & Elimination Engine (50%/50% Mathematical Probability).
 * Evaluates market-wise & loop-wise index transitions (R1 to R10), eliminates the bottom 5
 * digits, and keeps the top 5 highest-probability digits.
 */
export interface CarryTenWindowAnalysis {
  spectrum: string[];
  totalDraws: number;
  digitFrequencies: Record<string, number>;
  marketFrequencies: Record<string, Record<string, number>>;
  sameMarketCounts: Record<string, number>;
  recencyOrder: string[];
  trendMode: 'MOMENTUM_REPEAT' | 'RECENCY_FLOW' | 'REVERSAL_BREAK';
  trendDetails: string;
}

/**
 * Deep scan across the exact window required to reach 10 unique actuals:
 * Records how many times each digit occurred, which market generated it,
 * and detects the running Trend Director mode (MOMENTUM_REPEAT vs RECENCY_FLOW vs REVERSAL_BREAK).
 */
export function collectCarryTenWindowAnalysis(
  profile: UserProfile,
  date: string,
  index: number,
  name: string,
  record?: DayMarketRecord,
  loopContexts = new Map<string, ProfileLoopContext>(),
): CarryTenWindowAnalysis | undefined {
  if (!dateValid(date) || !Number.isInteger(index) || index < 0) return undefined;
  const markets = getEffectiveMarkets(profile.config);

  const digitFrequencies: Record<string, number> = {};
  const marketFrequencies: Record<string, Record<string, number>> = {};
  const sameMarketCounts: Record<string, number> = {};
  const seenUnique = new Set<string>();
  const recencyOrder: string[] = [];
  let totalDraws = 0;

  for (const d of Object.keys(profile.dayRecords || {}).filter(d => dateValid(d) && d <= date).sort().reverse()) {
    for (const [i, rec] of Object.entries(profile.dayRecords[d]?.data || {}).sort((a, b) => Number(b[0]) - Number(a[0]))) {
      if (!Number.isInteger(Number(i)) || Number(i) < 0 || (d === date && Number(i) >= index)) continue;
      const market = rec.marketName || markets[Number(i)]?.n;
      if (!market) continue;

      const actual = confirmedAnkResult(rec);
      if (actual === undefined || !/^\d$/.test(actual)) continue;

      totalDraws++;
      digitFrequencies[actual] = (digitFrequencies[actual] || 0) + 1;
      if (!marketFrequencies[market]) marketFrequencies[market] = {};
      marketFrequencies[market][actual] = (marketFrequencies[market][actual] || 0) + 1;
      if (market.trim().toUpperCase() === name.trim().toUpperCase()) {
        sameMarketCounts[actual] = (sameMarketCounts[actual] || 0) + 1;
      }
      if (!seenUnique.has(actual)) {
        seenUnique.add(actual);
        recencyOrder.push(actual);
      }
      if (seenUnique.size === 10) break;
    }
    if (seenUnique.size === 10) break;
  }

  if (seenUnique.size < 10) return undefined;

  const spectrum = [...recencyOrder];
  for (const d of ALL_DIGITS) {
    if (!spectrum.includes(d)) spectrum.push(d);
  }

  const streak = findLoopFailStreak(profile, date, index, name, record, loopContexts);
  const preceding = streak.lastSettledCard;
  let trendMode: 'MOMENTUM_REPEAT' | 'RECENCY_FLOW' | 'REVERSAL_BREAK' = 'MOMENTUM_REPEAT';
  let trendDetails = '';

  const rankedByFreq = [...spectrum].sort((a, b) => (digitFrequencies[b] || 0) - (digitFrequencies[a] || 0));
  const topRepeats = rankedByFreq.slice(0, 3);

  if (streak.streakCount >= 1 || preceding?.status === 'FAIL') {
    trendMode = 'REVERSAL_BREAK';
    trendDetails = `REVERSAL BREAK (${streak.streakCount} fail streak); hedged cold/mirror inversion`;
  } else if (preceding && preceding.actual && topRepeats.includes(preceding.actual)) {
    trendMode = 'MOMENTUM_REPEAT';
    trendDetails = `MOMENTUM REPEAT (last actual ${preceding.actual} was top frequency; hot repeat running)`;
  } else {
    trendMode = 'RECENCY_FLOW';
    trendDetails = `RECENCY FLOW (following active flow & delta transitions)`;
  }

  return {
    spectrum,
    totalDraws,
    digitFrequencies,
    marketFrequencies,
    sameMarketCounts,
    recencyOrder,
    trendMode,
    trendDetails,
  };
}


export function synthesizeFiveDigits(
  spectrum: string[],
  preceding: PrecedingLoopCard | null,
  streakCount: number = 0,
  failedCards: PrecedingLoopCard[] = [],
  transitions?: HistoricalCardTransitionSummary,
  windowAnalysis?: CarryTenWindowAnalysis,
): { targetDigits: string[]; trendMode: string; details: string } {
  const r1 = spectrum[0];
  const r1Cut = mirrorDigit(r1);
  const r1CutIdx = spectrum.indexOf(r1Cut) + 1 || 7;
  const prevHitDigit = preceding?.actual;

  const scores = new Map<string, number>();
  const maxFreq = windowAnalysis ? Math.max(1, ...Object.values(windowAnalysis.digitFrequencies)) : 1;
  const maxSameMarket = windowAnalysis ? Math.max(1, ...Object.values(windowAnalysis.sameMarketCounts), 1) : 1;
  const trendMode = windowAnalysis?.trendMode || (streakCount >= 1 ? 'REVERSAL_BREAK' : 'RECENCY_FLOW');

  for (let i = 0; i < spectrum.length; i++) {
    const d = spectrum[i];
    const rank = i + 1; // 1 to 10
    let score = (11 - rank) * 1.2;

    // 1. WINDOW OCCURRENCE FREQUENCY WEIGHT (The core user request):
    // "10 unique digit banne tak konsa market me kitne baar kya result tha ussi base par teyar karna"
    if (windowAnalysis) {
      const freq = windowAnalysis.digitFrequencies[d] || 0;
      score += (freq / maxFreq) * 5.5; // Up to +5.5 points for highest repeat digits

      const marketHits = windowAnalysis.sameMarketCounts[d] || 0;
      if (marketHits > 0) {
        score += (marketHits / maxSameMarket) * 3.0; // Up to +3.0 points for same-market repeat
      }
    }

    // 2. TREND DIRECTOR MODULATION:
    if (trendMode === 'MOMENTUM_REPEAT') {
      if (windowAnalysis && (windowAnalysis.digitFrequencies[d] || 0) >= 2) {
        score += 4.5;
      }
      if (rank <= 3) score += 3.0;
    } else if (trendMode === 'RECENCY_FLOW') {
      if (rank === 1) score += 4.0;
      if (rank === 2 || rank === 3) score += 2.5;
      if (prevHitDigit) {
        const diff = Math.abs(Number(d) - Number(prevHitDigit));
        if (diff === 1 || diff === 9) score += 3.0;
      }
    } else if (trendMode === 'REVERSAL_BREAK') {
      if (rank === r1CutIdx) score += 6.0;
      if (prevHitDigit && d === mirrorDigit(prevHitDigit)) score += 5.5;
      const originCard = failedCards.length > 0 ? failedCards[failedCards.length - 1] : preceding;
      const originCut = originCard?.actual ? mirrorDigit(originCard.actual) : undefined;
      if (originCut && d === originCut) score += 4.5;
      if (streakCount >= 2 && rank >= 6 && rank <= 8) {
        score += 4.0;
      }
    }

    // 3. Empirical transition statistics
    if (transitions && transitions.matchedTransitions > 0) {
      const total = transitions.matchedTransitions;
      const digitHitCount = transitions.nextDigitFrequency[d] || 0;
      if (digitHitCount > 0) {
        score += (digitHitCount / total) * 7.0;
      }
      if (prevHitDigit && d === mirrorDigit(prevHitDigit) && transitions.mirrorCutHitCount > 0) {
        score += (transitions.mirrorCutHitCount / total) * 6.0;
      }
      if (prevHitDigit && d === prevHitDigit && transitions.repeatHitCount > 0) {
        score += (transitions.repeatHitCount / total) * 5.0;
      }
      if (prevHitDigit && transitions.deltaNeighborCount > 0) {
        const diff = Math.abs(Number(d) - Number(prevHitDigit));
        if (diff === 1 || diff === 9) {
          score += (transitions.deltaNeighborCount / total) * 4.0;
        }
      }
    }

    scores.set(d, score);
  }

  // Sort digits descending by score: ELIMINATE BOTTOM 5, KEEP TOP 5!
  const sorted = [...spectrum].sort((a, b) => (scores.get(b) || 0) - (scores.get(a) || 0));
  const targetDigits = sorted.slice(0, 5);
  const details = windowAnalysis
    ? `Carry 5 Trend Director · ${trendMode} (${windowAnalysis.totalDraws} draws window, top: ${targetDigits.slice(0, 3).join(',')})`
    : `Carry 5 Trend Director · ${trendMode} (streak ${streakCount})`;

  return { targetDigits, trendMode, details };
}

/**
 * Deep Quantum Superposition & Dispersion Saturation Engine (6-digit legacy contract).
 */
export function diagnoseAndSynthesize(
  spectrum: string[],
  preceding: PrecedingLoopCard | null,
  streakCount: number = 0,
  failedCards: PrecedingLoopCard[] = [],
): FailDiagnosisResult {
  // If there is no preceding card, or preceding card was PASS, or had no full prediction:
  if (!preceding || preceding.status === 'PASS' || preceding.predicted.length < 4) {
    return {
      kind: 'TREND_FLOW',
      details: 'Active loop trend following 0-9 recency spectrum',
      targetDigits: spectrum.slice(0, 5),
    };
  }

  const failedActual = preceding.actual;
  const predicted = preceding.predicted;
  const actualRank = spectrum.indexOf(failedActual); // 0 = hottest, 9 = coldest

  if (predicted.includes(failedActual)) {
    return {
      kind: 'TREND_FLOW',
      details: `Preceding card contained actual ${failedActual}; maintained active trend flow`,
      targetDigits: spectrum.slice(0, 5),
    };
  }

  const originCard = failedCards.length > 0 ? failedCards[failedCards.length - 1] : preceding;
  const originActual = originCard.actual;
  const originFam = digitFamily(originActual);
  const latestFam = digitFamily(failedActual);

  // Compute family momentum scores across spectrum
  const scores = [0, 0, 0, 0, 0];
  for (let r = 0; r < spectrum.length; r++) {
    scores[digitFamily(spectrum[r])] += (10 - r);
  }
  const rankedFams = [0, 1, 2, 3, 4].sort((a, b) => scores[b] - scores[a]);
  const kingFam = rankedFams[0];

  // --- ROUND 4+ MASTER LOCK: FAMILY SATURATION & ANCHOR (streakCount >= 3) ---
  if (streakCount >= 3) {
    const recentFams = failedCards.slice(0, 3).map(fc => digitFamily(fc.actual));
    if (recentFams.length === 0) recentFams.push(latestFam);
    const uniqueFams = new Set(recentFams);
    const unhitFams = [0, 1, 2, 3, 4].filter(f => !uniqueFams.has(f));

    const famPicks = new Set<number>();
    famPicks.add(latestFam);
    famPicks.add(originFam);
    famPicks.add(kingFam);

    if (uniqueFams.size >= 3) {
      for (const u of unhitFams) {
        if (famPicks.size >= 3) break;
        famPicks.add(u);
      }
    }

    for (const f of rankedFams) {
      if (famPicks.size >= 3) break;
      famPicks.add(f);
    }

    const picks = new Set<string>();
    picks.add(failedActual);
    picks.add(mirrorDigit(failedActual));
    picks.add(originActual);
    picks.add(mirrorDigit(originActual));
    for (const d of spectrum) {
      if (picks.size >= 6) break;
      picks.add(d);
      picks.add(mirrorDigit(d));
    }
    for (const f of famPicks) {
      if (picks.size >= 6) break;
      picks.add(String(f));
      picks.add(mirrorDigit(String(f)));
    }
    for (const d of spectrum) {
      if (picks.size >= 6) break;
      picks.add(d);
    }
    return {
      kind: 'FAMILY_SATURATION_LOCK',
      details: `Round 4 Lock (${streakCount} fails): dispersion unhit families [${Array.from(famPicks).join(',')}]; exact 6 digits`,
      targetDigits: Array.from(picks).slice(0, 5),
    };
  }

  // --- ROUND 3: QUANTUM VELOCITY INTERCEPT WITH MODULAR DELTA (streakCount >= 2) ---
  if (streakCount >= 2) {
    const failedBoxes = failedCards.map(fc => fc.predicted).filter(p => p.length >= 4);
    const lastPredicted = failedBoxes[0] || predicted;
    const outOfBox = ALL_DIGITS.filter(d => !lastPredicted.includes(d)); // exactly 4 digits!

    const f0 = failedCards.length >= 2 ? digitFamily(failedCards[1].actual) : originFam;
    const f1 = latestFam;
    const v = (f1 - f0 + 5) % 5;
    const vFam = (f1 + (v !== 0 ? v : 3)) % 5;

    const picks = new Set<string>();
    for (const d of outOfBox) {
      picks.add(d);
    }
    picks.add(failedActual);
    picks.add(mirrorDigit(failedActual));
    picks.add(String(vFam));
    picks.add(mirrorDigit(String(vFam)));
    picks.add(originActual);
    picks.add(mirrorDigit(originActual));
    for (const fc of failedCards) {
      if (picks.size >= 6) break;
      picks.add(fc.actual);
      picks.add(mirrorDigit(fc.actual));
    }
    for (const d of spectrum.slice(6, 10)) {
      if (picks.size >= 6) break;
      picks.add(d);
    }
    for (const d of spectrum) {
      if (picks.size >= 6) break;
      picks.add(d);
    }

    return {
      kind: 'TRAP_INVERSION',
      details: `Trap detected (${streakCount} fails); velocity intercepted v=${v} to out-of-box digits [${outOfBox.join(',')}] + origin ${originActual}`,
      targetDigits: Array.from(picks).slice(0, 5),
    };
  }

  // --- ROUND 2: SINGLE FAIL DIAGNOSIS (streakCount === 1) ---
  const cutPartner = predicted.find(p => mirrorDigit(p) === failedActual);
  if (cutPartner) {
    const picks = new Set<string>();
    picks.add(failedActual);
    picks.add(mirrorDigit(failedActual));
    for (const d of spectrum) {
      if (picks.size >= 6) break;
      picks.add(d);
      picks.add(mirrorDigit(d));
    }
    for (const d of spectrum) {
      if (picks.size >= 6) break;
      picks.add(d);
    }
    return {
      kind: 'CUT_TRAP',
      details: `Failed on mirror cut of ${cutPartner} -> ${failedActual}; locked mirror bridge`,
      targetDigits: Array.from(picks).slice(0, 5),
    };
  }

  if (actualRank >= 6) {
    const picks = new Set<string>();
    picks.add(failedActual);
    picks.add(mirrorDigit(failedActual));
    for (const d of spectrum) {
      if (picks.size >= 6) break;
      picks.add(d);
      picks.add(mirrorDigit(d));
    }
    for (const d of spectrum) {
      if (picks.size >= 6) break;
      picks.add(d);
    }
    return {
      kind: 'COLD_SHIFT',
      details: `Failed on cold rank #${actualRank + 1} digit ${failedActual}; rebalanced cold cluster & cuts`,
      targetDigits: Array.from(picks).slice(0, 5),
    };
  }

  const failedNum = parseInt(failedActual, 10);
  const leftNeighbor = String((failedNum + 9) % 10);
  const rightNeighbor = String((failedNum + 1) % 10);

  const picks = new Set<string>();
  picks.add(failedActual);
  picks.add(mirrorDigit(failedActual));
  picks.add(leftNeighbor);
  picks.add(mirrorDigit(leftNeighbor));
  picks.add(rightNeighbor);
  picks.add(mirrorDigit(rightNeighbor));
  for (const d of spectrum) {
    if (picks.size >= 6) break;
    picks.add(d);
  }

  return {
    kind: 'DELTA_JUMP',
    details: `Failed on neighbor jump ${failedActual}; locked delta envelope [${leftNeighbor},${failedActual},${rightNeighbor}]`,
    targetDigits: Array.from(picks).slice(0, 5),
  };
}

export function carryResultSixHistory(
  profile: UserProfile,
  date: string,
  index: number,
  name?: string,
  record?: DayMarketRecord,
  limit: number = 6,
  _loopContexts = new Map<string, ProfileLoopContext>(),
): CarryActual[] {
  if (!dateValid(date) || !Number.isInteger(index) || index < 0) return [];
  const markets = getEffectiveMarkets(profile.config);
  const out: CarryActual[] = [];
  const seen = new Set<string>();

  for (const d of Object.keys(profile.dayRecords || {}).filter(d => dateValid(d) && d <= date).sort().reverse()) {
    for (const [i, rec] of Object.entries(profile.dayRecords[d]?.data || {}).sort((a, b) => Number(b[0]) - Number(a[0]))) {
      if (!Number.isInteger(Number(i)) || Number(i) < 0 || (d === date && Number(i) >= index)) continue;
      const market = rec.marketName || markets[Number(i)]?.n;
      if (!market) continue;

      const actual = confirmedAnkResult(rec);
      if (actual === undefined) continue;

      const evidence = [rec.manualResult, rec.scrapeResultDigit, rec.backtestResult?.checked ? rec.backtestResult.actual : undefined].filter(v => v !== undefined && v !== '');
      if (evidence.some(v => String(v) !== actual) || seen.has(actual)) continue;
      seen.add(actual);
      out.push({ actual, key: `${d}:ank_${i}` });
      if (out.length === limit) return out;
    }
  }
  return out;
}

const inputKeys = ['d', 'od', 'sourceMode', 'scrapeSource', 'trick', 'positionRule', 'marketModel', 'strictPanel30', 'autoRemovedResult', 'autoResultParity', 'firstDigitMirrorCut', 'triCut', 'sniperOne', 'liveCombinedCut'] as const;

/** Versioned independent opt-in overlay. Generates 5 digits (50% probability) for live use and 6 digits for legacy. */
export function applyCarryResultSix(
  rec: DayMarketRecord,
  history: CarryActual[],
  enabled: boolean,
  preceding: PrecedingLoopCard | null = null,
  streakCount: number = 0,
  failedCards: PrecedingLoopCard[] = [],
  transitions?: HistoricalCardTransitionSummary,
  windowAnalysis?: CarryTenWindowAnalysis,
): DayMarketRecord {
  if (rec.sentDigits || rec.sentRate || rec.dispatchState || rec.manualStatus || rec.deliveryRestoredAt || rec.s === 'SKIP' || ((rec.s === 'PASS' || rec.s === 'FAIL') && !rec.backtestResult)) return rec;
  const old = rec.carryResultSix;
  const active = Boolean(old && rec.d === old.output && modelSourceVersion(rec) === old.outputVersion);
  if (!enabled && !old) return rec;
  if (!enabled && !active) {
    const next = { ...rec };
    delete next.carryResultSix;
    return next;
  }
  const input: Partial<DayMarketRecord> = active ? old!.input : Object.fromEntries(inputKeys.filter(k => rec[k] !== undefined).map(k => [k, rec[k]]));

  const valid = history.length >= 5 && history.every(h => /^\d$/.test(h.actual));
  let output = '';
  let diagnosis: FailDiagnosisResult = { kind: 'TREND_FLOW', details: '', targetDigits: [] };
  let spectrumStr = '';

  if (enabled && valid) {
    const spectrum = carryResultTenSpectrum(history);
    spectrumStr = spectrum.join('');

    // ALWAYS 5 DIGITS MODE: Trend Director + 0-9 Spectrum
    const fiveResult = synthesizeFiveDigits(spectrum, preceding, streakCount, failedCards, transitions, windowAnalysis);
    const target5 = fiveResult.targetDigits.slice(0, 5);
    output = target5.join(', ');
    diagnosis = {
      kind: fiveResult.trendMode === 'REVERSAL_BREAK' ? 'CUT_TRAP' : 'TREND_FLOW',
      details: fiveResult.details,
      targetDigits: target5,
    };
  } else if (!enabled) {
    output = String(input.d || '');
  }

  if (enabled && active && output === rec.d && JSON.stringify(old!.history) === JSON.stringify(history) && old!.diagnosis === diagnosis.kind) return rec;
  const version = Math.max(Date.now(), modelSourceVersion(rec) + 1);
  let next: DayMarketRecord = { ...rec, d: output, sourceEditedAt: version };
  for (const k of inputKeys) if (k !== 'd') delete (next as any)[k];
  if (enabled) {
    next.sourceMode = 'RESULT_CARRY6';
    next.carryResultSix = {
      input,
      output,
      outputVersion: version,
      history,
      diagnosis: diagnosis.kind,
      diagnosisDetails: diagnosis.details,
      spectrum: spectrumStr,
    };
  } else {
    Object.assign(next, input, { d: output, sourceMode: input.sourceMode || 'MANUAL' });
    delete next.carryResultSix;
    if (next.autoRemovedResult) next.autoRemovedResult = { ...next.autoRemovedResult, outputVersion: version };
    if (next.autoResultParity) next.autoResultParity = { ...next.autoResultParity, outputVersion: version };
    if (next.firstDigitMirrorCut?.output === output) next.firstDigitMirrorCut = { ...next.firstDigitMirrorCut, outputVersion: version };
    if (next.triCut?.output === output) next.triCut = { ...next.triCut, outputVersion: version };
    if (next.sniperOne?.output === output) next.sniperOne = { ...next.sniperOne, outputVersion: version };
  }
  delete next.scrapeResultDigit;
  delete next.manualResult;
  if (!next.manualRate) {
    delete next.recRate;
    delete next.prevLoss;
    delete next.targetProfitWithLoss;
    delete next.rateFinalizedFrom;
    delete next.rateFinalizedAt;
  }
  if (rec.backtestResult) {
    const actual = rec.backtestResult;
    next.s = 'WAIT';
    delete next.backtestResult;
    if (actual.checked && actual.actual && output) next = evaluateBacktest(next, 'ank', actual.actual);
    else next.backtestResult = { ...actual, digits: output };
  }
  return next;
}

/** Seed current runtime actuals over persisted history without mutating either store. */
export function carryRuntimeProfile(
  saved: UserProfile,
  date: string,
  cards: Record<string, DayMarketRecord>,
  runtimeMarkets: Array<{ type: string; index: number; n: string }>,
): UserProfile {
  const data = { ...saved.dayRecords[date]?.data };
  for (const m of runtimeMarkets) {
    if (m.type === 'ank' && cards[`ank_${m.index}`]) {
      data[m.index] = { ...cards[`ank_${m.index}`], marketName: m.n };
    }
  }
  return { ...saved, dayRecords: { ...saved.dayRecords, [date]: { ...saved.dayRecords[date], data } } };
}

/** Apply the setting immediately even when today's records/runtime have not been materialized yet. */
export function applyCarryResultSixDay(profile: UserProfile, date: string, enabled: boolean): UserProfile {
  if (!dateValid(date) || (!enabled && !profile.dayRecords[date])) return profile;
  const day = profile.dayRecords[date] || {};
  const data = { ...day.data };
  const loopContexts = new Map<string, ProfileLoopContext>();
  for (const [index, market] of getEffectiveMarkets(profile.config).entries()) {
    if (!isMarketEnabledForDate(profile.config, day.visAnk, market.n, date)) continue;
    if (!data[index] && !enabled) continue;
    const rec = data[index] || { s: 'WAIT' as const, d: '', r: '', marketName: market.n };
    if (rec.marketName && rec.marketName.trim().toUpperCase() !== market.n.trim().toUpperCase()) continue;
    const history = enabled ? carryResultSixHistory(profile, date, index, market.n, rec, 10, loopContexts) : [];
    const streakInfo = enabled ? findLoopFailStreak(profile, date, index, market.n, rec, loopContexts) : { streakCount: 0, failedCards: [], lastSettledCard: null };
    const transitions = enabled && streakInfo.lastSettledCard ? analyzeHistoricalCardTransitions(profile, date, index, market.n, rec, streakInfo.lastSettledCard, loopContexts) : undefined;
    const cWin = enabled ? collectCarryTenWindowAnalysis(profile, date, index, market.n, rec, loopContexts) : undefined;
    data[index] = applyCarryResultSix(rec, history, enabled, streakInfo.lastSettledCard, streakInfo.streakCount, streakInfo.failedCards, transitions, cWin);
  }
  return { ...profile, dayRecords: { ...profile.dayRecords, [date]: { ...day, data } } };
}


/** Versioned independent opt-in Cut 5 overlay. Cuts the 5 latest unique confirmed actual results from 0-9 universe. */
export function applyCutFive(
  rec: DayMarketRecord,
  history: CarryActual[],
  enabled: boolean,
): DayMarketRecord {
  if (rec.sentDigits || rec.sentRate || rec.dispatchState || rec.manualStatus || rec.deliveryRestoredAt || rec.s === 'SKIP' || ((rec.s === 'PASS' || rec.s === 'FAIL') && !rec.backtestResult)) return rec;
  const old = rec.autoRemovedResult;
  const active = Boolean(old?.unique3 && old.actuals?.length === 5 && rec.d === old.output && modelSourceVersion(rec) === old.outputVersion);
  if (!enabled && !old) return rec;
  if (!enabled && !active) {
    const next = { ...rec };
    if (next.autoRemovedResult?.unique3) delete next.autoRemovedResult;
    if (next.sourceMode === 'RESULT_CUT5') delete next.sourceMode;
    return next;
  }
  const input: Partial<DayMarketRecord> = active ? (old as any).inputRecord || {} : Object.fromEntries(inputKeys.filter(k => rec[k] !== undefined).map(k => [k, rec[k]]));

  const uniqueDigits = [...new Set(history.map(h => h.actual).filter(d => /^\d$/.test(d)))].slice(0, 5);
  const valid = uniqueDigits.length === 5;
  let output = '';

  if (enabled && valid) {
    const cuts = new Set(uniqueDigits);
    // Cut 5 unique actual result digits from 0-9 universe: exactly 5 remaining digits!
    output = ALL_DIGITS.filter(d => !cuts.has(d)).join(', ');
  } else if (!enabled) {
    output = String(input.d || '');
  }

  if (enabled && active && output === rec.d && JSON.stringify(old!.actuals) === JSON.stringify(uniqueDigits)) return rec;
  const version = Math.max(Date.now(), modelSourceVersion(rec) + 1);
  let next: DayMarketRecord = { ...rec, d: output, sourceEditedAt: version };
  for (const k of inputKeys) if (k !== 'd') delete (next as any)[k];
  if (enabled) {
    next.sourceMode = 'RESULT_CUT5';
    next.autoRemovedResult = {
      input: '0, 1, 2, 3, 4, 5, 6, 7, 8, 9',
      output,
      actual: uniqueDigits[0] || '',
      actuals: uniqueDigits,
      unique3: true,
      sourceKey: history.map(h => h.key).join('|'),
      outputVersion: version,
      inputRecord: input,
    } as any;
  } else {
    Object.assign(next, input, { d: output, sourceMode: input.sourceMode || 'MANUAL' });
    delete next.autoRemovedResult;
  }
  delete next.scrapeResultDigit;
  delete next.manualResult;
  if (!next.manualRate) {
    delete next.recRate;
    delete next.prevLoss;
    delete next.targetProfitWithLoss;
    delete next.rateFinalizedFrom;
    delete next.rateFinalizedAt;
  }
  if (rec.backtestResult) {
    const actual = rec.backtestResult;
    next.s = 'WAIT';
    delete next.backtestResult;
    if (actual.checked && actual.actual && output) next = evaluateBacktest(next, 'ank', actual.actual);
    else next.backtestResult = { ...actual, digits: output };
  }
  return next;
}

/** Apply Cut 5 immediately across all markets for a date without needing any scraping source. */
export function applyCutFiveDay(profile: UserProfile, date: string, enabled: boolean): UserProfile {
  if (!dateValid(date) || (!enabled && !profile.dayRecords[date])) return profile;
  const day = profile.dayRecords[date] || {};
  const data = { ...day.data };
  const loopContexts = new Map<string, ProfileLoopContext>();
  for (const [index, market] of getEffectiveMarkets(profile.config).entries()) {
    if (!isMarketEnabledForDate(profile.config, day.visAnk, market.n, date)) continue;
    if (!data[index] && !enabled) continue;
    const rec = data[index] || { s: 'WAIT' as const, d: '', r: '', marketName: market.n };
    if (rec.marketName && rec.marketName.trim().toUpperCase() !== market.n.trim().toUpperCase()) continue;
    const history = enabled ? carryResultSixHistory(profile, date, index, market.n, rec, 5, loopContexts) : [];
    data[index] = applyCutFive(rec, history, enabled);
  }
  return { ...profile, dayRecords: { ...profile.dayRecords, [date]: { ...day, data } } };
}

export function carryResultSixStatus(profile: UserProfile, date: string) {
  let ready = 0;
  let pending = 0;
  let unchanged = 0;
  const day = profile.dayRecords[date] || {};
  for (const [i, m] of getEffectiveMarkets(profile.config).entries()) {
    if (!isMarketEnabledForDate(profile.config, day.visAnk, m.n, date)) continue;
    const r = day.data?.[i];
    if (!r || r.s !== 'WAIT' || r.manualStatus || r.sentDigits || r.sentRate || r.dispatchState || r.deliveryRestoredAt || !r.carryResultSix) {
      unchanged++;
      continue;
    }
    if (r.carryResultSix.history.length >= 5 && r.d === r.carryResultSix.output && r.d) ready++;
    else pending++;
  }
  return { ready, pending, unchanged };
}
