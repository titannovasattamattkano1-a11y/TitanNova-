/** Serialize related mutations so an older slow request cannot overwrite a newer click. */
export class SerialMutationQueue {
  private tails = new Map<string, Promise<void>>();

  /** Wait for previously submitted card commands before an all-card archive action. */
  async drain(): Promise<void> {
    // Capture the barrier once: newer background polling must not prolong an
    // Undo forever. Each captured tail already includes its earlier commands.
    await Promise.all([...this.tails.values()]);
  }

  enqueue<T>(key: string, task: () => Promise<T>): Promise<T> {
    const normalizedKey = String(key || 'global');
    const previous = this.tails.get(normalizedKey) || Promise.resolve();
    const run = previous.catch(() => undefined).then(task);
    const tail = run.then(() => undefined, () => undefined);
    this.tails.set(normalizedKey, tail);
    void tail.finally(() => {
      if (this.tails.get(normalizedKey) === tail) this.tails.delete(normalizedKey);
    });
    return run;
  }
}
