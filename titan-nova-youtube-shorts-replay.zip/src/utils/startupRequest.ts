/** Bound the complete startup operation, including response body download. */
export async function startupRequest<T>(operation: (signal: AbortSignal) => Promise<T>, timeoutMs = 20000): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await operation(controller.signal);
  } catch (error) {
    if (controller.signal.aborted) throw new Error('Server response slow hai. Connection / server check karke Retry karein.');
    throw error;
  } finally {
    clearTimeout(timer);
  }
}
