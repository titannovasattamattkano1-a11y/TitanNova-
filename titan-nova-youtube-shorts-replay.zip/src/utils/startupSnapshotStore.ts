let database:Promise<IDBDatabase|null>|undefined;
function openDatabase():Promise<IDBDatabase|null>{
 if(database)return database;
 database=new Promise(resolve=>{
  try{
   if(!globalThis.indexedDB){resolve(null);return;}
   const request=indexedDB.open('titan-startup-snapshots',1);let finished=false;
   const finish=(value:IDBDatabase|null)=>{if(finished){value?.close();return;}finished=true;clearTimeout(timer);resolve(value);};
   const timer=setTimeout(()=>finish(null),1500);
   request.onupgradeneeded=()=>{if(!request.result.objectStoreNames.contains('states'))request.result.createObjectStore('states');};
   request.onsuccess=()=>{request.result.onversionchange=()=>{request.result.close();database=undefined;};finish(request.result);};request.onerror=()=>finish(null);request.onblocked=()=>finish(null);
  }catch{resolve(null);}
 });return database;
}
/** Optional startup cache only. Server hash authorization remains mandatory. */
export async function readStartupSnapshotJson(key:string):Promise<string|null>{
 try{const db=await openDatabase();if(db){const value=await new Promise<unknown>(resolve=>{const tx=db.transaction('states','readonly'),request=tx.objectStore('states').get(key);const timer=setTimeout(()=>{try{tx.abort();}catch{}resolve(null);},1500);request.onsuccess=()=>{clearTimeout(timer);resolve(request.result);};request.onerror=()=>{clearTimeout(timer);resolve(null);};tx.onabort=()=>{clearTimeout(timer);resolve(null);};});if(typeof value==='string')return value;}}catch{}
 try{return localStorage.getItem(key);}catch{return null;}
}
export async function writeStartupSnapshotJson(key:string,json:string):Promise<void>{
 try{const db=await openDatabase();if(db){await new Promise<void>((resolve,reject)=>{const tx=db.transaction('states','readwrite');const timer=setTimeout(()=>{try{tx.abort();}catch{}reject(new Error('Startup cache timed out'));},3000);tx.objectStore('states').put(json,key);tx.oncomplete=()=>{clearTimeout(timer);resolve();};tx.onerror=()=>{clearTimeout(timer);reject(tx.error);};tx.onabort=()=>{clearTimeout(timer);reject(tx.error);};});return;}}catch{}
 // Old/restricted browsers keep their existing small-cache fallback; never block on huge sync writes.
 if(json.length<=128*1024)try{localStorage.setItem(key,json);}catch{}
}
