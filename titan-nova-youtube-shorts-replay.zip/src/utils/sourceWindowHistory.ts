import type {CardSourceMode,DayMarketRecord} from '../types';
import {getFullScrapeSource} from './scrapeProvenance';
import {actualForGame,type DatedActual} from './backtestResult';
import {sourceObservationWindow,isFrequencySourceMode,type FrequencySourceMode} from './sourceFrequencySmart';
import type {RollingHistoryChoice} from './marketHistoryLogic';
export const SOURCE_HISTORY_POLICY='source-window-weighted-321-v1';
export interface SourceHistoryAnalysis extends RollingHistoryChoice {
 policy:typeof SOURCE_HISTORY_POLICY; targetDate:string; market:string; sourceMode:FrequencySourceMode;
 sourceDigits:string; indices:number[]; observations:number;
}
const normalized=(s:string)=>s.trim().replace(/\s+/g,' ').toUpperCase();
const tokens=(s:string)=>s.split(/[,|\s]+/).filter(Boolean);
export function canApplySourceWindowHistory(record:DayMarketRecord|undefined,name:string){
 const source=getFullScrapeSource(record);
 return Boolean(source&&isFrequencySourceMode(source.mode)&&/\s+(OPEN|CLOSE)$/.test(normalized(name))&&record&&record.s==='WAIT'&&!record.manualStatus&&!record.sentDigits&&!record.sentRate&&!record.dispatchState&&!record.deliveryRestoredAt&&!record.vipAutoStopSkipped&&(!record.marketName||normalized(record.marketName)===normalized(name)));
}
/** Fresh chart only. Trial source is rebuilt as of each trial date, never from today's reference. */
export async function analyseSourceWindowHistory(draws:DatedActual[],date:string,market:string,mode:FrequencySourceMode,expected:string,pause:()=>Promise<void>=async()=>{}) : Promise<SourceHistoryAnalysis> {
 const side=/CLOSE$/.test(normalized(market))?'close':'open';
 let startDate=date;
 const values=sourceObservationWindow(draws,date,side,mode,undefined,d=>{if(d<startDate)startDate=d;});
 const source=[...new Set(values)],sourceDigits=source.join(', ');
 if(source.length!==10)throw Error('History Apply: complete original 10-digit source required; card unchanged');
 if(tokens(expected).join(', ')!==sourceDigits)throw Error('History Apply: saved source differs from fresh chart; scrape the selected source again');
 const endDate=new Date(Date.parse(date+'T00:00:00Z')-86400000).toISOString().slice(0,10);
 // Reject ambiguous dates rather than letting input order choose an outcome.
 const rows=new Map<string,DatedActual>(),conflicts=new Set<string>();
 for(const row of draws){
  if(row.date<startDate||row.date>=date)continue;
  const prior=rows.get(row.date);
  if(prior&&['open','jodi','close'].some(k=>prior[k as keyof DatedActual]!==row[k as keyof DatedActual]))conflicts.add(row.date);
  rows.set(row.date,row);
 }
 let keepHits=0,removeHits=0,keepWeight=0,removeWeight=0,samples=0,processed=0;
 let indices:number[]=[];
 for(const [day,row] of [...rows].sort(([a],[b])=>a.localeCompare(b))){
  if(++processed%8===0)await pause(); // Let health/login requests run between replay batches.
  if(conflicts.has(day))continue;
  const actual=actualForGame(row,'ank',market);if(actual===undefined)continue;
  let priorSource:string[];
  try{priorSource=[...new Set(sourceObservationWindow(draws,day,side,mode))];}catch{continue;}
  if(priorSource.length!==10)continue;
  const position=priorSource.indexOf(actual)+1;if(position<1)continue;
  if(indices.length===6){
   const age=Math.round((Date.parse(date)-Date.parse(day))/86400000),weight=age<=10?3:age<=20?2:1;
   samples++;
   if(indices.includes(position)){keepHits++;keepWeight+=weight;}
   if(!indices.slice(0,4).includes(position)){removeHits++;removeWeight+=weight;}
  }
  indices=[position,...indices.filter(p=>p!==position)].slice(0,6);
 }
 const result:SourceHistoryAnalysis={policy:SOURCE_HISTORY_POLICY,targetDate:date,market,sourceMode:mode,sourceDigits,indices,observations:values.length,startDate,endDate,keepHits,removeHits,keepWeight,removeWeight,samples};
 if(samples<5)return {...result,reason:`Only ${samples}/5 comparable results in source window ${startDate} to ${endDate}; card unchanged`};
 if(keepWeight===removeWeight)return {...result,reason:'Keep6 and Remove4 weighted scores tied in source window; card unchanged'};
 return {...result,mode:keepWeight>removeWeight?'keep6':'remove4'};
}
export function checkedSourceHistory(reply:any,date:string,market:string,mode:CardSourceMode,digits:string):SourceHistoryAnalysis{
 const a=reply?.sourceHistory as SourceHistoryAnalysis|undefined;
 if(reply?.status!=='success'||reply.staleCache||!a)throw Error(reply?.message||'Fresh source-window history unavailable');
 if(a.policy!==SOURCE_HISTORY_POLICY||a.targetDate!==date||normalized(a.market)!==normalized(market)||a.sourceMode!==mode||a.sourceDigits!==tokens(digits).join(', ')||!Array.isArray(a.indices)||a.indices.length>6||new Set(a.indices).size!==a.indices.length||a.indices.some(n=>!Number.isInteger(n)||n<1||n>10)||a.startDate>=date||a.endDate>=date)throw Error('History Apply: mismatched source/window response; card unchanged');
 const validDate=(d:unknown)=>typeof d==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(d)&&Number.isFinite(Date.parse(d))&&new Date(d).toISOString().slice(0,10)===d;
 if(!validDate(a.startDate)||a.endDate!==new Date(Date.parse(date)-86400000).toISOString().slice(0,10)||['samples','keepHits','removeHits','keepWeight','removeWeight','observations'].some(key=>!Number.isInteger((a as any)[key])||(a as any)[key]<0))throw Error('History Apply: invalid window evidence; card unchanged');
 if(a.mode&&(a.samples<5||a.indices.length!==6||!['keep6','remove4'].includes(a.mode)||a.keepWeight===a.removeWeight||(a.mode==='keep6')!==(a.keepWeight>a.removeWeight)))throw Error('History Apply: invalid comparison; card unchanged');
 return a;
}
