import type { DayMarketRecord, GameType, MarketItem, ProfileConfig, UserProfile } from '../types';
import { getDefaultConfig, getEffectiveBaseMarkets, getEffectiveMarkets, isMarketEnabled } from '../data/markets';
import { businessDateIST } from './businessDate';
import { dayLoopConfig, profileLoopTarget } from './dualLoops';
import { recoveryMarketOrder } from './recoveryMarketOrder';
import { calculateRecoveryRate, calculateSettlement, isRecoveryRatePossible } from './settlement';

export type WaveId = 'W1' | 'W2' | 'W3' | 'W4';
export const WAVE_IDS: readonly WaveId[] = ['W1', 'W2', 'W3', 'W4'] as const;

export function isFourWaveRelayActive(config: Partial<ProfileConfig> | undefined, loopEnabled = false): boolean {
  return !loopEnabled && config?.fourWaveRelay === true;
}

export interface FourWaveCardState {
  debt: number;
  consecutiveFails: number;
  waveId?: WaveId;
  waveIndex?: number;
  fromIndex?: number;
  fromCardKey?: string;
  pendingProfit?: number;
}

interface OrderedWaveEntry {
  m: MarketItem & { index: number };
  index: number;
  orderPos: number;
  rec: DayMarketRecord;
  status: string;
  isSettled: boolean;
  genuinelyDelivered: boolean;
  digits: string;
  hasValidDigits: boolean;
  isGenuineManualRate: boolean;
  isOpenPassForClose?: boolean;
}

/**
 * Core 4-Wave Auto-Relay + End-of-Day Handoff engine.
 * - Deals active/settled cards of the day into 4 independent waves: W1, W2, W3, W4 (pos % 4).
 * - Each wave carries its own recovery debt so consecutive fails across adjacent markets do not compound into a single chain.
 * - End-of-Day Handoff: if a card in wave W settles FAIL and wave W has no remaining cards in the day,
 *   its unrecovered debt is immediately handed off into carryHandoff for the next remaining card of the day.
 */
export function evaluateFourWaveDay(opts: {
  type: GameType;
  markets: MarketItem[];
  store: Record<string | number, DayMarketRecord | undefined>;
  cfg: ProfileConfig;
  visDict?: Record<string, boolean>;
  resetEnabled?: boolean;
  targetGetter: (m: MarketItem & { index: number }, rec: DayMarketRecord) => number;
  includeTargetIndex?: number;
  isArchiveOrBacktest?: boolean;
}): {
  byIndex: Map<number, FourWaveCardState>;
  waveDebt: [number, number, number, number];
  carryHandoff: number;
  totalPendingLoss: number;
  peakPendingLoss: number;
} {
  const {
    type,
    markets,
    store,
    cfg,
    visDict,
    resetEnabled = false,
    targetGetter,
    includeTargetIndex,
    isArchiveOrBacktest = false,
  } = opts;
  const ordered = recoveryMarketOrder(
    markets.map((m, idx) => ({ ...m, index: typeof m.id === 'number' ? m.id : idx }))
  );

  let lastSettledOrderPos = -1;
  let hasBacktestSettledCards = false;
  const rawEntries: OrderedWaveEntry[] = [];

  ordered.forEach((m, orderPos) => {
    const rec = (store[m.index] || { s: 'WAIT', d: '', r: '' }) as DayMarketRecord;
    const status =
      type === 'jodi' && (rec.jodiOpenStatus === 'PASS' || rec.jodiOpenStatus === 'FAIL')
        ? rec.jodiOpenStatus
        : String(rec.s || 'WAIT').toUpperCase().trim();
    const isSettled = status === 'PASS' || status === 'FAIL';
    if (isSettled) {
      lastSettledOrderPos = orderPos;
      if (rec.backtestResult?.checked) {
        hasBacktestSettledCards = true;
      }
    }
    const genuinelyDelivered = Boolean(rec.sentAt || rec.dispatchState === 'SENT');
    const digits = String(genuinelyDelivered ? (rec.sentDigits || rec.d || '') : (rec.d || '')).trim();
    const hasValidDigits = isRecoveryRatePossible(type, digits);
    const isGenuineManualRate = Boolean(rec.manualRate && !rec.manualStatus && Number(rec.r) > 0);
    const isCloseMkt = (type === 'ank' || type === 'pannel') && /\s+CLOSE$/i.test(m.n);
    const isOpenPassCloseZero = Boolean(cfg?.openPassCloseZero || profile?.openPassCloseZero || profile?.config?.openPassCloseZero);
    let isOpenPassForClose = false;
    if (isOpenPassCloseZero && isCloseMkt) {
      const bName = m.n.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
      const oName = `${bName} OPEN`;
      const oIdx = markets.findIndex(item => item.n.trim().toUpperCase() === oName);
      const oRec = oIdx >= 0 ? store[oIdx] : undefined;
      isOpenPassForClose = oRec?.s === 'PASS';
    }
    rawEntries.push({
      m,
      index: m.index,
      orderPos,
      rec,
      status,
      isSettled,
      genuinelyDelivered,
      digits,
      hasValidDigits,
      isGenuineManualRate,
      isOpenPassForClose,
    });
  });

  const anyWaitWithDigitsAfterSettled = rawEntries.some(
    (e) =>
      !e.isSettled &&
      !e.genuinelyDelivered &&
      e.orderPos > lastSettledOrderPos &&
      e.hasValidDigits &&
      !e.rec.backtestResult?.checked
  );

  const fourWaveEntries = rawEntries.filter((entry) => {
    const enabled = isMarketEnabled(cfg, entry.m.n) && (!visDict || visDict[entry.m.n] !== false);
    if (!enabled && !entry.isSettled && !entry.genuinelyDelivered) return false;
    if (entry.status === 'SKIP') return false;
    if (entry.isSettled || entry.genuinelyDelivered) return true;
    if (entry.orderPos < lastSettledOrderPos) return false; // Bypassed WAIT card
    // A WAIT card already checked by backtest with no result (e.g. closed market on weekend) was not played
    if (entry.rec.backtestResult?.checked && !entry.rec.manualStatus) return false;
    if (entry.hasValidDigits) return true;
    if (includeTargetIndex !== undefined && entry.index === includeTargetIndex) return true;
    // On a live day in progress when the user has not bulk-filled all later cards yet,
    // keep upcoming enabled markets in the day schedule so early fails never trigger premature EOD handoff.
    if (!isArchiveOrBacktest && !hasBacktestSettledCards && !anyWaitWithDigitsAfterSettled) {
      return true;
    }
    return false;
  });

  let lastSettledWavePos = -1;
  fourWaveEntries.forEach((entry, pos) => {
    if (entry.isSettled || entry.genuinelyDelivered) {
      lastSettledWavePos = pos;
    }
  });

  const isProfitCarry = Boolean(cfg?.profitCarry);
  const waveDebt: [number, number, number, number] = [0, 0, 0, 0];
  const waveFails: [number, number, number, number] = [0, 0, 0, 0];
  const waveProfit: [number, number, number, number] = [0, 0, 0, 0];
  const waveAssigned: [boolean, boolean, boolean, boolean] = [false, false, false, false];
  const waveFromIndex: [number, number, number, number] = [-1, -1, -1, -1];
  const waveFromCardKey: [string | undefined, string | undefined, string | undefined, string | undefined] = [
    undefined,
    undefined,
    undefined,
    undefined,
  ];
  let carryHandoff = 0;
  let carryProfitHandoff = 0;
  let carryFails = 0;
  let carryAssigned = false;
  let carryFromIndex = -1;
  let carryFromCardKey: string | undefined = undefined;
  let peakPendingLoss = 0;

  const byIndex = new Map<number, FourWaveCardState>();

  for (let pos = 0; pos < fourWaveEntries.length; pos++) {
    const entry = fourWaveEntries[pos];
    const w = pos % 4;
    const waveId = WAVE_IDS[w];

    if (entry.isOpenPassForClose && !entry.genuinelyDelivered) {
      byIndex.set(entry.index, {
        debt: 0,
        consecutiveFails: 0,
        waveId,
        waveIndex: w,
        fromIndex: -1,
        fromCardKey: undefined,
        pendingProfit: 0,
      });
      continue;
    }
    if (!entry.isSettled) {
      const canTakeWave = !waveAssigned[w];
      const canTakeCarry = canTakeWave && !carryAssigned && (carryHandoff > 0 || carryProfitHandoff > 0);
      const incomingDebt = canTakeWave
        ? Math.round((waveDebt[w] + (canTakeCarry ? carryHandoff : 0)) * 100) / 100
        : 0;
      const incomingProfit = canTakeWave && isProfitCarry
        ? Math.round((waveProfit[w] + (canTakeCarry ? carryProfitHandoff : 0)) * 100) / 100
        : 0;
      const incomingFails = canTakeWave
        ? Math.max(waveFails[w], canTakeCarry ? carryFails : 0)
        : 0;
      const fromIndex = canTakeCarry
        ? (carryFromIndex >= 0 ? carryFromIndex : waveFromIndex[w])
        : (canTakeWave ? waveFromIndex[w] : -1);
      const fromCardKey = canTakeCarry
        ? (carryFromCardKey || waveFromCardKey[w])
        : (canTakeWave ? waveFromCardKey[w] : undefined);

      byIndex.set(entry.index, {
        debt: incomingDebt,
        consecutiveFails: incomingFails,
        waveId,
        waveIndex: w,
        fromIndex,
        fromCardKey,
        pendingProfit: incomingProfit,
      });

      // Reserve the wave's recovery slot on the immediate next upcoming card of this wave
      waveAssigned[w] = true;
      if (canTakeCarry) carryAssigned = true;
      continue;
    }

    const handoff = carryHandoff;
    const profitHandoff = carryProfitHandoff;
    const incomingDebt = Math.round((waveDebt[w] + handoff) * 100) / 100;
    const incomingProfit = isProfitCarry ? Math.round((waveProfit[w] + profitHandoff) * 100) / 100 : 0;
    const incomingFails = Math.max(waveFails[w], handoff > 0 ? carryFails : 0);
    const fromIndex = handoff > 0 && carryFromIndex >= 0 ? carryFromIndex : waveFromIndex[w];
    const fromCardKey = handoff > 0 && carryFromCardKey ? carryFromCardKey : waveFromCardKey[w];

    byIndex.set(entry.index, {
      debt: incomingDebt,
      consecutiveFails: incomingFails,
      waveId,
      waveIndex: w,
      fromIndex,
      fromCardKey,
      pendingProfit: incomingProfit,
    });

    const target = targetGetter(entry.m, entry.rec);
    if (entry.isOpenPassForClose) {
      waveAssigned[w] = false;
      if (entry.status === 'FAIL') {
        if (isProfitCarry) {
          waveProfit[w] = Math.round((waveProfit[w] + target) * 100) / 100;
        }
        const hasSettledOrSentInWaveAfter = fourWaveEntries
          .slice(pos + 1)
          .some((e, idx) => (pos + 1 + idx) % 4 === w && (e.isSettled || e.genuinelyDelivered));
        const hasUpcomingLiveWaitInWaveAfter =
          pos + 4 > lastSettledWavePos &&
          pos + 4 < fourWaveEntries.length &&
          !fourWaveEntries[pos + 4].rec.backtestResult?.checked;
        const hasNextCardInWave = hasSettledOrSentInWaveAfter || hasUpcomingLiveWaitInWaveAfter;
        const hasAnyCardAfter =
          pos < lastSettledWavePos ||
          (pos + 1 < fourWaveEntries.length && !fourWaveEntries[pos + 1].rec.backtestResult?.checked);
        if (!hasNextCardInWave && hasAnyCardAfter && (waveDebt[w] > 0 || waveProfit[w] > 0)) {
          carryHandoff = Math.round((carryHandoff + waveDebt[w]) * 100) / 100;
          carryProfitHandoff = Math.round((carryProfitHandoff + waveProfit[w]) * 100) / 100;
          carryFails = Math.max(carryFails, waveFails[w]);
          waveDebt[w] = 0;
          waveProfit[w] = 0;
          waveFails[w] = 0;
        }
      } else if (entry.status === 'PASS') {
        waveProfit[w] = 0;
      }
      continue;
    }

    // Settled card consumes any pending carryHandoff
    carryHandoff = 0;
    carryProfitHandoff = 0;
    carryFails = 0;
    carryAssigned = false;
    carryFromIndex = -1;
    carryFromCardKey = undefined;
    waveAssigned[w] = false;

    const effectiveTarget = target + incomingProfit;
    const cardRate = entry.rec.sentAt
      ? (entry.rec.sentRate || entry.rec.r)
      : (entry.isGenuineManualRate
          ? entry.rec.r
          : (calculateRecoveryRate(type, entry.digits, incomingDebt, effectiveTarget) || entry.rec.r || entry.rec.recRate));
    const settlement = calculateSettlement({
      type,
      digits: entry.digits,
      rate: cardRate,
      sentRate: entry.rec.sentAt ? entry.rec.sentRate : undefined,
      sentInvest: entry.rec.sentAt ? entry.rec.sentInvest : undefined,
      smartStaking: entry.rec.sentAt ? entry.rec.smartStaking : undefined,
    });

    if (settlement.tokenCount > 0 && settlement.invest > 0) {
      const otherWavesDebt =
        waveDebt[0] + waveDebt[1] + waveDebt[2] + waveDebt[3] - waveDebt[w];
      peakPendingLoss = Math.max(peakPendingLoss, otherWavesDebt + incomingDebt + settlement.invest);

      waveFromIndex[w] = entry.index;
      waveFromCardKey[w] = `${type}_${entry.index}`;

      if (entry.status === 'FAIL') {
        waveDebt[w] = Math.round((incomingDebt + settlement.invest) * 100) / 100;
        if (isProfitCarry) {
          waveProfit[w] = Math.round((incomingProfit + target) * 100) / 100;
        }
        waveFails[w] = incomingFails + 1;
        if (resetEnabled && waveFails[w] >= 3) {
          waveDebt[w] = 0;
          waveProfit[w] = 0;
          waveFails[w] = 0;
        }
        const hasSettledOrSentInWaveAfter = fourWaveEntries
          .slice(pos + 1)
          .some((e, idx) => (pos + 1 + idx) % 4 === w && (e.isSettled || e.genuinelyDelivered));
        const hasUpcomingLiveWaitInWaveAfter =
          pos + 4 > lastSettledWavePos &&
          pos + 4 < fourWaveEntries.length &&
          !fourWaveEntries[pos + 4].rec.backtestResult?.checked;
        const hasNextCardInWave = hasSettledOrSentInWaveAfter || hasUpcomingLiveWaitInWaveAfter;
        const hasAnyCardAfter =
          pos < lastSettledWavePos ||
          (pos + 1 < fourWaveEntries.length && !fourWaveEntries[pos + 1].rec.backtestResult?.checked);

        if (!hasNextCardInWave && hasAnyCardAfter && (waveDebt[w] > 0 || waveProfit[w] > 0)) {
          carryHandoff = Math.round((carryHandoff + waveDebt[w]) * 100) / 100;
          carryProfitHandoff = Math.round((carryProfitHandoff + waveProfit[w]) * 100) / 100;
          carryFails = Math.max(carryFails, waveFails[w]);
          carryFromIndex = waveFromIndex[w];
          carryFromCardKey = waveFromCardKey[w];
          waveDebt[w] = 0;
          waveProfit[w] = 0;
          waveFails[w] = 0;
        }
      } else if (entry.status === 'PASS') {
        waveDebt[w] = 0;
        waveProfit[w] = 0;
        waveFails[w] = 0;
      }
    }
  }

  const totalPendingLoss = Math.round(
    (waveDebt[0] + waveDebt[1] + waveDebt[2] + waveDebt[3] + carryHandoff) * 100
  ) / 100;

  return {
    byIndex,
    waveDebt,
    carryHandoff,
    totalPendingLoss,
    peakPendingLoss: Math.round(peakPendingLoss * 100) / 100,
  };
}

export function getCardFourWaveStateForProfile(
  profile: UserProfile | undefined,
  currentDate: string,
  type: GameType,
  index: number
): FourWaveCardState {
  if (!profile) return { debt: 0, consecutiveFails: 0 };
  const day = profile.dayRecords?.[currentDate];
  const isPast = currentDate < businessDateIST();
  const cfg =
    (isPast ? day?.recoveryConfigSnapshot : undefined) ||
    profile.config ||
    getDefaultConfig();
  const resetEnabled = isPast
    ? day?.backtestRecoveryPolicy?.resetAfterThreeFails === true
    : cfg.liveThreeFailReset === true;
  const loopCfg = dayLoopConfig(profile, currentDate);
  const store = (type === 'ank' ? day?.data : type === 'jodi' ? day?.jodiData : day?.pannelData) || {};
  const visDict = type === 'ank' ? day?.visAnk : type === 'jodi' ? day?.visJodi : day?.visPan;
  const markets = type === 'jodi' ? getEffectiveBaseMarkets(cfg) : getEffectiveMarkets(cfg);

  const res = evaluateFourWaveDay({
    type,
    markets,
    store,
    cfg,
    visDict,
    resetEnabled,
    targetGetter: (m, rec) =>
      loopCfg?.enabled
        ? profileLoopTarget(profile, currentDate, type, m.n, rec)
        : parseFloat(String(cfg?.[type]?.tgt)) || 100,
    includeTargetIndex: index,
    isArchiveOrBacktest: isPast,
  });

  return res.byIndex.get(index) || { debt: 0, consecutiveFails: 0 };
}

export function evaluateServerFourWaveType(
  prof: any,
  type: GameType,
  cardsOverride?: Record<string, any>,
  includeTargetIndex?: number
) {
  const allCards = cardsOverride || prof?.cards || {};
  const typedMarkets = (Array.isArray(prof?.markets) ? prof.markets : [])
    .filter((m: any) => String(m?.type || '') === type)
    .sort((a: any, b: any) => Number(a?.index || 0) - Number(b?.index || 0));

  const store: Record<number, DayMarketRecord | undefined> = {};
  const visDict: Record<string, boolean> = {};
  const markets: MarketItem[] = typedMarkets.map((m: any) => {
    const idx = Number(m.index);
    store[idx] = allCards[`${type}_${idx}`];
    if (m.enabled === false) visDict[m.n] = false;
    return {
      id: idx as any,
      n: String(m.n || ''),
      hr: m.hr,
      min: m.min,
    };
  });

  const cfg: ProfileConfig = {
    ...getDefaultConfig(),
    fourWaveRelay: true,
    ankSplit: false,
    panSplit: false,
    profitCarry: Boolean(prof?.profitCarry || prof?.config?.profitCarry),
    openPassCloseZero: Boolean(prof?.openPassCloseZero || prof?.config?.openPassCloseZero),
  };
  const resetEnabled = prof?.liveThreeFailReset === true;
  const defaultTgt = Number(prof?.targetProfit?.[type]) || 100;

  return evaluateFourWaveDay({
    type,
    markets,
    store,
    cfg,
    visDict,
    resetEnabled,
    targetGetter: () => defaultTgt,
    includeTargetIndex,
    isArchiveOrBacktest: false,
  });
}
