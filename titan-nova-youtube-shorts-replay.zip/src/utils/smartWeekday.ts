export interface DatedJodi { date: string; jodi: string; order?: number; weekday?: number }
type Side = 'open' | 'close';
const digit = (jodi: string, side: Side) => jodi[side === 'open' ? 0 : 1];

const dateToken = '(?:\\d{4}[-/]\\d{1,2}[-/]\\d{1,2}|\\d{1,2}[-/]\\d{1,2}[-/]\\d{2,4})';
const rangePattern = new RegExp(`^(${dateToken})\\s*(?:to|[-–—])\\s*(${dateToken})$`, 'i');
export function smartDateRange(label: string): [string, string] | null {
  const match = label.trim().replace(/\s*([/])\s*/g, '$1').match(rangePattern);
  return match ? [match[1], match[2]] : null;
}

export function chartSingleDate(label: string): string | null {
  const clean = label.trim();
  const iso = clean.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/);
  const match = clean.match(/^(\d{1,2})\s*[\/\-]\s*(\d{1,2})\s*[\/\-]\s*(\d{2,4})$/);
  if (!iso && !match) return null;
  const rawYear = Number(iso ? iso[1] : match![3]);
  const year = rawYear < 100 ? 2000 + rawYear : rawYear;
  const month = Number(iso ? iso[2] : match![2]) - 1;
  const day = Number(iso ? iso[3] : match![1]);
  const date = new Date(Date.UTC(year, month, day));
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month || date.getUTCDate() !== day) return null;
  return date.toISOString().slice(0, 10);
}

export function chartWeekDates(label: string, slots: number): string[] {
  const range = smartDateRange(label);
  if (!range || slots < 1 || slots > 7) return [];
  const firstDate = chartSingleDate(range[0]);
  const lastDate = chartSingleDate(range[1]);
  const first = firstDate ? new Date(`${firstDate}T00:00:00Z`) : null;
  const last = lastDate ? new Date(`${lastDate}T00:00:00Z`) : null;
  if (!first || !last) return [];
  const span = (last.getTime() - first.getTime()) / 86400000 + 1;
  // Several weekly charts label Monday–Sunday but publish only six result
  // columns (Monday–Saturday). The omitted Sunday is unambiguous here.
  const sundayClosed = span === 7 && slots === 6 && first.getUTCDay() === 1 && last.getUTCDay() === 0;
  if (span !== slots && !sundayClosed) return [];
  return Array.from({ length: slots }, (_, index) => new Date(first.getTime() + index * 86400000).toISOString().slice(0, 10));
}

export interface SmartSelection {
  open: string[];
  close: string[];
  weekdaySamples: number;
  successorSamples: number;
  baseJodi: string;
  weekday: string;
  fallback: string[];
}

export function selectSmartWeekdayDigits(
  draws: DatedJodi[], today: string, fallbackJodis: string[] = [],
): SmartSelection | null {
  const now = new Date(`${today}T00:00:00Z`);
  if (Number.isNaN(now.getTime()) || now.toISOString().slice(0, 10) !== today) return null;
  const sequence = (fallbackJodis.length ? fallbackJodis : draws.map(draw => draw.jodi)).filter(jodi => /^\d{2}$/.test(jodi));
  if (!sequence.length) return null;
  // Malformed historical labels affect weekday statistics only. Pair history
  // is read in chart order and remains available for transitions and fallback.
  let lastDate = '';
  const history = draws.filter(draw => {
    if (!/^\d{2}$/.test(draw.jodi) || !/^\d{4}-\d{2}-\d{2}$/.test(draw.date) || draw.date > today || draw.date <= lastDate) return false;
    lastDate = draw.date;
    return true;
  });
  const weekday = now.getUTCDay();
  const seenWeekdayDraws = new Set<string>();
  const weekdayDraws = draws.filter(draw => {
    if (!/^\d{2}$/.test(draw.jodi) || !(draw.weekday === weekday ||
      (draw.weekday === undefined && history.includes(draw) && new Date(`${draw.date}T00:00:00Z`).getUTCDay() === weekday))) return false;
    const key = draw.date || String(draw.order);
    if (seenWeekdayDraws.has(key)) return false;
    seenWeekdayDraws.add(key);
    return true;
  });
  const baseJodi = sequence[sequence.length - 1];
  const successors: DatedJodi[] = sequence.slice(0, -1).flatMap((jodi, index) => {
    const from = draws[index];
    const next = draws[index + 1];
    const adjacent = fallbackJodis.length > 0 || from?.order === undefined || next?.order === undefined || next.order === from.order + 1;
    return jodi === baseJodi && adjacent ? [{ date: '', jodi: sequence[index + 1], order: index + 1 }] : [];
  });
  const fallback: string[] = weekdayDraws.length ? [] : ['weekday dates unavailable; pair history used'];
  const pick = (side: Side): string[] => {
    const scores = new Map<string, { overlap: number; support: number; recent: number }>();
    const add = (set: DatedJodi[]) => {
      const counts = new Map<string, number>();
      set.forEach((draw) => counts.set(digit(draw.jodi, side), (counts.get(digit(draw.jodi, side)) || 0) + 1));
      if (!counts.size) return;
      const ranked = [...counts].sort((a, b) => b[1] - a[1] || b[0].localeCompare(a[0]));
      const high = ranked[0][0];
      const low = [...counts].sort((a, b) => a[1] - b[1] || b[0].localeCompare(a[0]))[0][0];
      for (const value of [high, low]) {
        const row = scores.get(value) || { overlap: 0, support: 0, recent: -1 };
        row.overlap++;
        row.support += counts.get(value) || 0;
        row.recent = Math.max(row.recent, ...set.filter((draw) => digit(draw.jodi, side) === value).map((draw) => draw.order ?? Date.parse(`${draw.date}T00:00:00Z`)));
        scores.set(value, row);
      }
    };
    add(weekdayDraws);
    add(successors);
    const chosen = [...scores].sort((a, b) => b[1].overlap - a[1].overlap || b[1].support - a[1].support || b[1].recent - a[1].recent || a[0].localeCompare(b[0])).map(([value]) => value);
    if (chosen.length < 2) {
      const recent = (fallbackJodis.length ? fallbackJodis : history.map((draw) => draw.jodi))
        .filter((jodi) => /^\d{2}$/.test(jodi)).reverse();
      // OPEN and CLOSE remain independent even in the fallback.
      for (const jodi of recent) {
        const value = digit(jodi, side);
        if (!chosen.includes(value)) chosen.push(value);
        if (chosen.length === 2) break;
      }
      if (chosen.length === 2) fallback.push(`${side}: recent ${side}`);
    }
    // Preserve a genuine tie at the second boundary instead of arbitrarily
    // eliminating the third candidate. The response never exceeds 3 digits.
    const ranked = [...scores].sort((a, b) => b[1].overlap - a[1].overlap || b[1].support - a[1].support || b[1].recent - a[1].recent || a[0].localeCompare(b[0]));
    const tiedThird = ranked.length >= 3 && ranked[1][1].overlap === ranked[2][1].overlap && ranked[1][1].support === ranked[2][1].support;
    return chosen.slice(0, tiedThird ? 3 : 2);
  };
  return { open: pick('open'), close: pick('close'), weekdaySamples: weekdayDraws.length, successorSamples: successors.length, baseJodi, weekday: today, fallback };
}
