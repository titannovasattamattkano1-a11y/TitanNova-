import type {AppState,UserProfile} from '../types';
import {businessDateIST} from './businessDate';
import {carryControlMode,datedResultRemovalSettings} from './autoRemoveResult';
import {applyCarryResultSixDay, applyCutFiveDay} from './carryResultSix';
import {calculateBacktestRecovery} from './backtestRecovery';
import {vipCopiesAdmin} from './adminMirror';

/** Same carry overlay and archive calculator used by the former blocking API. */
export function replayResultControlDay(profile:UserProfile,date:string,carryModeChanged=false):UserProfile {
 const mode = carryControlMode(profile, date);
 let prepared = profile;
 if (carryModeChanged) {
   if (mode === 'CARRY6') {
     prepared = applyCutFiveDay(prepared, date, false);
     prepared = applyCarryResultSixDay(prepared, date, true);
   } else if (mode === 'CUT3') {
     prepared = applyCarryResultSixDay(prepared, date, false);
     prepared = applyCutFiveDay(prepared, date, true);
   } else {
     prepared = applyCarryResultSixDay(prepared, date, false);
     prepared = applyCutFiveDay(prepared, date, false);
   }
 }
 return date<businessDateIST()?calculateBacktestRecovery(prepared,date):prepared;
}

/** Reconcile accepted control edits even if the browser worker was interrupted.
 * Ordinary autosaves/retries with unchanged settings do not replay controls.
 */
export function reconcileResultControlChanges(incoming:AppState,stored:AppState|null,busyProfileId?:string):AppState {
 if(!stored)return incoming;
 const today=businessDateIST();let profiles=incoming.profiles;
 for(const [pid,profile] of Object.entries(incoming.profiles)){
  const old=stored.profiles[pid];if(!old||!profile.config||!old.config||!profile.dayRecords||!old.dayRecords)continue;
  // A full-year save may change a phone, VIP permission or payment setting
  // without touching a single historical day or any Result/Cut control.
  // In that case the old day replay loop is provably a no-op: every dated
  // policy, OPEN->CLOSE flag and the four profile-level control inputs match.
  if (profile.dayRecords===old.dayRecords &&
      ['autoCarryResultSix','autoRemoveResultDigit','autoRemoveResultMirror','autoRemoveResultUnique3']
        .every(key => (profile.config as any)[key]===(old.config as any)[key])) continue;
  let next=profile;
  const dates=new Set([today,...Object.keys(profile.dayRecords||{})]);
  for(const date of dates){
   if(date>today||!/^\d{4}-\d{2}-\d{2}$/.test(date))continue;
   if(date<today&&profile.dayRecords[date]===old.dayRecords[date])continue;
   const openCutChanged=profile.dayRecords[date]?.openToCloseCut!==old.dayRecords[date]?.openToCloseCut;
   if(date<today&&!openCutChanged&&!(['autoCarryResultSix','autoRemoveResultDigit','autoRemoveResultMirror','autoRemoveResultUnique3'] as const).some(key=>profile.dayRecords[date]?.backtestRecoveryPolicy?.[key]!==old.dayRecords[date]?.backtestRecoveryPolicy?.[key]))continue;
   const mode=carryControlMode(profile,date),beforeMode=carryControlMode(old,date);
   const carryChanged=mode!==beforeMode;
   const a=datedResultRemovalSettings(old,date),b=datedResultRemovalSettings(profile,date);
   const cutChanged=(a.autoRemoveResultDigit===true)!==(b.autoRemoveResultDigit===true)||(a.autoRemoveResultMirror===true)!==(b.autoRemoveResultMirror===true)||(a.autoRemoveResultUnique3===true)!==(b.autoRemoveResultUnique3===true);
   if(!carryChanged&&!cutChanged&&!openCutChanged)continue;
   if(carryChanged){
    if(pid===busyProfileId)throw new Error('Stop this profile’s range trial before changing Carry 6 / Cut 3');
    if(pid!=='admin1'&&vipCopiesAdmin(profile)&&incoming.profiles.admin1&&carryControlMode(incoming.profiles.admin1,date)==='CARRY6')throw new Error('Carry 6 is inherited from Copy Admin; change the Admin setting first');
   }
   // Live cut routing is handled by the normal confirmed runtime publisher.
   if(date===today&&!carryChanged)continue;
   next=replayResultControlDay(next,date,carryChanged);
  }
  if(next!==profile){if(profiles===incoming.profiles)profiles={...profiles};profiles[pid]=next;}
 }
 return profiles===incoming.profiles?incoming:{...incoming,profiles};
}
