/** Hidden cards use negative addresses. Numeric sorting would reverse their
 * original sequence and can put a recovery PASS before its source FAIL. */
export function recoveryMarketOrder<T extends {index?:number;hr?:number;min?:number}>(markets:readonly T[]):T[]{
  const minute=(m:T)=>{
    const h=Number(m.hr),n=Number(m.min);
    return Number.isInteger(h)&&h>=0&&h<24&&Number.isInteger(n)&&n>=0&&n<60?(h<6?1440:0)+h*60+n:undefined;
  };
  const timed=markets.every(m=>minute(m)!==undefined);
  const address=(m:T)=>Number(m.index)<0?Number.MIN_SAFE_INTEGER-Number(m.index):Number(m.index);
  return [...markets].sort((a,b)=>(timed?minute(a)!-minute(b)!:0)||address(a)-address(b));
}
