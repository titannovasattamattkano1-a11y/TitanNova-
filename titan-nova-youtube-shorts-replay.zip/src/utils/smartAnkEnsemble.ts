export type SmartAnkSide = 'open' | 'close';
export type SmartAnkMethod = 'hot' | 'gap' | 'markov' | 'decay';

const DIGITS = Array.from({ length: 10 }, (_, index) => String(index));
const WINDOWS = [10, 20, 30] as const;
const METHODS: SmartAnkMethod[] = ['hot', 'gap', 'markov', 'decay'];

export interface SmartAnkExpert {
  method: SmartAnkMethod;
  window: 10 | 20 | 30;
  digits: string[];
  samples: number;
  hits: number;
  hitPercent: number;
  weight: number;
}

export interface SmartAnkSelection {
  sourceDigits: string[];
  digits: string[];
  side: SmartAnkSide;
  historySize: number;
  windows: number[];
  methodSupport: Record<string, number>;
  experts: SmartAnkExpert[];
  rule: 'adaptive_ensemble_convergence_v1';
}

const validDigits = (values: unknown[]) => values
  .map((value) => String(value ?? '').trim())
  .filter((value) => /^\d$/.test(value));

function rank(historyRecentFirst: string[], method: SmartAnkMethod): string[] {
  const history = validDigits(historyRecentFirst);
  if (!history.length) return [];
  const count = new Map(DIGITS.map((digit) => [digit, 0]));
  const recent = new Map(DIGITS.map((digit) => [digit, Number.MAX_SAFE_INTEGER]));
  history.forEach((digit, index) => {
    count.set(digit, (count.get(digit) || 0) + 1);
    if (recent.get(digit) === Number.MAX_SAFE_INTEGER) recent.set(digit, index);
  });

  if (method === 'hot') {
    return [...DIGITS].filter((digit) => (count.get(digit) || 0) > 0).sort((a, b) =>
      (count.get(b) || 0) - (count.get(a) || 0) ||
      (recent.get(a) || 0) - (recent.get(b) || 0) || a.localeCompare(b));
  }

  if (method === 'gap') {
    const gap = (digit: string) => {
      const value = recent.get(digit) ?? Number.MAX_SAFE_INTEGER;
      return value === Number.MAX_SAFE_INTEGER ? history.length + 1 : value;
    };
    return [...DIGITS].sort((a, b) => gap(b) - gap(a) ||
      (count.get(a) || 0) - (count.get(b) || 0) || a.localeCompare(b));
  }

  if (method === 'decay') {
    const score = new Map(DIGITS.map((digit) => [digit, 0]));
    history.forEach((digit, index) => score.set(digit, (score.get(digit) || 0) + 1 / (index + 1)));
    return [...DIGITS].filter((digit) => (count.get(digit) || 0) > 0).sort((a, b) => (score.get(b) || 0) - (score.get(a) || 0) ||
      (count.get(b) || 0) - (count.get(a) || 0) || a.localeCompare(b));
  }

  const latest = history[0];
  const transitions = new Map(DIGITS.map((digit) => [digit, 0]));
  // recent-first: history[index] happened before history[index - 1].
  for (let index = 1; index < history.length; index++) {
    if (history[index] === latest) {
      const next = history[index - 1];
      transitions.set(next, (transitions.get(next) || 0) + 1);
    }
  }
  return [...DIGITS].filter((digit) => (count.get(digit) || 0) > 0).sort((a, b) =>
    (transitions.get(b) || 0) - (transitions.get(a) || 0) ||
    (count.get(b) || 0) - (count.get(a) || 0) ||
    (recent.get(a) || 0) - (recent.get(b) || 0) || a.localeCompare(b));
}

function walkForward(historyRecentFirst: string[], method: SmartAnkMethod, window: 10 | 20 | 30) {
  const chronological = [...historyRecentFirst].reverse();
  let samples = 0;
  let hits = 0;
  // Five observations are the minimum needed to avoid scoring an expert from
  // one or two accidental transitions. Every cutoff remains inside latest 30.
  for (let target = 5; target < chronological.length; target++) {
    const training = chronological.slice(Math.max(0, target - window), target).reverse();
    if (rank(training, method).slice(0, 2).includes(chronological[target])) hits++;
    samples++;
  }
  // Two hits in ten virtual trials is the neutral two-of-ten random baseline.
  // The prior prevents tiny samples from receiving extreme influence.
  const smoothed = (hits + 2) / (samples + 10);
  const weight = Number(Math.max(0.25, Math.min(2.5, 1 + (smoothed - 0.2) * 5)).toFixed(4));
  return { samples, hits, hitPercent: samples ? Number((100 * hits / samples).toFixed(2)) : 0, weight };
}

/**
 * Smart ANK authority. It uses only the latest 30 valid jodi pairs and keeps
 * OPEN/CLOSE independent. Four public predictor families vote across fixed
 * 10/20/30 windows; a digit needs support from at least two different methods.
 * No convergence means SKIP rather than inventing a second digit.
 */
export function selectSmartAnkEnsemble(
  chronologicalJodis: unknown[], side: SmartAnkSide,
): SmartAnkSelection | null {
  const sideIndex = side === 'open' ? 0 : 1;
  const history = chronologicalJodis
    .map((value) => String(value ?? '').trim())
    .filter((value) => /^\d{2}$/.test(value))
    .map((jodi) => jodi[sideIndex])
    .slice(-30)
    .reverse();
  if (history.length < 10) return null;

  const experts: SmartAnkExpert[] = [];
  const methodScores = new Map<SmartAnkMethod, Map<string, number>>();
  for (const method of METHODS) {
    const scores = new Map(DIGITS.map((digit) => [digit, 0]));
    for (const window of WINDOWS) {
      const windowHistory = history.slice(0, window);
      const validation = walkForward(history, method, window);
      const digits = rank(windowHistory, method).slice(0, 2);
      experts.push({ method, window, digits, ...validation });
      digits.forEach((digit, rankIndex) => scores.set(digit,
        (scores.get(digit) || 0) + validation.weight * (rankIndex === 0 ? 1 : 0.75)));
    }
    methodScores.set(method, scores);
  }

  const methodNominations = new Map<SmartAnkMethod, string[]>();
  methodScores.forEach((scores, method) => methodNominations.set(method,
    [...DIGITS].filter((digit) => (scores.get(digit) || 0) > 0)
      .sort((a, b) => (scores.get(b) || 0) - (scores.get(a) || 0) || a.localeCompare(b)).slice(0, 2)));

  const support = new Map(DIGITS.map((digit) => [digit, 0]));
  const totalScore = new Map(DIGITS.map((digit) => [digit, 0]));
  methodNominations.forEach((digits, method) => digits.forEach((digit, rankIndex) => {
    support.set(digit, (support.get(digit) || 0) + 1);
    totalScore.set(digit, (totalScore.get(digit) || 0) +
      (methodScores.get(method)?.get(digit) || 0) * (rankIndex === 0 ? 1 : 0.9));
  }));

  const chosen = [...DIGITS]
    .filter((digit) => (support.get(digit) || 0) >= 2)
    .sort((a, b) => (support.get(b) || 0) - (support.get(a) || 0) ||
      (totalScore.get(b) || 0) - (totalScore.get(a) || 0) || a.localeCompare(b))
    .slice(0, 2);
  if (chosen.length < 2) return null;

  return {
    sourceDigits: [...DIGITS].sort((a, b) =>
      (support.get(b) || 0) - (support.get(a) || 0) ||
      (totalScore.get(b) || 0) - (totalScore.get(a) || 0) || a.localeCompare(b)),
    digits: chosen,
    side,
    historySize: history.length,
    windows: [...WINDOWS],
    methodSupport: Object.fromEntries(chosen.map((digit) => [digit, support.get(digit) || 0])),
    experts,
    rule: 'adaptive_ensemble_convergence_v1',
  };
}
