import { actualForGame, type DatedActual } from './backtestResult';
import type { GameType } from '../types';

export interface ResultTestNotice { title:string; message:string; kind:'info'|'warning' }
/** Describe only published exact-date data; never infer a missing draw. */
export function resultTestNotice(actual:DatedActual|null|undefined,type:GameType,name:string,date:string,stale=false):ResultTestNotice {
  if(!actual){
    return {title:'Result not published',kind:'warning',message:`${name} · ${date}: selected date ka verified chart result nahi mila. Card WAIT rahega; date/source check karo.`};
  }
  const selected=actualForGame(actual,type,name);
  if(selected===undefined){
    const missing=type==='jodi'?'JODI':/\s+CLOSE$/i.test(name)?'CLOSE':'OPEN';
    return {title:'Partial chart result',kind:'warning',message:`${name} · ${date}: ${missing} result source par missing hai. Guess nahi kiya; card WAIT reh sakta hai.`};
  }
  const completeness=actual.open&&actual.jodi&&actual.close?'complete':'partial';
  return {title:'Exact-date result received',kind:'info',message:`${name} · ${date}: ${selected} (${completeness}${stale?', cached source':''}). Card par PASS/FAIL aur saving status verify karo.`};
}
export function resultTestErrorMessage(error:unknown):string {
  const message=error instanceof Error?error.message:String(error||'Unknown error');
  if(/network request failed|scraping timeout|fetch failed|502|503|504/i.test(message))
    return `${message}. Termux PM2 web, Cloudflare tunnel aur chart provider check karo.`;
  if(/exact-date result unavailable|invalid chart server response/i.test(message))
    return `${message}. Website frontend aur Termux backend ka updated build/version check karo.`;
  return message;
}
