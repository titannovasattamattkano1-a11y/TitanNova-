import { lazy, type ComponentType } from 'react';

/** Navigation and idle warming share one module request and one promise. */
export function preloadableView<T extends ComponentType<any>>(loader: () => Promise<{ default: T }>) {
  let pending: ReturnType<typeof loader> | undefined;
  const load = () => pending || (pending = loader().catch(error => {
    // Failed idle warming must remain retryable when the user opens the view.
    pending = undefined;
    throw error;
  }));
  return Object.assign(lazy(load), { preload: load });
}
