import type { GameType, UserProfile, DayMarketRecord } from '../types';
import { getEffectiveBaseMarkets, getEffectiveMarkets } from '../data/markets';
import { isEditableSourceSkip } from './marketModelCard';
import { vipLiveMarketEligible } from './vipLiveStart';
import { isMarketEnabledForDate } from './profileMarketToggle';

const normalizeSnapshotMarketName = (value: unknown): string =>
  String(value || '')
    .trim()
    .replace(/\s+/g, ' ')
    .toUpperCase()
    .replace(/^(?:SHRIDEVI|SRIDEVI|SRIDEV) DAY\b/, 'SRIDEVI')
    .replace(/^(?:SHRIDEVI|SRIDEV)\b/, 'SRIDEVI');

export interface AdminCopySnapshotTarget {
  type: GameType;
  index: number;
  marketName: string;
}
export interface AdminCopySnapshotPlan {
  targets: AdminCopySnapshotTarget[];
  noSource: number;
  outsideVipLiveEntry: number;
  nameConflict: number;
  settledOrSent: number;
  marketOff: number;
}

/** Snapshot is not an undo/reset command: even backtested settled cards stay intact. */
export function isAdminSnapshotProtected(record:{s?:string;manualStatus?:unknown;sentRate?:unknown;sentDigits?:unknown;sentAt?:unknown;dispatchState?:unknown;deliveryRestoredAt?:unknown;vipAutoStopSkipped?:unknown}|undefined):boolean {
  return Boolean(record && (record.s==='PASS'||record.s==='FAIL'||record.s==='SKIP'||record.manualStatus||
    record.sentRate||record.sentDigits||record.sentAt||record.dispatchState||record.deliveryRestoredAt||record.vipAutoStopSkipped));
}
export function adminSnapshotMarketEnabled(vip:UserProfile,date:string,type:GameType,name:string):boolean {
  const day=vip.dayRecords?.[date];
  const visibility=type==='ank'?day?.visAnk:type==='jodi'?day?.visJodi:day?.visPan;
  return isMarketEnabledForDate(vip.config,visibility,name,date);
}

/**
 * Plan one explicit, one-off Admin snapshot without changing VIP mirroring policy.
 * Exact source presence and stable market identities are required before any
 * eligible unsent source copy; cards without an Admin source are untouched.
 * The server remains authoritative for the actual guarded source projection.
 */
export function planAdminCopySnapshot(vip: UserProfile, admin: UserProfile, date: string): AdminCopySnapshotPlan {
  const plan: AdminCopySnapshotPlan = {
    targets: [], noSource: 0, outsideVipLiveEntry: 0, nameConflict: 0, settledOrSent: 0, marketOff: 0,
  };
  for (const type of ['ank', 'jodi', 'pannel'] as const) {
    const vipMarkets = type === 'jodi' ? getEffectiveBaseMarkets(vip.config) : getEffectiveMarkets(vip.config);
    const adminMarkets = type === 'jodi' ? getEffectiveBaseMarkets(admin.config) : getEffectiveMarkets(admin.config);
    const adminIdxByName = new Map(adminMarkets.map((market, index) => [normalizeSnapshotMarketName(market.n), index]));
    const dictName = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
    const source = (admin.dayRecords?.[date]?.[dictName] || {}) as Record<number, DayMarketRecord>;
    const existing = (vip.dayRecords?.[date]?.[dictName] || {}) as Record<number, DayMarketRecord>;
    for (let index = 0; index < vipMarkets.length; index++) {
      const rawName = vipMarkets[index].n.trim().toUpperCase();
      const name = normalizeSnapshotMarketName(rawName);
      if (!vipLiveMarketEligible(vip, date, type, rawName)) { plan.outsideVipLiveEntry++; continue; }
      if (!adminSnapshotMarketEnabled(vip,date,type,rawName)) { plan.marketOff++; continue; }
      const adminIndex = adminIdxByName.get(name);
      const adminCard = adminIndex === undefined ? undefined : source[adminIndex];
      if (!adminCard || (!String(adminCard.d || '').trim() && !isEditableSourceSkip(adminCard))) { plan.noSource++; continue; }
      // Admin source identity must also match the configured market; indices may
      // have been reused after a market reorder or a stale ledger restore.
      if (adminCard.marketName && normalizeSnapshotMarketName(adminCard.marketName) !== name) { plan.nameConflict++; continue; }
      // Never overwrite a differently named saved card after configuration reordering.
      const vipCard = existing[index];
      if (vipCard?.marketName && normalizeSnapshotMarketName(vipCard.marketName) !== name) { plan.nameConflict++; continue; }
      if (isAdminSnapshotProtected(vipCard)) {
        plan.settledOrSent++; continue;
      }
      plan.targets.push({ type, index, marketName: rawName });
    }
  }
  return plan;
}

/** Small read-only preview; never return other dates, credentials or full profiles. */
export function adminSnapshotPreview(vip:UserProfile,admin:UserProfile,date:string,runtime?:any,profileId?:string){
  const live=runtime?.date===date?runtime.profiles:undefined;
  const adminDay={...admin.dayRecords?.[date]};
  for(const type of ['ank','jodi','pannel'] as const){
    const dict=type==='ank'?'data':type==='jodi'?'jodiData':'pannelData';
    const records={...adminDay[dict]};
    const markets=type==='jodi'?getEffectiveBaseMarkets(admin.config):getEffectiveMarkets(admin.config);
    markets.forEach((_,index)=>{
      const card=live?.admin1?.cards?.[`${type}_${index}`];
      const storedCard=records[index];
      if(card && Number(storedCard?.sourceEditedAt||0)<=Number(card?.sourceEditedAt||0)){
        records[index]=card;
      }
    });
    adminDay[dict]=records;
  }
  const plan=planAdminCopySnapshot(vip,{...admin,dayRecords:{[date]:adminDay}},date);
  const liveVip=profileId?live?.[profileId]:undefined;
  plan.targets=plan.targets.filter(target=>{
    const card=liveVip?.cards?.[`${target.type}_${target.index}`];
    const market=liveVip?.markets?.find((m:any)=>m.type===target.type&&Number(m.index)===target.index);
    const targetCanonical=normalizeSnapshotMarketName(target.marketName);
    if((card?.marketName&&normalizeSnapshotMarketName(card.marketName)!==targetCanonical)||(market&&normalizeSnapshotMarketName(market.n)!==targetCanonical)){plan.nameConflict++;return false;}
    if(market?.enabled===false){plan.marketOff++;return false;}
    if(isAdminSnapshotProtected(card)){plan.settledOrSent++;return false;}
    return true;
  });
  const marketNames={ank:getEffectiveMarkets(vip.config).map(m=>normalizeSnapshotMarketName(m.n)),jodi:getEffectiveBaseMarkets(vip.config).map(m=>normalizeSnapshotMarketName(m.n))};
  return {name:vip.name,marketNames,plan};
}

/** Ignore background suggestion refreshes; stop for actual card/rate/catalog edits. */
export function adminSnapshotTargetUnchanged(current:UserProfile|undefined,captured:UserProfile,date:string,target:AdminCopySnapshotTarget):boolean {
  if(!current)return false;
  const markets=target.type==='jodi'?getEffectiveBaseMarkets(current.config):getEffectiveMarkets(current.config);
  const targetCanonical=normalizeSnapshotMarketName(target.marketName);
  if(normalizeSnapshotMarketName(markets[target.index]?.n)!==targetCanonical||!adminSnapshotMarketEnabled(current,date,target.type,target.marketName)||!vipLiveMarketEligible(current,date,target.type,target.marketName))return false;
  const dict=target.type==='ank'?'data':target.type==='jodi'?'jodiData':'pannelData';
  const old=captured.dayRecords?.[date]?.[dict]?.[target.index],now=current.dayRecords?.[date]?.[dict]?.[target.index];
  if(isAdminSnapshotProtected(now))return false;
  if(old===now)return true;
  if((old?.manualRate||now?.manualRate)&&old?.r!==now?.r)return false;
  if(old?.marketName&&now?.marketName&&normalizeSnapshotMarketName(old.marketName)!==normalizeSnapshotMarketName(now.marketName))return false;
  const fields=['s','d','sourceMode','sourceEditedAt','cardGeneration','manualRate','manualOverrideAt','trick','positionRule','mirroredFromAdmin'] as const;
  return fields.every(key=>old?.[key]===now?.[key])&&JSON.stringify(old?.scrapeSource)===JSON.stringify(now?.scrapeSource);
}
