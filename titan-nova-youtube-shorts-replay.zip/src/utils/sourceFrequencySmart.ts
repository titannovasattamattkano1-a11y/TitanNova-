import { sourceIndexWeekLength } from './sourceIndexDisplayDates';
import {selectPannaFollow} from './pannaFollow';
import {selectDigitFollow} from './digitFollow';
import {selectPairFollow,selectPairCombo,type PairDraw} from './pairFollow';
export const FREQUENCY_SOURCE_MODES=['AUTO','WEEKDAY','COMBO','DAY_COMBO','PAIR_FOLLOW','PAIR_COMBO','DIGIT_FOLLOW','PANNA_FOLLOW'] as const;
export type FrequencySourceMode=typeof FREQUENCY_SOURCE_MODES[number];
export function isFrequencySourceMode(mode: unknown): mode is FrequencySourceMode {
  return FREQUENCY_SOURCE_MODES.includes(mode as FrequencySourceMode);
}
/** Exact first-ten-unique boundary, including the repeats before completion. */
export function selectFrequencyGroupDigits(values: Iterable<string>) {
  const counts=new Map<string,{digit:string;count:number;first:number}>();
  let windowLength=0;
  for(const digit of values){
    if(!/^\d$/.test(digit))continue;
    const item=counts.get(digit)||{digit,count:0,first:windowLength};
    item.count++;counts.set(digit,item);windowLength++;
    if(counts.size===10)break;
  }
  if(!counts.size)throw new Error('Smart: source history me digits nahi mile; card unchanged');
  const ranked=[...counts.values()].sort((a,b)=>b.count-a.count||a.first-b.first);
  // At most 84 contiguous partitions for ten digits. Maximize the three
  // boundary gaps; tied choices prefer balanced sizes, then larger early groups.
  const groupCount=Math.min(4,ranked.length);
  let bestCuts:number[]=[],bestGap=-1,bestBalance=Infinity;
  const choose=(cuts:number[],last:number,remaining:number)=>{
    if(remaining){
      for(let cut=ranked.length-remaining;cut>last;cut--)choose([...cuts,cut],cut,remaining-1);
      return;
    }
    const boundaries=[0,...cuts,ranked.length];
    const gap=cuts.reduce((sum,cut)=>sum+ranked[cut-1].count-ranked[cut].count,0);
    const balance=boundaries.slice(1).reduce((sum,end,i)=>sum+(end-boundaries[i])**2,0);
    if(gap>bestGap||(gap===bestGap&&balance<bestBalance)){bestCuts=cuts;bestGap=gap;bestBalance=balance;}
  };
  choose([],0,groupCount-1);
  const names=['g1','g2','g3','g4'] as const;
  const groups:Record<typeof names[number],string[]>={g1:[],g2:[],g3:[],g4:[]};
  const boundaries=[0,...bestCuts,ranked.length];
  for(let i=0;i<groupCount;i++)groups[names[i]]=ranked.slice(boundaries[i],boundaries[i+1]).map(p=>p.digit);
  const selected:Array<{group:typeof names[number];digit:string}>=[];
  const picked=new Set<string>();
  for(const group of names){const digit=groups[group][0];if(digit!==undefined){selected.push({group,digit});picked.add(digit);}}
  return {digits:selected.map(p=>p.digit).join(', '),sourceDigits:[...counts.keys()].join(', '),windowLength,
    frequencies:Object.fromEntries([...counts].map(([d,v])=>[d,v.count])),groups,selected,eliminated:ranked.filter(p=>!picked.has(p.digit)).map(p=>p.digit)};
}
/** Retain each source's actual traversal, rather than counting its deduped list. */
export function sourceObservationWindow(draws: PairDraw[],targetDate:string,side:'open'|'close',mode:FrequencySourceMode,observationLimit?:number,observeDate?:(date:string)=>void){
  const target=new Date(`${targetDate}T00:00:00Z`);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(targetDate)||!Number.isFinite(target.getTime())||target.toISOString().slice(0,10)!==targetDate)throw new Error('Smart: invalid target date');
  if(mode==='DIGIT_FOLLOW'||mode==='PANNA_FOLLOW'){
    const values:string[]=[];
    (mode==='PANNA_FOLLOW'?selectPannaFollow:selectDigitFollow)(draws,targetDate,side,(d,date)=>{values.push(d);observeDate?.(date);},observationLimit);
    return values;
  }
  const byDate=new Map<string,string>(),conflicts=new Set<string>();
  for(const row of draws){
    if(row.date>=targetDate||!/^\d{2}$/.test(row.jodi||''))continue;
    if(!/^\d{4}-\d{2}-\d{2}$/.test(row.date))continue;
    if(byDate.has(row.date)&&byDate.get(row.date)!==row.jodi)conflicts.add(row.date);
    byDate.set(row.date,row.jodi!);
  }
  const rows=[...byDate].filter(([date])=>!conflicts.has(date)).sort(([a],[b])=>b.localeCompare(a)).map(([date,jodi])=>({date,jodi}));
  if(mode==='PAIR_FOLLOW'){
    const values:string[]=[];
    selectPairFollow(rows,targetDate,side,(d,date)=>{values.push(d);observeDate?.(date);},observationLimit);
    return values;
  }
  let ordered=rows;
  if(mode==='WEEKDAY'||mode==='DAY_COMBO'){
    const same=rows.filter(row=>new Date(`${row.date}T00:00:00Z`).getUTCDay()===target.getUTCDay()).slice(0,observationLimit===undefined?60:observationLimit);
    const dates=new Set(same.map(row=>row.date));
    ordered=observationLimit===undefined?[...same,...rows.filter(row=>!dates.has(row.date))]:same;
  }
  const combo=mode==='COMBO'||mode==='DAY_COMBO';
  function* stream(){for(const row of ordered)for(const digit of combo?[row.jodi[1],row.jodi[0]]:[row.jodi[side==='open'?0:1]])yield {digit,date:row.date};}
  const values:string[]=[],unique=new Set<string>();
  for(const {digit,date} of stream()){
    observeDate?.(date);
    values.push(digit);unique.add(digit);
    if(observationLimit===undefined?unique.size===10:values.length>=observationLimit)break;
  }
  return values;
}

export function sourceFrequencyWindow(draws:PairDraw[],targetDate:string,side:'open'|'close',mode:FrequencySourceMode){
  return selectFrequencyGroupDigits(sourceObservationWindow(draws,targetDate,side,mode));
}

/**
 * 10-Draw Frequency (Skip Most Recent Draw):
 * - Skips index 0 (the most recent draw).
 * - Takes strictly the next 10 draws (indices 1..10).
 * - Counts frequency of each digit inside that 10-draw window only.
 * - Ranks digits by highest frequency descending, then earliest position in the 10-draw window.
 * - Suggests top highest-frequency digits (up to maxSuggest = 6) for the digit box.
 */
export function selectTenDrawSkipRecentFrequency(values: Iterable<string>, maxSuggest = 6) {
  const allDigits: string[] = [];
  for (const val of values) {
    const d = String(val ?? '').trim();
    if (/^\d$/.test(d)) {
      allDigits.push(d);
      if (allDigits.length >= 11) break; // 1 skipped + 10 window draws
    }
  }
  if (allDigits.length < 2) {
    throw new Error('10-Draw Freq: recent draw chhod kar history me draws nahi mile; card unchanged');
  }
  const skippedRecent = allDigits[0];
  const windowDraws = allDigits.slice(1, 11);
  const counts = new Map<string, { digit: string; count: number; first: number }>();
  windowDraws.forEach((digit, idx) => {
    const existing = counts.get(digit) || { digit, count: 0, first: idx };
    existing.count += 1;
    counts.set(digit, existing);
  });
  const ranked = [...counts.values()].sort((a, b) => b.count - a.count || a.first - b.first);
  const suggested = ranked.slice(0, Math.max(1, Math.min(6, maxSuggest))).map((item) => item.digit);
  const rankedDigits = ranked.map((item) => item.digit);
  const strongDigits = suggested.slice(0, 2);
  const supportDigits = suggested.slice(2);
  return {
    digits: suggested.join(', '),
    rankedDigits: rankedDigits.join(', '),
    skippedRecent,
    windowLength: windowDraws.length,
    windowDraws,
    frequencies: Object.fromEntries(ranked.map((item) => [item.digit, item.count])),
    strongDigits,
    supportDigits,
  };
}

/**
 * 10-Day Open+Close Combined Frequency (Skip Most Recent Day):
 * - Input `jodis` is newest-first 2-digit Jodi strings (each Jodi = 1 day's Open + Close).
 * - Skips index 0 (the most recent day's draw).
 * - Takes strictly the next 10 days (indices 1..10, i.e. up to 10 Jodis = 20 Open+Close digits).
 * - Counts frequency of each digit across both OPEN and CLOSE together in that 10-day window.
 * - Ranks digits by highest frequency descending, then earliest appearance in the 10-day window.
 * - Suggests top highest-frequency digits (up to maxSuggest = 6) for the digit box.
 */
export function selectTenDayComboSkipRecentFrequency(jodis: Iterable<string>, maxSuggest = 6, marketName?: string) {
  const targetDays = marketName ? sourceIndexWeekLength(marketName) : 10;
  const validJodis: string[] = [];
  for (const raw of jodis) {
    const j = String(raw ?? '').trim();
    if (/^\d{2}$/.test(j)) {
      validJodis.push(j);
      if (validJodis.length >= 1 + targetDays) break; // 1 skipped day + market weekDays window (7, 6, or 5 days)
    }
  }
  if (validJodis.length < 2) {
    throw new Error(`${targetDays}-Day Combo Freq: recent din chhod kar history me draws nahi mile; card unchanged`);
  }
  const skippedRecentJodi = validJodis[0];
  const windowJodis = validJodis.slice(1, 1 + targetDays);
  // In recent-to-old order within each day, CLOSE (j[1]) then OPEN (j[0])
  const windowDigits = windowJodis.flatMap((j) => [j[1], j[0]]);
  const counts = new Map<string, { digit: string; count: number; first: number }>();
  windowDigits.forEach((digit, idx) => {
    const existing = counts.get(digit) || { digit, count: 0, first: idx };
    existing.count += 1;
    counts.set(digit, existing);
  });
  const ranked = [...counts.values()].sort((a, b) => b.count - a.count || a.first - b.first);
  const suggested = ranked.slice(0, Math.max(1, Math.min(6, maxSuggest))).map((item) => item.digit);
  const rankedDigits = ranked.map((item) => item.digit);
  const strongDigits = suggested.slice(0, 2);
  const supportDigits = suggested.slice(2);
  return {
    digits: suggested.join(', '),
    rankedDigits: rankedDigits.join(', '),
    skippedRecentJodi,
    windowDays: windowJodis.length,
    windowLength: windowDigits.length,
    windowJodis,
    frequencies: Object.fromEntries(ranked.map((item) => [item.digit, item.count])),
    strongDigits,
    supportDigits,
  };
}
