import { areSettlementTokensValid, calculateSettlement, normalizeSettlementTokens } from './settlement';
import {recoveryMarketOrder} from './recoveryMarketOrder';

/** JODI recovery advances on the published OPEN ank, not on the later full pair. */
export function jodiOpenSideStatus(
  digits: unknown,
  openAnk: unknown,
): 'PASS' | 'FAIL' | null {
  const winningOpen = String(openAnk ?? '').trim();
  if (!/^\d$/.test(winningOpen)) return null;
  if (!areSettlementTokensValid('jodi', digits)) return null;
  const pairs = normalizeSettlementTokens('jodi', digits);
  if (pairs.length === 0) return null;
  return pairs.some((pair) => pair[0] === winningOpen) ? 'PASS' : 'FAIL';
}

/** Recreate a recovery track from settled bets, independent of WAIT suggestions. */
export function rebuildSettledTrackState(
  type: string,
  markets: Array<{ type?: string; index?: number; n?: string }>,
  cards: Record<string, any>,
  trackKey: string,
  resolveTrackKey: (marketName: string) => string,
  beforeIndex = Infinity,
  resetAfterThreeFails = false,
  initialDebt = 0,
  initialConsecutiveFails = 0,
  isSmartStake = false,
  initialPendingProfit = 0,
  targetGetter?: (marketName: string, card: any) => number,
  isOpenPassCloseZero = false,
) {
  let debt = Math.max(0, Number(initialDebt) || 0);
  let consecutiveFails = Math.max(0, Number(initialConsecutiveFails) || 0), cyclesClosed=0, lastResetCardKey:string|undefined, lastResetDebt=0;
  let pendingProfit = isSmartStake ? Math.max(0, Number(initialPendingProfit) || 0) : 0;
  let fromIndex = -1;
  let fromCardKey: string | undefined;
  const selected = markets
    .filter((market) => String(market.type) === type && Number(market.index) < beforeIndex &&
      resolveTrackKey(String(market.n || '')) === trackKey)
    .sort((a, b) => Number(a.index) - Number(b.index));
  for (const market of recoveryMarketOrder(selected)) {
    const index = Number(market.index);
    const key = `${type}_${index}`;
    const card = cards[key];
    // Once an OPEN-side JODI outcome exists it remains the recovery truth.
    // The later full-pair result still owns ledger P/L, but must not charge the
    // same JODI stake a second time or reset an already-sent next-card rate.
    const effectiveStatus = type === 'jodi' && (card?.jodiOpenStatus === 'PASS' || card?.jodiOpenStatus === 'FAIL')
      ? card.jodiOpenStatus
      : card?.s;
    if (effectiveStatus !== 'PASS' && effectiveStatus !== 'FAIL') continue;

    const isGenuineManual = Boolean(card?.manualRate && !card?.manualStatus && Number(card?.r) > 0);
    const mName = String(market.n || '');
    const isClose = (type === 'ank' || type === 'pannel') && /\s+CLOSE$/i.test(mName);
    let isOpenPass = false;
    if (isOpenPassCloseZero && isClose) {
      const bMarket = mName.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
      const openName = `${bMarket} OPEN`;
      const openMkt = markets.find((m) => String(m.type) === type && String(m.n || '').trim().toUpperCase() === openName);
      const openCard = (openMkt ? cards[`${type}_${openMkt.index}`] : undefined) || Object.values(cards || {}).find((c: any) => String(c?.marketName || '').trim().toUpperCase() === openName);
      isOpenPass = openCard?.s === 'PASS';
    }
    if (isOpenPass && !isGenuineManual) {
      if (effectiveStatus === 'FAIL') {
        if (isSmartStake && targetGetter) {
          pendingProfit += targetGetter(mName, card);
        }
      } else if (effectiveStatus === 'PASS') {
        pendingProfit = 0;
      }
      fromIndex = index;
      fromCardKey = key;
      continue;
    }

    const settled = calculateSettlement({
      type, digits: card.sentDigits || card.d, rate: card.r,
      sentRate: card.sentRate, sentInvest: card.sentInvest,
      smartStaking: card.smartStaking,
    });
    if (settled.tokenCount <= 0 || settled.rate <= 0 || settled.invest <= 0) continue;
    if (effectiveStatus === 'FAIL') {
      debt += settled.invest;
      if (isSmartStake && targetGetter) {
        pendingProfit += targetGetter(String(market.n || ''), card);
      }
      if (resetAfterThreeFails) {
        consecutiveFails += 1;
        if (consecutiveFails === 3) {
          lastResetDebt = debt;
          lastResetCardKey = key;
          cyclesClosed++;
          debt = 0;
          pendingProfit = 0;
          consecutiveFails = 0;
        }
      }
    } else if (effectiveStatus === 'PASS') {
      debt = 0;
      pendingProfit = 0;
      consecutiveFails = 0;
    }
    fromIndex = index;
    fromCardKey = key;
  }
  return { debt, pendingProfit, fromIndex, fromCardKey, ...(resetAfterThreeFails?{consecutiveFails,cyclesClosed,lastResetCardKey,lastResetDebt}:{}) };
}
