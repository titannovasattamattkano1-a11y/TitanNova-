/**
 * A profile list is destructive/authoritative only when it comes from the
 * complete master state. Scoped VIP pages never contain admin1 and must be
 * treated as partial merge inputs.
 */
export function authoritativeProfileIds(value: unknown): string[] | null {
  if (!Array.isArray(value)) return null;
  const ids = [...new Set(value.map((id) => String(id || '').trim()).filter(Boolean))];
  return ids.includes('admin1') ? ids : null;
}

