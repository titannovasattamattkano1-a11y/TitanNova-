/** A market selection includes both OPEN/CLOSE sides and its JODI base. */
export const backtestMarketBase=(name:string)=>name.trim().toUpperCase().replace(/\s+(OPEN|CLOSE)$/i,'').trim();
export const backtestMarketSelected=(name:string,selected?:string[])=>selected===undefined||selected.includes(backtestMarketBase(name));
