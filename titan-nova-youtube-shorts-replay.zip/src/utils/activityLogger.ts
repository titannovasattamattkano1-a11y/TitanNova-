import { apiUrl } from './api';

export type ClientActivityAction =
  | 'DIGITS_APPLIED'
  | 'RATE_LOCKED'
  | 'CARD_SENT'
  | 'RESULT_SETTLED'
  | 'PROFIT_MILESTONE';

export interface ClientActivityPayload {
  date: string;
  profileId: string;
  market: string;
  type: 'ank' | 'jodi' | 'pannel' | 'system';
  action: ClientActivityAction;
  digits?: string;
  rate?: string;
  invest?: number;
  status?: 'WAIT' | 'PASS' | 'FAIL' | 'SKIP' | 'SENT';
  actual?: string;
  pl?: number;
  netDayPl?: number;
  trick?: string;
  sourceMode?: string;
  subtitle: string;
}

/** Fire-and-forget main activity logger; never blocks UI or throws. */
export function recordMainActivity(payload: ClientActivityPayload): void {
  try {
    void fetch(apiUrl('/api/app/activity_log'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }).catch(() => {});
  } catch {
    // Non-critical background timeline log
  }
}
