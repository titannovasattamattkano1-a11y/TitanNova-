/** Delivery reversal is server-owned; transport receipts remain historical facts. */
export const DELIVERY_FIELDS = ['sentRate','sentInvest','sentDigits','sentSourceMode','sentTrick','sentScrapeSource','sentTargets','sentLoopId','dispatchState','dispatchKey','queuedAt','sentAt','settledAt','jodiOpenStatus','jodiOpenResult','jodiOpenSettledAt'] as const;
export function clearRestoredDelivery(record: any) {
  if (record?.deliveryRestoredAt && record.s !== 'PASS' && record.s !== 'FAIL') for (const field of DELIVERY_FIELDS) delete record[field];
  return record;
}
export function reconcileCardRestore(incoming: any, current: any): any {
  if (current?.cardGeneration && Number(incoming?.cardGeneration || 0) !== Number(current.cardGeneration)) return { ...current };
  if (!incoming || !current?.deliveryRestoredAt) return incoming;
  const result = { ...incoming, s: current.s, deliveryRestoredAt: current.deliveryRestoredAt,
    manualStatus: current.manualStatus, manualOverrideAt: current.manualOverrideAt };
  clearRestoredDelivery(result);
  return result;
}
