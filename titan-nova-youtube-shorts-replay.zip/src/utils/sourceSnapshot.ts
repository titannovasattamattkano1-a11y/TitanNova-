import type { DayMarketRecord } from '../types';
import { modelSourceVersion } from './marketModelCard';

// Missing metadata in a revisioned source is intentional (Clear/manual edit),
// not a request to keep the previous scrape/trick metadata.
// Keep source-owned fields together. Backend status/rate/dispatch information is
// independently authoritative, but an older ledger reply may NEVER substitute
// old AUTO digits, source provenance or cut overlays for a newer COMBO scrape.
const sourceOwnedFields = ['d', 'od', 'sourceMode', 'sourceEditedAt', 'scrapeSource',
  'trick', 'positionRule', 'weekdaySelectedDigits', 'weekdayHitPosition',
  'firstDigitMirrorCut', 'triCut', 'sniperOne', 'mssdState', 'masterFlow', 'marketModel', 'strictPanel30', 'smartSelection',
  'liveCombinedCut', 'autoResultParity', 'autoRemovedResult', 'openCloseCut',
  'carryResultSix', 'mirroredFromAdmin'] as const;

export function applySourceSnapshot(target: Partial<DayMarketRecord>, source: Partial<DayMarketRecord>, local: Partial<DayMarketRecord>): void {
  if (!source.sourceEditedAt || modelSourceVersion(source) < modelSourceVersion(local)) {
    // The target may already contain old source fields from a ledger overlay.
    // Restore the locally newer source atomically (including deleted overlays).
    if (modelSourceVersion(local) > modelSourceVersion(source)) {
      for (const key of sourceOwnedFields) {
        if (local[key] === undefined) delete target[key];
        else (target as any)[key] = local[key];
      }
    }
    return;
  }
  if (source.cardGeneration && Number(source.cardGeneration) >= Number(local.cardGeneration || 0)) {
    for (const key of [...Object.keys(target)]) if ((source as any)[key] === undefined && /^(sent|dispatch|delivery|manual|settled|queued|backtest|rateFinalized|recRate|prevLoss|targetProfitWithLoss)/.test(key)) delete (target as any)[key];
    target.cardGeneration = source.cardGeneration;
    if (Number(source.cardGeneration) > Number(local.cardGeneration || 0)) { target.s = source.s; target.r = source.r; }
  }
  for (const key of sourceOwnedFields) {
    if (source[key] === undefined) delete target[key];
    else (target as any)[key] = source[key];
  }
  if (source.d === '' && source.sourceMode === 'MANUAL' && !source.sentRate && !source.sentDigits && !source.manualStatus) {
    delete target.manualStatus;
    delete target.manualOverrideAt;
    delete target.backtestResult;
    delete target.manualResult;
    delete target.manualResultSources;
    if (!source.manualRate) delete target.manualRate;
  }
}
