import type { DayMarketRecord } from '../types';
import type { MarketBehaviorPrediction } from './marketBehavior';
import { normalizeScrapeSource } from './scrapeProvenance';
export interface MarketModelSummary {
  engine: 'market_behavior_dynamic_v2'; decision: 'RETAIN' | 'SKIP'; reason: string;
  windows: number[]; patternShift: boolean; pastHitPercent: number;
  pastTrials: number; coveragePercent: number; updatedAt: number;
}
export function summarizeMarketModel(model: MarketBehaviorPrediction): MarketModelSummary {
  return { engine: model.engine, decision: model.decision, reason: model.reason,
    windows: [...model.selectedWindows], patternShift: model.patternShift,
    pastHitPercent: model.evaluation.hitPercent, pastTrials: model.evaluation.samples,
    coveragePercent: model.policyEvaluation.coveragePercent, updatedAt: Date.now() };
}
/** A SKIP is an explicit no-bet decision, never a manual PASS/FAIL or a delivered edit. */
export function applyMarketModelSummary(record: DayMarketRecord, summary: MarketModelSummary, sourceDigits?: string): void {
  if (record.sentRate || record.sentDigits || record.dispatchState === 'SENT' || record.dispatchState === 'SETTLED') return;
  record.marketModel = { ...summary, windows: [...summary.windows] };
  record.sourceMode = 'MARKET_MODEL';
  record.scrapeSource = normalizeScrapeSource({ mode: 'MARKET_MODEL', digits: sourceDigits });
  record.s = summary.decision === 'SKIP' ? 'SKIP' : 'WAIT';
  if (summary.decision === 'SKIP') record.d = '';
  delete record.manualStatus; delete record.manualResult; delete record.manualResultSources;
  delete record.backtestResult; delete record.scrapeResultDigit;
  delete record.dispatchState; delete record.dispatchKey; delete record.queuedAt;
}
export const isEditableModelSkip = (rec: Partial<DayMarketRecord> | undefined): boolean => Boolean(
  rec?.s === 'SKIP' && rec?.marketModel?.decision === 'SKIP' && !rec.manualStatus &&
  !rec.sentRate && !rec.sentDigits && rec.dispatchState !== 'SENT' && rec.dispatchState !== 'SETTLED'
);

export function marketModelReasonLabel(reason: string): string {
  return ({ insufficient_past_trials: 'More past trials needed', baseline_advantage_unproven: 'Past advantage unproven',
    recent_performance_weak: 'Recent performance weak', digit_ranking_uncertain: 'Digit confidence low',
    past_evidence_supports_selection: 'Past evidence supports selection' } as Record<string, string>)[reason] || 'Evidence check';
}

export const modelSourceVersion = (rec: Partial<DayMarketRecord> | undefined): number =>
  Math.max(Number(rec?.sourceEditedAt || 0), Number(rec?.marketModel?.updatedAt || 0));
export function isStaleModelSnapshot(local: Partial<DayMarketRecord>, remote: Partial<DayMarketRecord>): boolean {
  if (Number(local?.cardGeneration || 0) > Number(remote?.cardGeneration || 0)) return true;
  return Boolean((local.sourceEditedAt || remote.sourceEditedAt || local.marketModel || remote.marketModel || local.strictPanel30 || remote.strictPanel30) && modelSourceVersion(local) > modelSourceVersion(remote) &&
    !remote.sentRate && !remote.sentDigits && remote.s !== 'PASS' && remote.s !== 'FAIL' &&
    (!remote.manualStatus || Number(remote.manualOverrideAt || 0) <= modelSourceVersion(local)));
}

/** Unsent prediction-policy SKIPs may be replaced by a fresh source selection. */
export const isEditableSourceSkip = (rec: Partial<DayMarketRecord> | undefined): boolean =>
  Boolean(rec?.s==='SKIP'&&rec.liveCombinedCut?.reason&&!rec.manualStatus&&!rec.sentRate&&!rec.sentDigits&&!rec.dispatchState) || isEditableModelSkip(rec) || Boolean(rec?.s === 'SKIP' && rec.sourceMode === 'SP_SKIP30' && rec.strictPanel30?.decision === 'SKIP' && !rec.manualStatus && !rec.sentRate && !rec.sentDigits && !rec.dispatchState);
