import { normalizeProviderChartHtml } from './normalizeProviderChartHtml';
import { chartSingleDate, chartWeekDates, smartDateRange, type DatedJodi } from './smartWeekday';

/** Read only two-digit jodi cells; panna values never become ANK candidates. */
export function parseSmartJodiChart(html: string, today: string, recoverIsolatedYearTypos = false) {
  const normalizedHtml = normalizeProviderChartHtml(html);
  const table = normalizedHtml.match(/<table\b[^>]*class=["'][^"']*\bpchart\b[^"']*["'][^>]*>[\s\S]*?<\/table>/i)?.[0] || normalizedHtml;
  const cells = (source: string) => [...source.matchAll(/<t[dh]\b[^>]*>([\s\S]*?)<\/t[dh]>/gi)].map(m =>
    m[1].replace(/<[^>]+>/g, ' ').replace(/&nbsp;|&#160;/gi, ' ').replace(/\s+/g, ' ').trim());
  const all = cells(table);
  const anchors = all.flatMap((cell, index) => smartDateRange(cell) ? [index] : []);
  const header = anchors.length ? all.slice(0, anchors[0]).join(' ').toUpperCase() : '';
  const explicitMondayColumns = /\bMON\b/.test(header) && /\bTUE\b/.test(header);
  const startDays = anchors.flatMap((anchor, index) => {
    const slots = Math.floor(((anchors[index + 1] ?? all.length) - anchor - 1) / 3);
    const date = chartWeekDates(all[anchor], slots)[0];
    return date && date <= today ? [new Date(`${date}T00:00:00Z`).getUTCDay()] : [];
  });
  const predominantlyMonday = startDays.length >= 20 && startDays.filter(day => day === 1).length / startDays.length >= 0.95;
  const mondayColumns = explicitMondayColumns || predominantlyMonday;
  const jodis: string[] = [];
  const draws: DatedJodi[] = [];
  let skippedDateRows = 0;
  let recoveredDateRows = 0;
  let duplicateRows = 0;
  let latestDate = '';
  const seenRows = new Set<string>();
  const pair = (text: string) => /^\d{2}$/.test(text.replace(/\s/g, '')) ? text.replace(/\s/g, '') : null;
  const addRow = (label: string, values: string[], dates: string[], weekdayStart?: number) => {
    const signature = JSON.stringify([label, values]);
    if (seenRows.has(signature)) { duplicateRows++; return; }
    seenRows.add(signature);
    // A bad historical label must not invalidate the remaining chart. Do not
    // invent a corrected year/day or count an overlapping week twice by date.
    const trustworthy = dates.length === values.length && (!latestDate || dates[0] > latestDate) && dates[0] <= today;
    if (!trustworthy) skippedDateRows++;
    values.forEach((value, index) => {
      const jodi = pair(value);
      if (!jodi) return; // ** and partial results such as 1* are not jodis.
      const order = jodis.length;
      jodis.push(jodi);
      const date = trustworthy && dates[index] <= today ? dates[index] : '';
      const weekday = weekdayStart === undefined ? (date ? new Date(`${date}T00:00:00Z`).getUTCDay() : undefined) : (weekdayStart + index) % 7;
      if (date || weekday !== undefined) draws.push({ date, jodi, order, weekday });
    });
    if (trustworthy) latestDate = dates.filter(date => date <= today).at(-1) || latestDate;
  };
  if (anchors.length) {
    const shift = (date: string, days: number) => new Date(Date.parse(`${date}T00:00:00Z`) + days * 86400000).toISOString().slice(0, 10);
    const rowDates = anchors.map((anchor, index) =>
      chartWeekDates(all[anchor], Math.floor(((anchors[index + 1] ?? all.length) - anchor - 1) / 3)));
    for (let index = 0; index < anchors.length; index++) {
      const label = all[anchors[index]];
      const row = all.slice(anchors[index] + 1, anchors[index + 1] ?? all.length);
      const slots = Math.floor(row.length / 3);
      if (slots < 1 || slots > 7) { skippedDateRows++; continue; }
      let dates = rowDates[index];
      const previous = rowDates[index - 1];
      const next = rowDates[index + 1];
      // Recover one isolated wrong-year label only when both neighboring weeks
      // independently agree on every date. Other ambiguous rows stay excluded.
      if (recoverIsolatedYearTypos && dates.length === slots && previous?.length === slots && next?.length === slots &&
          dates[0] !== shift(previous[0], 7) &&
          shift(previous[0], 14) === next[0] &&
          dates.every((date, i) => date.slice(5) === shift(previous[0], 7 + i).slice(5))) {
        dates = dates.map((_, i) => shift(previous[0], 7 + i));
        recoveredDateRows++;
      }
      addRow(label, Array.from({ length: slots }, (_, i) => row[i * 3 + 1]), dates, mondayColumns ? 1 : undefined);
    }
  } else {
    for (const row of table.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)) {
      const rowCells = cells(row[1]);
      if (rowCells.length !== 4) continue;
      const date = chartSingleDate(rowCells[0]);
      addRow(rowCells[0], [rowCells[2]], date ? [date] : []);
    }
  }
  return { jodis, draws, skippedDateRows, recoveredDateRows, duplicateRows };
}
