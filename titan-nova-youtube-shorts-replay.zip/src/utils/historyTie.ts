import type {UserProfile,CardSourceMode} from '../types';
import {panelAnkDigit} from './panelAnk';
import {findHistoricalMarketRecord} from './cardHistory';
import {getFullScrapeSource as getScrapeSource,getScrapeResultIndex} from './scrapeProvenance';
import {actualForGame,evaluateBacktest,type DatedActual} from './backtestResult';
import {supportsMarketHistorySource,type MarketHistoryMode,type MarketHistorySource} from './marketHistoryLogic';
export const TIE_HISTORY_START='0000-01-01'; // All canonical chart dates, not a rolling calendar window.
export interface TieTrial{date:string;keep:boolean;remove:boolean}
export interface TieChoice{mode?:MarketHistoryMode;tieDate?:string;tieSamples:number;samples:number;keepHits:number;removeHits:number;keepPercent:number;removePercent:number;excludedDates:string[];reason?:string}
const validDate=(date:string)=>/^\d{4}-\d{2}-\d{2}$/.test(date)&&Number.isFinite(Date.parse(date))&&new Date(date).toISOString().slice(0,10)===date;
export function breakHistoryTie(trials:TieTrial[]):TieChoice{
 let keepHits=0,removeHits=0,tieSamples=0;let tieDate:string|undefined;
 for(const [index,trial] of trials.entries()){
  keepHits+=Number(trial.keep);removeHits+=Number(trial.remove);
  if(!tieSamples&&keepHits===removeHits){tieSamples=index+1;tieDate=trial.date;}
  // Keep the entire prefix; add older comparisons until the first post-tie winner.
  if(tieSamples&&keepHits!==removeHits){const samples=index+1;return {tieDate,tieSamples,samples,keepHits,removeHits,keepPercent:100*keepHits/samples,removePercent:100*removeHits/samples,excludedDates:[],mode:keepHits>removeHits?'keep6':'remove4'};}
 }
 return {tieDate,tieSamples,samples:trials.length,keepHits,removeHits,keepPercent:trials.length?100*keepHits/trials.length:0,removePercent:trials.length?100*removeHits/trials.length:0,excludedDates:[],reason:trials.length===0?'No valid comparable same-source results in available history':'Available history exhausted without a post-tie winner; card unchanged'};
}

export function tieHistoryFingerprint(days:UserProfile['dayRecords'],date:string,index:number,market:string){
 return JSON.stringify(Object.keys(days||{}).filter(d=>validDate(d)&&d<date).sort().flatMap(d=>{const rec=findHistoricalMarketRecord(days[d]?.data,index,market);if(!rec)return [];const source=getScrapeSource(rec);return [[d,rec.s,source?.mode,source?.digits,getScrapeResultIndex(rec)]];}));
}
interface Reply{status:string;market?:string;gameType?:string;sourceMode?:CardSourceMode;targetDate?:string;historyDates?:string[];historyBatchSize?:number;historyRelease?:boolean;historyReplies?:Reply[];staleCache?:boolean;code?:string;message?:string;sourceDigits?:Partial<Record<CardSourceMode,string>>;actual?:DatedActual|null}
export async function prepareTieHistory(options:{days:UserProfile['dayRecords'];date:string;index:number;market:string;mode:MarketHistorySource;isCurrent:()=>boolean;scrape:(body:Record<string,unknown>)=>Promise<Reply>;progress?:(scanned:number,total:number,comparisons:number)=>void;release?:()=>Promise<unknown>}){
 const {days,date,index,market,mode}=options,seed:UserProfile['dayRecords']={};
 if(!validDate(date)||!supportsMarketHistorySource(market,mode))throw Error('Valid date and supported original source required');
 const check=()=>{if(!options.isCurrent())throw Error('History Tie cancelled or card changed');};
 const base={market,type:'ank',backtest:true,historyTie:true,isCombo:mode==='COMBO'||mode==='DAY_COMBO',selectionMode:mode==='DAY_COMBO'?'same_weekday_vertical_combo':mode==='WEEKDAY'?'same_weekday_vertical':'pre_target_recent'};
 const identity=(reply:Reply)=>{
  const normalize=(value:string)=>String(value).trim().replace(/\s+/g,' ').toUpperCase();
  if(reply.market!==undefined&&(typeof reply.market!=='string'||normalize(reply.market)!==normalize(market)))throw Error('Historical source returned a different market/side');
  if(reply.gameType!==undefined&&reply.gameType!=='ank')throw Error('Historical source returned a different game');
  if(reply.sourceMode!==undefined&&reply.sourceMode!==mode)throw Error('Historical source returned a different source mode');
 };
 const yesterday=new Date(Date.parse(date)-86400000).toISOString().slice(0,10);
 check();const catalog=await options.scrape({...base,targetDate:yesterday,historyDatesOnly:true});
 try{
 check();
 if(catalog.status!=='success'||catalog.staleCache||catalog.targetDate!==yesterday||!Array.isArray(catalog.historyDates))throw Error(catalog.message||'Fresh chart date catalog unavailable');
 identity(catalog);
 if(catalog.historyDates.some(d=>typeof d!=='string'||!validDate(d)||d>=date))throw Error('Chart returned invalid or future history dates');
 const chartDates=new Set(catalog.historyDates);
 const dates=[...new Set([...chartDates,...Object.keys(days||{}).filter(d=>validDate(d)&&d<date&&getScrapeSource(findHistoricalMarketRecord(days[d]?.data,index,market))?.mode===mode)])].sort().reverse();
 const pending:Array<{date:string;actual:number;earlier:number[];trial?:TieTrial}>=[],trials:TieTrial[]=[];
 const buffered=new Map<string,Reply>();
 let useBatch=catalog.historyBatchSize===8;
 let keepTotal=0,removeTotal=0,tieSeen=false;
 let emitted=0,scanned=0;options.progress?.(0,dates.length,0);
 for(const [dateIndex,day] of dates.entries()){
  check();let rec=findHistoricalMarketRecord(days[day]?.data,index,market);
  // A saved same-source record owns its date, even WAIT/manual/restore records.
  if(getScrapeSource(rec)?.mode!==mode){
   if(useBatch&&!buffered.has(day)){
    const requested=dates.slice(dateIndex,dateIndex+8).filter(d=>getScrapeSource(findHistoricalMarketRecord(days[d]?.data,index,market))?.mode!==mode);
    try{
     const batch=await options.scrape({...base,targetDate:day,historyTieDates:requested});check();identity(batch);
     if(batch.status!=='success'||batch.staleCache||batch.targetDate!==day||!Array.isArray(batch.historyReplies)||batch.historyReplies.length!==requested.length||batch.historyReplies.some((r,i)=>r?.targetDate!==requested[i]))throw Error(batch.message||'Exact historical batch unavailable');
     batch.historyReplies.forEach(r=>buffered.set(r.targetDate!,r));
    }catch{
     check();useBatch=false;buffered.clear();
     // Retry only transport format, on this exact frozen run; never refetch a chart.
    }
   }
   const response=buffered.get(day)??await options.scrape({...base,targetDate:day});buffered.delete(day);check();
   identity(response);
   if(response.targetDate!==day)throw Error('Historical source returned a different date');
   if(response.staleCache)throw Error('Fresh chart required; stale history was not applied');
   if(response.status!=='success'){
    if(response.code==='HISTORY_SOURCE_INCOMPLETE'||response.code==='HISTORY_NO_PRIOR_DATA')rec=undefined;
    else throw Error(response.message||'Historical source unavailable');
   }else{
    const digits=response.sourceDigits?.[mode];
    rec={s:'WAIT',d:String(digits||''),r:'',marketName:market,sourceMode:mode,scrapeSource:{mode,digits:String(digits||'')}};
    if(!getScrapeSource(rec))throw Error('Original ten-digit source provenance missing');
    const actual=response.actual;
    if(!actual||actual.date!==day||Object.entries(actual).some(([key,value])=>key!=='date'&&value!==undefined&&!new RegExp(key==='jodi'?'^\\d{2}$':'^\\d{3}$').test(String(value))))throw Error('Exact dated actual required');
    if(actual.jodi&&((actual.open&&panelAnkDigit(actual.open)!==actual.jodi[0])||(actual.close&&panelAnkDigit(actual.close)!==actual.jodi[1])))throw Error('Conflicting Jodi/Patti actual; card unchanged');
    const digit=actualForGame(actual,'ank',market);if(digit===undefined)throw Error('Historical market side actual is missing');
    rec=evaluateBacktest(rec,'ank',digit);seed[day]={data:{[index]:rec}};
   }
  }
  scanned++;
  const position=(rec?.s==='PASS'||rec?.s==='FAIL')&&getScrapeSource(rec)?.mode===mode?getScrapeResultIndex(rec):undefined;
  if(position!==undefined){
   for(let i=emitted;i<pending.length;i++){
    const prior=pending[i];if(prior.trial||prior.earlier.includes(position))continue;
    prior.earlier.push(position);
    if(prior.earlier.length===6)prior.trial={date:prior.date,keep:prior.earlier.includes(prior.actual),remove:!prior.earlier.slice(0,4).includes(prior.actual)};
   }
   while(emitted<pending.length&&pending[emitted].trial){
    trials.push(pending[emitted++].trial!);
    const trial=trials[trials.length-1];keepTotal+=Number(trial.keep);removeTotal+=Number(trial.remove);
    if(keepTotal===removeTotal){tieSeen=true;continue;}
    if(!tieSeen)continue;
    const choice=breakHistoryTie(trials);
    if(choice.mode){check();options.progress?.(scanned,dates.length,trials.length);return {seed,choice,scanned,total:dates.length};}
   }
   pending.push({date:day,actual:position,earlier:[]});
  }
  if(scanned%8===0||scanned===dates.length)options.progress?.(scanned,dates.length,trials.length);
  // Saved-only long archives must still yield to Cancel and UI events.
  if(scanned%32===0)await new Promise(resolve=>setTimeout(resolve,0));
 }
 check();return {seed,choice:breakHistoryTie(trials),scanned,total:dates.length};
 }finally{if(catalog.historyRelease===true&&options.release)void Promise.resolve().then(options.release).catch(()=>{});}
}
