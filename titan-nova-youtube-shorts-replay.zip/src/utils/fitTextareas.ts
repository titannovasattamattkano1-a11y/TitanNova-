/** Batch textarea measurements so a ledger mount performs one layout pass. */
const pending = new Set<HTMLTextAreaElement>();
const widths = new WeakMap<HTMLTextAreaElement, number>();
let frame = 0;
const observed = new WeakSet<HTMLTextAreaElement>();
const visible = new WeakSet<HTMLTextAreaElement>();
let visibilityObserver: IntersectionObserver | undefined;

/** Do not force offscreen cards to lay out just to size their textboxes. */
export function observeTextareaFit(box: HTMLTextAreaElement): void {
  if (typeof IntersectionObserver === 'undefined') return;
  visibilityObserver ??= new IntersectionObserver(entries => {
    for (const entry of entries) {
      const element = entry.target as HTMLTextAreaElement;
      if (!observed.has(element)) continue;
      if (entry.isIntersecting) { visible.add(element); scheduleTextareaFit(element); }
      else { visible.delete(element); pending.delete(element); }
    }
  }, { rootMargin: '600px' });
  observed.add(box);
  visibilityObserver.observe(box);
}

export function scheduleTextareaFit(box: HTMLTextAreaElement): void {
  if (observed.has(box) && !visible.has(box)) return;
  pending.add(box);
  if (frame) return;
  frame = requestAnimationFrame(() => {
    frame = 0;
    const boxes = [...pending].filter(element => element.isConnected);
    pending.clear();
    for (const element of boxes) element.style.height = 'auto';
    const sizes = boxes.map(element => ({ height: Math.max(parseFloat(getComputedStyle(element).minHeight) || 42, element.scrollHeight + 2), width: element.clientWidth }));
    boxes.forEach((element, index) => {
      widths.set(element, sizes[index].width);
      element.style.height = `${sizes[index].height}px`;
    });
  });
}

export function textareaWidthChanged(box: HTMLTextAreaElement): boolean {
  if (observed.has(box) && !visible.has(box)) return false;
  return widths.get(box) !== box.clientWidth;
}

export function cancelTextareaFit(box: HTMLTextAreaElement): void {
  pending.delete(box);
  visibilityObserver?.unobserve(box);
  observed.delete(box);
  visible.delete(box);
}
