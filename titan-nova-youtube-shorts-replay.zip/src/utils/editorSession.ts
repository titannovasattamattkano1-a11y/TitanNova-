// Per-document identity: duplicated tabs cannot inherit another tab's writer lease.
const newEditorId = () => Array.from(crypto.getRandomValues(new Uint8Array(18)), byte => byte.toString(16).padStart(2, '0')).join('');
export let editorId = newEditorId();
/** Retire the old identity before hydrating a replacement writer. */
export function rotateEditorId(): void { editorId = newEditorId(); }
