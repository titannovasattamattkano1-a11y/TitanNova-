import type { DayMarketRecord,CardSourceMode } from '../types';
import {adminCardIntent} from './adminConflictMerge';
/** A simulated check owns an outcome, not the source/delivery lock. */
export function hasSimulatedSourceResult(r:Partial<DayMarketRecord>|undefined):boolean {
 return Boolean(['WAIT','PASS','FAIL'].includes(r?.s||'WAIT')&&r?.backtestResult?.checked&&r.backtestResult.digits===r.d&&!r.manualStatus&&!r.sentRate&&!r.sentDigits&&!r.sentAt&&!r.settledAt&&!r.dispatchState&&!r.loopAccountReservation);
}
export function isSourceScrapeFrozen(r:Partial<DayMarketRecord>|undefined,pastDate:boolean):boolean {
 return Boolean(r?.sentRate||r?.sentDigits||r?.sentAt||r?.dispatchState||r?.loopAccountReservation||
  (r?.s==='PASS'||r?.s==='FAIL')&&!(pastDate&&hasSimulatedSourceResult(r)));
}

// Automatic rate suggestions may change while scraping; source edits and
// settlement must invalidate the pending response.
export function scrapeRecordVersion(record?: Partial<DayMarketRecord>): string {
  const r = record || {};
  return JSON.stringify([r.d || '', r.s || 'WAIT', r.sourceMode, r.sourceEditedAt,
    r.manualStatus, r.manualOverrideAt, r.manualRate, r.manualRate ? r.r : null,
    r.sentRate, r.sentDigits, r.dispatchState]);
}
/** Transient source requests tolerate a result-only simulation finishing.
 * Keep scrapeRecordVersion unchanged for persisted range-job fingerprints. */
export function scrapeRequestVersion(record?:Partial<DayMarketRecord>):string {
 const r={...record};
 if(hasSimulatedSourceResult(r))r.s='WAIT';
 r.d=String(r.d||'').split(/[,|\s]+/).filter(Boolean).join(', ');
 r.sourceEditedAt=Number(r.sourceEditedAt||0);
 if(!r.manualStatus)delete r.manualStatus;
 if(!r.manualRate)delete r.manualRate;
 if(!r.manualStatus&&!r.manualRate)delete r.manualOverrideAt;
 return scrapeRecordVersion(r);
}
/** Original source inputs survive automatic F/C/L/result overlays. */
export function scrapeSelectionIntent(record?:Partial<DayMarketRecord>):string {
 const intent=adminCardIntent(record||{},true);delete intent.marketName;delete intent.backtestSelectionHold;
 return JSON.stringify(intent,(_key,value)=>value&&typeof value==='object'&&!Array.isArray(value)?Object.fromEntries(Object.keys(value).sort().map(key=>[key,value[key]])):value);
}
export function canKeepScrapeRequest(record:Partial<DayMarketRecord>|undefined,version:string,intent?:string):boolean {
 if(!record)return true;
 if(record.sentRate||record.sentDigits||record.sentAt||record.dispatchState==='SENT'||record.dispatchState==='SETTLED')return false;
 if(scrapeRequestVersion(record)===version)return true;
 if(record.loopAccountSkipped||record.vipAutoStopSkipped)return false;
 if(intent&&scrapeSelectionIntent(record)===intent)return true;
 // Allow scrape to commit if card is still in WAIT or editable simulated state
 return !record.manualStatus || record.s === 'WAIT';
}

export type ScrapeCommitGuard = {
  profileId: string; date: string; market: string; version: string; revision: number; ankDigits?: string; sourceMode?:CardSourceMode; sourceDigits?:string;requestId?:number;selectionIntent?:string;generation?:number;
};
