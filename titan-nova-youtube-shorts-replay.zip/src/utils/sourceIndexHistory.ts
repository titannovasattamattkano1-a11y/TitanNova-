import type { AppState, DayMarketRecord, UserProfile } from '../types';
import { getEffectiveMarkets } from '../data/markets';
import { getScrapeResultIndex, getScrapeSource } from './scrapeProvenance';
import { findHistoricalMarketRecord } from './cardHistory';

export interface SourceIndexCell {
  mode?: DayMarketRecord['sourceMode'];
  index?: number;
  status: DayMarketRecord['s'];
}
export type SourceIndexHistory = Record<string, Record<string, SourceIndexCell>>;
export function sourceIndexCell(record?: DayMarketRecord): SourceIndexCell | undefined {
  if (!record) return undefined;
  const source = getScrapeSource(record);
  const mode = source?.mode || record.sentSourceMode || record.sourceMode;
  const index = getScrapeResultIndex(record);
  return mode || index !== undefined ? { mode, index, status: record.s } : undefined;
}

const adminHistoryCache = new WeakMap<object, { configRef: unknown; keyCount: number; fullHistory: SourceIndexHistory }>();

/** Portal projection contains display metadata only, never admin wallets or tokens. */
export function buildSourceIndexHistory(admin?: UserProfile, vip?: UserProfile): SourceIndexHistory {
  if (!admin || !admin.dayRecords) return {};
  const entries = Object.entries(admin.dayRecords);
  let cached = adminHistoryCache.get(admin.dayRecords);
  if (!cached || cached.configRef !== admin.config || cached.keyCount !== entries.length) {
    const fullHistory: SourceIndexHistory = {};
    const markets = getEffectiveMarkets(admin.config);
    for (const [date, day] of entries) {
      const cells: Record<string, SourceIndexCell> = {};
      markets.forEach((market, index) => {
        const name = market.n.toUpperCase();
        const cell = sourceIndexCell(findHistoricalMarketRecord(day.data, index, market.n));
        if (cell) cells[name] = cell;
      });
      if (Object.keys(cells).length) fullHistory[date] = cells;
    }
    cached = { configRef: admin.config, keyCount: entries.length, fullHistory };
    adminHistoryCache.set(admin.dayRecords, cached);
  }
  if (!vip) return cached.fullHistory;
  const allowed = new Set(getEffectiveMarkets(vip.config).map(m => m.n.toUpperCase()));
  const history: SourceIndexHistory = {};
  for (const [date, cells] of Object.entries(cached.fullHistory)) {
    const filtered: Record<string, SourceIndexCell> = {};
    let count = 0;
    for (const [name, cell] of Object.entries(cells)) {
      if (allowed.has(name)) {
        filtered[name] = cell;
        count++;
      }
    }
    if (count > 0) history[date] = filtered;
  }
  return history;
}

export function resolveSourceIndexCell(local: DayMarketRecord | undefined, shared?: SourceIndexCell): SourceIndexCell | undefined {
  const own = sourceIndexCell(local);
  // A VIP's actual result has priority; missing history uses admin guidance.
  if (own?.index !== undefined) return own;
  return shared?.index !== undefined ? shared : own || shared;
}

/** Same metadata fallback for master-viewed VIPs and restricted VIP portals. */
export function profileSourceIndexGuidance(state:Pick<AppState,'profiles'|'sourceIndexHistory'>,profileId:string):SourceIndexHistory|undefined {
  if(profileId==='admin1')return undefined;
  const projected=state.sourceIndexHistory,admin=state.profiles.admin1,vip=state.profiles[profileId];
  if(!admin||!vip)return projected;
  const built=buildSourceIndexHistory(admin,vip);
  if(!projected)return built;
  const result={...projected};for(const [date,cells] of Object.entries(built))result[date]={...result[date],...cells};
  return result;
}
