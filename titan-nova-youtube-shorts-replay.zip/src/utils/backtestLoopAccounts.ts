import {isMarketEnabledForDate} from './profileMarketToggle';
import {backtestMarketSelected} from './backtestMarketSelection';
import type {UserProfile,DayMarketRecord,GameType} from '../types';
import {dayLoopConfig} from './dualLoops';
import {archivedRecoveryProfile} from './archiveRecoverySnapshot';
import {getEffectiveMarkets,getEffectiveBaseMarkets} from '../data/markets';
import {calculateSettlement} from './settlement';
import {evaluateBacktest} from './backtestResult';
import {evaluateLoopAccounts,deliveredLoopCard,type LoopAccountStops} from './loopAccounts';
import {isBacktestSelectionHeld} from './backtestSelectionHold';
import {isRecordedPlay} from './financialHistory';

export function restoreLoopAccountSkips(profile:UserProfile,date:string):UserProfile {
 const day=profile.dayRecords[date];if(!day)return profile;
 let next=day;
 for(const [type,key] of [['ank','data'],['jodi','jodiData'],['pannel','pannelData']] as const){
  let records=day[key];
  for(const [i,r] of Object.entries(records||{})){
   if(!r.loopAccountSkipped||deliveredLoopCard(r)||r.manualStatus)continue;
   const copy={...r,s:'WAIT' as const};delete copy.loopAccountSkipped;delete copy.loopAccountReason;
   const restored=r.backtestResult?.checked?evaluateBacktest(copy,type,r.backtestResult.actual,r.backtestResult.openActual):copy;
   if(records===day[key])records={...records};records![i]=restored;
  }
  if(records!==day[key])next={...next,[key]:records};
 }
 return next===day?profile:{...profile,dayRecords:{...profile.dayRecords,[date]:next}};
}

/** Game-specific account checks follow the actual timetable.
 * Neither money nor stops move between games within the same loop.
 */
export function applyBacktestLoopAccounts(profile:UserProfile,date:string):UserProfile {
 const archived=archivedRecoveryProfile(profile,date),config=dayLoopConfig(archived,date),day=profile.dayRecords[date];
 if(!config?.independentAccounts||!day)return profile;
 const effective=getEffectiveMarkets(archived.config);
 const known=getEffectiveMarkets({...profile.config,deletedMarketNames:[]});
 const events:Array<{key:string;dict:'data'|'jodiData'|'pannelData';type:GameType;index:number;n:string;minute:number;rec:DayMarketRecord}>=[];
 for(const [type,dict] of [['ank','data'],['jodi','jodiData'],['pannel','pannelData']] as const){
  const markets=type==='jodi'?getEffectiveBaseMarkets(archived.config):effective;
  const current=type==='jodi'?getEffectiveBaseMarkets(profile.config):getEffectiveMarkets(profile.config);
  for(const [key,rec] of Object.entries(day[dict]||{})){
   const index=Number(key);if(!Number.isInteger(index))continue;
   const identity=rec.marketName||markets[index]?.n;if(!identity)continue;
   const market=markets.find(m=>m.n===identity)||current.find(m=>m.n===identity)||{n:identity};
   const protectedCard=isRecordedPlay(rec);
   const visibility=type==='ank'?day.visAnk:type==='jodi'?day.visJodi:day.visPan;
   if(!protectedCard&&(!current.some(m=>m.n===identity)||!isMarketEnabledForDate(archived.config,visibility,market.n,date)||!backtestMarketSelected(market.n,day.backtestRecoveryPolicy?.selectedMarkets)))continue;
   const time=type==='jodi'?effective.find(m=>m.n===market.n+' CLOSE')||known.find(m=>m.n===market.n+' CLOSE')||market:market.hr===undefined?known.find(m=>m.n===market.n)||market:market;
   const hr=Number(time.hr??(index<0?6:23)),min=Number(time.min??(index<0?0:59));
   events.push({key:`${type}_${index}`,dict,type,index,n:market.n,minute:(hr<6?1440:0)+hr*60+min,rec});
  }
 }
 events.sort((a,b)=>a.minute-b.minute||a.type.localeCompare(b.type)||a.index-b.index);
 const runtime:any={markets:events.map(e=>({type:e.type,index:e.index,n:e.n})),cards:{}};
 let stops:LoopAccountStops={},next=day;
 for(const event of events){
  const r=event.rec;if(r.s==='SKIP'){if(isRecordedPlay(r))runtime.cards[event.key]=r;continue;}
  if(r.s==='WAIT'&&isBacktestSelectionHeld(r,date)&&!isRecordedPlay(r))continue;
  const protectedCard=isRecordedPlay(r);
  const stake=calculateSettlement({type:event.type,digits:r.sentAt?(r.sentDigits||r.d):r.d,rate:r.r||r.recRate,sentRate:r.sentAt?r.sentRate:undefined,sentInvest:r.sentAt?r.sentInvest:undefined,smartStaking:r.smartStaking});
  const decision=evaluateLoopAccounts(config,runtime,date,stops,{nextKey:event.key,nextCard:r,nextInvest:stake.invest,now:0});
  stops=decision.stops;
  if(!protectedCard&&!decision.allowed){
   const state=decision.states.find(s=>s.key===decision.nextAccountKey),reason=state?.reason||'CAPITAL_LIMIT';
   const normalized=r.backtestResult?.checked?evaluateBacktest({...r,s:'WAIT'},event.type,r.backtestResult.actual,r.backtestResult.openActual):r;
   next={...next,[event.dict]:{...next[event.dict],[event.index]:{...normalized,s:'SKIP',loopAccountSkipped:true,loopAccountReason:reason}}};
   continue;
  }
  runtime.cards[event.key]=r;
  stops=evaluateLoopAccounts(config,runtime,date,stops,{now:0}).stops;
 }
 next={...next,loopAccountStops:stops};
 return {...profile,dayRecords:{...profile.dayRecords,[date]:next}};
}
