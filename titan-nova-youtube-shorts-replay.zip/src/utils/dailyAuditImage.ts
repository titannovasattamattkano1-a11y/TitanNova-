import { isFourWaveRelayActive } from './fourWaveRelay';
import { dayLoopConfig } from './dualLoops';
import { calculateProtocolStats } from './calculator';
import type { GameType, UserProfile } from '../types';
import { getEffectiveMarkets, getEffectiveBaseMarkets } from '../data/markets';
import { calculateSettlement } from './settlement';
import { calculateCapitalWallet } from './capitalWallet';
import { profileRecoveryTrack } from './dualLoops';
import { getBaseMarketUnsettledDebt } from './calculator';
import { businessDateIST } from './businessDate';
import { aggregateAuditImageData, type AuditPeriod } from './monthlyAudit';

export interface AuditImageCell { pass:number; fail:number; stakes:number; payout:number; net:number }
export interface AuditImageRow { market:string; open?:AuditImageCell; close?:AuditImageCell; result?:AuditImageCell }
export interface DailyAuditImageData {
  date:string; game:GameType; profileName:string; rows:AuditImageRow[];
  period?: AuditPeriod; startDate?: string; endDate?: string;
  pass:number; fail:number; stakes:number; payout:number; net:number;
  ownCapital:number; wallet:number; pending:number; maxRisk:number;
}
export const AUDIT_ROWS_PER_PAGE=12;
export const auditGameLabel=(game:GameType)=>game==='pannel'?'PANEL':game.toUpperCase();
export const auditMoney=(n:number)=>`₹${Math.round(n).toLocaleString('en-IN')}`;
export const auditSigned=(n:number)=>`${n<0?'−':'+'}${auditMoney(Math.abs(n))}`;
export const auditDateLabel=(date:string)=>{
  const match=/^(\d{4})-(\d{2})-(\d{2})$/.exec(date);
  if(!match)return date;
  const month=['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'][Number(match[2])-1];
  return month?`${match[3]} ${month} ${match[1]}`:date;
};

/** Read-only projection of the existing daily Hisab settlement and risk rules. */
export function buildDailyAuditImageData(profile:UserProfile,date:string,game:GameType):DailyAuditImageData {
  const dict=profile.dayRecords?.[date]?.[game==='ank'?'data':game==='jodi'?'jodiData':'pannelData']||{};
  const markets=game==='jodi'?getEffectiveBaseMarkets(profile.config):getEffectiveMarkets(profile.config);
  const rows=new Map<string,AuditImageRow>(),debt:Record<string,number>={};
  let pass=0,fail=0,stakes=0,payout=0,maxRisk=0;
  for(const [index,card] of Object.entries(dict)){
    if(!card||(card.s!=='PASS'&&card.s!=='FAIL'))continue;
    const name=String(card.marketName||markets[Number(index)]?.n||'').trim();if(!name)continue;
    const winDigit = card.manualResult || card.scrapeResultDigit || (/CLOSE/i.test(name) ? card.backtestResult?.actual?.close : card.backtestResult?.actual?.open);
    const value=calculateSettlement({type:game,digits:card.sentAt?(card.sentDigits||card.d):card.d,rate:card.r||card.recRate,sentRate:card.sentAt?card.sentRate:undefined,sentInvest:card.sentAt?card.sentInvest:undefined,smartStaking:card.smartStaking,winningDigit:winDigit});
    if(value.tokenCount<=0)continue;
    const key=profileRecoveryTrack(profile,date,game,name,card);
    if (debt[key] === undefined) {
      const isSameMarket = profile.config?.sameMarketRecovery !== false && (
        game === 'ank' ? profile.config?.ankSplit !== false : game === 'pannel' ? profile.config?.panSplit !== false : false
      ) && !key.endsWith(':ALL');
      debt[key] = isSameMarket ? getBaseMarketUnsettledDebt(profile, date, game, name) : 0;
    }
    const totalDebt=()=>Object.values(debt).reduce((sum,n)=>sum+n,0);
    if(card.s==='PASS'){pass++;payout+=value.payout;maxRisk=Math.max(maxRisk,totalDebt()+value.invest);debt[key]=0;}
    else{fail++;debt[key]+=value.invest;maxRisk=Math.max(maxRisk,totalDebt());}
    stakes+=value.invest;
    const suffix=game==='jodi'?undefined:/\s+(OPEN|CLOSE)$/i.exec(name)?.[1].toUpperCase();
    const base=(suffix?name.replace(/\s+(OPEN|CLOSE)$/i,''):name).trim().toUpperCase();
    const groupKey=game!=='jodi'&&!suffix?`result:${base}`:`market:${base}`;
    const row=rows.get(groupKey)||{market:base};
    const side: 'open'|'close'|'result'=suffix==='OPEN'?'open':suffix==='CLOSE'?'close':'result';
    const cell=row[side]||{pass:0,fail:0,stakes:0,payout:0,net:0};
    cell.pass+=Number(card.s==='PASS');cell.fail+=Number(card.s==='FAIL');cell.stakes+=value.invest;
    cell.payout+=card.s==='PASS'?value.payout:0;cell.net=cell.payout-cell.stakes;row[side]=cell;rows.set(groupKey,row);
  }
  const wallet=calculateCapitalWallet(game,dict,true);
  const effCfg = (date < businessDateIST() ? profile.dayRecords?.[date]?.recoveryConfigSnapshot : undefined) || profile.config;
  if (isFourWaveRelayActive(effCfg, Boolean(dayLoopConfig(profile, date)?.enabled))) {
    maxRisk = calculateProtocolStats(game, profile, date).maxLoss;
  }
  return {date,game,profileName:profile.name,rows:[...rows.values()],pass,fail,stakes,payout,net:payout-stakes,ownCapital:wallet.invested,wallet:wallet.balance,pending:wallet.pending,maxRisk};
}

/** Read-only range aggregation; original daily PNG builder untouched. */
export function buildAuditImageData(profile:UserProfile,date:string,game:GameType,period:AuditPeriod='day'):DailyAuditImageData {
  return aggregateAuditImageData(profile,date,game,period,buildDailyAuditImageData);
}

export interface AuditImagePage { blob:Blob; url:string; filename:string; page:number; totalPages:number }
const WIDTH=1080,HEIGHT=1440;
/** Canvas renders actual numbers with local fonts; no external images, network or AI. */
export function renderAuditImagePage(data:DailyAuditImageData,rows:AuditImageRow[],page:number,totalPages:number):HTMLCanvasElement {
  const canvas=document.createElement('canvas');canvas.width=WIDTH;canvas.height=HEIGHT;
  const ctx=canvas.getContext('2d');if(!ctx)throw new Error('Image preview is unavailable in this browser.');
  const cyan='#53deee',white='#eef7ff',muted='#9db8cd',green='#59ed92',red='#ff8b91';
  const bg=ctx.createLinearGradient(0,0,WIDTH,HEIGHT);bg.addColorStop(0,'#103047');bg.addColorStop(.4,'#091b2c');bg.addColorStop(1,'#122839');ctx.fillStyle=bg;ctx.fillRect(0,0,WIDTH,HEIGHT);
  const text=(value:string,x:number,y:number,size:number,color=white,align:CanvasTextAlign='left',maxWidth=WIDTH-80,weight=600)=>{
    let font=size;ctx.font=`${weight} ${font}px Arial, sans-serif`;
    while(ctx.measureText(value).width>maxWidth&&font>12){font--;ctx.font=`${weight} ${font}px Arial, sans-serif`;}
    ctx.fillStyle=color;ctx.textAlign=align;ctx.fillText(value,x,y,maxWidth);
  };
  const line=(y:number)=>{ctx.strokeStyle='#3595b466';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(40,y);ctx.lineTo(1040,y);ctx.stroke();};
  const period = data.period || 'day';
  // Monthly rows summarize multiple results; preserve their counts and paise.
  const amountText=(value:number)=>period==='month'?value.toLocaleString('en-IN',{maximumFractionDigits:2}):Math.round(value).toLocaleString('en-IN');
  const moneyText=(value:number)=>`₹${amountText(value)}`;
  const signedText=(value:number)=>`${value<0?'−':'+'}${moneyText(Math.abs(value))}`;
  const statusText=(cell:AuditImageCell)=>period==='month'?`${cell.pass}P/${cell.fail}F`:cell.pass&&cell.fail?`${cell.pass}P/${cell.fail}F`:cell.pass?'P':'F';
  text('TITAN NOVA',540,94,66,white,'center',1000,800);
  text(`${period === 'day' ? 'DAILY' : period === 'week' ? 'WEEKLY' : 'MONTHLY'} AUDIT · ${auditGameLabel(data.game)}`,540,143,32,cyan,'center');
  text(data.startDate && data.startDate !== data.date ? `${auditDateLabel(data.startDate)} – ${auditDateLabel(data.date)}` : auditDateLabel(data.date),540,184,30,white,'center');
  text(data.profileName,540,218,22,muted,'center',1000,400);line(239);
  text(data.net<0?'NET LOSS':'NET PROFIT',44,297,36,white,'left',330,700);
  text(signedText(data.net),1036,302,62,data.net<0?red:green,'right',610,800);line(329);
  text(`${data.pass+data.fail} SETTLED`,48,380,29,white,'left',330);
  text(`${data.pass} PASS`,540,380,29,green,'center',300);
  text(`${data.fail} FAIL`,1036,380,29,red,'right',300);line(407);
  ctx.fillStyle='#18527288';ctx.fillRect(40,423,1000,52);
  const paired=data.game!=='jodi';
  text('MARKET',57,458,28,cyan,'left',450,700);
  text(paired?'OPEN':'STATUS',735,458,27,cyan,'right',260,700);
  text(paired?'CLOSE':'NET P/L',1020,458,27,cyan,'right',260,700);
  const cellText=(cell:AuditImageCell|undefined,right:number,y:number)=>{
    if(!cell){text('—',right,y,29,muted,'right',248);return;}
    const status=statusText(cell);
    const amount=`${cell.net<0?'−':'+'}${amountText(Math.abs(cell.net))}`;
    text(`${status}  ${amount}`,right,y,32,cell.net<0?red:green,'right',248);
  };
  rows.forEach((row,i)=>{
    const y=514+i*48;
    text(row.market,57,y,30,white,'left',445,700);
    if(paired){
      if(row.result&&!row.open&&!row.close)text(`RESULT ${statusText(row.result)} ${signedText(row.result.net)}`,1020,y,29,row.result.net<0?red:green,'right',510);
      else{cellText(row.open,735,y);cellText(row.close,1020,y);}
    }
    else{
      const cell=row.result!;text(period==='month'?`${cell.pass}P / ${cell.fail}F`:cell.pass&&cell.fail?`${cell.pass}P / ${cell.fail}F`:cell.pass?'PASS':'FAIL',735,y,26,cell.fail&&!cell.pass?red:green,'right',220);
      text(signedText(cell.net),1020,y,29,cell.net<0?red:green,'right',260);
    }
    line(y+14);
  });
  if(!rows.length)text(period === 'day' ? 'No settled cards for this date' : 'No settled cards for this period',540,650,36,muted,'center');
  text(paired?'P = PASS · F = FAIL · OPEN/CLOSE net in ₹':'Market net in ₹ · Settled results only',540,1125,22,muted,'center');line(1148);
  const figures=[['STAKES',data.stakes],['RETURN',data.payout],['OWN CAPITAL',data.ownCapital],['WALLET',data.wallet],['PENDING',data.pending],['MAX RISK',data.maxRisk]] as const;
  figures.forEach(([label,value],i)=>{
    const col=i<3?0:1,row=i%3,x=48+col*515,y=1200+row*53;
    text(label,x,y,23,cyan,'left',200,700);text(moneyText(value),x+465,y,29,white,'right',258,700);
  });line(1333);
  text(period === 'day' ? 'Day totals repeated on each page · Do not add pages together' : 'Period totals repeated on each page · Do not add pages together',540,1365,19,muted,'center',1000,400);
  text(`${period === 'day' ? 'Digits/rates in detailed text' : `Wallet is for ${auditDateLabel(data.date)}`} · PAGE ${page} / ${totalPages}`,540,1401,21,muted,'center',1000,400);
  return canvas;
}

export async function generateDailyAuditImages(data:DailyAuditImageData,signal?:AbortSignal):Promise<AuditImagePage[]> {
  const total=Math.max(1,Math.ceil(data.rows.length/AUDIT_ROWS_PER_PAGE)),pages:AuditImagePage[]=[];
  try{
    for(let i=0;i<total;i++){
      if(signal?.aborted)throw new DOMException('Preview closed','AbortError');
      const canvas=renderAuditImagePage(data,data.rows.slice(i*AUDIT_ROWS_PER_PAGE,(i+1)*AUDIT_ROWS_PER_PAGE),i+1,total);
      let blob:Blob;
      try{blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(value=>value?resolve(value):reject(new Error('Image generation failed; try again.')),'image/png'));}
      finally{canvas.width=0;canvas.height=0;}
      if(signal?.aborted)throw new DOMException('Preview closed','AbortError');
      pages.push({blob,url:URL.createObjectURL(blob),filename:`Titan-${auditGameLabel(data.game)}-${data.period === 'month' ? 'MONTHLY-' : data.period === 'week' ? 'WEEKLY-' : ''}Audit-${data.date}-${i+1}.png`,page:i+1,totalPages:total});
    }
    return pages;
  }catch(error){pages.forEach(p=>URL.revokeObjectURL(p.url));throw error;}
}
