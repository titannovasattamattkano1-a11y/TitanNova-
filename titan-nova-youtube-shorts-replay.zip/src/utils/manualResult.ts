import { normalizePanelPatti } from './panelAnk';
import { settlementTokenHit } from './settlement';

export function normalizeManualResult(type: string, value: unknown): string | undefined {
  const result = String(value ?? '').trim();
  const pattern = type === 'ank' ? /^\d$/ : type === 'jodi' ? /^\d{2}$/ : type === 'pannel' ? /^\d{3}$/ : /a^/;
  if (!pattern.test(result)) return undefined;
  return type === 'pannel' ? normalizePanelPatti(result) || undefined : result;
}
export function manualResultMatchesStatus(type: string, digits: unknown, result: string, status: string): boolean {
  return (status === 'PASS' || status === 'FAIL') && settlementTokenHit(type, digits, result) === (status === 'PASS');
}

/** Each VIP settles the actual result against its own delivered digits. */
export function manualResultStatus(type: string, digits: unknown, result: string): 'PASS' | 'FAIL' {
  return settlementTokenHit(type, digits, result) ? 'PASS' : 'FAIL';
}
