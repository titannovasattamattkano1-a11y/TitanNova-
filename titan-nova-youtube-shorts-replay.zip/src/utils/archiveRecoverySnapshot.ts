import type {DayRecordStore,UserProfile} from '../types';
import {businessDateIST} from './businessDate';

/** Capture settings only; opening an archive must not rewrite its saved bets. */
export function pinRecoverySettings(profile:UserProfile,date:string):UserProfile {
  if(date===businessDateIST()&&!profile.config.twoCardRecoveryFrom)profile={...profile,config:{...profile.config,twoCardRecoveryFrom:date,twoCardRecoveryLegacySplit:{ank:profile.config.ankSplit!==false,pannel:profile.config.panSplit!==false}}};
  const day=profile.dayRecords?.[date];if(!day||date>businessDateIST())return profile;
  if(day.recoveryConfigSnapshot&&(date<businessDateIST()||JSON.stringify(day.recoveryConfigSnapshot)===JSON.stringify(profile.config)))return profile;
  return {...profile,dayRecords:{...profile.dayRecords,[date]:{...day,recoveryConfigSnapshot:structuredClone(profile.config)}}};
}
export function archivedRecoveryProfile(profile:UserProfile,date:string):UserProfile {
  const config=date<businessDateIST()?profile.dayRecords?.[date]?.recoveryConfigSnapshot:undefined;
  return config?{...profile,config}:profile;
}
/** Changes to live defaults, other dates/profiles and settings snapshots are not replay triggers. */
export function archiveReplaySignature(day:DayRecordStore|undefined):string {
  return JSON.stringify([day?.data,day?.jodiData,day?.pannelData,day?.loopConfig,day?.backtestRecoveryPolicy,day?.openToCloseCut,day?.visAnk,day?.visJodi,day?.visPan]);
}
