import {apiDeadlineSignal} from './apiDeadline';

export class BulkCommandError extends Error {
  constructor(message:string, public readonly outcomeUnknown=false) { super(message); }
}

export function bulkOperationId():string {
  return `${Date.now()}_${globalThis.crypto?.randomUUID?.()||Math.random().toString(36).slice(2)}`;
}

/** Send once. A lost acknowledgement is checked using a read-only durable receipt;
 * never repeat a financial reset which could erase a later edit or settlement. */
export async function postBulkCommand(options:{url:string;receiptUrl:string;body:Record<string,unknown>;headers?:HeadersInit;fetcher?:typeof fetch}):Promise<any> {
  if(typeof navigator!=='undefined'&&navigator.onLine===false)throw new BulkCommandError('Offline: action was not sent. Reconnect and try again.');
  const fetcher=options.fetcher??fetch;
  let rejection:BulkCommandError|undefined;
  try {
    const response=await fetcher(options.url,{method:'POST',headers:options.headers,body:JSON.stringify(options.body),signal:apiDeadlineSignal(undefined,60000)});
    const result=await response.json();
    if(response.ok&&result?.status==='success'&&result.operationId===options.body.operationId)return result;
    rejection=new BulkCommandError(result?.message||`Bulk command rejected (HTTP ${response.status})`);
    // Validation, permissions and active-range guards reject before any reset.
    if(response.status>=400&&response.status<500)throw rejection;
  } catch(error) {
    if(error===rejection)throw error;
  }
  try {
    const response=await fetcher(options.receiptUrl,{method:'GET',cache:'no-store',headers:options.headers,signal:apiDeadlineSignal(undefined,15000)});
    const result=await response.json();
    if(response.ok&&result?.status==='success'&&result.operationId===options.body.operationId)return result;
    // A missing receipt cannot prove a delayed POST will never arrive.
    if(response.status===404&&result?.code==='BULK_OPERATION_NOT_FOUND')throw new BulkCommandError('Save confirmation pending. Reconnect and reload before trying this action again.',true);
    if(response.status===403||response.status===401)throw new BulkCommandError(result?.message||'Admin editing control is required.',true);
  } catch(error) {
    if(error instanceof BulkCommandError)throw error;
  }
  throw new BulkCommandError('Save confirmation unavailable. Reconnect and reload before trying this action again.',true);
}
