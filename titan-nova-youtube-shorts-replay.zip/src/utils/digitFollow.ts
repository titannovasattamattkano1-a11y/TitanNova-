import {panelAnkDigit} from './panelAnk';
export interface DigitFollowDraw {date:string;jodi?:string;open?:string;close?:string}
/** One market's actual OPEN -> CLOSE -> next available OPEN timeline. */
export function selectDigitFollow(draws:DigitFollowDraw[],targetDate:string,side:'open'|'close',observe?:(digit:string,date:string)=>void,observationLimit?:number){
  const target=new Date(`${targetDate}T00:00:00Z`);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(targetDate)||!Number.isFinite(target.getTime())||target.toISOString().slice(0,10)!==targetDate)throw new Error('Digit Follow: invalid target date');
  const byDate=new Map<string,{open?:string;close?:string}>(),conflicts=new Set<string>();
  for(const row of draws){
    if(row.date>=targetDate)continue;
    const date=new Date(`${row.date}T00:00:00Z`);
    if(!/^\d{4}-\d{2}-\d{2}$/.test(row.date)||!Number.isFinite(date.getTime())||date.toISOString().slice(0,10)!==row.date)continue;
    const pair=/^\d{2}$/.test(row.jodi||'')?row.jodi!:undefined;
    const open=panelAnkDigit(row.open)||undefined,close=panelAnkDigit(row.close)||undefined;
    if(pair&&((open&&open!==pair[0])||(close&&close!==pair[1])))conflicts.add(row.date);
    const next={open:pair?.[0]||open,close:pair?.[1]||close},old=byDate.get(row.date);
    if(old&&((old.open&&next.open&&old.open!==next.open)||(old.close&&next.close&&old.close!==next.close)))conflicts.add(row.date);
    byDate.set(row.date,{open:next.open||old?.open,close:next.close||old?.close});
  }
  const history=[...byDate].sort(([a],[b])=>a.localeCompare(b));
  const latest=[...history].reverse().find(([date,row])=>!conflicts.has(date)&&row[side]!==undefined);
  if(!latest)throw new Error('Digit Follow: selected date se pehle side ka reference digit nahi mila; card unchanged');
  const reference=latest[1][side]!;
  const timeline:Array<string|undefined>=[],timelineDates:string[]=[];
  for(const [date,row] of history){
    if(conflicts.has(date)){timeline.push(undefined);timelineDates.push(date);continue;}
    if(row.open===undefined&&row.close===undefined)continue; // No published draw: next available day.
    timeline.push(row.open,row.close);timelineDates.push(date,date); // Unknown half stays a barrier, never skip over it.
  }
  const digits=new Set<string>();let scanned=0,matches=0;
  for(let i=timeline.length-2;i>=0;i--){
    scanned++;
    const next=timeline[i+1];
    if(timeline[i]!==reference||next===undefined)continue;
    matches++;observe?.(next,timelineDates[i]);digits.add(next);
    if(observationLimit===undefined?digits.size===10:matches>=observationLimit)break;
  }
  return {digits:[...digits].join(', '),reference,basePair:latest[1].open!==undefined&&latest[1].close!==undefined?latest[1].open+latest[1].close:undefined,baseDate:latest[0],matches,scanned,complete:digits.size===10};
}
