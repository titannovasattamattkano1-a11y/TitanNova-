/** Carry6 is source agreement, not a probability or a guaranteed prediction. */
export function selectCarry6(sources: Record<string, unknown>, currentSource: string): string {
  const modes = ['AUTO', 'WEEKDAY', 'COMBO', 'DAY_COMBO'];
  const ordered = modes.map(mode => String(sources?.[mode] || '').split(/[,|\s]+/).filter(Boolean));
  if (ordered.some(d => d.length !== 10 || new Set(d).size !== 10 || d.some(x => !/^\d$/.test(x)))) throw new Error('Carry6: all four original ten-digit sources required; card unchanged');
  const current = String(currentSource || '').split(/[,|\s]+/).filter(Boolean);
  if (current.length !== 10 || new Set(current).size !== 10 || current.some(d => !/^\d$/.test(d))) throw new Error('Carry6: current card original scraping source unavailable; card unchanged');
  const groups = [current.slice(8, 10), ...ordered.map(d => d.slice(8, 10))];
  const votes = new Map<string, {digit: string; votes: number; priority: number}>();
  groups.forEach((digits, group) => [...new Set(digits)].forEach((digit, slot) => {
    const entry = votes.get(digit) || {digit, votes: 0, priority: group * 2 + slot};
    entry.votes++;
    votes.set(digit, entry);
  }));
  return [...votes.values()].sort((a,b) => b.votes - a.votes || a.priority - b.priority).slice(0,6).map(x => x.digit).join(', ');
}
