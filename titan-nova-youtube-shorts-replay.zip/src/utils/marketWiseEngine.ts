export interface MarketChartDay {
  date: string;
  weekday: number;
  open?: string;
  close?: string;
}

export type MarketLineName = 'Kadi Line' | 'Tirchi Line' | 'Jod-Fark' | 'Trikon' | 'O-C Matrix';

export interface MarketWiseProfile {
  winningLine: MarketLineName;
  lineWeights: Record<MarketLineName, number>;
  lineHitRates: Record<MarketLineName, number>;
  digitScores: Map<string, number>;
  crossLockCount: Map<string, number>;
  regimeShifted: boolean;
  confidenceGrade: 'A+' | 'A' | 'B';
  bestStreams: string[];
}

const ALL_DIGITS = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
const mirror = (d: string) => String((Number(d) + 5) % 10);

function normalizeMap(raw: Map<string, number>, digits: string[]): Map<string, number> {
  const vals = digits.map(d => raw.get(d) || 0);
  const min = Math.min(...vals);
  const max = Math.max(...vals);
  const span = max - min;
  const out = new Map<string, number>();
  for (const d of digits) {
    const v = raw.get(d) || 0;
    out.set(d, span > 1e-6 ? (v - min) / span : 0.5);
  }
  return out;
}

/**
 * Computes raw candidate scores for each of the 5 Matka lines at slice offset `offset`
 * (where `days.slice(offset)` is the history strictly before the draw being predicted).
 */
function scoreLinesAtOffset(
  days: MarketChartDay[],
  offset: number,
  targetWeekday: number,
  side: 'open' | 'close',
  digits: string[],
): Record<MarketLineName, Map<string, number>> {
  const oppSide: 'open' | 'close' = side === 'open' ? 'close' : 'open';
  const kadi = new Map<string, number>(digits.map(d => [d, 0]));
  const tirchi = new Map<string, number>(digits.map(d => [d, 0]));
  const jodFark = new Map<string, number>(digits.map(d => [d, 0]));
  const trikon = new Map<string, number>(digits.map(d => [d, 0]));
  const ocMatrix = new Map<string, number>(digits.map(d => [d, 0]));

  const prev1 = days[offset];
  const prev2 = days[offset + 1];
  if (!prev1) {
    return { 'Kadi Line': kadi, 'Tirchi Line': tirchi, 'Jod-Fark': jodFark, 'Trikon': trikon, 'O-C Matrix': ocMatrix };
  }

  // 1. Kadi Line (Same-Weekday Vertical Column & Weekly Rhythm)
  const vert: MarketChartDay[] = [];
  for (let i = offset; i < days.length && vert.length < 10; i++) {
    if (days[i].weekday === targetWeekday && days[i][side] !== undefined) {
      vert.push(days[i]);
    }
  }
  if (vert.length >= 1) {
    for (let k = 0; k < Math.min(6, vert.length); k++) {
      const d = vert[k][side]!;
      const w = Math.pow(0.82, k);
      kadi.set(d, (kadi.get(d) || 0) + 1.45 * w);
      kadi.set(mirror(d), (kadi.get(mirror(d)) || 0) + 0.65 * w);
    }
    if (vert.length >= 3) {
      const w1 = Number(vert[0][side]!);
      const w2 = Number(vert[1][side]!);
      const w3 = Number(vert[2][side]!);
      const s1 = (w1 - w2 + 10) % 10;
      const s2 = (w2 - w3 + 10) % 10;
      if (s1 === s2 && (s1 <= 3 || s1 >= 7)) {
        const nextStep = String((w1 + s1) % 10);
        kadi.set(nextStep, (kadi.get(nextStep) || 0) + 1.55);
        kadi.set(mirror(nextStep), (kadi.get(mirror(nextStep)) || 0) + 0.75);
      }
    }
  }

  // 2. Tirchi Line (Diagonal Cross Staircase & Close-to-Open Drop & Delta Velocity)
  const cRef = prev1[oppSide];
  const sRef = prev1[side];
  if (cRef) {
    tirchi.set(cRef, (tirchi.get(cRef) || 0) + 1.55);
    tirchi.set(mirror(cRef), (tirchi.get(mirror(cRef)) || 0) + 0.90);
  }
  if (sRef) {
    tirchi.set(sRef, (tirchi.get(sRef) || 0) + 1.00);
    tirchi.set(mirror(sRef), (tirchi.get(mirror(sRef)) || 0) + 0.60);
  }
  // Staircase Velocity Step (+1, -1, +2, -2 continuation)
  if (prev1[oppSide] && prev2?.[oppSide]) {
    const dStep = (Number(prev1[oppSide]) - Number(prev2[oppSide]) + 10) % 10;
    if (dStep <= 3 || dStep >= 7) {
      const diagNext = String((Number(prev1[oppSide]) + dStep) % 10);
      tirchi.set(diagNext, (tirchi.get(diagNext) || 0) + 1.50);
      tirchi.set(mirror(diagNext), (tirchi.get(mirror(diagNext)) || 0) + 0.80);
    }
  }
  if (prev1[side] && prev2?.[side]) {
    const sStep = (Number(prev1[side]) - Number(prev2[side]) + 10) % 10;
    if (sStep <= 2 || sStep >= 8) {
      const sameNext = String((Number(prev1[side]) + sStep) % 10);
      tirchi.set(sameNext, (tirchi.get(sameNext) || 0) + 1.25);
    }
  }

  // 3. Jod & Fark Line (Jodi Total & Difference Continuation)
  let latestJodi: MarketChartDay | undefined;
  for (let i = offset; i < Math.min(offset + 6, days.length); i++) {
    if (days[i].open !== undefined && days[i].close !== undefined) {
      latestJodi = days[i];
      break;
    }
  }
  if (latestJodi?.open && latestJodi?.close) {
    const jTot = (Number(latestJodi.open) + Number(latestJodi.close)) % 10;
    const jDif = (Number(latestJodi.close) - Number(latestJodi.open) + 10) % 10;
    const tStr = String(jTot);
    const dStr = String(jDif);
    jodFark.set(tStr, (jodFark.get(tStr) || 0) + 1.45);
    jodFark.set(mirror(tStr), (jodFark.get(mirror(tStr)) || 0) + 0.85);
    jodFark.set(dStr, (jodFark.get(dStr) || 0) + 1.35);
    jodFark.set(mirror(dStr), (jodFark.get(mirror(dStr)) || 0) + 0.80);

    const scanEnd = Math.min(days.length - 1, offset + 120);
    for (let k = offset; k < scanEnd; k++) {
      const cur = days[k];
      const prv = days[k + 1];
      if (!cur[side] || !prv.open || !prv.close) continue;
      const pTot = (Number(prv.open) + Number(prv.close)) % 10;
      const pDif = (Number(prv.close) - Number(prv.open) + 10) % 10;
      const w = Math.pow(0.985, k - offset);
      if (pTot === jTot) jodFark.set(cur[side]!, (jodFark.get(cur[side]!) || 0) + 0.70 * w);
      if (pDif === jDif) jodFark.set(cur[side]!, (jodFark.get(cur[side]!) || 0) + 0.65 * w);
    }
  }

  // 4. Trikon Sangam Bridge (Triangle Addition & Cross Differences)
  if (prev1.open && prev1.close) {
    const tri1 = String((Number(prev1.open) + Number(prev1.close)) % 10);
    trikon.set(tri1, (trikon.get(tri1) || 0) + 1.15);
    trikon.set(mirror(tri1), (trikon.get(mirror(tri1)) || 0) + 0.70);
  }
  if (vert[0]?.[side] && prev1[oppSide]) {
    const tri2 = String((Number(vert[0][side]!) + Number(prev1[oppSide])) % 10);
    trikon.set(tri2, (trikon.get(tri2) || 0) + 1.35);
    trikon.set(mirror(tri2), (trikon.get(mirror(tri2)) || 0) + 0.80);
  }
  if (vert[0]?.[oppSide] && prev1[side]) {
    const tri3 = String((Number(vert[0][oppSide]!) - Number(prev1[side]!) + 10) % 10);
    trikon.set(tri3, (trikon.get(tri3) || 0) + 1.20);
    trikon.set(mirror(tri3), (trikon.get(mirror(tri3)) || 0) + 0.70);
  }
  if (prev1[side] && prev2?.[side]) {
    const bridge = String((Number(prev1[side]!) + Number(prev2[side]!)) % 10);
    trikon.set(bridge, (trikon.get(bridge) || 0) + 1.25);
    trikon.set(mirror(bridge), (trikon.get(mirror(bridge)) || 0) + 0.75);
  }

  // 5. O-C Matrix (Market-Specific Open <-> Close & Jodi Successor Transition Matrix)
  const refOpen = prev1.open;
  const refClose = prev1.close;
  const matrixEnd = Math.min(days.length - 1, offset + 150);
  for (let k = offset; k < matrixEnd; k++) {
    const cur = days[k];
    const prv = days[k + 1];
    if (!cur[side]) continue;
    const w = Math.pow(0.985, k - offset);
    if (side === 'close') {
      if (refClose && prv.close === refClose) {
        ocMatrix.set(cur.close!, (ocMatrix.get(cur.close!) || 0) + 1.05 * w);
      }
      if (refOpen && prv.open === refOpen) {
        ocMatrix.set(cur.close!, (ocMatrix.get(cur.close!) || 0) + 0.95 * w);
      }
      if (refOpen && cur.open === refOpen && cur.close) {
        ocMatrix.set(cur.close, (ocMatrix.get(cur.close) || 0) + 1.25 * w);
      }
    } else {
      if (refClose && prv.close === refClose) {
        ocMatrix.set(cur.open!, (ocMatrix.get(cur.open!) || 0) + 1.15 * w);
      }
      if (refOpen && prv.open === refOpen) {
        ocMatrix.set(cur.open!, (ocMatrix.get(cur.open!) || 0) + 0.90 * w);
      }
    }
    if (refOpen && refClose && prv.open === refOpen && prv.close === refClose) {
      ocMatrix.set(cur[side]!, (ocMatrix.get(cur[side]!) || 0) + 1.75 * w);
    }
  }

  return {
    'Kadi Line': kadi,
    'Tirchi Line': tirchi,
    'Jod-Fark': jodFark,
    'Trikon': trikon,
    'O-C Matrix': ocMatrix,
  };
}

/**
 * Evaluates internal multi-source streams (AUTO, WEEKDAY, COMBO, DAY_COMBO, PAIR_FOLLOW, DIGIT_FOLLOW)
 * on this specific market's recent draws and returns per-digit cross-lock scores.
 */
function computeMarketStreamConsensus(
  days: MarketChartDay[],
  targetWeekday: number,
  side: 'open' | 'close',
): { streamBonus: Map<string, number>; bestStreams: string[]; lockCount: Map<string, number> } {
  const streamBonus = new Map<string, number>(ALL_DIGITS.map(d => [d, 0]));
  const lockCount = new Map<string, number>(ALL_DIGITS.map(d => [d, 0]));
  if (days.length < 8) return { streamBonus, bestStreams: ['AUTO'], lockCount };

  const getStreamTop4 = (offset: number): Record<string, string[]> => {
    const slice = days.slice(offset);
    const wday = offset === 0 ? targetWeekday : (days[offset - 1]?.weekday ?? targetWeekday);

    // 1. AUTO: recent same-side frequency in first-10-unique window
    const autoCounts = new Map<string, number>();
    const autoSeen = new Set<string>();
    for (const r of slice) {
      const d = r[side];
      if (!d) continue;
      autoCounts.set(d, (autoCounts.get(d) || 0) + 1);
      autoSeen.add(d);
      if (autoSeen.size === 10) break;
    }
    const autoTop = [...autoCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 4).map(e => e[0]);

    // 2. WEEKDAY: same-weekday same-side frequency
    const dayCounts = new Map<string, number>();
    let dayChecked = 0;
    for (const r of slice) {
      if (r.weekday !== wday || !r[side]) continue;
      dayCounts.set(r[side]!, (dayCounts.get(r[side]!) || 0) + Math.pow(0.88, dayChecked++));
      if (dayChecked >= 12) break;
    }
    const dayTop = [...dayCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 4).map(e => e[0]);

    // 3. COMBO: recent Open+Close frequency
    const comboCounts = new Map<string, number>();
    let comboChecked = 0;
    for (const r of slice) {
      for (const d of [r.close, r.open]) {
        if (!d) continue;
        comboCounts.set(d, (comboCounts.get(d) || 0) + Math.pow(0.92, comboChecked));
      }
      if (++comboChecked >= 12) break;
    }
    const comboTop = [...comboCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 4).map(e => e[0]);

    // 4. DIGIT_FOLLOW: historical successors of slice[0][side]
    const refDigit = slice[0]?.[side];
    const dfCounts = new Map<string, number>();
    if (refDigit) {
      for (let i = 0; i < Math.min(120, slice.length - 1); i++) {
        if (slice[i + 1][side] === refDigit && slice[i][side]) {
          const d = slice[i][side]!;
          dfCounts.set(d, (dfCounts.get(d) || 0) + Math.pow(0.97, i));
        }
      }
    }
    const dfTop = [...dfCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 4).map(e => e[0]);

    // 5. PAIR_FOLLOW: historical successors of latest Jodi family
    const refOpen = slice[0]?.open;
    const refClose = slice[0]?.close;
    const pfCounts = new Map<string, number>();
    if (refOpen && refClose) {
      const refFam = `${Number(refOpen) % 5}${Number(refClose) % 5}`;
      for (let i = 0; i < Math.min(140, slice.length - 1); i++) {
        const prv = slice[i + 1];
        if (prv.open && prv.close && `${Number(prv.open) % 5}${Number(prv.close) % 5}` === refFam && slice[i][side]) {
          const d = slice[i][side]!;
          pfCounts.set(d, (pfCounts.get(d) || 0) + Math.pow(0.97, i));
        }
      }
    }
    const pfTop = [...pfCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 4).map(e => e[0]);

    return { AUTO: autoTop, WEEKDAY: dayTop, COMBO: comboTop, DIGIT_FOLLOW: dfTop, PAIR_FOLLOW: pfTop };
  };

  const streamNames = ['AUTO', 'WEEKDAY', 'COMBO', 'DIGIT_FOLLOW', 'PAIR_FOLLOW'];
  const streamScores = new Map<string, number>(streamNames.map(s => [s, 1.0]));

  // Walk-forward evaluate each stream on the last 8 draws of this specific market
  const trials = Math.min(8, days.length - 6);
  for (let t = 0; t < trials; t++) {
    const actual = days[t][side];
    if (!actual) continue;
    const preds = getStreamTop4(t + 1);
    const recency = t < 3 ? 1.6 : 1.0;
    for (const sName of streamNames) {
      if (preds[sName]?.includes(actual)) {
        streamScores.set(sName, (streamScores.get(sName) || 1) + recency);
      }
    }
  }

  const rankedStreams = [...streamNames].sort((a, b) => (streamScores.get(b) || 0) - (streamScores.get(a) || 0));
  const bestStreams = rankedStreams.slice(0, 2);
  const todayPreds = getStreamTop4(0);

  for (const sName of rankedStreams) {
    const sWeight = (streamScores.get(sName) || 1) / (trials + 2);
    const list = todayPreds[sName] || [];
    list.forEach((d, idx) => {
      const rankFactor = 1 - idx * 0.18;
      streamBonus.set(d, (streamBonus.get(d) || 0) + sWeight * rankFactor);
      if (bestStreams.includes(sName)) {
        lockCount.set(d, (lockCount.get(d) || 0) + 1);
      }
    });
  }

  return { streamBonus, bestStreams, lockCount };
}

/**
 * Master Market-Wise Self-Calibrating Engine.
 * Backtests all 5 chart lines on the last 12 draws of THIS specific market & side,
 * detects 2-3 draw regime shifts, cross-locks with top market streams, and outputs
 * calibrated per-digit scores and the market's true winning line.
 */
export function buildMarketWiseProfile(
  days: MarketChartDay[],
  targetDate: string,
  side: 'open' | 'close',
  sourceTokens: string[],
): MarketWiseProfile {
  const [y, m, dNum] = targetDate.split('-').map(Number);
  const targetWeekday = new Date(Date.UTC(y || 2026, (m || 1) - 1, dNum || 1)).getUTCDay();
  const lineNames: MarketLineName[] = ['Kadi Line', 'Tirchi Line', 'Jod-Fark', 'Trikon', 'O-C Matrix'];

  const weightedHits: Record<MarketLineName, number> = {
    'Kadi Line': 0,
    'Tirchi Line': 0,
    'Jod-Fark': 0,
    'Trikon': 0,
    'O-C Matrix': 0,
  };
  const rawHits: Record<MarketLineName, number> = {
    'Kadi Line': 0,
    'Tirchi Line': 0,
    'Jod-Fark': 0,
    'Trikon': 0,
    'O-C Matrix': 0,
  };
  const recent3Hits: Record<MarketLineName, number> = {
    'Kadi Line': 0,
    'Tirchi Line': 0,
    'Jod-Fark': 0,
    'Trikon': 0,
    'O-C Matrix': 0,
  };
  const missStreak: Record<MarketLineName, number> = {
    'Kadi Line': 0,
    'Tirchi Line': 0,
    'Jod-Fark': 0,
    'Trikon': 0,
    'O-C Matrix': 0,
  };
  const streakBroken: Record<MarketLineName, boolean> = {
    'Kadi Line': false,
    'Tirchi Line': false,
    'Jod-Fark': false,
    'Trikon': false,
    'O-C Matrix': false,
  };

  const evalCount = Math.min(12, Math.max(0, days.length - 4));
  let validTrials = 0;

  for (let t = 0; t < evalCount; t++) {
    const targetRow = days[t];
    const actual = targetRow[side];
    if (!actual) continue;
    validTrials++;
    const stepMaps = scoreLinesAtOffset(days, t + 1, targetRow.weekday, side, ALL_DIGITS);
    const recencyW = Math.pow(0.88, t);

    for (const line of lineNames) {
      const map = stepMaps[line];
      const top4 = [...ALL_DIGITS]
        .sort((a, b) => (map.get(b) || 0) - (map.get(a) || 0))
        .slice(0, 4);
      const hit = top4.includes(actual) && (map.get(actual) || 0) > 0;
      if (hit) {
        rawHits[line]++;
        weightedHits[line] += recencyW;
        if (t < 3) recent3Hits[line]++;
        streakBroken[line] = true;
      } else if (!streakBroken[line]) {
        missStreak[line]++;
      }
    }
  }

  // Today's live line projections (offset = 0)
  const todayRawLines = scoreLinesAtOffset(days, 0, targetWeekday, side, sourceTokens);
  const todayNormLines: Record<MarketLineName, Map<string, number>> = {
    'Kadi Line': normalizeMap(todayRawLines['Kadi Line'], sourceTokens),
    'Tirchi Line': normalizeMap(todayRawLines['Tirchi Line'], sourceTokens),
    'Jod-Fark': normalizeMap(todayRawLines['Jod-Fark'], sourceTokens),
    'Trikon': normalizeMap(todayRawLines['Trikon'], sourceTokens),
    'O-C Matrix': normalizeMap(todayRawLines['O-C Matrix'], sourceTokens),
  };

  // Calibrate dynamic weights per line for THIS specific market:
  const lineWeights: Record<MarketLineName, number> = {
    'Kadi Line': 0.2,
    'Tirchi Line': 0.2,
    'Jod-Fark': 0.2,
    'Trikon': 0.2,
    'O-C Matrix': 0.2,
  };
  const lineHitRates: Record<MarketLineName, number> = {
    'Kadi Line': 0,
    'Tirchi Line': 0,
    'Jod-Fark': 0,
    'Trikon': 0,
    'O-C Matrix': 0,
  };

  let regimeShifted = false;
  for (const line of lineNames) {
    const rate = validTrials > 0 ? rawHits[line] / validTrials : 0.35;
    lineHitRates[line] = Number(rate.toFixed(3));
    const maxRawToday = Math.max(0, ...sourceTokens.map(d => todayRawLines[line].get(d) || 0));
    const hasSignalToday = maxRawToday > 0.1;
    let w = (weightedHits[line] + 0.8) * (hasSignalToday ? 1.0 : 0.15);

    // Instant Regime-Shift Protection:
    // If a line failed 3+ times in a row in this market, slash its weight by 65%
    if (missStreak[line] >= 3) {
      w *= 0.35;
      if (rawHits[line] >= 5) regimeShifted = true;
    }
    // If a line hit >= 2 of the last 3 draws in this market, boost by 1.85x
    if (recent3Hits[line] >= 2) {
      w *= 1.85;
    } else if (recent3Hits[line] === 1 && missStreak[line] === 0) {
      w *= 1.35;
    }
    // Close market boost for O-C Matrix and Jod-Fark
    if (side === 'close' && (line === 'O-C Matrix' || line === 'Jod-Fark')) {
      w *= 1.18;
    }
    lineWeights[line] = Math.max(0.05, w);
  }

  // Normalize weights to sum to 1
  const totalW = lineNames.reduce((s, l) => s + lineWeights[l], 0) || 1;
  let winningLine: MarketLineName = 'Tirchi Line';
  let bestW = -1;
  for (const line of lineNames) {
    lineWeights[line] = Number((lineWeights[line] / totalW).toFixed(4));
    if (lineWeights[line] > bestW) {
      bestW = lineWeights[line];
      winningLine = line;
    }
  }

  // Multi-source stream consensus for this market
  const { streamBonus, bestStreams, lockCount } = computeMarketStreamConsensus(days, targetWeekday, side);
  const streamNorm = normalizeMap(streamBonus, sourceTokens);

  // Flow & Cold/Blocked digit tracking in this market with exponential heat acceleration
  const flowCounts = new Map<string, number>();
  const lastSeen = new Map<string, number>();
  for (let k = 0; k < Math.min(24, days.length); k++) {
    const d = days[k][side];
    if (d) {
      const heatMultiplier = k < 5 ? 1.85 * Math.pow(0.85, k) : Math.pow(0.91, k);
      flowCounts.set(d, (flowCounts.get(d) || 0) + heatMultiplier);
      if (!lastSeen.has(d)) lastSeen.set(d, k);
    }
  }

  const digitScores = new Map<string, number>();
  const crossLockCount = new Map<string, number>();

  for (let i = 0; i < sourceTokens.length; i++) {
    const d = sourceTokens[i];
    let lineComposite = 0;
    let linesAgreed = 0;
    for (const line of lineNames) {
      const nVal = todayNormLines[line].get(d) || 0;
      lineComposite += lineWeights[line] * nVal;
      if (nVal >= 0.50 && lineWeights[line] >= 0.15) linesAgreed++;
    }

    const sVal = streamNorm.get(d) || 0;
    const sLocks = lockCount.get(d) || 0;
    const totalLocks = linesAgreed + (sLocks >= 1 ? 1 : 0);
    crossLockCount.set(d, totalLocks);

    // Cross-Lock Master Bonus when both Market Chart Line and Market Top Streams lock on `d`
    const crossLockBonus = linesAgreed >= 3 && sLocks >= 1 ? 0.48 : (linesAgreed >= 2 && sLocks >= 1 ? 0.35 : (linesAgreed >= 1 && sLocks >= 1 ? 0.20 : 0));
    const flowBonus = Math.min(0.35, (flowCounts.get(d) || 0) * 0.08);
    const seenAt = lastSeen.get(d);
    // Hard-optimized cold penalty: absent for 10+ draws = dead trap!
    const coldPenalty = seenAt === undefined || seenAt >= 10 ? 0.50 : (seenAt >= 7 ? 0.25 : 0);
    const tieBreak = (sourceTokens.length - i) * 1e-4;

    const finalScore = 0.65 * lineComposite + 0.35 * sVal + crossLockBonus + flowBonus - coldPenalty + tieBreak;
    digitScores.set(d, finalScore);
  }

  const topHitRate = lineHitRates[winningLine] || 0;
  const maxLocks = Math.max(0, ...sourceTokens.map(d => crossLockCount.get(d) || 0));
  const confidenceGrade: 'A+' | 'A' | 'B' =
    topHitRate >= 0.45 && maxLocks >= 2 && !regimeShifted
      ? 'A+'
      : topHitRate >= 0.30 || maxLocks >= 1
        ? 'A'
        : 'B';

  return {
    winningLine,
    lineWeights,
    lineHitRates,
    digitScores,
    crossLockCount,
    regimeShifted,
    confidenceGrade,
    bestStreams,
  };
}
