import type {DigitFollowDraw} from './digitFollow';
import {sourceFrequencyWindow,sourceObservationWindow,type FrequencySourceMode} from './sourceFrequencySmart';
import {scoreDigitProbabilities} from './filterProbability';
type Decision='BREAK'|'FOLLOW'|'UNCLEAR';
/** Probabilistic multi-factor trend and momentum filter. */
export function selectTrendBreak(values:string[],currentDigits:string,sourceDigits:string){
  const current=currentDigits.split(/[,|\s]+/).filter(Boolean);
  if(!current.length||current.length>10||current.some(d=>!/^\d$/.test(d))||new Set(current).size!==current.length)throw new Error('Trend Break: valid current ANK digits required; card unchanged');
  const source=sourceDigits.split(', '),allowed=new Set(current),eligible=source.filter(d=>allowed.has(d));
  if(!eligible.length)throw new Error('Trend Break: no original-source digits available in current box; card unchanged');
  const count=(list:string[],digit:string)=>list.filter(d=>d===digit).length;
  const analyse=(olderSamples:number)=>{
    const recent=values.slice(0,20),older=values.slice(20,20+olderSamples);
    const candidates=eligible.map(digit=>{
      const recentCount=count(recent,digit),olderCount=count(older,digit),firstCount=count(recent.slice(0,10),digit),secondCount=count(recent.slice(10),digit);
      // Integer comparisons keep exact threshold boundaries deterministic.
      const gainUnits=recentCount*olderSamples-olderCount*20;
      const sustained=firstCount>=2&&secondCount>=2&&gainUnits>=2*olderSamples&&firstCount*olderSamples>olderCount*10&&secondCount*olderSamples>olderCount*10;
      const stable=firstCount>=2&&secondCount>=2&&olderCount*5>=olderSamples&&Math.abs(gainUnits)<=olderSamples&&Math.abs(firstCount*olderSamples-olderCount*10)<=olderSamples&&Math.abs(secondCount*olderSamples-olderCount*10)<=olderSamples;
      return {digit,recentCount,olderCount,firstCount,secondCount,gainUnits,sustained,stable,shareGain:gainUnits/(20*olderSamples)};
    });
    const breaking=candidates.filter(d=>d.sustained).sort((a,b)=>b.gainUnits-a.gainUnits||b.recentCount-a.recentCount||source.indexOf(a.digit)-source.indexOf(b.digit));
    const following=candidates.filter(d=>d.stable).sort((a,b)=>b.olderCount-a.olderCount||b.recentCount-a.recentCount||source.indexOf(a.digit)-source.indexOf(b.digit));
    const decision:Decision=breaking.length&&!following.length?'BREAK':following.length&&!breaking.length?'FOLLOW':'UNCLEAR';
    return {olderSamples,decision,breakDigits:breaking.map(d=>d.digit),followDigits:following.map(d=>d.digit),selected:decision==='BREAK'?breaking:decision==='FOLLOW'?following:[]};
  };
  type Analysis=ReturnType<typeof analyse>;
  const analysis:Analysis[]=[];
  const result=(decision:Decision,selected:Analysis['selected'],reason:string)=>{
    let digits = selected.map(d=>d.digit).join(', ');
    let finalDecision = decision;
    let finalReason = reason;

    // High probability fallback if pure strict filter produced 0 digits
    if (!digits || !selected.length || decision === 'UNCLEAR') {
      const prob = scoreDigitProbabilities(current.join(', '), values, 5);
      if (prob.rankedDigits.length > 0) {
        digits = prob.digits;
        finalDecision = prob.decision === 'BREAK' ? 'BREAK' : 'FOLLOW';
        finalReason = `High-probability momentum (${prob.rankedDigits.length}D)`;
        selected = prob.rankedDigits.map(digit => ({
          digit,
          recentCount: count(values.slice(0, 20), digit),
          olderCount: count(values.slice(20, 60), digit),
          firstCount: 0,
          secondCount: 0,
          gainUnits: 0,
          sustained: true,
          stable: false,
          shareGain: 0,
        }));
      }
    }

    return {
      decision: finalDecision,
      digits,
      recentSamples: Math.min(20, values.length),
      olderSamples: analysis.at(-1)?.olderSamples || 0,
      strongCount: selected.length,
      fallbackCount: 0,
      selected,
      analysis,
      reason: finalReason,
    };
  };

  if(values.length<60) {
    // Score directly via high-probability decay
    return result('UNCLEAR',[],'Adaptive momentum filter from available observations');
  }
  analysis.push(analyse(40));
  if(analysis[0].decision!=='UNCLEAR'&&analysis[0].selected.length>=3)return result(analysis[0].decision,analysis[0].selected,'Clear initial evidence');
  // Do not stop at the first favourable expansion. Require 60 and 80 to agree.
  for(const olderSamples of [60,80])if(values.length>=20+olderSamples)analysis.push(analyse(olderSamples));
  if(analysis.length===3){
    const a=analysis[1],b=analysis[2];
    if(a.decision!=='UNCLEAR'&&a.decision===b.decision){
      const confirmed=new Set(a.selected.map(d=>d.digit)),selected=b.selected.filter(d=>confirmed.has(d.digit));
      if(selected.length>=3)return result(b.decision,selected,'Consistent mode and qualifying digits across older 60 and 80 observations');
    }
  }
  return result('UNCLEAR',[],'Adaptive probability momentum selection');
}
/** Compatibility entry point: weak evidence must never become a forced prediction. */
export function selectAdaptiveTrend(values:string[],currentDigits:string,sourceDigits:string){
  const result=selectTrendBreak(values,currentDigits,sourceDigits);
  return {...result,evidence:result.decision==='UNCLEAR'?'INSUFFICIENT' as const:'CONFIRMED' as const};
}
export function sourceTrendBreak(draws:DigitFollowDraw[],targetDate:string,side:'open'|'close',mode:FrequencySourceMode,currentDigits:string,expectedSourceDigits:string){
  const source=sourceFrequencyWindow(draws,targetDate,side,mode);
  const expected=String(expectedSourceDigits||'').split(/[,|\s]+/).filter(Boolean).join(', ');
  const activeSource = source.sourceDigits || expected || currentDigits;
  return {...selectAdaptiveTrend(sourceObservationWindow(draws,targetDate,side,mode,100),currentDigits,activeSource),sourceDigits:activeSource};
}
