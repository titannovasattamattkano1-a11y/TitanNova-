/**
 * Accept chart layouts from the ONE configured chart publisher:
 *  - historical charts with 3 cells per day: OPEN / JODI / CLOSE
 *  - compact weekly charts with one cell per day: "2 6 9 78 1 2 5"
 *
 * Expand only independently dated weekly rows. A missing/partial day remains a
 * triple of placeholders, so the next day's values can never shift columns.
 * This transforms in-memory HTML for parsing; no second website is fetched.
 */
export function normalizeProviderChartHtml(html: string): string {
  if (!/<table\b/i.test(html)) return html;
  const text = (value: string) => value
    .replace(/<br\s*\/?\s*>/gi, ' ')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;|&#160;/gi, ' ')
    .replace(/&mdash;|&ndash;|&#8212;|&#8211;/gi, ' — ')
    .replace(/\s+/g, ' ').trim();
  const week = /^\d{1,2}\s*[/-]\s*\d{1,2}\s*[/-]\s*\d{2,4}\s+to\s+\d{1,2}\s*[/-]\s*\d{1,2}\s*[/-]\s*\d{2,4}$/i;
  let conversions = 0;
  const out = html.replace(/<tr\b[^>]*>[\s\S]*?<\/tr\s*>/gi, row => {
    const cells = [...row.matchAll(/<t[dh]\b[^>]*>([\s\S]*?)<\/t[dh]\s*>/gi)];
    if (cells.length < 3 || cells.length > 8 || !week.test(text(cells[0][1]))) return row;
    const read = cells.slice(1).map(cell => text(cell[1]));
    const compact = (value: string): string[] | null => {
      // 269 78 125, 2 6 9 78 1 2 5, or markup with separate spans.
      const match = value.match(/^(\d)\s*(\d)\s*(\d)\s+(\d{2})\s+(\d)\s*(\d)\s*(\d)$/)
        || value.match(/^(\d{3})\s+(\d{2})\s+(\d{3})$/)
        || value.match(/^(\d{3})\s*[-–—|/]\s*(\d{2})\s*[-–—|/]\s*(\d{3})$/);
      if (!match) return null;
      return match.length === 8
        ? [match.slice(1, 4).join(''), match[4], match.slice(5, 8).join('')]
        : [match[1], match[2], match[3]];
    };
    // Don't rewrite conventional 3-cell charts or unrelated tables.
    if (!read.some(value => compact(value))) return row;
    const expanded = read.flatMap(value => compact(value) || ['***', '**', '***']);
    conversions++;
    return `<tr><td>${text(cells[0][1])}</td>${expanded.map(value => `<td>${value}</td>`).join('')}</tr>`;
  });
  return conversions ? out : html;
}
