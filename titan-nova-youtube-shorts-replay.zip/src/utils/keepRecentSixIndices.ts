import {resolveSourceIndexCell,type SourceIndexHistory} from './sourceIndexHistory';
import {cutCurrentSourceDigits} from './cumulativeSourceCut';
import type {DayMarketRecord,UserProfile} from '../types';
import {findHistoricalMarketRecord} from './cardHistory';
import {getScrapeSource} from './scrapeProvenance';
import {isMirrorProtected} from './adminMirror';
import {canReplaceLiveCombinedDecision,releaseLiveCombinedDecision} from './liveCombinedDecision';

/** Latest six distinct positions from actual earlier PASS/FAIL cards, including older gaps. */
export function recentSixUniqueIndices(days:UserProfile['dayRecords'],date:string,index:number,market:string,shared?:SourceIndexHistory):number[] {
  return recentUniqueSourceIndices(days,date,index,market,6,shared);
}

const recentIndicesDateCache = new WeakMap<object, { count: number; sorted: string[] }>();
const recentUniqueResultCache = new WeakMap<object, { shared: SourceIndexHistory | undefined; dayCount: number; map: Map<string, number[]> }>();
function getValidSortedDaysDesc(obj: Record<string, unknown> | undefined): string[] {
  if (!obj || typeof obj !== "object") return [];
  const rawKeys = Object.keys(obj);
  let cached = recentIndicesDateCache.get(obj);
  if (!cached || cached.count !== rawKeys.length) {
    cached = { count: rawKeys.length, sorted: rawKeys.filter(d=>/^\d{4}-\d{2}-\d{2}$/.test(d)&&Number.isFinite(Date.parse(d))&&new Date(d).toISOString().slice(0,10)===d).sort().reverse() };
    recentIndicesDateCache.set(obj, cached);
  }
  return cached.sorted;
}

export function recentUniqueSourceIndices(days:UserProfile['dayRecords'],date:string,index:number,market:string,count:4|6,shared?:SourceIndexHistory):number[] {
  const dayCount = days ? Object.keys(days).length : 0;
  let rEntry = days ? recentUniqueResultCache.get(days) : undefined;
  if (days && (!rEntry || rEntry.shared !== shared || rEntry.dayCount !== dayCount)) {
    rEntry = { shared, dayCount, map: new Map() };
    recentUniqueResultCache.set(days, rEntry);
  }
  const rKey = `${date}|${index}|${market}|${count}`;
  if (rEntry && rEntry.map.has(rKey)) return rEntry.map.get(rKey)!;
  const found:number[]=[];
  const ownDays = getValidSortedDaysDesc(days);
  const sharedDays = getValidSortedDaysDesc(shared);
  const allDays = sharedDays.length ? [...new Set([...ownDays, ...sharedDays])].sort().reverse() : ownDays;
  for(const day of allDays){
    if (day >= date) continue;
    const rec=findHistoricalMarketRecord(days[day]?.data,index,market);
    const cell=resolveSourceIndexCell(rec,shared?.[day]?.[market.trim().toUpperCase()]);
    if(cell?.status!=='PASS'&&cell?.status!=='FAIL')continue;
    const position=cell.index;
    if(position!==undefined&&Number.isInteger(position)&&position>=1&&position<=10&&!found.includes(position))found.push(position);
    if(found.length===count)break;
  }
  if (rEntry) rEntry.map.set(rKey, found);
  return found;
}

/** Full source selects six original positions; partial sources intersect available/current digits. */
export function keepRecentSixIndices(record:DayMarketRecord|undefined,indices:number[]):DayMarketRecord|undefined {
  if(!record||!canReplaceLiveCombinedDecision(record)||isMirrorProtected(record)||record.dispatchState||record.deliveryRestoredAt||record.s==='SKIP')return undefined;
  const source=getScrapeSource(record);if(!source)return undefined;
  const original=source.digits.split(', '),partial=original.length<10;
  if(!indices.length||indices.length>6||(!partial&&indices.length!==6)||new Set(indices).size!==indices.length||!indices.every(i=>Number.isInteger(i)&&i>=1&&i<=10))return;
  const keep=new Set(indices),current=new Set(record.d.split(/[,|\s]+/).filter(Boolean));
  const digits=original.filter((digit,i)=>keep.has(i+1)&&(!partial||current.has(digit))).join(', ');
  if(!digits)return;

  if(record.positionRule==='RECENT6'&&record.d.split(/[,|\s]+/).filter(Boolean).join(', ')===digits)return undefined;
  const next:DayMarketRecord={...record,s:'WAIT',d:digits,od:source.digits,scrapeSource:source,positionRule:'RECENT6',sourceEditedAt:Math.max(Date.now(),Number(record.sourceEditedAt||0)+1,Number(record.marketModel?.updatedAt||0)+1)};
  releaseLiveCombinedDecision(next);
  delete next.trick;delete next.weekdaySelectedDigits;delete next.weekdayHitPosition;
  delete next.scrapeResultDigit;delete next.manualResult;delete next.manualResultSources;delete next.backtestResult;
  delete next.marketModel;delete next.autoRemovedResult;delete next.autoResultParity;
  if(!next.manualRate){delete next.recRate;delete next.prevLoss;delete next.targetProfitWithLoss;delete next.rateFinalizedFrom;delete next.rateFinalizedAt;}
  return next;
}

/** Cut four original-source target digits only if still selected. Keep6 remains a source selector. */
export function removeRecentFourIndices(record:DayMarketRecord|undefined,indices:number[],noOpAsRecord=false):DayMarketRecord|undefined {
  const source=getScrapeSource(record);if(!source)return;
  const original=source.digits.split(', ');
  if(!indices.length||indices.length>4||(original.length===10&&indices.length!==4)||new Set(indices).size!==indices.length||!indices.every(i=>Number.isInteger(i)&&i>=1&&i<=10))return;

  return cutCurrentSourceDigits(record,indices.flatMap(i=>original[i-1]?[original[i-1]]:[]),'RECENT4',noOpAsRecord);
}
