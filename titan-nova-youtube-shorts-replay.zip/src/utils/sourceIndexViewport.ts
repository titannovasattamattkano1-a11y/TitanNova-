/** Display only: bound mounted history pages without removing any saved date. */
export function sourceIndexViewport(scrollTop:number,pageHeight:number,pageCount:number):{start:number;end:number}{
 const count=Math.max(0,Math.floor(pageCount));
 if(!count)return {start:0,end:0};
 const position=Number.isFinite(scrollTop)&&pageHeight>0?Math.floor(Math.max(0,-scrollTop)/pageHeight):0;
 const page=Math.min(count-1,Math.max(0,position));
 return {start:Math.max(0,page-2),end:Math.min(count,page+3)};
}
