import { panelAnkDigit } from './panelAnk';
import { resolveAmbiguousMarketByIST, type MonitorResultShape } from './resultMonitoring';

/** A declaration must belong to one market and agree with its drawn Pattis. */
export function automaticResultError(text: string, result: MonitorResultShape): string | undefined {
  const cleaned = String(text || '').toUpperCase().replace(/[\u200B-\u200D\uFEFF*]/g, '').replace(/\s+/g, ' ');
  const names = cleaned.match(/\b(?:SHRIDEVI|SRIDEVI|SRIDEV|MADHUR|MILAN|RAJDHANI|SUPREME)(?:\s+(?:DAY|NIGHT))?\b|\bKALYAN(?:\s+NIGHT)?\b|\b(?:TIME|MAIN)\s+BAZAR\b/g) || [];
  const normalized = names.map(name => name.replace(/^(SHRIDEVI|SRIDEV)\b/, 'SRIDEVI'));
  const markets = new Set(normalized.map(name => resolveAmbiguousMarketByIST(name)));
  if (markets.size > 1) return 'Multiple markets in one result message; send each market result separately';
  if (!result.marketBase || !(result.openAnk || result.closeAnk || result.jodi)) return 'Unrecognized actual market result';
  for (const [panel, ank, label] of [[result.openPanel, result.openAnk, 'OPEN'], [result.closePanel, result.closeAnk, 'CLOSE']]) {
    if (ank && !/^\d$/.test(ank)) return `Invalid ${label} ANK result`;
    if (panel && (!/^\d{3}$/.test(panel) || !ank || panelAnkDigit(panel) !== ank)) return `${label} Panel patti does not match declared ANK`;
  }
  if (result.jodi && (!/^\d{2}$/.test(result.jodi) || result.openAnk !== result.jodi[0] || result.closeAnk !== result.jodi[1])) return 'Invalid or conflicting JODI result';
  return undefined;
}
