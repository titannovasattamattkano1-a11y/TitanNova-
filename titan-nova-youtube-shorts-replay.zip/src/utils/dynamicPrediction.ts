import { chooseAnkRankingByBacktest, type AnkRankingMode, type AnkStrategyResult } from './ankAdaptive';
import { choosePanelRankingByBacktest, isSinglePatti, normalizeAnkDigits, normalizePanelPatti, selectGapRotationPanels, type PanelRankingMode, type PanelStrategyResult } from './panelAnk';

export type PredictionConfidence = 'insufficient' | 'low' | 'medium' | 'high';

const MAX_PREDICTION_CACHE_ENTRIES = 128;
const ankPredictionCache = new Map<string, DynamicAnkPrediction>();
const panelPredictionCache = new Map<string, DynamicPanelPrediction>();

// OPTIMIZATION: Reuse identical chart backtests across Admin/VIP requests and cap memory with LRU eviction.
function cacheSet<T>(cache: Map<string, T>, key: string, value: T): void {
  if (cache.has(key)) cache.delete(key);
  cache.set(key, value);
  while (cache.size > MAX_PREDICTION_CACHE_ENTRIES) cache.delete(cache.keys().next().value as string);
}

function cacheGet<T>(cache: Map<string, T>, key: string): T | undefined {
  const value = cache.get(key);
  if (!value) return undefined;
  cache.delete(key);
  cache.set(key, value);
  return value;
}

const rankedScores = <T extends string>(scores: Record<T, number>) =>
  (Object.entries(scores) as Array<[T, number]>).sort((a, b) => b[1] - a[1]);

function confidence(samples: number, passPercent: number, margin: number): PredictionConfidence {
  if (samples < 120) return 'insufficient';
  if (passPercent >= 60 && margin >= 3) return 'high';
  if (passPercent >= 55 && margin >= 1) return 'medium';
  return 'low';
}

export interface DynamicAnkPrediction extends AnkStrategyResult {
  engine: 'dynamic_precutoff_v1';
  runnerUpMode: AnkRankingMode;
  scoreMargin: number;
  confidence: PredictionConfidence;
  historySize: number;
}

/** Daily ANK prediction. Every strategy score is calculated from past-only walk-forward samples. */
export function buildDynamicAnkPrediction(recentToOld: unknown[]): DynamicAnkPrediction {
  const validHistory = recentToOld.map((value) => String(value ?? '').trim()).filter((value) => /^\d$/.test(value));
  const cacheKey = validHistory.join('');
  const cached = cacheGet(ankPredictionCache, cacheKey);
  // OPTIMIZATION: Clone cached arrays/maps so an API consumer cannot mutate shared prediction state.
  if (cached) return { ...cached, digits: [...cached.digits], scores: { ...cached.scores } };
  const strategy = chooseAnkRankingByBacktest(recentToOld);
  const ranking = rankedScores(strategy.scores);
  const selectedIndex = ranking.findIndex(([mode]) => mode === strategy.mode);
  const selectedScore = strategy.scores[strategy.mode] || 0;
  const runnerUp = ranking.find(([mode]) => mode !== strategy.mode) || ranking[selectedIndex] || [strategy.mode, selectedScore];
  const scoreMargin = Number(Math.max(0, selectedScore - runnerUp[1]).toFixed(2));
  const prediction: DynamicAnkPrediction = {
    ...strategy,
    engine: 'dynamic_precutoff_v1',
    runnerUpMode: runnerUp[0],
    scoreMargin,
    confidence: confidence(strategy.samples, strategy.passPercent, scoreMargin),
    historySize: validHistory.length,
  };
  cacheSet(ankPredictionCache, cacheKey, prediction);
  return { ...prediction, digits: [...prediction.digits], scores: { ...prediction.scores } };
}

export interface DynamicPanelPrediction {
  engine: 'dynamic_precutoff_v1';
  panels: string[];
  strategy: PanelStrategyResult;
  runnerUpMode: PanelRankingMode;
  scoreMargin: number;
  confidence: PredictionConfidence;
  historySize: number;
}

/** Single Panel authority: strategy choice and Patti selection share the exact same cutoff history. */
export function buildDynamicPanelPrediction(recentToOld: unknown[], ankDigits: unknown): DynamicPanelPrediction {
  const normalizedHistory = recentToOld.map((value) => normalizePanelPatti(value)).filter((value): value is string => Boolean(value));
  const normalizedAnks = normalizeAnkDigits(ankDigits).sort();
  const cacheKey = `${normalizedAnks.join('')}|${normalizedHistory.join(',')}`;
  const cached = cacheGet(panelPredictionCache, cacheKey);
  // OPTIMIZATION: Return isolated copies while sharing the expensive past-only backtest result.
  if (cached) return { ...cached, panels: [...cached.panels], strategy: { ...cached.strategy, scores: { ...cached.strategy.scores } } };
  const strategy = choosePanelRankingByBacktest(recentToOld);
  const ranking = rankedScores(strategy.scores);
  const selectedScore = strategy.scores[strategy.mode] || 0;
  const runnerUp = ranking.find(([mode]) => mode !== strategy.mode) || [strategy.mode, selectedScore];
  const scoreMargin = Number(Math.max(0, selectedScore - runnerUp[1]).toFixed(2));
  const prediction: DynamicPanelPrediction = {
    engine: 'dynamic_precutoff_v1',
    // BUG FIX: Canonical ANK order makes identical sets produce identical balanced Panel output/cache keys.
    panels: selectGapRotationPanels(recentToOld, normalizedAnks, {
      cooldown: 10,
      limit: 30,
      minOutput: 10,
      rankingMode: strategy.mode,
    }),
    strategy,
    runnerUpMode: runnerUp[0],
    scoreMargin,
    confidence: confidence(strategy.samples, strategy.passPercent, scoreMargin),
    historySize: normalizedHistory.filter((value) => isSinglePatti(value)).length,
  };
  cacheSet(panelPredictionCache, cacheKey, prediction);
  return { ...prediction, panels: [...prediction.panels], strategy: { ...prediction.strategy, scores: { ...prediction.strategy.scores } } };
}

// BUG FIX: Tests and controlled refreshes can clear cached decisions without restarting the server.
export function clearDynamicPredictionCache(): void {
  ankPredictionCache.clear();
  panelPredictionCache.clear();
}
