import type {DayMarketRecord} from '../types';
/** Scope protection/cleanup to the new live decision; legacy strategy rules stay intact. */
export function canReplaceLiveCombinedDecision(record:DayMarketRecord|undefined):boolean {
  return !record?.liveCombinedCut||!(record.manualStatus||record.sentRate||record.sentDigits||record.dispatchState||record.deliveryRestoredAt||record.s==='PASS'||record.s==='FAIL');
}
/** An explicit replacement starts a fresh source policy, never a second cut. */
export function releaseLiveCombinedDecision(record:DayMarketRecord):void {
  if(!record.liveCombinedCut||!canReplaceLiveCombinedDecision(record))return;
  if(record.s==='SKIP'&&record.liveCombinedCut.reason)record.s='WAIT';
  delete record.liveCombinedCut;delete record.autoRemovedResult;
  record.sourceEditedAt=Math.max(Date.now(),Number(record.sourceEditedAt||0)+1);
  if(!record.manualRate){delete record.recRate;delete record.prevLoss;delete record.targetProfitWithLoss;delete record.rateFinalizedFrom;delete record.rateFinalizedAt;}
}
