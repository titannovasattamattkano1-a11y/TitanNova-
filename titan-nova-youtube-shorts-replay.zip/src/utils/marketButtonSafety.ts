import {isChartProviderUrl} from './chartSource';
/** Search should not hide a valid market because of a copied trailing space. */
export function marketNameMatchesSearch(name:string,query:string):boolean {
  return String(name||'').toLocaleLowerCase().includes(String(query||'').trim().toLocaleLowerCase());
}
/** An Auto Detect preview must match the exact currently selected provider URL. */
export function previewMatchesCurrentChart(previewUrl:string,currentUrl:string):boolean {
  if(!isChartProviderUrl(previewUrl)||!isChartProviderUrl(currentUrl))return false;
  try{return new URL(previewUrl).href===new URL(currentUrl).href;}catch{return false;}
}

/** Reject blank, NaN or out-of-range market times before writing config. */
export function validMarketTime(hr:number,min:number):boolean {
  return Number.isInteger(hr)&&hr>=0&&hr<=23&&Number.isInteger(min)&&min>=0&&min<=59;
}
