import type { UserProfile } from '../types';
import { getEffectiveMarkets, getEffectiveBaseMarkets } from '../data/markets';
import { businessDateIST } from './businessDate';

/** Freeze the live entry boundary once; historical trials do not use this gate. */
export function createVipLiveStart(config: UserProfile['config'], admin?: UserProfile, now = new Date()) {
  const date = businessDateIST(now);
  const parts = new Intl.DateTimeFormat('en-GB', {timeZone:'Asia/Kolkata',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(now);
  const hour = Number(parts.find(p=>p.type==='hour')?.value);
  const minute = Number(parts.find(p=>p.type==='minute')?.value);
  const clock = (h:number,m:number) => (h<6?1440:0)+h*60+m;
  const elapsed = clock(hour,minute);
  const markets = getEffectiveMarkets(config);
  const adminMarkets = admin ? getEffectiveMarkets(admin.config) : [];
  const completed = (name:string) => {
    const idx=adminMarkets.findIndex(m=>m.n===name);
    const rec=admin?.dayRecords?.[date]?.data?.[idx];
    return rec?.s==='PASS'||rec?.s==='FAIL'||Boolean(rec?.scrapeResultDigit||rec?.manualResult);
  };
  const past = (m:{n:string;hr?:number;min?:number}) => (Number.isFinite(m.hr) && Number.isFinite(m.min) && clock(m.hr!,m.min!)<=elapsed) || completed(m.n);
  const excluded:Record<string,string[]> = {
    ank:markets.filter(past).map(m=>m.n),
    pannel:markets.filter(past).map(m=>m.n),
    jodi:getEffectiveBaseMarkets(config).filter(m=>{
      const open=markets.find(x=>x.n===`${m.n} OPEN`);
      return open ? past(open) : false;
    }).map(m=>m.n),
  };
  return {createdAt:now.getTime(),date,excluded};
}
export function vipLiveMarketEligible(profile: Pick<UserProfile,'vipLiveStart'>, date:string, type:string, name:string, now = new Date()):boolean {
  const start=profile.vipLiveStart;
  return !start || date !== businessDateIST(now) || date !== start.date || !start.excluded[type]?.includes(name);
}
