import { GameType } from '../types';
import { BASE_MARKETS } from '../data/markets';

export interface SmartExtractedData {
  marketName: string;
  phase: 'OPEN' | 'CLOSE';
  gameType: GameType;
  digits: string[];
  investAmount?: number;
}

export function parseRawTextToMarketData(textRaw: string, defaultType: GameType = 'ank'): SmartExtractedData[] {
  if (!textRaw.trim()) return [];

  const results: SmartExtractedData[] = [];
  const lines = textRaw.toUpperCase().replace(/[^A-Z0-9\s,:;|\-⬆️⬇️₹]/g, ' ').split('\n');
  
  let currentBaseMarket = '';
  let currentPhase: 'OPEN' | 'CLOSE' = 'OPEN';
  const sortedMarkets = [...BASE_MARKETS].sort((a, b) => b.n.length - a.n.length);

  for (const line of lines) {
    let foundMarket = '';
    for (const bm of sortedMarkets) {
      if (line.includes(bm.n)) {
        foundMarket = bm.n;
        break;
      }
    }

    if (!foundMarket) {
      if (line.includes('SRIDEVI') || line.includes('SRIDEV')) foundMarket = 'SRIDEVI';
      else if (line.includes('MADHUR')) foundMarket = 'MADHUR DAY';
      else if (line.includes('MILAN')) foundMarket = 'MILAN DAY';
      else if (line.includes('RAJDHANI')) foundMarket = 'RAJDHANI DAY';
      else if (line.includes('SUPREME')) foundMarket = 'SUPREME DAY';
      else if (line.includes('KALYAN')) foundMarket = 'KALYAN';
      else if (line.includes('TIME')) foundMarket = 'TIME BAZAR';
      else if (line.includes('MAIN BAZAR') || line.includes('MAIN')) foundMarket = 'MAIN BAZAR';
    }

    if (foundMarket) {
      currentBaseMarket = foundMarket;
      currentPhase = 'OPEN';
    }

    if (currentBaseMarket) {
      if (line.includes('NIGHT') || line.includes('NIT') || line.includes('NITE')) {
        if (currentBaseMarket.includes('SRIDEV')) currentBaseMarket = 'SRIDEVI NIGHT';
        else if (currentBaseMarket === 'KALYAN') currentBaseMarket = 'KALYAN NIGHT';
        else if (currentBaseMarket.includes('MADHUR')) currentBaseMarket = 'MADHUR NIGHT';
        else if (currentBaseMarket.includes('MILAN')) currentBaseMarket = 'MILAN NIGHT';
        else if (currentBaseMarket.includes('RAJDHANI')) currentBaseMarket = 'RAJDHANI NIGHT';
        else if (currentBaseMarket.includes('SUPREME')) currentBaseMarket = 'SUPREME NIGHT';
      } else if (line.includes('DAY') || line.includes('MORNING')) {
        if (currentBaseMarket.includes('SRIDEVI NIGHT')) currentBaseMarket = 'SRIDEVI';
        else if (currentBaseMarket === 'KALYAN NIGHT') currentBaseMarket = 'KALYAN';
        else if (currentBaseMarket.includes('MADHUR NIGHT')) currentBaseMarket = 'MADHUR DAY';
        else if (currentBaseMarket.includes('MILAN NIGHT')) currentBaseMarket = 'MILAN DAY';
        else if (currentBaseMarket.includes('RAJDHANI NIGHT')) currentBaseMarket = 'RAJDHANI DAY';
        else if (currentBaseMarket.includes('SUPREME NIGHT')) currentBaseMarket = 'SUPREME DAY';
      }
    }

    if (line.includes('CLOSE') || line.includes('⬇️') || line.includes('CL')) {
      currentPhase = 'CLOSE';
    } else if (line.includes('OPEN') || line.includes('⬆️') || line.includes('OP')) {
      currentPhase = 'OPEN';
    }

    if (!currentBaseMarket) continue;

    const cleanLine = line
      .replace(/\d{1,2}:\d{2}/g, '')
      .replace(/(RATE|INVEST|RS|₹|PRICE|AMT|AMOUNT|INV|INVESTMENT)[\s:=]*\d+/g, '');

    const digitMatches = cleanLine.match(/\d+/g);
    if (!digitMatches) continue;

    let validDigits: string[] = [];
    if (defaultType === 'ank') {
      validDigits = digitMatches.filter(n => n.length === 1);
    } else if (defaultType === 'jodi') {
      validDigits = digitMatches.filter(n => n.length === 2);
    } else if (defaultType === 'pannel') {
      validDigits = digitMatches.filter(n => n.length === 3);
    }

    if (validDigits.length > 0) {
      results.push({
        marketName: currentBaseMarket,
        phase: currentPhase,
        gameType: defaultType,
        digits: validDigits
      });
    }
  }

  return results;
}
