/** Accept unique genuine one-digit ANK tokens from string or array input. */
export function normalizeAnkDigits(raw: unknown): string[] {
  const values = Array.isArray(raw) ? raw : [raw];
  const tokens = values.flatMap((value) => String(value ?? '').split(/[\s,;|/]+/));
  return [...new Set(tokens.map((token) => token.trim()).filter((token) => /^\d$/.test(token)))];
}
