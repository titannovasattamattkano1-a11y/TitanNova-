import {cacheBacktestActual,isFreshBacktestActual,type CachedBacktestActual,type DatedActual} from './backtestResult';

/** Share exact-date lookups across individual cards and automatic checks. */
export function lookupBacktestActual(options:{
 key:string;date:string;cache:Map<string,CachedBacktestActual>;
 pending:Map<string,Promise<DatedActual|null|undefined>>;
 explicit?:boolean;
 fetcher:()=>Promise<{status:string;targetDate?:string;actual?:DatedActual|null;staleCache?:boolean;message?:string}>;
}):Promise<DatedActual|null|undefined>{
 const {key,date,cache,pending}=options,cached=cache.get(key),row=cached?.actual;
 // An explicit click retries missing/partial/error results immediately.
 // Manual Test Result must revalidate the publisher, even if a complete draw was
 // previously cached. Automatic refreshes retain their bounded cache policy.
 if(!options.explicit&&isFreshBacktestActual(cached)&&(!row||row.date===date))return Promise.resolve(row);
 const existing=pending.get(key);if(existing)return existing;
 const request=Promise.resolve().then(options.fetcher).then(reply=>{
  if(reply.staleCache)throw new Error('Cached chart is stale; fresh exact-date result required. Card unchanged; retry when provider is online.');
  if(reply.status!=='success'||reply.targetDate!==date||(reply.actual&&reply.actual.date!==date))throw new Error(reply.message||'Exact-date result unavailable');
  const actual=reply.actual||null;
  if(pending.get(key)===request)cache.set(key,cacheBacktestActual(actual,Date.now(),date));
  return actual;
 }).catch(error=>{
  if(pending.get(key)===request)cache.set(key,cacheBacktestActual(undefined));
  throw error;
 }).finally(()=>{if(pending.get(key)===request)pending.delete(key);});
 pending.set(key,request);return request;
}
