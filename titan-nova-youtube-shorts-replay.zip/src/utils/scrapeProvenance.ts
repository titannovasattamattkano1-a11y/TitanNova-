import { CARD_SOURCE_MODES, type DayMarketRecord } from '../types';
export type ScrapeSource = NonNullable<DayMarketRecord['scrapeSource']>;
type ScrapeRecord = Partial<Pick<DayMarketRecord, 'autoRemovedResult' | 'sourceEditedAt' | 'marketModel' | 'liveCombinedCut' | 'backtestSkipHistory' | 'backtestResult' | 'scrapeSource' | 'sentScrapeSource' | 'scrapeResultDigit' | 'sourceMode' | 'sentSourceMode' | 'od' | 'sentRate' | 'sentDigits' | 'd' | 'weekdaySelectedDigits' | 'weekdayHitPosition' | 'manualStatus' | 'manualResult'>> & { s?: string; carryResultSix?: { spectrum?: string; history?: Array<{ actual: string }>; output?: string } };
export function normalizeScrapeSource(value: unknown): ScrapeSource | undefined {
  if (!value || typeof value !== 'object') return undefined;
  const source = value as Partial<ScrapeSource>;
  if (!source.mode || source.mode === 'MANUAL' || !CARD_SOURCE_MODES.includes(source.mode)) return undefined;
  const digits = String(source.digits || '').split(/[,|\s]+/).filter(Boolean);
  if (digits.length < 1 || digits.length > 10 || new Set(digits).size !== digits.length || !digits.every(d => /^\d$/.test(d))) return undefined;
  return { mode: source.mode, digits: digits.join(', ') };
}
/** Fixed-ten comparison algorithms retain their original contract. */
export function normalizeFullScrapeSource(value:unknown):ScrapeSource|undefined {
  const source=normalizeScrapeSource(value);
  return source?.digits.split(', ').length===10?source:undefined;
}
export function getFullScrapeSource(record:ScrapeRecord|undefined):ScrapeSource|undefined {
  return normalizeFullScrapeSource(getScrapeSource(record));
}
/** Never manufacture ten positions from a six-digit selection or manual status. */
export function getScrapeSource(record: ScrapeRecord | undefined): ScrapeSource | undefined {
  if (!record) return undefined;
  const sent = normalizeScrapeSource(record.sentScrapeSource);
  if (sent) return sent; // Delivered provenance remains frozen independently.
  const saved = normalizeScrapeSource(record.scrapeSource);
  const mode = record.sentSourceMode || record.sourceMode;
  // A manual/new source must not inherit an old AUTO scrapeSource accidentally
  // left by a stale backend acknowledgement or a restored legacy card.
  if (!record.sentRate && !record.sentDigits && record.sourceMode === 'MANUAL') return undefined;
  // Follow sources can start with fewer than ten digits. A later Mirror Add or
  // selection edit reaching ten does not prove ten original source positions.
  if (mode === 'PAIR_FOLLOW' || mode === 'PAIR_COMBO' || mode === 'MSSD' || mode === 'DIGIT_FOLLOW' || mode === 'PANNA_FOLLOW' || mode === 'FLOW_3_1' || mode === 'FREQ_10' || mode === 'FREQ_10_COMBO') return saved?.mode === mode ? saved : undefined;
  if (saved && (!mode || saved.mode === mode)) return saved;
  if (saved && mode === 'SELF_LEARNING') return { mode: 'SELF_LEARNING', digits: saved.digits };
  if (saved && mode && saved.mode !== mode) return undefined;
  // Legacy cards may retain the exact ten-digit source in od.
  const legacy = normalizeFullScrapeSource({ mode, digits: record.od || record.sentDigits || record.d });
  if (legacy) return legacy;
  // A current automatic result cut still owns its original source. Never infer
  // positions from the shortened selection, or revive an overlay after an edit.
  const overlay = record.autoRemovedResult;
  const version = Math.max(Number(record.sourceEditedAt || 0), Number(record.marketModel?.updatedAt || 0));
  if (!record.sentDigits && overlay && record.d === overlay.output &&
      (overlay.outputVersion === undefined || overlay.outputVersion === version)) {
    return normalizeFullScrapeSource({ mode, digits: overlay.input });
  }

  // Result Carry (Carry 10) provenance from spectrum or card digits:
  const carry = record.carryResultSix;
  if (carry?.spectrum) {
    const spec = carry.spectrum;
    const specDigits = spec.includes(',') ? spec.split(/[,|\s]+/).filter(Boolean) : spec.split('');
    if (specDigits.length === 10) {
      return { mode: 'RESULT_CARRY6', digits: specDigits.join(', ') };
    }
  }
  if ((record?.sourceMode === 'RESULT_CARRY6' || carry) && record?.d) {
    const dDigits = record.d.split(/[,|\s]+/).filter(Boolean);
    if (dDigits.length === 10) {
      return { mode: 'RESULT_CARRY6', digits: dDigits.join(', ') };
    }
  }

  return undefined;
}
export function getScrapeResultIndex(record: ScrapeRecord | undefined): number | undefined {
  const source = getScrapeSource(record);
  if(record?.s==='SKIP'&&record.liveCombinedCut?.observation&&!record.manualStatus){
    const observed=record.liveCombinedCut.observation;
    const index=source&&/^\d$/.test(observed.actual)?source.digits.split(', ').indexOf(observed.actual)+1:0;
    return index>0&&index===observed.sourceIndex?index:undefined;
  }
  if(record?.s==='SKIP'&&record.backtestSkipHistory&&!record.manualStatus){
    const history=record.backtestSkipHistory;
    const index=source&&/^\d$/.test(history.actual||'')?source.digits.split(', ').indexOf(history.actual!)+1:0;
    return index>0&&index===history.sourceIndex?index:undefined;
  }
  const result = getScrapeResultDigit(record);
  if (!source || result === undefined || (record?.s !== 'PASS' && record?.s !== 'FAIL')) return undefined;
  const index = source.digits.split(', ').indexOf(result);
  return index >= 0 ? index + 1 : undefined;
}
export function getScrapeResultDigit(record: ScrapeRecord | undefined): string | undefined {
  if (record?.manualStatus) return /^\d$/.test(String(record.manualResult || '')) ? record.manualResult : undefined;
  if (/^[0-9]$/.test(String(record?.scrapeResultDigit || ''))) return record!.scrapeResultDigit;
  // Older restored/saved trials can retain the checked result without its duplicate index hint.
  const trial=record?.backtestResult;
  if((record?.s==='PASS'||record?.s==='FAIL')&&trial?.checked&&trial.digits===record.d&&/^[0-9]$/.test(String(trial.actual??'')))return String(trial.actual);
  // Old automatic Weekday hits recorded the actual winning position among six.
  // Recover that digit, then map it back to the original TEN positions above.
  if (record?.manualStatus || record?.s !== 'PASS') return undefined;
  const selected = String(record.weekdaySelectedDigits || '').split(/[,|\s]+/).filter(Boolean);
  const position = record.weekdayHitPosition;
  if (selected.length !== 6 || !selected.every(d => /^\d$/.test(d)) || !Number.isInteger(position) || position! < 1 || position! > 6) return undefined;
  return selected[position! - 1];
}
