import {activeLoopIds,assignedLoop,normalizeDualLoops,loopSettingsForDate,LOOP_GAMES,gameAccountLimits,type DualLoopConfig,type LoopId} from './dualLoops';
import {calculateSettlement} from './settlement';
import type {GameType} from '../types';
import {isRecordedPlay} from './financialHistory';

export type LoopAccountReason='TARGET_REACHED'|'CAPITAL_LIMIT';
export interface LoopAccountStop {date:string;reason:LoopAccountReason;profit:number;at:number}
export type LoopAccountKey=`${LoopId}:${GameType}`;
// Legacy bare loop keys may be read from storage, but never stop another game.
export type LoopAccountStops=Partial<Record<LoopAccountKey|LoopId,LoopAccountStop>>;
export const loopAccountKey=(id:LoopId,type:GameType):LoopAccountKey=>`${id}:${type}`;
export const deliveredLoopCard=(r:any)=>Boolean(r?.sentRate||r?.sentDigits||r?.sentAt||['SENT','SENT_PARTIAL','SETTLED'].includes(r?.dispatchState));
export function accountForCard(config:DualLoopConfig,type:string,name:string,rec:any){return assignedLoop(config,type,name,rec);}

/** Every loop/game pair has its own capital, profit, reservations and stop. */
export function loopAccountTotals(config:DualLoopConfig,runtime:any,options:{liveOnly?:boolean;excludeKey?:string;now?:number}={}){
 const totals=Object.fromEntries(activeLoopIds(config).flatMap(id=>LOOP_GAMES.map(type=>[loopAccountKey(id,type),{profit:0,pending:0,spent:0}]))) as Record<LoopAccountKey,{profit:number;pending:number;spent:number}>;
 const now=options.now??Date.now();
 for(const [key,r] of Object.entries(runtime?.cards||{}) as [string,any][]){
  const type=key.split('_')[0] as GameType;if(!['ank','jodi','pannel'].includes(type)||!r)continue;
  const market=runtime.markets?.find((m:any)=>`${m.type}_${m.index}`===key);
  if(market?.enabled===false&&!isRecordedPlay(r))continue;
  const id=accountForCard(config,type,market?.n||r.marketName||'',r);if(!id)continue;
  const accountKey=loopAccountKey(id,type);if(!totals[accountKey])continue;
  const delivered=deliveredLoopCard(r),settled=r.s==='PASS'||r.s==='FAIL';
  if(r.s==='SKIP'&&!delivered)continue;
  if(options.liveOnly&&r.backtestResult&&!r.manualStatus&&!delivered)continue;
  const winDigit = r.manualResult || r.scrapeResultDigit || r.backtestResult?.actual?.open || r.backtestResult?.actual?.close;
  const stake=calculateSettlement({type,digits:r.sentAt?(r.sentDigits||r.d):r.d,rate:r.r||r.recRate,sentRate:r.sentAt?r.sentRate:undefined,sentInvest:r.sentAt?r.sentInvest:undefined,smartStaking:r.smartStaking,winningDigit:winDigit});
  if(settled){totals[accountKey].profit+=(r.s==='PASS'?stake.payout:0)-stake.invest;totals[accountKey].spent+=stake.invest;}
  else if(key!==options.excludeKey){
   const reservation=r.loopAccountReservation?.expiresAt>now?Math.max(0,Number(r.loopAccountReservation.invest)||0):0;
   if(delivered||['QUEUED','SENDING'].includes(r.dispatchState))totals[accountKey].pending+=Math.max(stake.invest,reservation);
   else totals[accountKey].pending+=reservation;
  }
 }
 return totals;
}

export function evaluateLoopAccounts(config:DualLoopConfig,runtime:any,date:string,stops:LoopAccountStops={},options:{liveOnly?:boolean;excludeKey?:string;nextKey?:string;nextCard?:any;nextInvest?:number;now?:number}={}){
 const totals=loopAccountTotals(config,runtime,options),nextStops:LoopAccountStops=Object.fromEntries(Object.entries(stops).filter(([key])=>/^L(?:[1-9]|10):(ank|jodi|pannel)$/.test(key)));
 let nextId:LoopId|undefined;
 const nextType=options.nextKey?.split('_')[0] as GameType|undefined;
 if(options.nextKey){const rec=options.nextCard||runtime.cards?.[options.nextKey],market=runtime.markets?.find((m:any)=>`${m.type}_${m.index}`===options.nextKey);nextId=accountForCard(config,options.nextKey.split('_')[0],market?.n||rec?.marketName||'',rec);}
 const nextAccountKey=nextId&&nextType?loopAccountKey(nextId,nextType):undefined;
 const states=activeLoopIds(config).flatMap(id=>LOOP_GAMES.map(type=>{
  const key=loopAccountKey(id,type),t=totals[key],account=config.loops[id],limits=gameAccountLimits(account,type),cash=limits.capital+t.profit,available=cash-t.pending;
  const previous=stops[key]?.date===date?stops[key]:undefined;
  let reason=previous?.reason;
  if(!reason&&limits.dayTarget>0&&t.profit+1e-8>=limits.dayTarget)reason='TARGET_REACHED';
  if(!reason&&cash<=1e-8)reason='CAPITAL_LIMIT';
  const requested=key===nextAccountKey?Math.max(0,Number(options.nextInvest)||0):0;
  const cannotFit=requested>available+1e-8;
  // A sent/queued stake may return cash. Wait for it; do not latch a false stop.
  if(!reason&&cannotFit&&t.pending<=1e-8)reason='CAPITAL_LIMIT';
  if(reason&&!previous)nextStops[key]={date,reason,profit:t.profit,at:options.now??Date.now()};
  return {id,type,key,name:account.name||id,capital:limits.capital,goal:limits.dayTarget,...t,available,reason,waiting:!reason&&cannotFit,allowed:!reason&&!cannotFit};
 }));
 return {states,stops:nextStops,nextId,nextType,nextAccountKey,allowed:!nextAccountKey||states.find(s=>s.key===nextAccountKey)?.allowed!==false};
}

/** Suppress new work only. Actual delivered/manual settlements stay authoritative. */
export function stopLoopUnsentCards(runtime:any,config:DualLoopConfig,date:string,stops:LoopAccountStops,claimedKeys=new Set<string>()){
 let changed=0;
 for(const [key,r] of Object.entries(runtime.cards||{}) as [string,any][]){
  if(!r||deliveredLoopCard(r)||r.manualStatus||claimedKeys.has(key))continue;
  if(r.s&&r.s!=='WAIT'&&!(r.s==='SKIP'&&r.loopAccountSkipped))continue;
  const market=runtime.markets?.find((m:any)=>`${m.type}_${m.index}`===key),id=accountForCard(config,key.split('_')[0],market?.n||r.marketName||'',r);
  const stop=id&&stops[loopAccountKey(id,key.split('_')[0] as GameType)];
  if(!stop||stop.date!==date){
   if(r.loopAccountSkipped){r.s='WAIT';delete r.loopAccountSkipped;delete r.loopAccountReason;changed++;}
   continue;
  }
  if(r.s==='SKIP'&&r.loopAccountReason===stop.reason)continue;
  r.s='SKIP';r.loopAccountSkipped=true;r.loopAccountReason=stop.reason;delete r.dispatchState;delete r.dispatchKey;delete r.queuedAt;delete r.loopAccountReservation;changed++;
 }
 return changed;
}

export function independentLoopConfig(value:unknown){const config=normalizeDualLoops(value);return config?.enabled&&config.independentAccounts?config:undefined;}

export function resolveLoopAccountConfig(saved:any,runtime:any,date:string){
 const configured=saved?.config?loopSettingsForDate(saved,date):undefined;
 const running=normalizeDualLoops(runtime?.loopConfig,saved?.config);
 const config=configured&&(!running||Number(configured.revision||0)>=Number(running.revision||0))?configured:running;
 return config?.enabled&&config.independentAccounts&&date>=config.startsOn?config:undefined;
}
