/**
 * Monthly/weekly report projections only. No settlement, ledger or broadcasting
 * writes. Each calendar day is evaluated using the existing getWeekStats
 * calculation and then aggregated, preserving the original daily risk reset.
 */
import type { GameType, UserProfile } from '../types';
import type { DailyAuditImageData, AuditImageRow, AuditImageCell } from './dailyAuditImage';
import { getWeekStats } from './calculator';

export type AuditPeriod = 'day' | 'week' | 'month' | 'custom';

export function firstOfMonthUtc(date: string): string {
  return `${date.slice(0, 7)}-01`;
}
export function firstOfWeekUtc(date: string): string {
  const value = new Date(`${date}T00:00:00Z`);
  const weekday = value.getUTCDay();
  value.setUTCDate(value.getUTCDate() - ((weekday + 6) % 7));
  return value.toISOString().slice(0, 10);
}
export function* reportDates(start: string, end: string): Generator<string> {
  const next = new Date(`${start}T00:00:00Z`);
  const last = new Date(`${end}T00:00:00Z`);
  for (; next <= last; next.setUTCDate(next.getUTCDate() + 1)) yield next.toISOString().slice(0, 10);
}

/** Compute aggregated stats for any custom date range. */
export function getCustomRangeStats(profile: UserProfile, startDate: string, endDate: string) {
  const seed = getWeekStats({ ...profile, dayRecords: {} }, endDate);
  const stats = seed.stats;
  const totals = seed.totals;
  for (const date of reportDates(startDate, endDate)) {
    const dayProfile = { ...profile, dayRecords: { [date]: profile.dayRecords?.[date] || {} } };
    const oneDay = getWeekStats(dayProfile, date);
    for (const game of ['ank', 'jodi', 'pannel'] as GameType[]) {
      for (const [market, values] of Object.entries(oneDay.stats[game])) {
        const dest = stats[game][market] ||= { rounds: 0, pass: 0, fail: 0, invest: 0, win: 0 };
        dest.rounds += values.rounds;
        dest.pass += values.pass;
        dest.fail += values.fail;
        dest.invest += values.invest;
        dest.win += values.win;
      }
      const to = totals[game];
      const from = oneDay.totals[game];
      to.invest += from.invest;
      to.win += from.win;
      to.runningPL += from.runningPL;
      to.maxLoss = Math.max(to.maxLoss, from.maxLoss);
      to.pendingLoss = from.pendingLoss;
    }
  }
  return { monthStart: new Date(`${startDate}T00:00:00Z`), startDate, endDate, stats, totals };
}

/** Reuse the exact existing daily settlement/risk calculation without altering it. */
export function getMonthStats(profile: UserProfile, currentDate: string) {
  const start = firstOfMonthUtc(currentDate);
  return getCustomRangeStats(profile, start, currentDate);
}

function cloneCell(cell: AuditImageCell): AuditImageCell {
  return { pass: cell.pass, fail: cell.fail, stakes: cell.stakes, payout: cell.payout, net: cell.net };
}
function addCell(a: AuditImageCell | undefined, b: AuditImageCell | undefined) {
  if (!b) return a;
  if (!a) return cloneCell(b);
  a.pass += b.pass;
  a.fail += b.fail;
  a.stakes += b.stakes;
  a.payout += b.payout;
  a.net += b.net;
  return a;
}

/**
 * Aggregates pre-existing daily PNG projections. Financial numbers always come
 * from buildDailyAuditImageData, never a new payout/recovery implementation.
 * Current-day wallet is shown separately and is NOT summed across the month.
 */
export function aggregateAuditImageData(
  profile: UserProfile,
  date: string,
  game: GameType,
  period: AuditPeriod,
  buildDay: (profile: UserProfile, date: string, game: GameType) => DailyAuditImageData,
  customStart?: string,
): DailyAuditImageData {
  const startDate = period === 'day' ? date : period === 'week' ? firstOfWeekUtc(date) : (period === 'custom' && customStart ? customStart : firstOfMonthUtc(date));
  if (period === 'day') return buildDay(profile, date, game);
  const grouped = new Map<string, AuditImageRow>();
  let pass = 0, fail = 0, stakes = 0, payout = 0, maxRisk = 0;
  const endDay = buildDay(profile, date, game);
  for (const day of reportDates(startDate, date)) {
    const data = day === date ? endDay : buildDay(profile, day, game);
    pass += data.pass;
    fail += data.fail;
    stakes += data.stakes;
    payout += data.payout;
    maxRisk = Math.max(maxRisk, data.maxRisk);
    for (const source of data.rows) {
      // Preserve the daily image's separate identity for a bare custom-result
      // market and an OPEN/CLOSE market sharing the same base name.
      const key = `${source.result && !source.open && !source.close ? 'result' : 'paired'}:${source.market}`;
      const row = grouped.get(key) || { market: source.market };
      row.open = addCell(row.open, source.open);
      row.close = addCell(row.close, source.close);
      row.result = addCell(row.result, source.result);
      grouped.set(key, row);
    }
  }
  return {
    ...endDay,
    period,
    startDate,
    endDate: date,
    rows: [...grouped.values()],
    pass,
    fail,
    stakes,
    payout,
    net: payout - stakes,
    maxRisk,
    // endDay.ownCapital, wallet and pending are snapshots of selected date;
    // they are not monthly sums and not part of settled P/L.
  };
}
