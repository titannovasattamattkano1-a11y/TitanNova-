import type {UserProfile} from '../types';
import {normalizeDualLoops,loopSettingsForDate,hasCommittedInactiveLoop,isLoopAssignmentFrozen,validLoopDate,type DualLoopConfig} from './dualLoops';
import {businessDateIST} from './businessDate';
import {calculateBacktestRecovery} from './backtestRecovery';

/** Upgrade existing explicit custom saves once; auto-pinned days are not edits. */
export function migrateCustomLoopSettings(profile:UserProfile):UserProfile {
  if(profile.customLoopChanges)return profile;
  const changes:Record<string,DualLoopConfig>={};
    const previous=normalizeDualLoops(profile.config.dualLoops,profile.config);
    if(previous?.independentAccounts)changes[previous.startsOn]=previous;
    for(const [day,records] of Object.entries(profile.dayRecords)){
      const old=normalizeDualLoops(records.loopConfig,profile.config);
      if(old?.independentAccounts&&old.startsOn===day&&Number(old.revision||0)>=Number(changes[day]?.revision||0))changes[day]=old;
    }
  return Object.keys(changes).length?{...profile,customLoopChanges:changes}:profile;
}

/** One source of truth for explicit ON/OFF and financial setup changes. */
export function applyCustomLoopSetup(profile:UserProfile,date:string,draft:unknown,now=Date.now()):UserProfile {
  if(!validLoopDate(date))throw new Error('Select a valid business date.');
  const config=normalizeDualLoops(draft,profile.config);
  if(!config)throw new Error('Valid custom account settings are required.');
  const changes={...migrateCustomLoopSettings(profile).customLoopChanges};
  const revision=Math.max(now,1,...Object.values(changes).map(c=>Number(c.revision||0)+1));
  const saved:DualLoopConfig={...config,independentAccounts:true,startsOn:date,revision};
  changes[date]=saved;
  const latest=Object.keys(changes).sort().at(-1)!;
  let next:UserProfile={...profile,customLoopChanges:changes,config:{...profile.config,dualLoops:changes[latest]},dayRecords:{...profile.dayRecords}};
  // Validate every affected saved date, including today's committed cards.
  for(const day of Object.keys(profile.dayRecords)){
    const effective=loopSettingsForDate(next,day);
    if(effective?.enabled&&hasCommittedInactiveLoop(profile.dayRecords[day],effective))throw new Error('An account with committed bets cannot be removed. Keep its original account active.');
  }
  const day={...(next.dayRecords[date]||{}),loopConfig:saved,...(date<businessDateIST()?{backtestRevision:revision}:{})};
  for(const key of ['data','jodiData','pannelData'] as const){
    day[key]=Object.fromEntries(Object.entries(day[key]||{}).map(([i,record])=>{
      if(isLoopAssignmentFrozen(record))return [i,record];
      const copy={...record};delete copy.loopId;delete copy.sentLoopId;delete copy.recRate;delete copy.prevLoss;delete copy.targetProfitWithLoss;
      if(!saved.enabled&&copy.loopAccountSkipped){copy.s='WAIT';delete copy.loopAccountSkipped;delete copy.loopAccountReason;}
      return [i,copy];
    }));
  }
  next={...next,dayRecords:{...next.dayRecords,[date]:day}};
  return date<businessDateIST()?calculateBacktestRecovery(next,date):next;
}
