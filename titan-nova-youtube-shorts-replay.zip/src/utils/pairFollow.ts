export interface PairDraw { date: string; jodi?: string }

/** Latest completed pair before the selected day; single-side successor digits; no target/future outcomes. */
export function selectPairFollow(draws: PairDraw[], targetDate: string, side: 'open' | 'close', observe?: (digit: string, date: string) => void, observationLimit?:number) {
  const parsed = new Date(`${targetDate}T00:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(targetDate) || !Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0,10)!==targetDate) throw new Error('Pair Follow: invalid target date');
  const byDate = new Map<string,string>();
  const conflicts = new Set<string>();
  for (const row of draws) {
    if (row.date >= targetDate || !/^\d{2}$/.test(row.jodi || '')) continue;
    const date = new Date(`${row.date}T00:00:00Z`);
    if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0,10)!==row.date) continue;
    if (byDate.has(row.date) && byDate.get(row.date)!==row.jodi) conflicts.add(row.date);
    byDate.set(row.date,row.jodi!);
  }
  const history = [...byDate].filter(([date])=>!conflicts.has(date)).sort(([a],[b])=>a.localeCompare(b));
  const latest = history.at(-1);
  if (!latest) throw new Error('Pair Follow: selected day se pehle completed dated pair nahi mila; card unchanged');
  const digits = new Set<string>();
  let scanned = 0, matches = 0;
  for (let i=history.length-2;i>=0;i--) {
    scanned++;
    if (history[i][1]!==latest[1]) continue;
    matches++;
    const digit=history[i+1][1][side==='open'?0:1];
    observe?.(digit,history[i][0]);
    digits.add(digit);
    if (observationLimit===undefined ? digits.size===10 : matches>=observationLimit) break;
  }
  return {digits:[...digits].join(', '),basePair:latest[1],baseDate:latest[0],matches,scanned,complete:digits.size===10};
}

/** 
 * Pair Combo:
 * Finds the latest completed pair before targetDate.
 * Searches earlier occurrences of that pair (from newest to oldest).
 * For each occurrence, takes the NEXT available completed pair from the chart.
 * Collects BOTH digits of that next pair (the combo).
 * On CLOSE card: takes close digit (index 1) then open digit (index 0).
 * On OPEN card: takes open digit (index 0) then close digit (index 1).
 * Preserves first-encounter order and uniqueness until 10 unique digits are collected (or history exhausted).
 */
export function selectPairCombo(
  draws: PairDraw[],
  targetDate: string,
  side: 'open' | 'close',
  observe?: (digit: string, date: string) => void,
  observationLimit?: number,
) {
  const parsed = new Date(`${targetDate}T00:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(targetDate) || !Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0,10)!==targetDate) throw new Error('Pair Combo: invalid target date');
  const byDate = new Map<string,string>();
  const conflicts = new Set<string>();
  for (const row of draws) {
    if (row.date >= targetDate || !/^\d{2}$/.test(row.jodi || '')) continue;
    const date = new Date(`${row.date}T00:00:00Z`);
    if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0,10)!==row.date) continue;
    if (byDate.has(row.date) && byDate.get(row.date)!==row.jodi) conflicts.add(row.date);
    byDate.set(row.date,row.jodi!);
  }
  const history = [...byDate].filter(([date])=>!conflicts.has(date)).sort(([a],[b])=>a.localeCompare(b));
  const latest = history.at(-1);
  if (!latest) throw new Error('Pair Combo: selected day se pehle completed dated pair nahi mila; card unchanged');
  const digits = new Set<string>();
  let scanned = 0, matches = 0;
  for (let i=history.length-2;i>=0;i--) {
    scanned++;
    if (history[i][1]!==latest[1]) continue;
    matches++;
    const nextPair = history[i+1][1];
    const dPrimary = nextPair[side==='close' ? 1 : 0];
    const dSecondary = nextPair[side==='close' ? 0 : 1];
    observe?.(dPrimary, history[i][0]);
    digits.add(dPrimary);
    if (digits.size < 10) {
      observe?.(dSecondary, history[i][0]);
      digits.add(dSecondary);
    }
    if (observationLimit===undefined ? digits.size===10 : matches>=observationLimit) break;
  }
  return {digits:[...digits].join(', '),basePair:latest[1],baseDate:latest[0],matches,scanned,complete:digits.size===10};
}
