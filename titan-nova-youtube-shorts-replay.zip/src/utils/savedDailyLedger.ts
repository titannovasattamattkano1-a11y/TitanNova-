import {useRecoveryShareLedger} from './twoCardRecovery';
import { vipLiveMarketEligible } from './vipLiveStart';
import { loopSettingsForDate, assignedLoop } from './dualLoops';
import type { UserProfile } from '../types';
import {getDefaultConfig} from '../data/markets';
import {buildFinancialLedger} from './financialHistory';
import { normalizeTargetProfit } from './settlement';
import { isTelegramTarget, normalizeTargetList } from './targetNormalization';
import { vipCopiesAdmin, projectAdminSource } from './adminMirror';

/** Fresh-date ledger from that date's saved records only; never clone prior plays. */
export function savedDailyLedgerProfiles(profiles: Record<string, UserProfile>, date: string): Record<string, any> {
  const result: Record<string, any> = {};
  const adminLedger = profiles?.admin1
    ? buildFinancialLedger({ ...profiles.admin1, config: profiles.admin1.config || getDefaultConfig() }, date)
    : null;
  for (const [pid, saved] of Object.entries(profiles || {})) {
    const cfg = saved.config || getDefaultConfig();
    const day = saved.dayRecords?.[date] || {};
    const loopConfig = loopSettingsForDate(saved,date);
    const ledger=buildFinancialLedger({...saved,config:cfg},date);
    const markets=ledger.markets.map(m=>({...m,enabled:m.enabled&&vipLiveMarketEligible(saved,date,m.type,m.n)}));
    const cards: Record<string, any> = Object.fromEntries(Object.entries(ledger.cards).map(([key,rec])=>{
      const market=markets.find(m=>`${m.type}_${m.index}`===key)!;
      const loopId=assignedLoop(loopConfig,market.type,market.n,rec);
      return [key,{...rec,...(loopId?{loopId}:{}),...(pid!=='admin1'?{schTime:'',schTargets:[]}:{})}];
    }));
    if (pid !== 'admin1' && vipCopiesAdmin(saved) && adminLedger) {
      for (const market of markets) {
        if (!market.enabled) continue;
        const key = `${market.type}_${market.index}`;
        const existing = cards[key] || { s: 'WAIT', d: '', r: '', marketName: market.n };
        const frozen = Boolean(existing.sentRate || existing.sentDigits || existing.sentAt || ['QUEUED', 'SENT', 'SETTLED'].includes(String(existing.dispatchState || '')) || existing.s === 'PASS' || existing.s === 'FAIL');
        if (frozen || String(existing.d || '').trim()) continue;
        const adminMarket = adminLedger.markets.find(m => m.type === market.type && String(m.n || '').trim().toUpperCase() === String(market.n || '').trim().toUpperCase());
        const adminCard = adminMarket ? adminLedger.cards[`${adminMarket.type}_${adminMarket.index}`] : undefined;
        if (adminCard && String(adminCard.d || '').trim()) {
          const projected = projectAdminSource(existing, adminCard, market.n, false, true);
          const loopId = assignedLoop(loopConfig, market.type, market.n, projected);
          cards[key] = { ...projected, ...(loopId ? { loopId } : {}), schTime: '', schTargets: [] };
        }
      }
    }
    const rawPhone = String(saved.vipSchTarget || saved.phone || '');
    const phone = isTelegramTarget(rawPhone) ? rawPhone : rawPhone.replace(/\D/g,'');
    const mode = saved.vipDeliveryMode || 'private';
    const targets = mode === 'group' ? normalizeTargetList([saved.vipGroupJid], 'group')
      : mode === 'channel' ? normalizeTargetList([saved.vipChannelJid], 'channel')
      : phone ? normalizeTargetList([phone], 'phone') : [];
    result[pid] = {
      name: saved.name, phone: pid === 'admin1' ? '' : phone,
      vipAutoMode: pid === 'admin1' ? false : saved.vipAutoMode !== false,
      vipGameRuns: pid === 'admin1' ? undefined : saved.vipGameRuns,
      deliveryMode: mode, deliveryTargets: pid === 'admin1' ? [] : targets,
      vipGroupJid: saved.vipGroupJid || '', vipChannelJid: saved.vipChannelJid || '',
      detailedMessage: cfg.detailedMessage !== false,
      schedulePolicy: pid === 'admin1' ? cfg.scheduleTypeEnabled || {} : saved.vipScheduleEnabled || {},
      autoRemoveResultUnique3: cfg.autoRemoveResultUnique3===true,
      autoCarryResultSix: cfg.autoCarryResultSix === true,
      openToCloseCut: day.openToCloseCut===true,
      autoRemoveResultDigit: cfg.autoRemoveResultDigit === true,
      autoRemoveResultMirror: cfg.autoRemoveResultMirror === true,
      autoResultParity: cfg.autoResultParity === true,
      liveThreeFailReset: cfg.liveThreeFailReset === true,
      sameMarketRecovery: cfg.sameMarketRecovery !== false,
      fourWaveRelay: cfg.fourWaveRelay === true,
      twoCardRecoveryLegacySplit: cfg.twoCardRecoveryLegacySplit,
      twoCardRecoveryVersion: useRecoveryShareLedger(cfg,date,'ank')||useRecoveryShareLedger(cfg,date,'pannel')?2:undefined,
      splitMode: { ank: cfg.ankSplit !== false, pannel: cfg.panSplit !== false },
      targetProfit: { ank: normalizeTargetProfit(cfg.ank?.tgt,100), jodi: normalizeTargetProfit(cfg.jodi?.tgt,100), pannel: normalizeTargetProfit(cfg.pannel?.tgt,100) },
      loopConfig, loopAccountStops:day.loopAccountStops, markets, cards, recoveryState: {},
    };
  }
  return result;
}
