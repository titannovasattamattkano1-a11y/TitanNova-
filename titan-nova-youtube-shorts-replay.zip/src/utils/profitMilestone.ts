import { runtimeRecoveryTrack, runtimeLoop, type LoopId } from './dualLoops';
import { calculateSettlement } from './settlement';
import { savedDailyLedgerProfiles } from './savedDailyLedger';

/** Reporting-only union: live cards (including Restore/WAIT) own their identity;
 * saved same-day history fills cards omitted from a partial live snapshot. */
export function profitMilestoneLedger(runtime: any, saved: any, date: string): any {
  if(!saved?.dayRecords?.[date])return runtime;
  const archived=savedDailyLedgerProfiles({profile:saved},date).profile;
  const markets=[...(runtime?.markets || [])],cards={...(runtime?.cards || {})};
  const identity=(type:string,name:unknown)=>`${type}|${String(name || '').trim().toUpperCase()}`;
  const owned=new Set<string>();
  for(const [key,card] of Object.entries(cards) as Array<[string,any]>) {
    const [type,index]=key.split('_');
    const market=markets.find((m:any)=>m.type===type&&Number(m.index)===Number(index));
    const name=card?.marketName || market?.n;
    if(name)owned.add(identity(type,name));
  }
  let index=-1000000;
  for(const market of archived.markets || []) {
    const card=archived.cards[`${market.type}_${market.index}`];
    if(!card || !['PASS','FAIL'].includes(card.s) || owned.has(identity(market.type,market.n)))continue;
    // Same-index live records without identity also own that slot.
    if(Object.prototype.hasOwnProperty.call(cards,`${market.type}_${market.index}`)&&!markets.find((m:any)=>m.type===market.type&&m.index===market.index))continue;
    while(Object.prototype.hasOwnProperty.call(cards,`${market.type}_${index}`))index--;
    markets.push({...market,index});cards[`${market.type}_${index}`]=card;
    owned.add(identity(market.type,market.n));index--;
  }
  // Keep the original day order for Max Risk, rather than sorting synthetic slots.
  const order=new Map((archived.markets || []).map((m:any)=>[identity(m.type,m.n),Number(m.index)]));
  markets.sort((a:any,b:any)=>Number(order.get(identity(a.type,a.n))??a.index)-Number(order.get(identity(b.type,b.n))??b.index));
  return {...runtime,markets,cards,profitHistoryOrder:true,loopConfig:runtime?.loopConfig || archived.loopConfig};
}

export interface ProfitMilestoneSummary {
  totalMarket: number;
  totalPass: number;
  totalFail: number;
  maxRisk: number;
  profit: number;
}

const aggregateDebt = (debt: Record<string, number>): number =>
  Object.values(debt).reduce((sum, amount) => sum + Math.max(0, Number(amount) || 0), 0);


/** Calculate one profile/day summary, optionally scoped to one actual delivery destination. */
export function calculateProfitMilestoneSummary(profile: any, destination?: string, loopFilter?: LoopId): ProfitMilestoneSummary {
  const summary: ProfitMilestoneSummary = { totalMarket: 0, totalPass: 0, totalFail: 0, maxRisk: 0, profit: 0 };
  const markets = Array.isArray(profile?.markets) ? profile.markets : [];
  const cards = profile?.cards || {};
  let spent = 0;
  let returned = 0;

  for (const type of ['ank', 'jodi', 'pannel']) {
    const debt: Record<string, number> = {};
    const typedMarkets = markets
      // A settled card is financial history. Turning a market off later must
      // stop future cards, but it must never erase an already delivered result
      // from TOTAL HISAB / profit milestone calculations.
      .filter((market: any) => String(market?.type || '') === type)
      .sort((a: any, b: any) => profile?.profitHistoryOrder ? 0 : Number(a?.index || 0) - Number(b?.index || 0));

    for (const market of typedMarkets) {
      const card = cards[`${type}_${Number(market.index)}`];
      if (loopFilter && runtimeLoop(profile,type,String(market.n || ''),card) !== loopFilter) continue;
      const status = String(card?.s || '').toUpperCase();
      if (status !== 'PASS' && status !== 'FAIL') continue;
      const delivered = Boolean(card.sentRate || card.sentDigits || card.dispatchState === 'SENT' || card.dispatchState === 'SETTLED');
      if (card.backtestResult && !delivered) continue;
      if (destination) {
        const deliveredTargets = Array.isArray(card?.sentTargets)
          ? card.sentTargets.map((target: unknown) => String(target || '').trim()).filter(Boolean)
          : [];
        if (!deliveredTargets.includes(String(destination).trim())) continue;
      }
      const winDigit = card.manualResult || card.scrapeResultDigit;
      const settlement = calculateSettlement({
        type,
        digits: card.sentAt ? (card.sentDigits || card.d) : card.d,
        rate: card.r || card.recRate,
        sentRate: card.sentAt ? card.sentRate : undefined,
        sentInvest: card.sentAt ? card.sentInvest : undefined,
        smartStaking: card.smartStaking,
        winningDigit: winDigit,
      });
      if (settlement.tokenCount <= 0 || settlement.rate <= 0 || settlement.invest <= 0) continue;

      // Count only a financially valid, actually delivered settlement. This
      // keeps market/pass/fail totals aligned with the amount shown below them.
      summary.totalMarket += 1;
      if (status === 'PASS') summary.totalPass += 1;
      else summary.totalFail += 1;

      const key = runtimeRecoveryTrack(profile, type, String(market.n || ''));
      if (debt[key] === undefined) debt[key] = 0;
      spent += settlement.invest;
      if (status === 'FAIL') {
        debt[key] += settlement.invest;
        summary.maxRisk = Math.max(summary.maxRisk, aggregateDebt(debt));
      } else {
        returned += settlement.payout;
        summary.maxRisk = Math.max(summary.maxRisk, aggregateDebt(debt) + settlement.invest);
        debt[key] = 0;
      }
    }
  }

  summary.profit = returned - spent;
  return summary;
}

export function reachedProfitMilestone(profit: number, step = 1000): number {
  const safeStep = Math.max(1, Math.floor(Number(step) || 1000));
  return Math.floor(Math.max(0, Number(profit) || 0) / safeStep) * safeStep;
}

export function buildProfitMilestoneMessage(summary: ProfitMilestoneSummary): string {
  const inr = (value: number) => `₹${Math.round(Math.abs(value)).toLocaleString('en-IN')}`;
  const signedProfit = `${summary.profit >= 0 ? '+' : '-'}${inr(summary.profit)}`;
  const row = (value: string) => `║ ${value.padEnd(28, ' ')} ║`;
  return [
    '🎉 *ABHI TAK KA PROFIT, AAGE AUR BHI HOGA*',
    '',
    '╔══════════════════════════════╗',
    '║        📋 TOTAL HISAB        ║',
    '╠══════════════════════════════╣',
    row(`🧾 Total Market : ${summary.totalMarket}`),
    row(`✅ Total Pass   : ${summary.totalPass}`),
    row(`❌ Total Fail   : ${summary.totalFail}`),
    '╠══════════════════════════════╣',
    row(`⚡ Max Risk     : ${inr(summary.maxRisk)}`),
    row(`💰 Profit       : ${signedProfit}`),
    '╚══════════════════════════════╝',
  ].join('\n');
}
