// Server instance + revision; never shared across VIP or unrelated origins.
export let adminWorkspaceVersion='';
export function noteAdminWorkspaceVersion(value:string|null){if(value)adminWorkspaceVersion=value;}
