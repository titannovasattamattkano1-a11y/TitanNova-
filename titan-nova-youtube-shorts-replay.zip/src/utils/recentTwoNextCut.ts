import type {DayMarketRecord} from '../types';
import {getScrapeSource} from './scrapeProvenance';
import {removeRecentTwoIndices} from './removeRecentSourceIndices';

/** Shift source positions, never digit values: 1→2, …, 10→1. */
export function recentTwoNextPositions(indices:number[],allowPartial=false):number[]|undefined {
  if(!indices.length||indices.length>2||(!allowPartial&&indices.length!==2)||!indices.every(i=>Number.isInteger(i)&&i>=1&&i<=10))return;
  return indices.map(i=>i%10+1);
}

/** Separate button policy; normal Recent2 and T1/T2 keep their existing formulas. */
export function removeRecentTwoNextIndices(record:DayMarketRecord|undefined,indices:number[]):DayMarketRecord|undefined {
  if(!record||record.manualStatus||record.deliveryRestoredAt||record.s==='PASS'||record.s==='FAIL')return;
  const source=getScrapeSource(record);if(!source)return;
  const shifted=recentTwoNextPositions(indices,source.digits.split(', ').length<10);if(!shifted)return;
  const current=record.d.split(/[,|\s]+/).filter(Boolean);
  if(!current.length||new Set(current).size!==current.length||!current.every(d=>/^\d$/.test(d)))return;
  // Map cuts through original source, then intersect with current remaining digits.
  // Reset only the marker for calculation; the existing helper supplies guards,
  // shifted-repeat mirror handling, undo source and rate/metadata cleanup.
  const next=removeRecentTwoIndices({...record,positionRule:undefined},shifted);if(!next)return;
  return next;
}
