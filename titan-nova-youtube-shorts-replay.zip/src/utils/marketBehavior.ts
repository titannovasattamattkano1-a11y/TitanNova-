/** Dynamic market/side model. All weights and eligibility use past-only outcomes. */
import type { BehaviorDraw, BehaviorSide, MarketBehaviorPrediction as LegacyPrediction } from './legacyMarketBehavior';
export type { BehaviorDraw, BehaviorSide } from './legacyMarketBehavior';
export const MARKET_MODEL_WINDOWS = [10, 15, 20, 30, 45, 60, 90] as const;
const DIGITS = Array.from({ length: 10 }, (_, i) => String(i));
const METHODS = [...MARKET_MODEL_WINDOWS.map(window => `window_${window}`), 'weekday'];
const MIN_HISTORY = 30, MAX_HISTORY = 600, MIN_EVIDENCE = 60;
const round = (value: number) => Number(value.toFixed(6));
interface Observation { date: string; digit: string; weekday: number }
interface Trial { hit: boolean; loss: number; logLoss: number }
interface MixtureTrial extends Trial { set: string; frequencyHit: boolean; frequencyLoss: number; emitted: boolean }
export interface ModelPolicyEvaluation {
  opportunities: number; predictions: number; skipped: number; coveragePercent: number;
  hits: number; hitPercent: number | null; maxMissStreak: number;
}
export interface MarketBehaviorPrediction extends Omit<LegacyPrediction, 'engine' | 'experts' | 'behavior' | 'selection'> {
  engine: 'market_behavior_dynamic_v2';
  decision: 'RETAIN' | 'SKIP';
  reason: string;
  selectedWindows: number[];
  patternShift: boolean;
  policyEvaluation: ModelPolicyEvaluation;
  selection: {
    method: 'retain_top_6_eliminate_bottom_4'; boundaryProbabilityGap: number;
    retainedProbabilityMass: number; randomBaselinePercent: 60;
    minEvidenceSamples: number;
  };
  experts: Array<{ method: string; window: number | null; weight: number; samples: number;
    evaluationSamples: number; recentHitPercent: number | null; brierScore: number | null; maxMissStreak: number }>;
  behavior: { recentFrequencyShift: number; dominantExpert: string };
}
const validDate = (value: string) => /^\d{4}-\d{2}-\d{2}$/.test(value) &&
  !Number.isNaN(Date.parse(`${value}T00:00:00Z`)) && new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) === value;
const dayOfWeek = (date: string) => new Date(`${date}T00:00:00Z`).getUTCDay();
const ranking = (p: number[]) => [...DIGITS].sort((a, b) => p[Number(b)] - p[Number(a)] || a.localeCompare(b));
const brier = (p: number[], actual: string) => p.reduce((sum, value, i) => sum + (value - Number(i === Number(actual))) ** 2, 0);
function distribution(history: Observation[], method: string, weekday: number) {
  const window = method === 'weekday' ? null : Number(method.split('_')[1]);
  const rows = window === null ? history.filter(row => row.weekday === weekday).slice(-30) : history.slice(-window);
  const active = window === null ? rows.length >= 12 : rows.length >= window;
  const counts = Array<number>(10).fill(1);
  let total = 10;
  rows.forEach((row, i) => {
    const weight = window === null ? 1 : 0.5 + 0.5 * Math.pow(0.5, (rows.length - 1 - i) / (window / 2));
    counts[Number(row.digit)] += weight; total += weight;
  });
  return { probabilities: counts.map(count => count / total), samples: rows.length, active, window };
}
function stats<T extends Trial>(trials: T[], limit = 60) {
  const recent = trials.slice(-limit), samples = recent.length;
  let streak = 0, maxMissStreak = 0;
  for (const row of recent) { streak = row.hit ? 0 : streak + 1; maxMissStreak = Math.max(maxMissStreak, streak); }
  const mean = (key: 'loss' | 'logLoss') => samples ? recent.reduce((sum, row) => sum + row[key], 0) / samples : null;
  return { samples, hits: recent.filter(row => row.hit).length, brier: mean('loss'), logLoss: mean('logLoss'), maxMissStreak };
}
function lowerWilson(hits: number, samples: number) {
  if (!samples) return null;
  const p = hits / samples, z2 = 1.96 ** 2;
  return (p + z2 / (2 * samples) - 1.96 * Math.sqrt(p * (1 - p) / samples + z2 / (4 * samples ** 2))) / (1 + z2 / samples);
}
function shiftMagnitude(history: Observation[]) {
  if (history.length < 45) return 0;
  const frequency = (rows: Observation[]) => {
    const counts = Array<number>(10).fill(1); rows.forEach(row => counts[Number(row.digit)]++);
    return counts.map(count => count / (rows.length + 10));
  };
  const recent = frequency(history.slice(-15)), older = frequency(history.slice(-60, -15));
  return recent.reduce((sum, p, i) => sum + Math.abs(p - older[i]), 0) / 2;
}
function mix(history: Observation[], weekday: number, logs: Trial[][]) {
  const candidates = METHODS.map(method => distribution(history, method, weekday));
  const shift = shiftMagnitude(history), patternShift = shift >= 0.2;
  const fitness = candidates.map((candidate, i) => {
    if (!candidate.active) return -Infinity;
    const evidence = stats(logs[i]);
    if (evidence.samples < 20) return 0; // no performance reward without sufficient trials
    const hitRate = (evidence.hits + 6) / (evidence.samples + 10);
    const shortBonus = patternShift && candidate.window !== null ? shift * Math.max(0, 1 - candidate.window / 60) * 2 : 0;
    return -4 * ((evidence.logLoss ?? Math.log(10)) - Math.log(10)) -
      3 * ((evidence.brier ?? 0.9) - 0.9) + 2 * (hitRate - 0.6) - 0.06 * evidence.maxMissStreak + shortBonus;
  });
  const best = Math.max(...fitness), scores = fitness.map(value => Number.isFinite(value) ? Math.exp(value - best) : 0);
  const total = scores.reduce((sum, value) => sum + value, 0), active = candidates.filter(row => row.active).length;
  const weights = scores.map((score, i) => candidates[i].active ? 0.95 * score / total + 0.05 / active : 0);
  const probabilities = DIGITS.map((_, digit) => candidates.reduce((sum, candidate, i) => sum + weights[i] * candidate.probabilities[digit], 0));
  return { candidates, weights, probabilities, shift, patternShift };
}
function eligibility(trials: MixtureTrial[], probabilities: number[]) {
  const evidence = stats(trials, 120), lower = lowerWilson(evidence.hits, evidence.samples);
  const recent30 = stats(trials, 30), order = ranking(probabilities);
  const mass = order.slice(0, 6).reduce((sum, digit) => sum + probabilities[Number(digit)], 0);
  const gap = probabilities[Number(order[5])] - probabilities[Number(order[6])];
  if (evidence.samples < MIN_EVIDENCE) return { decision: 'SKIP' as const, reason: 'insufficient_past_trials' };
  if (lower === null || lower <= 0.6 || (evidence.brier ?? 1) >= 0.9)
    return { decision: 'SKIP' as const, reason: 'baseline_advantage_unproven' };
  if (recent30.hits / recent30.samples <= 0.6) return { decision: 'SKIP' as const, reason: 'recent_performance_weak' };
  if (mass < 0.68 || (gap < 0.001 && mass < 0.85)) return { decision: 'SKIP' as const, reason: 'digit_ranking_uncertain' };
  return { decision: 'RETAIN' as const, reason: 'past_evidence_supports_selection' };
}
/** Zero data from the target/future enters rankings, weights, regime detection or the SKIP gate. */
export function buildMarketBehaviorPrediction(draws: BehaviorDraw[], market: string, side: BehaviorSide, targetDate: string): MarketBehaviorPrediction | null {
  if (!validDate(targetDate)) return null;
  const byDate = new Map<string, Set<string>>();
  for (const draw of draws) {
    if (!validDate(draw.date) || draw.date >= targetDate || !/^\d{2}$/.test(draw.jodi)) continue;
    if (!byDate.has(draw.date)) byDate.set(draw.date, new Set());
    byDate.get(draw.date)!.add(draw.jodi);
  }
  const sideIndex = side === 'open' ? 0 : 1;
  const history = [...byDate].filter(([, pairs]) => pairs.size === 1).sort(([a], [b]) => a.localeCompare(b)).slice(-MAX_HISTORY)
    .map(([date, pairs]) => ({ date, digit: [...pairs][0][sideIndex], weekday: dayOfWeek(date) }));
  if (history.length < MIN_HISTORY) return null;
  const logs: Trial[][] = METHODS.map(() => []), trials: MixtureTrial[] = [];
  for (let index = MIN_HISTORY; index < history.length; index++) {
    const prior = history.slice(0, index), actual = history[index];
    const current = mix(prior, actual.weekday, logs), order = ranking(current.probabilities);
    const decision = eligibility(trials, current.probabilities); // predict before observing
    const frequency = distribution(prior, 'window_90', actual.weekday).probabilities;
    trials.push({ hit: order.slice(0, 6).includes(actual.digit), loss: brier(current.probabilities, actual.digit),
      logLoss: -Math.log(Math.max(1e-9, current.probabilities[Number(actual.digit)])), set: order.slice(0, 6).sort().join(''),
      frequencyHit: ranking(frequency).slice(0, 6).includes(actual.digit), frequencyLoss: brier(frequency, actual.digit), emitted: decision.decision === 'RETAIN' });
    current.candidates.forEach((candidate, i) => {
      if (candidate.active) logs[i].push({ hit: ranking(candidate.probabilities).slice(0, 6).includes(actual.digit),
        loss: brier(candidate.probabilities, actual.digit), logLoss: -Math.log(Math.max(1e-9, candidate.probabilities[Number(actual.digit)])) });
    });
  }
  const current = mix(history, dayOfWeek(targetDate), logs), sourceDigits = ranking(current.probabilities);
  const policy = eligibility(trials, current.probabilities), recent = trials.slice(-120), evidence = stats(recent, 120);
  const lower = lowerWilson(evidence.hits, evidence.samples), emitted = recent.filter(row => row.emitted);
  const emittedStats = stats(emitted, 120);
  let changes = 0, sameStreak = 0, maxSame = 0;
  recent.forEach((row, i) => { const same = i > 0 && row.set === recent[i - 1].set;
    if (i > 0 && !same) changes++; sameStreak = same ? sameStreak + 1 : 1; maxSame = Math.max(maxSame, sameStreak); });
  const dominantIndex = current.weights.reduce((best, weight, i) => weight > current.weights[best] ? i : best, 0);
  const selectedWindows = current.weights.map((weight, i) => ({weight, window: current.candidates[i].window}))
    .filter(row => row.window !== null && row.weight > 0).sort((a, b) => b.weight - a.weight).slice(0, 2).map(row => row.window!);
  const lastTrainingDate = history.at(-1)!.date, calendarGapDays = Math.round((Date.parse(targetDate) - Date.parse(lastTrainingDate)) / 86400000);
  const mean = (key: 'frequencyLoss') => recent.length ? round(recent.reduce((sum, row) => sum + row[key], 0) / recent.length) : null;
  const proven = evidence.samples >= MIN_EVIDENCE && lower !== null && lower > 0.6 && (evidence.brier ?? 1) < 0.9;
  return {
    engine: 'market_behavior_dynamic_v2', market: market.trim().toUpperCase(), side, targetDate,
    historySize: history.length, lastTrainingDate, ...policy, selectedWindows, patternShift: current.patternShift,
    sourceDigits, digits: policy.decision === 'RETAIN' ? sourceDigits.slice(0, 6) : [],
    eliminatedDigits: policy.decision === 'RETAIN' ? sourceDigits.slice(6).reverse() : [],
    selection: { method: 'retain_top_6_eliminate_bottom_4', boundaryProbabilityGap: round(current.probabilities[Number(sourceDigits[5])] - current.probabilities[Number(sourceDigits[6])]),
      retainedProbabilityMass: round(sourceDigits.slice(0, 6).reduce((sum, digit) => sum + current.probabilities[Number(digit)], 0)), randomBaselinePercent: 60, minEvidenceSamples: MIN_EVIDENCE },
    freshness: { lastTrainingDate, calendarGapDays, status: calendarGapDays > 3 ? 'check_latest_result' : 'recent' },
    probabilities: Object.fromEntries(DIGITS.map((digit, i) => [digit, round(current.probabilities[i])])),
    confidence: evidence.samples < MIN_EVIDENCE ? 'insufficient' : policy.decision === 'SKIP' ? 'low' : lower! > 0.7 ? 'high' : 'medium',
    evidence: proven ? 'above_uniform_baseline' : 'unproven',
    experts: METHODS.map((method, i) => { const summary = stats(logs[i]); return { method, window: current.candidates[i].window, weight: round(current.weights[i]),
      samples: current.candidates[i].active ? current.candidates[i].samples : 0, evaluationSamples: summary.samples,
      recentHitPercent: summary.samples ? round(100 * summary.hits / summary.samples) : null, brierScore: summary.brier === null ? null : round(summary.brier), maxMissStreak: summary.maxMissStreak }; }),
    behavior: { recentFrequencyShift: round(current.shift), dominantExpert: METHODS[dominantIndex] },
    evaluation: { samples: evidence.samples, hits: evidence.hits, hitPercent: evidence.samples ? round(100 * evidence.hits / evidence.samples) : 0,
      randomBaselinePercent: 60, frequencyHitPercent: recent.length ? round(100 * recent.filter(row => row.frequencyHit).length / recent.length) : 0,
      brierScore: evidence.brier === null ? null : round(evidence.brier), uniformBrierScore: evidence.samples ? 0.9 : null, frequencyBrierScore: mean('frequencyLoss'),
      maxMissStreak: evidence.maxMissStreak, lowerHitBound: lower === null ? null : round(lower),
      recent30HitPercent: recent.length >= 30 ? round(100 * recent.slice(-30).filter(row => row.hit).length / 30) : null,
      recent60HitPercent: recent.length >= 60 ? round(100 * recent.slice(-60).filter(row => row.hit).length / 60) : null,
      setComparisons: Math.max(0, recent.length - 1), setChanges: changes, setChangePercent: recent.length > 1 ? round(100 * changes / (recent.length - 1)) : 0,
      maxSameSetStreak: maxSame, scope: 'past_only_online_walk_forward' },
    policyEvaluation: { opportunities: recent.length, predictions: emitted.length, skipped: recent.length - emitted.length,
      coveragePercent: recent.length ? round(100 * emitted.length / recent.length) : 0, hits: emittedStats.hits,
      hitPercent: emitted.length ? round(100 * emittedStats.hits / emitted.length) : null, maxMissStreak: emittedStats.maxMissStreak },
  };
}
