/**
 * Display-only operating calendars for the source-index strip.
 * Never use these dates for betting, History Apply, scraping, recovery or settlement.
 * Market opening schedules may change; missing results remain explicitly unknown.
 * Defaults for unlisted/custom names retain the legacy Monday-Friday presentation.
 */
export type SourceIndexWeekLength = 5 | 6 | 7;

// Market names are the canonical base names from getEffectiveMarkets().
// Both OPEN and CLOSE inherit the same weekly display calendar.
const WEEK_LENGTH_BY_MARKET: Readonly<Record<string, SourceIndexWeekLength>> = {
  // 7-Day Markets (Monday – Sunday | All 7 Days Open)
  'SRIDEVI': 7,
  'MADHUR DAY': 7,
  'SUPREME DAY': 7,
  'SRIDEVI NIGHT': 7,
  'SUPREME NIGHT': 7,
  // 6-Day Markets (Monday – Saturday | Sunday OFF)
  'TIME BAZAR': 6,
  'MILAN DAY': 6,
  'RAJDHANI DAY': 6,
  'KALYAN': 6,
  'MADHUR NIGHT': 6,
  'MILAN NIGHT': 6,
  // 5-Day Markets (Monday – Friday | Saturday & Sunday OFF)
  'KALYAN NIGHT': 5,
  'RAJDHANI NIGHT': 5,
  'MAIN BAZAR': 5,
};

export function sourceIndexWeekLength(marketName?: string): SourceIndexWeekLength {
  const base = String(marketName || '')
    .trim()
    .replace(/\s+/g, ' ')
    .replace(/\s+(OPEN|CLOSE)$/i, '')
    .trim()
    .toUpperCase()
    .replace(/^(?:SHRIDEVI|SRIDEVI|SRIDEV) DAY\b/, 'SRIDEVI')
    .replace(/^(?:SHRIDEVI|SRIDEV)\b/, 'SRIDEVI');
  return WEEK_LENGTH_BY_MARKET[base] || 5;
}

/**
 * Checks whether a market operates on the given YYYY-MM-DD date based on its
 * 5-day (Mon–Fri), 6-day (Mon–Sat), or 7-day (Mon–Sun) schedule.
 */
export function isMarketOpenOnDate(marketName?: string, dateStr?: string): boolean {
  if (!dateStr || !/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return true;
  const day = new Date(`${dateStr}T00:00:00Z`);
  if (!Number.isFinite(day.getTime()) || day.toISOString().slice(0, 10) !== dateStr) return true;
  const weekday = day.getUTCDay(); // 0 = Sun, 1 = Mon ... 6 = Sat
  const weekLength = sourceIndexWeekLength(marketName);
  if (weekLength === 7) return true;
  if (weekLength === 6) return weekday !== 0;
  return weekday !== 0 && weekday !== 6;
}

export function getDateWeekdayScheduleInfo(dateStr?: string): {
  weekday: number;
  dayName: string;
  shortDay: string;
  activeScheduleLabel: string;
  closedScheduleNote: string | null;
  minWeekLength: SourceIndexWeekLength;
} {
  const names = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
  const shorts = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
  if (!dateStr || !/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    return {
      weekday: 1,
      dayName: 'WEEKDAY',
      shortDay: 'DAY',
      activeScheduleLabel: '5D · 6D · 7D ALL OPEN',
      closedScheduleNote: null,
      minWeekLength: 5,
    };
  }
  const day = new Date(`${dateStr}T00:00:00Z`);
  const weekday = Number.isFinite(day.getTime()) ? day.getUTCDay() : 1;
  const dayName = names[weekday] || 'WEEKDAY';
  const shortDay = shorts[weekday] || 'DAY';
  if (weekday === 0) {
    return {
      weekday,
      dayName,
      shortDay,
      activeScheduleLabel: '7-DAY MARKETS OPEN (SRIDEVI · MADHUR DAY · SUPREME DAY · SRIDEVI NIGHT · SUPREME NIGHT)',
      closedScheduleNote: '5D (Kalyan Night, Rajdhani Night, Main Bazar) & 6D (Time Bazar, Milan Day/Night, Rajdhani Day, Kalyan, Madhur Night) Sunday OFF',
      minWeekLength: 7,
    };
  }
  if (weekday === 6) {
    return {
      weekday,
      dayName,
      shortDay,
      activeScheduleLabel: '6-DAY & 7-DAY MARKETS OPEN (11 MARKETS · 22 CARDS)',
      closedScheduleNote: '5-Day Markets (Kalyan Night, Rajdhani Night, Main Bazar) Saturday OFF',
      minWeekLength: 6,
    };
  }
  return {
    weekday,
    dayName,
    shortDay,
    activeScheduleLabel: '5-DAY · 6-DAY · 7-DAY ALL 14 MARKETS OPEN (28 CARDS)',
    closedScheduleNote: null,
    minWeekLength: 5,
  };
}

export function sourceIndexStripLabel(marketName?: string): string {
  const count = sourceIndexWeekLength(marketName);
  return `Source indices · ${3 * count} days · ${count === 7 ? 'Mon–Sun' : count === 6 ? 'Mon–Sat' : 'Mon–Fri'} · ${count} + ${count} + ${count}`;
}

/** Last three rows of trading-day slots, oldest to newest, including selected date when open. */
export function sourceIndexDisplayDates(selectedDate: string, marketName?: string): string[] {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(selectedDate)) return [];
  const day = new Date(`${selectedDate}T00:00:00Z`);
  if (!Number.isFinite(day.getTime()) || day.toISOString().slice(0, 10) !== selectedDate) return [];
  const weekLength = sourceIndexWeekLength(marketName);
  const dates: string[] = [];
  while (dates.length < 3 * weekLength) {
    const weekday = day.getUTCDay();
    if (weekLength === 7 || (weekLength === 6 ? weekday !== 0 : weekday !== 0 && weekday !== 6)) {
      dates.push(day.toISOString().slice(0, 10));
    }
    day.setUTCDate(day.getUTCDate() - 1);
  }
  return dates.reverse();
}

/** Recent three-row page plus older saved working-day pages, without inventing results. */
export function sourceIndexDisplayPages(selectedDate: string, availableDates: Iterable<string>, marketName?: string): string[][] {
  const recent = sourceIndexDisplayDates(selectedDate, marketName);
  if (!recent.length) return [];
  const weekLength = sourceIndexWeekLength(marketName);
  const pageSize = weekLength * 3;
  const eligibleDay = (weekday: number) => weekLength === 7 || (weekLength === 6 ? weekday !== 0 : weekday !== 0 && weekday !== 6);
  const older = [...new Set(availableDates)].filter(date => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date >= recent[0]) return false;
    const day = new Date(`${date}T00:00:00Z`);
    return Number.isFinite(day.getTime()) && day.toISOString().slice(0, 10) === date && eligibleDay(day.getUTCDay());
  }).sort();
  const pages = [recent];
  for (let end = older.length; end > 0; end -= pageSize) pages.push(older.slice(Math.max(0, end - pageSize), end));
  return pages;
}

/** Display-only label for the strategy that was actually persisted on a card.
 * RECENT6 and RECENT4 are saved by both History Apply and manual quick actions;
 * no strategy is inferred from the chosen six digits or from a PASS/FAIL result.
 */
export function sourceIndexAppliedMethod(positionRule?: string): 'Keep 6' | 'Remove 4' | undefined {
  if (positionRule === 'RECENT6') return 'Keep 6';
  if (positionRule === 'RECENT4') return 'Remove 4';
  return undefined;
}

/** The cutoff-based history decision is a recommendation, NOT proof of application. */
export function sourceIndexHistorySuggestion(mode?: string): 'Keep 6' | 'Remove 4' | undefined {
  if (mode === 'keep6') return 'Keep 6';
  if (mode === 'remove4') return 'Remove 4';
  return undefined;
}
