import type { DayMarketRecord, UserProfile } from '../types';
import { isMirrorProtected } from './adminMirror';
import { getScrapeSource } from './scrapeProvenance';
import { modelSourceVersion } from './marketModelCard';
import { canReplaceLiveCombinedDecision, releaseLiveCombinedDecision } from './liveCombinedDecision';
import { confirmedAnkResult } from './autoRemoveResult';
import { getEffectiveMarkets } from '../data/markets';
const dateValid = (d: string) => /^\d{4}-\d{2}-\d{2}$/.test(d) && Number.isFinite(Date.parse(d));
import { carryResultSixHistory } from './carryResultSix';

export interface SniperOneDetails {
  winner: string;
  runnerUp?: string;
  winnerScore: number;
  actual?: string;
  mirrorCut?: string;
  padosiCut: string[];
  farakCut: string[];
  coldCut: string[];
  input: string;
  output: string;
  outputVersion: number;
  summary: string;
}

const ALL_DIGITS = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

/**
 * Collect settled history specific to this market's base identity (e.g. KALYAN, SRIDEVI, etc.).
 * Scans preceding dates for Open & Close draws of this base market.
 */
export function collectMarketSettledHistory(
  profile: UserProfile,
  date: string,
  marketName: string,
  index: number,
  limit: number = 15,
): Array<{ actual: string; status: 'PASS' | 'FAIL'; marketName: string; date: string }> {
  const baseMarket = String(marketName || '').replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
  const markets = getEffectiveMarkets(profile.config);
  const out: Array<{ actual: string; status: 'PASS' | 'FAIL'; marketName: string; date: string }> = [];

  const dates = Object.keys(profile.dayRecords || {})
    .filter(d => dateValid(d) && d <= date)
    .sort()
    .reverse();

  for (const d of dates) {
    const day = profile.dayRecords[d];
    if (!day || !day.data) continue;

    const entries = Object.entries(day.data).sort((a, b) => Number(b[0]) - Number(a[0]));
    for (const [iStr, rec] of entries) {
      const i = Number(iStr);
      if (d === date && i >= index) continue;

      const mName = rec?.marketName || markets[i]?.n || '';
      const recBase = mName.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();

      // Only match draws from this specific base market
      if (!baseMarket || recBase !== baseMarket) continue;

      let actual = confirmedAnkResult(rec);
      if (!actual && (rec?.s === 'PASS' || rec?.s === 'FAIL')) {
        const cand = rec.manualStatus
          ? rec.manualResult
          : rec.scrapeResultDigit || (rec.backtestResult?.checked ? rec.backtestResult.actual : undefined);
        if (/^\d$/.test(String(cand || ''))) {
          actual = String(cand);
        }
      }

      if (actual && /^\d$/.test(actual)) {
        // The outer guard already established a settled record. Prefer its
        // canonical status if a stale backtest payload contains WAIT/unknown.
        const backtestStatus = (rec.backtestResult as any)?.status;
        const status: 'PASS' | 'FAIL' = backtestStatus === 'PASS' || backtestStatus === 'FAIL'
          ? backtestStatus
          : rec.s as 'PASS' | 'FAIL';
        out.push({ actual, status, marketName: mName, date: d });
        if (out.length >= limit) break;
      }
    }
    if (out.length >= limit) break;
  }

  return out.reverse();
}

/**
 * Retrieve the immediate preceding actual for this specific card:
 * - If CLOSE: check today's confirmed OPEN of the same base market.
 * - If not settled or OPEN: check yesterday's CLOSE of this same base market.
 * - Fallback: chronologically preceding settled actual across all markets.
 */
export function getPrecedingMarketActual(
  profile: UserProfile,
  date: string,
  index: number,
  marketName: string,
  record?: DayMarketRecord,
): string | undefined {
  const baseMarket = String(marketName || '').replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
  const isClose = /\s+CLOSE$/i.test(marketName);
  const day = profile.dayRecords?.[date];

  // 1. If this is a CLOSE card, check if today's OPEN of this market is confirmed
  if (isClose && day?.data && baseMarket) {
    const markets = getEffectiveMarkets(profile.config);
    const openName = `${baseMarket} OPEN`;
    const openIdx = markets.findIndex(m => m.n.trim().toUpperCase() === openName);
    const openRec = openIdx >= 0 ? day.data[openIdx] : Object.values(day.data).find(r => String(r?.marketName || '').trim().toUpperCase() === openName);
    if (openRec) {
      const act = confirmedAnkResult(openRec) || (openRec.manualStatus ? openRec.manualResult : openRec.scrapeResultDigit || (openRec.backtestResult?.checked ? openRec.backtestResult.actual : undefined));
      if (act && /^\d$/.test(String(act))) {
        return String(act);
      }
    }
  }

  // 2. Check preceding settled draws of this same base market
  const marketHist = collectMarketSettledHistory(profile, date, marketName, index, 5);
  if (marketHist.length > 0) {
    const lastMktCard = marketHist[marketHist.length - 1];
    if (lastMktCard?.actual && /^\d$/.test(lastMktCard.actual)) {
      return lastMktCard.actual;
    }
  }

  // 3. Fallback: chronologically preceding settled card in recovery order
  const globalHist = carryResultSixHistory(profile, date, index, marketName, record, 1);
  return globalHist[0]?.actual;
}

/**
 * Find the latest settled Jodi (Open + Close) difference for this base market.
 */
export function getMarketLastJodiFarak(
  profile: UserProfile,
  date: string,
  marketName: string,
  index: number,
): number | null {
  const baseMarket = String(marketName || '').replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
  if (!baseMarket) return null;

  const dates = Object.keys(profile.dayRecords || {})
    .filter(d => dateValid(d) && d <= date)
    .sort()
    .reverse();

  for (const d of dates) {
    const day = profile.dayRecords[d];
    if (!day || !day.data) continue;

    const markets = getEffectiveMarkets(profile.config);
    const openName = `${baseMarket} OPEN`;
    const closeName = `${baseMarket} CLOSE`;

    const openIdx = markets.findIndex(m => m.n.trim().toUpperCase() === openName);
    const closeIdx = markets.findIndex(m => m.n.trim().toUpperCase() === closeName);

    // If on current date, ensure they precede index
    if (d === date && (openIdx >= index || closeIdx >= index)) continue;

    const openRec = openIdx >= 0 ? day.data[openIdx] : Object.values(day.data).find(r => String(r?.marketName || '').trim().toUpperCase() === openName);
    const closeRec = closeIdx >= 0 ? day.data[closeIdx] : Object.values(day.data).find(r => String(r?.marketName || '').trim().toUpperCase() === closeName);

    if (openRec && closeRec) {
      const oAct = confirmedAnkResult(openRec) || (openRec.manualStatus ? openRec.manualResult : openRec.scrapeResultDigit || (openRec.backtestResult?.checked ? openRec.backtestResult.actual : undefined));
      const cAct = confirmedAnkResult(closeRec) || (closeRec.manualStatus ? closeRec.manualResult : closeRec.scrapeResultDigit || (closeRec.backtestResult?.checked ? closeRec.backtestResult.actual : undefined));
      if (oAct && cAct && /^\d$/.test(String(oAct)) && /^\d$/.test(String(cAct))) {
        return Math.abs(Number(oAct) - Number(cAct));
      }
    }
  }

  return null;
}

/**
 * Multi-Layer Market-Specific Dynamic Tournament Engine for Single Golden Ank (Sniper-1):
 * Every market evaluates its OWN chart history, its OWN scraper ranking, and its OWN preceding actual!
 */
export function evaluateSniperOneEngine(
  rawInput: string,
  marketName: string,
  marketHistory: Array<{ actual: string; status: 'PASS' | 'FAIL'; marketName: string; date: string }>,
  precedingActual?: string,
  lastJodiFarak?: number | null,
  todayPicks?: Record<string, number>,
): { formatted: string; details: Omit<SniperOneDetails, 'outputVersion'> } | null {
  const scrapedDigits = [...new Set(rawInput.match(/\d/g) || [])];
  if (!scrapedDigits.length) return null;

  // 1. Market-Specific Frequency (from this market's own draws)
  const marketFreq: Record<string, number> = {};
  for (const d of ALL_DIGITS) marketFreq[d] = 0;
  for (const item of marketHistory.slice(-10)) {
    if (/^\d$/.test(item.actual)) {
      marketFreq[item.actual] = (marketFreq[item.actual] || 0) + 1;
    }
  }

  // 2. Market Cold Cut (the 2 coldest digits in this market)
  let coldCut: string[] = [];
  if (marketHistory.length >= 4) {
    const sortedCold = [...ALL_DIGITS].sort((a, b) => marketFreq[a] - marketFreq[b]);
    coldCut = sortedCold.slice(0, 2);
  }

  // 3. Mirror & Padosi of this market's direct preceding draw
  let mirrorCut: string | undefined;
  const padosiCut: string[] = [];
  if (precedingActual !== undefined && /^\d$/.test(String(precedingActual).trim())) {
    const act = Number(precedingActual);
    mirrorCut = String((act + 5) % 10);
    const left = String((act - 1 + 10) % 10);
    const right = String((act + 1) % 10);
    padosiCut.push(left, right);
  }

  // 4. Market-Specific Jodi Farak Cut
  const farakCut: string[] = [];
  if (lastJodiFarak !== undefined && lastJodiFarak !== null) {
    const f = lastJodiFarak % 10;
    const fMir = (f + 5) % 10;
    farakCut.push(String(f), String(fMir));
  }

  // Penalty weights for cuts
  const cutPenalties: Record<string, number> = {};
  if (mirrorCut) cutPenalties[mirrorCut] = (cutPenalties[mirrorCut] || 0) + 15;
  for (const p of padosiCut) cutPenalties[p] = (cutPenalties[p] || 0) + 12;
  for (const f of farakCut) cutPenalties[f] = (cutPenalties[f] || 0) + 10;
  for (const c of coldCut) cutPenalties[c] = (cutPenalties[c] || 0) + 8;

  // Center density cluster on this card's sorted scraped digits
  const sortedScraped = [...scrapedDigits].sort((a, b) => Number(a) - Number(b));
  const midStart = Math.max(0, Math.floor(sortedScraped.length / 2) - 1);
  const centerCluster = new Set(sortedScraped.slice(midStart, midStart + 3));

  // Score each scraped candidate with market-specific weights
  const latestMarketDraw = marketHistory.length > 0 ? marketHistory[marketHistory.length - 1] : undefined;
  const scored = scrapedDigits.map((d, idx) => {
    let score = 0;

    // A. Card's Scraped Source Rank (Highest influence: #1 scraped digit gets +18 pts down to +2 pts)
    const sourceRankPts = Math.max(2, 18 - (idx * 3));
    score += sourceRankPts;

    // B. Market's Own Frequency Score (+5 pts per appearance in this market's recent draws)
    score += (marketFreq[d] || 0) * 5;

    // C. Reverse Inversion / Trend Strike
    if (precedingActual !== undefined && /^\d$/.test(precedingActual)) {
      const actNum = Number(precedingActual);
      const candNum = Number(d);

      if (latestMarketDraw?.status === 'FAIL') {
        if (candNum % 2 !== actNum % 2) score += 6; // Polarity flip on fail
        const actHigh = actNum >= 5 || actNum === 0;
        const candHigh = candNum >= 5 || candNum === 0;
        if (candHigh !== actHigh) score += 4; // High/low flip on fail
      } else {
        if (candNum % 2 === actNum % 2) score += 3; // Polarity continuation on pass
      }

      // Avoid immediate direct repeat of previous actual
      if (d === precedingActual) score -= 8;
    }

    // D. Center Cluster bonus (+3 pts for balanced non-extreme digits)
    if (centerCluster.has(d)) score += 3;

    // E. Cut Penalties (Mirror, Padosi, Farak, Cold)
    const penalty = cutPenalties[d] || 0;
    score -= penalty;

    // F. Anti-Monopoly Daily Diversity Penalty (if already picked today)
    if (todayPicks && todayPicks[d]) {
      score -= todayPicks[d] * 5;
    }

    return { digit: d, score, rank: idx };
  });

  scored.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    return a.rank - b.rank;
  });

  const winnerObj = scored[0];
  const runnerUpObj = scored[1];
  const winner = winnerObj.digit;

  const summaryParts: string[] = [`🎯 Pick: ${winner} (${winnerObj.score} pts)`];
  if (runnerUpObj) summaryParts.push(`Bkp: ${runnerUpObj.digit}`);
  if (mirrorCut) summaryParts.push(`MirCut: ${mirrorCut}`);
  if (padosiCut.length) summaryParts.push(`PadCut: ${padosiCut.join(',')}`);
  if (farakCut.length) summaryParts.push(`FarakCut: ${[...new Set(farakCut)].join(',')}`);

  return {
    formatted: winner,
    details: {
      winner,
      runnerUp: runnerUpObj?.digit,
      winnerScore: winnerObj.score,
      actual: precedingActual,
      mirrorCut,
      padosiCut,
      farakCut: [...new Set(farakCut)],
      coldCut,
      input: rawInput,
      output: winner,
      summary: summaryParts.join(' · '),
    },
  };
}

/**
 * Apply Sniper-1 Single Ank Dynamic Engine to an individual DayMarketRecord.
 */
export function applySniperOne(
  record: DayMarketRecord | undefined,
  profile: UserProfile,
  date: string,
  index: number,
  marketName?: string,
  todayPicks?: Record<string, number>,
): DayMarketRecord | undefined {
  if (!record || record.s !== 'WAIT' || record.manualStatus || record.deliveryRestoredAt || record.dispatchState || isMirrorProtected(record) || !canReplaceLiveCombinedDecision(record)) {
    return undefined;
  }

  const source = getScrapeSource(record);
  const raw = String(record.od || source?.digits || record.d || '').trim();
  const digits = raw.match(/\d/g);
  if (!digits || digits.length < 1) return undefined;

  const mName = marketName || record.marketName || '';
  const marketHistory = collectMarketSettledHistory(profile, date, mName, index, 12);
  const precedingActual = getPrecedingMarketActual(profile, date, index, mName, record);
  const lastJodiFarak = getMarketLastJodiFarak(profile, date, mName, index);

  const result = evaluateSniperOneEngine(raw, mName, marketHistory, precedingActual, lastJodiFarak, todayPicks);
  if (!result) return undefined;

  const version = Math.max(Date.now(), modelSourceVersion(record) + 1);
  const next: DayMarketRecord = {
    ...record,
    d: result.formatted,
    od: record.od || source?.digits || raw,
    positionRule: 'SNIPER_1',
    sniperOne: {
      ...result.details,
      outputVersion: version,
    },
    sourceEditedAt: version,
  };

  releaseLiveCombinedDecision(next);
  delete next.trick;
  delete next.triCut;
  delete next.tesla369;
  delete next.firstDigitMirrorCut;
  delete next.weekdaySelectedDigits;
  delete next.weekdayHitPosition;
  delete next.scrapeResultDigit;
  delete next.manualResult;
  delete next.manualResultSources;
  delete next.backtestResult;
  delete next.marketModel;
  delete next.autoRemovedResult;
  delete next.autoResultParity;
  delete next.smartSelection;

  if (!next.manualRate) {
    delete next.recRate;
    delete next.prevLoss;
    delete next.targetProfitWithLoss;
    delete next.rateFinalizedFrom;
    delete next.rateFinalizedAt;
  }

  return next;
}
