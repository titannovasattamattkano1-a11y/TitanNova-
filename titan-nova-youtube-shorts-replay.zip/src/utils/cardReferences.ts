import type {DayMarketRecord} from '../types';

/** Market indices are addresses, not identity. Move every saved financial
 * reference with its card when the catalog is inserted, hidden or restored. */
export function remapCardReferences(record:DayMarketRecord,keys:Record<string,string>):DayMarketRecord {
  const ref=(key:string)=>keys[key]??key;
  const manual=record.manualResultSources?.map(ref);
  const shares=record.twoCardRecoveryShares?.map(share=>({...share,source:ref(share.source)}));
  const from=record.rateFinalizedFrom?ref(record.rateFinalizedFrom):undefined;
  if(JSON.stringify(manual)===JSON.stringify(record.manualResultSources)&&JSON.stringify(shares)===JSON.stringify(record.twoCardRecoveryShares)&&from===record.rateFinalizedFrom)return record;
  return {...record,...(manual?{manualResultSources:manual}:{}),...(shares?{twoCardRecoveryShares:shares}:{}),...(from?{rateFinalizedFrom:from}:{})};
}
