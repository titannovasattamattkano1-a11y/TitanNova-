type RecoveryEntry = { debt?: number; fromCardKey?: string; fromIndex?: number; updatedAt?: number; consecutiveFails?: number; pendingProfit?: number };

/**
 * Preserve outstanding recovery debt when ANK/PANEL Smart Stake (Split) mode changes.
 * ON (per-base-market tracks e.g. ank:SRIDEVI) → OFF (unified track ank:ALL) combines active debts.
 * OFF (ank:ALL) → ON assigns the unified chain to the base market of its latest source card.
 */
export function migrateRecoveryStateForSplitChange(
  input: Record<string, RecoveryEntry> | undefined,
  markets: Array<{ type?: string; index?: number; n?: string }> | undefined,
  type: 'ank' | 'pannel',
  wasSplit: boolean,
  isSplit: boolean,
): Record<string, RecoveryEntry> {
  const state = { ...(input || {}) };
  if (wasSplit === isSplit) return state;

  const prefix = `${type}:`;
  const allKey = `${type}:ALL`;

  if (!isSplit) {
    const splitKeys = Object.keys(state).filter((k) => k.startsWith(prefix) && k !== allKey);
    const entries = splitKeys.map((k) => state[k]).filter(Boolean) as RecoveryEntry[];
    const latest = [...entries].sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0))[0] || {};
    state[allKey] = {
      debt: entries.reduce((sum, entry) => sum + Math.max(0, Number(entry.debt) || 0), 0),
      fromCardKey: latest.fromCardKey,
      fromIndex: entries.length ? Math.max(...entries.map((entry) => Number(entry.fromIndex ?? -1))) : -1,
      updatedAt: Math.max(0, ...entries.map((entry) => Number(entry.updatedAt || 0))),
    };
    for (const k of splitKeys) delete state[k];
    return state;
  }

  const unified = state[allKey] || { debt: 0, fromIndex: -1 };
  const sourceIndex = Number.isFinite(Number(unified.fromIndex))
    ? Number(unified.fromIndex)
    : Number(String(unified.fromCardKey || '').split('_').pop());
  const sourceMarket = (markets || []).find((market) => String(market.type) === type && Number(market.index) === sourceIndex);
  const baseMarket = String(sourceMarket?.n || '')
    .replace(/\s+(OPEN|CLOSE)$/i, '')
    .trim()
    .toUpperCase();
  const destinationKey = baseMarket ? `${type}:${baseMarket}` : `${type}:OPEN`;
  state[destinationKey] = { ...unified };
  delete state[allKey];
  return state;
}
