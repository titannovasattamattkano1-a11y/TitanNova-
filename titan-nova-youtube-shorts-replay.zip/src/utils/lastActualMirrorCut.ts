import type {DayMarketRecord,UserProfile} from '../types';
import {findHistoricalMarketRecord} from './cardHistory';
import {confirmedAnkResult} from './autoRemoveResult';
import {isMirrorProtected} from './adminMirror';
import {getScrapeSource} from './scrapeProvenance';
import {canReplaceLiveCombinedDecision,releaseLiveCombinedDecision} from './liveCombinedDecision';
const validDate=(date:string)=>/^\d{4}-\d{2}-\d{2}$/.test(date)&&Number.isFinite(Date.parse(date))&&new Date(date).toISOString().slice(0,10)===date;
/** Latest settled prior draw only; missing/conflicting latest actual never falls back to an older draw. */
export function latestMarketDrawActual(days:UserProfile['dayRecords'],date:string,index:number,market:string):{date:string;actual:string}|undefined {
  if(!validDate(date))return;
  for(const day of Object.keys(days||{}).filter(d=>validDate(d)&&d<date).sort().reverse()){
    const rec=findHistoricalMarketRecord(days[day]?.data,index,market);
    if(rec?.s!=='PASS'&&rec?.s!=='FAIL')continue;
    const actual=confirmedAnkResult(rec);
    const evidence=[rec.manualResult,rec.scrapeResultDigit,rec.backtestResult?.checked?rec.backtestResult.actual:undefined].filter(v=>v!==undefined&&v!=='');
    if(actual===undefined||evidence.some(v=>!/^\d$/.test(String(v))||String(v)!==actual))return;
    return {date:day,actual};
  }
}
/** Cumulative actual+mirror cut. It never switches T1/T2 or selects a fallback digit. */
export function removeLastActualAndMirror(record:DayMarketRecord|undefined,actual:string|undefined):DayMarketRecord|undefined {
  if(!record||record.s!=='WAIT'||record.manualStatus||record.deliveryRestoredAt||record.dispatchState||isMirrorProtected(record)||!canReplaceLiveCombinedDecision(record)||!/^\d$/.test(actual||''))return;
  const current=record.d.split(/[,|\s]+/).filter(Boolean);
  if(!current.length||new Set(current).size!==current.length||!current.every(d=>/^\d$/.test(d)))return;
  const cut=new Set([actual!,String((Number(actual)+5)%10)]),kept=current.filter(d=>!cut.has(d));
  if(!kept.length||kept.length===current.length)return;
  const source=getScrapeSource(record);
  const next:DayMarketRecord={...record,d:kept.join(', '),od:source?.digits||record.od||record.d,positionRule:'LAST_ACTUAL_MIRROR',sourceEditedAt:Math.max(Date.now(),Number(record.sourceEditedAt||0)+1,Number(record.marketModel?.updatedAt||0)+1)};
  releaseLiveCombinedDecision(next);
  delete next.trick;delete next.weekdaySelectedDigits;delete next.weekdayHitPosition;
  delete next.scrapeResultDigit;delete next.manualResult;delete next.manualResultSources;delete next.backtestResult;
  delete next.marketModel;delete next.autoRemovedResult;delete next.autoResultParity;
  if(!next.manualRate){delete next.recRate;delete next.prevLoss;delete next.targetProfitWithLoss;delete next.rateFinalizedFrom;delete next.rateFinalizedAt;}
  return next;
}
