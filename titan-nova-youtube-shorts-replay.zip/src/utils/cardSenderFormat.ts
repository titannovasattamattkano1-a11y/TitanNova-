export type CardSenderFormat='text'|'png';
export type CardSenderPlatform='whatsapp'|'telegram';
export type CardSenderFormats=Record<CardSenderPlatform,CardSenderFormat>;
const valid=(value:unknown):value is CardSenderFormat=>value==='text'||value==='png';
export function profileCardSenderFormats(config:any):CardSenderFormats {
 const fallback:CardSenderFormat=config?.cardSenderFormat==='png'?'png':'text';
 return {whatsapp:valid(config?.cardSenderFormats?.whatsapp)?config.cardSenderFormats.whatsapp:fallback,telegram:valid(config?.cardSenderFormats?.telegram)?config.cardSenderFormats.telegram:fallback};
}
/** Freeze both formats once, so the second platform/retries retain the same choice. */
export function cardSenderPresentation(item:any,config:any){
 const fallback:CardSenderFormat=valid(item?.senderFormat)?item.senderFormat:config?.cardSenderFormat==='png'?'png':'text';
 const formats= item?.senderFormats ? profileCardSenderFormats({cardSenderFormat:fallback,cardSenderFormats:item.senderFormats}) : valid(item?.senderFormat)?{whatsapp:fallback,telegram:fallback}:profileCardSenderFormats(config);
 return {senderFormat:fallback,senderFormats:formats};
}
export function cardSenderFormatForDelivery(item:any,platform:CardSenderPlatform):CardSenderFormat {
 return profileCardSenderFormats({cardSenderFormat:item?.senderFormat,cardSenderFormats:item?.senderFormats})[platform];
}
export function cardUsesPng(item:any):boolean {
 return cardSenderFormatForDelivery(item,'whatsapp')==='png'||cardSenderFormatForDelivery(item,'telegram')==='png';
}
