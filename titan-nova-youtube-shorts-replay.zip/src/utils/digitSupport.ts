import type {DayMarketRecord,GameType,UserProfile} from '../types';
import {getEffectiveMarkets,getEffectiveBaseMarkets} from '../data/markets';
import {findHistoricalMarketRecord,findMarketIndexByName} from './cardHistory';
import {normalizeManualResult} from './manualResult';
import {cutCurrentSourceDigits} from './cumulativeSourceCut';

/** SupportLow is the lighter second SUPPORT circle, not different visible text. */
export type DigitSupport='Strong'|'Support'|'SupportLow';
export type MssdSourceKey='AUTO'|'WEEKDAY'|'COMBO'|'DAY_COMBO';
const validDate=(value:string)=>/^\d{4}-\d{2}-\d{2}$/.test(value)&&Number.isFinite(Date.parse(value))&&new Date(value).toISOString().slice(0,10)===value;
const split=(value:unknown)=>String(value??'').split(/[,|\s]+/).filter(Boolean);

/** Read-only latest-to-oldest actual results, ending exactly at unique result ten. */
const sortedDayKeysCache = new WeakMap<object, { count: number; sorted: string[] }>();
function getSortedDayKeysDesc(dayRecords: Record<string, unknown> | undefined): string[] {
 if (!dayRecords || typeof dayRecords !== "object") return [];
 const rawKeys = Object.keys(dayRecords);
 let cached = sortedDayKeysCache.get(dayRecords);
 if (!cached || cached.count !== rawKeys.length) {
  cached = { count: rawKeys.length, sorted: rawKeys.filter(validDate).sort().reverse() };
  sortedDayKeysCache.set(dayRecords, cached);
 }
 return cached.sorted;
}

export function dynamicSupportRanking(
 profile:UserProfile|undefined,
 date:string,
 type:GameType,
 market:string,
 sharedHistory?:UserProfile,
 sourceDigitsOverride?:string,
){
 if(!profile||!['ank','jodi','pannel'].includes(type)||!validDate(date))return;
 const markets=type==='jodi'?getEffectiveBaseMarkets(profile.config):getEffectiveMarkets(profile.config);
 const index=findMarketIndexByName(markets,market);if(index<0)return;
 const dict=type==='ank'?'data':type==='jodi'?'jodiData':'pannelData';
 const sharedIndex=sharedHistory?findMarketIndexByName(type==='jodi'?getEffectiveBaseMarkets(sharedHistory.config):getEffectiveMarkets(sharedHistory.config),market):-1;
 const ownDates = getSortedDayKeysDesc(profile.dayRecords);
 const sharedDates = sharedIndex >= 0 && sharedHistory?.dayRecords && sharedHistory.dayRecords !== profile.dayRecords
  ? getSortedDayKeysDesc(sharedHistory.dayRecords)
  : [];
 const dates = (sharedDates.length ? [...new Set([...ownDates, ...sharedDates])].sort().reverse() : ownDates)
  .filter(day => day < date);
 const counts=new Map<string,{token:string;count:number;first:number}>();
 const usedDates:string[]=[];
 let sawConflict=false;
 const readActual=(rec:ReturnType<typeof findHistoricalMarketRecord>)=>{
  if(!rec||!['PASS','FAIL'].includes(rec.s))return {actual:undefined,conflict:false};
  const values=[rec.manualResult,rec.scrapeResultDigit,rec.backtestResult?.checked?rec.backtestResult.actual:undefined].filter(v=>v!==undefined&&v!=='');
  const normalized=values.map(v=>normalizeManualResult(type,v));
  const conflict=normalized.some(v=>!v)||new Set(normalized).size>1;
  return {actual:conflict?undefined:normalized[0],conflict};
 };
 for(const day of dates){
  const own=readActual(findHistoricalMarketRecord(profile.dayRecords?.[day]?.[dict],index,market));
  if(own.conflict){sawConflict=true;continue;}
  const actual=own.actual??(sharedIndex>=0?readActual(findHistoricalMarketRecord(sharedHistory?.dayRecords?.[day]?.[dict],sharedIndex,market)).actual:undefined);
  if(!actual)continue;
  const item=counts.get(actual)||{token:actual,count:0,first:usedDates.length};
  item.count++;counts.set(actual,item);usedDates.push(day);
  if(counts.size===10)break;
 }
 const current=findHistoricalMarketRecord(profile.dayRecords?.[date]?.[dict],index,market);
 const sharedCurrent=sharedIndex>=0?findHistoricalMarketRecord(sharedHistory?.dayRecords?.[date]?.[dict],sharedIndex,market):undefined;
 const source=split(
  sourceDigitsOverride||
  current?.sentScrapeSource?.digits||
  current?.scrapeSource?.digits||
  current?.smartSelection?.sourceDigits||
  current?.od||
  sharedCurrent?.sentScrapeSource?.digits||
  sharedCurrent?.scrapeSource?.digits||
  sharedCurrent?.smartSelection?.sourceDigits||
  sharedCurrent?.od
 );
 const sourceOrder=new Map<string,number>();
 for(const token of source){
  const normalized=normalizeManualResult(type,token);
  if(normalized&&!sourceOrder.has(normalized))sourceOrder.set(normalized,sourceOrder.size);
 }
 // When settled dayRecords have fewer than 10 unique draws (e.g. fresh market history),
 // complete the 10-token ranking from the current card's verified 10-digit chart source
 // only if there were no conflicting result records.
 if(counts.size<10&&!sawConflict&&sourceOrder.size===10){
  for(const [token,orderIdx] of sourceOrder.entries()){
   if(!counts.has(token)){
    counts.set(token,{token,count:0,first:usedDates.length+orderIdx});
   }
   if(counts.size===10)break;
  }
 }
 // Never fabricate missing history or fill a complete ranking with unseen results.
 if(counts.size!==10)return;
 const ranked=[...counts.values()].sort((a,b)=>b.count-a.count
  ||(sourceOrder.get(a.token)??Infinity)-(sourceOrder.get(b.token)??Infinity)
  ||a.first-b.first||a.token.localeCompare(b.token));
 return {windowLength:usedDates.length||sourceOrder.size,newestDate:usedDates[0]||date,oldestDate:usedDates.at(-1)||date,
  ranked,groups:{high:ranked.slice(0,3),medium:ranked.slice(3,7),low:ranked.slice(7,10)}};
}

/** PNG presentation only: strongest available member of each 3/4/3 frequency band (or Smart strong/support ranking). */
export function cardDigitSupport(
 profile:UserProfile|undefined,
 date:string,
 type:GameType,
 market:string,
 digits:string,
 sharedHistory?:UserProfile,
 sourceDigitsOverride?:string,
):Record<string,DigitSupport>|undefined{
 const tokens=[...new Set(split(digits))];
 if(!tokens.length||tokens.some(token=>!normalizeManualResult(type,token)))return;
 const ranking=dynamicSupportRanking(profile,date,type,market,sharedHistory,sourceDigitsOverride);
 const available=new Map(tokens.map(token=>[normalizeManualResult(type,token)!,token]));
 if(ranking){
  const result:Record<string,DigitSupport>={};
  for(const [group,label] of [['high','Strong'],['medium','Support'],['low','SupportLow']] as const){
   const pick=ranking.groups[group].find(item=>available.has(item.token));
   if(pick)result[available.get(pick.token)!]=label;
  }
  if(Object.keys(result).length)return result;
 }
 // Fallback for Smart-selected cards when historical dayRecords are empty:
 if(profile&&type==='ank'){
  const markets=getEffectiveMarkets(profile.config);
  const index=findMarketIndexByName(markets,market);
  const current=index>=0?findHistoricalMarketRecord(profile.dayRecords?.[date]?.data,index,market):undefined;
  const smart=current?.smartSelection;
  if(smart&&Array.isArray(smart.strongDigits)&&smart.strongDigits.length){
   const out:Record<string,DigitSupport>={};
   const strongPick=smart.strongDigits.find(t=>available.has(t));
   if(strongPick)out[available.get(strongPick)!]='Strong';
   const supCandidates=[...(smart.supportDigits||[]),...smart.strongDigits.slice(1)].filter(t=>t!==strongPick&&available.has(t));
   if(supCandidates[0])out[available.get(supCandidates[0])!]='Support';
   if(supCandidates[1])out[available.get(supCandidates[1])!]='SupportLow';
   if(Object.keys(out).length)return out;
  }
 }
 return undefined;
}

/**
 * SSD (Support Strong Digit) filter:
 * Evaluates ONLY the digits currently remaining in the card's box (record.d),
 * keeps only the digits marked as Strong or Support (Support / SupportLow),
 * and cuts all other digits from the current box without restoring earlier cuts.
 */
export function keepSupportStrongDigits(
 record:DayMarketRecord|undefined,
 profile:UserProfile|undefined,
 date:string,
 market:string,
 sharedHistory?:UserProfile,
):DayMarketRecord|undefined{
 if(!record||!profile)return undefined;
 const current=split(record.d).filter(d=>/^\d$/.test(d));
 if(!current.length)return undefined;
 const supportMap=cardDigitSupport(profile,date,'ank',market,current.join(', '),sharedHistory);
 if(!supportMap)return undefined;
 const keepSet=new Set(Object.keys(supportMap));
 if(!keepSet.size)return undefined;
 const targetsToCut=current.filter(d=>!keepSet.has(d));
 if(!targetsToCut.length&&record.positionRule==='SSD')return undefined;
 return cutCurrentSourceDigits(record,targetsToCut,'SSD',targetsToCut.length===0);
}

/** Compute 3 SSD digits (Strong, Support, SupportLow) directly from a chart observation stream and 10-digit source. */
export function computeSourceSsdFromStream(streamDigits:Iterable<string>,sourceDigits:string):string[]{
 const srcTokens=split(sourceDigits).filter(d=>/^\d$/.test(d));
 const sourceOrder=new Map<string,number>();
 for(const token of srcTokens){
  if(!sourceOrder.has(token))sourceOrder.set(token,sourceOrder.size);
 }
 const counts=new Map<string,{token:string;count:number;first:number}>();
 let step=0;
 for(const d of streamDigits){
  if(!/^\d$/.test(d))continue;
  const item=counts.get(d)||{token:d,count:0,first:step};
  item.count++;
  counts.set(d,item);
  step++;
  if(counts.size===10)break;
 }
 if(counts.size<10&&sourceOrder.size===10){
  for(const [token,orderIdx] of sourceOrder.entries()){
   if(!counts.has(token)){
    counts.set(token,{token,count:0,first:step+orderIdx});
   }
   if(counts.size===10)break;
  }
 }
 if(counts.size===10){
  const ranked=[...counts.values()].sort((a,b)=>b.count-a.count
   ||(sourceOrder.get(a.token)??Infinity)-(sourceOrder.get(b.token)??Infinity)
   ||a.first-b.first||a.token.localeCompare(b.token));
  const picks=[ranked[0]?.token,ranked[3]?.token,ranked[7]?.token].filter((x):x is string=>Boolean(x));
  const uniquePicks=[...new Set(picks)];
  return srcTokens.length?srcTokens.filter(d=>uniquePicks.includes(d)).slice(0,3):uniquePicks.slice(0,3);
 }
 if(srcTokens.length>=8)return [srcTokens[0],srcTokens[3],srcTokens[7]];
 return [...new Set(srcTokens)].slice(0,3);
}

/**
 * Extract up to 3 SSD digits (Strong, Support, SupportLow) from a 10-digit source
 * using the exact same SSD ranking as keepSupportStrongDigits.
 */
export function extractSsdDigits(
  profile: UserProfile | undefined,
  date: string,
  type: GameType,
  market: string,
  sourceDigits: string,
  sharedHistory?: UserProfile,
): string[] {
  const tokens = split(sourceDigits).filter(d => /^\d$/.test(d));
  if (!tokens.length) return [];
  const supportMap = cardDigitSupport(profile, date, type, market, tokens.join(', '), sharedHistory, sourceDigits);
  if (supportMap && Object.keys(supportMap).length > 0) {
    const keepSet = new Set(Object.keys(supportMap));
    const ordered = tokens.filter(d => keepSet.has(d));
    const uniqueOrdered: string[] = [];
    for (const d of ordered) {
      if (!uniqueOrdered.includes(d)) uniqueOrdered.push(d);
    }
    return uniqueOrdered.slice(0, 3);
  }
  return computeSourceSsdFromStream([], sourceDigits);
}

export function mergeUniqueMssdDigits(...groups: string[][]): string[] {
  const result: string[] = [];
  for (const group of groups) {
    for (const d of group) {
      if (/^\d$/.test(d) && !result.includes(d)) {
        result.push(d);
      }
    }
  }
  return result;
}

/**
 * Build the 4-click progressive MSSD plan:
 * - Click 1 (Stage 1): Auto SSD only
 * - Click 2 (Stage 2): Auto SSD + Day SSD (duplicates cut)
 * - Click 3 (Stage 3): Auto SSD + Day SSD + Combo SSD (duplicates cut)
 * - Click 4 (Stage 4): Auto SSD + Day SSD + Combo SSD + DayCombo SSD (duplicates cut)
 */
export function buildMssdFourClickPlan(
  sources: Partial<Record<MssdSourceKey, string>>,
  profile?: UserProfile,
  date = '',
  market = '',
  sharedHistory?: UserProfile,
  fallbackSsdByMode?: Partial<Record<MssdSourceKey, string[]>>,
): {
  sources: Record<MssdSourceKey, string>;
  ssdByMode: Record<MssdSourceKey, string[]>;
  stageDigits: { 1: string; 2: string; 3: string; 4: string };
} {
  const cleanSources: Record<MssdSourceKey, string> = {
    AUTO: String(sources.AUTO || ''),
    WEEKDAY: String(sources.WEEKDAY || ''),
    COMBO: String(sources.COMBO || ''),
    DAY_COMBO: String(sources.DAY_COMBO || ''),
  };
  const resolveSsd = (mode: MssdSourceKey): string[] => {
    const src = cleanSources[mode];
    if (profile && date && market && src) {
      const extracted = extractSsdDigits(profile, date, 'ank', market, src, sharedHistory);
      if (extracted.length > 0) return mergeUniqueMssdDigits(extracted).slice(0, 3);
    }
    if (fallbackSsdByMode?.[mode]?.length) {
      return mergeUniqueMssdDigits(fallbackSsdByMode[mode]!).slice(0, 3);
    }
    return computeSourceSsdFromStream([], src);
  };
  const autoSsd = resolveSsd('AUTO');
  const daySsd = resolveSsd('WEEKDAY');
  const comboSsd = resolveSsd('COMBO');
  const dayComboSsd = resolveSsd('DAY_COMBO');

  const stage1 = mergeUniqueMssdDigits(autoSsd);
  const stage2 = mergeUniqueMssdDigits(stage1, daySsd);
  const stage3 = mergeUniqueMssdDigits(stage2, comboSsd);
  const stage4 = mergeUniqueMssdDigits(stage3, dayComboSsd);

  return {
    sources: cleanSources,
    ssdByMode: {
      AUTO: autoSsd,
      WEEKDAY: daySsd,
      COMBO: comboSsd,
      DAY_COMBO: dayComboSsd,
    },
    stageDigits: {
      1: stage1.join(', '),
      2: stage2.join(', '),
      3: stage3.join(', '),
      4: stage4.join(', '),
    },
  };
}

export function isActiveMssdRecord(record: DayMarketRecord | undefined): boolean {
  if (!record || record.sourceMode !== 'MSSD' || !record.mssdState) return false;
  return split(record.d).length > 0;
}

export function getNextMssdStage(record: DayMarketRecord | undefined): 1 | 2 | 3 | 4 {
  if (!isActiveMssdRecord(record)) return 1;
  const stage = record!.mssdState!.stage;
  if (stage === 1) return 2;
  if (stage === 2) return 3;
  if (stage === 3) return 4;
  return 1;
}

/**
 * MSSD (Mix Strong Support Digit):
 * Supports both 2-source (Auto + Day) and full 4-click progressive (Auto -> +Day -> +Combo -> +DayCombo)
 * while cutting any duplicate digits across stages.
 */
export function mixStrongSupportDigits(
  autoDigits: string,
  dayDigits: string,
  profile: UserProfile | undefined,
  date: string,
  market: string,
  sharedHistory?: UserProfile,
  comboDigits = '',
  dayComboDigits = '',
  stage: 1 | 2 | 3 | 4 = 2,
): {
  digits: string;
  autoSsd: string[];
  daySsd: string[];
  comboSsd: string[];
  dayComboSsd: string[];
  stageDigits: { 1: string; 2: string; 3: string; 4: string };
  count: number;
} {
  const plan = buildMssdFourClickPlan(
    {
      AUTO: autoDigits,
      WEEKDAY: dayDigits,
      COMBO: comboDigits,
      DAY_COMBO: dayComboDigits,
    },
    profile,
    date,
    market,
    sharedHistory,
  );
  const chosenDigits = plan.stageDigits[stage];
  const tokens = split(chosenDigits);
  return {
    digits: chosenDigits,
    autoSsd: plan.ssdByMode.AUTO,
    daySsd: plan.ssdByMode.WEEKDAY,
    comboSsd: plan.ssdByMode.COMBO,
    dayComboSsd: plan.ssdByMode.DAY_COMBO,
    stageDigits: plan.stageDigits,
    count: tokens.length,
  };
}
