import {buildCanonicalSinglePattiUniverse,normalizePanelPatti,isSinglePatti,panelAnkDigit,normalizeAnkDigits} from './panelAnk';
export interface StrictPanelDraw {date:string;panel:string}
export interface StrictPanel30Selection {
  mode:'RECENT30_ANK5';targetDate:string;side:'open'|'close';decision:'RETAIN'|'SKIP';
  reason:string;anks:string[];panels:string[];excluded:string[];eliminated:string[];
  buckets:Array<{ank:string;eligible:number;selected:string[]}>;
  scores:Record<string,number>;historySamples:number;lastHistoryDate?:string;
}
const weekday=(date:string)=>new Date(date+'T12:00:00Z').getUTCDay();
/** Strict dated side history: no target/future draw, no recent-repeat fill or quota redistribution. */
export function selectStrictPanel30(draws:StrictPanelDraw[],ankInput:unknown,targetDate:string,side:'open'|'close'):StrictPanel30Selection {
  const anks=normalizeAnkDigits(ankInput),universe=buildCanonicalSinglePattiUniverse();
  const byDate=new Map<string,string>();const conflicts=new Set<string>();
  for(const draw of draws){
    if(!/^\d{4}-\d{2}-\d{2}$/.test(draw.date)||draw.date>=targetDate)continue;
    const p=normalizePanelPatti(draw.panel);if(!p)continue;
    if(byDate.has(draw.date)&&byDate.get(draw.date)!==p)conflicts.add(draw.date);else byDate.set(draw.date,p);
  }
  const history=[...byDate].filter(([date])=>!conflicts.has(date)).sort((a,b)=>b[0].localeCompare(a[0])).filter(([,p])=>isSinglePatti(p));
  const excluded=[...new Set(history.map(([,p])=>p))].slice(0,30),banned=new Set(excluded);
  const eligible=universe.filter(p=>!banned.has(p)&&anks.includes(panelAnkDigit(p)!));
  const recent=history.slice(0,60),week=history.filter(([date])=>weekday(date)===weekday(targetDate)).slice(0,12);
  const count=(rows:typeof history,p:string)=>rows.filter(([,v])=>v===p).length;
  const features=eligible.map(p=>{const at=history.findIndex(([,v])=>v===p);return {p,f:count(recent,p),w:count(week,p),g:at<0?60:Math.min(60,at)};});
  const percentile=(key:'f'|'w'|'g',value:number)=>(features.filter(r=>r[key]<value).length+.5*features.filter(r=>r[key]===value).length)/Math.max(1,features.length);
  const scores=Object.fromEntries(features.map(r=>[r.p,Number((.5*percentile('f',r.f)+.3*percentile('w',r.w)+.2*percentile('g',r.g)).toFixed(12))]));
  const order=new Map(universe.map((p,i)=>[p,i]));
  const buckets=anks.map(ank=>{const pool=eligible.filter(p=>panelAnkDigit(p)===ank).sort((a,b)=>scores[b]-scores[a]||order.get(a)!-order.get(b)!);return {ank,eligible:pool.length,selected:pool.slice(0,5)};});
  const shortages=buckets.filter(b=>b.eligible<5);
  const reason=anks.length!==6?'Exactly 6 distinct ANK required':excluded.length!==30?`Only ${excluded.length}/30 unique historical SP available`:shortages.length?`Insufficient candidates: ${shortages.map(b=>`ANK ${b.ank}: ${b.eligible}/5`).join(' · ')}`:'6 ANK × 5 SP ready';
  const complete=anks.length===6&&excluded.length===30&&!shortages.length;
  const panels=complete?buckets.flatMap(b=>b.selected):[];
  return {mode:'RECENT30_ANK5',targetDate,side,decision:complete?'RETAIN':'SKIP',reason,anks,panels,excluded,
    eliminated:eligible.filter(p=>!panels.includes(p)),buckets:complete?buckets:buckets.map(b=>({...b,selected:[]})),scores,historySamples:history.length,lastHistoryDate:history[0]?.[0]};
}
