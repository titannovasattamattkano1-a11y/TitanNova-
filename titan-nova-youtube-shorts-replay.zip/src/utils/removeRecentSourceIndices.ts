import {cutCurrentSourceDigits} from './cumulativeSourceCut';
import {canReplaceLiveCombinedDecision} from './liveCombinedDecision';
import type { DayMarketRecord, UserProfile } from '../types';
import { isMirrorProtected } from './adminMirror';
import { findHistoricalMarketRecord } from './cardHistory';
import { getScrapeResultIndex, getScrapeSource } from './scrapeProvenance';

export const SOURCE_INDEX_HISTORY_DAYS = 15;

/** Latest requested result indices from the prior 15-day strip; PASS-only by default, optional PASS/FAIL. */
export function recentSourceIndices(dayRecords: UserProfile['dayRecords'], date: string, index: number, marketName: string, count: 2 | 4 = 2, includeFail = false, includeSkippedHistory = false, includeLiveSkippedHistory = false): number[] {
  const indices: number[] = [];
  for (let offset = 1; offset < SOURCE_INDEX_HISTORY_DAYS && indices.length < count; offset++) {
    const day = new Date(`${date}T00:00:00Z`);
    day.setUTCDate(day.getUTCDate() - offset);
    const rec = findHistoricalMarketRecord(dayRecords?.[day.toISOString().slice(0,10)]?.data, index, marketName);
    const observed=includeSkippedHistory&&rec?.s==='SKIP'&&rec.backtestSkipHistory&&(includeFail||rec.backtestSkipHistory.status==='PASS');
    const liveObserved=includeLiveSkippedHistory&&includeFail&&rec?.s==='SKIP'&&rec.liveCombinedCut?.observation?.date===day.toISOString().slice(0,10);
    if (!liveObserved && !observed && rec?.s !== 'PASS' && !(includeFail && rec?.s === 'FAIL')) continue;
    const position = getScrapeResultIndex(rec);
    if (position !== undefined) indices.push(position);
  }
  return indices;
}

/** Remove current selected digits at historical indices in the current ORIGINAL source. */
export function removeRecentSourceIndexDigits(record: DayMarketRecord | undefined, indices: number[], count: 2 | 4 = 2): DayMarketRecord | undefined {
  if (!record || !canReplaceLiveCombinedDecision(record) || isMirrorProtected(record) || !indices.length || indices.length > count || !indices.every(i => Number.isInteger(i) && i >= 1 && i <= 10)) return undefined;
  const source = getScrapeSource(record);
  if (!source || (source.digits.split(', ').length===10&&indices.length!==count)) return undefined;
  return cutCurrentSourceDigits(record,indices.flatMap(i=>source.digits.split(', ')[i-1]?[source.digits.split(', ')[i-1]]:[]));
}

/** Exactly four unique cuts from original10: historical two positions, then source positions1/2. */
export function removeRecentTwoAndScrapeDigits(record: DayMarketRecord | undefined, indices: number[],noOpAsRecord=false): DayMarketRecord | undefined {
  if (!record || !canReplaceLiveCombinedDecision(record) || isMirrorProtected(record) || record.dispatchState || record.s === 'SKIP' || !indices.length || indices.length > 2 || !indices.every(i=>Number.isInteger(i)&&i>=1&&i<=10)) return undefined;
  const source = getScrapeSource(record);
  if (!source) return undefined;
  const original = source.digits.split(', '), removed = new Set<string>();
  if(original.length<10)return cutCurrentSourceDigits(record,[...new Set([...indices.map(i=>original[i-1]),original[0],original[1]].filter((d):d is string=>d!==undefined))],undefined,noOpAsRecord);
  if(indices.length!==2)return;

  for (const digit of [original[indices[0]-1], original[indices[1]-1], original[0], original[1]]) {
    const mirror = String((Number(digit)+5)%10);
    const chosen = !removed.has(digit) ? digit : !removed.has(mirror) ? mirror : original.find(d=>!removed.has(d));
    if (!chosen) return undefined;
    removed.add(chosen);
  }
  if (removed.size !== 4) return undefined;
  return cutCurrentSourceDigits(record,removed,undefined,noOpAsRecord);
}

/** Cut latest two result positions; a repeated position also cuts its digit mirror. */
export function removeRecentTwoIndices(record: DayMarketRecord | undefined, indices: number[],noOpAsRecord=false): DayMarketRecord | undefined {
  if (!record || !canReplaceLiveCombinedDecision(record) || isMirrorProtected(record) || record.dispatchState || record.s === 'SKIP' || !indices.length || indices.length > 2 || !indices.every(i => Number.isInteger(i) && i >= 1 && i <= 10)) return undefined;
  const source = getScrapeSource(record);
  if (!source) return undefined;
  const original = source.digits.split(', ');
  if(original.length===10&&indices.length!==2)return;
  const removed = new Set(indices.filter(i=>i<=original.length));
  if (indices.length===2 && indices[0]===indices[1] && removed.size === 1) {
    const mirror = String((Number(original[indices[0] - 1]) + 5) % 10);
    const mirrorIndex=original.indexOf(mirror)+1;if(mirrorIndex>0)removed.add(mirrorIndex);
  }
  return cutCurrentSourceDigits(record,[...removed].flatMap(i=>original[i-1]?[original[i-1]]:[]),'RECENT2',noOpAsRecord);
}
