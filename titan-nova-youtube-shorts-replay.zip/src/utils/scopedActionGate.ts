/** Same-scope taps share a lock immediately, before React can rerender.
 * Resetting scope releases the UI without letting an old completion clear a new job.
 */
export class ScopedActionGate {
 private current:{scope:string}|undefined;
 reset(){this.current=undefined;}
 async run(scope:string,action:string,task:()=>unknown|Promise<unknown>,feedback:(action:string|null,error?:Error)=>void):Promise<boolean>{
  if(this.current?.scope===scope)return false;
  const job={scope};this.current=job;feedback(action);
  try{await task();}
  catch(error){if(this.current===job)feedback(action,error instanceof Error?error:new Error('Action failed; retry'));}
  finally{if(this.current===job){this.current=undefined;feedback(null);}}
  return true;
 }
}
