import {applyStateSerializationPatch} from '../utils/stateSerializationPatch';
import {writeStartupSnapshotJson} from '../utils/startupSnapshotStore';
let snapshot:unknown,version=0;
self.onmessage=(event:MessageEvent)=>{
 const {id,state,cacheKey,patch,baseId}=event.data;
 try{if(patch){if(baseId!==version)throw Error('Snapshot version mismatch');snapshot=applyStateSerializationPatch(snapshot,patch);}else snapshot=state;const json=JSON.stringify(snapshot);version=id;self.postMessage({id,json});if(cacheKey)void writeStartupSnapshotJson(cacheKey,json);}
 catch(error){self.postMessage({id,error:error instanceof Error?error.message:'State serialization failed'});}
};
