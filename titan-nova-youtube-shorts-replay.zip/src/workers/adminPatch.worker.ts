import {adminChanges} from '../utils/adminStatePatch';
self.onmessage=(event:MessageEvent)=>{
 const {id,before,after}=event.data;
 try{self.postMessage({id,patch:adminChanges(JSON.parse(before),JSON.parse(after))});}
 catch(error){self.postMessage({id,error:error instanceof Error?error.message:'Workspace comparison failed'});}
};
