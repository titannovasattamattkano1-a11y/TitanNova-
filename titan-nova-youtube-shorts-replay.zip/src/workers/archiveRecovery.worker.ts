import {replayResultControlDay} from '../utils/resultControlReplay';
self.onmessage=(event:MessageEvent)=>{
 const {profile,date,carryModeChanged}=event.data;
 try{const next=replayResultControlDay(profile,date,carryModeChanged===true);self.postMessage({day:next.dayRecords[date],changed:next!==profile});}
 catch(error){self.postMessage({error:error instanceof Error?error.message:'Archive calculation failed'});}
};
