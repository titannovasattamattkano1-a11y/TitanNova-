import type { DualLoopConfig, LoopId } from './utils/dualLoops';
import type { MarketModelSummary } from './utils/marketModelCard';
export type GameType = 'ank' | 'jodi' | 'pannel';
export type MarketScope = 'ALL' | 'DAY' | 'NIGHT';

export type MarketStatus = 'WAIT' | 'PASS' | 'FAIL' | 'SKIP';

export type TrickType = 'T1' | 'T2' | 'T3';
export const CARD_SOURCE_MODES = ['MANUAL', 'AUTO', 'WEEKDAY', 'COMBO', 'DAY_COMBO', 'SMART', 'MARKOV', 'MARKET_MODEL', 'CARRY6', 'PAIR_FOLLOW', 'PAIR_COMBO', 'MSSD', 'DIGIT_FOLLOW', 'PANNA_FOLLOW', 'FREQ_10', 'FREQ_10_COMBO', 'RESULT_CARRY6', 'SP_RARE', 'SP_SKIP30', 'ANK_SUM', 'AI_SCAN', 'FLOW_3_1', 'RESULT_CUT5', 'SELF_LEARNING'] as const;
export type CardSourceMode = typeof CARD_SOURCE_MODES[number];

export interface MarketItem {
  id?: string;
  n: string;
  hr?: number;
  min?: number;
  openTime?: string;
  closeTime?: string;
  scrapeUrl?: string;
  autoSchedule?: boolean;
  isCustom?: boolean;
}

export interface ChartLink {
  n: string;
  l: string;
}

export interface DayMarketRecord {
  masterFlow?: {
    anchor: string;
    shield: string;
    neighbor: string;
    parity: string;
    digits: string;
    reason?: string;
    winningLogics?: string[];
    walkForwardRate?: number;
    evaluatedDraws?: number;
    chartScores?: number[];
    loopRefinedKey?: string;
  };
  openCloseCut?: {input:Partial<DayMarketRecord>;output:string;outputVersion:number;actual:string};
  loopAccountSkipped?: boolean;
  loopAccountReason?: 'TARGET_REACHED'|'CAPITAL_LIMIT';
  loopAccountReservation?: {key:string;invest:number;expiresAt:number};
  smartSelection?: {decision:'TOP'|'REVERSE';date:string;digits:string;sourceDigits:string;samples:number;topHits:number;reverseHits:number;digitCount?:4|5|6;strongDigits?:string[];supportDigits?:string[];recommendedFilter?:string;sourceVersion?:number};
  mssdState?: {
    stage: 1 | 2 | 3 | 4;
    output: string;
    outputVersion?: number;
    sources?: {
      AUTO: string;
      WEEKDAY: string;
      COMBO: string;
      DAY_COMBO: string;
    };
    ssdByMode?: {
      AUTO: string[];
      WEEKDAY: string[];
      COMBO: string[];
      DAY_COMBO: string[];
    };
    stageDigits?: {
      1: string;
      2: string;
      3: string;
      4: string;
    };
  };
  twoCardRecoveryShares?: import('./utils/twoCardRecovery').RecoveryShare[];
  smartStaking?: import('./utils/settlement').SmartStakingInfo;
  twoCardRecoveryStrategy?: 'TWO'|'ALL';
  carryResultSix?: {input:Partial<DayMarketRecord>;output:string;outputVersion:number;history:Array<{actual:string;key:string}>;diagnosis?:'CUT_TRAP'|'COLD_SHIFT'|'DELTA_JUMP'|'RECOVERY_HEDGE'|'TREND_FLOW'|'TRAP_INVERSION'|'FAMILY_SATURATION_LOCK';diagnosisDetails?:string;spectrum?:string};
  /** Legacy parity snapshots remain readable; O/D now owns OPEN/loop cut decisions. */
  autoResultParity?: {actual?:string;sourceKey:string;input:string;inputTrick?:TrickType;inputPositionRule?:DayMarketRecord['positionRule'];output:string;outputVersion:number;trick?:'T1'|'T2';
    rule?:'OPEN_LOOP_CUT';cut?:'FCUT'|'LCUT'|'CENTER';loopCut?:'FCUT'|'LCUT';marketCut?:'FCUT'|'LCUT';loopSourceKey?:string;marketSourceKey?:string};
  /** Live opt-in four-cut decision, separate from trial policy. */
  liveCombinedCut?: NonNullable<DayMarketRecord['backtestCombinedCut']> & {output:string;updatedAt:number; observation?:{date:string;actual:string;sourceIndex:number}};
  /** Trial-only audit. Never used by the live bulk/delivery pipeline. */
  backtestCombinedKeep?: {
    rule:'auto_day_recent2_keep'; auto:string[]; day:string[]; indices:number[];
    indexDigits:string[]; kept:string[]; choices:Array<{digit:string;via:'original'|'mirror'}>; reason?:string;
  };
  backtestCombinedCut?: {
    rule: 'auto_day_recent2'; auto: string[]; day: string[]; indices?: number[];
    fallback?: string[]; removed: string[];
    choices: Array<{digit:string;via:'original'|'index1'|'index2'|'mirror'}>;
    reason?: string;
    position?: 'first' | 'last';
  };
  backtestRecoveryReset?: { fails: 3; debtCleared: number; track: string };
  backtestStakeLimitSkipped?: boolean;
  backtestSkipHistory?: {date:string; actual?:string; sourceIndex?:number; status?:'PASS'|'FAIL'};
  backtestDailyStopLossSkipped?: boolean;
  backtestDailyStopLossSourceSkipped?: boolean;
  backtestDailyProfitSkipped?: boolean;
  backtestDailyProfitSourceSkipped?: boolean;
  bulkBacktestJobId?: string;
  bulkBacktestVersion?: number;
  /** Card Restore reverses delivery accounting and blocks old transport receipts. */
  deliveryRestoredAt?: number;
  cardGeneration?: number;
  /** Unsent card paused by VIP target/capital auto-stop; resumable explicitly. */
  vipAutoStopSkipped?: boolean;
  /** Restored unsent pause card can be released by an explicit game resume. */
  vipAutoStopResumeEligible?: boolean;
  s: MarketStatus;
  d: string;
  /** Selected-date Undo preserves digits until a fresh test or explicit source edit. */
  backtestSelectionHold?: {date:string;digits:string;sourceVersion:number};
  backtestResult?: { digits: string; actual?: any; openActual?: string; checked: boolean; updatedAt?: number };
  r: string;
  od?: string; // Original digits before trick application
  trick?: TrickType;
  /** Explicit source-position policy: weekday selection or only two recent-index removals. */
  positionRule?: 'FIRST_CUT' | 'CUT2' | 'FCUT' | 'LCUT' | 'CENTER' | 'WEEKDAY' | 'RECENT2' | 'RECENT6' | 'RECENT4' | 'LAST_ACTUAL_MIRROR' | 'FIRST_DIGIT_MIRROR' | 'SSD' | 'FLOW_3_1' | 'TRI_CUT' | 'SNIPER_1' | 'TESLA_369' | 'SELF_LEARN';
  selfLearning?: {
    confidence: number;
    rawConfidence?: number;
    confidenceThreshold?: number;
    isConservativeFallback?: boolean;
    digits: string;
    weights?: Record<string, number>;
    strategy: string;
    sampleCount: number;
    updatedAt: number;
    shieldMode?: boolean;
    ruleProof?: string;
    examplesSummary?: string;
    predictedSingleAnk?: string;
    newInput?: string;
    analysisState?: 'IDLE' | 'SCANNING' | 'LOCKED';
    mistakeLesson?: string;
    selfDecisionAction?: string;
    lastOutcome?: 'PASS' | 'FAIL' | 'NEW';
    consensusLayers?: {
      chartRuleAnks: string[];
      positionIndexAnks: string[];
      otcMistakeAnks: string[];
      agreementCount: 1 | 2 | 3;
    };
    riskTier?: 'SAFE' | 'GUARDED' | 'HIGH_RISK';
    recommendedAction?: 'PLAY' | 'PLAY_GUARDED' | 'SKIP_ADVISORY';
    zigzagAnalysis?: {
      stateHistory: string[];
      detectedPattern: string;
      slotBreakdown: {
        repeatAnk: string;
        cutAnk: string;
        zigzagAnk: string;
        counterAnk: string;
      };
      regimeStatus?: 'STABLE_7_15D' | 'REGIME_SHIFT_PIVOT' | 'DRAWDOWN_RECOVERY_LOCK';
      overdueColdDigit?: string;
      droughtDraws?: number;
      exhaustedDigits?: string[];
      liveDayTrendNote?: string;
      dayTwinLink?: {
        twinMarket: string;
        twinJodi: string;
        formulaUsed: string;
        twinTargetAnk: string;
      };
      calendarShield?: {
        isWeekendTrap: boolean;
        isMonthEndTrap: boolean;
        shieldLabel: string;
        reverseComplementAnk: string;
      };
      marketMoodTournament?: {
        activeTrickId: string;
        activeTrickName: string;
        activeTrickFormula: string;
        winCount: number;
        evalDraws: number;
        consecutiveFails: number;
        moodState: 'LOCKED_CHAMPION' | 'ONE_FAIL_HOLD' | 'TWO_FAIL_MOOD_SHIFT';
        previousFailedTrickName?: string;
        runnerUpTrickName?: string;
        runnerUpWinCount?: number;
        leaderboardSummary: string;
      };
    };
  };
  firstDigitMirrorCut?: {digit:string;mirror:string;stage:1|2;input:string;output:string;outputVersion:number};
  triCut?: import('./utils/triCut').TriCutDetails;
  sniperOne?: import('./utils/sniperOne').SniperOneDetails;
  tesla369?: import('./utils/teslaThreeSixNine').Tesla369Details;
  /** Original six-digit Weekday selection, frozen separately from later edits/tricks. */
  weekdaySelectedDigits?: string;
  /** 1–6 for a hit, 0 for a miss; populated only from an actual ANK result. */
  weekdayHitPosition?: number;
  /** How the current digit source was selected; preserved for next-day guidance. */
  sourceMode?: CardSourceMode;
  loopId?: LoopId;
  sentLoopId?: LoopId;
  marketModel?: MarketModelSummary;
  strictPanel30?: import('./utils/strictPanel30').StrictPanel30Selection;
  sourceEditedAt?: number;
  /** Ordered original 1–10 unique digits/ranking returned by the selected scraping logic; display metadata only. */
  scrapeSource?: { mode: CardSourceMode; digits: string };
  sentScrapeSource?: { mode: CardSourceMode; digits: string };
  /** Actual published ANK result, never inferred from a manual PASS/FAIL. */
  autoRemovedResult?: { input: string; output: string; actual: string; sourceKey: string; outputVersion?: number; mirror?: string; unique3?:boolean; actuals?:string[] };
  scrapeResultDigit?: string;
  /** Explicit actual result selected during manual settlement. */
  manualResult?: string;
  /** Actual Patti supplied alongside manual ANK, never guessed from that ANK. */
  manualPanelResult?: string;
  /** Cards whose actual results produced this linked settlement; supports undo. */
  manualResultSources?: string[];
  /** True only when the current unsent source fields were projected from Admin. */
  mirroredFromAdmin?: boolean;
  /** Stable identity used when market configuration changes reorder card indices. */
  marketName?: string;
  schTime?: string;
  schTargets?: string[];
  prevLoss?: number;
  recRate?: string;
  targetProfitWithLoss?: number;
  /** Rate frozen when schedule WhatsApp was actually sent — FAIL/PASS reply MUST use this */
  sentRate?: string;
  /** Invest frozen at schedule send (digits × sentRate) */
  sentInvest?: number;
  sentDigits?: string;
  /** Source/trick frozen with the actual delivered or manually settled card. */
  sentSourceMode?: CardSourceMode;
  sentTrick?: TrickType;
  /** User explicitly edited status; automatic PASS/FAIL must not replace it. */
  manualStatus?: boolean;
  /** User explicitly edited rate; automatic rate suggestions must not replace it. */
  manualRate?: boolean;
  manualOverrideAt?: number;
  dispatchState?: 'QUEUED' | 'SENT' | 'SETTLED';
  dispatchKey?: string;
  queuedAt?: number;
  sentAt?: number;
  settledAt?: number;
  /** OPEN match advances recovery provisionally; OPEN miss settles JODI FAIL immediately. */
  jodiOpenStatus?: 'PASS' | 'FAIL';
  jodiOpenResult?: string;
  jodiOpenSettledAt?: number;
  rateFinalizedFrom?: string;
  rateFinalizedAt?: number;
}

export interface ProtocolConfig {
  cap: number; // Capital cap for protocol
  tgt: number; // Target profit per card
}

export interface ProfileConfig {
  /** New split allocator activation date; prior snapshots keep legacy history. */
  twoCardRecoveryFrom?: string;
  twoCardRecoveryLegacySplit?: {ank:boolean;pannel:boolean};
  /** Opt-in live Admin/VIP recovery cycle reset; financial losses remain. */
  liveThreeFailReset?: boolean;
  sameMarketRecovery?: boolean;
  profitCarry?: boolean;
  openPassCloseZero?: boolean;
  fourWaveRelay?: boolean;
  autoResultParity?: boolean;
  autoCarryResultSix?: boolean;
  autoRemoveResultDigit?: boolean;
  autoRemoveResultMirror?: boolean;
  autoRemoveResultUnique3?: boolean;
  /** Global WhatsApp presentation policy. False hides rates/calculation only. */
  detailedMessage?: boolean;
  cardSenderFormat?: 'text' | 'png';
  cardSenderFormats?: {whatsapp?:'text'|'png';telegram?:'text'|'png'};
  dualLoops?: DualLoopConfig;
  /** Legacy storage keys: Split 2 on activated dates; old snapshots stay compatible. */
  ankSplit: boolean;
  panSplit: boolean;
  capital: number;
  dayTarget: number;
  maxStopLoss?: number;
  lossMultiplier?: number;
  ankDefaultDigits?: string;
  jodiDefaultDigits?: string;
  pannelDefaultDigits?: string;
  ankDefaultRate?: string;
  jodiDefaultRate?: string;
  pannelDefaultRate?: string;
  customMarkets?: MarketItem[];
  deletedMarketNames?: string[];
  marketScheduleTimes?: Record<string, string>;
  marketScheduleTargets?: Record<string, string[]>;
  marketScrapeUrls?: Record<string, string>;
  marketAutoScheduleEnabled?: Record<string, boolean>;
  /** Per-market master switch. Explicit false = fully disabled everywhere. */
  marketEnabled?: Record<string, boolean>;
  /** Global auto-broadcast switches by card type. Missing keys default to ON for backward compatibility. */
  scheduleTypeEnabled?: Record<GameType, boolean>;
  ank: ProtocolConfig;
  jodi: ProtocolConfig;
  pannel: ProtocolConfig;
}

export interface BacktestRecoveryPolicy {
  autoRemoveResultDigit?: boolean;
  autoRemoveResultMirror?: boolean;
  autoRemoveResultUnique3?: boolean;
  autoCarryResultSix?: boolean;
  autoResultParity?: boolean;
  profitCarry?: boolean;
  openPassCloseZero?: boolean;
  selectedMarkets?:string[];
  dailyStopLoss?: number;
  dailyProfitTarget?: number;
  dailyTargetGames?: GameType[];
  resetAfterThreeFails: boolean;
  maxStake: number;
  updatedAt?: number;
  runId?: string;
}

export interface DayRecordStore {
  loopAccountStops?: import('./utils/loopAccounts').LoopAccountStops;
  /** Date/profile-owned OPEN actual → same-market CLOSE cut. OFF never refills digits. */
  openToCloseCut?: boolean;
  /** Date-owned recovery inputs; never use later live defaults to reprice this archive. */
  recoveryConfigSnapshot?: ProfileConfig;
  /** Historical trial only; never used by live delivery/recovery. */
  backtestRecoveryPolicy?: BacktestRecoveryPolicy;
  loopConfig?: DualLoopConfig;
  /** Archive restore generation; older dashboard saves cannot resurrect the previous trial. */
  backtestRevision?: number;
  data?: Record<string, DayMarketRecord>;       // Ank market records by index
  jodiData?: Record<string, DayMarketRecord>;   // Jodi market records by index
  pannelData?: Record<string, DayMarketRecord>; // Pannel market records by index
  yesterdayLoopSetup?: { sourceDate: string; sourceDates?: Record<string, string>; mixed?: boolean; loopCount?: 2 | 3; repeats?: number; priorVisibility: Record<string, boolean | null> };
  visAnk?: Record<string, boolean>;             // Visibility map for Ank
  visJodi?: Record<string, boolean>;            // Visibility map for Jodi
  visPan?: Record<string, boolean>;             // Visibility map for Pan
}

export interface UserProfile {
  profitCarry?: boolean;
  openPassCloseZero?: boolean;
  /** Explicit custom setup changes, effective from each business date onward. */
  customLoopChanges?: Record<string, DualLoopConfig>;
  vipLiveStart?: { createdAt: number; date: string; excluded: Record<string, string[]> };
  /** Independent profit milestone alert preference; not a delivery/auto-stop switch. */
  profitMilestoneNotificationsEnabled?: boolean;
  vipGameRuns?: import('./utils/vipAutoStop').VipGameRuns;
  name: string;
  phone: string;
  config: ProfileConfig;
  dayRecords: Record<string, DayRecordStore>;   // Map ISO date string -> DayRecordStore
  expiryDate?: string;
  /** Admin-only member classification used by the VIP management filters. */
  vipMemberType?: 'regular' | 'demo';
  /** Per-VIP source projection switch. Missing means ON for backward compatibility. */
  vipCopyAdmin?: boolean;
  vipAccessEnabled?: boolean;
  vipSchTime?: string;
  vipSchTarget?: string;
  /** Event-driven VIP delivery: digits + rate available => direct send to profile.phone. */
  vipAutoMode?: boolean;
  /** VIP WhatsApp delivery destination. Group/Channel modes use their exact WhatsApp JID. */
  vipDeliveryMode?: 'private' | 'group' | 'channel';
  vipGroupJid?: string;
  vipGroupName?: string;
  vipChannelJid?: string;
  vipChannelName?: string;
  /** Per-VIP auto-broadcast switches by card type. Missing keys default to ON. */
  vipScheduleEnabled?: Record<GameType, boolean>;
  /** Secret carried only by this VIP's personal portal link/API commands. */
  vipAccessToken?: string;
}

export interface PaymentMethod {
  upi: string;
  phone: string;
  qr: string;
}

export interface PaymentRequest {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  utr: string;
  planLabel: string;
  image?: string;
  status: 'pending' | 'approved' | 'rejected';
  autoFlag: 'safe' | 'duplicate' | 'low_amount' | 'spam' | 'pending';
  submittedAt?: string;
  reviewedAt?: string;
  reviewedBy?: string;
  accessDays?: number;
  time: string;
}

export interface Broadcast {
  id: number;
  title: string;
  msg: string;
  time?: string;
}

export interface AppState {
  /** Read-only display projection supplied to token-scoped VIP portals. */
  sourceIndexHistory?: import('./utils/sourceIndexHistory').SourceIndexHistory;
  activeId: string;
  profiles: Record<string, UserProfile>;
  paymentMethods: PaymentMethod;
  payments: PaymentRequest[];
  broadcasts: Broadcast[];
}

export interface ProtocolStats {
  spent: number;
  win: number;
  pl: number;
  port: number;
  maxLoss: number;
}

export interface GlobalStats {
  ank: ProtocolStats;
  jodi: ProtocolStats;
  pannel: ProtocolStats;
}

export interface ToastMessage {
  id: string;
  title: string;
  body: string;
  type: 'info' | 'success' | 'warning' | 'danger';
}
