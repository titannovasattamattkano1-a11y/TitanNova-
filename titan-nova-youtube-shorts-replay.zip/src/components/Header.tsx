import React from 'react';
import { Menu, ArrowLeft, Bell, Calendar, Download } from 'lucide-react';
import { UserProfile } from '../types';

interface HeaderProps {
  isMaster: boolean;
  activeId: string;
  activeProfile: UserProfile;
  currentDate: string;
  onDateChange: (date: string) => void;
  todayBacktest: boolean;
  onToggleTodayBacktest: () => void;
  showTodayBacktest: boolean;
  onToggleSidebar: () => void;
  onBackToMaster: () => void;
  onRequestNotificationPermission: () => void;
  onShowInstallModal: () => void;
  showSplitToggle: boolean;
  splitChecked: boolean;
  onToggleSplit: (checked: boolean) => void;
  fourWaveChecked?: boolean;
  onToggleFourWave?: (checked: boolean) => void;
  profitCarryChecked?: boolean;
  onToggleProfitCarry?: (checked: boolean) => void;
  openPassCloseZeroChecked?: boolean;
  onToggleOpenPassCloseZero?: (checked: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  isMaster,
  activeId,
  activeProfile,
  currentDate,
  onDateChange,
  todayBacktest,
  onToggleTodayBacktest,
  showTodayBacktest,
  onToggleSidebar,
  onBackToMaster,
  onRequestNotificationPermission,
  onShowInstallModal,
  showSplitToggle,
  splitChecked,
  onToggleSplit,
  fourWaveChecked,
  onToggleFourWave,
  profitCarryChecked,
  onToggleProfitCarry,
  openPassCloseZeroChecked,
  onToggleOpenPassCloseZero,
}) => {
  const isMasterAdmin = isMaster && activeId === 'admin1';

  return (
    <header className="app-header sticky top-0 z-50 bg-gradient-to-r from-[#17212B] via-[#1C2733] to-[#17212B] border-b border-[#2AABEE]/40 h-[58px] px-3 flex items-center justify-between shadow-[0_4px_20px_rgba(42,171,238,0.15)] relative">
      {/* Top Matching Theme Highlight Line */}
      <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-[#2AABEE] via-[#00C26F] to-[#FAC748]" />

      {/* Left Action */}
      {isMasterAdmin ? (
        <button
          onClick={onToggleSidebar}
          className="w-9 h-9 rounded-xl flex items-center justify-center text-[#2AABEE] bg-[#2AABEE]/10 border border-[#2AABEE]/20 hover:bg-[#2AABEE]/20 active:scale-95 transition-all"
          title="Open Menu"
        >
          <Menu className="w-5 h-5" />
        </button>
      ) : isMaster && activeId !== 'admin1' ? (
        <button
          onClick={onBackToMaster}
          className="w-9 h-9 rounded-xl flex items-center justify-center text-[#2AABEE] bg-[#2AABEE]/10 border border-[#2AABEE]/20 hover:bg-[#2AABEE]/20 active:scale-95 transition-all"
          title="Back to Admin"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
      ) : (
        <button
          onClick={onToggleSidebar}
          className="w-9 h-9 rounded-xl flex items-center justify-center text-[#2AABEE] bg-[#2AABEE]/10 border border-[#2AABEE]/20 hover:bg-[#2AABEE]/20 active:scale-95 transition-all"
          title="Open Menu"
        >
          <Menu className="w-5 h-5" />
        </button>
      )}

      {/* Title Center - Highlighted Pill */}
      <div className="app-brand flex flex-col items-center">
        <div className="flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-[rgba(42,171,238,0.12)] border border-[rgba(42,171,238,0.35)] shadow-[0_0_12px_rgba(42,171,238,0.2)]">
          <span className="w-2 h-2 rounded-full bg-[#00C26F] shrink-0" />
          <h1 className="text-[14px] font-black tracking-tight bg-gradient-to-r from-[#2AABEE] via-[#38C0FF] to-[#00C26F] bg-clip-text text-transparent uppercase">
            {activeId === 'admin1' ? 'TITAN NOVA' : activeProfile?.name || 'TITAN NOVA'}
          </h1>
        </div>
        <span className="text-[9px] text-[#2AABEE] font-bold uppercase tracking-widest mt-0.5 drop-shadow">
          {activeId === 'admin1'
            ? 'Master Admin'
            : !isMaster
            ? 'VIP Live App'
            : 'VIP Member View'}
        </span>
      </div>

      {/* Right Controls */}
      <div className="app-header-controls flex items-center gap-2">
        {!isMaster && (
          <button
            onClick={onRequestNotificationPermission}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-[#00C26F] bg-[#00C26F]/10 border border-[#00C26F]/20 active:scale-95 transition-all"
            title="Enable Notifications"
          >
            <Bell className="w-5 h-5" />
          </button>
        )}

        {isMaster && (
          <button
            onClick={onShowInstallModal}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-[#2AABEE] bg-[#2AABEE]/10 border border-[#2AABEE]/20 hover:bg-[#2AABEE]/20 active:scale-95 transition-all"
            title="Install App"
          >
            <Download className="w-5 h-5" />
          </button>
        )}

        {showSplitToggle && (
          <div className="flex items-center gap-1.5">
            <div title="Smart Stake: Strong digits profit booster + Support digits insurance cover" className="flex items-center gap-1 h-9 px-2 bg-[#2B3A4D] border border-[rgba(255,255,255,0.07)] rounded-xl">
              <label className="switch transform scale-75 m-0 cursor-pointer">
                <input
                  type="checkbox"
                  aria-label="Smart staking"
                  checked={splitChecked}
                  onChange={(e) => onToggleSplit(e.target.checked)}
                />
                <span className="slider"></span>
              </label>
              <span
                className={`text-[8px] font-bold uppercase whitespace-nowrap ${
                  splitChecked ? 'text-[#00C26F]' : 'text-[#7A9CB8]'
                }`}
              >
                Smart Stake
              </span>
            </div>

            {onToggleProfitCarry && (
              <div title="Profit Carry: Fail card ki unearned target profit agle card par carry karega" className="flex items-center gap-1 h-9 px-2 bg-[#2B3A4D] border border-[rgba(255,255,255,0.07)] rounded-xl">
                <label className="switch transform scale-75 m-0 cursor-pointer">
                  <input
                    type="checkbox"
                    aria-label="Profit Carry"
                    checked={Boolean(profitCarryChecked)}
                    onChange={(e) => onToggleProfitCarry(e.target.checked)}
                  />
                  <span className="slider"></span>
                </label>
                <span
                  className={`text-[8px] font-bold uppercase whitespace-nowrap ${
                    profitCarryChecked ? 'text-[#FAC748]' : 'text-[#7A9CB8]'
                  }`}
                >
                  Profit Carry
                </span>
              </div>
            )}

            {onToggleOpenPassCloseZero && (
              <div title="Close Zero: Jab OPEN pass ho jaye to usi market ka CLOSE ₹0 invest mana jayega, result track hoga aur fail par profit aage carry hoga" className="flex items-center gap-1 h-9 px-2 bg-[#2B3A4D] border border-[rgba(255,255,255,0.07)] rounded-xl">
                <label className="switch transform scale-75 m-0 cursor-pointer">
                  <input
                    type="checkbox"
                    aria-label="Close Zero"
                    checked={Boolean(openPassCloseZeroChecked)}
                    onChange={(e) => onToggleOpenPassCloseZero(e.target.checked)}
                  />
                  <span className="slider"></span>
                </label>
                <span
                  className={`text-[8px] font-bold uppercase whitespace-nowrap ${
                    openPassCloseZeroChecked ? 'text-[#00E5FF]' : 'text-[#7A9CB8]'
                  }`}
                >
                  Close Zero
                </span>
              </div>
            )}

            {onToggleFourWave && (
              <div title="4-Wave Auto-Relay + End-of-Day Handoff Recovery (W1→W2→W3→W4)" className="flex items-center gap-1 h-9 px-2 bg-[#2B3A4D] border border-[rgba(255,255,255,0.07)] rounded-xl">
                <label className="switch transform scale-75 m-0 cursor-pointer">
                  <input
                    type="checkbox"
                    aria-label="4-Wave Relay Recovery"
                    checked={Boolean(fourWaveChecked)}
                    onChange={(e) => onToggleFourWave(e.target.checked)}
                  />
                  <span className="slider"></span>
                </label>
                <span
                  className={`text-[8px] font-bold uppercase whitespace-nowrap ${
                    fourWaveChecked ? 'text-[#2AABEE]' : 'text-[#7A9CB8]'
                  }`}
                >
                  4-Wave
                </span>
              </div>
            )}
          </div>
        )}

        {/* Date Picker */}
        {showTodayBacktest && (
          <button
            type="button"
            onClick={onToggleTodayBacktest}
            title={todayBacktest ? 'Aaj ka backtest band karke live scrape karein' : 'Aaj ke result ko exclude karke backtest karein'}
            aria-pressed={todayBacktest}
            className={`px-2 h-9 rounded-lg border text-[10px] font-bold whitespace-nowrap ${todayBacktest ? 'bg-amber-500/20 border-amber-500 text-amber-300' : 'bg-[#2B3A4D] border-[#2AABEE]/30 text-[#7A9CB8]'}`}
          >
            Aaj Backtest {todayBacktest ? 'ON' : 'OFF'}
          </button>
        )}
        <div className="relative w-9 h-9 bg-[#2B3A4D] rounded-xl flex items-center justify-center border border-[rgba(42,171,238,0.3)] text-[#2AABEE] overflow-hidden active:scale-95 transition-all shadow-sm">
          <Calendar className="w-4 h-4" />
          <input
            aria-label="Ledger date"
            type="date"
            value={currentDate}
            onChange={(e) => onDateChange(e.target.value)}
            className="absolute inset-0 opacity-0 w-full h-full cursor-pointer"
          />
        </div>
      </div>
    </header>
  );
};
