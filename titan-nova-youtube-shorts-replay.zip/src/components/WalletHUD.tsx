import { businessDateIST } from '../utils/businessDate';
import { vipGameLimits, vipGameTotals, vipPendingInvest } from '../utils/vipAutoStop';
import { dayLoopConfig } from '../utils/dualLoops';
import { calculateCapitalWallet } from '../utils/capitalWallet';
import React from 'react';
import { LoopWallets } from './LoopWallets';
import { GameType, ProtocolStats, UserProfile } from '../types';

interface WalletHUDProps {
  activeTab: GameType;
  stats: ProtocolStats;
  profile: UserProfile;
  currentDate?: string;
  vipGameOn?: boolean;
  vipStopReason?: string;
  onToggleVipGame?: (enabled: boolean) => void;
  vipGameDisabled?: boolean;
  vipGamePending?: boolean;
}

/**
 * Per-game reporting. Custom accounts below are isolated by game.
 */
export const WalletHUD: React.FC<WalletHUDProps> = ({
  activeTab,
  stats,
  profile,
  currentDate,
  vipGameOn = true,
  vipStopReason,
  onToggleVipGame,
  vipGameDisabled,
  vipGamePending,
}) => {
  const loops = currentDate ? dayLoopConfig(profile,currentDate) : undefined;

  const title =
    activeTab === 'ank' ? 'ANK WALLET' : activeTab === 'jodi' ? 'JODI WALLET' : 'PANEL WALLET';
  const stopLimits = vipGameLimits(profile, { loopConfig: loops });
  const capital = stopLimits.capital;
  const target = loops?.independentAccounts?0:stopLimits.target;
  const pl = stats?.pl || 0;
  const spent = stats?.spent || 0;
  const maxLoss = stats?.maxLoss || 0;

  const run = currentDate ? profile.vipGameRuns?.[activeTab] : undefined;
  const liveVipDay = Boolean(onToggleVipGame && currentDate === businessDateIST());
  const liveCycle = Boolean(!loops?.independentAccounts && liveVipDay && currentDate === run?.date);
  const dictName = activeTab === 'ank' ? 'data' : activeTab === 'jodi' ? 'jodiData' : 'pannelData';
  const dayCards = currentDate ? profile.dayRecords?.[currentDate]?.[dictName] || {} : {};
  const totals = vipGameTotals({ cards: Object.fromEntries(Object.entries(dayCards).map(([index, rec]) => [`${activeTab}_${index}`, rec])) }, activeTab);
  const progressProfit = liveVipDay ? totals.profit - (liveCycle ? run!.baseProfit : 0) : pl;
  const reservedInvest = vipPendingInvest({ cards: Object.fromEntries(Object.entries(dayCards).map(([index, rec]) => [`${activeTab}_${index}`, rec])) }, activeTab);
  const progressInvest = Math.max(0, reservedInvest - progressProfit);
  const dayPct = target > 0 ? Math.min(100, Math.max(0, Math.floor((progressProfit / target) * 100))) : 0;

  const accent =
    activeTab === 'ank' ? '#2AABEE' : activeTab === 'jodi' ? '#B85CFF' : '#FAC748';

  const resumed = liveCycle && (run!.baseProfit !== 0 || run!.baseInvest !== 0);
  const unsettledCards = Object.fromEntries(Object.entries(dayCards).filter(([, rec]) => rec && rec.s !== 'PASS' && rec.s !== 'FAIL').map(([index, rec]) => [`${activeTab}_${index}`, rec]));
  const deliveredInvest = vipGameTotals({ cards: Object.fromEntries(Object.entries(dayCards).map(([index, rec]) => [`${activeTab}_${index}`, rec])) }, activeTab, '*').invest;
  const cashWallet = calculateCapitalWallet(activeTab, dayCards, true);
  const walletInvested = cashWallet.invested;
  const pendingInvest = vipGameTotals({ cards: unsettledCards }, activeTab, '*').invest;
  const queuedInvest = Math.max(0, totals.invest - deliveredInvest);
  const stopMessage = vipStopReason === 'TARGET_REACHED' ? 'Daily profit goal reached.'
    : vipStopReason === 'CAPITAL_LIMIT' ? 'Next stake blocked by capital limit.'
    : vipStopReason === 'MANUAL_OFF' ? 'Paused manually.' : 'Next cards skipped.';
  const money = (value: number) => `₹${value.toLocaleString('en-IN')}`;

  return (
    <section aria-label={`${activeTab.toUpperCase()} wallet`} className="px-3 py-2 bg-[#232E3C] border-b border-white/10">
      <div className="flex items-center justify-between mb-1.5 text-[9px] font-bold">
        <span style={{ color: accent }}>{title}</span>
        <span className="text-[#7A9CB8]">{resumed ? 'Resumed cycle' : 'Daily'} · {activeTab.toUpperCase()} only</span>
      </div>
      <div className="grid grid-cols-3 divide-x divide-white/10 rounded-lg bg-[#2B3A4D] py-2">
        <div className="px-2 min-w-0">
          <p className="text-[9px] text-[#8DA6C0]">{pl < 0 ? 'Loss' : 'Profit'}</p>
          <p className={`text-sm font-extrabold break-words ${pl >= 0 ? 'text-[#00C26F]' : 'text-[#FF5D5D]'}`}>{pl >= 0 ? '+' : ''}{money(pl)}</p>
        </div>
        <div className="px-2 min-w-0">
          <p className="text-[9px] text-[#8DA6C0]">Invested</p>
          <p className="text-sm font-extrabold text-white break-words">{money(spent)}</p>
        </div>
        <div className="px-2 min-w-0">
          <p className="text-[9px] text-[#8DA6C0]">Max risk</p>
          <p className="text-sm font-extrabold text-[#FF8A8A] break-words">{money(maxLoss)}</p>
        </div>
      </div>
      <div className="mt-1.5 rounded-lg bg-[#17212B]/50 px-2 py-1.5">
        <div className="flex items-center justify-between gap-2 text-[10px]">
          <span className="min-w-0 text-[#8DA6C0]">
            {progressProfit >= 0 ? '+' : ''}{money(progressProfit)}{target > 0 ? ` / daily goal ${money(target)}` : loops?.independentAccounts?' / separate account goals below':' / daily goal disabled'}
          </span>
          {onToggleVipGame ? (
            <label className="flex shrink-0 items-center gap-1.5 font-bold text-white cursor-pointer">
              <span role="status">{vipGamePending ? `Saving ${vipGameOn ? 'ON' : 'OFF'}…` : vipGameOn ? 'Game ON' : 'Game OFF'}</span>
              <span className="relative flex items-center">
                <input aria-label={`${activeTab.toUpperCase()} VIP game ON/OFF`} aria-busy={vipGamePending} type="checkbox" role="switch"
                  className="peer absolute inset-0 z-10 h-full w-full cursor-pointer opacity-0 disabled:cursor-not-allowed" checked={vipGameOn} disabled={vipGameDisabled}
                  onChange={event => onToggleVipGame(event.target.checked)} />
                <span className="pointer-events-none block h-5 w-9 rounded-full bg-[#53667A] peer-checked:bg-[#00A66A] peer-disabled:opacity-40 peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-[#2AABEE]" />
                <span className="pointer-events-none absolute left-0.5 top-0.5 h-4 w-4 rounded-full bg-white transition-transform peer-checked:translate-x-4" />
              </span>
            </label>
          ) : <span className="shrink-0 font-bold text-[#8DA6C0]">Daily goal</span>}
        </div>
        {target > 0 && <div className="mt-1 flex items-center gap-2">
          <div role="progressbar" aria-label={`${activeTab.toUpperCase()} daily profit goal`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={dayPct} className="h-1 flex-1 rounded-full overflow-hidden bg-[#2B3A4D]">
            <div key={`${run?.date || currentDate}_${run?.baseProfit || 0}_${run?.baseInvest || 0}`} className="h-full rounded-full transition-all duration-500" style={{ width: `${dayPct}%`, background: progressProfit >= 0 ? '#00C26F' : '#FF5D5D' }} />
          </div>
          <span className="text-[9px] text-[#8DA6C0]">{dayPct}%</span>
        </div>}
        {onToggleVipGame && !vipGameOn && <p className="mt-1 text-[9px] text-[#FAC748]">{stopMessage}</p>}
      </div>
      <details key={`${currentDate}_${activeTab}`} open={loops?.independentAccounts||undefined} className="group mt-1">
        <summary className="cursor-pointer text-[10px] font-bold text-[#8DA6C0] py-1 marker:text-[#8DA6C0]">Details{loops ? ' · loop wallets' : ''}</summary>
        <div className="border-t border-white/10 pt-2 pb-1 text-[10px] text-[#8DA6C0]">
          <p className="mb-1">Capital &amp; Profit Goals · {activeTab.toUpperCase()}{resumed ? ' · resumed cycle' : ' · daily'}</p>
          <div className="grid grid-cols-2 gap-x-3 gap-y-1">
            <span>Settled investment: {money(spent)}</span>
            {!loops?.independentAccounts&&<span>Daily capital: {capital > 0 ? money(capital) : 'Disabled'}</span>}
            <span>Wallet balance: {money(cashWallet.balance)}</span>
            <span>Own capital: {money(walletInvested)}</span>
            <span>Capital used + reserved: {money(progressInvest)}</span>
            {!loops?.independentAccounts&&<span>Remaining budget: {capital > 0 ? money(Math.max(0, capital + progressProfit - reservedInvest)) : 'No limit'}</span>}
            <span>Result pending: {money(pendingInvest)}</span>
            <span>Queued reservation: {money(queuedInvest)}</span>
          </div>
          {onToggleVipGame && <p className="mt-2">{vipGameOn ? loops?.independentAccounts?'Each game has separate account capital, profit goals and stops.':'Stops at daily profit goal or before investment exceeds capital.' : loops?.independentAccounts?'Turn ON to resume this game. Account daily stops remain in effect.':'Turn ON to start a new limit cycle; past results stay saved.'}</p>}
          {resumed && <p className="mt-1">Goal progress uses the resumed cycle; net profit above keeps the full day.</p>}
          {loops && currentDate && <LoopWallets profile={profile} date={currentDate} type={activeTab} />}
        </div>
      </details>
    </section>
  );
};
