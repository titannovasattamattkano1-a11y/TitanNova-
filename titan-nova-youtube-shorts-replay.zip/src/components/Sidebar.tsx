import './Sidebar.css';
import React from 'react';
import { CHART_LINKS } from '../data/markets';
import { Download, ExternalLink, X, Shield, Sparkles } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onShowInstallModal: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  onShowInstallModal,
}) => {
  return (
    <>
      {/* Overlay Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="sidebar-backdrop fixed inset-0 z-[999]"
        />
      )}

      {/* Drawer */}
      <div
        aria-label="App sidebar" aria-hidden={!isOpen} inert={!isOpen}
        className={`titan-sidebar fixed top-0 left-0 bottom-0 z-[1000] transition-transform duration-300 ease-out flex flex-col ${
          isOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="sidebar-heading">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="sidebar-brandmark">
                T
              </div>
              <div>
                <h2 className="sidebar-brand-title">TITAN NOVA</h2>
                <p className="sidebar-brand-caption">Charts & AI Analytics</p>
              </div>
            </div>
            <button
              onClick={onClose} type="button" aria-label="Close sidebar"
              className="sidebar-close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <button
            onClick={() => {
              onClose();
              onShowInstallModal();
            }}
            className="sidebar-install"
          >
            <Download className="w-4 h-4" /> Install App
          </button>
        </div>

        {/* Chart Links Grid */}
        <div className="sidebar-charts">
          <div className="sidebar-charts-heading">
            <span className="sidebar-section-label">
              <Sparkles className="w-3.5 h-3.5 text-[#2AABEE]" /> Live Panel Charts
            </span>
            <span className="sidebar-market-count">{CHART_LINKS.length} Markets</span>
          </div>

          <div className="sidebar-chart-grid">
            {CHART_LINKS.map((link) => (
              <a
                key={link.n}
                href={link.l}
                target="_blank"
                rel="noreferrer"
                title={link.n}
                className="sidebar-chart-link"
              >
                <span>{link.n}</span>
                <ExternalLink className="w-3 h-3 text-[#2AABEE] shrink-0" />
              </a>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="sidebar-footer">
          <p className="text-[9px] font-bold text-[#7A9CB8] flex items-center justify-center gap-1">
            <Shield className="w-3 h-3 text-[#00C26F]" /> Andres Barlin Engine V10.9
          </p>
        </div>
      </div>
    </>
  );
};
