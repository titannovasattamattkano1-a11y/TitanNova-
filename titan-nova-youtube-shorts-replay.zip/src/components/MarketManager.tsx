import { isChartProviderUrl } from '../utils/chartSource';
import {marketNameMatchesSearch,previewMatchesCurrentChart,validMarketTime} from '../utils/marketButtonSafety';
import { resolveMarketScrapeUrl } from '../utils/marketCatalogMigration';
import { apiUrl } from '../utils/api';
import React, { useState, useRef } from 'react';
import {
  Globe,
  Plus,
  Trash2,
  Clock,
  Search,
  RotateCcw,
  Sparkles,
  Link2,
  CheckCircle2,
  Edit3,
  Layers,
  X,
  Check,
} from 'lucide-react';
import { UserProfile, ProfileConfig, MarketItem } from '../types';
import { getEffectiveBaseMarkets, getEffectiveMarkets } from '../data/markets';
import { isMarketEnabledForDate } from '../utils/profileMarketToggle';

interface MarketManagerProps {
  profile: UserProfile;
  currentDate: string;
  onUpdateConfig: (newConfig: ProfileConfig) => void;
  onToggleMasterMarket: (baseMarketName: string, enabled: boolean) => void;
  onShowToast: (title: string, body: string, type: 'info' | 'success' | 'danger') => void;
}

export const MarketManager: React.FC<MarketManagerProps> = ({
  profile,
  currentDate,
  onUpdateConfig,
  onToggleMasterMarket,
  onShowToast,
}) => {
  // UserProfile guarantees a normalized ProfileConfig; avoid `{}` fallbacks
  // that erase the config type and hide invalid update shapes.
  const config = profile.config;
  const activeMarkets = getEffectiveMarkets(config);
  const activeBaseMarkets = getEffectiveBaseMarkets(config);
  const dayRecord = profile.dayRecords?.[currentDate] || {};
  const deletedSet = new Set((config.deletedMarketNames || []).map((n) => String(n).toUpperCase()));

  // URL Auto Add state
  const [urlInput, setUrlInput] = useState('');
  const [isParsingUrl, setIsParsingUrl] = useState(false);
  // Network replies may arrive after a different URL has been pasted.
  const detectionVersionRef = useRef(0);
  const latestUrlRef = useRef(urlInput);
  latestUrlRef.current = urlInput;
  const [parsedPreview, setParsedPreview] = useState<{
    baseName: string;
    openMarket: MarketItem;
    closeMarket: MarketItem;
    url: string;
  } | null>(null);

  // Manual Add state
  const [showManualForm, setShowManualForm] = useState(false);
  const [manualName, setManualName] = useState('');
  const [manualHr, setManualHr] = useState(12);
  const [manualMin, setManualMin] = useState(0);
  const [manualUrl, setManualUrl] = useState('');

  // Search filter
  const [searchQuery, setSearchQuery] = useState('');

  // Editing scrape URL state
  const [editingMarketName, setEditingMarketName] = useState<string | null>(null);
  const [editingUrlValue, setEditingUrlValue] = useState('');

  // Editing Time state
  const [editingTimeMarketName, setEditingTimeMarketName] = useState<string | null>(null);
  const [editingHr, setEditingHr] = useState<number>(12);
  const [editingMin, setEditingMin] = useState<number>(0);

  // Auto Detect Market from URL
  const handleParseUrl = async () => {
    const requestedUrl = urlInput.trim();
    if (!requestedUrl) {
      onShowToast('⚠️ Input Required', 'Please enter or paste a market chart URL', 'danger');
      return;
    }
    if (!isChartProviderUrl(requestedUrl)) {
      onShowToast('Invalid chart provider', 'Only PlayMatka chart URLs are allowed.', 'danger');
      return;
    }
    const version = ++detectionVersionRef.current;
    setIsParsingUrl(true);
    setParsedPreview(null);
    try {
      const res = await fetch(apiUrl('/api/parse_market_url'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: requestedUrl }),
      });
      const data = await res.json();
      // Never offer a preview for a URL the user has since replaced.
      if (version !== detectionVersionRef.current || latestUrlRef.current.trim() !== requestedUrl) return;
      if (res.ok && data.status === 'success' && isChartProviderUrl(data.url)
        && data.openMarket?.n && data.closeMarket?.n) {
        setParsedPreview({
          baseName: data.baseName,
          openMarket: data.openMarket,
          closeMarket: data.closeMarket,
          url: data.url,
        });
        onShowToast('✨ Market Detected!', `Auto detected ${data.baseName} Open & Close times from URL`, 'success');
      } else {
        onShowToast('❌ Detection Failed', data.message || 'Could not parse market link', 'danger');
      }
    } catch (_) {
      if (version === detectionVersionRef.current) onShowToast('❌ Error', 'Network error while parsing link', 'danger');
    } finally {
      if (version === detectionVersionRef.current) setIsParsingUrl(false);
    }
  };

  // Confirm and Add Detected Markets
  const handleConfirmAddDetected = () => {
    if (!parsedPreview) return;
    // Confirm is bound to the exact chart shown by the preview, not stale input.
    if (!previewMatchesCurrentChart(parsedPreview.url,urlInput.trim())) {
      setParsedPreview(null);
      onShowToast('Chart URL changed', 'Detect the updated URL before adding this market.', 'danger');
      return;
    }

    const currentCustom = [...(config.customMarkets || [])];
    const newOpen = parsedPreview.openMarket;
    const newClose = parsedPreview.closeMarket;

    // Filter out duplicates if same name exists in customMarkets
    const updatedCustom = currentCustom.filter(
      (m) => m.n.toUpperCase() !== newOpen.n.toUpperCase() && m.n.toUpperCase() !== newClose.n.toUpperCase()
    );
    updatedCustom.push(newOpen, newClose);

    // Save scrape URL mapping if available
    const marketScrapeUrls = { ...(config.marketScrapeUrls || {}) };
    if (parsedPreview.url) {
      marketScrapeUrls[newOpen.n] = parsedPreview.url;
      marketScrapeUrls[newClose.n] = parsedPreview.url;
      marketScrapeUrls[parsedPreview.baseName] = parsedPreview.url;
    }

    // Remove from deleted set if it was deleted previously
    const baseUpper = parsedPreview.baseName.toUpperCase();
    const openUpper = newOpen.n.toUpperCase();
    const closeUpper = newClose.n.toUpperCase();

    const updatedDeleted = (config.deletedMarketNames || []).filter((name) => {
      const u = String(name).toUpperCase();
      return u !== openUpper && u !== closeUpper && u !== baseUpper;
    });

    const newConfig: ProfileConfig = {
      ...config,
      customMarkets: updatedCustom,
      marketScrapeUrls,
      deletedMarketNames: updatedDeleted,
    };

    onUpdateConfig(newConfig);
    setUrlInput('');
    setParsedPreview(null);
    onShowToast('✅ Markets Added!', `Successfully added ${parsedPreview.baseName} Open & Close markets!`, 'success');
  };

  // Manual Add Market
  const handleAddManualMarket = () => {
    if (!manualName.trim()) {
      onShowToast('⚠️ Name Required', 'Please enter market name', 'danger');
      return;
    }

    if(!validMarketTime(manualHr,manualMin)){onShowToast('Invalid market time','Hour must be 0–23 and minute 0–59.','danger');return;}
    if(manualUrl.trim()&&!isChartProviderUrl(manualUrl.trim())){onShowToast('PlayMatka URL required','Use a playmatka.live chart URL. Other providers are disabled.','danger');return;}
    const uppercaseName = manualName.trim().replace(/\s+/g,' ').toUpperCase();
    const newMarket: MarketItem = {
      n: uppercaseName,
      hr: Math.max(0, Math.min(23, manualHr)),
      min: Math.max(0, Math.min(59, manualMin)),
      scrapeUrl: manualUrl.trim() || undefined,
      isCustom: true,
    };

    const currentCustom = [...(config.customMarkets || [])];
    const updatedCustom = currentCustom.filter((m) => m.n.toUpperCase() !== uppercaseName);
    updatedCustom.push(newMarket);

    const marketScrapeUrls = { ...(config.marketScrapeUrls || {}) };
    if (manualUrl.trim()) {
      marketScrapeUrls[uppercaseName] = manualUrl.trim();
    }

    const baseUpper=uppercaseName.replace(/\s+(OPEN|CLOSE)$/i,'').trim();
    const updatedDeleted = (config.deletedMarketNames || []).filter((n) => ![uppercaseName,baseUpper].includes(String(n).toUpperCase()));

    const newConfig: ProfileConfig = {
      ...config,
      customMarkets: updatedCustom,
      marketScrapeUrls,
      deletedMarketNames: updatedDeleted,
    };

    onUpdateConfig(newConfig);
    setManualName('');
    setManualUrl('');
    setShowManualForm(false);
    onShowToast('✅ Market Saved!', `Custom market ${uppercaseName} added successfully`, 'success');
  };

  // Delete / Hide Market
  const handleDeleteMarket = (marketName: string) => {
    const targetUpper = marketName.trim().toUpperCase();
    if (!confirm(`Are you sure you want to delete/hide market: "${targetUpper}"?`)) return;

    // Keep the definition so Restore retains time and scraping URL.
    const currentCustom = [...(config.customMarkets || [])];

    // Add to deletedMarketNames
    const currentDeleted = new Set((config.deletedMarketNames || []).map((n) => String(n).toUpperCase()));
    currentDeleted.add(targetUpper);

    const baseName = targetUpper.replace(/\s+(OPEN|CLOSE)$/i, '').trim();
    if (baseName) {
      currentDeleted.add(baseName);
      currentDeleted.add(`${baseName} OPEN`);
      currentDeleted.add(`${baseName} CLOSE`);
    }

    const newConfig: ProfileConfig = {
      ...config,
      customMarkets: currentCustom,
      deletedMarketNames: Array.from(currentDeleted),
    };

    onUpdateConfig(newConfig);
    onShowToast('🗑️ Market Removed', `${targetUpper} was removed from active markets`, 'info');
  };

  // Restore Deleted Market
  const handleRestoreMarket = (marketName: string) => {
    const targetUpper = marketName.trim().toUpperCase();
    const baseName = targetUpper.replace(/\s+(OPEN|CLOSE)$/i, '').trim();

    const updatedDeleted = (config.deletedMarketNames || []).filter((n) => {
      const u = String(n).toUpperCase();
      if (u === targetUpper) return false;
      if (baseName && (u === baseName || u === `${baseName} OPEN` || u === `${baseName} CLOSE`)) return false;
      return true;
    });

    const newConfig: ProfileConfig = {
      ...config,
      deletedMarketNames: updatedDeleted,
    };

    onUpdateConfig(newConfig);
    onShowToast('🔄 Market Restored', `${targetUpper} restored to active markets`, 'success');
  };

  // Save Scrape URL for existing market
  const handleSaveScrapeUrl = (marketName: string) => {
    if(editingUrlValue.trim()&&!isChartProviderUrl(editingUrlValue.trim())){onShowToast('PlayMatka URL required','Use a playmatka.live chart URL. Other providers are disabled.','danger');return;}
    const sourceChoice=editingUrlValue.trim();
    if(sourceChoice && resolveMarketScrapeUrl({marketScrapeUrls:{[marketName]:sourceChoice}},marketName)!==sourceChoice){
      onShowToast('Built-in source protected','This stock market uses its verified chart mapping. Manual URL changes are not applied.','danger');
      return;
    }
    const marketScrapeUrls = { ...(config.marketScrapeUrls || {}) };
    if (editingUrlValue.trim()) {
      marketScrapeUrls[marketName] = resolveMarketScrapeUrl({marketScrapeUrls:{[marketName]:editingUrlValue.trim()}},marketName) || editingUrlValue.trim();
    } else {
      delete marketScrapeUrls[marketName];
    }

    const newConfig: ProfileConfig = {
      ...config,
      marketScrapeUrls,
    };

    onUpdateConfig(newConfig);
    setEditingMarketName(null);
    setEditingUrlValue('');
    onShowToast('🌐 Scraper URL Saved', `Updated scrape link for ${marketName}`, 'success');
  };

  // Save Time for existing market
  const handleSaveMarketTime = (marketName: string) => {
    if(!validMarketTime(editingHr,editingMin)){onShowToast('Invalid market time','Hour must be 0–23 and minute 0–59.','danger');return;}
    const uppercaseName = marketName.toUpperCase();
    const currentCustom = [...(config.customMarkets || [])];

    const idx = currentCustom.findIndex((cm) => cm.n.toUpperCase() === uppercaseName);
    const existingMarket = activeMarkets.find((m) => m.n.toUpperCase() === uppercaseName);

    const updatedMarketItem: MarketItem = {
      n: uppercaseName,
      hr: Math.max(0, Math.min(23, editingHr)),
      min: Math.max(0, Math.min(59, editingMin)),
      scrapeUrl: config.marketScrapeUrls?.[marketName] || existingMarket?.scrapeUrl,
      isCustom: true,
    };

    if (idx !== -1) {
      currentCustom[idx] = updatedMarketItem;
    } else {
      currentCustom.push(updatedMarketItem);
    }

    const newConfig: ProfileConfig = {
      ...config,
      customMarkets: currentCustom,
    };

    onUpdateConfig(newConfig);
    setEditingTimeMarketName(null);
    onShowToast(
      '⏰ Time Updated!',
      `Updated ${uppercaseName} time to ${formatTime(editingHr, editingMin)}`,
      'success'
    );
  };

  // Filtered active markets
  const filteredActiveMarkets = activeMarkets.filter((m) =>
    marketNameMatchesSearch(m.n,searchQuery)
  );

  const formatTime = (hr?: number, min?: number) => {
    if (hr === undefined || min === undefined) return 'Time N/A';
    const hourStr = hr.toString().padStart(2, '0');
    const minStr = min.toString().padStart(2, '0');
    const period = hr >= 12 ? 'PM' : 'AM';
    const hour12 = hr % 12 === 0 ? 12 : hr % 12;
    return `${hourStr}:${minStr} (${hour12.toString().padStart(2, '0')}:${minStr} ${period})`;
  };

  const filteredMasterMarkets = activeBaseMarkets.filter((m) =>
    marketNameMatchesSearch(m.n,searchQuery)
  );
  const isMasterMarketEnabled = (baseName: string) => {
    const base = baseName.toUpperCase();
    const open = `${base} OPEN`;
    const close = `${base} CLOSE`;
    const existingNames = new Set(activeMarkets.map((m) => m.n.toUpperCase()));
    const ankVisible = (!existingNames.has(open) || isMarketEnabledForDate(config, dayRecord.visAnk, open))
      && (!existingNames.has(close) || isMarketEnabledForDate(config, dayRecord.visAnk, close));
    const panelVisible = (!existingNames.has(open) || isMarketEnabledForDate(config, dayRecord.visPan, open))
      && (!existingNames.has(close) || isMarketEnabledForDate(config, dayRecord.visPan, close));
    const jodiVisible = isMarketEnabledForDate(config, dayRecord.visJodi, base);
    return ankVisible && panelVisible && jodiVisible;
  };

  return (
    <div className="p-3 sm:p-4 space-y-4 max-w-4xl mx-auto pb-20">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#1E293B] to-[#0F172A] border border-[rgba(255,255,255,0.08)] rounded-2xl p-4 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
          <Globe className="w-32 h-32 text-[#2AABEE]" />
        </div>
        <div className="relative z-10 flex items-center justify-between flex-wrap gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-[rgba(42,171,238,0.15)] text-[#2AABEE] text-xs font-black uppercase px-2.5 py-0.5 rounded-md border border-[rgba(42,171,238,0.3)]">
                Market Center
              </span>
              <span className="text-[11px] text-[#7A9CB8]">Auto Web Scraper Sync</span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-white tracking-wide">
              Market & Web Scrapers
            </h2>
            <p className="text-xs text-[#94A3B8] mt-0.5">
              Auto-detect timings from chart links, customize timings, or manage active & deleted markets.
            </p>
          </div>
          <button
            onClick={() => setShowManualForm(!showManualForm)}
            className="bg-[rgba(255,255,255,0.06)] hover:bg-[rgba(255,255,255,0.1)] text-white text-xs font-bold px-3 py-2 rounded-xl border border-[rgba(255,255,255,0.1)] transition-all flex items-center gap-1.5"
          >
            {showManualForm ? <X className="w-4 h-4 text-red-400" /> : <Plus className="w-4 h-4 text-[#00C26F]" />}
            {showManualForm ? 'Close Manual Form' : 'Manual Add Market'}
          </button>
        </div>
      </div>

      {/* ONE master switch per base market controls runtime + all card visibility. */}
      <div className="bg-[#17212B] border border-[#2AABEE]/30 rounded-2xl p-4 shadow-lg space-y-3">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-[#2AABEE]" />
          <div>
            <h3 className="text-sm font-bold text-white">Master Market Control</h3>
            <p className="text-[10px] text-[#7A9CB8]">Ek button: ANK + JODI + PANEL visibility aur pura market system ON/OFF.</p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-80 overflow-y-auto pr-1">
          {filteredMasterMarkets.map((m) => {
            const enabled = isMasterMarketEnabled(m.n);
            return (
              <div key={`master_${m.n}`} className={`flex items-center justify-between gap-2 px-3 py-2.5 rounded-xl border ${enabled ? 'bg-[#232E3C] border-white/5' : 'bg-[#FF5D5D]/10 border-[#FF5D5D]/25'}`}>
                <div className="min-w-0">
                  <div className={`text-[10px] font-black truncate ${enabled ? 'text-white' : 'text-[#FF8A8A]'}`}>{m.n}</div>
                  <div className={`text-[8px] font-bold ${enabled ? 'text-[#00C26F]' : 'text-[#FF5D5D]'}`}>
                    {enabled ? 'ALL SYSTEMS ON' : 'ALL SYSTEMS OFF'}
                  </div>
                </div>
                <label className="switch shrink-0">
                  <input
                    type="checkbox"
                    checked={enabled}
                    aria-label={`${m.n} market ON/OFF`}
                    onChange={(e) => {
                      onToggleMasterMarket(m.n, e.target.checked);
                      onShowToast(
                        e.target.checked ? '🟢 Market Fully ON' : '🔴 Market Fully OFF',
                        `${m.n}: selected profile ke ANK, JODI, PANEL, queue, result, recovery aur schedule ${e.target.checked ? 'enabled' : 'disabled'}`,
                        e.target.checked ? 'success' : 'info',
                      );
                    }}
                  />
                  <span className="slider round"></span>
                </label>
              </div>
            );
          })}
        </div>
      </div>

      {/* 1. EASY AUTO ADD BY CHART URL */}
      <div className="bg-[#17212B] border border-[rgba(42,171,238,0.3)] rounded-2xl p-4 shadow-lg space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-[rgba(42,171,238,0.15)] flex items-center justify-center text-[#2AABEE]">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">⚡ Auto Add Market by Chart URL</h3>
            <p className="text-[11px] text-[#7A9CB8]">
              Paste a PlayMatka chart URL. Only this provider is enabled.
            </p>
          </div>
        </div>

        <div className="flex gap-2 flex-col sm:flex-row">
          <div className="flex-1 bg-[#232E3C] border border-[rgba(255,255,255,0.1)] rounded-xl px-3 py-2 flex items-center gap-2">
            <Link2 className="w-4 h-4 text-[#2AABEE] shrink-0" />
            <input
              type="url"
              placeholder="Paste URL e.g. https://playmatka.live/panel-chart/kalyan-night"
              value={urlInput}
              onChange={(e) => {
                detectionVersionRef.current++;
                setUrlInput(e.target.value);
                setParsedPreview(null);
                setIsParsingUrl(false);
              }}
              className="bg-transparent text-xs text-white placeholder-[#7A9CB8] w-full focus:outline-none"
            />
          </div>
          <button
            onClick={handleParseUrl}
            disabled={isParsingUrl}
            className="bg-[#2AABEE] hover:bg-[#2297D6] text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5 shrink-0 disabled:opacity-50"
          >
            {isParsingUrl ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Detecting...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Auto Detect Market</span>
              </>
            )}
          </button>
        </div>

        {/* DETECTED PREVIEW BOX WITH EDITABLE TIMES */}
        {parsedPreview && (
          <div className="bg-[#232E3C] border border-[#00C26F]/40 rounded-xl p-3.5 space-y-3 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.08)] pb-2 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#00C26F]" />
                <span className="text-xs font-bold text-white">Detected Base Market:</span>
                <input
                  type="text"
                  value={parsedPreview.baseName}
                  onChange={(e) => {
                    const newBase = e.target.value.toUpperCase();
                    setParsedPreview({
                      ...parsedPreview,
                      baseName: newBase,
                      openMarket: { ...parsedPreview.openMarket, n: `${newBase} OPEN` },
                      closeMarket: { ...parsedPreview.closeMarket, n: `${newBase} CLOSE` },
                    });
                  }}
                  className="text-xs font-black text-[#FAC748] uppercase bg-[rgba(250,199,72,0.15)] px-2 py-0.5 rounded border border-[rgba(250,199,72,0.3)] focus:outline-none"
                />
              </div>
              <span className="text-[10px] text-[#00C26F] font-bold">✨ Auto Timings Caught (Editable)</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {/* Open Market preview */}
              <div className="bg-[#17212B] p-2.5 rounded-lg border border-[rgba(255,255,255,0.06)] space-y-1.5">
                <span className="text-[10px] text-[#7A9CB8] block font-semibold">OPEN MARKET</span>
                <span className="font-bold text-white block">{parsedPreview.openMarket.n}</span>
                <div className="flex items-center gap-2 text-xs">
                  <Clock className="w-3.5 h-3.5 text-[#2AABEE] shrink-0" />
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] text-[#7A9CB8]">Hour:</span>
                    <input
                      type="number"
                      min="0"
                      max="23"
                      value={parsedPreview.openMarket.hr}
                      onChange={(e) => {
                        const val = parseInt(e.target.value, 10) || 0;
                        setParsedPreview({
                          ...parsedPreview,
                          openMarket: { ...parsedPreview.openMarket, hr: Math.max(0, Math.min(23, val)) },
                        });
                      }}
                      className="w-12 bg-[#232E3C] border border-[rgba(255,255,255,0.15)] rounded px-1 py-0.5 text-center text-white text-xs font-bold focus:outline-none"
                    />
                    <span className="text-[10px] text-[#7A9CB8]">Min:</span>
                    <input
                      type="number"
                      min="0"
                      max="59"
                      value={parsedPreview.openMarket.min}
                      onChange={(e) => {
                        const val = parseInt(e.target.value, 10) || 0;
                        setParsedPreview({
                          ...parsedPreview,
                          openMarket: { ...parsedPreview.openMarket, min: Math.max(0, Math.min(59, val)) },
                        });
                      }}
                      className="w-12 bg-[#232E3C] border border-[rgba(255,255,255,0.15)] rounded px-1 py-0.5 text-center text-white text-xs font-bold focus:outline-none"
                    />
                  </div>
                </div>
                <p className="text-[10px] text-[#00C26F] font-semibold">
                  Preview: {formatTime(parsedPreview.openMarket.hr, parsedPreview.openMarket.min)}
                </p>
              </div>

              {/* Close Market preview */}
              <div className="bg-[#17212B] p-2.5 rounded-lg border border-[rgba(255,255,255,0.06)] space-y-1.5">
                <span className="text-[10px] text-[#7A9CB8] block font-semibold">CLOSE MARKET</span>
                <span className="font-bold text-white block">{parsedPreview.closeMarket.n}</span>
                <div className="flex items-center gap-2 text-xs">
                  <Clock className="w-3.5 h-3.5 text-[#2AABEE] shrink-0" />
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] text-[#7A9CB8]">Hour:</span>
                    <input
                      type="number"
                      min="0"
                      max="23"
                      value={parsedPreview.closeMarket.hr}
                      onChange={(e) => {
                        const val = parseInt(e.target.value, 10) || 0;
                        setParsedPreview({
                          ...parsedPreview,
                          closeMarket: { ...parsedPreview.closeMarket, hr: Math.max(0, Math.min(23, val)) },
                        });
                      }}
                      className="w-12 bg-[#232E3C] border border-[rgba(255,255,255,0.15)] rounded px-1 py-0.5 text-center text-white text-xs font-bold focus:outline-none"
                    />
                    <span className="text-[10px] text-[#7A9CB8]">Min:</span>
                    <input
                      type="number"
                      min="0"
                      max="59"
                      value={parsedPreview.closeMarket.min}
                      onChange={(e) => {
                        const val = parseInt(e.target.value, 10) || 0;
                        setParsedPreview({
                          ...parsedPreview,
                          closeMarket: { ...parsedPreview.closeMarket, min: Math.max(0, Math.min(59, val)) },
                        });
                      }}
                      className="w-12 bg-[#232E3C] border border-[rgba(255,255,255,0.15)] rounded px-1 py-0.5 text-center text-white text-xs font-bold focus:outline-none"
                    />
                  </div>
                </div>
                <p className="text-[10px] text-[#00C26F] font-semibold">
                  Preview: {formatTime(parsedPreview.closeMarket.hr, parsedPreview.closeMarket.min)}
                </p>
              </div>
            </div>

            <button
              onClick={handleConfirmAddDetected}
              className="w-full bg-[#00C26F] hover:bg-[#00A860] text-white font-bold text-xs py-2.5 rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Confirm & Add Both Open & Close Markets</span>
            </button>
          </div>
        )}
      </div>

      {/* 2. MANUAL ADD FORM (IF TOGGLED) */}
      {showManualForm && (
        <div className="bg-[#17212B] border border-[rgba(255,255,255,0.1)] rounded-2xl p-4 shadow-lg space-y-3 animate-fadeIn">
          <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.08)] pb-2">
            <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
              <Plus className="w-4 h-4 text-[#00C26F]" />
              Add Custom Market Manually
            </h3>
            <button onClick={() => setShowManualForm(false)} className="text-[#7A9CB8] hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
            <div className="sm:col-span-2">
              <label className="text-[10px] text-[#7A9CB8] block mb-1">Market Name (e.g. KALYAN NIGHT OPEN)</label>
              <input
                type="text"
                placeholder="MARKET NAME"
                value={manualName}
                onChange={(e) => setManualName(e.target.value)}
                className="w-full bg-[#232E3C] border border-[rgba(255,255,255,0.1)] rounded-xl px-3 py-2 text-white uppercase placeholder-[#7A9CB8] focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-1">
              <div>
                <label className="text-[10px] text-[#7A9CB8] block mb-1">Hour (0-23)</label>
                <input
                  type="number"
                  min="0"
                  max="23"
                  value={manualHr}
                  onChange={(e) => setManualHr(parseInt(e.target.value, 10) || 0)}
                  className="w-full bg-[#232E3C] border border-[rgba(255,255,255,0.1)] rounded-xl px-2 py-2 text-white text-center focus:outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-[#7A9CB8] block mb-1">Min (0-59)</label>
                <input
                  type="number"
                  min="0"
                  max="59"
                  value={manualMin}
                  onChange={(e) => setManualMin(parseInt(e.target.value, 10) || 0)}
                  className="w-full bg-[#232E3C] border border-[rgba(255,255,255,0.1)] rounded-xl px-2 py-2 text-white text-center focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="text-[10px] text-[#7A9CB8] block mb-1">Scrape Link URL (Optional)</label>
            <input
              type="url"
              placeholder="https://..."
              value={manualUrl}
              onChange={(e) => setManualUrl(e.target.value)}
              className="w-full bg-[#232E3C] border border-[rgba(255,255,255,0.1)] rounded-xl px-3 py-2 text-white placeholder-[#7A9CB8] focus:outline-none text-xs"
            />
          </div>

          <button
            onClick={handleAddManualMarket}
            className="w-full bg-[#00C26F] hover:bg-[#00A860] text-white font-bold text-xs py-2 rounded-xl transition-all flex items-center justify-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Save Custom Market</span>
          </button>
        </div>
      )}

      {/* 3. ACTIVE MARKETS LIST */}
      <div className="bg-[#17212B] border border-[rgba(255,255,255,0.08)] rounded-2xl p-4 shadow-lg space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#2AABEE]" />
            <h3 className="text-sm font-bold text-white">
              Active Markets ({filteredActiveMarkets.length})
            </h3>
          </div>

          <div className="bg-[#232E3C] border border-[rgba(255,255,255,0.08)] rounded-xl px-2.5 py-1 flex items-center gap-1.5 text-xs w-full sm:w-auto">
            <Search className="w-3.5 h-3.5 text-[#7A9CB8]" />
            <input
              type="text"
              placeholder="Search market name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent text-white placeholder-[#7A9CB8] focus:outline-none w-full text-xs"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
          {filteredActiveMarkets.map((m) => {
            const customScrapeUrl = resolveMarketScrapeUrl(config,m.n);
            const isEditingUrl = editingMarketName === m.n;
            const isEditingTime = editingTimeMarketName === m.n;

            return (
              <div
                key={m.n}
                className="bg-[#232E3C] border border-[rgba(255,255,255,0.06)] hover:border-[rgba(255,255,255,0.15)] rounded-xl p-3 transition-all space-y-2"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-black text-white text-xs">{m.n}</span>
                      {m.isCustom ? (
                        <span className="text-[9px] font-bold uppercase bg-[rgba(184,92,255,0.2)] text-[#B85CFF] px-1.5 py-0.5 rounded border border-[rgba(184,92,255,0.3)]">
                          CUSTOM
                        </span>
                      ) : (
                        <span className="text-[9px] font-bold uppercase bg-[rgba(255,255,255,0.06)] text-[#7A9CB8] px-1.5 py-0.5 rounded">
                          DEFAULT
                        </span>
                      )}
                    </div>

                    {/* TIME DISPLAY OR TIME EDITOR */}
                    {isEditingTime ? (
                      <div className="bg-[#17212B] p-2 rounded-lg border border-[rgba(42,171,238,0.3)] space-y-1.5 mt-1">
                        <div className="flex items-center justify-between text-[10px] text-[#2AABEE] font-bold">
                          <span>Set Manual Timing:</span>
                          <button onClick={() => setEditingTimeMarketName(null)} className="text-[#7A9CB8] hover:text-white">
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1">
                            <span className="text-[10px] text-[#7A9CB8]">Hr:</span>
                            <input
                              type="number"
                              min="0"
                              max="23"
                              value={editingHr}
                              onChange={(e) => setEditingHr(parseInt(e.target.value, 10) || 0)}
                              className="w-12 bg-[#232E3C] border border-[rgba(255,255,255,0.15)] text-center text-white text-xs font-bold rounded py-0.5 focus:outline-none"
                            />
                          </div>
                          <div className="flex items-center gap-1">
                            <span className="text-[10px] text-[#7A9CB8]">Min:</span>
                            <input
                              type="number"
                              min="0"
                              max="59"
                              value={editingMin}
                              onChange={(e) => setEditingMin(parseInt(e.target.value, 10) || 0)}
                              className="w-12 bg-[#232E3C] border border-[rgba(255,255,255,0.15)] text-center text-white text-xs font-bold rounded py-0.5 focus:outline-none"
                            />
                          </div>
                          <button
                            onClick={() => handleSaveMarketTime(m.n)}
                            className="bg-[#00C26F] hover:bg-[#00A860] text-white text-[10px] font-bold px-2.5 py-1 rounded transition-all flex items-center gap-1 shrink-0 ml-auto"
                          >
                            <Check className="w-3 h-3" />
                            <span>Save Time</span>
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 mt-1">
                        <div className="flex items-center gap-1 text-[11px] text-[#7A9CB8]">
                          <Clock className="w-3 h-3 text-[#2AABEE]" />
                          <span>{formatTime(m.hr, m.min)}</span>
                        </div>
                        <button
                          onClick={() => {
                            setEditingTimeMarketName(m.n);
                            setEditingHr(m.hr ?? 12);
                            setEditingMin(m.min ?? 0);
                          }}
                          className="text-[10px] text-[#2AABEE] hover:underline font-bold flex items-center gap-0.5 bg-[rgba(42,171,238,0.1)] px-1.5 py-0.5 rounded"
                          title="Manually edit market timing"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>Edit Time</span>
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleDeleteMarket(m.n)}
                      className="p-1.5 rounded-lg bg-[rgba(255,82,82,0.1)] text-red-400 hover:bg-red-500 hover:text-white transition-all shrink-0"
                      title="Delete / Hide Market"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Scrape URL bar / Edit */}
                <div className="bg-[#17212B] p-2 rounded-lg border border-[rgba(255,255,255,0.05)] text-[11px]">
                  {isEditingUrl ? (
                    <div className="flex gap-1.5 items-center">
                      <input
                        type="url"
                        placeholder="https://..."
                        value={editingUrlValue}
                        onChange={(e) => setEditingUrlValue(e.target.value)}
                        className="bg-[#232E3C] border border-[rgba(255,255,255,0.1)] rounded px-2 py-1 text-white w-full text-[11px] focus:outline-none"
                      />
                      <button
                        onClick={() => handleSaveScrapeUrl(m.n)}
                        className="bg-[#00C26F] text-white px-2 py-1 rounded text-[10px] font-bold shrink-0"
                      >
                        Save
                      </button>
                      <button
                        onClick={() => setEditingMarketName(null)}
                        className="text-[#7A9CB8] hover:text-white px-1"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between gap-1">
                      <div className="flex items-center gap-1 overflow-hidden text-[#7A9CB8] text-[10px]">
                        <Globe className="w-3 h-3 text-[#2AABEE] shrink-0" />
                        <span className="truncate">
                          {customScrapeUrl || 'Default Scraper Link'}
                        </span>
                      </div>
                      <button
                        onClick={() => {
                          setEditingMarketName(m.n);
                          setEditingUrlValue(customScrapeUrl || '');
                        }}
                        className="text-[#2AABEE] hover:underline flex items-center gap-0.5 text-[10px] font-semibold shrink-0"
                      >
                        <Edit3 className="w-3 h-3" />
                        <span>Edit Link</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {filteredActiveMarkets.length === 0 && (
            <div className="col-span-full text-center py-6 text-[#7A9CB8] text-xs">
              No markets found matching "{searchQuery}".
            </div>
          )}
        </div>
      </div>

      {/* 4. DELETED MARKETS RESTORATION SECTION */}
      {deletedSet.size > 0 && (
        <div className="bg-[#17212B] border border-red-500/20 rounded-2xl p-4 shadow-lg space-y-3">
          <div className="flex items-center gap-2">
            <Trash2 className="w-4 h-4 text-red-400" />
            <h3 className="text-sm font-bold text-white">
              Deleted / Hidden Markets ({deletedSet.size})
            </h3>
          </div>

          <div className="flex flex-wrap gap-2 text-xs">
            {Array.from(deletedSet).map((marketName) => {
              const nameStr = String(marketName);
              return (
                <div
                  key={nameStr}
                  className="bg-[#232E3C] border border-[rgba(255,255,255,0.08)] px-3 py-1.5 rounded-xl flex items-center gap-2"
                >
                  <span className="text-white text-xs font-medium">{nameStr}</span>
                  <button
                    onClick={() => handleRestoreMarket(nameStr)}
                    className="bg-[rgba(42,171,238,0.15)] hover:bg-[#2AABEE] text-[#2AABEE] hover:text-white px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Restore</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
