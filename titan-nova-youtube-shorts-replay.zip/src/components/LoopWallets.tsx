import React from 'react';
import type { UserProfile, GameType } from '../types';
import { calculateLoopWallets } from '../utils/loopWallets';
export const LoopWallets:React.FC<{profile:UserProfile;date:string;type:GameType}> = ({profile,date,type})=>{
 const wallets=calculateLoopWallets(profile,date,type);if(!wallets.length)return null;
 const game=type==='pannel'?'PANEL':type.toUpperCase();
 const inr=(n:number)=>`₹${Math.round(n).toLocaleString('en-IN')}`;
 return <div aria-label="Independent loop wallets" className="px-3 py-2 space-y-2">
  <div className="text-[9px] text-[#8DA6C0]">{game} accounts · capital {inr(wallets.reduce((s,w)=>s+w.capital,0))} · profit {inr(wallets.reduce((s,w)=>s+w.pl,0))}</div>
  <div className="grid grid-cols-2 gap-2">{wallets.map(w=><div key={w.id} data-loop-wallet={w.id} className={`rounded-xl bg-[#17212B] border border-white/10 p-2 space-y-1 ${wallets.length===1||wallets.length===3&&w.id==='L3'?'col-span-2':''}`}>
   <div className="flex justify-between text-[10px] font-black"><span className={w.id==='L1'?'text-[#2AABEE]':w.id==='L2'?'text-[#B85CFF]':w.id==='L3'?'text-[#FAC748]':'text-[#20E093]'}>{w.name===w.id?w.id:`${w.name} · ${w.id}`} · {game}</span><span className={w.pl>=0?'text-[#20E093]':'text-[#FF8A8A]'}>{w.pl>=0?'+':''}{inr(w.pl)}</span></div>
   <div role="status" className="text-[10px] font-bold text-sky-200">{w.status==='TARGET_REACHED'?'STOP · Profit goal reached':w.status==='CAPITAL_LIMIT'?'STOP · Capital limit':'Active'}</div>
   <div className="text-[9px] text-[#8DA6C0]">Capital {inr(w.capital)} · available {inr(w.availableCapital)}</div>
   <div className="text-[9px] text-[#8DA6C0]">Daily goal {inr(w.dayTarget)} · stake reserved {inr(w.pendingInvest)}</div>
   <div className="text-[9px] text-[#8DC8FF]">{type==='pannel'?'PANEL':type.toUpperCase()} loss {inr(w.debt[type])} · card target {inr(w.targets[type])}</div>
  </div>)}</div>
 </div>;
};
