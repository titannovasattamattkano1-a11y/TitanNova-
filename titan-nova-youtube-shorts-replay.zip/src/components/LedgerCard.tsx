import {ScopedActionGate} from '../utils/scopedActionGate';
import { createScrollThrottle } from '../utils/scrollThrottle';
import { sourceIndexViewport } from '../utils/sourceIndexViewport';
import { canAutoEvaluateBacktest } from '../utils/backtestResult';
import {smartIndicator} from '../utils/smartIndicator';
import {cardDigitSupport} from '../utils/digitSupport';
import {canApplySourceWindowHistory} from '../utils/sourceWindowHistory';
import {canApplyMarketHistoryChoice,marketHistorySourceLabel} from '../utils/marketHistoryLogic';
import { scheduleTextareaFit, textareaWidthChanged, cancelTextareaFit, observeTextareaFit } from '../utils/fitTextareas';
import { sourceIndexCell, resolveSourceIndexCell, type SourceIndexHistory } from '../utils/sourceIndexHistory';
import { selectionUndoSource } from '../utils/undoSelection';
import { assignedLoop, dayLoopConfig, profileLoopTarget } from '../utils/dualLoops';
import { isEditableSourceSkip, marketModelReasonLabel } from '../utils/marketModelCard';
import { normalizeManualResult, manualResultMatchesStatus } from '../utils/manualResult';
import { panelAnkDigit } from '../utils/panelAnk';
import { sourceIndexDisplayPages, sourceIndexWeekLength, sourceIndexStripLabel, sourceIndexAppliedMethod, sourceIndexHistorySuggestion } from '../utils/sourceIndexDisplayDates';
import { getScrapeSource } from '../utils/scrapeProvenance';
import './LedgerCard.css';
import React, { useState, useRef, useLayoutEffect } from 'react';
import { GameType, DayMarketRecord, MarketItem, UserProfile } from '../types';
import { applyTrickFormula, isStrongWeekSource, titanLocalDateISO, getEffectiveCardRate, getCardSameMarketRecoveryState } from '../utils/calculator';
import {
  CheckCircle,
  XCircle,
  Forward,
  Clock,
  LockKeyhole,
  Trash2,
  Satellite,
  RotateCcw,
  Users,
  ChevronDown,
  ChevronUp,
  Wrench,
  TrendingDown,
  Zap,
  Sparkles,
} from 'lucide-react';
import { TargetSelectorModal } from './TargetSelectorModal';
import { areSettlementTokensValid, calculateRecoveryRate, calculateSmartStakingRates, countSettlementTokens, isRecoveryRatePossible, settlementMargin } from '../utils/settlement';
import { useTwoCardRecovery } from '../utils/twoCardRecovery';
import { findHistoricalMarketRecord, findLatestSettledMarketRecord, findMarketIndexByName, getRecordFilterLabel, getCompactFilterBadge, getNextDayFilterRecommendation } from '../utils/cardHistory';
import { recentUniqueSourceIndices } from '../utils/keepRecentSixIndices';
import { getEffectiveBaseMarkets, getEffectiveMarkets, isNightMarket } from '../data/markets';
import { scoreDigitProbabilities } from '../utils/filterProbability';

interface LedgerCardProps {
  type: GameType;
  index: number;
  market: MarketItem;
  record: DayMarketRecord;
  isMaster: boolean;
  vipCanEdit: boolean;
  profiles: Record<string, UserProfile>;
  sourceIndexHistory?: SourceIndexHistory;
  activeId: string;
  currentDate: string;
  onUpdateRecord: (type: GameType, index: number, field: 'd' | 'r' | 's' | 'schTime' | 'sourceMode', value: any) => void;
  onApplyRecoveryRate?: (type: GameType, index: number) => void;
  onApplyTrick: (type: GameType, index: number, formattedDigits: string, trickTag: 'T1' | 'T2' | 'T3') => void;
  onApplyTriCut?: (index: number) => void;
  onApplySniperOne?: (index: number) => void;
  onApplyTesla369?: (index: number) => void;
  onRecentIndices?: (index:number,mode:'keep6'|'remove4'|'lcut'|'fcut'|'ssd') => void;
  onMarketHistoryLogic?: (index:number,marketName:string) => void | Promise<void>;
  onTieHistory?: (index:number,marketName:string) => void | Promise<void>;
  onCancelTieHistory?: (index:number) => void;
  tieHistoryProgress?: string;
  onUndoTrick: (type: GameType, index: number) => void;
  onScrapeMarket: (type: GameType, index: number, marketName: string) => void | Promise<void>;
  onWeekdayScrapeMarket?: (type: GameType, index: number, marketName: string) => void | Promise<void>;
  onComboScrape: (type: GameType, index: number, marketName: string) => void | Promise<void>;
  onDayComboScrape?: (type: GameType, index: number, marketName: string) => void | Promise<void>;
  onTrendBreak?: (type: GameType, index: number, marketName: string) => void | Promise<void>;
  onSmartAutoDigits?: (type: GameType, index: number, marketName: string) => void | Promise<void>;
  onBuildJodiFromAnk?: (index: number, marketName: string) => void;
  onApplyLifetimeJodiFormula?: (index: number, marketName: string) => void | Promise<any>;
  onApply32JodiOnly?: (index: number, marketName: string) => void | Promise<any>;
  onApplySrideviMasterFormula?: (index: number, marketName: string) => void | Promise<any>;
  onApplySrideviHeadSum?: (index: number, marketName: string) => void | Promise<any>;
  onApplyTimeBazarRoot?: (index: number, marketName: string) => void | Promise<any>;
  onApplyMadhurTotal?: (index: number, marketName: string) => void | Promise<any>;
  onApplyMilanPyramid?: (index: number, marketName: string) => void | Promise<any>;
  onApplySupremeCenter?: (index: number, marketName: string) => void | Promise<any>;
  onApplyKalyanFarak?: (index: number, marketName: string) => void | Promise<any>;
  onApplyMainBazar?: (index: number, marketName: string) => void | Promise<any>;
  onApplyMilanNight?: (index: number, marketName: string) => void | Promise<any>;
  onApplyUniversalLifetime4Ank?: (index: number, marketName: string) => void | Promise<any>;
  onTransferJodiToAnk?: (index: number, marketName: string) => void;
  onBuildPanelFromAnk?: (index: number, marketName: string) => void | Promise<void>;
  onBuildStrictPanel30?: (index: number, marketName: string) => void | Promise<void>;
  onBuildLowPanelFromAnk?: (index: number, marketName: string) => void | Promise<void>;
  onTestResult?: (type: GameType, index: number) => Promise<void>;
  onSendNow?: (type: GameType, index: number) => Promise<void>;
  onScheduleUpdate: (type: GameType, index: number, time: string, targets: string[]) => void;
  onResetCard: (type: GameType, index: number) => void;
  onUnlockCard: (type: GameType, index: number) => void;
  disabled?: boolean;
}

const LedgerCardView: React.FC<LedgerCardProps> = ({
  type,
  index,
  market,
  record,
  isMaster,
  vipCanEdit,
  profiles,
  sourceIndexHistory,
  activeId,
  currentDate,
  onUpdateRecord,
  onApplyRecoveryRate,
  onApplyTrick,
  onApplyTriCut,
  onApplySniperOne,
  onApplyTesla369,
  onRecentIndices,
  onMarketHistoryLogic,
  onTieHistory,
  onCancelTieHistory,
  tieHistoryProgress,
  onUndoTrick,
  onScrapeMarket,
  onWeekdayScrapeMarket,
  onComboScrape,
  onDayComboScrape,
  onSmartAutoDigits,
  onTrendBreak,
  onBuildJodiFromAnk,
  onApplyLifetimeJodiFormula,
  onApply32JodiOnly,
  onApplySrideviMasterFormula,
  onApplySrideviHeadSum,
  onApplyTimeBazarRoot,
  onApplyMadhurTotal,
  onApplyMilanPyramid,
  onApplySupremeCenter,
  onApplyKalyanFarak,
  onApplyMainBazar,
  onApplyMilanNight,
  onApplyUniversalLifetime4Ank,
  onTransferJodiToAnk,
  onBuildPanelFromAnk,
  onBuildLowPanelFromAnk,
  onBuildStrictPanel30,
  onTestResult,
  onSendNow,
  onScheduleUpdate,
  onResetCard,
  onUnlockCard,
  disabled = false,
}) => {

  const currentProf = profiles[activeId] || profiles['admin1'];
  const cardRoot = useRef<HTMLDivElement>(null);
  const [showSourceHistory, setShowSourceHistory] = useState(() => typeof IntersectionObserver === 'undefined');
  useLayoutEffect(() => {
    if (showSourceHistory || type !== 'ank') return;
    const card = cardRoot.current;
    if (!card) return;
    const observer = new IntersectionObserver(entries => {
      if (entries.some(entry => entry.isIntersecting)) {
        setShowSourceHistory(true);
        observer.disconnect();
      }
    }, {rootMargin:'800px'});
    observer.observe(card);
    return () => observer.disconnect();
  }, [showSourceHistory, type, activeId]);

  const cfg = currentProf?.config;
  const marketKey = `${type}_${index}`;
  const historySource=getScrapeSource(record);
  const jodiOpenSummary = type === 'jodi' && record.jodiOpenStatus && (
    <div data-jodi-open-status={record.jodiOpenStatus}
      className={`mt-1 text-[10px] font-bold ${record.jodiOpenStatus === 'PASS' ? 'text-[#4ADE80]' : 'text-[#FF8A8A]'}`}>
      OPEN {record.jodiOpenResult} · {record.jodiOpenStatus}
      {record.s === 'WAIT' && <span className="text-[#8DA6C0]"> · Full Jodi: CLOSE result pending</span>}
    </div>
  );
  const isVipProfile = activeId !== 'admin1';
  const [sendingNow, setSendingNow] = useState(false);
  const sendingNowRef = useRef(false);
  const showSendNow = isMaster && isVipProfile && Boolean(onSendNow);
  const sendCardCopy = async () => {
    if (sendingNowRef.current || !onSendNow) return;
    sendingNowRef.current = true; setSendingNow(true);
    try { await onSendNow(type, index); }
    finally { sendingNowRef.current = false; setSendingNow(false); }
  };

  // VIP delivery is event-driven. Never expose or inherit admin clock/target scheduling.
  const effectiveSchTime = isVipProfile ? '' : (record?.schTime ?? cfg?.marketScheduleTimes?.[marketKey] ?? cfg?.marketScheduleTimes?.[market.n] ?? '');
  const effectiveSchTargets = isVipProfile ? [] : (record?.schTargets ?? cfg?.marketScheduleTargets?.[marketKey] ?? cfg?.marketScheduleTargets?.[market.n] ?? []);

  const [manualStatusChoice, setManualStatusChoice] = useState<'PASS' | 'FAIL' | null>(null);
  const [manualDigits, setManualDigits] = useState<string[]>(['', '', '']);
  const [includeManualPanel, setIncludeManualPanel] = useState(false);
  const [manualPanelDigits, setManualPanelDigits] = useState<string[]>(['', '', '']);
  const resultLength = type === 'ank' ? 1 : type === 'jodi' ? 2 : 3;
  const selectedManualResult = normalizeManualResult(type, manualDigits.slice(0, resultLength).join(''));
  const selectedManualPanel = includeManualPanel && type === 'ank' ? normalizeManualResult('pannel', manualPanelDigits.join('')) : undefined;
  const manualPanelValid = !includeManualPanel || type !== 'ank' || Boolean(selectedManualPanel && panelAnkDigit(selectedManualPanel) === selectedManualResult);
  const manualResultValid = Boolean(selectedManualResult && manualStatusChoice && manualPanelValid && manualResultMatchesStatus(type, record.sentDigits || record.d, selectedManualResult, manualStatusChoice));
  const startManualResult = (status: 'PASS' | 'FAIL') => { setManualDigits(['', '', '']); setIncludeManualPanel(false); setManualPanelDigits(['', '', '']); setManualStatusChoice(status); };
  React.useEffect(() => { setManualStatusChoice(null); }, [type, index, activeId, currentDate, record.s]);
  const actionGate=useRef(new ScopedActionGate());
  const [activeCardAction,setActiveCardAction]=useState<string|null>(null);
  const [cardActionError,setCardActionError]=useState('');
  const actionScope=`${activeId}|${currentDate}|${type}|${index}|${market.n}`;
  useLayoutEffect(()=>{const gate=actionGate.current;gate.reset();setActiveCardAction(null);setCardActionError('');setSelectedScrapeButton(null);return()=>gate.reset();},[actionScope]);
  const runCardAction=(action:string,task:()=>unknown|Promise<unknown>)=>{
    if(disabled||isDeliveryFrozen)return Promise.resolve(false);
    return actionGate.current.run(actionScope,action,task,(pending,error)=>{
      setActiveCardAction(pending);
      if(pending&&!error&&!['test','history','history-tie'].includes(pending))setSelectedScrapeButton(pending);
      if(error)setCardActionError(error.message);else if(pending)setCardActionError('');
    });
  };
  const isScraping=activeCardAction!==null;
  const testingResult=activeCardAction==='test';
  const isApplyingHistory=activeCardAction==='history';
  const [selectedScrapeButton, setSelectedScrapeButton] = useState<string | null>(null);
  const selectedScrapeClass = (button: string) => selectedScrapeButton === button
    ? 'ring-2 ring-white/90 ring-offset-2 ring-offset-[#18222D] brightness-125 shadow-[0_0_18px_rgba(255,255,255,0.65)]'
    : '';
  const [isToolsOpen, setIsToolsOpen] = useState(false);
  const [schTime, setSchTime] = useState(effectiveSchTime);
  const [schTargets, setSchTargets] = useState<string[]>(effectiveSchTargets);
  const [isTargetModalOpen, setIsTargetModalOpen] = useState(false);
  const [digitDraft, setDigitDraft] = useState(String(record?.d || ''));
  const digitDraftRef=useRef({value:String(record?.d||''),changed:false});
  const [isDigitEditing, setIsDigitEditing] = useState(false);
  useLayoutEffect(()=>{
    const value=String(record?.d||'');digitDraftRef.current={value,changed:false};setDigitDraft(value);setIsDigitEditing(false);
  },[currentDate,activeId,type,index,market.n]);
  const [sourceViewport, setSourceViewport] = useState({start:0,end:3});
  // The keyed strip starts at native scroll position zero. Imperative scrollTop
  // writes here forced layout for every card during the commit phase.
  useLayoutEffect(() => {
    setSourceViewport({start:0,end:3});
  }, [currentDate, market.n, activeId, currentProf?.name]);

  const targetsKey = (effectiveSchTargets || []).join('|');
  React.useEffect(() => {
    setSchTime(effectiveSchTime);
    setSchTargets(effectiveSchTargets);
  }, [effectiveSchTime, targetsKey]);

  const d = record || { s: 'WAIT', d: '', r: '' };
  // Only a user-edited draft owns the focused value. Untouched fields follow a
  // completed scrape; blur must never write their previous empty value back.
  React.useEffect(() => {
    if (!isDigitEditing||!digitDraftRef.current.changed) {setDigitDraft(String(d.d||''));digitDraftRef.current.value=String(d.d||'');}
  }, [d.d, isDigitEditing]);
  const visibleDigits = isDigitEditing ? digitDraft : String(d.d || '');
  const digitBoxRef=useRef<HTMLTextAreaElement>(null);
  useLayoutEffect(()=>{
    const box=digitBoxRef.current;if(!box)return;
    observeTextareaFit(box);
    const fit=()=>scheduleTextareaFit(box);
    fit();const observer=new ResizeObserver(()=>{if(textareaWidthChanged(box))fit();});observer.observe(box);
    document.fonts?.addEventListener('loadingdone',fit);
    return()=>{observer.disconnect();cancelTextareaFit(box);document.fonts?.removeEventListener('loadingdone',fit);};
  },[visibleDigits,d.s]);
  const selectedSourceDigits = (d.sentDigits || visibleDigits).split(/[,|\s]+/).filter(Boolean);
  const removedSourceDigits = type === 'ank' && selectedSourceDigits.length > 0 && selectedSourceDigits.every(digit => /^\d$/.test(digit))
    ? (getScrapeSource(d)?.digits.split(', ') || []).flatMap((digit, position) => selectedSourceDigits.includes(digit) ? [] : [{ digit, index: position + 1 }])
    : [];
  const removedIndicesBadge = removedSourceDigits.length > 0 && (
    <div data-removed-source-indices className="mt-0.5 flex flex-wrap items-center gap-x-1 gap-y-0 text-[8px] leading-[11px] text-[#E5A58A]"
      title="Original 10-digit source mein jo digits selected box mein nahi hain, unke source index">
      <span>Removed:</span>
      {removedSourceDigits.map(({ digit, index }) => <span key={index} className="whitespace-nowrap">{digit}<sup className="ml-0.5 text-[6px]">#{index}</sup></span>)}
    </div>
  );
  const pngSupportMap = React.useMemo(
    () => cardDigitSupport(currentProf, currentDate, type, market.n, d.sentDigits || visibleDigits, profiles['admin1']),
    [currentProf, currentDate, type, market.n, d.sentDigits, visibleDigits, profiles['admin1']],
  );
  const effectiveSplitCfg = currentDate < titanLocalDateISO()
    ? currentProf?.dayRecords?.[currentDate]?.recoveryConfigSnapshot || cfg
    : cfg;
  const isSmartStakeOn = Boolean(
    effectiveSplitCfg && useTwoCardRecovery(effectiveSplitCfg, currentDate, type)
  );


  const isOpenPassCloseZeroActive = Boolean(
    (effectiveSplitCfg?.openPassCloseZero || currentProf?.openPassCloseZero || currentProf?.config?.openPassCloseZero) &&
    (type === 'ank' || type === 'pannel') &&
    /\s+CLOSE$/i.test(market.n)
  );
  const isOpenPassForThisClose = React.useMemo(() => {
    if (!isOpenPassCloseZeroActive) return false;
    const baseName = market.n.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();
    const openName = `${baseName} OPEN`;
    const dayStore = type === 'ank' ? currentProf?.dayRecords?.[currentDate]?.data : currentProf?.dayRecords?.[currentDate]?.pannelData;
    if (!dayStore) return false;
    const openMarkets = getEffectiveMarkets(cfg);
    const openIdx = openMarkets.findIndex(m => m.n.trim().toUpperCase() === openName);
    const openCard = (openIdx >= 0 ? dayStore[openIdx] : undefined) || Object.values(dayStore).find(r => String(r?.marketName || '').trim().toUpperCase() === openName);
    return openCard?.s === 'PASS';
  }, [isOpenPassCloseZeroActive, market.n, currentProf?.dayRecords, currentDate, type, cfg]);

  const sameMarketRecoveryState = React.useMemo(
    () => getCardSameMarketRecoveryState(currentProf, currentDate, type, index, market.n),
    [currentProf, currentDate, type, index, market.n]
  );
  const effectivePrevLoss = sameMarketRecoveryState.debt;
  const baseTargetProfit = dayLoopConfig(currentProf, currentDate)
    ? profileLoopTarget(currentProf, currentDate, type, market.n, d)
    : Number(effectiveSplitCfg?.[type]?.tgt || cfg?.[type]?.tgt || 100);
  const isProfitCarryOn = Boolean(effectiveSplitCfg?.profitCarry || currentProf?.profitCarry || currentProf?.config?.profitCarry);
  const carriedProfit = isProfitCarryOn ? (sameMarketRecoveryState.pendingProfit || 0) : 0;
  const effectiveTargetProfit = baseTargetProfit + carriedProfit;
  const effectiveTargetWithLoss = effectivePrevLoss + effectiveTargetProfit;
  const isGenuineManualRate = Boolean(d.manualRate && !d.manualStatus && Number(d.r) > 0);
  const effectiveRecRate = React.useMemo(
    () => {
      if (isOpenPassForThisClose && !isGenuineManualRate) return '0';
      return calculateRecoveryRate(type, d.sentAt ? (d.sentDigits || visibleDigits) : visibleDigits, effectivePrevLoss, effectiveTargetProfit);
    },
    [type, d.sentAt, d.sentDigits, visibleDigits, effectivePrevLoss, effectiveTargetProfit, isOpenPassForThisClose, isGenuineManualRate]
  );
  const isCardRateFrozen = Boolean(
    d.sentAt ||
    d.dispatchState === 'SENT' ||
    d.dispatchState === 'SETTLED' ||
    d.s === 'PASS' ||
    d.s === 'FAIL' ||
    d.s === 'SKIP'
  );
  const isSkippedStatus = d.s === 'SKIP' || (isOpenPassForThisClose && !d.sentAt && !isGenuineManualRate);
  const displayRate = isSkippedStatus
    ? '0'
    : isCardRateFrozen
    ? (d.sentRate || d.r || effectiveRecRate || '')
    : (isGenuineManualRate ? (d.r || '') : (effectiveRecRate || d.r || ''));
  const liveSmartStaking = React.useMemo(() => {
    if (isSkippedStatus) return undefined;
    if (isCardRateFrozen) {
      return d.smartStaking?.isSmartStaking ? d.smartStaking : undefined;
    }
    if (!isSmartStakeOn || (type !== 'ank' && type !== 'pannel') || isGenuineManualRate) return undefined;
    const strongFromMap = pngSupportMap
      ? Object.entries(pngSupportMap).filter(([, role]) => role === 'Strong').map(([t]) => t)
      : d.smartSelection?.strongDigits;
    const supportFromMap = pngSupportMap
      ? Object.entries(pngSupportMap).filter(([, role]) => role !== 'Strong').map(([t]) => t)
      : d.smartSelection?.supportDigits;
    const computed = calculateSmartStakingRates(type, d.sentAt ? (d.sentDigits || visibleDigits) : visibleDigits, effectivePrevLoss, effectiveTargetProfit, strongFromMap, supportFromMap);
    return computed.isSmartStaking ? computed : undefined;
  }, [isSkippedStatus, isCardRateFrozen, d.smartStaking, isOpenPassForThisClose, isSmartStakeOn, type, isGenuineManualRate, effectivePrevLoss, effectiveTargetProfit, d.sentAt, d.sentDigits, d.smartSelection, visibleDigits, pngSupportMap]);
  const pngSupportBadge = pngSupportMap && Object.keys(pngSupportMap).length > 0 ? (
    <div data-png-digit-support className="mt-0.5 flex flex-wrap items-center gap-1 text-[8px] leading-[12px]"
      title="PNG card green highlight: Strong (#00884f dark green) & Support (#79ce9d / #cdedd9 green)">
      {Object.entries(pngSupportMap).map(([token, role]) => (
        <span
          key={token}
          className={`px-1.5 py-0.5 rounded-full font-black whitespace-nowrap ${
            role === 'Strong'
              ? 'bg-[#00884f] text-white'
              : role === 'Support'
                ? 'bg-[#79ce9d] text-[#073b20]'
                : 'bg-[#cdedd9] text-[#073b20]'
          }`}
        >
          {role === 'Strong' ? 'Strong' : 'Support'}: {token}
        </span>
      ))}
    </div>
  ) : null;
  const isNight = isNightMarket(market.n, market.hr);
  const isOpen = market.n.includes('OPEN');
  const isJodi = type === 'jodi';

  // One compact next-day guidance chip. Source mode is recorded at selection
  // time; legacy cards honestly show OLD because their source was never stored.
  const previousDictName = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
  const historyProfile = profiles['admin1'];
  const adminMarkets = React.useMemo(() => type === 'jodi' ? getEffectiveBaseMarkets(historyProfile?.config) : getEffectiveMarkets(historyProfile?.config), [type, historyProfile?.config]);
  const adminHistoryIndex = findMarketIndexByName(adminMarkets, market.n);
  const latestHistory = React.useMemo(() => findLatestSettledMarketRecord(
    historyProfile?.dayRecords, currentDate, previousDictName,
    adminHistoryIndex >= 0 ? adminHistoryIndex : index, market.n,
  ), [historyProfile?.dayRecords, currentDate, previousDictName, adminHistoryIndex, index, market.n]);
  const previousDate = latestHistory?.date || '';
  const previousRecord = latestHistory?.record;
  const hasPreviousResult = previousRecord?.s === 'PASS' || previousRecord?.s === 'FAIL';
  const previousSourceMode = String(previousRecord?.sentSourceMode || previousRecord?.sourceMode || 'OLD').replace('_', ' ');
  const previousPriorIndices = React.useMemo(() => type === 'ank' && previousDate ? recentUniqueSourceIndices(
    historyProfile?.dayRecords || {}, previousDate,
    adminHistoryIndex >= 0 ? adminHistoryIndex : index, market.n, 6, sourceIndexHistory,
  ) : [], [type, previousDate, historyProfile?.dayRecords, adminHistoryIndex, index, market.n, sourceIndexHistory]);
  const previousFilter = React.useMemo(
    () => getRecordFilterLabel(previousRecord, previousPriorIndices),
    [previousRecord, previousPriorIndices],
  );
  const todayFilter = React.useMemo(
    () => getNextDayFilterRecommendation(previousRecord, previousFilter),
    [previousRecord, previousFilter],
  );
  const previousCell = React.useMemo(
    () => type === 'ank' && previousRecord ? resolveSourceIndexCell(previousRecord, sourceIndexHistory?.[previousDate]?.[market.n.toUpperCase()]) : undefined,
    [type, previousRecord, sourceIndexHistory, previousDate, market.n],
  );
  const previousPos = previousCell?.index;
  const previousPosFallback = React.useMemo(() => {
    if (!hasPreviousResult || previousFilter || type !== 'ank' || !previousPos) return '';
    const ydayCut = previousPos <= 4 ? 'Lcut' : previousPos >= 7 ? 'Fcut' : 'Fcut/Lcut';
    const ydayTrick = previousPos % 2 === 1 ? 'T1' : 'T2';
    const nextCut = previousPos <= 4 ? 'Fcut' : previousPos >= 7 ? 'Lcut' : 'Center';
    const nextTrick = previousPos % 2 === 1 ? 'T2' : 'T1';
    const nextIdx = previousPriorIndices.length >= 4
      ? (previousPriorIndices.slice(0, 4).includes(previousPos) ? 'Remove4' : !previousPriorIndices.slice(0, 6).includes(previousPos) ? 'Keep6' : '')
      : '';
    return `YDAY #${previousPos} (${ydayCut}/${ydayTrick}) → TODAY ${nextCut} · ${nextTrick}${nextIdx ? ` · ${nextIdx}` : ''}`;
  }, [hasPreviousResult, previousFilter, type, previousPos, previousPriorIndices]);
  const previousLogic = previousFilter || '';
  const previousSummary = hasPreviousResult && previousLogic
    ? `YDAY ${previousLogic} · ${previousRecord?.s}${todayFilter ? ` → TODAY ${todayFilter}` : ''}`
    : previousPosFallback;
  const yesterdayBadge = previousSummary ? (
    <span
      className={`text-[7px] px-1.5 py-0.5 rounded-md border font-black uppercase whitespace-nowrap ${previousRecord?.s === 'PASS' ? 'text-[#00C26F] bg-[rgba(0,194,111,0.08)] border-[rgba(0,194,111,0.2)]' : 'text-[#FF8A8A] bg-[rgba(255,93,93,0.08)] border-[rgba(255,93,93,0.2)]'}`}
      title={`${previousDate}: ${previousLogic || previousSourceMode}${previousPos ? ` (#${previousPos})` : ''}, ${previousRecord?.s}${todayFilter ? ` → Today: ${todayFilter}` : ''}`}
    >
      ↶ {previousSummary}
    </span>
  ) : null;

  const loopId = currentProf ? assignedLoop(dayLoopConfig(currentProf,currentDate),type,market.n,d) : undefined;
  const waveId = !loopId ? sameMarketRecoveryState.waveId : undefined;
  const loopBadge = loopId ? (
    <span data-loop-badge={loopId} className={`text-[9px] font-black px-1.5 py-0.5 rounded border ${loopId==='L1'?'text-[#2AABEE] border-[#2AABEE]/30':loopId==='L2'?'text-[#B85CFF] border-[#B85CFF]/30':loopId==='L3'?'text-[#FAC748] border-[#FAC748]/30':'text-[#20E093] border-[#20E093]/30'}`}>{loopId}</span>
  ) : waveId ? (
    <span data-wave-badge={waveId} title={`4-Wave Auto-Relay (${waveId})`} className={`text-[9px] font-black px-1.5 py-0.5 rounded border ${waveId==='W1'?'text-[#2AABEE] border-[#2AABEE]/30':waveId==='W2'?'text-[#B85CFF] border-[#B85CFF]/30':waveId==='W3'?'text-[#FAC748] border-[#FAC748]/30':'text-[#20E093] border-[#20E093]/30'}`}>{waveId}</span>
  ) : null;
  const currentSourceMode = getScrapeSource(d)?.mode || d.sentSourceMode || d.sourceMode;
  const flowWinLogics = Array.isArray(d?.masterFlow?.winningLogics) ? d.masterFlow.winningLogics.filter(Boolean) : [];
  const flowWinSummary = flowWinLogics.length > 0 ? `4-Ank Brain · ${flowWinLogics.slice(0, 2).join(' + ')}` : '4-Ank Dynamic Brain · 16-Logic Consensus';
  const scrapingLabel = currentSourceMode === 'SP_SKIP30' ? 'Recent 30 SP skip · 6×5' : currentSourceMode === 'AUTO' ? 'AUTO · Recent → Old'
    : currentSourceMode === 'FLOW_3_1' ? flowWinSummary : currentSourceMode === 'WEEKDAY' ? 'DAY · Bottom → Top'
    : currentSourceMode === 'DAY_COMBO' ? 'DAY COMBO · CLOSE → OPEN · Bottom → Top'
    : currentSourceMode === 'MSSD' ? (d.mssdState?.stage === 1 ? 'MSSD 1/4 · Auto SSD' : d.mssdState?.stage === 2 ? 'MSSD 2/4 · Auto + Day SSD' : d.mssdState?.stage === 3 ? 'MSSD 3/4 · + Combo SSD' : d.mssdState?.stage === 4 ? 'MSSD 4/4 · + DayCombo SSD' : 'MSSD · Mix Strong Support')
    : currentSourceMode === 'FREQ_10' ? '10-DRAW FREQ · Skip Recent 1'
    : currentSourceMode === 'FREQ_10_COMBO' ? `${sourceIndexWeekLength(market.n)}-DAY O+C FREQ · Skip Recent 1`
    : currentSourceMode === 'SELF_LEARNING' ? (d.selfLearning?.strategy ? `${d.selfLearning.strategy} · ${d.selfLearning.confidence}%` : 'SELF LEARNING · Rule Extracted')
    : currentSourceMode ? String(currentSourceMode).replaceAll('_', ' ') : 'Source unavailable';
  const selfLearningProofBadge = d.selfLearning ? (
    <div data-self-learning-proof className="mt-1 text-[9px] font-mono tabular-nums leading-snug text-cyan-300/95">
      {d.selfLearning.analysisState === 'SCANNING' ? (
        <span className="text-amber-300 animate-pulse">🔍 Running Per-Market 12-Trick Tournament &amp; 2-Fail Mood Check…</span>
      ) : (
        <>
          <span className="font-bold text-cyan-200">{d.selfLearning.strategy}</span>
          <span> · {d.selfLearning.confidence}%</span>
          {d.selfLearning.zigzagAnalysis?.marketMoodTournament && (
            <span
              className={
                d.selfLearning.zigzagAnalysis.marketMoodTournament.moodState === 'TWO_FAIL_MOOD_SHIFT'
                  ? 'text-amber-300 font-bold'
                  : d.selfLearning.zigzagAnalysis.marketMoodTournament.moodState === 'ONE_FAIL_HOLD'
                  ? 'text-cyan-300 font-bold'
                  : 'text-emerald-300 font-bold'
              }
            >
              {' · '}
              {d.selfLearning.zigzagAnalysis.marketMoodTournament.moodState === 'TWO_FAIL_MOOD_SHIFT'
                ? `🔄 2-FAIL MOOD SHIFT (${d.selfLearning.zigzagAnalysis.marketMoodTournament.previousFailedTrickName || 'Prior'} → ${d.selfLearning.zigzagAnalysis.marketMoodTournament.activeTrickName})`
                : d.selfLearning.zigzagAnalysis.marketMoodTournament.moodState === 'ONE_FAIL_HOLD'
                ? `🛡️ 1-FAIL HOLD (${d.selfLearning.zigzagAnalysis.marketMoodTournament.activeTrickName} + Hedge)`
                : `👑 LOCKED LINE (${d.selfLearning.zigzagAnalysis.marketMoodTournament.activeTrickName} · ${d.selfLearning.zigzagAnalysis.marketMoodTournament.winCount}/${d.selfLearning.zigzagAnalysis.marketMoodTournament.evalDraws} Pass)`}
            </span>
          )}
          {d.selfLearning.zigzagAnalysis?.dayTwinLink && (
            <span className="text-purple-300 font-bold">
              {' · '}🔗 DAY-TWIN [{d.selfLearning.zigzagAnalysis.dayTwinLink.twinMarket} {d.selfLearning.zigzagAnalysis.dayTwinLink.twinJodi} → {d.selfLearning.zigzagAnalysis.dayTwinLink.twinTargetAnk}]
            </span>
          )}
          {d.selfLearning.zigzagAnalysis?.calendarShield && (
            <span className="text-amber-300 font-bold">
              {' · '}{d.selfLearning.zigzagAnalysis.calendarShield.shieldLabel} (10-X:{d.selfLearning.zigzagAnalysis.calendarShield.reverseComplementAnk})
            </span>
          )}
          {d.selfLearning.zigzagAnalysis?.slotBreakdown && (
            <span className="text-indigo-200 font-semibold">
              {' · '}
              Anks[{d.selfLearning.zigzagAnalysis.slotBreakdown.repeatAnk}, {d.selfLearning.zigzagAnalysis.slotBreakdown.cutAnk}, {d.selfLearning.zigzagAnalysis.slotBreakdown.zigzagAnk}, {d.selfLearning.zigzagAnalysis.slotBreakdown.counterAnk}]
              {d.selfLearning.zigzagAnalysis.marketMoodTournament?.leaderboardSummary
                ? ` · Top3: ${d.selfLearning.zigzagAnalysis.marketMoodTournament.leaderboardSummary}`
                : ''}
            </span>
          )}
          {d.selfLearning.ruleProof && !d.selfLearning.zigzagAnalysis && (
            <span className="text-slate-300"> · {d.selfLearning.ruleProof}</span>
          )}
          {d.selfLearning.selfDecisionAction && (
            <span
              className={`block mt-0.5 ${
                d.selfLearning.lastOutcome === 'FAIL' ||
                d.selfLearning.zigzagAnalysis?.regimeStatus === 'DRAWDOWN_RECOVERY_LOCK' ||
                Boolean(d.selfLearning.zigzagAnalysis?.calendarShield)
                  ? 'text-amber-300'
                  : 'text-emerald-300/90'
              }`}
              title={d.selfLearning.mistakeLesson || d.selfLearning.selfDecisionAction}
            >
              {d.selfLearning.selfDecisionAction}
              {d.selfLearning.mistakeLesson ? ` · (${d.selfLearning.mistakeLesson})` : ''}
            </span>
          )}
        </>
      )}
    </div>
  ) : null;
  const smartDecision=smartIndicator(d,currentDate);
  const smartBadge=smartDecision?<span data-smart-decision={smartDecision.decision} title={`Smart: ${smartDecision.decision==='REVERSE'?'Cut / Mirror Line':'Direct Line'} + ${smartDecision.recommendedFilter||'multi-line'} · ${smartDecision.samples} comparisons · Direct ${smartDecision.topHits} / Cut ${smartDecision.reverseHits}${smartDecision.strongDigits?.length?` · Strong: ${smartDecision.strongDigits.join(', ')}`:''}${smartDecision.supportDigits?.length?` · Support: ${smartDecision.supportDigits.join(', ')}`:''}${smartDecision.filtered?' · further filtered':''}`} className={`text-[10px] font-black px-2 py-0.5 rounded-md border shrink-0 whitespace-nowrap ${smartDecision.decision==='REVERSE'?'bg-violet-100 text-violet-950 border-violet-300':'bg-sky-100 text-sky-950 border-sky-300'}`}>{smartDecision.label.replace(/^RSMART\b/, 'SMART')}{smartDecision.decision==='REVERSE'?' (Cut)':''}{smartDecision.recommendedFilter?` · ${smartDecision.recommendedFilter}`:''}{smartDecision.filtered?' · CUT':''}</span>:null;
  const probRecommendation = React.useMemo(() => {
    if (type !== 'ank' || !d.d) return null;
    const list = d.d.split(/[,|\s]+/).filter(Boolean);
    if (list.length <= 4) return null;
    return scoreDigitProbabilities(d.d, [], 5);
  }, [type, d.d]);
  const probBadge = probRecommendation ? (
    <button
      type="button"
      disabled={isScraping || disabled || Boolean(d.sentRate || d.sentDigits || d.dispatchState === 'QUEUED' || d.dispatchState === 'SENT')}
      onClick={() => {
        if (onTrendBreak) {
          void runCardAction('trend_break', () => onTrendBreak(type, index, market.n));
        } else if (onSmartAutoDigits) {
          void runCardAction('smart', () => onSmartAutoDigits(type, index, market.n));
        }
      }}
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-black bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-amber-500/20 text-amber-300 border border-amber-500/40 hover:border-amber-400 hover:bg-amber-500/30 transition-all shadow-sm cursor-pointer shrink-0 active:scale-95"
      title={`${probRecommendation.reason}. Click to auto-filter to top ${probRecommendation.rankedDigits.length} high-probability digits.`}
    >
      <Zap className="w-2.5 h-2.5 text-amber-400 animate-pulse" />
      <span>{probRecommendation.badgeLabel}</span>
    </button>
  ) : null;
  const currentSourceBadge = <span className="text-[8px] font-bold text-[#8DC8FF]" title={`${currentDate}: ${scrapingLabel}`}>{currentDate} · {scrapingLabel}{d.marketModel ? ` · ${d.marketModel.decision} · ${d.marketModel.windows.join('/')}${d.marketModel.patternShift ? ' · SHIFT' : ''}` : ''}</span>;

  // Three rows of market-specific operating-day slots; other days remain saved for strategy logic.
  // Manual results use the explicitly selected digit for the original index.
  const sourceWeekLength = sourceIndexWeekLength(market.n);
  const sourceStripLabel = sourceIndexStripLabel(market.n);
  // The saved RECENT6/RECENT4 flag is an actual application (History or quick action).
  // The historical winner is only a suggestion until a selection is committed.
  const currentPriorIndices = React.useMemo(() => type === 'ank' ? recentUniqueSourceIndices(
    currentProf?.dayRecords || {}, currentDate, index, market.n, 6, sourceIndexHistory,
  ) : [], [type, currentProf?.dayRecords, currentDate, index, market.n, sourceIndexHistory]);
  const currentFilterLabel = React.useMemo(
    () => getRecordFilterLabel(d, currentPriorIndices),
    [d, currentPriorIndices],
  );
  const appliedIndexMethod = sourceIndexAppliedMethod(d.positionRule) || currentFilterLabel || undefined;
  const suggestedIndexMethod = !appliedIndexMethod ? (todayFilter || sourceIndexHistorySuggestion(undefined)) : undefined;
  const indexMethodDisplay = appliedIndexMethod
    ? { text: `Applied · ${appliedIndexMethod}`, title: `Saved card selection: ${appliedIndexMethod}.`, state: 'applied' }
    : suggestedIndexMethod
      ? { text: `Today · ${suggestedIndexMethod}`, title: `Recommended today from yesterday's settled filter (${previousDate}: ${previousFilter || 'index'} ${previousRecord?.s || ''}).`, state: 'suggested' }
      : undefined;
  const sourcePositionHeading = <div className="ledger-position-heading">
    <span title="A Auto · D Day · DC Day Combo · C Combo · S Smart · M Market Model · C6 Carry6 · PF Pair Follow · PC Pair Combo · MS MSSD · DF Digit Follow · K Markov · I AI Scan">{sourceStripLabel}</span>
    {indexMethodDisplay && <span data-source-index-method={indexMethodDisplay.state} className={`ledger-index-method ledger-index-method-${indexMethodDisplay.state}`} title={indexMethodDisplay.title}>{indexMethodDisplay.text}</span>}
  </div>;
  const sourcePages = React.useMemo(() => type === 'ank' && showSourceHistory ? sourceIndexDisplayPages(currentDate, [
    ...Object.keys(currentProf?.dayRecords || {}),
    ...(isVipProfile ? [...Object.keys(historyProfile?.dayRecords || {}), ...Object.keys(sourceIndexHistory || {})] : []),
  ], market.n) : [], [type, showSourceHistory, currentDate, market.n, currentProf?.dayRecords, isVipProfile, historyProfile?.dayRecords, sourceIndexHistory]);
  const sourcePagesRef=useRef(sourcePages.length);sourcePagesRef.current=sourcePages.length;
  const sourceStart=Math.min(sourceViewport.start,Math.max(0,sourcePages.length-3));
  const sourceEnd=Math.min(sourcePages.length,Math.max(sourceStart+3,sourceViewport.end));
  const sourceScrollThrottle=React.useMemo(()=>createScrollThrottle(el=>{
    const next=sourceIndexViewport(el.scrollTop,el.clientHeight,sourcePagesRef.current);
    setSourceViewport(previous=>previous.start===next.start&&previous.end===next.end?previous:next);
  }),[]);
  React.useEffect(()=>{sourceScrollThrottle.cancel();return()=>sourceScrollThrottle.cancel();},[sourceScrollThrottle,currentDate,market.n,activeId]);
  const positionStrip = type === 'ank' ? (
    <div key={JSON.stringify([currentDate, market.n, activeId, currentProf?.name])} className="ledger-source-scroll" style={{'--source-index-columns': sourceWeekLength} as React.CSSProperties} tabIndex={0} aria-label={`Recent ${sourceWeekLength * 3} market days of original ten-digit source indices`} title="Scroll up for older indices; down for recent indices" onScroll={event => sourceScrollThrottle.schedule(event.currentTarget)}>
      {sourceStart>0&&<div aria-hidden="true" className="ledger-source-spacer" style={{flexBasis:`calc(var(--source-page-height) * ${sourceStart})`}}/>}
      {sourcePages.slice(sourceStart, sourceEnd).map((dates, page) => <div key={dates[0]} className="ledger-source-indices" data-source-index-page={sourceStart+page}>
      {dates.map(date => {
        const rec = date === currentDate ? d : findHistoricalMarketRecord(currentProf?.dayRecords?.[date]?.data, index, market.n);
        const adminRec = findHistoricalMarketRecord(historyProfile?.dayRecords?.[date]?.data, adminHistoryIndex >= 0 ? adminHistoryIndex : index, market.n);
        const localCell = sourceIndexCell(rec);
        const adminCell = sourceIndexCell(adminRec);
        const shared = adminCell || sourceIndexHistory?.[date]?.[market.n.toUpperCase()];
        const cell = resolveSourceIndexCell(rec, isVipProfile ? shared : undefined);
        // Only show historical K6/R4 when the actual displayed result index has
        // a matching saved strategy flag. Display-only shared indices have none.
        const indexedRec = localCell?.index !== undefined ? rec : isVipProfile && adminCell?.index !== undefined ? adminRec : undefined;
        const savedMethod = cell?.index !== undefined ? (sourceIndexAppliedMethod(indexedRec?.positionRule) || getRecordFilterLabel(indexedRec) || undefined) : undefined;
        const compactMethod = savedMethod === 'Keep 6' ? 'K6' : savedMethod === 'Remove 4' ? 'R4' : cell?.index !== undefined ? getCompactFilterBadge(indexedRec) : undefined;
        const mark = cell?.index;
        const mode = cell?.mode;
        const sourceName = mode === 'AUTO' ? 'AUTO · Recent → Old' : mode === 'WEEKDAY' ? 'DAY · Bottom → Top' : mode === 'DAY_COMBO' ? 'DAY COMBO · CLOSE → OPEN · Bottom → Top' : mode === 'RESULT_CARRY6' ? 'CARRY 10 · Recent → Old' : mode === 'SELF_LEARNING' ? 'AI SELF-LEARNING · Real 10-Digit Source' : mode ? String(mode).replaceAll('_', ' ') : 'Source unavailable';
        const prefix = ({ AUTO: 'A', WEEKDAY: 'D', COMBO: 'C', DAY_COMBO: 'DC', SMART: 'S', MARKET_MODEL: 'M', CARRY6: 'C6', PAIR_FOLLOW: 'PF', PAIR_COMBO: 'PC', MSSD: 'MS', DIGIT_FOLLOW: 'DF', PANNA_FOLLOW: 'PNF', FREQ_10: 'F10', FREQ_10_COMBO: 'FC10', FLOW_3_1: '4A', RESULT_CARRY6: 'R', RESULT_CUT5: 'C5', SELF_LEARNING: 'AI', MARKOV: 'K', AI_SCAN: 'I', SP_SKIP30: 'R30', SP_RARE: 'R', ANK_SUM: 'Σ', MANUAL: '' } as Record<string, string>)[mode || 'MANUAL'] ?? 'AI';
        const label = `${prefix}${mark ?? '–'}`;
        return <span key={date} data-source-index-date={date} data-source-index-applied={compactMethod} title={`${date}: ${sourceName} · original index ${mark ?? 'unknown'} · ${cell?.status || 'WAIT'}${savedMethod ? ` · Applied ${savedMethod}` : ''}`} className={`ledger-source-index min-w-0 rounded-md border flex flex-col items-center justify-center font-black ${mark === undefined ? 'bg-[#17212B] text-[#6C7D93] border-white/10' : cell?.status === 'SKIP' ? 'bg-[#2AABEE]/10 text-[#8DC8FF] border-[#2AABEE]/30' : cell?.status === 'FAIL' ? 'bg-[#FF5D5D]/10 text-[#FF7777] border-[#FF5D5D]/30' : 'bg-[#00C26F]/12 text-[#20E093] border-[#00C26F]/35'}`}>
          <span className="text-[6px] leading-2 opacity-70">{date.slice(8)}/{date.slice(5, 7)}</span>
          <span className={`${mode === 'DAY_COMBO' ? 'text-[8px]' : 'text-[10px]'} leading-3`}>{label}{compactMethod && <small className="ledger-index-method-mini">{compactMethod}</small>}</span>
        </span>;
      })}
      </div>)}
      {sourcePages.length>sourceEnd&&<div aria-hidden="true" className="ledger-source-spacer" style={{flexBasis:`calc(var(--source-page-height) * ${sourcePages.length-sourceEnd})`}}/>}
    </div>
  ) : null;

  // Accent & theme configuration
  const accentColor = isJodi ? '#B85CFF' : isOpen ? '#2AABEE' : '#FAC748';

  // Format timing string if available
  const timingFormatted = market.hr !== undefined && market.min !== undefined
    ? `${String(market.hr).padStart(2, '0')}:${String(market.min).padStart(2, '0')}`
    : null;

  if (disabled) {
    return (
      <div ref={cardRoot} className="ledger-card ledger-card-disabled rounded-xl border border-red-500/25 bg-[#1A2029] p-3 opacity-70">
        <div className="flex items-center justify-between gap-2">
          <div><div className="text-xs font-black text-white">{market.n}</div><div className="text-[9px] text-[#FF5D5D] font-black mt-1">🔴 MARKET OFF · CARD COMPLETELY DISABLED</div></div>
          <div className="text-[10px] text-[#7A9CB8]">{timingFormatted || ''}{isMaster && <button type="button" onClick={() => onResetCard(type, index)} title="Clear card" className="p-2 text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>}</div>
        </div>
      </div>
    );
  }

  // Calculate 7-Day Trick History Badges
  const getTrickHistoryBadges = () => {
    if (type === 'jodi') return null;
    const dictName = type === 'ank' ? 'data' : 'pannelData';
    const historyProfile = profiles[activeId] || profiles['admin1'];
    if (!historyProfile || !historyProfile.dayRecords) return null;

    const currObj = new Date(currentDate);
    const dayOfWeek = currObj.getDay();
    const diff = currObj.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1);
    const monday = new Date(currObj);
    monday.setDate(diff);

    const badges = [];
    for (let j = 0; j < 7; j++) {
      const pastDate = new Date(monday);
      pastDate.setDate(monday.getDate() + j);
      const dateStr = titanLocalDateISO(pastDate, false);
      const dayName = pastDate.toLocaleDateString('en-US', { weekday: 'short' }).toUpperCase();

      let trickLabel = '-';
      let badgeStyle = 'bg-[#F1F5F9] text-[#475569] border-[#CBD5E1]';

      const historyRecords = historyProfile.dayRecords[dateStr]?.[dictName];
      const rec = findHistoricalMarketRecord(historyRecords, index, market.n);
      const historicalTrick = getRecordFilterLabel(rec);
      if (historicalTrick) {
        trickLabel = historicalTrick;
        if (trickLabel === 'T1') badgeStyle = 'bg-[rgba(123,143,255,0.18)] text-[#4338CA] border-[rgba(123,143,255,0.35)] font-bold';
        else if (trickLabel === 'T2') badgeStyle = 'bg-[rgba(250,199,72,0.18)] text-[#854D0E] border-[rgba(250,199,72,0.35)] font-bold';
        else if (trickLabel === 'T3') badgeStyle = 'bg-[rgba(0,194,111,0.18)] text-[#166534] border-[rgba(0,194,111,0.35)] font-bold';
        else if (trickLabel === 'Fcut' || trickLabel === 'Lcut') badgeStyle = 'bg-teal-500/18 text-teal-900 border-teal-500/35 font-bold';
        else if (trickLabel === 'Keep6') badgeStyle = 'bg-sky-500/18 text-sky-900 border-sky-500/35 font-bold';
        else if (trickLabel === 'Remove4') badgeStyle = 'bg-rose-500/18 text-rose-900 border-rose-500/35 font-bold';
        else badgeStyle = 'bg-violet-500/18 text-violet-900 border-violet-500/35 font-bold';
      }

      badges.push(
        <div key={dateStr} className="flex flex-col items-center shrink-0">
          <span className="text-[7px] text-[#475569] font-semibold mb-0.5">{dayName}</span>
          <span className={`text-[8px] px-1.5 py-0.5 rounded-md border ${badgeStyle}`}>
            {trickLabel}
          </span>
        </div>
      );
    }

    return (
      <div className="flex gap-1.5 pt-2 border-t border-[rgba(255,255,255,0.06)] items-center overflow-x-auto no-scrollbar">
        <span className="text-[8px] font-bold text-[#475569] uppercase shrink-0 tracking-wider">7-DAY RECAP:</span>
        {badges}
      </div>
    );
  };

  const handleTrick = (trickNum: 1 | 2 | 3) => {
    // Reapplying a trick must always use the untouched source. Otherwise
    // T1 → T2 → T3 compounds transformations and produces the wrong pipeline.
    const raw = d.od || (type==='ank'?getScrapeSource(d)?.digits:undefined) || visibleDigits || '';
    const res = applyTrickFormula(raw, trickNum);
    if (!res) {
      if (trickNum === 3 && isStrongWeekSource(raw)) {
        alert('T3 strong week ko skip karta hai — is week par T3 apply nahi hoga.');
      } else {
        alert('T' + trickNum + ' ke required positions source mein available nahi hain.');
      }
      return;
    }
    onApplyTrick(type, index, res.formatted, res.trick);
  };

  const isBacktestCard = Boolean(d.backtestResult && !d.manualStatus && currentDate < titanLocalDateISO());
  const isLocked = d.s !== 'WAIT' && !isBacktestCard && !isEditableSourceSkip(d);
  const isDeliveryFrozen = Boolean(
    d.sentRate || d.sentDigits || d.dispatchState === 'QUEUED' || String(d.dispatchState) === 'SENDING' || d.dispatchState === 'SENT' || d.dispatchState === 'SETTLED'
  );

  // Presentation only: delivery guards and stored status stay unchanged.
  const isVisuallyFrozen=d.s==='WAIT'&&Boolean(isDeliveryFrozen||d.dispatchState==='QUEUED'||d.deliveryRestoredAt);
  const displayedStatus=isVisuallyFrozen?(d.dispatchState==='QUEUED'?'QUEUED':'FROZEN'):d.s;

  // Status Styling
  let statusBadgeClass = 'text-[#7A9CB8] bg-[rgba(122,156,184,0.1)] border-[rgba(122,156,184,0.2)]';
  let statusIcon = <Clock className="w-3 h-3 text-[#7A9CB8]" />;
  let cardBorderLeft = `border-l-4 border-l-[${accentColor}]`;

  if (d.s === 'PASS') {
    statusBadgeClass = 'text-[#00C26F] bg-[rgba(0,194,111,0.12)] border-[rgba(0,194,111,0.3)] font-black';
    statusIcon = <CheckCircle className="w-3 h-3 text-[#00C26F]" />;
    cardBorderLeft = 'border-l-4 border-l-[#00C26F]';
  } else if (d.s === 'FAIL') {
    statusBadgeClass = 'text-[#FF5D5D] bg-[rgba(255,93,93,0.12)] border-[rgba(255,93,93,0.3)] font-black';
    statusIcon = <XCircle className="w-3 h-3 text-[#FF5D5D]" />;
    cardBorderLeft = 'border-l-4 border-l-[#FF5D5D]';
  } else if (d.s === 'SKIP') {
    statusBadgeClass = 'text-[#7A9CB8] bg-[rgba(122,156,184,0.12)] border-[rgba(122,156,184,0.25)] font-bold';
    statusIcon = <Forward className="w-3 h-3 text-[#7A9CB8]" />;
    cardBorderLeft = 'border-l-4 border-l-[#7A9CB8]';
  } else if(isVisuallyFrozen){
    statusIcon=<LockKeyhole className="w-3 h-3 text-[#8DC8FF]"/>;
  }

  // Count items
  const hasDigitInput = Boolean(visibleDigits.trim());
  const invalidTokenCard = hasDigitInput && !areSettlementTokensValid(type, visibleDigits);
  const digitCount = countSettlementTokens(visibleDigits, type);
  const invalidTargetCard = !invalidTokenCard && digitCount > 0 && !isRecoveryRatePossible(type, visibleDigits);

  const testResultButton = isMaster && onTestResult && <button type="button"
    aria-label={`${market.n} Test Result`} aria-busy={testingResult}
    disabled={isScraping || disabled || currentDate>=titanLocalDateISO() || !canAutoEvaluateBacktest(d,type) || String(d.dispatchState)==='SENDING'}
    title="Test this card on the selected past date; delivered, queued, skipped and manual-settled cards stay protected"
    onClick={()=>void runCardAction('test',()=>onTestResult(type,index))}
    className="bg-[#2AABEE]/15 text-[#8DC8FF] px-2 py-2 rounded-xl text-[10px] font-bold disabled:opacity-40 disabled:cursor-not-allowed">
    {testingResult?'Testing…':'Test Result'}
  </button>;

  // -------------------------------------------------------------
  // LOCKED CARD VIEW (Compact, Clean Result Summary)
  // -------------------------------------------------------------
  if (isLocked) {
    return (
      <div ref={cardRoot} data-status={d.s} data-frozen={isVisuallyFrozen||undefined}
        style={{ '--ledger-accent': accentColor } as React.CSSProperties}
        className={`ledger-card ledger-card-settled bg-[#1E293B]/90 backdrop-blur border border-[rgba(255,255,255,0.08)] rounded-2xl p-3 mb-2.5 shadow-md ${cardBorderLeft} transition-all`}>
        <div className="ledger-settled-layout flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-2 min-w-0">
            <span
              className="ledger-market-name text-xs sm:text-[13px] font-black tracking-wide uppercase break-words"
              style={{ color: accentColor }}
            >
              {market.n}
            </span>
            <span className={`text-[8px] font-black px-1.5 py-0.5 rounded-full shrink-0 ${isNight ? "bg-[#6C5CE7]/20 border border-[#6C5CE7]/40 text-[#A29BFE]" : "bg-[#E5A93C]/20 border border-[#E5A93C]/40 text-[#FDCB6E]"}`}>
              {isNight ? '🌙 NIGHT' : '☀️ DAY'}
            </span>
            <span
              title={sourceWeekLength === 7 ? '7-Day Market (Mon–Sun Open)' : sourceWeekLength === 6 ? '6-Day Market (Mon–Sat Open · Sun Off)' : '5-Day Market (Mon–Fri Open · Sat & Sun Off)'}
              className={`text-[8px] font-black px-1.5 py-0.5 rounded-full shrink-0 border ${
                sourceWeekLength === 7
                  ? 'bg-emerald-500/15 border-emerald-500/35 text-emerald-300'
                  : sourceWeekLength === 6
                    ? 'bg-cyan-500/15 border-cyan-500/35 text-cyan-300'
                    : 'bg-amber-500/15 border-amber-500/35 text-amber-300'
              }`}
            >
              📅 {sourceWeekLength}D · {sourceWeekLength === 7 ? 'MON–SUN' : sourceWeekLength === 6 ? 'MON–SAT' : 'MON–FRI'}
            </span>
            {(currentFilterLabel || (selectionUndoSource(d) && (!smartDecision || d.trick || d.positionRule))) && (
              <span className="text-[8px] bg-gradient-to-r from-[#7B8FFF] to-[#5C6CFF] text-white px-1.5 py-0.5 rounded-full font-extrabold uppercase shadow-sm shrink-0">
                {currentFilterLabel || d.trick || (d.positionRule === 'SELF_LEARN' ? (d.selfLearning?.isConservativeFallback ? '🛡️ AI CONSERVATIVE' : d.selfLearning?.shieldMode ? '🛡️ AI SHIELD' : '🧠 AI LEARN') : d.positionRule === 'RECENT4' ? 'Remove4' : d.positionRule === 'RECENT6' ? 'Keep6' : d.positionRule === 'RECENT2' ? 'RECENT 2' : d.positionRule === 'FIRST_CUT' ? 'FIRST CUT' : d.positionRule === 'FIRST_DIGIT_MIRROR' ? (d.firstDigitMirrorCut?.stage===1?'FIRST CUT':'MIRROR DONE') : d.positionRule === 'CUT2' ? 'CUT 2' : d.positionRule === 'FCUT' ? 'Fcut' : d.positionRule === 'LCUT' ? 'Lcut' : d.positionRule === 'CENTER' ? 'CENTER' : d.positionRule === 'LAST_ACTUAL_MIRROR' ? 'ACTUAL + MIRROR' : d.positionRule === 'SSD' ? 'SSD' : d.positionRule === 'TESLA_369' ? '⚡ 3-6-9' : d.positionRule === 'SNIPER_1' ? '🎯 SNIPER-1' : d.positionRule === 'TRI_CUT' ? 'TRI-CUT' : d.positionRule === 'FLOW_3_1' ? (flowWinLogics[0] ? `👑 4-ANK · ${flowWinLogics[0]}` : '👑 4-ANK BRAIN') : 'WD')}
              </span>
            )}
            <span className={`ledger-status-badge text-[9px] px-2 py-0.5 rounded-lg border flex items-center gap-1 uppercase shrink-0 ${statusBadgeClass}`}>
              {statusIcon} {displayedStatus} {loopBadge}
            </span>
            {smartBadge}
            {probBadge}
            {yesterdayBadge}
          </div>

          <div className="flex items-center justify-between sm:justify-end gap-2 shrink-0 border-t sm:border-t-0 border-[rgba(255,255,255,0.06)] pt-1.5 sm:pt-0">
            <div className="ledger-settled-values text-right">
              <div>{currentSourceBadge}</div>
              <span className="text-[11px] font-mono font-black text-[#FAC748] block">
                <span className="ledger-value-label">Selected digits</span>{d.d || '---'}
              </span>
              <div className="mt-1">{currentSourceBadge}</div>
            {selfLearningProofBadge}
            {pngSupportBadge}
            {removedIndicesBadge}
            {d.autoRemovedResult && d.autoRemovedResult.input !== d.autoRemovedResult.output && <p className="text-[9px] text-[#8DC8FF]">{d.autoRemovedResult.actuals?.length === 5 ? `Cut 5: ${d.autoRemovedResult.actuals.join(', ')} (Removed)` : `Removed ${d.autoRemovedResult.actual} · previous card result`}</p>}
              <span className="text-[9px] font-mono font-bold text-[#6C7D93] block">
                ₹{getEffectiveCardRate(d, type, cfg)} / digit
              </span>
            </div>

            {testResultButton}
            {showSendNow && <button type="button" onClick={sendCardCopy}
              disabled={sendingNow || !hasDigitInput || invalidTokenCard || !(Number(d.sentRate || displayRate || d.r || d.recRate) > 0)}
              className="ledger-send-now text-[#8DC8FF] px-2 py-2 rounded-xl text-[10px] font-bold disabled:opacity-40"
              title="Send a copy only; normal queue and accounting stay unchanged">{sendingNow ? 'Sending…' : 'Send now'}</button>}
            {isMaster && <>
              <button type="button" onClick={() => onUnlockCard(type, index)} className="bg-[#2B3A4D] text-[#2AABEE] p-2 rounded-xl" title="Unlock Card"><RotateCcw className="w-3.5 h-3.5" /></button>
              <button type="button" onClick={() => onResetCard(type, index)} title="Clear card and reverse old investment/result" className="p-2 text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>
            </>}
          </div>
        </div>
        {currentDate < titanLocalDateISO() && d.backtestSkipHistory && <div className="mt-2 rounded border border-[#2AABEE]/30 p-2 text-[10px] text-[#8DC8FF]">Skipped card · History only · Result {d.backtestSkipHistory.actual ?? 'pending'} · Original source index {d.backtestSkipHistory.sourceIndex ?? 'pending'} · No stake or profit</div>}
        {d.marketModel?.decision === 'SKIP' && <div className="text-[9px] text-[#FAC748] mt-1">SKIP · {marketModelReasonLabel(d.marketModel.reason)}</div>}
        {positionStrip && <div className="ledger-position-row mt-2">{sourcePositionHeading}{positionStrip}</div>}
        {d.manualStatus && d.manualResult && <div className="mt-1 text-[9px] text-[#8DC8FF]">Manual result: {d.manualResult}</div>}
        {jodiOpenSummary}
      </div>
    );
  }

  // -------------------------------------------------------------
  // ACTIVE CARD VIEW (Modern, Spacious, High-Contrast UI)
  // -------------------------------------------------------------
  return (
    <div ref={cardRoot}
      data-status={d.s} data-frozen={isVisuallyFrozen||undefined}
      data-tools-open={isToolsOpen || undefined}
      style={{ '--ledger-accent': accentColor } as React.CSSProperties}
      className={`ledger-card ledger-card-active bg-[#18222D] border border-[rgba(255,255,255,0.09)] rounded-2xl p-3 mb-3 shadow-lg transition-all hover:border-[rgba(255,255,255,0.15)] ${cardBorderLeft}`}
    >
        {d.manualStatus && d.manualResult && <div className="mt-1 text-[9px] text-[#8DC8FF]">Manual result: {d.manualResult}</div>}
        {jodiOpenSummary}
      {/* 1. Header Row: Market Name, Category Badge, Status, Scrape & Tools */}
      <div className="ledger-card-header pb-2.5 mb-2.5 border-b border-[rgba(255,255,255,0.06)] space-y-2">
        <div className="ledger-header-content flex flex-wrap items-center justify-between gap-2">
          <span className="ledger-category">{type === 'pannel' ? 'PANEL' : type.toUpperCase()} <span>MARKET CARD</span></span>
          {/* Market Title & Badges Container */}
          <div className="ledger-market-summary flex flex-wrap items-center gap-2 min-w-0 flex-1">
            <span
              className="ledger-market-name text-xs sm:text-sm font-black uppercase tracking-wide leading-tight break-words"
              style={{ color: accentColor }}
            >
              {market.n}
            </span>
            <span className={`text-[8px] font-black px-1.5 py-0.5 rounded-full shrink-0 ${isNight ? "bg-[#6C5CE7]/20 border border-[#6C5CE7]/40 text-[#A29BFE]" : "bg-[#E5A93C]/20 border border-[#E5A93C]/40 text-[#FDCB6E]"}`}>
              {isNight ? '🌙 NIGHT' : '☀️ DAY'}
            </span>
            <span
              title={sourceWeekLength === 7 ? '7-Day Market (Mon–Sun Open)' : sourceWeekLength === 6 ? '6-Day Market (Mon–Sat Open · Sun Off)' : '5-Day Market (Mon–Fri Open · Sat & Sun Off)'}
              className={`text-[8px] font-black px-1.5 py-0.5 rounded-full shrink-0 border ${
                sourceWeekLength === 7
                  ? 'bg-emerald-500/15 border-emerald-500/35 text-emerald-300'
                  : sourceWeekLength === 6
                    ? 'bg-cyan-500/15 border-cyan-500/35 text-cyan-300'
                    : 'bg-amber-500/15 border-amber-500/35 text-amber-300'
              }`}
            >
              📅 {sourceWeekLength}D · {sourceWeekLength === 7 ? 'MON–SUN' : sourceWeekLength === 6 ? 'MON–SAT' : 'MON–FRI'}
            </span>

            {smartBadge}
            {d.autoRemovedResult?.unique3 && <span className="ledger-model-badge" title="Previous 5 unique actual result digits cut; exactly 5 digits remain (50% probability)">{d.autoRemovedResult.actuals?.length===5?'CUT 5 · 50%':`CUT WAIT · ${d.autoRemovedResult.actuals?.length||0}/5`}</span>}
            {(d.positionRule === 'FLOW_3_1' || d.sourceMode === 'FLOW_3_1') && <span title={String(d?.masterFlow?.reason || '4-Ank Dynamic Brain')} className="text-[8px] bg-gradient-to-r from-[#D4AF37] to-[#F39C12] text-black px-1.5 py-0.5 rounded-full font-extrabold uppercase shadow-sm shrink-0">👑 4-ANK BRAIN{flowWinLogics[0] ? ` · ${flowWinLogics[0]}` : ''}</span>}
            {d.positionRule === 'TRI_CUT' && <span title={`Tri-Cut: Mirror (${d.triCut?.mirror || '-'}), Padosi (${d.triCut?.padosi?.join(',') || '-'}), Center (${d.triCut?.centerCut?.join(',') || '-'})`} className="text-[8px] bg-gradient-to-r from-[#9333EA] to-[#6366F1] text-white px-1.5 py-0.5 rounded-full font-extrabold uppercase shadow-sm shrink-0">⚡ TRI-CUT</span>}
            {d.positionRule === 'SNIPER_1' && <span title={d.sniperOne?.summary || 'Sniper-1 Single Ank Dynamic Engine'} className="text-[8px] bg-gradient-to-r from-[#EF4444] via-[#F59E0B] to-[#D97706] text-white px-1.5 py-0.5 rounded-full font-extrabold uppercase shadow-sm shrink-0">🎯 SNIPER-1{d.sniperOne?.runnerUp ? ` · BKP ${d.sniperOne.runnerUp}` : ''}</span>}
            {d.positionRule === 'TESLA_369' && <span title={d.tesla369?.summary || 'Tesla 3-6-9 Delta Jump & Trinity Harmonics'} className="text-[8px] bg-gradient-to-r from-[#D97706] to-[#F59E0B] text-black px-1.5 py-0.5 rounded-full font-extrabold uppercase shadow-sm shrink-0">⚡ 3-6-9</span>}
            {d.sourceMode === 'RESULT_CARRY6' && (
              <span
                className="ledger-model-badge"
                title={d.carryResultSix?.diagnosisDetails || "Full 0-9 Spectrum Loop Trend & Deep Fail-Trace"}
              >
                {(d.carryResultSix?.history.length || 0) >= 5
                  ? d.carryResultSix?.diagnosis === 'FAMILY_SATURATION_LOCK'
                    ? 'CARRY 5 · FAMILY LOCK'
                    : d.carryResultSix?.diagnosis === 'TRAP_INVERSION'
                    ? 'CARRY 5 · TRAP INVERT'
                    : d.carryResultSix?.diagnosis === 'CUT_TRAP'
                    ? 'CARRY 5 · CUT FIX'
                    : d.carryResultSix?.diagnosis === 'COLD_SHIFT'
                    ? 'CARRY 5 · COLD SHIFT'
                    : d.carryResultSix?.diagnosis === 'DELTA_JUMP'
                    ? 'CARRY 5 · DELTA FIX'
                    : d.carryResultSix?.diagnosis === 'RECOVERY_HEDGE'
                    ? 'CARRY 5 · RECOVERY'
                    : 'CARRY 5 · 50%'
                  : `CARRY WAIT · ${d.carryResultSix?.history.length || 0}/5`}
              </span>
            )}
            {d.sourceMode === 'MARKET_MODEL' && <span className="ledger-model-badge" title={d.marketModel ? marketModelReasonLabel(d.marketModel.reason) : undefined}>{d.marketModel ? `DYNAMIC · ${d.marketModel.decision} · ${d.marketModel.windows.join('/')}${d.marketModel.patternShift ? ' · SHIFT' : ''}` : 'MODEL'}</span>}

            {timingFormatted && (
              <span className="text-[9px] font-mono text-[#8DA6C0] bg-[#0F1722] px-1.5 py-0.5 rounded border border-[rgba(255,255,255,0.08)] shrink-0 flex items-center gap-0.5">
                ⏰ {timingFormatted}
              </span>
            )}

            {(currentFilterLabel || (selectionUndoSource(d) && (!smartDecision || d.trick || d.positionRule))) && (
              <span className="text-[8px] bg-[#7B8FFF] text-white px-1.5 py-0.5 rounded-md font-extrabold uppercase shadow-sm shrink-0">
                {currentFilterLabel || d.trick || (d.positionRule === 'SELF_LEARN' ? (d.selfLearning?.isConservativeFallback ? '🛡️ AI CONSERVATIVE' : d.selfLearning?.shieldMode ? '🛡️ AI SHIELD' : '🧠 AI LEARN') : d.positionRule === 'RECENT4' ? 'Remove4' : d.positionRule === 'RECENT6' ? 'Keep6' : d.positionRule === 'RECENT2' ? 'RECENT 2' : d.positionRule === 'FIRST_CUT' ? 'FIRST CUT' : d.positionRule === 'FIRST_DIGIT_MIRROR' ? (d.firstDigitMirrorCut?.stage===1?'FIRST CUT':'MIRROR DONE') : d.positionRule === 'CUT2' ? 'CUT 2' : d.positionRule === 'FCUT' ? 'Fcut' : d.positionRule === 'LCUT' ? 'Lcut' : d.positionRule === 'CENTER' ? 'CENTER' : d.positionRule === 'LAST_ACTUAL_MIRROR' ? 'ACTUAL + MIRROR' : d.positionRule === 'SSD' ? 'SSD' : d.positionRule === 'TESLA_369' ? '⚡ 3-6-9' : d.positionRule === 'SNIPER_1' ? '🎯 SNIPER-1' : d.positionRule === 'TRI_CUT' ? 'TRI-CUT' : d.positionRule === 'FLOW_3_1' ? '4-ANK' : 'WD')}
              </span>
            )}

            <span className={`ledger-status-badge text-[8px] px-2 py-0.5 rounded-lg border flex items-center gap-1 uppercase shrink-0 ${statusBadgeClass}`}>
              {statusIcon} {displayedStatus} {loopBadge}
            </span>
            {probBadge}
            <span className={positionStrip ? "ledger-yesterday-desktop" : "ledger-yesterday-standalone"}>{yesterdayBadge}</span>
          </div>

          {d.marketModel?.decision === 'SKIP' && <div className="text-[9px] text-[#FAC748] mt-1">SKIP · {marketModelReasonLabel(d.marketModel.reason)}</div>}
          {positionStrip && <div className="ledger-position-row"><div className="ledger-position-meta">{sourcePositionHeading}<span className="ledger-yesterday-mobile">{yesterdayBadge}</span></div>{positionStrip}</div>}
          {cardActionError&&<p role="alert" className="text-xs text-red-400">{cardActionError}</p>}
          {activeCardAction&&<p role="status" aria-live="polite" className="text-xs text-sky-300">{testingResult?'Testing result…':'Fetching chart…'}</p>}
          {/* Quick Toolbar */}
          <div data-game={type} aria-busy={isScraping} className={`ledger-card-toolbar flex items-center gap-1.5 shrink-0 ml-auto ${type === 'ank' ? 'flex-wrap w-full' : ''}`}>
            {/SRIDEVI/i.test(market.n) && type === 'ank' && (
              <>
                <button
                  type="button"
                  onClick={() => void onApplySrideviMasterFormula?.(index, market.n)}
                  disabled={isDeliveryFrozen || !onApplySrideviMasterFormula}
                  className="bg-gradient-to-r from-[#2AABEE] via-[#00C26F] to-[#FAC748] hover:opacity-90 text-[#101923] font-black px-2 py-1 rounded-lg text-[9px] uppercase active:scale-95 transition-all shadow-md whitespace-nowrap flex items-center gap-1 border border-white/20"
                  title={isOpen ? "🎯 SRIDEVI MASTER FORMULA: Panna Head-Sum Root (65.9% Pass Rate)" : "🎯 SRIDEVI MASTER FORMULA: Open Session Bridge Lock (63.7% Pass Rate)"}
                >
                  🎯 SRIDEVI MASTER
                </button>
                <button
                  type="button"
                  onClick={() => void onApplySrideviHeadSum?.(index, market.n)}
                  disabled={isDeliveryFrozen || !onApplySrideviHeadSum}
                  className="bg-gradient-to-r from-[#EC4899] via-[#F43F5E] to-[#E11D48] hover:from-[#F472B6] hover:to-[#BE123C] text-white px-2 py-1 rounded-lg text-[9px] font-black uppercase active:scale-95 transition-all shadow-sm whitespace-nowrap"
                  title="Sridevi Patti Head Sum 4-Ank Formula (pichle din ke Open aur Close Panna ke 1st digits ka sum)"
                >
                  👑 SRIDEVI HEAD SUM
                </button>
              </>
            )}
            {type === 'ank' && (
              <button
                type="button"
                onClick={() => void onApplyUniversalLifetime4Ank?.(index, market.n)}
                disabled={isDeliveryFrozen || !onApplyUniversalLifetime4Ank}
                className="bg-gradient-to-r from-[#D4AF37] via-[#F39C12] to-[#E67E22] hover:from-[#B45309] hover:to-[#D4AF37] text-black font-black px-2.5 py-1 rounded-lg text-[9px] uppercase active:scale-95 transition-all shadow-sm whitespace-nowrap flex items-center gap-1"
                title="👑 Universal Lifetime 4-Ank Formula: Pichli Jodi Total + Double Family Cut (All Markets OTC)"
              >
                👑 4-ANK
              </button>
            )}
            {(isMaster || ((type === 'jodi' || type === 'pannel') && vipCanEdit)) && (
              <>
                {type === 'jodi' ? (
                  <>
                    <button
                      type="button"
                      onClick={() => onBuildJodiFromAnk?.(index, market.n)}
                      disabled={isDeliveryFrozen || !onBuildJodiFromAnk}
                      className="bg-gradient-to-r from-[#2AABEE] to-[#087FB8] hover:from-[#43B8F0] hover:to-[#1594D1] text-white px-2.5 py-1 rounded-lg text-[9px] font-black uppercase active:scale-95 transition-all shadow-sm whitespace-nowrap"
                      title="Same market ke OPEN ANK × CLOSE ANK se Jodi banao"
                    >
                      ANK → JODI
                    </button>
                    <button
                      type="button"
                      onClick={() => void onApply32JodiOnly?.(index, market.n)}
                      disabled={isDeliveryFrozen || !onApply32JodiOnly}
                      className="bg-gradient-to-r from-[#FF5722] via-[#F43F5E] to-[#E11D48] hover:from-[#FF7043] hover:to-[#BE123C] text-white px-2.5 py-1 rounded-lg text-[9px] font-black uppercase active:scale-95 transition-all shadow-sm whitespace-nowrap"
                      title="Is market ke liye strictly 32 JODIS (6 Family Digits Cross) generate karo"
                    >
                      🎯 32 JODI
                    </button>
                    <button
                      type="button"
                      onClick={() => void onApplyLifetimeJodiFormula?.(index, market.n)}
                      disabled={isDeliveryFrozen || !onApplyLifetimeJodiFormula}
                      className="bg-gradient-to-r from-[#8B3DFF] via-[#A855F7] to-[#D35400] hover:from-[#9D4EDD] hover:to-[#E67E22] text-white px-2.5 py-1 rounded-lg text-[9px] font-black uppercase active:scale-95 transition-all shadow-sm whitespace-nowrap"
                      title="Pichli Jodi ke Farak (Difference) ke hisab se Lifetime 16, 24 ya 32 Jodis banao"
                    >
                      ⚡ 16/24/32 FORMULA
                    </button>
                    <button
                      type="button"
                      onClick={() => onTransferJodiToAnk?.(index, market.n)}
                      disabled={isDeliveryFrozen || !onTransferJodiToAnk}
                      className="bg-gradient-to-r from-[#00C26F] to-[#059669] hover:from-[#10B981] hover:to-[#047857] text-white px-2.5 py-1 rounded-lg text-[9px] font-black uppercase active:scale-95 transition-all shadow-sm whitespace-nowrap"
                      title="Is Jodi card ke Open aur Close Ank nikal kar ANK tab ke OPEN aur CLOSE cards me transfer karo"
                    >
                      📤 JODI → ANK
                    </button>
                    {/SRIDEVI/i.test(market.n) && (
                      <>
                        <button
                          type="button"
                          onClick={() => void onApplySrideviMasterFormula?.(index, market.n)}
                          disabled={isDeliveryFrozen || !onApplySrideviMasterFormula}
                          className="bg-gradient-to-r from-[#2AABEE] via-[#00C26F] to-[#FAC748] hover:opacity-90 text-[#101923] font-black px-2.5 py-1 rounded-lg text-[9px] uppercase active:scale-95 transition-all shadow-md whitespace-nowrap flex items-center gap-1 border border-white/20"
                          title="🎯 SRIDEVI MASTER 16 JODI (Open Head Sum × Close Session Bridge)"
                        >
                          🎯 SRIDEVI MASTER 16 JODI
                        </button>
                        <button
                          type="button"
                          onClick={() => void onApplySrideviHeadSum?.(index, market.n)}
                          disabled={isDeliveryFrozen || !onApplySrideviHeadSum}
                          className="bg-gradient-to-r from-[#EC4899] via-[#F43F5E] to-[#E11D48] hover:from-[#F472B6] hover:to-[#BE123C] text-white px-2.5 py-1 rounded-lg text-[9px] font-black uppercase active:scale-95 transition-all shadow-sm whitespace-nowrap"
                          title="Sridevi Patti Head Sum 16-Jodi Formula"
                        >
                          👑 SRIDEVI 16 JODI
                        </button>
                      </>
                    )}
                    <button
                      type="button"
                      onClick={() => void onApplyUniversalLifetime4Ank?.(index, market.n)}
                      disabled={isDeliveryFrozen || !onApplyUniversalLifetime4Ank}
                      className="bg-gradient-to-r from-[#D4AF37] via-[#F39C12] to-[#E67E22] hover:from-[#B45309] hover:to-[#D4AF37] text-black font-black px-2.5 py-1 rounded-lg text-[9px] uppercase active:scale-95 transition-all shadow-sm whitespace-nowrap flex items-center gap-1"
                      title="👑 Universal Lifetime 16-Jodi Formula: Pichli Jodi Total + Double Family Cut 4x4 Cross"
                    >
                      👑 16-JODI
                    </button>
                  </>
                ) : type === 'pannel' ? (
                  <>
                    <button type="button"
                      onClick={()=>void runCardAction('panel',()=>onBuildPanelFromAnk?.(index, market.n))}
                      disabled={isScraping || disabled || isDeliveryFrozen || !onBuildPanelFromAnk}
                      className="bg-gradient-to-r from-[#20B2AA] to-[#087F78] hover:from-[#2AC7BE] hover:to-[#129990] text-white px-2.5 py-1 rounded-lg text-[9px] font-black uppercase active:scale-95 transition-all shadow-sm whitespace-nowrap"
                      title="Same session chart se ANK-sum matching overdue Single Pattis select karo"
                    >
                      {isScraping ? 'LOADING…' : 'ANK → PANEL'}
                    </button>
                    <button type="button"
                      onClick={()=>void runCardAction('panel',()=>onBuildLowPanelFromAnk?.(index, market.n))}
                      disabled={isScraping || disabled || isDeliveryFrozen || !onBuildLowPanelFromAnk}
                      className="bg-gradient-to-r from-[#B04A7A] to-[#75305D] hover:from-[#C95B8E] hover:to-[#8B3A70] text-white px-2.5 py-1 rounded-lg text-[9px] font-black uppercase active:scale-95 transition-all shadow-sm whitespace-nowrap"
                      title="Unseen first; then weekday + Jodi-after lowest-frequency Single Pattis"
                    >
                      {isScraping ? 'LOADING…' : '📉 LOW PANEL 30'}
                    </button>
                    <button type="button" onClick={()=>void runCardAction('panel',()=>onBuildStrictPanel30?.(index,market.n))}
                      disabled={isScraping || disabled || isDeliveryFrozen || !onBuildStrictPanel30}
                      className="bg-[#25635E] text-white px-2.5 py-1 rounded-lg text-[9px] font-black whitespace-nowrap disabled:opacity-50"
                      title="Skip recent 30 unique SP; retain exactly 5 per ANK; shortage means SKIP">
                      {isScraping ? 'LOADING…' : '✂ RECENT 30 SKIP · 6×5'}
                    </button>
                  </>
                ) : (
                  <div className="contents">
                <button type="button"
                  onClick={()=>void runCardAction('auto',()=>onScrapeMarket(type, index, market.n))}
                  disabled={isScraping || disabled || isDeliveryFrozen}
                  className={`text-[#2AABEE] bg-[rgba(42,171,238,0.12)] hover:bg-[rgba(42,171,238,0.22)] border border-[rgba(42,171,238,0.25)] w-12 h-12 shrink-0 p-1 rounded-lg text-[9px] font-extrabold uppercase active:scale-95 transition-all flex flex-col items-center justify-center gap-1 text-center ${selectedScrapeClass('auto')}`}
                  title="Fetch auto digits"
                >
                  <Satellite className={`w-3 h-3 ${isScraping ? 'animate-spin' : ''}`} />
                  <span>Auto</span>
                </button>

                <button type="button"
                  onClick={()=>void runCardAction('day',()=>onWeekdayScrapeMarket?.(type, index, market.n))}
                  disabled={isScraping || disabled || isDeliveryFrozen || !onWeekdayScrapeMarket}
                  className={`text-[#20E093] bg-[rgba(32,224,147,0.12)] hover:bg-[rgba(32,224,147,0.22)] border border-[rgba(32,224,147,0.25)] w-12 h-12 shrink-0 p-1 rounded-lg text-[9px] font-extrabold uppercase active:scale-95 transition-all flex flex-col items-center justify-center gap-1 text-center ${selectedScrapeClass('day')}`}
                  title="Aaj ke weekday ka same column bottom-to-top scrape karo (OPEN/CLOSE separate)"
                >
                  <TrendingDown className={`w-3 h-3 ${isScraping ? 'animate-pulse' : ''}`} />
                  <span>Day</span>
                </button>

                <button type="button"
                  onClick={()=>void runCardAction('combo',()=>onComboScrape(type,index,market.n))}
                  disabled={isScraping || disabled || isDeliveryFrozen}
                  className={`bg-gradient-to-r from-[#00C26F] to-[#009E5A] hover:from-[#00D47A] hover:to-[#00B064] text-white w-12 h-12 shrink-0 p-1 rounded-lg text-[9px] font-black uppercase active:scale-95 transition-all shadow-sm ${selectedScrapeClass('combo')}`}
                  title="Combo auto scrape"
                >
                  Combo
                </button>

                {onDayComboScrape && (
                  <button type="button"
                    onClick={()=>void runCardAction('day_combo',()=>onDayComboScrape(type, index, market.n))}
                    disabled={isScraping || disabled || isDeliveryFrozen}
                    className={`bg-gradient-to-r from-[#237D74] to-[#165A53] text-white w-12 h-12 shrink-0 p-1 rounded-lg text-[9px] font-black uppercase active:scale-95 transition-all shadow-sm ${selectedScrapeClass('day_combo')}`}
                    title="Selected weekday bottom-to-top: CLOSE → OPEN, phir purana din; 10 unique digits"
                  >
                    Day<br/>Combo
                  </button>
                )}

                {onSmartAutoDigits && (
                  <button type="button"
                    onClick={()=>void runCardAction('smart',()=>onSmartAutoDigits(type, index, market.n))}
                    disabled={isScraping || disabled || isDeliveryFrozen}
                    className={`bg-gradient-to-r from-[#B85CFF] to-[#8B3DFF] hover:from-[#C570FF] hover:to-[#9B55FF] text-white w-12 h-12 shrink-0 p-1 rounded-lg text-[9px] font-black uppercase active:scale-95 transition-all shadow-sm flex flex-col items-center justify-center gap-1 text-center ${selectedScrapeClass('smart')}`}
                    title="Smart: selected source first-ten-unique window; choose up to six highest-frequency digits"
                  >
                    <Sparkles className={`w-3 h-3 ${isScraping ? 'animate-spin' : ''}`} />
                    Smart
                  </button>
                )}

                {onTrendBreak && type==='ank' && (
                  <button type="button"
                    onClick={()=>void runCardAction('trend_break',()=>onTrendBreak(type,index,market.n))}
                    disabled={isScraping||disabled||isDeliveryFrozen}
                    className={`bg-gradient-to-br from-[#B45309] to-[#78350F] hover:from-[#D97706] hover:to-[#92400E] border border-amber-500/40 text-amber-100 w-12 h-12 shrink-0 p-1 rounded-lg text-[9px] font-black uppercase shadow-md active:scale-95 transition-all flex flex-col items-center justify-center gap-0.5 text-center ${selectedScrapeClass('trend_break')}`}
                    title="Trend Filter: Keep Top 4–5 highest-probability digits based on live chart momentum and decay"
                  >
                    <Zap className="w-3 h-3 text-amber-300" />
                    <span>Trend<br/>Filter</span>
                  </button>
                )}



                  </div>
                )}

                {isMaster && (
                  <button type="button"
                    onClick={() => onResetCard(type, index)}
                    className={type === 'ank' ? 'w-12 h-12 shrink-0 p-1 rounded-lg text-[9px] font-bold flex flex-col items-center justify-center gap-1 text-[#FF7777] bg-[#232E3C] border border-[#FF5D5D]/25 active:scale-95 transition-all' : 'text-[#6C7D93] hover:text-[#FF5D5D] hover:bg-[rgba(255,93,93,0.1)] p-1 rounded-lg active:scale-95 transition-all'}
                    title="Reset Card"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    {type === 'ank' && <span>Clear</span>}
                  </button>
                )}
              </>
            )}

            {/* Tools Expander Toggle */}
            <button type="button"
              onClick={() => setIsToolsOpen(!isToolsOpen)}
              className={`${type === 'ank' ? 'w-12 h-12 shrink-0 flex-col justify-center' : ''} p-1.5 rounded-lg text-[9px] font-bold flex items-center gap-1 border transition-all ${
                isToolsOpen
                  ? 'bg-[#2AABEE] text-white border-[#2AABEE] shadow-sm'
                  : 'bg-[#232E3C] text-[#8DA6C0] border-[rgba(255,255,255,0.08)] hover:text-white hover:bg-[#2B3A4D]'
              }`}
              title="Toggle Tricks & Tools"
            >
              <Wrench className="w-3 h-3" />
              {type === 'ank' && <span>Tools</span>}
              {type !== 'ank' && (isToolsOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />)}
            </button>
          </div>
        </div>
      </div>



      {d.autoResultParity?.rule==='OPEN_LOOP_CUT'&&<div className="mb-2 rounded-lg border border-[#2AABEE]/30 bg-[#2AABEE]/10 p-2 text-[10px] text-[#8DC8FF]">F/C/L-cut {d.autoResultParity.cut==='CENTER'?'CENTER · middle 4–7 cut':d.autoResultParity.cut==='LCUT'?'Lcut':'Fcut'} · Loop {d.autoResultParity.loopCut==='LCUT'?'Lcut':'Fcut'}{d.autoResultParity.marketCut?` · OPEN ${d.autoResultParity.marketCut==='LCUT'?'Lcut':'Fcut'}`:''}</div>}
      {isBacktestCard && d.backtestRecoveryReset && <div className="mb-2 rounded-lg border border-[#2AABEE]/30 bg-[#2AABEE]/10 p-2 text-[10px] text-[#8DC8FF]">3 FAIL cycle closed · ₹{d.backtestRecoveryReset.debtCleared.toLocaleString('en-IN')} removed from next-rate recovery. Loss remains in daily P/L; next eligible card starts at base rate.</div>}
      {isBacktestCard && d.backtestStakeLimitSkipped && <div className="mb-2 rounded-lg border border-[#FAC748]/30 p-2 text-[10px] text-[#FAC748]">Backtest stake cap · card skipped before betting.</div>}
      {currentDate < titanLocalDateISO() && d.backtestSkipHistory && <div className="mb-2 rounded-lg border border-[#2AABEE]/30 p-2 text-[10px] text-[#8DC8FF]">Skipped card · History only · Result {d.backtestSkipHistory.actual ?? 'pending'} · Original source index {d.backtestSkipHistory.sourceIndex ?? 'pending'} · {d.backtestSkipHistory.status ? `Selection ${d.backtestSkipHistory.status}` : 'No simulated selection status'} · No stake or profit</div>}
      {currentDate < titanLocalDateISO() && d.backtestDailyStopLossSkipped && <div className="mb-2 rounded-lg border border-[#FF8A8A]/30 p-2 text-[10px] text-[#FF8A8A]">Backtest daily stop loss · No bet · Next date starts at base rate</div>}
      {currentDate < titanLocalDateISO() && d.backtestDailyProfitSkipped && <div className="mb-2 rounded-lg border border-[#00C26F]/30 p-2 text-[10px] text-[#00C26F]">Backtest daily profit exit · No bet · Next date starts normally</div>}
      {currentDate < titanLocalDateISO() && d.backtestCombinedKeep && <div className="mb-2 rounded-lg border border-[#00C26F]/30 p-2 text-[10px] text-[#8DC8FF]">
        <div>Backtest combined KEEP · AUTO {d.backtestCombinedKeep.auto.join(', ')} · DAY {d.backtestCombinedKeep.day.join(', ')}</div>
        <div>Index digits: {d.backtestCombinedKeep.indexDigits.join(', ') || 'missing'} · Kept: {d.backtestCombinedKeep.kept.join(', ') || 'none'}</div>
        <div>{d.backtestCombinedKeep.choices.map(c=>`${c.digit} (${c.via})`).join(' · ')}</div>
        {d.backtestCombinedKeep.reason && <div className="text-[#FAC748]">{d.backtestCombinedKeep.reason}</div>}
      </div>}
      {d.liveCombinedCut&&<div className="mb-2 rounded-lg border border-[#2AABEE]/30 bg-[#2AABEE]/10 p-2 text-[10px] text-[#8DC8FF]">
        <div>Live AUTO 2 + DAY 2 · {d.liveCombinedCut.position==='last'?'Last 2 Cut':'First 2 Cut'}</div>
        <div>AUTO {d.liveCombinedCut.auto.join(', ')} · DAY {d.liveCombinedCut.day.join(', ')}</div>
        <div>Removed: {d.liveCombinedCut.removed.join(', ')||'none'} · {d.liveCombinedCut.choices.map(c=>`${c.digit} (${c.via})`).join(' · ')}</div>
        {d.liveCombinedCut.reason&&<div className="text-[#FAC748]">{d.liveCombinedCut.reason}</div>}
      </div>}
      {currentDate < titanLocalDateISO() && d.backtestCombinedCut && <div className="mb-2 rounded-lg border border-[#2AABEE]/30 bg-[#2AABEE]/10 p-2 text-[10px] text-[#8DC8FF]">
        <div>Backtest combined cut · AUTO {d.backtestCombinedCut.auto.join(', ')} · DAY {d.backtestCombinedCut.day.join(', ')}</div>
        <div>Index fallbacks: {d.backtestCombinedCut.fallback.join(', ') || 'missing'} · Removed: {d.backtestCombinedCut.removed.join(', ') || 'none'}</div>
        <div>{d.backtestCombinedCut.choices.map(c=>`${c.digit} (${c.via})`).join(' · ')}</div>
        {d.backtestCombinedCut.reason && <div className="text-[#FAC748]">{d.backtestCombinedCut.reason}</div>}
      </div>}
      {/* Zero Invest Close Banner when OPEN Won */}
      {isOpenPassForThisClose && (
        <div className="mb-2.5 bg-gradient-to-r from-[rgba(0,194,111,0.15)] to-[rgba(42,171,238,0.1)] border border-[rgba(0,194,111,0.35)] rounded-xl px-3 py-1.5 flex items-center justify-between text-[11px] shadow-sm">
          <div className="flex items-center gap-1.5 text-[#00C26F] font-extrabold">
            <Zap className="w-3.5 h-3.5" />
            <span>OPEN Won · CLOSE ₹0 Invest</span>
          </div>
          <div className="flex items-center gap-1 text-[#8DA6C0] font-mono font-bold text-[10px]">
            <span>Result tracked · Fail carries profit</span>
          </div>
        </div>
      )}

      {/* 2. Loss Recovery / Profit Carry Alert Banner (High visual priority when active) */}
      {!isOpenPassForThisClose && (effectivePrevLoss > 0 || carriedProfit > 0) && (
        <div className={`ledger-recovery-banner mb-2.5 rounded-xl px-3 py-1.5 flex items-center justify-between text-[11px] shadow-sm border ${
          effectivePrevLoss > 0
            ? 'bg-gradient-to-r from-[rgba(255,93,93,0.15)] to-[rgba(250,199,72,0.1)] border-[rgba(255,93,93,0.35)]'
            : 'bg-gradient-to-r from-[rgba(250,199,72,0.15)] to-[rgba(0,194,111,0.1)] border-[rgba(250,199,72,0.35)]'
        }`}>
          <div className="flex items-center gap-1.5 font-extrabold">
            {effectivePrevLoss > 0 ? (
              <>
                <TrendingDown className="w-3.5 h-3.5 text-[#FF5D5D] animate-pulse" />
                <span className="text-[#FF5D5D]">Loss Recovery: -₹{effectivePrevLoss}</span>
                {carriedProfit > 0 && <span className="text-[#FAC748] ml-1">(+₹{carriedProfit} profit carry)</span>}
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5 text-[#FAC748] animate-pulse" />
                <span className="text-[#FAC748]">Profit Carry: +₹{carriedProfit}</span>
              </>
            )}
          </div>
          <div className="flex items-center gap-1 text-[#FAC748] font-mono font-bold text-[10px]">
            <Zap className="w-3 h-3 text-[#FAC748]" />
            <span>Target Profit + Loss: ₹{effectiveTargetWithLoss}</span>
          </div>
        </div>
      )}

      {/* 3. Main Data Input Section */}
      <div className="ledger-data-section space-y-2">
        {isBacktestCard && <div className="text-[9px] text-[#8DC8FF]">Backtest result: {d.backtestResult?.actual || (d.backtestResult?.openActual?`OPEN ${d.backtestResult.openActual}${d.s==='FAIL'?' · settled at OPEN':' · CLOSE pending'}`:'Missing / unclear · WAIT')} · {d.s}{d.backtestResult?.digits !== d.d ? ' · Digits changed; result pending' : ''}</div>}
        {!isBacktestCard&&type==='jodi'&&d.jodiOpenResult&&<div className={`text-[9px] ${d.jodiOpenStatus==='FAIL'?'text-[#FF8A8A]':'text-[#8DC8FF]'}`}>OPEN result: {d.jodiOpenResult} · {d.jodiOpenStatus==='FAIL'?'No selected pair matched · FAIL':d.s==='WAIT'?'Matched · CLOSE pending':'Matched'}</div>}
        {invalidTokenCard && (
          <div className="rounded-xl border border-[#FF5D5D]/40 bg-[#FF5D5D]/10 px-3 py-2 text-[10px] font-bold text-[#FF8A8A]">
            ⚠️ Invalid {type.toUpperCase()} token. {type === 'ank' ? 'Har token 1 digit' : type === 'jodi' ? 'Har token exactly 2 digits' : 'Har Patti exactly 3 digits'} honi chahiye.
          </div>
        )}
        {invalidTargetCard && (
          <div className="rounded-xl border border-[#FF5D5D]/40 bg-[#FF5D5D]/10 px-3 py-2 text-[10px] font-bold text-[#FF8A8A]">
            ⚠️ Target rate possible nahi: {digitCount} selections payout x{settlementMargin(type)} se zyada/equal hain. Digits kam karein.
          </div>
        )}
        {type === 'pannel' && d.sourceMode === 'SP_SKIP30' && d.strictPanel30 && (
          <details className="rounded-xl bg-[#10332F] border border-[#28665D] px-3 py-2 text-[10px] text-[#BBE9DC]">
            <summary className="cursor-pointer font-bold">Recent 30 skip · 6×5 · {d.strictPanel30.targetDate} · {d.strictPanel30.decision === 'SKIP' ? 'Insufficient candidates / SKIP' : '30 SP ready'}</summary>
            <p className="mt-1">{d.strictPanel30.reason}</p>
            {d.strictPanel30.buckets.map(bucket=><p key={bucket.ank}>ANK {bucket.ank} · eligible {bucket.eligible} · selected {bucket.selected.join(', ') || '—'}</p>)}
            <p className="mt-2 break-words">Recent excluded ({d.strictPanel30.excluded.length}): {d.strictPanel30.excluded.join(', ')}</p>
            <p className="mt-1 break-words">Remaining eliminated ({d.strictPanel30.eliminated.length}): {d.strictPanel30.eliminated.join(', ')}</p>
          </details>
        )}
        <div className="ledger-data-fields flex items-stretch gap-2">
          {/* Target Digits Field */}
          <div className="ledger-digits-field flex-1 min-w-0 flex flex-col justify-center">
            <div><span className="ledger-field-label">Selected digits</span></div>
            <div className="ledger-digit-box relative flex items-center">
              <textarea ref={digitBoxRef} rows={1} wrap="soft"
                aria-label={`${market.n} selected digits`}
                disabled={disabled || isScraping || (!vipCanEdit && !isMaster) || isDeliveryFrozen}
                value={visibleDigits}
                onFocus={() => {
                  digitDraftRef.current={value:String(d.d||''),changed:false};
                  setDigitDraft(String(d.d || ''));
                  setIsDigitEditing(true);
                }}
                onChange={(e) => {
                  const next = e.target.value;
                  digitDraftRef.current={value:next,changed:true};
                  setDigitDraft(next);
                  onUpdateRecord(type, index, 'd', next);
                }}
                onBlur={() => {
                  const draft=digitDraftRef.current;
                  if(draft.changed&&draft.value!==String(d.d||''))onUpdateRecord(type,index,'d',draft.value);
                  draft.changed=false;
                  setIsDigitEditing(false);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') e.currentTarget.blur();
                }}
                placeholder={type === 'jodi' ? 'Enter Jodi Pairs (e.g. 12,34)' : 'Enter Target Digits (e.g. 1,2,3,4)'}
                className="w-full bg-[#0F1722] border border-[rgba(255,255,255,0.12)] text-[#FAC748] font-mono font-black text-xs px-3 py-2.5 rounded-xl outline-none focus:border-[#2AABEE] focus:ring-1 focus:ring-[#2AABEE] placeholder:text-[#4A5A6E] placeholder:font-normal placeholder:text-[10px] transition-all"
              />
              {digitCount > 0 && (
                <span className="ledger-digit-count bg-[#232E3C] text-[#8DA6C0] text-[9px] font-mono px-1.5 py-0.5 rounded-md border border-[rgba(255,255,255,0.06)]">
                  {digitCount} {type === 'jodi' ? 'jodi' : 'nums'}
                </span>
              )}
            </div>
            <div className="ledger-card-source-meta">
            <div className="mt-1">{currentSourceBadge}</div>
            {selfLearningProofBadge}
            {pngSupportBadge}
            {removedIndicesBadge}
            {d.autoRemovedResult && d.autoRemovedResult.input !== d.autoRemovedResult.output && <p className="text-[9px] text-[#8DC8FF]">{d.autoRemovedResult.actuals?.length === 5 ? `Cut 5: ${d.autoRemovedResult.actuals.join(', ')} (Removed)` : `Removed ${d.autoRemovedResult.actual} · previous card result`}</p>}
            </div>
          </div>

          {/* Rate Input Field & Recovery Quick Apply */}
          <div className="ledger-rate-field w-28 shrink-0 flex flex-col justify-center">
            <span className="ledger-field-label">Rate / digit</span>
            <div className="relative flex items-center">
              <span className="absolute left-2 text-[#8DA6C0] font-mono text-xs font-bold">₹</span>
              <input
                type="number"
                aria-label={`${market.n} rate per digit`}
                disabled={(!vipCanEdit && !isMaster) || Boolean(d.sentRate || d.dispatchState === 'SENT' || d.dispatchState === 'SETTLED' || (!isBacktestCard && (d.s === 'PASS' || d.s === 'FAIL')))}
                value={displayRate}
                onChange={(e) => onUpdateRecord(type, index, 'r', e.target.value)}
                placeholder={invalidTargetCard || invalidTokenCard ? 'Invalid' : 'Rate'}
                title={d.sentRate || d.dispatchState === 'SENT' || d.dispatchState === 'SETTLED' || d.s === 'PASS' || d.s === 'FAIL' ? 'Sent/settled rate is frozen' : 'Edit current unsent card rate'}
                className="w-full bg-[#0F1722] border border-[rgba(255,255,255,0.12)] text-white font-mono font-black text-xs pl-5 pr-2 py-2.5 rounded-xl outline-none focus:border-[#2AABEE] focus:ring-1 focus:ring-[#2AABEE] placeholder:text-[#4A5A6E] transition-all disabled:cursor-not-allowed disabled:opacity-60"
              />
            </div>
            {String(d.r||'').length>7&&<output className="ledger-full-rate" aria-label={`${market.n} full rate`}>₹{d.r}</output>}
          </div>
        </div>

        {liveSmartStaking?.isSmartStaking && (
          <div className="bg-[#172535] border border-[#00C26F]/30 rounded-xl px-2.5 py-1.5 flex flex-wrap items-center justify-between gap-1 text-[10px] font-mono shadow-sm">
            <div className="flex items-center gap-1.5 font-bold">
              <span className="text-[#00C26F]">🟢 Strong: ₹{liveSmartStaking.strongRate} ({liveSmartStaking.strongDigits.join(', ')})</span>
              <span className="text-[#7A9CB8]">·</span>
              <span className="text-[#79ce9d]">Support: ₹{liveSmartStaking.supportRate} ({liveSmartStaking.supportDigits.join(', ')})</span>
            </div>
            <div className="font-extrabold text-[#FAC748]">
              Total: ₹{liveSmartStaking.totalInvest}
            </div>
          </div>
        )}

        {/* Recovery Rate Quick Apply Pill */}
        {d.recRate && d.recRate !== d.r && !(d.sentRate || d.dispatchState === 'SENT' || d.dispatchState === 'SETTLED' || (!isBacktestCard && (d.s === 'PASS' || d.s === 'FAIL'))) && (
          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => onApplyRecoveryRate?.(type, index)}
              className="bg-[rgba(250,199,72,0.15)] hover:bg-[rgba(250,199,72,0.25)] border border-[rgba(250,199,72,0.35)] text-[#FAC748] px-2.5 py-1 rounded-lg text-[9px] font-black uppercase flex items-center gap-1 active:scale-95 transition-all shadow-sm"
              title="Click to apply exact loss recovery rate"
            >
              <Zap className="w-3 h-3 text-[#FAC748]" />
              <span>Apply Loss Recovery Rate: ₹{d.recRate}</span>
            </button>
          </div>
        )}

        {testResultButton}
        {/* Explicit copy delivery is independent of financial card actions. */}
        {(vipCanEdit || isMaster) && <div className={`ledger-settlement-actions grid ${showSendNow ? 'grid-cols-4' : 'grid-cols-3'} gap-2 pt-1`}>
            {(vipCanEdit || isMaster) && <><button type="button"
              onClick={() => startManualResult('PASS')}
              className="bg-gradient-to-r from-[#00C26F] to-[#00A05E] hover:from-[#00D87B] hover:to-[#00B268] text-white py-2 rounded-xl font-black text-[11px] uppercase tracking-wider active:scale-95 transition-transform shadow-md flex items-center justify-center gap-1"
            >
              <CheckCircle className="w-3.5 h-3.5" /> PASS
            </button>
            <button type="button"
              onClick={() => startManualResult('FAIL')}
              className="bg-gradient-to-r from-[#FF5D5D] to-[#D63838] hover:from-[#FF6E6E] hover:to-[#E54242] text-white py-2 rounded-xl font-black text-[11px] uppercase tracking-wider active:scale-95 transition-transform shadow-md flex items-center justify-center gap-1"
            >
              <XCircle className="w-3.5 h-3.5" /> FAIL
            </button>
            <button type="button"
              onClick={() => onUpdateRecord(type, index, 's', 'SKIP')}
              className="bg-[#232E3C] hover:bg-[#2C3B4E] text-[#8DA6C0] hover:text-white py-2 rounded-xl font-extrabold text-[11px] uppercase tracking-wider active:scale-95 transition-all border border-[rgba(255,255,255,0.08)] flex items-center justify-center gap-1"
            >
              <Forward className="w-3.5 h-3.5" /> SKIP
            </button>
            {showSendNow && <button
              type="button"
              disabled={sendingNow || !hasDigitInput || invalidTokenCard || !(Number(d.sentRate || displayRate || d.r || d.recRate) > 0)}
              onClick={sendCardCopy}
              className="ledger-send-now bg-[#2AABEE]/15 text-[#8DC8FF] py-2 rounded-xl font-black text-[11px] uppercase tracking-wider active:scale-95 transition-transform flex items-center justify-center gap-1 disabled:opacity-40 disabled:cursor-not-allowed"
              title="Send a copy only; normal queue and accounting stay unchanged"
            >{sendingNow ? 'Sending…' : 'Send now'}</button>}</>}
          </div>}
      </div>

      {manualStatusChoice && (vipCanEdit || isMaster) && (
        <div role="dialog" aria-label="Select actual manual result" className="mt-2 rounded-xl border border-white/10 bg-[#111B26] p-3 space-y-2">
          <div className="text-[10px] font-bold text-[#CFDCEB]">Manual {manualStatusChoice} · {type === 'ank' ? 'ANK digit' : type === 'jodi' ? 'JODI pair' : 'PANEL patti'} select karo</div>
          <div className="flex items-center gap-2">
            {Array.from({ length: resultLength }, (_, slot) => (
              <select key={slot} aria-label={`Actual result digit ${slot + 1}`} value={manualDigits[slot]}
                onChange={event => setManualDigits(previous => previous.map((digit, i) => i === slot ? event.target.value : digit))}
                className="rounded border border-white/20 bg-[#18222D] p-2 text-sm text-white">
                <option value="">—</option>
                {Array.from({ length: 10 }, (_, digit) => <option key={digit} value={String(digit)}>{digit}</option>)}
              </select>
            ))}
            {selectedManualResult && <span className="text-[10px] text-[#8DC8FF]">Result: {selectedManualResult}</span>}
          </div>
          {type === 'ank' && <div className="mt-2">
            <label className="flex items-center gap-2 text-[10px] text-[#CFDCEB]"><input type="checkbox" checked={includeManualPanel} onChange={event => setIncludeManualPanel(event.target.checked)} />Actual Panel patti · ANK apne aap niklega</label>
            {includeManualPanel && <div className="mt-1 flex flex-wrap items-center gap-2">
              {manualPanelDigits.map((digit, slot) => <select key={slot} aria-label={`Actual Panel result digit ${slot + 1}`} value={digit} onChange={event => {
                const next = manualPanelDigits.map((value, i) => i === slot ? event.target.value : value);
                setManualPanelDigits(next);
                const actualAnk = panelAnkDigit(next.join(''));
                if (actualAnk) setManualDigits(previous => [actualAnk, ...previous.slice(1)]);
              }} className="rounded border border-white/20 bg-[#18222D] p-2 text-sm text-white"><option value="">—</option>{Array.from({ length: 10 }, (_, value) => <option key={value} value={String(value)}>{value}</option>)}</select>)}
              {selectedManualPanel && <span className="text-[10px] text-[#8DC8FF]">Panel: {selectedManualPanel}</span>}
              {!manualPanelValid && <p className="text-[9px] text-[#FF8A8A]">Actual 3-digit patti ka sum selected ANK se match hona chahiye.</p>}
            </div>}
          </div>}
          {type !== 'jodi' && <p className="mt-1 text-[9px] text-[#8DC8FF]">Same market ka Jodi OPEN/CLOSE ANK results se check hoga.{type === 'ank' ? ' Panel ke liye actual patti zaroori hai.' : ' ANK result bhi is patti se check hoga.'}</p>}
          {selectedManualResult && !manualResultMatchesStatus(type, record.sentDigits || record.d, selectedManualResult, manualStatusChoice) && <p className="text-[9px] text-[#FF8A8A]">Selected result card digits se {manualStatusChoice} match nahi karta.</p>}
          <div className="flex gap-2">
            <button type="button" disabled={!manualResultValid} onClick={() => {
              onUpdateRecord(type, index, 's', { status: manualStatusChoice, actualResult: selectedManualResult, actualPanel: selectedManualPanel });
              setManualStatusChoice(null);
            }} className="rounded-lg bg-[#00A05E] px-3 py-1.5 text-[10px] font-bold text-white disabled:opacity-40">Confirm {manualStatusChoice}</button>
            <button type="button" onClick={() => setManualStatusChoice(null)} className="rounded-lg bg-[#232E3C] px-3 py-1.5 text-[10px] text-[#CFDCEB]">Cancel</button>
          </div>
        </div>
      )}

      {/* 4. Collapsible Tools & Tricks Drawer */}
      {isToolsOpen && (
        <div className="ledger-tools-drawer mt-3 pt-3 border-t border-[rgba(255,255,255,0.08)] space-y-3 bg-[#0F1722] p-3 rounded-xl border border-[rgba(255,255,255,0.05)]">
          {type !== 'ank' && selectionUndoSource(d) && <button type="button"
            onClick={() => onUndoTrick(type, index)}
            disabled={disabled || isScraping || (!vipCanEdit && !isMaster) || isDeliveryFrozen}
            className="text-[#B42318] hover:underline uppercase text-[8px] font-bold"
          >Undo Selection ({d.sourceMode || 'SOURCE'})</button>}
          {/* Tricks T1, T2, T3 Buttons */}
          {type === 'ank' && (
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[9px] font-bold text-[#475569]">
                <span className="flex items-center gap-1 text-[#075985] uppercase tracking-wider font-extrabold">
                  <Sparkles className="w-3 h-3 text-[#075985]" /> Apply Formula Trick:
                </span>
                {selectionUndoSource(d) && (
                  <button type="button"
                    onClick={() => onUndoTrick(type, index)}
                    disabled={disabled || isScraping || (!vipCanEdit && !isMaster) || isDeliveryFrozen}
                    className="text-[#B42318] hover:underline uppercase text-[8px] font-bold"
                  >
                    Undo Selection ({d.trick || (d.positionRule === 'SELF_LEARN' ? 'AI LEARN' : d.positionRule === 'FIRST_CUT' ? 'FIRST CUT' : d.positionRule === 'FIRST_DIGIT_MIRROR' ? (d.firstDigitMirrorCut?.stage===1?'FIRST CUT':'MIRROR DONE') : d.positionRule === 'CUT2' ? 'CUT 2' : d.positionRule === 'FCUT' ? 'Fcut' : d.positionRule === 'LCUT' ? 'Lcut' : d.positionRule === 'CENTER' ? 'CENTER' : d.positionRule === 'LAST_ACTUAL_MIRROR' ? 'ACTUAL + MIRROR' : d.positionRule === 'WEEKDAY' ? 'WD' : d.positionRule === 'RECENT2' ? 'RECENT 2' : d.positionRule === 'RECENT4' ? 'REMOVE 4' : d.positionRule === 'RECENT6' ? 'RECENT 6' : d.positionRule === 'TESLA_369' ? '⚡ 3-6-9' : d.positionRule === 'SNIPER_1' ? '🎯 SNIPER-1' : d.positionRule === 'TRI_CUT' ? 'TRI-CUT' : d.positionRule === 'SSD' ? 'SSD' : d.sourceMode || 'SOURCE')})
                  </button>
                )}
              </div>

              <div className="card-selection-row grid grid-cols-4 sm:grid-cols-8 gap-1">
                <button type="button"
                  title="T1 Odd · 1 3 5 7 9" onClick={() => handleTrick(1)}
                  disabled={disabled || isScraping || (!vipCanEdit && !isMaster) || isDeliveryFrozen}
                  className="text-[9px] bg-[rgba(123,143,255,0.15)] hover:bg-[rgba(123,143,255,0.25)] border border-[rgba(123,143,255,0.3)] text-[#4338CA] py-1.5 rounded-lg font-black active:scale-95 transition-transform"
                >
                  T1
                </button>
                <button type="button"
                  title="T2 Even · 2 4 6 8 0" onClick={() => handleTrick(2)}
                  disabled={disabled || isScraping || (!vipCanEdit && !isMaster) || isDeliveryFrozen}
                  className="text-[9px] bg-[rgba(250,199,72,0.15)] hover:bg-[rgba(250,199,72,0.25)] border border-[rgba(250,199,72,0.3)] text-[#854D0E] py-1.5 rounded-lg font-black active:scale-95 transition-transform"
                >
                  T2
                </button>
                <button type="button"
                  title="T3 Trick" onClick={() => handleTrick(3)}
                  disabled={disabled || isScraping || (!vipCanEdit && !isMaster) || isDeliveryFrozen}
                  className="text-[9px] bg-[rgba(0,194,111,0.15)] hover:bg-[rgba(0,194,111,0.25)] border border-[rgba(0,194,111,0.3)] text-[#166534] py-1.5 rounded-lg font-black active:scale-95 transition-transform"
                >
                  T3
                </button>
                <button type="button" title="Fcut: cut original source positions 1–4 from current digits; preserve earlier cuts" onClick={() => onRecentIndices?.(index,'fcut')} disabled={disabled || isScraping || (!vipCanEdit && !isMaster) || isDeliveryFrozen || !onRecentIndices} className="text-[9px] bg-teal-500/15 border border-teal-400/30 text-teal-800 py-1.5 rounded-lg font-black">Fcut</button>
                <button type="button" title="Lcut: cut original source positions 7–10 from current digits; preserve earlier cuts" onClick={() => onRecentIndices?.(index,'lcut')} disabled={disabled || isScraping || (!vipCanEdit && !isMaster) || isDeliveryFrozen || !onRecentIndices} className="text-[9px] bg-teal-500/15 border border-teal-400/30 text-teal-800 py-1.5 rounded-lg font-black">Lcut</button>
              </div>

              {getTrickHistoryBadges()}
            </div>
          )}

          {/* Auto Schedule Settings */}
          {isMaster && !isVipProfile && (
            <div className="border border-[rgba(0,194,111,0.25)] bg-[rgba(0,194,111,0.05)] rounded-xl p-2.5 space-y-2">
              <div className="flex items-center justify-between text-[10px] font-black text-[#166534] uppercase">
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" /> Auto Schedule Posting
                </span>
                <span className="text-[9px] font-mono text-[#475569]">
                  {schTargets.length ? `${schTargets.length} Targets` : 'Use Saved Targets'}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="time"
                  value={schTime}
                  onChange={(e) => {
                    setSchTime(e.target.value);
                    onScheduleUpdate(type, index, e.target.value, schTargets);
                  }}
                  className="bg-[#F8FAFC] border border-[rgba(0,194,111,0.3)] text-[#166534] text-[11px] font-mono font-bold px-2.5 py-1.5 rounded-lg outline-none focus:border-[#00C26F]"
                />
                <button type="button"
                  onClick={() => setIsTargetModalOpen(true)}
                  className="bg-[rgba(42,171,238,0.12)] hover:bg-[rgba(42,171,238,0.22)] border border-[rgba(42,171,238,0.3)] text-[#075985] text-[9px] font-black uppercase rounded-lg flex items-center justify-center gap-1 active:scale-95 transition-all"
                >
                  <Users className="w-3.5 h-3.5" /> Select Targets ({schTargets.length})
                </button>
              </div>

              <TargetSelectorModal
                isOpen={isTargetModalOpen}
                onClose={() => setIsTargetModalOpen(false)}
                selectedTargets={schTargets}
                marketName={market.n}
                showChannels
                onSaveTargets={(newTargets) => {
                  setSchTargets(newTargets);
                  onScheduleUpdate(type, index, schTime, newTargets);
                }}
              />
            </div>
          )}


        </div>
      )}
    </div>
  );
};


const MemoizedLedgerCard = React.memo(LedgerCardView);

function useStableObject<T extends object>(value: T): T {
  const previous = useRef(value);
  const keys = Object.keys(value) as Array<keyof T>;
  if (keys.length !== Object.keys(previous.current).length || keys.some(key => !Object.is(value[key], previous.current[key]))) {
    previous.current = value;
  }
  return previous.current;
}

/** Keep committed actions fresh while unrelated App status changes skip card work. */
export const LedgerCard: React.FC<LedgerCardProps> = props => {
  const latest = useRef(props);
  useLayoutEffect(() => { latest.current = props; });
  const handlers = useRef<Record<string, (...args: any[]) => any>>({});
  const selectedProfiles = React.useMemo(() => ({ admin1: props.profiles.admin1, [props.activeId]: props.profiles[props.activeId] }), [props.activeId, props.profiles.admin1, props.profiles[props.activeId]]);
  const forwarded = { ...props, profiles: selectedProfiles, market: useStableObject(props.market), record: useStableObject(props.record) };
  for (const [key, value] of Object.entries(props)) {
    if (typeof value !== 'function') continue;
    if (!handlers.current[key]) handlers.current[key] = (...args: any[]) => {
      const current = latest.current[key as keyof LedgerCardProps];
      return typeof current === 'function' ? (current as (...values: any[]) => any)(...args) : undefined;
    };
    (forwarded as any)[key] = handlers.current[key];
  }
  return <MemoizedLedgerCard {...forwarded} />;
};
