import { memo, useEffect, useState, type ReactNode } from 'react';

/**
 * Prepare hidden workspaces progressively instead of mounting every heavy ledger,
 * report and settings screen in the same browser frame.  Only presentation work
 * is deferred: active views mount immediately, mounted views retain their DOM,
 * local drafts and network lifecycle, and all business data stays unchanged.
 */
type PendingPreparation = { run: () => void; cancelled: boolean };
const preparationQueue: PendingPreparation[] = [];
let preparationTimer: ReturnType<typeof setTimeout> | undefined;

function scheduleNextPreparation() {
  if (preparationTimer !== undefined || preparationQueue.length === 0) return;
  preparationTimer = setTimeout(() => {
    preparationTimer = undefined;
    const prepare = () => {
      let next: PendingPreparation | undefined;
      while ((next = preparationQueue.shift())) {
        if (next.cancelled) continue;
        next.run(); // Only ONE hidden screen can request a render per idle slot.
        break;
      }
      scheduleNextPreparation();
    };
    if ('requestIdleCallback' in window) {
      window.requestIdleCallback(prepare, { timeout: 1800 });
    } else {
      prepare();
    }
  }, 300);
}

function queuePreparation(run: () => void) {
  const entry: PendingPreparation = { run, cancelled: false };
  preparationQueue.push(entry);
  scheduleNextPreparation();
  return () => { entry.cancelled = true; };
}

export const PreparedView = memo(function PreparedView({ active, children }: {
  active: boolean;
  children: () => ReactNode;
  freeze?: boolean;
}) {
  const [prepared, setPrepared] = useState(active);
  useEffect(() => {
    if (prepared) return;
    if (active) { setPrepared(true); return; }
    return queuePreparation(() => setPrepared(true));
  }, [active, prepared]);
  return <div hidden={!active} data-prepared-view={prepared || active ? 'ready' : 'pending'}>
    {(prepared || active) ? children() : null}
  </div>;
}, (previous, next) => previous.freeze !== false && next.freeze !== false && !previous.active && !next.active);
