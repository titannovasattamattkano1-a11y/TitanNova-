import { apiUrl } from '../utils/api';
import React, { useState } from 'react';
import { TargetSelectorModal } from './TargetSelectorModal';
import { X, CheckCircle, XCircle, Send, Sparkles, Smartphone, Search, Award } from 'lucide-react';
import { DayRecordStore, UserProfile } from '../types';
import { MARKETS } from '../data/markets';
import { parseMarketResultText, computePassFailUpdates } from '../utils/calculator';

interface ResultAuditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  dayStore: DayRecordStore;
  profile: UserProfile;
  onShowToast: (title: string, msg: string, type: 'success' | 'danger' | 'warning' | 'info') => void;
}

export interface ParsedResult {
  raw: string;
  marketName: string;
  matchedMarketIndex?: number;
  session: 'OPEN' | 'CLOSE' | 'FULL';
  openPanel?: string;
  openAnk?: string;
  jodi?: string;
  closeAnk?: string;
  closePanel?: string;
}

export const ResultAuditorModal: React.FC<ResultAuditorModalProps> = ({
  isOpen,
  onClose,
  dayStore,
  profile,
  onShowToast,
}) => {
  const [rawText, setRawText] = useState('');
  const [selectedMarketName, setSelectedMarketName] = useState(MARKETS[0]?.n || 'SRIDEVI OPEN');
  const [manualOpenPanel, setManualOpenPanel] = useState('');
  const [manualOpenAnk, setManualOpenAnk] = useState('');
  const [manualJodi, setManualJodi] = useState('');
  const [manualCloseAnk, setManualCloseAnk] = useState('');
  const [manualClosePanel, setManualClosePanel] = useState('');

  const [parsed, setParsed] = useState<ParsedResult | null>(null);
  const [auditReport, setAuditReport] = useState<any[]>([]);
  const [reportText, setReportText] = useState('');
  const [isForwarding, setIsForwarding] = useState(false);
  const [targetGroups, setTargetGroups] = useState<string[]>([]);
  const [isTargetModalOpen, setIsTargetModalOpen] = useState(false);

  if (!isOpen) return null;

  const handleRunParse = () => {
    const engine = parseMarketResultText(rawText);
    const res: ParsedResult = {
      raw: rawText,
      marketName: engine.marketHint || engine.marketBase || selectedMarketName,
      session: engine.session,
      openPanel: engine.openPanel || manualOpenPanel,
      openAnk: engine.openAnk || manualOpenAnk,
      jodi: engine.jodi || manualJodi,
      closeAnk: engine.closeAnk || manualCloseAnk,
      closePanel: engine.closePanel || manualClosePanel,
    };
    setParsed(res);
    runAuditFromEngine(engine, res.marketName);
  };

  const handleManualParse = () => {
    const engine = {
      raw: 'Manual Entry',
      marketBase: selectedMarketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase(),
      marketHint: selectedMarketName.toUpperCase(),
      session: 'FULL' as const,
      openPanel: manualOpenPanel,
      openAnk: manualOpenAnk,
      jodi: manualJodi || (manualOpenAnk && manualCloseAnk ? `${manualOpenAnk}${manualCloseAnk}` : ''),
      closeAnk: manualCloseAnk,
      closePanel: manualClosePanel,
    };
    const res: ParsedResult = {
      raw: 'Manual Entry',
      marketName: selectedMarketName,
      session: 'FULL',
      openPanel: manualOpenPanel,
      openAnk: manualOpenAnk,
      jodi: engine.jodi,
      closeAnk: manualCloseAnk,
      closePanel: manualClosePanel,
    };
    setParsed(res);
    runAuditFromEngine(engine, selectedMarketName);
  };

  const runAuditFromEngine = async (engine: ReturnType<typeof parseMarketResultText>, displayName: string) => {
    const auditUpdates = computePassFailUpdates(engine, dayStore, profile.config);
    const reports = auditUpdates.map((u) => ({
      type: u.type.toUpperCase(),
      market: u.marketName,
      digits: u.digits,
      winning: u.winning,
      status: u.status,
      rate: '',
    }));
    setAuditReport(reports);

    const displayResult = `${engine.openPanel || '***'}-${engine.jodi || (engine.openAnk || '*') + (engine.closeAnk || '*')}-${engine.closePanel || '***'}`;
    let msg = `🎰 *${displayName} RESULT*\n`;
    msg += `🎲 *Result:* ${displayResult}\n`;
    if (engine.openAnk) msg += `🔑 *Open:* ${engine.openAnk} (Panel: ${engine.openPanel || 'N/A'})\n`;
    if (engine.jodi) msg += `🔑 *Jodi:* ${engine.jodi}\n`;
    if (engine.closeAnk) msg += `🔑 *Close:* ${engine.closeAnk} (Panel: ${engine.closePanel || 'N/A'})\n`;
    if (reports.length > 0) {
      msg += `\n📊 *Card Audit:*\n`;
      reports.forEach((r) => {
        msg += `• *${r.type}:* ${r.status === 'PASS' ? '🟢 PASS' : '🔴 FAIL'}\n`;
      });
    }
    setReportText(msg);

    // Send the result itself to the backend authority. The old modal calculated
    // updates from only the currently visible profile and then copied those same
    // PASS/FAIL values to every VIP, which was wrong when clients had different
    // digits. The backend now matches every profile/card independently.
    try {
      const normalizedResult = `${displayName} ${engine.openPanel || ''}-${engine.jodi || `${engine.openAnk || ''}${engine.closeAnk || ''}`}-${engine.closePanel || ''}`;
      const rawResult = String(engine.raw || '').trim();
      const resultText = rawResult && rawResult !== 'Manual Entry' ? rawResult : normalizedResult;
      const response = await fetch(apiUrl('/api/bot/auto_audit_result'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resultText }),
      });
      const json = await response.json().catch(() => ({}));
      if (!response.ok || json.status !== 'success') throw new Error(json.message || 'Server audit failed');
      onShowToast('🎯 Result Audited!', `Exact cards checked independently for ${displayName}`, 'success');
    } catch (error: any) {
      onShowToast('❌ Audit Not Applied', error?.message || 'Backend unavailable; no ledger status was changed', 'danger');
    }
  };

  // Dispatch forwarded message to WhatsApp Groups
  const handleForwardToWhatsApp = async () => {
    if (!reportText) return;
    setIsForwarding(true);
    try {
      const res = await fetch(apiUrl('/api/bot/broadcast'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: reportText, targets: targetGroups }),
      });
      const data = await res.json();
      if (data.status === 'success') {
        onShowToast('🚀 Result Queued!', 'Result and audit report queued for the selected WhatsApp / Telegram targets.', 'success');
      } else {
        onShowToast('⚠️ Forward Notice', data.message || 'Check WhatsApp Bot connection.', 'warning');
      }
    } catch (e) {
      onShowToast('❌ Forward Failed', 'Error connecting to bot server.', 'danger');
    } finally {
      setIsForwarding(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-3 animate-fade-in overflow-y-auto">
      <div className="bg-[#1C2733] border border-[rgba(42,171,238,0.3)] rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl space-y-0 my-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#1C2733] via-[#2B3A4D] to-[#1C2733] p-4 border-b border-[rgba(255,255,255,0.08)] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#2AABEE]/20 text-[#2AABEE] border border-[#2AABEE]/30 flex items-center justify-center">
              <Award className="w-5 h-5 animate-bounce" />
            </div>
            <div>
              <h3 className="text-white font-black text-sm uppercase tracking-wide flex items-center gap-2">
                Result Auditor & Auto Matcher
              </h3>
              <p className="text-[#7A9CB8] text-[10px] font-bold">
                Auto Pass/Fail Ledger Verification & Result Forwarding
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-[#2B3A4D] text-[#7A9CB8] hover:text-white border border-[rgba(255,255,255,0.08)] active:scale-95"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-4 max-h-[80vh] overflow-y-auto no-scrollbar">
          {/* SECTION 1: WHATSAPP RESULT PASTE / PARSER */}
          <div className="bg-[#17212B] p-3.5 rounded-xl border border-[rgba(255,255,255,0.08)] space-y-2.5">
            <label className="text-xs font-black text-white uppercase tracking-wider flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#FAC748]" /> 1. Paste WhatsApp / Telegram Result Text
              </span>
              <span className="text-[9px] text-[#2AABEE] font-bold">Auto-Parse Format</span>
            </label>

            <div className="space-y-2">
              <textarea
                value={rawText}
                onChange={(e) => setRawText(e.target.value)}
                placeholder="Paste result from WhatsApp group e.g.:&#10;SRIDEVI OPEN 123-4&#10;KALYAN 123-45-678&#10;TIME BAZAR CLOSE 5-678"
                className="w-full h-20 bg-[#2B3A4D] text-white text-xs font-mono border border-[rgba(255,255,255,0.1)] rounded-xl p-2.5 outline-none focus:border-[#2AABEE] resize-none"
              />
              <button
                onClick={handleRunParse}
                disabled={!rawText.trim()}
                className="w-full bg-[#2AABEE] hover:bg-[#2297D4] text-white py-2.5 rounded-xl font-black text-xs uppercase flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all disabled:opacity-50"
              >
                <Search className="w-4 h-4" /> Auto-Parse Result & Audit Cards
              </button>
            </div>
          </div>

          {/* OR SECTION 2: MANUAL ENTRY SELECTOR */}
          <div className="bg-[#17212B] p-3.5 rounded-xl border border-[rgba(255,255,255,0.08)] space-y-2.5">
            <label className="text-xs font-black text-white uppercase tracking-wider block">
              2. Or Manual Result Entry
            </label>

            <div className="space-y-2">
              <div>
                <span className="text-[10px] text-[#7A9CB8] font-bold block mb-1">Select Market:</span>
                <select
                  value={selectedMarketName}
                  onChange={(e) => setSelectedMarketName(e.target.value)}
                  className="w-full bg-[#2B3A4D] text-white text-xs font-bold border border-[rgba(255,255,255,0.1)] rounded-xl px-3 py-2 outline-none focus:border-[#2AABEE]"
                >
                  {MARKETS.map((m) => (
                    <option key={m.n} value={m.n}>
                      {m.n}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-3 gap-2 text-[10px]">
                <div>
                  <span className="text-[#7A9CB8] font-bold block mb-1">Open Panel</span>
                  <input
                    type="text"
                    value={manualOpenPanel}
                    onChange={(e) => setManualOpenPanel(e.target.value)}
                    placeholder="e.g. 123"
                    className="w-full bg-[#2B3A4D] text-white text-xs font-mono font-bold border border-[rgba(255,255,255,0.1)] rounded-xl px-2.5 py-1.5 outline-none"
                  />
                </div>

                <div>
                  <span className="text-[#7A9CB8] font-bold block mb-1">Open Ank</span>
                  <input
                    type="text"
                    value={manualOpenAnk}
                    onChange={(e) => setManualOpenAnk(e.target.value)}
                    placeholder="e.g. 4"
                    className="w-full bg-[#2B3A4D] text-white text-xs font-mono font-bold border border-[rgba(255,255,255,0.1)] rounded-xl px-2.5 py-1.5 outline-none"
                  />
                </div>

                <div>
                  <span className="text-[#7A9CB8] font-bold block mb-1">Jodi</span>
                  <input
                    type="text"
                    value={manualJodi}
                    onChange={(e) => setManualJodi(e.target.value)}
                    placeholder="e.g. 45"
                    className="w-full bg-[#2B3A4D] text-white text-xs font-mono font-bold border border-[rgba(255,255,255,0.1)] rounded-xl px-2.5 py-1.5 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[10px]">
                <div>
                  <span className="text-[#7A9CB8] font-bold block mb-1">Close Ank</span>
                  <input
                    type="text"
                    value={manualCloseAnk}
                    onChange={(e) => setManualCloseAnk(e.target.value)}
                    placeholder="e.g. 5"
                    className="w-full bg-[#2B3A4D] text-white text-xs font-mono font-bold border border-[rgba(255,255,255,0.1)] rounded-xl px-2.5 py-1.5 outline-none"
                  />
                </div>

                <div>
                  <span className="text-[#7A9CB8] font-bold block mb-1">Close Panel</span>
                  <input
                    type="text"
                    value={manualClosePanel}
                    onChange={(e) => setManualClosePanel(e.target.value)}
                    placeholder="e.g. 678"
                    className="w-full bg-[#2B3A4D] text-white text-xs font-mono font-bold border border-[rgba(255,255,255,0.1)] rounded-xl px-2.5 py-1.5 outline-none"
                  />
                </div>
              </div>

              <button
                onClick={handleManualParse}
                className="w-full bg-[#00C26F] hover:bg-[#00A860] text-white py-2 rounded-xl font-black text-xs uppercase flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
              >
                <CheckCircle className="w-4 h-4" /> Audit Manual Result
              </button>
            </div>
          </div>

          {/* SECTION 3: AUDIT VERIFICATION REPORT */}
          {parsed && (
            <div className="bg-[#17212B] p-3.5 rounded-xl border border-[rgba(42,171,238,0.3)] space-y-3">
              <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.08)] pb-2">
                <span className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-2">
                  <Award className="w-4 h-4 text-[#FAC748]" /> Audit Status: {parsed.marketName}
                </span>
                <span className="text-[10px] font-mono font-bold text-[#2AABEE] bg-[#2AABEE]/20 px-2 py-0.5 rounded-full border border-[#2AABEE]/30">
                  {parsed.openPanel || '***'}-{parsed.jodi || (parsed.openAnk || '*') + (parsed.closeAnk || '*')}-{parsed.closePanel || '***'}
                </span>
              </div>

              {auditReport.length === 0 ? (
                <p className="text-center text-xs text-[#7A9CB8] py-2 font-bold">
                  No active cards set for {parsed.marketName} today in Ledger.
                </p>
              ) : (
                <div className="space-y-2">
                  {auditReport.map((item, idx) => (
                    <div
                      key={idx}
                      className={`p-2.5 rounded-xl border flex items-center justify-between text-xs font-bold ${
                        item.status === 'PASS'
                          ? 'bg-[#00C26F]/15 border-[#00C26F]/40 text-[#00C26F]'
                          : 'bg-[#FF5D5D]/15 border-[#FF5D5D]/40 text-[#FF5D5D]'
                      }`}
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="uppercase text-[9px] font-black px-1.5 py-0.5 rounded bg-black/30">
                            {item.type}
                          </span>
                          <span className="text-white">{item.market}</span>
                        </div>
                        <p className="text-[10px] text-[#7A9CB8] font-mono">
                          Card Digits: [{item.digits}]
                        </p>
                      </div>

                      <div className="text-right">
                        <span className="flex items-center gap-1 font-black text-xs uppercase justify-end">
                          {item.status === 'PASS' ? (
                            <>
                              <CheckCircle className="w-4 h-4" /> PASS (HIT!)
                            </>
                          ) : (
                            <>
                              <XCircle className="w-4 h-4" /> FAIL (MISS)
                            </>
                          )}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* WHATSAPP REPORT BROADCAST */}
              <div className="pt-2 border-t border-[rgba(255,255,255,0.08)] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-[#7A9CB8] uppercase flex items-center gap-1">
                    <Smartphone className="w-3.5 h-3.5 text-[#2AABEE]" /> WhatsApp / Telegram Result Broadcast Report
                  </span>
                  <button
                    onClick={() => setIsTargetModalOpen(true)}
                    className="text-[9px] text-[#2AABEE] hover:underline font-bold"
                  >
                    Select Target Groups ({targetGroups.length})
                  </button>
                </div>

                <textarea
                  value={reportText}
                  onChange={(e) => setReportText(e.target.value)}
                  className="w-full h-32 bg-[#2B3A4D] text-white text-[11px] font-mono border border-[rgba(255,255,255,0.1)] rounded-xl p-2.5 outline-none focus:border-[#2AABEE] resize-none"
                />

                <button
                  onClick={handleForwardToWhatsApp}
                  disabled={isForwarding || !reportText}
                  className="w-full bg-[#00C26F] hover:bg-[#00A860] text-white py-2.5 rounded-xl font-black text-xs uppercase flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  {isForwarding ? 'Queueing...' : 'Send Result & Audit Report to Selected Targets'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <TargetSelectorModal
        isOpen={isTargetModalOpen}
        onClose={() => setIsTargetModalOpen(false)}
        selectedTargets={targetGroups}
        showChannels
        onSaveTargets={(targets) => setTargetGroups(targets)}
      />
    </div>
  );
};
