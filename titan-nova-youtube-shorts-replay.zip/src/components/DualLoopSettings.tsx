import React, {useState} from 'react';
import {Check, ChevronDown, Save} from 'lucide-react';
import type {GameType, UserProfile} from '../types';
import {getEffectiveMarkets, getEffectiveBaseMarkets} from '../data/markets';
import {LOOP_IDS, activeLoopIds, loopSettingsForDate, loopAssignmentKey, normalizeDualLoops, gameAccountLimits, LOOP_GAMES, type DualLoopConfig, type LoopId} from '../utils/dualLoops';

type SaveResult = string | undefined | Promise<string | undefined>;
interface Props {
  profile: UserProfile;
  date: string;
  canEdit: boolean;
  onSave: (config: DualLoopConfig, archive: boolean) => SaveResult;
  onToggle?: (enabled: boolean) => SaveResult;
  onApplyYesterday?: (config: DualLoopConfig) => string | undefined;
}
export const DualLoopSettings: React.FC<Props> = ({profile, date, canEdit, onSave, onToggle}) => {
  const saved = loopSettingsForDate(profile, date);
  const [draft, setDraft] = useState<DualLoopConfig>(() => ({
    ...(saved || normalizeDualLoops({enabled:false, startsOn:date, loopCount:1, assignments:{}, loops:{}}, profile.config)!),
    independentAccounts:true,
  }));
  const [selected, setSelected] = useState<LoopId>('L1');
  const [game, setGame] = useState<GameType>('ank');
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [pendingMode, setPendingMode] = useState<boolean | null>(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const ids = activeLoopIds(draft);
  const accountId = ids.includes(selected) ? selected : 'L1';
  const account = draft.loops[accountId];
  const gameName=game==='pannel'?'PANEL':game.toUpperCase(),limits=gameAccountLimits(account,game);
  const enabled = pendingMode ?? saved?.enabled ?? false;
  const markets = game === 'jodi' ? getEffectiveBaseMarkets(profile.config) : getEffectiveMarkets(profile.config);
  const field = 'mt-1 min-h-11 w-full min-w-0 rounded-lg border border-white/10 bg-[#15212D] px-3 text-sm text-white outline-none focus:border-sky-400 disabled:opacity-50';
  const updateAccount = (values: Partial<typeof account>) => {
    setDraft({...draft, loops:{...draft.loops, [accountId]:{...account, ...values}}}); setNotice('');
  };
  const updateLimits=(values:Partial<typeof limits>)=>updateAccount({gameAccounts:{...account.gameAccounts,[game]:{...limits,...values}}});
  const toggle = async (value:boolean) => {
    if(busy || !canEdit)return;
    setBusy(true); setPendingMode(value); setError(''); setNotice('');
    try {
      const message = onToggle ? await onToggle(value) : await onSave({...draft, enabled:value, startsOn:date}, false);
      if(message)throw new Error(message);
      setNotice(`${value?'ON':'OFF'} saved · continues on following days.`);
    } catch(e) { setError(e instanceof Error ? e.message : 'Save failed. Please retry.'); }
    finally { setBusy(false); setPendingMode(null); }
  };
  const save = async () => {
    if(busy || !canEdit)return;
    for(const id of ids) {
      const a=draft.loops[id];
      if(LOOP_GAMES.flatMap(type=>{const limits=gameAccountLimits(a,type);return [limits.capital,limits.dayTarget,a[type].tgt];}).some(n=>!Number.isFinite(n)||n<0)) {
        setError('Enter zero or more for capital and targets.'); return;
      }
    }
    setBusy(true); setError(''); setNotice('');
    try {
      const message=await onSave({...draft, enabled, independentAccounts:true, startsOn:date}, false);
      if(message)throw new Error(message);
      setNotice('Setup saved.');
    } catch(e) { setError(e instanceof Error ? e.message : 'Save failed. Please retry.'); }
    finally { setBusy(false); }
  };
  return <section aria-label="Custom loop accounts" className="overflow-hidden rounded-xl border border-white/10 bg-[#1C2936]">
    <div className="flex items-center justify-between gap-4 px-4 py-4">
      <div className="min-w-0"><h2 className="text-sm font-semibold text-white">Custom loop</h2><p className="mt-1 text-xs text-slate-400">Your markets. Separate accounts.</p></div>
      <label className="flex shrink-0 items-center gap-2 text-xs font-semibold text-slate-200">
        <span>{busy&&pendingMode!==null?'Saving…':enabled?'ON':'OFF'}</span>
        <span className="relative flex h-6 w-11 items-center">
          <input aria-label="Enable custom loop accounts" aria-busy={busy} type="checkbox" role="switch" checked={enabled} disabled={!canEdit||busy} onChange={e=>void toggle(e.target.checked)} className="peer absolute inset-0 z-10 h-full w-full cursor-pointer opacity-0 disabled:cursor-wait"/>
          <span className="h-6 w-11 rounded-full bg-slate-600 transition-colors peer-checked:bg-sky-500 peer-disabled:opacity-50 peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-sky-300"/>
          <span className="pointer-events-none absolute left-1 h-4 w-4 rounded-full bg-white transition-transform peer-checked:translate-x-5"/>
        </span>
      </label>
    </div>
    <div className="border-t border-white/5 px-4 py-2 text-[11px] text-slate-400">From {date} · ON/OFF continues until you change it.</div>
    {!enabled&&!editing&&<div className="border-t border-white/5 px-4 py-4">
      <p className="text-xs text-slate-400">Custom recovery is off. Your saved setup is kept.</p>
      <button type="button" disabled={!canEdit||busy} className="mt-3 min-h-10 rounded-lg border border-white/15 px-3 text-xs font-medium text-slate-200 disabled:opacity-50" onClick={()=>setEditing(true)}>Edit saved setup</button>
    </div>}
    {(enabled||editing)&&<div className="space-y-4 border-t border-white/5 p-4">
      <div className="flex items-center justify-between gap-3"><h3 className="text-xs font-semibold text-slate-200">Accounts</h3>
        <label className="flex items-center gap-2 text-xs text-slate-400">Count
          <select aria-label="Recovery loop count" value={draft.loopCount||1} disabled={!canEdit||busy} onChange={e=>{setDraft(normalizeDualLoops({...draft,loopCount:Number(e.target.value)},profile.config)!);setNotice('');}} className="min-h-10 rounded-lg border border-white/10 bg-[#15212D] px-3 text-sm text-white">
            {LOOP_IDS.map((id,i)=><option key={id} value={i+1}>{i+1}</option>)}
          </select>
        </label>
      </div>
      {ids.length>1&&<div className="flex gap-2 overflow-x-auto pb-1" role="group" aria-label="Choose account">
        {ids.map(id=><button key={id} type="button" aria-pressed={accountId===id} onClick={()=>setSelected(id)} className={`min-h-10 shrink-0 rounded-lg px-3 text-xs font-medium ${accountId===id?'bg-sky-500/15 text-sky-200 ring-1 ring-sky-400/40':'bg-white/5 text-slate-400'}`}>{draft.loops[id].name||id}</button>)}
      </div>}
      <div className="space-y-3" aria-label={`${accountId} settings`}>
        <label className="block text-xs text-slate-400">Account name<input aria-label={`${accountId} name`} className={field} maxLength={40} value={account.name||''} placeholder={`Account ${accountId.slice(1)}`} disabled={!canEdit||busy} onChange={e=>updateAccount({name:e.target.value})}/></label>
        <div className="flex rounded-lg bg-[#15212D] p-1" role="group" aria-label="Account game">
          {LOOP_GAMES.map(type=><button key={type} type="button" aria-pressed={game===type} onClick={()=>setGame(type)} className={`min-h-10 flex-1 rounded-md text-xs ${game===type?'bg-white/10 text-white':'text-slate-400'}`}>{type==='pannel'?'PANEL':type.toUpperCase()}</button>)}
        </div>
        <div className="grid grid-cols-2 gap-3">
          <label className="text-xs text-slate-400">{gameName} Capital ₹<input aria-label={`${accountId} ${game} capital`} className={field} type="number" inputMode="decimal" min={0} value={limits.capital} disabled={!canEdit||busy} onChange={e=>updateLimits({capital:Number(e.target.value)})}/></label>
          <label className="text-xs text-slate-400">Daily profit goal ₹<input aria-label={`${accountId} ${game} dayTarget`} className={field} type="number" inputMode="decimal" min={0} value={limits.dayTarget} disabled={!canEdit||busy} onChange={e=>updateLimits({dayTarget:Number(e.target.value)})}/></label>
        </div>
        <label className="block text-xs text-slate-400">{gameName} Profit per card ₹<input aria-label={`${accountId} ${game} target`} className={field} type="number" inputMode="decimal" min={0} value={account[game].tgt} disabled={!canEdit||busy} onChange={e=>updateAccount({[game]:{...account[game],tgt:Number(e.target.value)}})}/></label>
        <p className="text-[11px] text-slate-500">ANK, JODI and PANEL have separate capital, profit and stops. Goal 0 = no profit stop.</p>
      </div>
      <details className="rounded-lg border border-white/10">
        <summary className="flex min-h-11 cursor-pointer list-none items-center justify-between px-3 text-xs font-medium text-slate-200">Market assignments<ChevronDown className="h-4 w-4 text-slate-500"/></summary>
        <div className="border-t border-white/5 p-3">
          <p className="mb-2 text-xs text-slate-400">{gameName} market assignments</p>
          <div className="max-h-72 overflow-y-auto">{markets.map(m=><label key={m.n} className="flex min-h-12 items-center justify-between gap-3 border-b border-white/5 py-1 text-[11px] text-slate-300">
            <span className="min-w-0">{m.n}</span>
            <select aria-label={`${game} ${m.n} loop`} className="min-h-10 w-28 shrink-0 rounded-lg bg-[#15212D] px-2 text-xs text-slate-200" value={draft.assignments[loopAssignmentKey(game,m.n)]||'L1'} disabled={!canEdit||busy} onChange={e=>{setDraft({...draft,assignments:{...draft.assignments,[loopAssignmentKey(game,m.n)]:e.target.value as LoopId}});setNotice('');}}>
              {ids.map(id=><option key={id} value={id}>{draft.loops[id].name||id}</option>)}
            </select>
          </label>)}</div>
        </div>
      </details>
      <button aria-label="Save custom loop setup" type="button" disabled={!canEdit||busy} onClick={()=>void save()} className="flex min-h-11 w-full items-center justify-center gap-2 rounded-lg bg-sky-500 text-sm font-semibold text-white hover:bg-sky-400 disabled:opacity-50"><Save className="h-4 w-4"/>{busy?'Saving…':'Save setup'}</button>
      <details className="text-[11px] text-slate-400"><summary className="cursor-pointer py-1">How it works</summary><p className="mt-2 leading-relaxed">Only this game in the account reaching its profit goal or capital limit stops. Other accounts keep running. Other games keep running. Sent bets keep their recorded account. Capital 0 means no funds. Settings continue from the selected date until a later saved change.</p></details>
    </div>}
    {error&&<p role="alert" className="border-t border-white/5 px-4 py-3 text-xs text-red-300">{error}</p>}
    {notice&&<p role="status" className="flex items-center gap-2 border-t border-white/5 px-4 py-3 text-xs text-emerald-300"><Check className="h-3.5 w-3.5"/>{notice}</p>}
  </section>;
};
