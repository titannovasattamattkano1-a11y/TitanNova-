import React from 'react';
import type { DayMarketRecord } from '../types';
import { getScrapeResultIndex, getScrapeSource } from '../utils/scrapeProvenance';

/** Display-only provenance; never changes the selected digits or settlement. */
export const ScrapeSourceDetails: React.FC<{ record: Partial<DayMarketRecord> }> = ({ record }) => {
  const source = getScrapeSource(record);
  const mode = source?.mode || record.sentSourceMode || record.sourceMode;
  if (!mode || mode === 'MANUAL') return null;
  const index = getScrapeResultIndex(record);
  const name = mode === 'AUTO' ? 'AUTO · Recent → Old' : mode === 'WEEKDAY' ? 'DAY · Bottom → Top' : mode.replaceAll('_', ' ');
  return (
    <div className="mt-1.5" aria-label="Original scraping source and available indices">
      <div className="flex flex-wrap items-center justify-between gap-1 text-[9px] font-bold">
        <span className="text-[#8DC8FF]">{name}</span>
        {index === undefined && <span className="text-[8px] text-[#8294A8]">Result index: —</span>}
      </div>
      {source ? (
        <div className="mt-1 grid grid-cols-10 gap-1">
          {source.digits.split(', ').map((digit, position) => (
            <span key={position} title={`Original index ${position + 1}: digit ${digit}`}
              className={`relative flex min-w-0 flex-col items-center rounded border py-0.5 ${index === position + 1 ? record.s === 'PASS' ? 'border-[#20E093]/50 bg-[#20E093]/10 text-[#20E093]' : 'border-[#FF8A8A]/50 bg-[#FF8A8A]/10 text-[#FF8A8A]' : 'border-white/10 text-[#CFDCEB]'}`}>
              <span className="text-[11px] font-black leading-4">{digit}</span>
              <span className="text-[7px] leading-3 opacity-60">#{position + 1}</span>
              {index === position + 1 && <span className="text-[6px] font-bold leading-2" aria-label={`${record.s} · digit ${digit} · index #${index}`}>{record.s}</span>}
            </span>
          ))}
        </div>
      ) : <div className="mt-1 text-[9px] text-[#8294A8]">Original 10-digit source unavailable</div>}
    </div>
  );
};
