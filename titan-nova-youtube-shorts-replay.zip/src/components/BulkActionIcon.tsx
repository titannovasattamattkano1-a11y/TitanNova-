import { Satellite, CalendarDays, GitMerge, Layers3, Shuffle, Sparkles, ChartNoAxesCombined, MapPin, Scissors, RotateCcw, Trash2, History, Link2, WandSparkles } from 'lucide-react';

/** Decorative bulk-control icons; labels, numbering and action handlers remain authoritative. */
const icons: Record<string, any> = {
  section: Layers3, scrape: Satellite, weekday: CalendarDays, open_auto_close_day: GitMerge,
  combo: Link2, day_combo: Shuffle, smart: Sparkles, market_model: ChartNoAxesCombined,
  pair_combo: Link2, mssd: Sparkles, freq_10: ChartNoAxesCombined, freq_10_combo: ChartNoAxesCombined, dynamic_4ank: Sparkles,
  positions: MapPin, match: GitMerge, cut: Scissors, mix: Shuffle, yday: History,
  trick: WandSparkles, undo: RotateCcw, clear: Trash2, history: ChartNoAxesCombined,
};
export function BulkActionIcon({kind}:{kind: string}) {
  const Icon = icons[kind] || Sparkles;
  return <Icon aria-hidden="true" focusable="false" className="bulk-action-icon" />;
}
