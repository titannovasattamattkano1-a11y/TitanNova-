import { Send, ShieldCheck, ArrowDownLeft, ArrowUpRight, RefreshCw, LogOut, KeyRound, Activity, Clock, Smartphone, ChevronRight } from 'lucide-react';
import { useEffect, useState } from 'react';
import { telegramApi, telegramKey } from '../utils/telegramApi';
import { apiUrl } from '../utils/api';
import { TargetSelectorModal } from './TargetSelectorModal';
import { isTelegramTarget } from '../utils/targetNormalization';
import { storeTelegramKey } from '../utils/telegramCredentialStorage';

export function TelegramGatewayView({visible=true}:{visible?:boolean}) {
  const [key, setKey] = useState(telegramKey);
  const [apiId, setApiId] = useState('');
  const [apiHash, setApiHash] = useState('');
  const [phone, setPhone] = useState('');
  const [answer, setAnswer] = useState('');
  const [status, setStatus] = useState<any>({ phase: 'offline', logs: [] });
  const [error, setError] = useState('');
  const [storageWarning, setStorageWarning] = useState('');
  const [busy, setBusy] = useState(false);
  const [picker, setPicker] = useState<'source' | 'target' | null>(null);
  const [sources, setSources] = useState<string[]>([]);
  const [targets, setTargets] = useState<string[]>([]);
  const load = async () => {
    try {
      setStatus(await telegramApi('status'));
      const response = await fetch(apiUrl('/api/bot/config'));
      const json = await response.json();
      if (!response.ok || json.status !== 'success') throw new Error('Source configuration unavailable');
      setSources((json.config.resultReadGroups || []).filter(isTelegramTarget));
      setTargets((json.config.targetGroups || []).filter(isTelegramTarget));
    } catch (e: any) { setError(e.message); }
  };
  useEffect(() => { if (!visible) return; void load(); const timer = setInterval(() => { if(document.visibilityState !== 'hidden') void load(); }, 3000); return () => clearInterval(timer); }, [visible]);
  const action = async (route: string, body: any = {}) => {
    setBusy(true); setError('');
    try { await telegramApi(route, body); setAnswer(''); if (route === 'login') setApiHash(''); await load(); }
    catch (e: any) { setError(e.message); }
    finally { setBusy(false); }
  };
  const saveTargets = async (values: string[]) => {
    try {
      const field = picker === 'source' ? 'resultReadGroups' : 'targetGroups';
      // Dedicated merge endpoint preserves the other platform's selections.
      const result = await telegramApi('selection', { field, values });
      if (result.status !== 'success') throw new Error(result.message);
      await load();
    } catch (e: any) { setError(e.message); }
  };
  const input = 'gateway-input';
  const button = 'gateway-button gateway-button-primary';
  return <section className="gateway-telegram-body">
    <div className="gateway-connection-heading">
      <div className="gateway-connection-title"><span className="gateway-platform-icon telegram"><Send size={22} /></span><div><h2>Telegram connection</h2><p>{status.connected ? `Connected as ${status.account}` : 'Manage your Telegram account connection'}</p></div></div>
      <span className={`gateway-status-badge ${status.connected ? 'is-online' : ''}`}><span />{status.connected ? 'Connected' : status.phase}</span>
    </div>
    <div className="gateway-summary-grid">
      <div className="gateway-summary"><span><Activity size={16} />Connection</span><strong className={status.connected ? 'gateway-online' : ''}>{status.connected ? 'Connected' : status.phase}</strong><small>{status.account || 'No connected account'}</small></div>
      <div className="gateway-summary"><span><ArrowDownLeft size={16} />Incoming sources</span><strong>{sources.length}</strong><small>Result monitoring</small></div>
      <div className="gateway-summary"><span><ArrowUpRight size={16} />Sending targets</span><strong>{targets.length}</strong><small>Configured destinations</small></div>
      <div className="gateway-summary"><span><Clock size={16} />Last sync</span><strong className="gateway-sync-value">{status.lastSync ? new Date(status.lastSync).toLocaleTimeString() : 'Not synced'}</strong><small>Groups, channels & chats</small></div>
    </div>
    {(error || status.error) && <p role="alert" className="gateway-alert gateway-alert-error">{error || status.error}</p>}
    {status.warning && <p role="status" className="gateway-alert">{status.warning}</p>}
    {storageWarning && <p role="alert" className="gateway-alert">{storageWarning}</p>}
    <div className="gateway-telegram-grid">
      <div className="gateway-panel gateway-account-panel">
        <div className="gateway-panel-heading"><Smartphone size={18} /><div><h3>Account access</h3><p>Connect and verify your Telegram account.</p></div></div>
        <details className="gateway-key-details"><summary><KeyRound size={16} /> Telegram control key <ChevronRight size={15} /></summary>
          <div className="gateway-details-content">
            <p className="gateway-help">Key is browser mein saved rahegi, app dobara kholne par bhi. Wahi app URL use karein.</p>
            <code className="gateway-command">cat ~/titan_data/titan_telegram_control_token</code>
            <label className="gateway-field-label" htmlFor="telegram-control-key">Control key</label>
            <input id="telegram-control-key" aria-label="Telegram control key" type="password" className={input} value={key} onChange={e => setKey(e.target.value)} autoComplete="off" />
            <button className={button} onClick={() => {
              const persisted = storeTelegramKey(key);
              setStorageWarning(persisted ? '' : 'Browser permanent storage allow nahi kar raha. Normal browser mode mein storage enable karein; key dobara maang sakta hai.');
              setError(''); void load();
            }}><ShieldCheck size={16} /> Unlock Telegram</button>
            <button className="gateway-text-button" onClick={() => { storeTelegramKey(''); setKey(''); setStorageWarning(''); setError('Is browser se control key hata di. Telegram account server par connected reh sakta hai.'); }}>Forget key on this browser</button>
          </div>
        </details>
        {status.phase === 'offline' && <div className="gateway-account-form">
          <p className="gateway-help">API ID aur API hash <a href="https://my.telegram.org/apps" target="_blank" rel="noreferrer">my.telegram.org/apps</a> se lein. Existing Telegram account se login karein.</p>
          <label className="gateway-field-label" htmlFor="telegram-api-id">API ID</label>
          <input id="telegram-api-id" aria-label="API ID" placeholder="Enter API ID" className={input} inputMode="numeric" value={apiId} onChange={e => setApiId(e.target.value)} />
          <label className="gateway-field-label" htmlFor="telegram-api-hash">API hash</label>
          <input id="telegram-api-hash" aria-label="API hash" placeholder="Enter API hash" type="password" autoComplete="off" className={input} value={apiHash} onChange={e => setApiHash(e.target.value)} />
          <label className="gateway-field-label" htmlFor="telegram-phone">Phone number</label>
          <input id="telegram-phone" aria-label="Telegram phone" placeholder="Phone with country code" className={input} value={phone} onChange={e => setPhone(e.target.value)} />
          <button disabled={busy} className={button} onClick={() => void action('login', { apiId: Number(apiId), apiHash, phone })}><Send size={16} />{busy ? 'Connecting…' : 'Login to Telegram'}</button>
        </div>}
        {['code', 'password', 'email', 'email-code'].includes(status.phase) && <div className="gateway-account-form">
          <p className="gateway-help">Complete the verification requested by Telegram.</p>
          <input aria-label={`Telegram ${status.phase}`} placeholder={`Telegram ${status.phase === 'password' ? '2FA password' : status.phase}`} autoComplete="off" type={status.phase === 'email' ? 'email' : 'password'} className={input} value={answer} onChange={e => setAnswer(e.target.value)} />
          <button disabled={busy} className={button} onClick={() => void action('answer', { value: answer })}>Verify</button>
        </div>}
        {status.phase !== 'offline' && <div className="gateway-account-actions">
          <button disabled={busy || !status.connected} className={button} onClick={() => void action('sync')}><RefreshCw size={16} /> Sync Groups / Channels / Chats</button>
          <button disabled={busy} className="gateway-button gateway-button-danger" onClick={() => void action('logout')}><LogOut size={16} /> Logout</button>
        </div>}
      </div>
      <div className="gateway-panel gateway-routing-panel">
        <div className="gateway-panel-heading"><Activity size={18} /><div><h3>Result routing</h3><p>Choose where results come from and where they go.</p></div></div>
        <div className="gateway-route-row"><span className="gateway-route-icon"><ArrowDownLeft size={20} /></span><div><h4>Incoming sources</h4><p>Groups and channels to monitor</p></div><strong>{sources.length}</strong></div>
        <button className="gateway-button gateway-button-secondary" onClick={() => setPicker('source')}>Select incoming sources <ChevronRight size={16} /></button>
        <div className="gateway-route-divider" />
        <div className="gateway-route-row"><span className="gateway-route-icon"><ArrowUpRight size={20} /></span><div><h4>Sending targets</h4><p>Destinations for forwarded results</p></div><strong>{targets.length}</strong></div>
        <button className="gateway-button gateway-button-secondary" onClick={() => setPicker('target')}>Select sending targets <ChevronRight size={16} /></button>
        <div className="gateway-routing-note"><ShieldCheck size={17} /><p>VIP delivery is independent<span>Incoming Sources / Sending Targets sirf normal result monitoring-forwarding ke liye hain. VIP cards apne VIP profile me saved WhatsApp / Telegram destination par independently send hote hain; global Sending Targets (0) VIP delivery ko block nahi karta.</span></p></div>
      </div>
    </div>
    <TargetSelectorModal isOpen={!!picker} onClose={() => setPicker(null)} selectedTargets={picker === 'source' ? sources : targets} onSaveTargets={values => void saveTargets(values)} incomeSourceOnly={picker === 'source'} showChannels platformOnly="telegram" />
    <details className="gateway-panel gateway-log-details"><summary><Activity size={18} /><span>Delivery & connection activity<small>Telegram account events and delivery logs</small></span><ChevronRight size={17} /></summary>
      <div className="gateway-log-list">
        {(status.logs || []).length === 0 && <p className="gateway-empty">No activity recorded yet.</p>}
        {(status.logs || []).map((row: any, i: number) => <div key={i} className="gateway-log-row"><time>{new Date(row.time).toLocaleTimeString()}</time><p>{row.message}</p></div>)}
      </div>
    </details>
  </section>;
}
