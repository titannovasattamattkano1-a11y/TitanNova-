import {SOURCE_HISTORY_POLICY} from '../utils/sourceWindowHistory';
import { useEffect, useRef, useState } from 'react';
import { apiUrl } from '../utils/api';
import { businessDateIST } from '../utils/businessDate';
import { rangeDates, rangeProgress, RANGE_WEEKDAYS, RANGE_SELECTIONS, type RangeSelection, type RangeMode, type RangeOptions } from '../utils/rangeBacktest';
import type { AppState, GameType } from '../types';

// Bound the full response, including JSON body reads, so polling can recover after a stalled connection.
async function rangeFetchJson(url:string,init?:RequestInit){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),20000);
  try{const response=await fetch(url,{...init,signal:controller.signal});const json=await response.json();return {response,json};}
  catch(error:any){if(error?.name==='AbortError')throw new Error('Connection timed out. Checking saved run again; do not start a duplicate trial.');throw error;}
  finally{clearTimeout(timer);}
}
function readDraft(profileId:string):Partial<RangeOptions>{
  try{const value=JSON.parse(localStorage.getItem(`titan-range-draft:${profileId}`)||'{}');
    return {from:/^\d{4}-\d{2}-\d{2}$/.test(value.from)?value.from:undefined,to:/^\d{4}-\d{2}-\d{2}$/.test(value.to)?value.to:undefined,
      mode:modes.some(([v])=>v===value.mode)?value.mode:undefined,selection:RANGE_SELECTIONS.some(([v])=>v===value.selection)?value.selection:undefined,
      games:Array.isArray(value.games)?value.games.filter((v:string)=>['ank','jodi','pannel'].includes(v)):undefined,
      markets:Array.isArray(value.markets)?value.markets.filter((v:unknown)=>typeof v==='string'):undefined,
      weekdays:Array.isArray(value.weekdays)?value.weekdays.filter((v:number)=>Number.isInteger(v)&&v>=0&&v<=6):undefined,
      autoResultParity:value.autoResultParity===true,
      dailyStopLoss:typeof value.dailyStopLoss==='number'&&Number.isFinite(value.dailyStopLoss)&&value.dailyStopLoss>=0?value.dailyStopLoss:0,
      dailyProfitTarget:typeof value.dailyProfitTarget==='number'&&Number.isFinite(value.dailyProfitTarget)&&value.dailyProfitTarget>=0?value.dailyProfitTarget:0,resetAfterThreeFails:value.resetAfterThreeFails===true,backtestMaxStake:typeof value.backtestMaxStake==='number'&&Number.isFinite(value.backtestMaxStake)&&value.backtestMaxStake>=0?value.backtestMaxStake:0,
      recentHistorySeed:typeof value.recentHistorySeed==='boolean'?value.recentHistorySeed:undefined,fresh:typeof value.fresh==='boolean'?value.fresh:undefined,initialTrick:[0,1,2].includes(value.initialTrick)?value.initialTrick:undefined};
  }catch{return {};}
}
const clockText=(value:number)=>value?new Date(value).toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit',second:'2-digit'}):'—';
const modes:Array<[RangeMode,string]>=[['scrape','AUTO · Recent → Old'],['weekday','DAY · Same weekday'],['combo','COMBO'],['day_combo','DAY COMBO'],['smart','SMART'],['market_model','PAIR FOLLOW'],['pair_combo','PAIR COMBO'],['freq_10','10D FREQ · Skip Recent 1 (10 Draws)'],['freq_10_combo','WK O+C FREQ · Market Weekdays (7D/6D/5D)'],['open_auto_close_day','OPEN Auto / CLOSE Day']];
const money=(n:number)=>`₹${Number(n||0).toLocaleString('en-IN',{maximumFractionDigits:2})}`;
const signed=(n:number)=>`${n<0?'-':'+'}${money(Math.abs(n||0))}`;
export function RangeBacktestPanel({visible=true,profileId,beforeRun,onArchive,onOpenDate,onOpenRunProfile,disabled,autoRemoveResultDigit,autoRemoveResultMirror=false,autoRemoveResultUnique3=false,onAutoRemoveChange,marketChoices}:{visible?:boolean;marketChoices:string[];autoRemoveResultDigit:boolean;autoRemoveResultMirror?:boolean;autoRemoveResultUnique3?:boolean;onAutoRemoveChange:(enabled:boolean)=>void;profileId:string;beforeRun:()=>Promise<void>;onArchive:(state:AppState)=>void;onOpenDate:(date:string)=>void;onOpenRunProfile:(profileId:string)=>void;disabled:boolean}){
  const today=businessDateIST(),yesterday=new Date(Date.parse(today)-86400000).toISOString().slice(0,10);
  const [draft]=useState(()=>readDraft(profileId));
  const restoreServerSetup=useRef(!draft.from);
  const [connectedAt,setConnectedAt]=useState(0);
  const [open,setOpen]=useState(true),[from,setFrom]=useState(draft.from||yesterday),[to,setTo]=useState(draft.to||yesterday),[mode,setMode]=useState<RangeMode>(draft.mode||'scrape'),[selection,setSelection]=useState<RangeSelection>(draft.selection||'first4');
  const [games,setGames]=useState<GameType[]>(draft.games||['ank']),[preview,setPreview]=useState<any>(null),[job,setJob]=useState<any>(null),[error,setError]=useState(''),[working,setWorking]=useState(false),[reportGame,setReportGame]=useState<GameType>('ank');
  const [notice,setNotice]=useState('');
  const [recentHistorySeed,setRecentHistorySeed]=useState(draft.recentHistorySeed!==false);
  const [initialTrick,setInitialTrick]=useState<0|1|2>(draft.initialTrick??1);
  const [resetAfterThreeFails,setResetAfterThreeFails]=useState(draft.resetAfterThreeFails===true);
  const [autoResultParity,setAutoResultParity]=useState(draft.autoResultParity===true);
  const [dailyStopLoss,setDailyStopLoss]=useState(draft.dailyStopLoss||0);
  const [stopLossEnabled,setStopLossEnabled]=useState((draft.dailyStopLoss||0)>0);
  const [dailyProfitTarget,setDailyProfitTarget]=useState(draft.dailyProfitTarget||0);
  const [backtestMaxStake,setBacktestMaxStake]=useState(draft.backtestMaxStake||0);
  const [fresh,setFresh]=useState(draft.fresh??true);
  const [selectedMarkets,setSelectedMarkets]=useState<string[]|undefined>(draft.markets);
  const [marketSearch,setMarketSearch]=useState('');
  const [weekdays,setWeekdays]=useState<number[]>(draft.weekdays||[0,1,2,3,4,5,6]);
  const requestEpoch=useRef(0),mutationInFlight=useRef(false);
  const [detailsLoading,setDetailsLoading]=useState(false);
  const lastCommit=useRef(''),callbacks=useRef({onArchive});callbacks.current={onArchive};
  const options:RangeOptions={profileId,from,to,mode,selection:autoResultParity?'result_parity':selection,games,markets:selectedMarkets,weekdays,fresh,initialTrick,recentHistorySeed,autoResultParity,dailyStopLoss:stopLossEnabled?dailyStopLoss:0,dailyProfitTarget,resetAfterThreeFails,backtestMaxStake:resetAfterThreeFails?backtestMaxStake:0};
  const draftSignature=JSON.stringify(options);
  useEffect(()=>{try{localStorage.setItem(`titan-range-draft:${profileId}`,draftSignature);}catch{}},[draftSignature,profileId]);
  const signature=JSON.stringify({...options,autoRemoveResultDigit,autoRemoveResultMirror,autoRemoveResultUnique3}),previewSignature=useRef('');
  useEffect(()=>{setPreview(null);setError('');},[signature]);
  const api=async(path:string,body?:unknown)=>{
    const {response,json}=await rangeFetchJson(apiUrl(`/api/app/backtest_range${path}`),{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});
    if(!response.ok||json.status!=='success')throw new Error(json.message||'Range request failed');return json;
  };
  useEffect(()=>{
    if(!open)return;let stopped=false,polling=false,detailPolling=false,detailsVersion='',lastDetailsAt=0,lastDetailState='';
    const loadDetails=async(epoch:number,id:string)=>{
      detailPolling=true;lastDetailsAt=Date.now();setDetailsLoading(true);
      try{
        const full=await api('');if(stopped||epoch!==requestEpoch.current||full.job?.id!==id)return;
        setJob((prev:any)=>{if(prev?.id!==id)return prev;const {report:_,history:__,...live}=prev;return {...full.job,...live,report:full.job.report,history:full.job.history,summaryOnly:false};});
        setError(prev=>prev.startsWith('Date report:')?'':prev);
        detailsVersion=`full:${id}:${full.job.updatedAt}:${full.job.state}`;lastDetailState=full.job.state;
        if(full.job.profileId===profileId){const version=`${id}:${full.job.updatedAt}`;
          if(lastCommit.current!==version){const {json:state}=await rangeFetchJson(apiUrl('/api/app/state'));if(!stopped&&epoch===requestEpoch.current&&state.state){callbacks.current.onArchive(state.state);lastCommit.current=version;}}
        }
      }catch(e:any){if(!stopped&&epoch===requestEpoch.current)setError(`Date report: ${e.message}`);}
      finally{detailPolling=false;if(!stopped)setDetailsLoading(false);}
    };
    const poll=async()=>{if(stopped||document.visibilityState==='hidden'||polling||mutationInFlight.current)return;polling=true;const epoch=requestEpoch.current;
      try{const json=await api('?summary=1');if(stopped||epoch!==requestEpoch.current)return;
        setConnectedAt(Date.now());const live=json.job;
        setJob((prev:any)=>live?(prev?.id===live.id?{...prev,...live}:{...live,summaryOnly:true,report:[],history:[]}):null);
        // Progress stays fast; heavy date reports/state refresh at most every 10s.
        // Completion, pause, stop and a different run bypass the throttle.
        if(visible&&live&&!detailPolling&&detailsVersion!==`full:${live.id}:${live.updatedAt}:${live.state}`&&(Date.now()-lastDetailsAt>=10000||lastDetailState!==live.state||!detailsVersion.startsWith(`full:${live.id}:`)))void loadDetails(epoch,live.id);
      }catch(e:any){if(!stopped&&epoch===requestEpoch.current)setError(e.message);}finally{polling=false;}
    };
    void poll();const timer=visible?window.setInterval(poll,1500):undefined;const reconnect=()=>{if(visible&&document.visibilityState!=='hidden')void poll();};
    window.addEventListener('focus',reconnect);window.addEventListener('online',reconnect);window.addEventListener('pageshow',reconnect);document.addEventListener('visibilitychange',reconnect);
    return()=>{stopped=true;window.clearInterval(timer);window.removeEventListener('focus',reconnect);window.removeEventListener('online',reconnect);window.removeEventListener('pageshow',reconnect);document.removeEventListener('visibilitychange',reconnect);};
  },[open,profileId,visible]);
  const action=async(kind:'preview'|'start'|'pause'|'resume'|'stop'|'clear')=>{
    if(kind==='clear'&&!window.confirm('Clear only this run’s unchanged backtest cards? Manual/sent cards and newer edits stay protected. Comparison summary stays saved.'))return;
    if(kind!=='preview')requestEpoch.current++;
    mutationInFlight.current=true;setWorking(true);setError('');setNotice('');try{
      if(kind==='preview'||kind==='start'){rangeDates(from,to);await beforeRun();}
      const json=await api(`/${kind}`,kind==='preview'||kind==='start'?options:kind==='clear'?{profileId,jobId:job?.id}:{});
      if(kind!=='preview')window.dispatchEvent(new Event('titan-backtest-updated'));
      if(kind==='preview'){setPreview(json);previewSignature.current=signature;}else {setJob(json.job);if(kind==='start'){setPreview(null);lastCommit.current='';setNotice('New trial started · progress and automatic totals reset');const {json:saved}=await rangeFetchJson(apiUrl('/api/app/state'));if(saved.state)callbacks.current.onArchive(saved.state);}if(kind==='clear'){setNotice(`${json.cleared} cards cleared/restored · ${json.kept} newer/protected cards kept`);lastCommit.current='';const {json:saved}=await rangeFetchJson(apiUrl('/api/app/state'));if(saved.state)callbacks.current.onArchive(saved.state);setPreview(null);} }
    }catch(e:any){setError(e.message);}finally{mutationInFlight.current=false;setWorking(false);}
  };
  const mine=job?.profileId===profileId,rows=mine?job.report||[]:[],active=job?.state==='running',counts=job?.counts||{};
  useEffect(()=>{
    if(!mine||!restoreServerSetup.current)return;restoreServerSetup.current=false;
    setFrom(job.from);setTo(job.to);setMode(job.mode);setSelection(job.selection);setGames(job.games);
    setSelectedMarkets(job.markets);setWeekdays(job.weekdays||[0,1,2,3,4,5,6]);setFresh(job.fresh===true);setInitialTrick(job.initialTrick||0);setRecentHistorySeed(job.recentHistorySeed!==false);setAutoResultParity(job.autoResultParity===true);setDailyStopLoss(job.dailyStopLoss||0);setStopLossEnabled((job.dailyStopLoss||0)>0);setDailyProfitTarget(job.dailyProfitTarget||0);setResetAfterThreeFails(job.resetAfterThreeFails===true);setBacktestMaxStake(job.backtestMaxStake||0);
  },[job?.id,profileId]);
  const fallbackTasks=Object.entries(counts).flatMap(([status,count])=>Array.from({length:Number(count)},()=>({status:status as any})));
  const progress=job?.progress||rangeProgress(fallbackTasks),processed=progress.checked,eligible=progress.eligible;
  const financial=rows.filter((r:any)=>!r.counts.live&&!r.counts.weekday_skip).map((r:any)=>r.games[reportGame]||{});
  const total={stakes:financial.reduce((n:number,r:any)=>n+(r.spent||0),0),returns:financial.reduce((n:number,r:any)=>n+(r.win||0),0),profit:financial.reduce((n:number,r:any)=>n+(r.pl||0),0),capital:Math.max(0,...financial.map((r:any)=>r.invested||0)),risk:Math.max(0,...financial.map((r:any)=>r.maxLoss||0))};
  const download=(dataRows:any[]=rows,run:any=job)=>{
    const header=['Date','Game','Stakes','Return','Profit','Own capital','Closing wallet','Pending stake','Max risk','Missing cards','Failed cards','Protected cards','Live skipped','Weekday skipped','3 fail reset','Maximum card stake','Recent history seed','Daily profit target','Daily stop loss','F/C/L-cut','Selected markets','Scraping mode','ANK selection','History choice policy','History evaluation'];
    const values=dataRows.flatMap((r:any)=>run.games.map((g:GameType)=>{const f=r.games[g]||{};return [r.date,g,f.spent||0,f.win||0,f.pl||0,f.invested||0,f.balance||0,f.pending||0,f.maxLoss||0,r.counts.missing,r.counts.failed,r.counts.protected,r.counts.live,r.counts.weekday_skip||0,run.resetAfterThreeFails?'ON':'OFF',run.backtestMaxStake||0,run.selection==='history_apply'?'fresh source-window replay':(run.selection==='recent2'||run.selection==='recent4'||run.selection==='recent6_keep'||run.selection==='history_apply'||run.selection==='auto_day_recent2'||run.selection==='auto_day_recent2_keep')?(run.recentHistorySeed!==false?(run.warmup?.seedRule==='scraped'?'uncut scraping warmup':'legacy first4 warmup'):'saved history only'):'none',run.dailyProfitTarget||0,run.dailyStopLoss||0,run.autoResultParity?'ON':'OFF',run.markets?run.markets.join(' | '):'ALL MARKETS',run.mode,run.selection==='result_parity'?'F/C/L-cut':run.selection,run.selection==='history_apply'?(run.historyChoicePolicy||'legacy-fixed'):'',run.selection==='history_apply'?(run.historyChoicePolicy===SOURCE_HISTORY_POLICY?'Selected source first-ten-unique history span; age weights 3/2/1':`Legacy fixed choice through ${run.historyChoiceCutoff||'unknown cutoff'}`):''];}));
    const blob=new Blob(['\uFEFF'+[header,...values].map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\n')],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`Titan_Backtest_${run.from}_${run.to}_${run.selection==='result_parity'?'FCL-cut':run.selection}_${run.resetAfterThreeFails?'reset3_':''}${run.id}.csv`;a.click();URL.revokeObjectURL(url);
  };
  return <section className="rounded-xl border border-[#2AABEE]/30 bg-[#17212B] overflow-hidden" aria-label="Bulk date backtest">
    <button type="button" className="w-full py-2.5 text-[10px] font-bold text-[#8DC8FF]" onClick={()=>setOpen(v=>!v)} aria-expanded={open}>📅 BULK DATE SCRAPE + BACKTEST {open?'▴':'▾'}</button>
    {open&&<div className="p-3 pt-0 space-y-3">
      <div className="rounded-xl border border-[#2AABEE]/20 bg-[#153342] p-3 space-y-2">
        <div className="flex items-center justify-between gap-2"><h2 className="text-sm font-bold text-white">Background execution</h2><span className={`rounded-full px-2 py-1 text-[9px] ${error?'bg-[#FF8A8A]/10 text-[#FF8A8A]':'bg-[#00C26F]/10 text-[#00C26F]'}`}>{error?'RECONNECTING':connectedAt?'SERVER CONNECTED':'CONNECTING'}</span></div>
        <p className="text-[11px] text-[#C8D6E3]">Switch tabs or close the browser. The server continues your run and restores progress when you return.</p>
        <p className="text-[9px] text-[#8DA6C0]">Last sync {clockText(connectedAt)} · {mine?`Saved checkpoint ${clockText(job.updatedAt)}`:job?`Run belongs to ${job.profileId}`:'Checking saved run'} · Backend must remain running.</p>
        {mine&&<div className="grid grid-cols-3 gap-2 text-[10px]">{[['Processed',`${processed}/${eligible}`],['Settled',counts.done||0],['Needs retry',(counts.failed||0)+(counts.missing||0)]].map(([label,value])=><div key={label} className="rounded-lg bg-[#17212B] p-2"><p className="text-[#8DA6C0]">{label}</p><p className="mt-1 font-bold text-white">{value}</p></div>)}</div>}
        {mine&&job?.warmup?.enabled&&<p role="status" className="text-[10px] text-[#8DC8FF]">Recent history preparation: {job.warmup.checked}/{job.warmup.total} checked · {job.warmup.done} dated records · {job.warmup.missing} missing/failed · {job.warmup.seedRule==='first4'?'legacy INDEX 1–4':'scraped digits unchanged · PASS/FAIL'} · excluded from financial totals</p>}
        {!!job?.restartCount&&mine&&<p className="text-[9px] text-[#8DC8FF]">Automatically recovered after {job.restartCount} server restart(s). Manual Pause and Stop remain saved.</p>}
      </div>
      <details open={!active} className="rounded-xl border border-white/10 p-3"><summary className="cursor-pointer text-xs font-bold text-[#8DC8FF]">Trial setup · dates &amp; strategy</summary><div className="mt-3 space-y-3">
      <p className="text-[10px] text-[#8DA6C0]">Selected profile only · historical dates · no live broadcasts. Existing dated loops/settings apply; missing dates use current settings.</p>
      <div className="grid grid-cols-2 gap-2">
        <label className="text-[10px] text-[#8DA6C0]">From<input aria-label="Backtest range From" type="date" disabled={working||active||job?.busy} max={today} value={from} onChange={e=>setFrom(e.target.value)} className="mt-1 w-full min-w-0 rounded-md bg-[#232E3C] p-2 text-white"/></label>
        <label className="text-[10px] text-[#8DA6C0]">To<input aria-label="Backtest range To" type="date" disabled={working||active||job?.busy} max={today} value={to} onChange={e=>setTo(e.target.value)} className="mt-1 w-full min-w-0 rounded-md bg-[#232E3C] p-2 text-white"/></label>
      </div>
      <fieldset className="space-y-2 text-[10px] text-[#8DA6C0]">
        <legend>Selected weekdays</legend>
        <div className="flex flex-wrap gap-2">{RANGE_WEEKDAYS.map(([day,label])=><label key={day} className="flex items-center gap-1"><input type="checkbox" aria-label={`Range ${label}`} checked={weekdays.includes(day)} disabled={working||active} onChange={e=>setWeekdays(v=>e.target.checked?[...v,day].sort():v.filter(d=>d!==day))}/>{label.slice(0,3)}</label>)}</div>
        <div className="flex gap-2"><button type="button" disabled={working||active} onClick={()=>setWeekdays([1,2,3,4,5])} className="rounded border border-[#2AABEE]/30 px-2 py-1">MON–FRI</button><button type="button" disabled={working||active} onClick={()=>setWeekdays([0,1,2,3,4,5,6])} className="rounded border border-[#2AABEE]/30 px-2 py-1">ALL DAYS</button></div>
      </fieldset>
      <fieldset className="space-y-2 rounded-lg border border-[#2AABEE]/20 p-3 text-[10px] text-[#8DA6C0]">
        <legend>Selected markets · {selectedMarkets?.length??marketChoices.length}/{marketChoices.length}</legend>
        <input type="search" aria-label="Search backtest markets" placeholder="Search market…" value={marketSearch} onChange={e=>setMarketSearch(e.target.value)} className="w-full rounded bg-[#232E3C] p-2 text-white"/>
        <div className="flex gap-2"><button type="button" disabled={working||active||job?.busy} onClick={()=>setSelectedMarkets(undefined)} className="rounded border border-[#2AABEE]/30 px-2 py-1">ALL MARKETS</button><button type="button" disabled={working||active||job?.busy} onClick={()=>setSelectedMarkets([])} className="rounded border border-[#2AABEE]/30 px-2 py-1">CLEAR SELECTION</button></div>
        <div className="grid max-h-48 grid-cols-2 gap-2 overflow-y-auto">{marketChoices.filter(name=>name.includes(marketSearch.trim().toUpperCase())).map(name=><label key={name} className="flex items-start gap-1"><input type="checkbox" aria-label={`Backtest market ${name}`} checked={selectedMarkets===undefined||selectedMarkets.includes(name)} disabled={working||active||job?.busy} onChange={e=>setSelectedMarkets(previous=>e.target.checked?[...new Set([...(previous||marketChoices),name])]:(previous||marketChoices).filter(m=>m!==name))}/><span>{name}</span></label>)}</div>
        <p className="text-[9px]">Each market includes its OPEN/CLOSE sides. Only chosen markets are tested; other markets stay untouched and are excluded from recovery and profit targets.</p>
        {selectedMarkets?.length===0&&<p role="alert" className="text-[#FF8A8A]">Choose at least one market.</p>}
      </fieldset>
      <label className="flex items-center gap-2 text-[10px] text-[#8DC8FF]"><input type="checkbox" aria-label="Range auto remove result digit" checked={autoRemoveResultDigit} disabled={disabled||working||active} onChange={e=>onAutoRemoveChange(e.target.checked)}/>AUTO REMOVE RESULT DIGIT · {autoRemoveResultDigit?(autoRemoveResultUnique3?'CUT 5':autoRemoveResultMirror?'RESULT + MIRROR':'RESULT'):'OFF'}</label>
      <p className="text-[9px] text-[#8DA6C0]">Uses selected profile's same setting: actual result digit is removed from the next available ANK card in its existing recovery track, for PASS or FAIL. Skipped weekdays are kept untouched.</p>
      <label className="block text-[10px] text-[#8DA6C0]">Scraping mode<select disabled={working||active||job?.busy} aria-label="Range scraping mode" value={mode} onChange={e=>{const v=e.target.value as RangeMode;setMode(v);setSelection(selection==='self_learn_90d'||selection==='carry6'||selection==='carry_result6'?selection:v==='smart'||v==='market_model'||v==='dynamic_4ank'?'keep':selection==='history_apply'?'history_apply':'first4');}} className="mt-1 w-full rounded-md bg-[#232E3C] p-2 text-white">{modes.map(([v,label])=><option key={v} value={v}>{label}</option>)}</select></label>
      {selection==='carry_result6'&&<p className="text-[10px] text-[#8DA6C0]">Carry Result 6: scraping mode ignored for ANK selection. Same recovery track ke latest 6 unique actuals; today → yesterday → older days. No mirror/voting. Saved earlier actuals required; missing history leaves task unchanged.</p>}
      {selection==='carry6'&&<p className="text-[10px] text-[#8DA6C0]">Carry6: selected scraping source ke original #9/#10 + Auto, Day, Combo, Day Mix #9/#10. Maximum 6 digits; missing source par card unchanged.</p>}
      <label className="block text-[10px] text-[#8DA6C0]">ANK digit selection<select disabled={working||active||job?.busy} aria-label="Range digit selection" value={autoResultParity?'result_parity':selection} onChange={e=>{setSelection(e.target.value as RangeSelection);setAutoResultParity(e.target.value==='result_parity');}} className="mt-1 w-full rounded-md bg-[#232E3C] p-2 text-white">{RANGE_SELECTIONS.map(([value,label])=><option key={value} value={value} disabled={value==='history_apply'&&(mode==='smart'||mode==='market_model'||mode==='dynamic_4ank')}>{label}</option>)}</select></label>
      {selection==='self_learn_90d'&&<div className="rounded-lg border border-[#00C26F]/40 bg-[#0F292A] p-3 text-[10px] text-[#BBE9DC] space-y-1">
        <p className="font-bold text-[#20E093]">🧠 AI PER-MARKET 12-TRICK TOURNAMENT &amp; 2-FAIL MOOD SWITCHER (90D Zero-Lookahead)</p>
        <p>1. <strong>Har Market Ka Apna Individual Line (12-Trick Tournament)</strong>: Sabhi markets par ek hi trick lagane ke bajaye, AI har market (Sridevi, Time Bazar, Madhur, Milan 23-Pyramid, Supreme, Kalyan Farak, Main Bazar, etc.) ke pichle 5–7 draws par 12 alag tricks ka mini-backtest chala kar us market ki #1 winning trick lock karta hai.</p>
        <p>2. <strong>2-Consecutive-Fail Mood Switch Rule</strong>: 1 fail hone par AI panic-switch nahi karta (3 core digits + 1 safety hedge rakhta hai). Jab kisi market ki active trick <strong>lagatar 2 baar fail</strong> hoti hai (Mood Shift), tab AI turant us market ko #1 Counter-Trick par switch kar deta hai.</p>
      </div>}
      {selection==='history_apply'&&<p className="rounded-lg border border-[#00C26F]/30 p-3 text-[10px] text-[#8DC8FF]">Same History Apply as card Tools / bulk 14: each market, OPEN/CLOSE and source chooses its own Keep6 or Remove4 winner. Auto, Day, O/C, Combo and Day Mix supported. Indices use only earlier same-source PASS/FAIL; result removal follows your existing setting. Every tested date uses its selected source’s first-ten-unique history span. Latest 10 days ×3, days 11–20 ×2, older days ×1. Higher weighted PASS score wins; ties or fewer than 5 comparable results leave selection unapplied. Each comparison uses only earlier positions inside that same window.</p>}
      {selection==='recent6_keep'&&<p className="text-[10px] text-[#8DA6C0]">Keep exactly six digits at the latest six unique prior PASS/FAIL source positions. Repeats and missing results are skipped; older saved history is searched. AUTO REMOVE RESULT DIGIT applies separately when ON: a present prior result is removed, leaving five digits. Parity filtering remains bypassed for these cards. History preparation checks up to 90 prior days, selected weekdays only. Fewer than six valid unique positions means no selection.</p>}
      {selection==='recent2'&&<p className="text-[10px] text-[#8DA6C0]">Only the latest two PASS/FAIL result-index positions are removed from the original ten digits. Repeated indices remove one position. No scrape-digit, mirror or fallback cuts apply. AUTO REMOVE RESULT DIGIT applies separately when ON; F/C/L-cut filtering remains bypassed for these cards.</p>}
      {job?.selection==='recent2'&&job.recent2IndicesOnly!==true&&<p className="text-[10px] text-[#FAC748]">This saved trial uses the previous Recent 2 + scrape 2 rule. Start a fresh trial for RECENT 2 INDICES✅.</p>}
      {selection==='auto_day_recent2_keep'&&<p className="rounded-lg border border-[#00C26F]/30 p-3 text-[10px] text-[#8DC8FF]">KEEP six slots: same-side AUTO recent 2 + DAY recent 2 + two prior PASS/FAIL result positions mapped into your selected scraping source. Duplicate → its mirror (+5). If both are already used, SKIP. These six digits are kept, including digits outside a narrower scraper selection. OPEN uses OPEN history; CLOSE uses CLOSE history. Existing result auto-remove runs afterwards when ON.</p>}
      {selection==='auto_day_recent2'&&<p className="rounded-lg border border-[#2AABEE]/30 p-3 text-[10px] text-[#8DC8FF]">BACKTEST ONLY · Any scraping mode. Same market/side: first 2 recent AUTO source digits + first 2 DAY source digits. Four removal slots, not six cuts. Duplicate/absent digit: recent index 1 → index 2 → original digit’s mirror. Exactly four unique cuts required; otherwise that card is SKIP. OPEN uses only OPEN; CLOSE uses only CLOSE. The existing result auto-remove runs afterwards.</p>}
      {selection==='history_apply'&&<p className="rounded-lg border border-[#2AABEE]/30 bg-[#153342] p-3 text-[10px] text-[#8DA6C0]">Source history is prepared automatically from the trial chart. Each date rebuilds its own source using earlier results only. Comparison data stays private and adds no wallet stake or report profit.</p>}
      {(selection==='recent2'||selection==='recent4'||selection==='recent6_keep'||selection==='auto_day_recent2'||selection==='auto_day_recent2_keep')&&<div className="rounded-lg border border-[#2AABEE]/30 bg-[#153342] p-3 space-y-2"><label className="flex items-center gap-2 text-[11px] text-white"><input aria-label="Prepare Recent rule history" type="checkbox" checked={recentHistorySeed} disabled={working||active||job?.busy} onChange={e=>setRecentHistorySeed(e.target.checked)}/>AUTO PREPARE RECENT HISTORY</label><p className="text-[9px] text-[#8DA6C0]">Missing history uses real charts from the {selection==='recent6_keep'?90:14} days before From, selected weekdays only. Seed: INDEX 1–4 REMOVE / KEEP 5–10. Existing saved cards take priority. History is private to this trial and excluded from wallet/report totals. Recent 2 and Keep Recent 6 use PASS/FAIL; Recent 4 uses PASS only. Missing results stay missing.</p></div>}
      {(selection==='yday'||selection==='yday_trim')&&<div className="space-y-1"><label className="block text-[10px] text-[#8DA6C0]">Starting trick when no prior settled T1/T2 exists<select aria-label="YDAY starting trick" value={initialTrick} disabled={working||active} onChange={e=>setInitialTrick(Number(e.target.value) as 0|1|2)} className="mt-1 w-full rounded-md bg-[#232E3C] p-2 text-white"><option value={1}>Start T1 · only if history is unavailable</option><option value={2}>Start T2 · only if history is unavailable</option><option value={0}>Require prior T1/T2 history · no seed</option></select></label><p className="text-[9px] text-[#8DA6C0]">A fresh YDAY trial can start without an older trial. Existing settled T1/T2 history always takes priority; PASS switches and FAIL keeps. Missing results do not invent an outcome.</p></div>}
      <div className="flex flex-wrap gap-3 text-[10px] text-white">{(['ank','jodi','pannel'] as GameType[]).map(type=><label key={type} className="flex items-center gap-1"><input type="checkbox" disabled={working||active||job?.busy} checked={games.includes(type)} onChange={e=>setGames(v=>e.target.checked?[...v,type]:v.filter(g=>g!==type))}/>{type==='pannel'?'PANEL from ANK':type==='jodi'?'JODI from ANK':'ANK'}</label>)}</div>
      <div className="rounded-lg border border-[#FF8A8A]/30 p-3 text-[11px] text-white">
        <label className="flex items-center justify-between gap-2 font-bold">DAILY STOP LOSS · BACKTEST ONLY<input aria-label="Enable backtest daily stop loss" type="checkbox" checked={stopLossEnabled} disabled={working||active||job?.busy} onChange={e=>{setStopLossEnabled(e.target.checked);if(e.target.checked&&!dailyStopLoss)setDailyStopLoss(2000);}}/></label>
        {stopLossEnabled&&<input aria-label="Backtest daily stop loss" type="number" min="1" step="1" value={dailyStopLoss} disabled={working||active||job?.busy} onChange={e=>setDailyStopLoss(Math.max(1,Number(e.target.value)||1))} className="mt-2 w-full rounded-md bg-[#232E3C] p-2"/>}
        <p className="mt-1 text-[9px] text-[#8DA6C0]">Each selected game stops separately when settled daily net P/L reaches −₹limit. The crossing bet settles fully, so loss can exceed the limit. Next selected date starts at base rate. Skipped ANK result indices are kept for strategy history; no stake. Protected settlements stay intact. Live settings are unchanged.</p>
      </div>
      <label className="block rounded-lg border border-[#00C26F]/30 p-3 text-[11px] text-white">DAILY PROFIT EXIT · BACKTEST ONLY
        <input aria-label="Backtest daily profit target" type="number" min="0" step="1" value={dailyProfitTarget} disabled={working||active||job?.busy} onChange={e=>setDailyProfitTarget(Math.max(0,Number(e.target.value)||0))} className="mt-2 w-full rounded-md bg-[#232E3C] p-2"/>
        <span className="mt-1 block text-[9px] text-[#8DA6C0]">₹0 = OFF. Each game stops its remaining cards once settled daily net profit reaches this amount. ANK/JODI/PANEL targets are independent across recovery loops. Next selected date starts normally. Skipped ANK cards still scrape source/result indices for next-date strategy history, with no stake. Protected settlements are kept.</span>
      </label>
      <div className="rounded-lg border border-[#2AABEE]/30 bg-[#153342] p-3 space-y-2">
        <label className="flex items-center gap-2 text-[11px] font-bold text-white"><input aria-label="Reset recovery after 3 consecutive fails" type="checkbox" checked={resetAfterThreeFails} disabled={working||active||job?.busy} onChange={e=>setResetAfterThreeFails(e.target.checked)}/>3 FAIL RESET · BACKTEST ONLY</label>
        <p className="text-[9px] text-[#8DA6C0]">First and second FAIL use existing recovery. Third consecutive FAIL closes that track’s recovery cycle; the next eligible card starts at base rate. PASS resets the counter. Old losses stay in wallet/profit. Each game/loop follows its existing separate track; counters restart each test date.</p>
        {resetAfterThreeFails&&<label className="block text-[10px] text-[#8DA6C0]">Maximum total stake per card · ₹ (0 = no extra cap)<input aria-label="Backtest maximum card stake" type="number" min="0" step="1" value={backtestMaxStake} disabled={working||active||job?.busy} onChange={e=>setBacktestMaxStake(Math.max(0,Number(e.target.value)||0))} className="mt-1 w-full min-w-0 rounded-md bg-[#232E3C] p-2 text-white"/><span className="block mt-1 text-[9px]">A card above this cap is skipped before betting. Skips do not erase debt or count as FAIL. Frozen/manual settlements stay protected. Live settings remain unchanged.</span></label>}
      </div>
      <label className="flex items-center gap-2 text-[10px] text-white"><input aria-label="Fresh backtest trial" type="checkbox" checked={fresh} disabled={working||active} onChange={e=>setFresh(e.target.checked)}/>FRESH TEST · reset selections/results when Start is pressed</label>
      <p className="text-[9px] text-[#8DA6C0]">Previous comparison summaries stay saved. Skipped dates, manual/sent cards and other profiles are protected. New run totals only include its own cards plus explicitly protected settlements. Uncheck Fresh to retain selections until replaced.</p>
      <p className="text-[9px] text-[#8DA6C0]">JODI/PANEL need same-date ANK selections; ANK is processed first. Recent rules can prepare missing prior history separately; it is excluded from test totals. For YDAY, choose a starting T1/T2 when history is unavailable. Trim options apply T1/T2 before 6→5. Up to 366 dates. Today is skipped. Sent/queued/manual settlements stay protected; automatic archive trials can refresh.</p>
      <div className="grid grid-cols-2 gap-2"><button type="button" disabled={working||disabled||active||job?.busy||selectedMarkets?.length===0} onClick={()=>void action('preview')} className="rounded-lg border border-[#2AABEE]/40 py-2 text-[10px] text-[#8DC8FF] disabled:opacity-40">PREVIEW RANGE</button>
        <button type="button" disabled={working||disabled||active||job?.busy||selectedMarkets?.length===0||!preview||previewSignature.current!==signature||!preview.counts.pending} onClick={()=>void action('start')} className="rounded-lg bg-[#147D91] py-2 text-[10px] font-bold text-white disabled:opacity-40">{fresh?'START FRESH BACKTEST':'START RANGE BACKTEST'}</button></div>
      </div></details>
      {preview&&<p className="text-[10px] text-[#8DC8FF]">{preview.dates} dates · {preview.counts.pending} eligible · {preview.counts.protected} protected · {preview.counts.disabled} disabled · {preview.counts.live} live skipped · {preview.counts.weekday_skip||0} weekday cards skipped</p>}
      {notice&&<p role="status" className="text-[10px] text-[#8DC8FF]">{notice}</p>}
      {error&&<p role="alert" className="text-[10px] text-[#FF8A8A] break-words">{error}</p>}
      {job&&!mine&&<button type="button" onClick={()=>onOpenRunProfile(job.profileId)} className="w-full rounded-lg bg-[#147D91] p-3 text-xs font-bold text-white">OPEN RUN PROFILE · {job.profileId}</button>}
      {detailsLoading&&<p role="status" className="text-[10px] text-[#8DC8FF]">Loading date-wise report · live progress continues</p>}
      {job&&<div className="border-t border-white/10 pt-3 space-y-2"><p className="text-[10px] text-[#8DC8FF]">Run markets: {job.markets?.join(' · ')||'ALL MARKETS'}</p>
        {!mine?<p className="text-[10px] text-[#8DA6C0]">Last/current run belongs to {job.profileId}.</p>:<>
          <p className="text-[9px] text-[#8DA6C0]">Run ID: {job.id} · Fresh {job.fresh?'ON':'OFF'}</p>
          <p className="text-[9px] text-[#00C26F]">F/C/L-cut: {job.autoResultParity?'ON':'OFF'} · Daily stop loss: {job.dailyStopLoss?money(job.dailyStopLoss):'OFF'} · Daily profit exit: {job.dailyProfitTarget?money(job.dailyProfitTarget):'OFF'} · Next date restarts normally</p>
          <p className="text-[9px] text-[#8DC8FF]">3 FAIL reset: {job.resetAfterThreeFails?'ON':'OFF'} · Max card stake: {job.backtestMaxStake?money(job.backtestMaxStake):'No extra cap'}</p>
          <p className="text-[10px] text-[#8DC8FF]">Current run: {job.mode} · {RANGE_SELECTIONS.find(([v])=>v===job.selection)?.[1]||job.selection} · {job.from} → {job.to}</p>
          <p className="text-[9px] text-[#8DA6C0]">Run weekdays: {RANGE_WEEKDAYS.filter(([d])=>(job.weekdays||[0,1,2,3,4,5,6]).includes(d)).map(([,label])=>label.slice(0,3)).join(', ')} · Auto remove: {job.autoRemoveResultDigit?(job.autoRemoveResultUnique3?'CUT 5':job.autoRemoveResultMirror?'RESULT + MIRROR':'RESULT'):'OFF'}</p>{(job.selection==='yday'||job.selection==='yday_trim')&&<p className="text-[9px] text-[#8DA6C0]">YDAY starting trick: {job.initialTrick?`T${job.initialTrick}`:'Require history'}</p>}
          <p className="text-[11px] font-bold text-white">{job.state.toUpperCase()} · {processed}/{eligible} eligible cards</p>
          <div role="progressbar" aria-label="Range backtest progress" aria-valuemin={0} aria-valuemax={eligible||1} aria-valuenow={processed} className="h-1.5 rounded bg-[#232E3C]"><div className="h-full rounded bg-[#2AABEE]" style={{width:`${eligible?processed/eligible*100:0}%`}}/></div>
          <p className="text-[9px] text-[#8DA6C0]">{progress.finalized} finalized · {progress.excluded} excluded cards (weekdays/live/disabled/protected)</p>
          {job.staging?.total>0&&<p className="text-[9px] text-[#8DA6C0]">Current date {job.staging.date}: {job.staging.checked}/{job.staging.total} checked. Archive totals save when this date finishes.</p>}
          {job.current&&<p className="text-[9px] text-[#8DA6C0] break-words">{job.current}{active&&job.currentStartedAt?` · waiting ${Math.max(0,Math.floor((Date.now()-job.currentStartedAt)/1000))}s`:''}</p>}
          <p className="text-[10px] text-[#8DA6C0]">Done {counts.done||0} · Weekday skipped {counts.weekday_skip||0} · Missing {counts.missing||0} · Failed {counts.failed||0} · Policy SKIP {counts.policy_skip||0}</p>
          {job.state==='completed'&&(counts.failed||counts.missing)>0&&<p role="status" className="rounded-lg bg-[#E7A741]/10 p-2 text-[10px] text-[#F4C46B]">Finished with gaps · {(counts.failed||0)+(counts.missing||0)} cards need retry. Use RESUME / RETRY PENDING to check them again.</p>}
          {job.error&&<p className="text-[10px] text-[#FF8A8A]">{job.error}</p>}
          <div className="flex gap-2"><button type="button" disabled={working||job.state!=='running'} onClick={()=>void action('pause')} className="rounded border border-white/20 px-3 py-2 text-[10px] text-white disabled:opacity-40">PAUSE</button>
            <button type="button" disabled={working||job.state==='running'||job.state==='stopped'||job.state==='cleared'||job.busy||(!counts.pending&&!counts.failed&&!counts.missing)} onClick={()=>void action('resume')} className="rounded border border-[#2AABEE]/40 px-3 py-2 text-[10px] text-[#8DC8FF] disabled:opacity-40">RESUME / RETRY PENDING</button></div>
          <div className="grid grid-cols-2 gap-2"><button type="button" disabled={working||job.state==='cleared'||job.state==='stopped'} onClick={()=>void action('stop')} className="rounded border border-[#FF8A8A]/40 py-2 text-[10px] text-[#FF8A8A] disabled:opacity-40">STOP RUN</button><button type="button" disabled={working||active||job.busy||job.state==='cleared'} onClick={()=>void action('clear')} className="rounded border border-[#FF8A8A]/40 py-2 text-[10px] text-[#FF8A8A] disabled:opacity-40">CLEAR THIS RUN’S DATA</button></div>
          <p className="text-[9px] text-[#8DA6C0]">Pause saves a resumable checkpoint. Stop ends this run after the current request finishes. Navigation and closing the browser never send Stop. A failed chart request is recorded and the run continues; retry failed/missing cards afterward. Retry rebuilds affected dates and later strategy history. To try another logic, change the selection, keep Fresh ON, then Preview → Start.</p>
          <div className="flex gap-2">{(job.games||[]).map((g:GameType)=><button type="button" key={g} onClick={()=>setReportGame(g)} aria-pressed={reportGame===g} className={`rounded px-3 py-1.5 text-[10px] ${reportGame===g?'bg-[#147D91] text-white':'bg-[#232E3C] text-[#8DA6C0]'}`}>{g==='pannel'?'PANEL':g.toUpperCase()}</button>)}</div>
          {!job.summaryOnly&&<div className="grid grid-cols-2 gap-2 text-[10px] text-white"><div>Stakes {money(total.stakes)}</div><div>Return {money(total.returns)}</div><div className={total.profit>=0?'text-[#00C26F]':'text-[#FF8A8A]'}>Net {signed(total.profit)}</div><div>Max daily capital {money(total.capital)}</div><div>Max daily risk {money(total.risk)}</div></div>}
          {!job.summaryOnly&&rows.length>0&&(()=>{
            const eligibleRows=rows.filter((r:any)=>!r.counts.live&&!r.counts.weekday_skip);
            const isTrapDate=(dStr:string)=>{const dt=new Date(`${dStr}T00:00:00Z`);const dow=dt.getUTCDay(),dom=dt.getUTCDate();return dow===0||dow===6||dom>=25||dom<=2;};
            const trapRows=eligibleRows.filter((r:any)=>isTrapDate(r.date));
            const normalRows=eligibleRows.filter((r:any)=>!isTrapDate(r.date));
            const trapPL=trapRows.reduce((n:number,r:any)=>n+(r.games[reportGame]?.pl||0),0);
            const normalPL=normalRows.reduce((n:number,r:any)=>n+(r.games[reportGame]?.pl||0),0);
            const trapWinDays=trapRows.filter((r:any)=>(r.games[reportGame]?.pl||0)>=0).length;
            const normalWinDays=normalRows.filter((r:any)=>(r.games[reportGame]?.pl||0)>=0).length;
            return <div className="grid grid-cols-2 gap-2 rounded-lg border border-white/10 bg-[#153342]/60 p-2 text-[9px] font-mono tabular-nums">
              <div>
                <p className="text-[#8DA6C0] font-sans font-bold">Normal Days ({normalWinDays}/{normalRows.length} +ve)</p>
                <p className={normalPL>=0?'text-[#00C26F] font-bold':'text-[#FF8A8A] font-bold'}>{signed(normalPL)}</p>
              </div>
              <div>
                <p className="text-[#FAC748] font-sans font-bold">Weekend &amp; Month-End ({trapWinDays}/{trapRows.length} +ve)</p>
                <p className={trapPL>=0?'text-[#00C26F] font-bold':'text-[#FF8A8A] font-bold'}>{signed(trapPL)}</p>
              </div>
            </div>;
          })()}
          <p className="text-[9px] text-[#8DA6C0]">This run’s saved totals; explicitly protected settlements included. Missing/failed cards make the run incomplete. Capital/wallet reset per business date; they are not cumulative deposits.</p>
          <div className="max-h-64 overflow-auto rounded border border-white/10"><table className="w-full text-[9px]"><thead className="text-[#8DA6C0]"><tr><th className="p-2 text-left">Date</th><th>Net</th><th>Wallet</th><th>Pending / failed</th></tr></thead><tbody>{rows.map((r:any)=><tr key={r.date} className="border-t border-white/5"><td className="p-2"><button type="button" onClick={()=>onOpenDate(r.date)} className="text-[#8DC8FF]">{r.date}</button></td><td className={(r.games[reportGame]?.pl||0)>=0?'text-[#00C26F]':'text-[#FF8A8A]'}>{signed(r.games[reportGame]?.pl||0)}</td><td className="text-white">{money(r.games[reportGame]?.balance||0)}</td><td className="text-[#8DA6C0]">{r.counts.weekday_skip?'Weekday skipped':r.counts.live?'Live skipped':`${r.counts.missing+r.counts.pending} / ${r.counts.failed}`}</td></tr>)}</tbody></table></div>
          <button type="button" onClick={()=>download()} className="w-full rounded border border-[#2AABEE]/30 py-2 text-[10px] text-[#8DC8FF]">DOWNLOAD DATE-WISE CSV</button>
          {job.history?.length>0&&<div className="space-y-2 border-t border-white/10 pt-3"><h2 className="text-[11px] font-bold text-white">Saved logic comparisons · {reportGame.toUpperCase()}</h2><div className="max-h-60 overflow-auto space-y-2">{job.history.map((h:any)=>{const figures=h.report?.map((r:any)=>r.games?.[reportGame]||{})||[],profit=figures.reduce((n:number,r:any)=>n+(r.pl||0),0),missing=h.report?.reduce((n:number,r:any)=>n+(r.counts.missing||0)+(r.counts.failed||0)+(r.counts.pending||0),0)||0;return <div key={h.id} className="rounded bg-[#232E3C] p-2 text-[10px]"><p className="text-[#8DC8FF]">{h.mode} · {(h.selection==='recent2'&&h.recent2IndicesOnly!==true?'Recent 2 + scrape 2 (previous rule)':RANGE_SELECTIONS.find(([v])=>v===h.selection)?.[1]||h.selection)}</p><p className="text-[#8DA6C0]">{h.from} → {h.to} · {h.state} · Auto remove {h.autoRemoveResultDigit?(h.autoRemoveResultUnique3?'CUT 5':h.autoRemoveResultMirror?'RESULT + MIRROR':'RESULT'):'OFF'} · 3 FAIL reset {h.resetAfterThreeFails?'ON':'OFF'} · F/C/L-cut {h.autoResultParity?'ON':'OFF'} · Stop loss {h.dailyStopLoss?money(h.dailyStopLoss):'OFF'} · Daily exit {h.dailyProfitTarget?money(h.dailyProfitTarget):'OFF'} · cap {h.backtestMaxStake?money(h.backtestMaxStake):'none'}{h.selection==='history_apply'?` · History ${h.historyChoicePolicy===SOURCE_HISTORY_POLICY?'source window':'legacy policy'}`:(h.selection==='recent2'||h.selection==='recent4'||h.selection==='auto_day_recent2'||h.selection==='auto_day_recent2_keep')?` · History ${h.recentHistorySeed!==false?(h.warmup?.seedRule==='scraped'?'uncut scraping warmup':'legacy first4 warmup'):'saved only'}`:''} · unfinished {missing}{(h.selection==='yday'||h.selection==='yday_trim')?` · Seed ${h.initialTrick?`T${h.initialTrick}`:'history required'}`:''}</p><p className="text-[#8DA6C0]">Markets: {h.markets?.join(' · ')||'ALL MARKETS'}</p><p className="text-[#8DA6C0]">{RANGE_WEEKDAYS.filter(([d])=>(h.weekdays||[0,1,2,3,4,5,6]).includes(d)).map(([,label])=>label.slice(0,3)).join(', ')}</p><p className={profit>=0?'text-[#00C26F]':'text-[#FF8A8A]'}>Net {signed(profit)} · Stakes {money(figures.reduce((n:number,r:any)=>n+(r.spent||0),0))}</p><p className="text-[#8DA6C0]">Return {money(figures.reduce((n:number,r:any)=>n+(r.win||0),0))} · Max daily risk {money(Math.max(0,...figures.map((r:any)=>r.maxLoss||0)))}</p><button type="button" onClick={()=>download(h.report,h)} className="mt-1 text-[#8DC8FF] underline">EXPORT THIS TRIAL CSV</button></div>;})}</div></div>}
          {job.issues?.length>0&&<details className="text-[9px] text-[#8DA6C0]"><summary>Reasons / protected cards ({job.issues.length})</summary><div className="max-h-40 overflow-auto space-y-1 pt-2">{job.issues.map((t:any,i:number)=><p key={i}>{t.date} · {t.market} · {t.status}: {t.reason}</p>)}</div></details>}
        </>}
      </div>}
    </div>}
  </section>;
}
