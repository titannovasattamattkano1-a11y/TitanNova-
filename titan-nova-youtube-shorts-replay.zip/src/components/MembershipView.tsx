import {validatePaymentProof} from '../utils/manualPayments';
import React, { useState, useRef } from 'react';
import { UserProfile, PaymentMethod, PaymentRequest } from '../types';
import { HARDCODED_PAYMENTS } from '../data/markets';
import { Crown, Sun, Calendar, Gem, Upload } from 'lucide-react';

interface MembershipViewProps {
  profile: UserProfile;
  paymentMethods: PaymentMethod;
  userPayments: PaymentRequest[];
  onSubmitPayment: (amount: number, utr: string, image: string, planLabel: string) => Promise<void>;
  onShowToast: (title: string, body: string, type: 'info' | 'success' | 'danger') => void;
}

export const MembershipView: React.FC<MembershipViewProps> = ({
  profile,
  paymentMethods,
  userPayments,
  onSubmitPayment,
  onShowToast,
}) => {
  const [selectedPlan, setSelectedPlan] = useState<'day' | 'week' | 'month'>('week');
  const [amount, setAmount] = useState(1500);
  const [utr, setUtr] = useState('');
  const [screenshot, setScreenshot] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);
  const submitting=useRef(false);

  const expiryDate = profile?.expiryDate || '';
  let isActive = false;
  let daysLeft = 0;
  let expiryLabel = 'Not Active';

  if (expiryDate) {
    const expObj = new Date(expiryDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    expObj.setHours(0, 0, 0, 0);
    daysLeft = Math.ceil((expObj.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    isActive = daysLeft > 0;
    expiryLabel = expObj.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  }

  const handlePlanSelect = (plan: 'day' | 'week' | 'month') => {
    setSelectedPlan(plan);
    const amounts = { day: 500, week: 1500, month: 4000 };
    setAmount(amounts[plan]);
  };

  const handleOpenUpiApp = (appId: 'phonepe' | 'gpay' | 'paytm') => {
    const upi = paymentMethods?.upi?.trim() || HARDCODED_PAYMENTS[appId] || HARDCODED_PAYMENTS.phonepe;
    const name = HARDCODED_PAYMENTS.name;
    const note = `TITAN NOVA ${selectedPlan.toUpperCase()}`;

    const pa = encodeURIComponent(upi);
    const pn = encodeURIComponent(name);
    const am = amount;
    const tn = encodeURIComponent(note);

    const deepLinks = {
      gpay: `tez://upi/pay?pa=${pa}&pn=${pn}&am=${am}&cu=INR&tn=${tn}`,
      phonepe: `phonepe://pay?pa=${pa}&pn=${pn}&am=${am}&cu=INR&tn=${tn}`,
      paytm: `paytmmp://pay?pa=${pa}&pn=${pn}&am=${am}&cu=INR&tn=${tn}`,
    };

    const genericUpi = `upi://pay?pa=${pa}&pn=${pn}&am=${am}&cu=INR&tn=${tn}`;
    const targetLink = deepLinks[appId] || genericUpi;

    window.location.href = targetLink;

    setTimeout(() => {
      window.location.href = genericUpi;
    }, 1500);
  };

  const handleScreenshotUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if(file.size>2*1024*1024||!['image/png','image/jpeg','image/webp'].includes(file.type)){onShowToast('Invalid screenshot','Use PNG, JPEG or WebP, maximum 2 MB.','danger');return;}
      const reader = new FileReader();
      reader.onload = () => {
        setScreenshot(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async () => {
    if(submitting.current)return;
    const planLabels = { day: '1 Day - ₹500', week: 'Weekly - ₹1,500', month: 'Monthly - ₹4,000' };
    try{validatePaymentProof({amount,utr,image:screenshot,planLabel:planLabels[selectedPlan]});}
    catch(error:any){onShowToast('Check payment details',error.message,'danger');return;}
    submitting.current=true;setIsUploading(true);
    try{
      await onSubmitPayment(amount,utr.trim(),screenshot,planLabels[selectedPlan]);
      setUtr('');setScreenshot('');
    }catch{/* Parent displays save error; preserve the form for retry. */}
    finally{submitting.current=false;setIsUploading(false);}
  };

  return (
    <div className="pb-8 space-y-4">
      {/* Active Membership Status Banner */}
      <div
        className="mx-3 mt-3 rounded-2xl overflow-hidden shadow-xl"
        style={{
          background: isActive
            ? 'linear-gradient(135deg, #00A05E 0%, #1A8FC4 100%)'
            : 'linear-gradient(135deg, #8B1A1A 0%, #5B21B6 100%)',
        }}
      >
        <div className="p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-white/15 flex items-center justify-center backdrop-blur-sm">
                <Crown className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-white/60 text-[10px] font-bold uppercase tracking-widest">VIP Membership</p>
                <p className="text-white font-black text-base tracking-tight leading-tight">{profile.name}</p>
              </div>
            </div>

            <span className="bg-white/20 text-white text-[10px] font-black px-3 py-1 rounded-full backdrop-blur-sm uppercase tracking-wider">
              {isActive ? '✓ ACTIVE' : '✗ EXPIRED'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white/10 rounded-xl p-3 backdrop-blur-sm border border-white/10">
              <p className="text-white/60 text-[9px] font-black uppercase mb-1">Expiry Date</p>
              <p className="text-white font-black text-sm">{expiryLabel}</p>
            </div>
            <div className="bg-white/10 rounded-xl p-3 backdrop-blur-sm border border-white/10">
              <p className="text-white/60 text-[9px] font-black uppercase mb-1">Days Left</p>
              <p className="text-white font-black text-sm">{expiryDate ? (isActive ? `${daysLeft} Days` : 'Expired') : '---'}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Plan Selector */}
      <div className="px-3">
        <p className="text-[11px] font-black text-[#7A9CB8] uppercase tracking-widest mb-2">Choose Membership Plan</p>
        <div className="grid grid-cols-3 gap-2.5">
          {[
            { id: 'day', label: '1 Day', price: '₹500', icon: <Sun className="w-4 h-4 text-white" />, grad: 'linear-gradient(135deg, #FAC748, #EF4444)' },
            { id: 'week', label: 'Weekly', price: '₹1,500', icon: <Calendar className="w-4 h-4 text-white" />, grad: 'linear-gradient(135deg, #2AABEE, #3B82F6)' },
            { id: 'month', label: 'Monthly', price: '₹4,000', icon: <Gem className="w-4 h-4 text-white" />, grad: 'linear-gradient(135deg, #7B8FFF, #EC4899)' },
          ].map((p) => {
            const isSelected = selectedPlan === p.id;
            return (
              <div
                key={p.id}
                onClick={() => handlePlanSelect(p.id as any)}
                className="rounded-2xl p-[1.5px] cursor-pointer transition-all active:scale-95"
                style={{ background: isSelected ? p.grad : '#2B3A4D' }}
              >
                <div
                  className="bg-[#232E3C] rounded-[15px] p-3 flex flex-col items-center gap-1.5"
                  style={{ background: isSelected ? 'rgba(0,0,0,0.4)' : '#232E3C' }}
                >
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center shadow-md" style={{ background: p.grad }}>
                    {p.icon}
                  </div>
                  <p className="text-white font-black text-[11px] text-center leading-tight">{p.label}</p>
                  <p className="font-black text-[13px] text-[#00C26F]">{p.price}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* UPI App Buttons */}
      <div className="px-3">
        <p className="text-[11px] font-black text-[#7A9CB8] uppercase tracking-widest mb-2">Pay via UPI Deep Links</p>
        <div className="grid grid-cols-3 gap-2.5">
          {[
            { id: 'phonepe', label: 'PhonePe', upi: paymentMethods?.upi?.trim() || HARDCODED_PAYMENTS.phonepe, color: '#6F3FFF' },
            { id: 'gpay', label: 'GPay', upi: paymentMethods?.upi?.trim() || HARDCODED_PAYMENTS.gpay, color: '#4285F4' },
            { id: 'paytm', label: 'Paytm', upi: paymentMethods?.upi?.trim() || HARDCODED_PAYMENTS.paytm, color: '#00BAF2' },
          ].map((app) => (
            <button
              key={app.id}
              onClick={() => handleOpenUpiApp(app.id as any)}
              className="flex flex-col items-center gap-1.5 py-3 px-2 rounded-2xl border bg-[#2B3A4D] active:scale-95 transition-transform"
              style={{ borderColor: `${app.color}50` }}
            >
              <span className="text-[12px] font-black text-white" style={{ color: app.color }}>{app.label}</span>
              <span className="text-[8px] font-bold text-[#7A9CB8] truncate w-full text-center px-1">{app.upi}</span>
            </button>
          ))}
        </div>
        <p className="text-[9px] text-[#7A9CB8] text-center mt-2 font-bold">
          Click any UPI app to pay directly — amount is pre-filled automatically
        </p>

        {/* Copy UPI IDs */}
        <div className="mt-3 space-y-2">
          {[
            { label: 'PhonePe UPI', upi: paymentMethods?.upi?.trim() || HARDCODED_PAYMENTS.phonepe, color: '#6F3FFF' },
            { label: 'GPay UPI', upi: paymentMethods?.upi?.trim() || HARDCODED_PAYMENTS.gpay, color: '#4285F4' },
            { label: 'Paytm UPI', upi: paymentMethods?.upi?.trim() || HARDCODED_PAYMENTS.paytm, color: '#00BAF2' },
          ].map((u) => (
            <div key={u.label} className="flex items-center gap-3 bg-[#2B3A4D] border border-[rgba(255,255,255,0.07)] rounded-2xl p-2.5 px-3">
              <div className="flex-1 min-w-0">
                <p className="text-[9px] font-bold uppercase mb-0.5" style={{ color: u.color }}>{u.label}</p>
                <p className="text-white font-black text-xs truncate">{u.upi}</p>
              </div>
              <button
                onClick={async() => {
                  try{if(!navigator.clipboard)throw Error('Clipboard unavailable');await navigator.clipboard.writeText(u.upi);onShowToast('UPI Copied!', `${u.upi} copied to clipboard`, 'success');}
                  catch{onShowToast('Copy failed','Please copy the displayed UPI ID manually.','danger');}
                }}
                className="shrink-0 text-white px-3 py-1.5 rounded-xl font-bold text-[10px] uppercase active:scale-95"
                style={{ background: u.color }}
              >
                Copy
              </button>
            </div>
          ))}
        </div>

        {/* Admin QR Code if present */}
        {paymentMethods?.qr && (
          <div className="mt-3 bg-white rounded-2xl p-3 flex flex-col items-center">
            <p className="text-black text-[10px] font-bold uppercase mb-1">Scan QR Code to Pay</p>
            <img src={paymentMethods.qr} alt="Admin QR" className="w-44 h-44 object-contain" />
          </div>
        )}
      </div>

      {/* Proof Submission Form */}
      <div className="px-3">
        <p className="text-[11px] font-black text-[#7A9CB8] uppercase tracking-widest mb-2">Submit Payment Verification</p>
        <div className="native-card bg-[#232E3C] border border-[rgba(255,255,255,0.07)] p-4 rounded-2xl shadow-xl space-y-3">
          <div>
            <label className="text-[9px] font-bold text-[#7A9CB8] uppercase block mb-1">Amount Paid ₹</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
              className="w-full bg-[#2B3A4D] border border-[rgba(255,255,255,0.1)] text-white font-bold rounded-xl px-3 py-2.5 outline-none text-sm focus:border-[#00C26F]"
            />
          </div>

          <div>
            <label className="text-[9px] font-bold text-[#7A9CB8] uppercase block mb-1">UTR / Transaction Reference Number</label>
            <input
              type="text"
              value={utr}
              onChange={(e) => setUtr(e.target.value)}
              placeholder="e.g. 329182391203"
              className="w-full bg-[#2B3A4D] border border-[rgba(255,255,255,0.1)] text-white font-bold rounded-xl px-3 py-2.5 outline-none text-sm focus:border-[#00C26F]"
            />
          </div>

          <div>
            <label className="text-[9px] font-bold text-[#7A9CB8] uppercase block mb-1">Screenshot Upload (Optional)</label>
            <label className="flex items-center gap-2 bg-[#2B3A4D] border border-dashed border-[rgba(255,255,255,0.15)] rounded-xl p-3 cursor-pointer">
              <Upload className="w-4 h-4 text-[#7A9CB8]" />
              <span className="text-xs text-[#7A9CB8] font-bold">
                {screenshot ? 'Screenshot Uploaded ✓' : 'Tap to attach payment screenshot'}
              </span>
              <input type="file" accept="image/png,image/jpeg,image/webp" onChange={handleScreenshotUpload} className="hidden" />
            </label>
          </div>

          <button
            onClick={handleSubmit}
            disabled={isUploading}
            className="w-full bg-[#00C26F] text-white py-3.5 rounded-2xl font-black text-[12px] uppercase tracking-wide active:scale-95 transition-all shadow-lg shadow-[rgba(0,194,111,0.2)]"
          >
            {isUploading ? 'Submitting...' : 'Submit Payment Proof'}
          </button>
        </div>
      </div>

      {/* History */}
      <div className="px-3">
        <p className="text-[11px] font-black text-[#7A9CB8] uppercase tracking-widest mb-2">Your Payment History</p>
        <div className="space-y-2">
          {userPayments.length === 0 ? (
            <p className="text-[#7A9CB8] text-xs text-center py-4 bg-[#232E3C] rounded-2xl">No previous payment submissions found.</p>
          ) : (
            userPayments.map((p) => {
              let statusColor = 'text-[#FAC748]';
              if (p.status === 'approved') statusColor = 'text-[#00C26F]';
              if (p.status === 'rejected') statusColor = 'text-[#FF5D5D]';

              return (
                <div key={p.id} className="bg-[#232E3C] p-3 rounded-xl border border-[rgba(255,255,255,0.07)]">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-black text-white text-sm">₹{p.amount}</span>
                    <span className={`text-xs font-black uppercase ${statusColor}`}>{p.status}</span>
                  </div>
                  <p className="text-[10px] text-[#7A9CB8]">UTR: {p.utr}</p>
                  <p className="text-[9px] text-[#7A9CB8] mt-0.5">{p.time}</p>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
