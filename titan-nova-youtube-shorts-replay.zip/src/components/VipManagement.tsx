import { vipBusinessDate, vipMembershipDaysLeft } from '../utils/vipMembership';
import {normalizeBroadcastLink} from '../../scripts/broadcast-link.mjs';
import {BROADCAST_DESIGNS,renderBroadcastImage,type BroadcastPresentation} from '../utils/broadcastImage';
import { apiUrl } from '../utils/api';
import React, { useMemo, useState, useRef, useEffect } from 'react';
import { UserProfile, Broadcast, GameType } from '../types';
import { Users, Megaphone, UserPlus, Link, Trash2, CalendarCheck, Send, Contact, Smartphone, ChevronDown, ChevronUp, Settings2 } from 'lucide-react';
import { TargetSelectorModal } from './TargetSelectorModal';
import { normalizeTargetJid, isGroupTarget, isChannelTarget, isTelegramTarget } from '../utils/targetNormalization';

interface VipManagementProps {
  profiles: Record<string, UserProfile>;
  onSelectClient: (pid: string) => void;
  onAddVIP: (name: string, phone: string) => void;
  onDeleteProfile: (pid: string) => void;
  onSetExpiry: (pid: string, expiryDate: string) => void;
  onSetMemberType?: (pid: string, memberType: 'regular' | 'demo') => void;
  onToggleVipAccess: (pid: string, enabled: boolean) => void;
  onSendBroadcast: (title: string, msg: string, targets: string[], presentation?:BroadcastPresentation) => Promise<boolean>;
  onToggleVipAutoMode?: (pid: string, enabled: boolean) => void;
  onUpdateVipDestination?: (pid: string, mode: 'private' | 'group' | 'channel', destinationJid?: string, destinationName?: string) => void;
  onUpdateVipScheduleEnabled?: (pid: string, type: GameType, enabled: boolean) => void;
  broadcasts: Broadcast[];
}

export const VipManagement: React.FC<VipManagementProps> = ({
  profiles,
  onSelectClient,
  onAddVIP,
  onDeleteProfile,
  onSetExpiry,
  onSetMemberType,
  onToggleVipAccess,
  onSendBroadcast,
  onToggleVipAutoMode,
  onUpdateVipDestination,
  onUpdateVipScheduleEnabled,
}) => {
  const [broadcastLink,setBroadcastLink]=useState('');
  const [broadcastFormat,setBroadcastFormat]=useState<'text'|'png'>('text');
  const [broadcastDesign,setBroadcastDesign]=useState(0);
  const [broadcastPreview,setBroadcastPreview]=useState('');
  const broadcastLock=useRef(false);
  const previewBroadcast=()=>{try{setBroadcastPreview(renderBroadcastImage(bcastTitle,bcastMsg,broadcastDesign));}catch(error:any){alert(error.message);}};
  const [bcastTitle, setBcastTitle] = useState('');
  const [bcastMsg, setBcastMsg] = useState('');
  const [bcastTargets, setBcastTargets] = useState<string[]>([]);
  const [isBroadcastSending, setIsBroadcastSending] = useState(false);
  const [isBroadcastPickerOpen, setIsBroadcastPickerOpen] = useState(false);
  const [cName, setCName] = useState('');
  const [cPhone, setCPhone] = useState('');

  const [isPickerOpen, setIsPickerOpen] = useState(false);
  const [activePickerTargetPid, setActivePickerTargetPid] = useState<string | null>(null);
  const [activePickerMode, setActivePickerMode] = useState<'group' | 'channel'>('group');
  const [isSendingWa, setIsSendingWa] = useState<Record<string, boolean>>({});
  const [channelDrafts, setChannelDrafts] = useState<Record<string, string>>({});
  // Large client lists stay compact. Opening one settings panel closes the
  // previous one, so dozens of VIPs remain quick to scan on mobile.
  const [expandedClientId, setExpandedClientId] = useState<string | null>(null);
  const [memberFilter, setMemberFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [deliveryFilter, setDeliveryFilter] = useState<'all' | 'demo' | GameType | 'sending' | 'paused'>('all');
  const [membershipToday, setMembershipToday] = useState(vipBusinessDate);
  useEffect(() => {
    const interval = window.setInterval(() => setMembershipToday(vipBusinessDate()), 60_000);
    return () => window.clearInterval(interval);
  }, []);

  // UI FIX: Derive membership status once from expiryDate so counts, filters and badges cannot disagree.
  const vipMembers = useMemo(() => {
    return Object.entries(profiles || {}).flatMap(([pid, profile]) => {
      if (pid === 'admin1' || pid === 'client_dummy' || !profile) return [];
      const name = String(profile.name || '').trim().toLowerCase();
      const phone = String(profile.phone || profile.vipSchTarget || '').replace(/\D/g, '');
      if ((name === '' || name === 'vip client' || name === 'vip member' || name === 'dummy test vip') && phone.length < 10 && ![profile.phone, profile.vipSchTarget, profile.vipGroupJid, profile.vipChannelJid].some(isTelegramTarget)) return [];

      const daysLeft = vipMembershipDaysLeft(profile.expiryDate);

      return [{ pid, profile, isActive: daysLeft !== null && daysLeft > 0, daysLeft }];
    });
  }, [profiles, membershipToday]);

  const activeMemberCount = vipMembers.filter((member) => member.isActive).length;
  const inactiveMemberCount = vipMembers.length - activeMemberCount;
  const visibleVipMembers = vipMembers.filter(({ profile, isActive }) => {
    const membershipMatches = memberFilter === 'all' || (memberFilter === 'active' ? isActive : !isActive);
    if (!membershipMatches) return false;
    if (deliveryFilter === 'all') return true;
    if (deliveryFilter === 'demo') return profile.vipMemberType === 'demo';
    if (deliveryFilter === 'sending') return profile.vipAutoMode !== false;
    if (deliveryFilter === 'paused') return profile.vipAutoMode === false;
    return profile.vipScheduleEnabled?.[deliveryFilter] !== false;
  });

  // Native phone contacts picker with fallback
  const handlePickPhoneContact = async () => {
    if ('contacts' in navigator && 'select' in (navigator as any).contacts) {
      try {
        const contacts = await (navigator as any).contacts.select(['name', 'tel'], { multiple: false });
        if (contacts && contacts.length > 0) {
          const contact = contacts[0];
          const name = contact.name?.[0] || 'VIP Client';
          const tel = contact.tel?.[0] || '';
          const cleanPhone = tel.replace(/\D/g, '');
          setCName(name);
          setCPhone(cleanPhone);
          return;
        }
      } catch (err) {
        console.log('Native contact selection cancelled or failed, opening WA target selector modal');
      }
    }
    // Fallback to WhatsApp Target Selector Modal
    setIsPickerOpen(true);
  };

  const handleAdd = () => {
    if (!cName.trim()) {
      alert('Client Name is required!');
      return;
    }
    const phone = normalizeTargetJid(cPhone);
    if (!phone) {
      alert('Valid WhatsApp number ya synced WhatsApp / Telegram destination select karein.');
      return;
    }
    onAddVIP(cName.trim(), phone);
    setCName('');
    setCPhone('');
  };

  const handleBroadcast = async () => {
    if (isBroadcastSending||broadcastLock.current) return;
    if (!bcastTitle.trim() || !bcastMsg.trim()) {
      alert('Title and Message are required for broadcast!');
      return;
    }
    if (bcastTargets.length === 0) {
      alert('Live Push ke liye kam se kam ek WhatsApp / Telegram target select karein.');
      return;
    }
    broadcastLock.current=true;setIsBroadcastSending(true);
    try {
      const link=normalizeBroadcastLink(broadcastLink);
      const png=broadcastFormat==='png'?renderBroadcastImage(bcastTitle,bcastMsg,broadcastDesign):undefined;
      if (await onSendBroadcast(bcastTitle, bcastMsg, bcastTargets,{format:broadcastFormat,design:broadcastDesign,png,link})) {
        setBcastTitle('');
        setBcastMsg('');setBroadcastPreview('');setBroadcastLink('');
      }
    } catch(error:any){alert(error.message||'Broadcast not queued');} finally {
      broadcastLock.current=false;setIsBroadcastSending(false);
    }
  };

  const handleShareLink = (pid: string, name: string) => {
    const origin = window.location.origin;
    const token = String(profiles[pid]?.vipAccessToken || '');
    if (!token) {
      alert('VIP secure token abhi prepare ho raha hai. 2 seconds baad retry karein.');
      return;
    }
    const link = `${origin}/?vip=${encodeURIComponent(pid)}#token=${encodeURIComponent(token)}`;
    const msg = `🚀 *TITAN NOVA VIP PORTAL*\nHello ${name}, here is your personal application link:\n\n🔗 ${link}`;

    if (navigator.clipboard) {
      navigator.clipboard.writeText(msg);
      alert(`✅ VIP Link for ${name} copied to clipboard! Send via WhatsApp.`);
    } else {
      prompt('Copy VIP App Link:', link);
    }
  };

  const handleSendInstantWa = async (pid: string, name: string, targetPhone: string) => {
    const rawTarget = targetPhone || profiles[pid]?.phone || '';
    const cleanTarget = normalizeTargetJid(rawTarget);
    if (!cleanTarget) {
      alert('Please select a valid WhatsApp / Telegram destination first!');
      return;
    }

    const origin = window.location.origin;
    const token = String(profiles[pid]?.vipAccessToken || '');
    if (!token) {
      alert('VIP secure token abhi prepare ho raha hai. Please retry.');
      return;
    }
    const vipLink = `${origin}/?vip=${encodeURIComponent(pid)}#token=${encodeURIComponent(token)}`;
    const msg = `🚀 *TITAN NOVA VIP EXCLUSIVE ACCESS*\n\nHello *${name}*,\nYour VIP Portal dashboard & daily market intel updates are ready!\n\n🔗 *Access Link:* ${vipLink}\n\n⚡ *Status:* DISPATCHED VIA TITAN GATEWAY`;

    setIsSendingWa((prev) => ({ ...prev, [pid]: true }));
    try {
      // Real queue — bot drains /api/bot/pending_broadcasts
      const res = await fetch(apiUrl('/api/bot/broadcast'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: msg,
          targets: [cleanTarget],
          profileId: pid,
          broadcastKind: 'vip-test',
        }),
      });
      const json = await res.json();
      if (json.status === 'success') {
        alert(`✅ Queued to ${cleanTarget}. Bot will send in ~10s if online.`);
      } else {
        alert(`⚠️ Gateway error: ${json.message || 'Check the selected platform connection.'}`);
      }
    } catch (e: any) {
      alert(`❌ Failed to queue message: ${e.message || e}`);
    } finally {
      setIsSendingWa((prev) => ({ ...prev, [pid]: false }));
    }
  };

  return (
    <div className="px-3 py-4 space-y-4">
      {/* Target Selector Modal for Contact Pick */}
      <TargetSelectorModal
        isOpen={isPickerOpen}
        channelPickerOnly={Boolean(activePickerTargetPid) && activePickerMode === 'channel'}
        showChannels
        singleSelect
        onClose={() => {
          setIsPickerOpen(false);
          setActivePickerTargetPid(null);
          setActivePickerMode('group');
        }}
        selectedTargets={activePickerTargetPid
          ? activePickerMode === 'channel'
            ? (profiles[activePickerTargetPid]?.vipChannelJid ? [String(profiles[activePickerTargetPid].vipChannelJid)] : [])
            : (profiles[activePickerTargetPid]?.vipGroupJid ? [String(profiles[activePickerTargetPid].vipGroupJid)] : [])
          : cPhone ? [cPhone] : []}
        onSaveTargets={(targets) => {
          if (targets.length > 0 && activePickerTargetPid) {
            const channelJid = targets.find(isChannelTarget);
            const groupJid = targets.find(isGroupTarget);
            if (channelJid) {
              onUpdateVipDestination?.(activePickerTargetPid, 'channel', channelJid, channelJid.split('@')[0]);
            } else if (groupJid) {
              onUpdateVipDestination?.(activePickerTargetPid, 'group', groupJid, groupJid.split('@')[0]);
            } else if (normalizeTargetJid(targets[0], 'phone')) {
              onUpdateVipDestination?.(activePickerTargetPid, 'private', targets[0], targets[0]);
            } else {
              alert('VIP destination ke liye WhatsApp Group ya Channel select karein.');
              return;
            }
          } else if (targets.length > 0) {
            const raw = targets[0];
            const clean = raw.split('@')[0];
            setCPhone(raw);
            if (!cName) setCName(`VIP ${clean.slice(-4) || 'Client'}`);
          }
        }}
      />

      <TargetSelectorModal
        isOpen={isBroadcastPickerOpen}
        onClose={() => setIsBroadcastPickerOpen(false)}
        selectedTargets={bcastTargets}
        onSaveTargets={setBcastTargets}
        showChannels
      />

      {/* Push Broadcast Section */}
      <div className="native-card bg-[#232E3C] border border-[rgba(42,171,238,0.25)] p-4 rounded-2xl shadow-xl" style={{ background: 'rgba(42,171,238,0.04)' }}>
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-[rgba(42,171,238,0.15)] text-[#2AABEE] flex items-center justify-center shrink-0">
            <Megaphone className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-[14px] font-black text-white">Live Push Broadcast</h3>
            <p className="text-[9px] text-[#7A9CB8] uppercase tracking-wider mt-0.5">Send only to individually selected WhatsApp / Telegram targets</p>
          </div>
        </div>

        <div role="group" aria-label="Broadcast format" className="flex gap-2 mb-3">
          {(['text','png'] as const).map(format=><button key={format} type="button" aria-pressed={broadcastFormat===format} disabled={isBroadcastSending} onClick={()=>{setBroadcastFormat(format);setBroadcastPreview('');}} className={`flex-1 rounded-lg py-2 border text-xs font-bold ${broadcastFormat===format?'bg-sky-700 border-sky-400 text-white':'border-white/20 text-slate-300'}`}>{format==='text'?'TXT':'PNG'}</button>)}
        </div>
        {broadcastFormat==='png'&&<div className="mb-3 space-y-2">
          <div role="group" aria-label="Broadcast PNG design" className="grid grid-cols-5 gap-1">
            {BROADCAST_DESIGNS.map((theme,index)=><button key={theme.name} type="button" aria-pressed={broadcastDesign===index} disabled={isBroadcastSending} onClick={()=>{setBroadcastDesign(index);setBroadcastPreview('');}} className="rounded-lg py-3 text-[9px] font-bold border-2" style={{background:theme.bg,color:theme.ink,borderColor:broadcastDesign===index?theme.accent:'transparent'}}>{index+1} {theme.name}</button>)}
          </div>
          <p className="text-[10px] text-slate-400">Your title and full message appear in the PNG, including line breaks. Preview before sending.</p>
        </div>}
        <input
          type="text"
          value={bcastTitle} disabled={isBroadcastSending}
          onChange={(e) => {setBcastTitle(e.target.value);setBroadcastPreview('');}}
          placeholder="Broadcast Title (e.g. 🔥 New Kalyan Target Alert)"
          className="w-full bg-[#2B3A4D] border border-[rgba(255,255,255,0.07)] text-white text-sm py-2.5 px-3 rounded-xl font-bold mb-2 outline-none focus:border-[#2AABEE]"
        />
        <textarea
          rows={2}
          value={bcastMsg} disabled={isBroadcastSending}
          onChange={(e) => {setBcastMsg(e.target.value);setBroadcastPreview('');}}
          placeholder="Broadcast Message content..."
          className="w-full bg-[#2B3A4D] border border-[rgba(255,255,255,0.07)] text-white text-sm py-2.5 px-3 rounded-xl font-bold mb-3 outline-none focus:border-[#2AABEE]"
        />
        <label className="block mb-3 text-[11px] text-slate-300">Link URL (optional)
          <input type="url" aria-label="Broadcast Link URL" value={broadcastLink} disabled={isBroadcastSending} onChange={e=>setBroadcastLink(e.target.value)} placeholder="https://example.com/join" className="mt-1 w-full rounded-xl border border-white/10 bg-[#2B3A4D] px-3 py-2.5 text-sm text-white outline-none focus:border-sky-400"/>
          <span className="block mt-1 text-[10px] text-slate-400">PNG: clickable link in the caption. TXT: link below the message. Leave blank for no link.</span>
        </label>
        {broadcastFormat==='png'&&<div className="mb-3"><button type="button" disabled={isBroadcastSending||!bcastTitle.trim()||!bcastMsg.trim()} onClick={previewBroadcast} className="w-full py-2 rounded-lg bg-sky-900 text-white text-xs">Preview broadcast PNG</button>{broadcastPreview&&<img src={broadcastPreview} alt="Broadcast PNG preview" className="w-full mt-2 rounded-lg"/>}{broadcastPreview&&broadcastLink.trim()&&<p className="mt-1 break-all text-xs text-sky-300">Caption: {broadcastLink.trim()}</p>}</div>}
        <button
          type="button"
          disabled={isBroadcastSending} onClick={() => setIsBroadcastPickerOpen(true)}
          className="w-full mb-2 bg-[#17212B] border border-[rgba(42,171,238,0.35)] text-[#2AABEE] py-2.5 rounded-xl font-black text-[10px] uppercase active:scale-95 flex items-center justify-center gap-1.5"
        >
          <Smartphone className="w-4 h-4" /> Select WhatsApp / Telegram Targets ({bcastTargets.length})
        </button>
        <button
          onClick={handleBroadcast}
          disabled={isBroadcastSending}
          className="w-full bg-[#2AABEE] text-white py-3 rounded-xl font-black text-[11px] uppercase active:scale-95 shadow-lg shadow-[rgba(42,171,238,0.2)] flex items-center justify-center gap-1.5"
        >
          <Send className="w-4 h-4" /> Send Live Push Notification
        </button>
      </div>

      {/* Add New VIP Member */}
      <div className="native-card bg-[#232E3C] border border-[rgba(250,199,72,0.25)] p-4 rounded-2xl shadow-xl" style={{ background: 'rgba(250,199,72,0.04)' }}>
        <div className="flex justify-between items-center mb-3">
          <div className="flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-[#FAC748]" />
            <h3 className="text-[14px] font-black text-white">Add VIP Client</h3>
          </div>
          <button
            onClick={handlePickPhoneContact}
            className="bg-[rgba(42,171,238,0.15)] border border-[rgba(42,171,238,0.3)] text-[#2AABEE] px-3 py-1.5 rounded-xl font-black text-[10px] uppercase flex items-center gap-1.5 active:scale-95 transition-all shadow-md"
          >
            <Contact className="w-3.5 h-3.5" /> Pick Contact
          </button>
        </div>

        <div className="space-y-2 mb-3">
          <input
            type="text"
            value={cName}
            onChange={(e) => setCName(e.target.value)}
            placeholder="VIP Display Name"
            className="w-full bg-[#2B3A4D] border border-[rgba(255,255,255,0.07)] text-white text-sm py-2.5 px-3 rounded-xl font-bold outline-none focus:border-[#FAC748]"
          />
          <div className="relative">
            <input
              type="text"
              value={cPhone}
              onChange={(e) => setCPhone(e.target.value)}
              placeholder="WhatsApp Mobile Number (e.g. 91XXXXXXXXXX)"
              className="w-full bg-[#2B3A4D] border border-[rgba(255,255,255,0.07)] text-white text-sm py-2.5 px-3 rounded-xl font-bold outline-none focus:border-[#FAC748]"
            />
            <button
              onClick={() => setIsPickerOpen(true)}
              className="absolute right-2 top-2 text-[#2AABEE] text-[10px] font-bold bg-[#17212B] px-2 py-1 rounded-lg border border-[rgba(42,171,238,0.2)] hover:bg-[#2AABEE] hover:text-white transition-all"
            >
              Select
            </button>
          </div>
        </div>

        <button
          onClick={handleAdd}
          className="w-full bg-[#FAC748] text-black py-3 rounded-xl font-black text-[11px] uppercase active:scale-95 shadow-md flex items-center justify-center gap-1.5"
        >
          <UserPlus className="w-4 h-4" /> Add VIP Member
        </button>
      </div>

      {/* Profiles List */}
      <div>
        <div className="flex items-center justify-between mb-2 px-1">
          <div>
            <span className="text-[11px] font-black text-[#7A9CB8] uppercase tracking-widest flex items-center gap-1.5">
              <Users className="w-4 h-4 text-[#2AABEE]" /> VIP Profiles
            </span>
            <p className="text-[8px] text-[#52677D] mt-0.5">Settings खोलने पर सिर्फ एक client expand होगा</p>
          </div>
          <span className="text-[9px] bg-[#2B3A4D] text-white px-2 py-0.5 rounded-full font-bold">
            {vipMembers.length} Clients
          </span>
        </div>

        <div className="grid grid-cols-3 gap-1.5 mb-3 p-1.5 rounded-xl bg-[#17212B] border border-white/5" role="tablist" aria-label="VIP membership filter">
          {([
            ['all', 'ALL', vipMembers.length],
            ['active', 'ACTIVE', activeMemberCount],
            ['inactive', 'INACTIVE', inactiveMemberCount],
          ] as const).map(([value, label, count]) => {
            const selected = memberFilter === value;
            const color = value === 'active' ? '#00C26F' : value === 'inactive' ? '#FF5D5D' : '#2AABEE';
            return (
              <button
                key={value}
                type="button"
                role="tab"
                aria-selected={selected}
                onClick={() => {
                  setMemberFilter(value);
                  setExpandedClientId(null);
                }}
                className={`h-9 rounded-lg text-[9px] font-black flex items-center justify-center gap-1.5 border transition-all active:scale-95 ${selected ? 'bg-[#2B3A4D] text-white border-white/10 shadow-sm' : 'text-[#7A9CB8] border-transparent'}`}
              >
                <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
                {label}
                <span className="min-w-[18px] px-1 py-0.5 rounded-md bg-[#17212B] text-[8px]" style={{ color }}>{count}</span>
              </button>
            );
          })}
        </div>

        <div className="flex gap-1.5 mb-3 overflow-x-auto pb-1 scrollbar-none" role="tablist" aria-label="VIP delivery filter">
          {([
            ['all', 'ALL TYPES'],
            ['demo', 'DEMO'],
            ['ank', 'ANK'],
            ['jodi', 'JODI'],
            ['pannel', 'PANEL'],
            ['sending', 'SEND ON'],
            ['paused', 'SEND OFF'],
          ] as const).map(([value, label]) => (
            <button
              key={value}
              type="button"
              role="tab"
              aria-selected={deliveryFilter === value}
              onClick={() => {
                setDeliveryFilter(value);
                setExpandedClientId(null);
              }}
              className={`shrink-0 h-8 px-3 rounded-lg text-[8px] font-black border transition-all active:scale-95 ${deliveryFilter === value ? 'bg-[#2AABEE] text-white border-[#2AABEE]' : 'bg-[#1C2733] text-[#7A9CB8] border-white/5'}`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="space-y-3 pb-8">
          {vipMembers.length === 0 && (
            <div className="native-card bg-[#232E3C] border border-dashed border-[rgba(255,255,255,0.15)] rounded-2xl p-6 text-center">
              <Users className="w-8 h-8 text-[#7A9CB8] mx-auto mb-2 opacity-60" />
              <p className="text-white font-black text-sm">No VIP clients yet</p>
              <p className="text-[#7A9CB8] text-[11px] mt-1">Upar se name + number daal ke Add VIP Member dabao</p>
            </div>
          )}
          {vipMembers.length > 0 && visibleVipMembers.length === 0 && (
            <div className="native-card bg-[#232E3C] border border-dashed border-[rgba(255,255,255,0.15)] rounded-2xl p-5 text-center">
              <Users className="w-7 h-7 text-[#7A9CB8] mx-auto mb-2 opacity-60" />
              <p className="text-white font-black text-xs">No matching members</p>
              <p className="text-[#7A9CB8] text-[10px] mt-1">Membership ya delivery filter change karke dekhein.</p>
            </div>
          )}
          {visibleVipMembers.map(({ pid, profile: c, isActive: isMembershipActive, daysLeft }) => {
            const displayName = (c.name && String(c.name).trim()) || 'VIP Client';
            const isDummy = false;
            const expDate = c.expiryDate || '';

            let expLabel = 'No Expiry Set';
            let expColor = 'text-[#7A9CB8]';

            if (expDate) {
              expLabel = isMembershipActive ? `${daysLeft}d left (${expDate})` : `Expired (${expDate})`;
              expColor = isMembershipActive ? 'text-[#00C26F]' : 'text-[#FF5D5D]';
            }

            const currentSchTarget = c.vipSchTarget || c.phone || '';
            const isGroupDestination = c.vipDeliveryMode === 'group' && Boolean(c.vipGroupJid);
            const isChannelDestination = c.vipDeliveryMode === 'channel' && Boolean(c.vipChannelJid);
            const isPrivateDestination = !isGroupDestination && !isChannelDestination;
            const currentDeliveryTarget = isGroupDestination
              ? String(c.vipGroupJid)
              : isChannelDestination
                ? String(c.vipChannelJid)
                : currentSchTarget;
            const destinationLabel = isGroupDestination ? 'GROUP' : isChannelDestination ? 'CHANNEL' : 'PRIVATE';

            return (
              <div
                key={pid}
                className={`native-card bg-[#232E3C] border border-[rgba(255,255,255,0.07)] rounded-2xl overflow-hidden shadow-md border-l-4 ${
                  isDummy ? 'border-l-[#7B8FFF]' : 'border-l-[#2AABEE]'
                }`}
              >
                {/* Main Row */}
                <div
                  onClick={() => onSelectClient(pid)}
                  className="p-3 flex justify-between items-center gap-2 cursor-pointer hover:bg-[rgba(255,255,255,0.02)] transition-colors"
                >
                  <div className="flex items-center gap-2.5 min-w-0 flex-1">
                    <div
                      className={`w-10 h-10 rounded-full bg-[#2B3A4D] border border-[rgba(255,255,255,0.07)] flex items-center justify-center font-bold ${
                        isDummy ? 'text-[#7B8FFF]' : 'text-[#2AABEE]'
                      }`}
                    >
                      {displayName.charAt(0).toUpperCase()}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <p className="text-white font-black text-[13px] uppercase leading-tight truncate" title={displayName}>{displayName}</p>
                        <span className={`shrink-0 px-1.5 py-0.5 rounded-md text-[7px] font-black border ${isMembershipActive ? 'text-[#00C26F] bg-[rgba(0,194,111,0.1)] border-[rgba(0,194,111,0.22)]' : 'text-[#FF5D5D] bg-[rgba(255,93,93,0.1)] border-[rgba(255,93,93,0.22)]'}`}>
                          {isMembershipActive ? 'ACTIVE' : 'INACTIVE'}
                        </span>
                        {c.vipMemberType === 'demo' && (
                          <span className="shrink-0 px-1.5 py-0.5 rounded-md text-[7px] font-black text-[#FAC748] bg-[rgba(250,199,72,0.1)] border border-[rgba(250,199,72,0.22)]">DEMO</span>
                        )}
                      </div>
                      {c.phone && (
                        <p className="text-[10px] text-[#7A9CB8] font-mono font-bold truncate" title={`+${String(c.phone).replace(/\D/g, '')}`}>+{String(c.phone).replace(/\D/g, '')}</p>
                      )}
                      <p className={`text-[10px] ${expColor} font-bold mt-0.5 flex items-center gap-1`}>
                        <CalendarCheck className="w-3 h-3" /> {expLabel}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0" onClick={(e) => e.stopPropagation()}>
                    <button
                      onClick={() => handleShareLink(pid, displayName)}
                      className="w-8 h-8 text-[#2AABEE] bg-[rgba(42,171,238,0.12)] rounded-xl flex items-center justify-center active:scale-95 border border-[rgba(42,171,238,0.2)]"
                      title="Copy VIP App Link"
                    >
                      <Link className="w-4 h-4" />
                    </button>
                    {!isDummy && (
                      <button
                        onClick={() => onDeleteProfile(pid)}
                        className="w-8 h-8 text-[#FF5D5D] bg-[rgba(255,93,93,0.12)] rounded-xl flex items-center justify-center active:scale-95 border border-[rgba(255,93,93,0.2)]"
                        title="Delete Profile"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Always-visible compact operational summary. */}
                <div className="px-3.5 pb-3 flex items-center gap-1.5 flex-wrap">
                  <span className={`px-2 py-1 rounded-lg text-[8px] font-black border ${c.vipAutoMode !== false ? 'text-[#00C26F] bg-[rgba(0,194,111,0.1)] border-[rgba(0,194,111,0.2)]' : 'text-[#FF8A8A] bg-[rgba(255,93,93,0.1)] border-[rgba(255,93,93,0.2)]'}`}>
                    AUTO {c.vipAutoMode !== false ? 'ON' : 'OFF'}
                  </span>
                  <span className="px-2 py-1 rounded-lg text-[8px] font-black text-[#2AABEE] bg-[rgba(42,171,238,0.1)] border border-[rgba(42,171,238,0.2)]">
                    {destinationLabel}
                  </span>
                  <span className="px-2 py-1 rounded-lg text-[8px] font-black text-[#CBD5E1] bg-[#1C2733] border border-white/5">
                    {(['ank', 'jodi', 'pannel'] as GameType[])
                      .filter((type) => c.vipScheduleEnabled?.[type] !== false)
                      .map((type) => type === 'pannel' ? 'PAN' : type.toUpperCase())
                      .join(' · ') || 'NO GAMES'}
                  </span>
                  <span className={`px-2 py-1 rounded-lg text-[8px] font-black border ${c.vipAccessEnabled !== false ? 'text-[#FAC748] bg-[rgba(250,199,72,0.08)] border-[rgba(250,199,72,0.18)]' : 'text-[#94A3B8] bg-[#1C2733] border-white/5'}`}>
                    {c.vipAccessEnabled !== false ? 'EDIT' : 'READ ONLY'}
                  </span>
                  <button
                    type="button"
                    onClick={() => setExpandedClientId((current) => current === pid ? null : pid)}
                    className="ml-auto min-w-[88px] px-2.5 py-1.5 rounded-lg text-[9px] font-black text-[#2AABEE] bg-[rgba(42,171,238,0.12)] border border-[rgba(42,171,238,0.25)] flex items-center justify-center gap-1 active:scale-95"
                    aria-expanded={expandedClientId === pid}
                  >
                    <Settings2 className="w-3 h-3" />
                    {expandedClientId === pid ? 'CLOSE' : 'SETTINGS'}
                    {expandedClientId === pid ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                  </button>
                </div>

                {expandedClientId === pid && (
                  <>
                {/* VIP Event-Driven Auto Dispatch */}
                <div className="px-3.5 py-2.5 bg-[#17212B] border-t border-[rgba(255,255,255,0.07)] space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-[#00C26F] uppercase flex items-center gap-1">
                      <Smartphone className="w-3.5 h-3.5" /> VIP Auto Mode
                    </span>
                    <label className="switch m-0 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={c.vipAutoMode !== false}
                        onChange={(e) => onToggleVipAutoMode?.(pid, e.target.checked)}
                      />
                      <span className="slider"></span>
                    </label>
                  </div>

                  <div className="grid grid-cols-3 gap-1.5">
                    <button
                      type="button"
                      onClick={() => onUpdateVipDestination?.(pid, 'private')}
                      className={`rounded-lg px-2 py-1.5 text-[9px] font-black border ${isPrivateDestination ? 'bg-[#00C26F] text-white border-[#00C26F]' : 'bg-[#2B3A4D] text-[#7A9CB8] border-white/10'}`}
                    >
                      PRIVATE
                    </button>
                    <button
                      type="button"
                      onClick={() => { setActivePickerMode('group'); setActivePickerTargetPid(pid); setIsPickerOpen(true); }}
                      className={`rounded-lg px-2 py-1.5 text-[9px] font-black border ${isGroupDestination ? 'bg-[#2AABEE] text-white border-[#2AABEE]' : 'bg-[#2B3A4D] text-[#7A9CB8] border-white/10'}`}
                    >
                      GROUP
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setActivePickerMode('channel');
                        setActivePickerTargetPid(pid);
                        setIsPickerOpen(true);
                      }}
                      className={`rounded-lg px-1 py-1.5 text-[8px] font-black border ${isChannelDestination ? 'bg-[#7B8FFF] text-white border-[#7B8FFF]' : 'bg-[#2B3A4D] text-[#7A9CB8] border-white/10'}`}
                    >
                      CHANNEL
                    </button>
                  </div>

                  <div className="flex gap-1.5">
                    <button type="button" className="text-xs text-[#2AABEE]" onClick={() => { setActivePickerMode('group'); setActivePickerTargetPid(pid); setIsPickerOpen(true); }}>Select WhatsApp / Telegram destination</button>
                    <input
                      type="text"
                      value={channelDrafts[pid] ?? c.vipChannelJid ?? ''}
                      onChange={(event) => setChannelDrafts((current) => ({ ...current, [pid]: event.target.value }))}
                      placeholder="Channel JID: 120363...@newsletter"
                      className="min-w-0 flex-1 bg-[#2B3A4D] text-white text-[9px] font-mono border border-white/10 rounded-lg px-2 py-1.5 outline-none focus:border-[#7B8FFF]"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const jid = String(channelDrafts[pid] ?? c.vipChannelJid ?? '').trim();
                        onUpdateVipDestination?.(pid, 'channel', jid, c.vipChannelName || jid.split('@')[0]);
                      }}
                      className="px-2 py-1.5 rounded-lg text-[8px] font-black text-white bg-[#7B8FFF] active:scale-95"
                    >
                      SAVE
                    </button>
                  </div>

                  <div className="flex items-center justify-between bg-[#2B3A4D] border border-[rgba(0,194,111,0.18)] rounded-xl px-2.5 py-2">
                    <div>
                      <p className="text-[8px] font-black text-[#7A9CB8] uppercase">Permanent {destinationLabel} Destination</p>
                      <p className="text-xs font-mono font-bold text-[#00C26F] mt-0.5">
                        {isGroupDestination
                          ? (c.vipGroupName || c.vipGroupJid)
                          : isChannelDestination
                            ? (c.vipChannelName || c.vipChannelJid)
                            : (currentSchTarget ? isTelegramTarget(currentSchTarget) ? currentSchTarget : `+${currentSchTarget.replace(/\D/g, '')}` : 'No phone')}
                      </p>
                    </div>
                    <button
                      onClick={() => handleSendInstantWa(pid, displayName, currentDeliveryTarget)}
                      disabled={isSendingWa[pid]}
                      className="text-[9px] font-black uppercase text-[#2AABEE] bg-[rgba(42,171,238,0.15)] border border-[rgba(42,171,238,0.3)] px-2.5 py-1 rounded-lg flex items-center gap-1 active:scale-95 hover:bg-[#2AABEE] hover:text-white transition-all disabled:opacity-50"
                    >
                      <Send className="w-3 h-3" /> {isSendingWa[pid] ? 'Queueing...' : 'Test Send'}
                    </button>
                  </div>

                  <div className="bg-[rgba(0,194,111,0.08)] border border-[rgba(0,194,111,0.18)] rounded-xl px-3 py-2">
                    <p className="text-[9px] font-black text-[#00C26F]">Digits + Rate available = Card Ready</p>
                    <p className="text-[8px] text-[#7A9CB8] mt-1">Same recovery sequence · card aur PASS/FAIL reply selected destination par auto-send honge.</p>
                  </div>

                  {/* Per-VIP card-type auto switches */}
                  <div className="grid grid-cols-3 gap-1.5 pt-1">
                    {([
                      ['ank', 'ANK'],
                      ['jodi', 'JODI'],
                      ['pannel', 'PANEL'],
                    ] as Array<[GameType, string]>).map(([type, label]) => {
                      const enabled = c.vipScheduleEnabled?.[type] !== false;
                      return (
                        <label key={type} className="flex items-center justify-between gap-1 bg-[#2B3A4D] rounded-lg px-2 py-1.5 border border-[rgba(255,255,255,0.06)] cursor-pointer">
                          <span className="text-[8px] font-black text-white">{label}</span>
                          <input
                            type="checkbox"
                            checked={enabled}
                            onChange={(e) => onUpdateVipScheduleEnabled?.(pid, type, e.target.checked)}
                            className="accent-[#00C26F]"
                          />
                        </label>
                      );
                    })}
                  </div>

                  <div className="flex items-center justify-between gap-2 bg-[#2B3A4D] rounded-lg px-2 py-1.5 border border-white/5">
                    <span className="text-[8px] font-black text-[#7A9CB8]">MEMBER TYPE</span>
                    <div className="grid grid-cols-2 gap-1 w-[150px]">
                      {(['regular', 'demo'] as const).map((memberType) => (
                        <button
                          key={memberType}
                          type="button"
                          onClick={() => onSetMemberType?.(pid, memberType)}
                          className={`rounded-md py-1 text-[8px] font-black border ${((c.vipMemberType || 'regular') === memberType) ? (memberType === 'demo' ? 'bg-[#FAC748] text-black border-[#FAC748]' : 'bg-[#00C26F] text-white border-[#00C26F]') : 'bg-[#1C2733] text-[#7A9CB8] border-white/5'}`}
                        >
                          {memberType === 'regular' ? 'MEMBER' : 'DEMO'}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Expiry Date Set */}
                <div className="px-3.5 py-2 flex items-center gap-2 border-t border-[rgba(255,255,255,0.07)] bg-[#1C2733]">
                  <span className="text-[9px] font-bold text-[#FAC748] uppercase shrink-0">Expiry Date:</span>
                  <input
                    type="date"
                    value={expDate}
                    onChange={(e) => onSetExpiry(pid, e.target.value)}
                    className="bg-[#2B3A4D] border border-[rgba(255,255,255,0.1)] text-white rounded-lg px-2 py-1 text-[11px] font-bold outline-none flex-1 min-w-0"
                  />
                </div>

                {/* Access Toggle */}
                <div className="px-3.5 py-2.5 flex items-center justify-between border-t border-[rgba(255,255,255,0.07)] bg-[#1C2733]">
                  <div>
                    <p className="text-[9px] font-bold text-[#7A9CB8] uppercase">App Editing Permission</p>
                    <p
                      className={`text-[10px] font-black ${
                        c.vipAccessEnabled !== false ? 'text-[#00C26F]' : 'text-[#FF5D5D]'
                      }`}
                    >
                      {c.vipAccessEnabled !== false ? 'Enabled (VIP can edit)' : 'Locked (Read-Only mode)'}
                    </p>
                  </div>
                  <label className="switch m-0 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={c.vipAccessEnabled !== false}
                      onChange={(e) => onToggleVipAccess(pid, e.target.checked)}
                    />
                    <span className="slider"></span>
                  </label>
                </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
