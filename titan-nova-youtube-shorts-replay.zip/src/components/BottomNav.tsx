import React from 'react';
import { Gamepad2, PieChart, Zap, Users, IndianRupee, Crown, Bot } from 'lucide-react';

export type MainNavTab = 'ledger' | 'audit' | 'smart' | 'clients' | 'payments' | 'settings' | 'membership' | 'bot';

interface BottomNavProps {
  currentTab: MainNavTab;
  onSelectTab: (tab: MainNavTab) => void;
  isMaster: boolean;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onSelectTab,
  isMaster,
}) => {
  const navItems: { id: MainNavTab; label: string; icon: React.ReactNode }[] = [
    { id: 'ledger', label: 'Ledger', icon: <Gamepad2 className="w-5 h-5 mb-0.5" /> },
    { id: 'audit', label: 'Audit', icon: <PieChart className="w-5 h-5 mb-0.5" /> },
  ];

  if (isMaster) {
    // Always show master tabs (not only when activeId === admin1)
    // Otherwise switching to a VIP client hides VIPs/Bot and feels "blank"
    navItems.push({ id: 'bot', label: 'Connect', icon: <Bot className="w-5 h-5 mb-0.5" /> });
    navItems.push({ id: 'smart', label: 'AI Scan', icon: <Zap className="w-5 h-5 mb-0.5" /> });
    navItems.push({ id: 'clients', label: 'VIPs', icon: <Users className="w-5 h-5 mb-0.5" /> });
    navItems.push({ id: 'payments', label: 'Pay', icon: <IndianRupee className="w-5 h-5 mb-0.5" /> });
  } else {
    navItems.push({ id: 'membership', label: 'Member', icon: <Crown className="w-5 h-5 mb-0.5" /> });
  }

  return (
    <nav className="app-bottom-nav fixed bottom-0 left-0 right-0 w-full bg-[#1C2733] border-t border-[rgba(255,255,255,0.06)] flex justify-around items-stretch z-40 h-[72px] pb-[env(safe-area-inset-bottom,8px)] pt-1.5">
      {navItems.map((item) => {
        const isActive = currentTab === item.id;
        return (
          <button
            key={item.id}
            aria-label={item.id==='bot'?'Gateways':item.label}
            aria-current={isActive?'page':undefined}
            onClick={() => onSelectTab(item.id)}
            className={`flex flex-col items-center justify-center font-bold text-[9px] uppercase transition-all px-2 min-w-[52px] relative ${
              isActive ? 'text-[#2AABEE]' : 'text-[#7A9CB8] hover:text-white'
            }`}
          >
            {item.icon}
            <span className="tracking-wider">{item.label}</span>
            {isActive && (
              <span className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-[3px] bg-[#2AABEE] rounded-b-md shadow-[0_0_8px_#2AABEE]" />
            )}
          </button>
        );
      })}
    </nav>
  );
};
