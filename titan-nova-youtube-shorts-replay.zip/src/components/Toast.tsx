import React from 'react';
import { ToastMessage } from '../types';
import { Info, CheckCircle, AlertTriangle, X } from 'lucide-react';

interface ToastProps {
  toasts: ToastMessage[];
  onClose: (id: string) => void;
}

export const ToastContainer: React.FC<ToastProps> = ({ toasts, onClose }) => {
  if (!toasts.length) return null;

  return (
    <div className="fixed top-3 left-1/2 -translate-x-1/2 w-[92%] max-w-sm z-[9999] pointer-events-none flex flex-col gap-2">
      {toasts.map(toast => {
        const isSuccess = toast.type === 'success';
        const isDanger = toast.type === 'danger';

        return (
          <div
            key={toast.id}
            className="tg-toast show pointer-events-auto bg-[#2B3A4D] border border-[rgba(42,171,238,0.25)] rounded-2xl p-3 flex items-center gap-3 shadow-2xl transition-all duration-300"
          >
            <div
              className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
                isSuccess
                  ? 'bg-[rgba(0,194,111,0.2)] text-[#00C26F]'
                  : isDanger
                  ? 'bg-[rgba(255,93,93,0.2)] text-[#FF5D5D]'
                  : 'bg-[rgba(42,171,238,0.2)] text-[#2AABEE]'
              }`}
            >
              {isSuccess ? (
                <CheckCircle className="w-5 h-5" />
              ) : isDanger ? (
                <AlertTriangle className="w-5 h-5" />
              ) : (
                <Info className="w-5 h-5" />
              )}
            </div>

            <div className="flex-1 min-w-0">
              <h4 className="text-[13px] font-bold text-white leading-tight mb-0.5">{toast.title}</h4>
              <p className="text-[11px] text-[#7A9CB8] leading-snug line-clamp-2">{toast.body}</p>
            </div>

            <button
              onClick={() => onClose(toast.id)}
              className="text-[#7A9CB8] hover:text-white text-xs w-6 h-6 flex items-center justify-center shrink-0 rounded-lg active:scale-95 transition-transform"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
