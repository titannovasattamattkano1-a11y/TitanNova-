import React, { useState } from 'react';
import { UserProfile } from '../types';
import { Share2, X, MessageSquare, Briefcase } from 'lucide-react';
import { TargetSelectorModal } from './TargetSelectorModal';
import { apiUrl } from '../utils/api';
import { isTelegramTarget } from '../utils/targetNormalization';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  message: string;
  profiles: Record<string, UserProfile>;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  message,
  profiles,
}) => {
  const [telegramPicker, setTelegramPicker] = useState(false);
  const [error, setError] = useState('');
  const sendTelegram = async (targets: string[]) => {
    if (!targets.length) return;
    try {
      const response = await fetch(apiUrl('/api/bot/broadcast'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message, targets }) });
      const result = await response.json();
      if (!response.ok || result.status !== 'success') throw new Error(result.message || 'Queue failed');
      onClose();
    } catch (e: any) { setError(e.message); }
  };
  if (!isOpen) return null;

  const handleTriggerShare = (phone: string, isBusiness = false) => {
    if (isTelegramTarget(phone)) { void sendTelegram([phone]); return; }
    const text = encodeURIComponent(message);
    const cleanPhone = phone ? (phone.length === 10 ? '91' + phone : phone) : '';

    let url = '';
    if (isBusiness) {
      url = cleanPhone
        ? `intent://send?phone=${cleanPhone}&text=${text}#Intent;package=com.whatsapp.w4b;scheme=whatsapp;end;`
        : `intent://send?text=${text}#Intent;package=com.whatsapp.w4b;scheme=whatsapp;end;`;
    } else {
      url = cleanPhone ? `whatsapp://send?phone=${cleanPhone}&text=${text}` : `whatsapp://send?text=${text}`;
    }

    window.location.href = url;

    setTimeout(() => {
      if (!isBusiness) {
        window.location.href = cleanPhone ? `https://wa.me/${cleanPhone}?text=${text}` : `https://api.whatsapp.com/send?text=${text}`;
      }
    }, 600);

    onClose();
  };

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-[9001] bg-black/70 backdrop-blur-sm flex flex-col justify-end transition-opacity"
    >
      <div className="bg-[#1C2733] border-t border-[rgba(42,171,238,0.2)] rounded-t-3xl p-5 max-h-[85vh] overflow-y-auto animate-in slide-in-from-bottom duration-300">
        <div className="w-9 h-1 bg-[rgba(255,255,255,0.15)] rounded-full mx-auto mb-4" />

        <div className="flex justify-between items-center mb-4">
          <h4 className="text-white font-black text-xs uppercase tracking-widest flex items-center gap-1.5">
            <Share2 className="w-4 h-4 text-[#2AABEE]" /> Dispatch Destination
          </h4>
          <button onClick={onClose} className="text-[#7A9CB8] hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2 mb-4 max-h-60 overflow-y-auto no-scrollbar">
          {Object.keys(profiles).map((pid) => {
            if (pid === 'admin1' || pid === 'client_dummy') return null;
            const c = profiles[pid];
            if (!c.phone) return null;

            return (
              <div
                key={pid}
                className="p-3 bg-[#2B3A4D] border border-[rgba(255,255,255,0.07)] rounded-xl flex justify-between items-center"
              >
                <div>
                  <p className="text-white text-xs font-black uppercase">{c.name}</p>
                  <p className="text-[#7A9CB8] text-[10px]">{isTelegramTarget(c.phone) ? c.phone : `+91 ${c.phone}`}</p>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => handleTriggerShare(c.phone, false)}
                    className="w-9 h-9 bg-[#128C7E] text-white rounded-xl flex items-center justify-center active:scale-95 shadow-md"
                    title="WhatsApp Standard"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleTriggerShare(c.phone, true)}
                    className="w-9 h-9 bg-[rgba(42,171,238,0.2)] text-[#2AABEE] border border-[rgba(42,171,238,0.3)] rounded-xl flex items-center justify-center active:scale-95"
                    title="WhatsApp Business"
                  >
                    <Briefcase className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {error && <p className="text-sm text-red-400">{error}</p>}
        <button className="w-full p-3 mb-3 rounded-xl bg-[#2AABEE] text-white font-bold" onClick={() => setTelegramPicker(true)}>Telegram — Select Group / Channel / Chat</button>
        <TargetSelectorModal isOpen={telegramPicker} onClose={() => setTelegramPicker(false)} selectedTargets={[]} onSaveTargets={targets => void sendTelegram(targets)} showChannels platformOnly="telegram" />
        {/* Global Group Broadcast Option */}
        <div className="flex gap-2 mb-4">
          <button
            onClick={() => handleTriggerShare('', false)}
            className="flex-1 py-3 rounded-xl border border-[rgba(255,255,255,0.07)] text-[#7A9CB8] hover:text-white bg-[#2B3A4D] text-[10px] font-bold uppercase flex justify-center items-center gap-2 active:scale-95"
          >
            <MessageSquare className="w-4 h-4 text-[#00C26F]" /> WA Group Share
          </button>
          <button
            onClick={() => handleTriggerShare('', true)}
            className="flex-1 py-3 rounded-xl border border-[rgba(255,255,255,0.07)] text-[#7A9CB8] hover:text-white bg-[#2B3A4D] text-[10px] font-bold uppercase flex justify-center items-center gap-2 active:scale-95"
          >
            <Briefcase className="w-4 h-4 text-[#2AABEE]" /> Biz Group Share
          </button>
        </div>

        <button
          onClick={onClose}
          className="w-full bg-[rgba(255,93,93,0.1)] text-[#FF5D5D] border border-[rgba(255,93,93,0.2)] py-3 rounded-xl font-bold text-xs uppercase active:scale-95"
        >
          Cancel
        </button>
      </div>
    </div>
  );
};
