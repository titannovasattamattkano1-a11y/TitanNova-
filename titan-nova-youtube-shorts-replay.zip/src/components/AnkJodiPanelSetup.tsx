import {profileCardSenderFormats} from '../utils/cardSenderFormat';
import {financialSetupForDate} from '../utils/datedFinancialSetup';
import { dayLoopConfig } from '../utils/dualLoops';
import { businessDateIST } from '../utils/businessDate';
import { DualLoopSettings } from './DualLoopSettings';
import type { DualLoopConfig } from '../utils/dualLoops';
import React, { useState, useEffect } from 'react';
import {
  Target,
  DollarSign,
  TrendingUp,
  ShieldCheck,
  Power,
  Save,
  MessageSquareText,
  CopyCheck,
  Camera,
  Eraser,
} from 'lucide-react';
import { UserProfile, ProfileConfig, GlobalStats, GameType } from '../types';

interface AnkJodiPanelSetupProps {
  onToggleArchiveRecovery?: (enabled: boolean) => void;
  archiveRecoverySaving?: boolean;
  profile: UserProfile;
  onApplyYesterdayLoops?: (config: DualLoopConfig) => string | undefined;
  onSaveDualLoops?: (config: DualLoopConfig, archive: boolean) => string | undefined | Promise<string | undefined>;
  onToggleCustomLoops?: (enabled:boolean) => string | undefined | Promise<string | undefined>;
  canEditLoops?: boolean;
  showAdminScheduleControls: boolean;
  currentDate: string;
  globalStats: GlobalStats;
  onUpdateConfig: (newConfig: ProfileConfig) => void;
  onApplyProtocolTargetsToToday?: (type: 'all' | 'ank' | 'jodi' | 'pannel') => void;
  cardSenderSaving?:boolean;
  pendingCardSenderFormat?:{platform:'whatsapp'|'telegram';format:'text'|'png'};
  onChangeCardSenderFormat?: (format:'text'|'png',platform:'whatsapp'|'telegram')=>void;
  detailedMessage: boolean;
  onToggleDetailedMessage: (enabled: boolean) => void;
  onShowToast: (title: string, body: string, type: 'info' | 'success' | 'danger') => void;
  copyAdminEnabled?: boolean;
  onToggleCopyAdmin?: (enabled: boolean) => void;
  onClearAdminCopy?: () => void;
  onTakeAdminSnapshot?: () => void;
  adminSnapshotBusy?: boolean;
  adminSnapshotProgress?: string;
}

export const AnkJodiPanelSetup: React.FC<AnkJodiPanelSetupProps> = ({
  profile,
  onToggleArchiveRecovery,
  archiveRecoverySaving,
  currentDate,
  onSaveDualLoops,
  onToggleCustomLoops,
  onApplyYesterdayLoops,
  canEditLoops = true,
  showAdminScheduleControls,
  globalStats,
  onUpdateConfig,
  onShowToast,
  cardSenderSaving,
  pendingCardSenderFormat,
  onChangeCardSenderFormat,
  detailedMessage,
  onToggleDetailedMessage,
  copyAdminEnabled,
  onToggleCopyAdmin,
  onClearAdminCopy,
  onTakeAdminSnapshot,
  adminSnapshotBusy = false,
  adminSnapshotProgress = '',
}) => {
  // UserProfile guarantees a normalized ProfileConfig; keep the concrete type
  // instead of falling back to `{}`, which makes every config property unsafe.
  const config = financialSetupForDate(profile,currentDate);
  const loopsActive=Boolean(dayLoopConfig(profile,currentDate));

  // Form state from existing config
  const [capital, setCapital] = useState<number>(config.capital ?? 5000);
  const [dayTarget, setDayTarget] = useState<number>(config.dayTarget ?? 2000);
  const [scheduleTypeEnabled, setScheduleTypeEnabled] = useState<Record<GameType, boolean>>({
    ank: (profile.config?.scheduleTypeEnabled ?? config.scheduleTypeEnabled)?.ank !== false,
    jodi: (profile.config?.scheduleTypeEnabled ?? config.scheduleTypeEnabled)?.jodi !== false,
    pannel: (profile.config?.scheduleTypeEnabled ?? config.scheduleTypeEnabled)?.pannel !== false,
  });

  useEffect(() => {
    const src = profile.config?.scheduleTypeEnabled ?? config.scheduleTypeEnabled;
    if (!src) return;
    setScheduleTypeEnabled({
      ank: src.ank !== false,
      jodi: src.jodi !== false,
      pannel: src.pannel !== false,
    });
  }, [
    profile.config?.scheduleTypeEnabled?.ank,
    profile.config?.scheduleTypeEnabled?.jodi,
    profile.config?.scheduleTypeEnabled?.pannel,
    config.scheduleTypeEnabled?.ank,
    config.scheduleTypeEnabled?.jodi,
    config.scheduleTypeEnabled?.pannel,
  ]);

  // Targets
  const [ankTarget, setAnkTarget] = useState<number>(config.ank?.tgt ?? 200);
  const [jodiTarget, setJodiTarget] = useState<number>(config.jodi?.tgt ?? 500);
  const [pannelTarget, setPannelTarget] = useState<number>(config.pannel?.tgt ?? 800);

  // Live total P/L calculation for HUD
  const totalPL = (globalStats.ank?.pl || 0) + (globalStats.jodi?.pl || 0) + (globalStats.pannel?.pl || 0);

  const handleSaveAll = (overrides: Partial<ProfileConfig> = {}) => {
    if(currentDate>businessDateIST()){onShowToast('Choose a date','Select today or a past date to save financial settings.','info');return;}
    const updatedConfig: ProfileConfig = {
      ...config,
      capital:loopsActive?config.capital:capital,
      dayTarget:loopsActive?config.dayTarget:dayTarget,
      ...(showAdminScheduleControls ? { scheduleTypeEnabled } : {}),
      ank: { ...config.ank, tgt: loopsActive?config.ank.tgt:ankTarget },
      jodi: { ...config.jodi, tgt: loopsActive?config.jodi.tgt:jodiTarget },
      pannel: { ...config.pannel, tgt: loopsActive?config.pannel.tgt:pannelTarget },
      ...overrides,
    };

    onUpdateConfig(updatedConfig);
    onShowToast('💾 Setup Saved', `${currentDate} · Targets and capital saved for this date`, 'success');
  };

  return (
    <div className="setup-page p-3 space-y-3 max-w-2xl mx-auto pb-10">
      {currentDate<businessDateIST()&&onToggleArchiveRecovery&&<div className="bg-[#1C2733] border border-[#2AABEE]/40 rounded-2xl p-4">
        <label className="flex items-center justify-between gap-3 text-xs font-bold text-white"><span>3 FAIL RESET · THIS TEST DATE · {currentDate}</span>
          <input type="checkbox" role="switch" aria-label="Historical date 3 fail recovery reset" checked={profile.dayRecords[currentDate]?.backtestRecoveryPolicy?.resetAfterThreeFails===true} disabled={!canEditLoops||archiveRecoverySaving} onChange={e=>onToggleArchiveRecovery(e.target.checked)}/>
        </label>
        <details className="setup-help"><summary>How it works</summary><p className="mt-2 text-[10px] text-[#8DC8FF]">This profile and selected past date only. Live reset does not apply here. Third FAIL closes this track’s recovery; the next editable card starts at its target-only rate for its selected digit count. Settled stakes, wallet losses and other dates stay unchanged. To rerun settled cards, start a fresh trial in Backtest Lab.</p></details>
      </div>}
      {onSaveDualLoops && <DualLoopSettings profile={profile} date={currentDate} canEdit={canEditLoops} onSave={onSaveDualLoops} onToggle={onToggleCustomLoops} onApplyYesterday={onApplyYesterdayLoops}/>}

      {/* VIP-only source projection control; Admin setup remains unchanged. */}
      {typeof copyAdminEnabled === 'boolean' && (
        <div className="bg-[#1C2733] border border-[#7B8FFF]/30 rounded-2xl p-4 shadow-lg space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-[#7B8FFF]/15 text-[#8EA1FF] flex items-center justify-center shrink-0"><CopyCheck className="w-4 h-4" /></div>
              <div>
                <span className="text-xs font-black text-white uppercase tracking-wider">Copy Admin</span>
                <p className="text-[9px] text-[#7A9CB8] mt-0.5">ON: fresh Admin copy; old stake/result reversed. VIP rate independent.</p>
              </div>
            </div>
            <label className="switch shrink-0">
              <input type="checkbox" checked={copyAdminEnabled} disabled={adminSnapshotBusy} onChange={(event) => onToggleCopyAdmin?.(event.target.checked)} />
              <span className="slider round"></span>
            </label>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button type="button" onClick={() => onTakeAdminSnapshot?.()} disabled={adminSnapshotBusy || !onTakeAdminSnapshot} aria-busy={adminSnapshotBusy}
              title="One-time fresh Admin snapshot for this VIP and selected date. Only eligible unsent cards are copied; settled, sent and OFF cards stay untouched."
              className="h-10 rounded-lg border border-[#7B8FFF]/50 bg-[#313665] text-[#E1E6FF] text-[10px] font-black flex items-center justify-center gap-1.5 active:scale-95 disabled:opacity-50">
              <Camera className={`w-4 h-4 ${adminSnapshotProgress ? 'motion-safe:animate-pulse' : ''}`} /> {adminSnapshotBusy ? 'PLEASE WAIT…' : 'TAKE SNAPSHOT'}
            </button>
            <button type="button" onClick={() => onClearAdminCopy?.()} disabled={adminSnapshotBusy} className="h-10 rounded-lg border border-[#FF5D5D]/25 bg-[#FF5D5D]/10 text-[#FF8A8A] text-[9px] font-black flex items-center justify-center gap-1.5 active:scale-95 disabled:opacity-50">
              <Eraser className="w-3.5 h-3.5" /> CLEAR ADMIN COPY
            </button>
          </div>
          {adminSnapshotProgress && <p role="status" aria-live="polite" className="rounded-lg border border-sky-400/20 bg-sky-400/10 px-3 py-2 text-[10px] text-sky-200">{adminSnapshotProgress}</p>}
          <p className="text-[9px] text-[#7A9CB8] leading-relaxed">Snapshot: selected date par ek baar fresh Admin digits/trick; VIP ka rate independent. Copy Admin OFF ho tab bhi future auto-copy ON nahi hoga. Settled, sent aur OFF cards untouched. Rate edit save ho raha ho to woh card skip hoga.</p>
        </div>
      )}

      <div className="bg-[#1C2733] border border-[#2AABEE]/30 rounded-2xl p-3">
        <p className="text-xs font-black text-white">Card Sender · WhatsApp / Telegram</p>
        {(['whatsapp','telegram'] as const).map(platform=>{
          const selected=pendingCardSenderFormat?.platform===platform?pendingCardSenderFormat.format:profileCardSenderFormats(profile.config)[platform];
          return <div key={platform} className="flex items-center gap-2 mt-2" role="group" aria-label={`${platform==='whatsapp'?'WhatsApp':'Telegram'} card sender format`}>
            <span className="text-xs text-[#b7cddd] w-20 shrink-0">{platform==='whatsapp'?'WhatsApp':'Telegram'}</span>
            {(['text','png'] as const).map(format=><button key={format} type="button" aria-pressed={selected===format} disabled={cardSenderSaving||!onChangeCardSenderFormat||!canEditLoops} onClick={()=>onChangeCardSenderFormat?.(format,platform)} className={`flex-1 rounded-lg py-2 text-xs font-black ${selected===format?'bg-[#2AABEE] text-white':'bg-[#101b27] text-[#9db8cd]'}`}>{format==='text'?'TXT':'PNG'}</button>)}
          </div>;
        })}
        <p className="text-[10px] text-[#7A9CB8] mt-2">Scheduled / auto cards · {cardSenderSaving?'Saving…':'Saved per profile'} · Result replies stay text</p>
      </div>

      {/* GLOBAL WHATSAPP PRESENTATION ONLY — calculation/queue stays unchanged */}
      <div className="bg-[#1C2733] border border-[#2AABEE]/30 rounded-2xl p-4 shadow-lg">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-[#2AABEE]/15 text-[#2AABEE] flex items-center justify-center shrink-0">
              <MessageSquareText className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-black text-white uppercase tracking-wider">WhatsApp / Telegram Message Format</span>
              <p className="text-[10px] text-[#7A9CB8] mt-0.5">
                ON = Rate/Total premium detail · OFF = Market, Digits aur simple PASS/FAIL
              </p>
            </div>
          </div>
          <div className="shrink-0 text-center">
            <div className={`text-[8px] font-black uppercase mb-1 ${detailedMessage ? 'text-[#00C26F]' : 'text-[#FAC748]'}`}>
              {detailedMessage ? 'Detailed ON' : 'Simple OFF'}
            </div>
            <label className="switch">
              <input
                type="checkbox"
                checked={detailedMessage}
                onChange={(e) => onToggleDetailedMessage(e.target.checked)}
              />
              <span className="slider round"></span>
            </label>
          </div>
        </div>
      </div>

      {/* 2. WHATSAPP AUTO-SCHEDULE TYPE CONTROLS */}
      {showAdminScheduleControls && <div className="bg-[#1C2733] border border-[rgba(42,171,238,0.18)] rounded-2xl p-4 space-y-3 shadow-lg">
        <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.07)] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#2AABEE]/15 text-[#2AABEE] flex items-center justify-center"><Power className="w-4 h-4" /></div>
            <div>
              <span className="text-xs font-black text-white uppercase tracking-wider">2. WhatsApp / Telegram Auto Schedule</span>
              <p className="text-[10px] text-[#7A9CB8]">ANK, JODI and PANEL broadcast independently. OFF means no schedule or result follow-up.</p>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {([
            ['ank', 'ANK'],
            ['jodi', 'JODI'],
            ['pannel', 'PANEL'],
          ] as Array<[GameType, string]>).map(([type, label]) => {
            const enabled = scheduleTypeEnabled[type];
            return (
              <div key={type} className="bg-[#17212B] rounded-xl border border-[rgba(255,255,255,0.07)] p-2.5 flex items-center justify-between gap-2">
                <div>
                  <div className="text-[10px] font-black text-white">{label}</div>
                  <div className={`text-[8px] font-bold uppercase ${enabled ? 'text-[#00C26F]' : 'text-[#FF5D5D]'}`}>{enabled ? 'Broadcast ON' : 'Broadcast OFF'}</div>
                </div>
                <label className="switch shrink-0">
                  <input type="checkbox" checked={enabled} onChange={() => {
                    const nextEnabled = !enabled;
                    const next = { ...scheduleTypeEnabled, [type]: nextEnabled };
                    setScheduleTypeEnabled(next);
                    // Persist atomically to backend policy endpoint immediately AND update profile config
                    fetch('/api/app/profile_schedule_policy', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        profileId: profile.id || 'admin1',
                        cardType: type,
                        enabled: nextEnabled,
                      }),
                    }).catch(() => {});
                    handleSaveAll({
                      scheduleTypeEnabled: next,
                      schedulePolicyUpdatedAt: Date.now(),
                    } as any);
                  }} />
                  <span className="slider round"></span>
                </label>
              </div>
            );
          })}
        </div>
        <div className="text-[9px] text-[#7A9CB8] bg-[#17212B] rounded-lg px-2.5 py-2">Example: JODI ON + ANK OFF + PANEL OFF = only JODI cards can be scheduled/broadcast.</div>
      </div>}

      {!loopsActive&&<>
      {/* 2. PROTOCOL CARD TARGETS SECTION */}
      <div className="bg-[#1C2733] border border-[rgba(255,255,255,0.08)] rounded-2xl p-4 space-y-4 shadow-lg">
        <div className="flex items-center gap-2.5 border-b border-[rgba(255,255,255,0.07)] pb-3">
          <div className="w-8 h-8 rounded-lg bg-[#FAC748]/20 text-[#FAC748] flex items-center justify-center">
            <Target className="w-4 h-4" />
          </div>
          <div>
            <span className="text-xs font-black text-white uppercase tracking-wider">
              2. Protocol Card Targets
            </span>
            <p className="text-[10px] text-[#7A9CB8]">
              Target profit goal per card for Ank, Jodi and Panel
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {/* Ank Target */}
          <div className="flex justify-between items-center bg-[#17212B] p-3 rounded-xl border border-[#2AABEE]/30">
            <div>
              <p className="text-xs font-black uppercase text-[#2AABEE]">ANK Target Profit (x9.5)</p>
              <p className="text-[10px] text-[#7A9CB8]">Single Digits (0-9)</p>
            </div>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-xs text-[#7A9CB8] font-bold">₹</span>
              <input
                type="number"
                value={ankTarget}
                onChange={(e) => setAnkTarget(Number(e.target.value) || 0)}
                className="w-28 bg-[#2B3A4D] text-white font-mono font-bold text-xs rounded-xl pl-7 pr-3 py-2 outline-none focus:border-[#2AABEE]"
                placeholder="200"
              />
            </div>
          </div>

          {/* Jodi Target */}
          <div className="flex justify-between items-center bg-[#17212B] p-3 rounded-xl border border-[#B85CFF]/30">
            <div>
              <p className="text-xs font-black uppercase text-[#B85CFF]">JODI Target Profit (x95)</p>
              <p className="text-[10px] text-[#7A9CB8]">Jodi Pairs (00-99)</p>
            </div>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-xs text-[#7A9CB8] font-bold">₹</span>
              <input
                type="number"
                value={jodiTarget}
                onChange={(e) => setJodiTarget(Number(e.target.value) || 0)}
                className="w-28 bg-[#2B3A4D] text-white font-mono font-bold text-xs rounded-xl pl-7 pr-3 py-2 outline-none focus:border-[#B85CFF]"
                placeholder="500"
              />
            </div>
          </div>

          {/* Panel Target */}
          <div className="flex justify-between items-center bg-[#17212B] p-3 rounded-xl border border-[#FAC748]/30">
            <div>
              <p className="text-xs font-black uppercase text-[#FAC748]">PANEL Target Profit (x150)</p>
              <p className="text-[10px] text-[#7A9CB8]">Three-Digit Panels</p>
            </div>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-xs text-[#7A9CB8] font-bold">₹</span>
              <input
                type="number"
                value={pannelTarget}
                onChange={(e) => setPannelTarget(Number(e.target.value) || 0)}
                className="w-28 bg-[#2B3A4D] text-white font-mono font-bold text-xs rounded-xl pl-7 pr-3 py-2 outline-none focus:border-[#FAC748]"
                placeholder="800"
              />
            </div>
          </div>
        </div>
      </div>

      {/* 3. CAPITAL & PROFIT GOALS SECTION */}
      <div className="bg-[#1C2733] border border-[rgba(255,255,255,0.08)] rounded-2xl p-4 space-y-4 shadow-lg">
        <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.07)] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#00C26F]/20 text-[#00C26F] flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-black text-white uppercase tracking-wider">
                3. Capital & Profit Goals
              </span>
              <p className="text-[10px] text-[#7A9CB8]">
                Set total capital bankroll and daily target profit goal
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="bg-[#17212B] p-3 rounded-xl border border-[rgba(255,255,255,0.08)] space-y-1">
            <label className="text-[10px] text-[#7A9CB8] font-bold uppercase flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-[#2AABEE]" /> Total Wallet Capital
            </label>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-xs text-[#7A9CB8] font-bold">₹</span>
              <input
                type="number"
                value={capital}
                onChange={(e) => setCapital(Number(e.target.value) || 0)}
                placeholder="5000"
                className="w-full bg-[#2B3A4D] text-white text-xs border border-[rgba(255,255,255,0.08)] rounded-xl pl-7 pr-3 py-2 outline-none font-mono font-bold focus:border-[#2AABEE]"
              />
            </div>
          </div>

          <div className="bg-[#17212B] p-3 rounded-xl border border-[rgba(255,255,255,0.08)] space-y-1">
            <label className="text-[10px] text-[#00C26F] font-bold uppercase flex items-center gap-1">
              <TrendingUp className="w-3 h-3 text-[#00C26F]" /> Daily Profit Target Goal
            </label>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-xs text-[#00C26F] font-bold">₹</span>
              <input
                type="number"
                value={dayTarget}
                onChange={(e) => setDayTarget(Number(e.target.value) || 0)}
                placeholder="2000"
                className="w-full bg-[#2B3A4D] text-white text-xs border border-[rgba(255,255,255,0.08)] rounded-xl pl-7 pr-3 py-2 outline-none font-mono font-bold focus:border-[#00C26F]"
              />
            </div>
          </div>
        </div>

        {/* Live Net P/L HUD */}
        <div className="bg-[#17212B] p-3 rounded-xl border border-[rgba(255,255,255,0.08)] flex items-center justify-between">
          <span className="text-xs text-[#7A9CB8] font-bold uppercase">Current Net P/L:</span>
          <span className={`text-sm font-black font-mono ${totalPL >= 0 ? 'text-[#00C26F]' : 'text-[#FF4D4D]'}`}>
            ₹{totalPL.toLocaleString()} / ₹{dayTarget.toLocaleString()}
          </span>
        </div>
      </div>

      <button
        onClick={() => handleSaveAll()}
        className="w-full bg-[#00C26F] hover:bg-[#00a860] text-white py-3.5 rounded-2xl font-black text-xs uppercase tracking-wide flex items-center justify-center gap-2 shadow-lg active:scale-98 transition-all"
      >
        <Save className="w-4 h-4" /> Save Setup Settings
      </button>
      </>}
    </div>
  );
};
