import React, { useState } from 'react';
import { GameType, UserProfile } from '../types';
import { getWeekStats } from '../utils/calculator';
import { getMonthStats, getCustomRangeStats } from '../utils/monthlyAudit';
import { calculateCapitalWallet } from '../utils/capitalWallet';
import { businessDateIST } from '../utils/businessDate';
import { Share2, Calendar, ShieldCheck, Search, ArrowUpRight, ArrowDownRight, Wallet, ChevronDown } from 'lucide-react';

interface WeeklyAuditProps {
  profile: UserProfile;
  currentDate: string;
  isMaster: boolean;
  onSendReport: (msg: string) => void;
  onPreviewDailyImage?: (game:GameType)=>void;
  onPreviewAuditImage?: (game:GameType, period:'day'|'week'|'month'|'custom')=>void;
  onOpenActivityReplay?: () => void;
}

const money = (value: number) => `₹${value.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
const signed = (value: number) => `${value < 0 ? '-' : '+'}${money(Math.abs(value))}`;
const labelDate = (value: string) => new Date(`${value}T00:00:00Z`).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', timeZone: 'UTC' });
const gameLabel = (type: GameType) => type === 'pannel' ? 'Panel' : type === 'jodi' ? 'Jodi' : 'Ank';
const dictName = (type: GameType) => type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';

export const WeeklyAudit: React.FC<WeeklyAuditProps> = ({ profile, currentDate, isMaster, onSendReport, onPreviewDailyImage, onPreviewAuditImage, onOpenActivityReplay }) => {
  const [weeklyTab, setWeeklyTab] = useState<GameType>('ank');
  const [period, setPeriod] = useState<'day' | 'week' | 'month' | 'custom'>('week');
  const [customStartDate, setCustomStartDate] = useState(() => {
    const d = new Date(`${currentDate}T00:00:00Z`);
    d.setUTCDate(d.getUTCDate() - 6);
    return d.toISOString().slice(0, 10);
  });
  const [customEndDate, setCustomEndDate] = useState(currentDate);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'profit' | 'loss'>('all');
  const scoped = period === 'day' ? { ...profile, dayRecords: { [currentDate]: profile.dayRecords?.[currentDate] || {} } } : profile;
  const weekly = getWeekStats(scoped, currentDate);
  const monthly = period === 'month' ? getMonthStats(profile, currentDate) : null;
  const custom = period === 'custom' ? getCustomRangeStats(profile, customStartDate, customEndDate) : null;
  const { monday } = weekly;
  const stats = period === 'custom' ? custom!.stats : (monthly?.stats || weekly.stats);
  const totals = period === 'custom' ? custom!.totals : (monthly?.totals || weekly.totals);
  const start = period === 'day' ? currentDate : period === 'month' ? monthly!.monthStart.toISOString().slice(0, 10) : period === 'custom' ? customStartDate : monday.toISOString().slice(0, 10);
  const end = period === 'custom' ? customEndDate : currentDate;
  const dateStr = period === 'day' ? labelDate(currentDate) : `${labelDate(start)} – ${labelDate(end)}`;
  const entries = Object.entries(stats[weeklyTab]).filter(([, value]) => value.rounds > 0);
  const total = totals[weeklyTab];
  const net = total.win - total.invest;
  const pass = entries.reduce((sum, [, value]) => sum + value.pass, 0);
  const fail = entries.reduce((sum, [, value]) => sum + value.fail, 0);
  const rounds = pass + fail;
  const passRate = rounds ? Math.round(pass / rounds * 100) : 0;
  const visible = entries.filter(([name, value]) => name.toLowerCase().includes(search.trim().toLowerCase()) &&
    (filter === 'all' || (filter === 'profit' ? value.win > value.invest : value.win < value.invest)))
    .sort(([a], [b]) => a.localeCompare(b));
  const dayCards = profile.dayRecords?.[currentDate]?.[dictName(weeklyTab)] || {};
  const wallet = calculateCapitalWallet(weeklyTab, dayCards, currentDate !== businessDateIST());
  const days = Array.from({
    length: period === 'custom'
      ? Math.min(31, Math.max(1, Math.round((new Date(`${end}T00:00:00Z`).getTime() - new Date(`${start}T00:00:00Z`).getTime()) / 86400000) + 1))
      : period === 'month'
        ? Number(currentDate.slice(8, 10))
        : 7
  }, (_, i) => {
    const day = period === 'custom'
      ? new Date(`${start}T00:00:00Z`)
      : period === 'month'
        ? new Date(`${currentDate.slice(0, 7)}-01T00:00:00Z`)
        : new Date(monday);
    day.setUTCDate(day.getUTCDate() + i);
    const date = day.toISOString().slice(0, 10);
    const dayProfile = { ...profile, dayRecords: { [date]: profile.dayRecords?.[date] || {} } };
    const values = getWeekStats(dayProfile, date).totals[weeklyTab];
    return { date, net: values.win - values.invest, active: values.invest > 0 };
  }).filter(day => day.date <= end);
  const chartMax = Math.max(1, ...days.map(day => Math.abs(day.net)));
  const accent = weeklyTab === 'ank' ? '#2AABEE' : weeklyTab === 'jodi' ? '#B85CFF' : '#FAC748';

  const handleShare = () => {
    const periodLabel = period === 'day' ? 'DAILY' : period === 'week' ? 'WEEKLY' : period === 'month' ? 'MONTHLY' : 'CUSTOM';
    let msg = `📊 *TITAN NOVA · ${periodLabel} AUDIT*\n👤 ${profile.name}\n🎯 ${gameLabel(weeklyTab).toUpperCase()}\n📅 ${start}${start !== end ? ` to ${end}` : ''}\n━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `✅ Pass: ${pass} | ❌ Fail: ${fail}\n📊 Settled cards: ${rounds} | Pass rate: ${passRate}%\n💸 Total stakes: ${money(total.invest)}\n💰 Total payout: ${money(total.win)}\n🛡️ Max risk: ${money(total.maxLoss)}\n*Net P/L: ${signed(net)}*\n━━━━━━━━━━━━━━━━━━━━\n`;
    for (const [name, value] of [...entries].sort(([a], [b]) => a.localeCompare(b))) {
      msg += `*${name}*\n${value.pass} PASS · ${value.fail} FAIL\nStakes ${money(value.invest)} · Payout ${money(value.win)}\nNet ${signed(value.win - value.invest)}\n\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n*${currentDate} WALLET*\nOwn capital: ${money(wallet.invested)}\nWallet balance: ${money(wallet.balance)}\nResult pending: ${money(wallet.pending)}\n\nTotal stakes include reused winnings; own capital is shown separately. Pending cards do not count as settled profit.`;
    onSendReport(msg);
  };

  return <section aria-label="Financial audit" className="pb-5">
    <div role="tablist" aria-label="Audit game" className="flex bg-[#232E3C] p-2 gap-1.5 border-b border-white/10">
      {(['ank', 'jodi', 'pannel'] as GameType[]).map(type => <button key={type} role="tab" aria-selected={weeklyTab === type}
        onClick={() => setWeeklyTab(type)} className={`flex-1 rounded-lg py-2.5 text-[11px] font-bold transition-colors ${weeklyTab === type ? 'bg-[#2B3A4D] text-white' : 'text-[#8DA6C0]'}`}
        style={weeklyTab === type ? { boxShadow: `inset 0 -2px ${accent}` } : undefined}>{gameLabel(type)} <span className="text-[9px] opacity-60">×{type === 'ank' ? '9.5' : type === 'jodi' ? '95' : '150'}</span></button>)}
    </div>
    <div className="p-3 space-y-3">
      <div className="flex items-center justify-between gap-2">
        <div><h2 className="text-sm font-extrabold text-white">Financial audit</h2><p className="text-[10px] text-[#8DA6C0] flex items-center gap-1 mt-1"><Calendar className="h-3 w-3" />{dateStr} · {gameLabel(weeklyTab)}</p></div>
        <div className="flex rounded-lg bg-[#232E3C] p-1 shrink-0" role="group" aria-label="Audit period">
          {(['day', 'week', 'month', 'custom'] as const).map(value => (
            <button
              key={value}
              aria-pressed={period === value}
              onClick={() => setPeriod(value)}
              className={`px-2 py-1.5 rounded-md text-[10px] font-bold transition-all ${period === value ? 'bg-[#34465D] text-white' : 'text-[#8DA6C0]'}`}
            >
              {value === 'day' ? 'Daily' : value === 'week' ? 'Weekly' : value === 'month' ? 'Monthly' : 'Custom'}
            </button>
          ))}
        </div>
      </div>
      {period === 'custom' && (
        <div className="bg-[#232E3C] border border-white/10 rounded-xl p-3 flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#2AABEE]" />
            <span className="text-[11px] font-bold text-white">Custom Range:</span>
          </div>
          <div className="flex items-center gap-2 text-[11px]">
            <input
              type="date"
              aria-label="Custom audit start date"
              value={customStartDate}
              max={customEndDate}
              onChange={(e) => setCustomStartDate(e.target.value)}
              className="bg-[#18222D] border border-white/10 rounded-lg px-2.5 py-1 text-white text-xs font-mono focus:outline-none focus:border-[#2AABEE]"
            />
            <span className="text-[#8DA6C0] font-bold">to</span>
            <input
              type="date"
              aria-label="Custom audit end date"
              value={customEndDate}
              min={customStartDate}
              onChange={(e) => setCustomEndDate(e.target.value)}
              className="bg-[#18222D] border border-white/10 rounded-lg px-2.5 py-1 text-white text-xs font-mono focus:outline-none focus:border-[#2AABEE]"
            />
          </div>
        </div>
      )}
      <div className="rounded-2xl border border-white/10 p-4 bg-gradient-to-br from-[#28394B] to-[#17212B]">
        <div className="flex justify-between items-start gap-2"><div><p className="text-[10px] uppercase tracking-wider text-[#8DA6C0] font-bold">{period === 'day' ? 'Daily' : period === 'week' ? 'Weekly' : period === 'month' ? 'Monthly' : 'Custom'} net {net < 0 ? 'loss' : 'profit'}</p>
          <p className={`mt-1 text-3xl font-extrabold break-all ${net >= 0 ? 'text-[#00C26F]' : 'text-[#FF5D5D]'}`}>{signed(net)}</p></div>
          <div className={`p-2 rounded-xl ${net >= 0 ? 'bg-[#00C26F]/10 text-[#00C26F]' : 'bg-[#FF5D5D]/10 text-[#FF5D5D]'}`}>{net >= 0 ? <ArrowUpRight className="h-5 w-5" /> : <ArrowDownRight className="h-5 w-5" />}</div></div>
        <p className="text-[10px] text-[#8DA6C0] mt-2">Payout minus settled stakes · pending results excluded</p>
        <div className="grid grid-cols-2 gap-3 border-t border-white/10 pt-3 mt-3">
          <div><p className="text-[10px] text-[#8DA6C0]">Total stakes</p><p className="font-bold text-white text-sm break-all">{money(total.invest)}</p></div>
          <div><p className="text-[10px] text-[#8DA6C0]">Total payout</p><p className="font-bold text-white text-sm break-all">{money(total.win)}</p></div>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-2">
        {[{ label: 'Settled cards', value: rounds, color: 'text-white' }, { label: 'Pass', value: pass, color: 'text-[#00C26F]' }, { label: 'Fail', value: fail, color: 'text-[#FF5D5D]' }].map(item => <div key={item.label} className="bg-[#232E3C] border border-white/10 rounded-xl p-3"><p className="text-[9px] text-[#8DA6C0]">{item.label}</p><p className={`text-lg font-extrabold ${item.color}`}>{item.value}</p></div>)}
      </div>
      <div className="bg-[#232E3C] border border-white/10 rounded-xl p-3 space-y-2">
        <div className="flex justify-between text-[10px]"><span className="text-[#8DA6C0]">Pass rate</span><span className="font-bold text-white">{rounds ? `${passRate}%` : '—'}</span></div>
        <div role="progressbar" aria-label="Settled card pass rate" aria-valuemin={0} aria-valuemax={100} aria-valuenow={passRate} className="h-1.5 bg-[#34465D] overflow-hidden rounded-full"><div className="h-full bg-[#00C26F] rounded-full" style={{ width: `${passRate}%` }} /></div>
        <p className="text-[9px] text-[#8DA6C0]">Pass rate measures card results; profit depends on stakes and payouts.</p>
      </div>
      <details open className="bg-[#232E3C] border border-white/10 rounded-xl p-3">
        <summary className="text-[11px] text-white font-bold cursor-pointer"><Wallet className="inline h-3.5 w-3.5 mr-1.5" />{labelDate(currentDate)} wallet · {gameLabel(weeklyTab)}</summary>
        <div className="grid grid-cols-2 gap-3 mt-3">
          <div><p className="text-[9px] text-[#8DA6C0]">Own capital invested</p><p className="text-sm text-white font-bold break-all">{money(wallet.invested)}</p></div>
          <div><p className="text-[9px] text-[#8DA6C0]">Wallet balance</p><p className="text-sm text-white font-bold break-all">{money(wallet.balance)}</p></div>
          <div><p className="text-[9px] text-[#8DA6C0]">Result pending</p><p className="text-xs text-[#FAC748] font-bold break-all">{money(wallet.pending)}</p></div>
          <div><p className="text-[9px] text-[#8DA6C0]">Total played</p><p className="text-xs text-white font-bold break-all">{money(wallet.turnover)}</p></div>
        </div>
        <p className="text-[9px] leading-relaxed text-[#8DA6C0] mt-3">Total stakes count every settled play, including reused winnings. Own capital counts only the cash needed from you. Wallet figures apply to this date.</p>
      </details>
      {period !== 'day' && <div className="bg-[#232E3C] border border-white/10 rounded-xl p-3">
        <h3 className="text-[11px] text-white font-bold mb-3">Daily net P/L</h3>
        <div className="space-y-2 max-h-[360px] overflow-y-auto">{days.map(day => <div key={day.date} className="flex items-center gap-2 text-[10px]" aria-label={`${day.date}: ${day.active ? signed(day.net) : 'No settled cards'}`}>
          <span className="w-12 shrink-0 text-[#8DA6C0]">{labelDate(day.date)}</span><div className="flex-1 flex items-center h-2 rounded-full bg-[#34465D] overflow-hidden"><span className={`h-full rounded-full ${day.net < 0 ? 'bg-[#FF5D5D]' : 'bg-[#00C26F]'}`} style={{ width: `${Math.abs(day.net) / chartMax * 100}%` }} /></div>
          <span className={`w-20 shrink-0 text-right font-bold ${day.net < 0 ? 'text-[#FF5D5D]' : day.active ? 'text-[#00C26F]' : 'text-[#8DA6C0]'}`}>{day.active ? signed(day.net) : '—'}</span>
        </div>)}</div>
      </div>}
      <div className="flex items-center justify-between text-[10px] px-1"><span className="text-[#8DA6C0] flex items-center gap-1.5"><ShieldCheck className="h-3.5 w-3.5" />Max risk</span><span className="font-bold text-[#FAC748]">{money(total.maxLoss)}</span></div>
      <p className="text-[9px] text-[#8DA6C0] px-1">Largest settled recovery exposure in a day, including the stake that closes a loss chain.</p>
      <div className="pt-2 space-y-2">
        <h3 className="text-xs text-white font-bold">Market breakdown <span className="font-normal text-[#8DA6C0]">· {entries.length}</span></h3>
        <div className="flex gap-2"><label className="flex items-center gap-2 min-w-0 flex-1 px-3 py-2.5 bg-[#232E3C] border border-white/10 rounded-lg"><Search className="h-3.5 w-3.5 shrink-0 text-[#8DA6C0]" /><input aria-label="Search audit markets" value={search} onChange={event => setSearch(event.target.value)} placeholder="Search market" className="w-full min-w-0 bg-transparent text-white text-[11px] outline-none placeholder:text-[#8DA6C0]" /></label>
          <div className="relative"><select aria-label="Filter audit markets" value={filter} onChange={event => setFilter(event.target.value as typeof filter)} className="h-full appearance-none pl-3 pr-7 bg-[#232E3C] border border-white/10 rounded-lg text-[11px] text-white"><option value="all">All</option><option value="profit">Profit</option><option value="loss">Loss</option></select><ChevronDown className="pointer-events-none absolute right-2 top-3 h-3.5 w-3.5 text-[#8DA6C0]" /></div>
        </div>
        {!visible.length && <div className="text-center bg-[#232E3C] border border-dashed border-white/10 rounded-xl px-4 py-8"><p className="text-xs text-white font-bold">{entries.length ? 'No matching markets' : 'No settled cards yet'}</p><p className="text-[10px] text-[#8DA6C0] mt-1">{entries.length ? 'Try another search or filter.' : 'PASS and FAIL results will appear here after settlement.'}</p></div>}
        {visible.map(([name, value]) => {
          const pl = value.win - value.invest;
          return <details key={`${weeklyTab}_${name}`} className="bg-[#232E3C] border border-white/10 rounded-xl overflow-hidden" data-audit-market={name}>
            <summary className="p-3 cursor-pointer list-none flex justify-between items-center gap-2"><div className="min-w-0"><h4 className="text-[11px] text-white font-bold break-words">{name}</h4><p className="mt-1 text-[9px] text-[#8DA6C0]"><span className="text-[#00C26F]">{value.pass} pass</span> · <span className="text-[#FF5D5D]">{value.fail} fail</span> · {value.rounds} cards</p></div><div className="flex items-center gap-1.5 shrink-0"><span className={`text-xs font-bold ${pl < 0 ? 'text-[#FF5D5D]' : 'text-[#00C26F]'}`}>{signed(pl)}</span><ChevronDown className="h-3.5 w-3.5 text-[#8DA6C0]" /></div></summary>
            <div className="grid grid-cols-2 gap-3 border-t border-white/10 p-3 text-[10px]"><div className="text-[#8DA6C0]">Stakes<p className="text-white font-bold mt-1">{money(value.invest)}</p></div><div className="text-[#8DA6C0]">Payout<p className="text-white font-bold mt-1">{money(value.win)}</p></div></div>
          </details>;
        })}
      </div>
      {isMaster&&(onPreviewAuditImage||(period==='day'&&onPreviewDailyImage))&&<button type="button" onClick={()=>{if(onPreviewAuditImage)onPreviewAuditImage(weeklyTab,period as any);else if(period==='day')onPreviewDailyImage?.(weeklyTab);}} className="w-full rounded-xl py-3 text-[11px] font-bold bg-[#16475c] border border-[#53deee]/40 text-[#bceeff]">🖼️ {gameLabel(weeklyTab)} {period==='day'?'daily':period==='week'?'weekly':period==='month'?'monthly':'custom'} image · Preview / Share</button>}
      {onOpenActivityReplay&&<button type="button" onClick={onOpenActivityReplay} className="w-full rounded-xl py-3 text-[11px] font-bold bg-gradient-to-r from-[#1A293E] to-[#17354A] border border-cyan-400/40 text-cyan-200">🔥 Story / Status 15–30s Trailer &amp; 3D Video Studio (YT · Insta · FB · WA)</button>}
      {isMaster && <button onClick={handleShare} disabled={!rounds && !wallet.pending} className="w-full flex items-center justify-center gap-2 rounded-xl bg-[#2AABEE] text-white py-3.5 text-[11px] font-bold disabled:opacity-40 active:scale-[0.99]"><Share2 className="h-4 w-4" />Share {period === 'day' ? 'daily' : period === 'week' ? 'weekly' : period === 'month' ? 'monthly' : 'custom'} audit</button>}
    </div>
  </section>;
};
