import {useEffect,useRef} from 'react';
import {Download,Check,X,Smartphone,RefreshCw} from 'lucide-react';
import type {usePwaInstall} from '../utils/pwaInstall';
interface InstallModalProps{isOpen:boolean;onClose:()=>void;pwa:ReturnType<typeof usePwaInstall>}
export function InstallModal({isOpen,onClose,pwa}:InstallModalProps){
 const close=useRef<HTMLButtonElement>(null);
 useEffect(()=>{
  if(!isOpen)return;
  const previous=document.activeElement as HTMLElement|null,overflow=document.body.style.overflow;
  document.body.style.overflow='hidden';close.current?.focus();
  return()=>{document.body.style.overflow=overflow;previous?.focus();};
 },[isOpen]);
 if(!isOpen)return null;
 const steps=pwa.ios?['Open your personal app link in Safari.','Tap Share, then Add to Home Screen.','Keep Open as Web App enabled if offered, then tap Add.']:pwa.embedded?['Open this same link in Chrome or Edge, outside the in-app browser.','Tap the browser menu ⋮.','Choose Install app or Add to Home Screen.']:['Open this same app link in Chrome or Edge.','Tap Install Now when available, or open the browser menu.','Choose Install app or Add to Home Screen.'];
 return <div onClick={event=>{if(event.target===event.currentTarget)onClose();}} onKeyDown={event=>{
  if(event.key==='Escape'&&!pwa.installing)onClose();
  if(event.key==='Tab'){const buttons=[...event.currentTarget.querySelectorAll<HTMLButtonElement>('button:not(:disabled)')];if(event.shiftKey&&document.activeElement===buttons[0]){event.preventDefault();buttons.at(-1)?.focus();}else if(!event.shiftKey&&document.activeElement===buttons.at(-1)){event.preventDefault();buttons[0]?.focus();}}
 }} className="fixed inset-0 z-[9500] bg-black/75 backdrop-blur-sm flex items-end sm:items-center sm:justify-center">
  <section role="dialog" aria-modal="true" aria-labelledby="pwa-install-title" className="bg-[#1C2733] w-full sm:max-w-lg max-h-[90dvh] overflow-y-auto border-t-2 border-[#2AABEE] rounded-t-3xl sm:rounded-3xl p-5 pb-[calc(20px+env(safe-area-inset-bottom,0px))] shadow-2xl">
   <header className="flex items-center justify-between gap-3 mb-4"><div className="flex items-center gap-3"><div className="w-11 h-11 shrink-0 rounded-2xl bg-[#2AABEE]/15 text-[#64d5f5] flex items-center justify-center"><Download size={23}/></div><div><h2 id="pwa-install-title" className="text-white font-bold text-base">{pwa.installed?'Titan Nova installed':'Install Titan Nova'}</h2><p className="text-[#93afc7] text-xs mt-1">Your app link, on your Home Screen</p></div></div><button ref={close} type="button" aria-label="Close install panel" disabled={pwa.installing} onClick={onClose} className="p-2 text-slate-300"><X size={20}/></button></header>
   {!pwa.secure&&<p className="mb-3 p-3 rounded-xl bg-amber-500/10 text-amber-200 text-xs">Installation requires HTTPS. Open your HTTPS app link first.</p>}
   {pwa.installed?<div className="flex gap-2 p-3 mb-3 rounded-xl bg-emerald-500/10 text-emerald-200 text-sm"><Check size={19}/>Already installed. Open Titan Nova from your Home Screen.</div>:pwa.prompt&&pwa.secure&&!pwa.embedded&&<button type="button" onClick={()=>void pwa.install()} disabled={pwa.installing} className="w-full mb-4 py-3 rounded-xl bg-[#2AABEE] text-white text-sm font-bold flex justify-center items-center gap-2"><Smartphone size={18}/>{pwa.installing?'Installing…':'Install Now'}</button>}
   {!pwa.installed&&<ol className="space-y-2 mb-3">{steps.map((step,index)=><li key={step} className="flex gap-3 p-3 bg-[#27384b] rounded-xl text-xs text-[#d2e4f4] leading-relaxed"><span className="flex-none rounded-full w-6 h-6 flex items-center justify-center bg-[#2AABEE]/15 text-[#7bd5ff] font-bold">{index+1}</span><span>{step}</span></li>)}</ol>}
   {!pwa.installed&&<p className="text-[11px] text-[#95aec4] leading-relaxed mb-3">For VIP access, install from your own complete VIP link. Browser support varies; an existing installation may only appear on your Home Screen.</p>}
   {pwa.temporaryDomain&&<p className="p-3 mb-3 rounded-xl border border-sky-400/20 text-[#b3d8ee] text-xs leading-relaxed">This is a temporary Cloudflare address. If it changes, the installed app keeps the old address. Use a stable domain for a lasting installation.</p>}
   {pwa.error&&<p role="alert" className="text-red-300 text-xs mb-3 leading-relaxed">{pwa.error}</p>}
   {pwa.notice&&<p role="status" className="text-[#9dd9ed] text-xs mb-3 leading-relaxed">{pwa.notice}</p>}
   <div className="border-t border-white/10 pt-3 space-y-2">{pwa.workerReady&&<button type="button" disabled={pwa.checking||!pwa.secure} onClick={()=>void pwa.checkUpdate()} className="w-full rounded-xl py-2.5 text-[#b5d6ec] border border-white/10 text-xs flex items-center justify-center gap-2"><RefreshCw size={14}/>{pwa.checking?'Checking…':'Check for app update'}</button>}{pwa.updateAvailable&&<button type="button" onClick={pwa.activateUpdate} className="w-full rounded-xl py-2.5 bg-[#246c8a] text-white text-xs font-bold">Activate update · current page stays open</button>}<p className="text-[10px] leading-relaxed text-[#89a5bc]">Financial records require a server connection. Updates never force-reload your current page.</p></div>
  </section>
 </div>;
}
