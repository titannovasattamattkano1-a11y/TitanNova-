import {useEffect,useState,useRef} from 'react';
import {apiUrl} from '../utils/api';

/** A monitor only. Browser visibility, navigation and unmount never mutate the server job. */
export function BackgroundBacktestStatus({profileId,profileNames,onOpen}:{profileId:string;profileNames?:Record<string,string>;onOpen:(profileId:string)=>void}){
  const [job,setJob]=useState<any>(null),[connected,setConnected]=useState(false);
  const previousJob=useRef<any>(null);
  useEffect(()=>{
    let disposed=false,polling=false,controller:AbortController|undefined;
    const poll=async()=>{
      if(disposed||polling)return;polling=true;controller=new AbortController();
      const timeout=setTimeout(()=>controller?.abort(),10000);
      try{
        const response=await fetch(apiUrl('/api/app/backtest_range?summary=1'),{signal:controller.signal});
        const json=await response.json();if(!response.ok||json.status!=='success')throw new Error('Status unavailable');
        if(!disposed){
          const previous=previousJob.current,next=json.job;previousJob.current=next;
          if(previous&&(!next||previous.id===next.id)&&(previous.busy||['running','paused'].includes(previous.state))&&(!next||!next.busy&&!['running','paused'].includes(next.state)))
            window.dispatchEvent(new Event('titan-workspace-refresh'));
          setJob(next);setConnected(true);
        }
      }catch{if(!disposed)setConnected(false);}finally{clearTimeout(timeout);polling=false;}
    };
    void poll();const timer=setInterval(()=>{if(document.visibilityState!=='hidden')void poll();},3000);
    const reconnect=()=>{if(document.visibilityState!=='hidden')void poll();};
    window.addEventListener('titan-backtest-updated',reconnect);window.addEventListener('focus',reconnect);window.addEventListener('online',reconnect);window.addEventListener('pageshow',reconnect);document.addEventListener('visibilitychange',reconnect);
    return()=>{disposed=true;clearInterval(timer);controller?.abort();window.removeEventListener('titan-backtest-updated',reconnect);window.removeEventListener('focus',reconnect);window.removeEventListener('online',reconnect);window.removeEventListener('pageshow',reconnect);document.removeEventListener('visibilitychange',reconnect);};
  },[profileId]);
  if(!job||!['running','paused'].includes(job.state)&&!job.busy)return null;
  const mine=job.profileId===profileId;
  return <aside aria-label="Background backtest status" className="mx-3 my-2 rounded-xl border border-[#2AABEE]/30 bg-[#153342] p-3 text-[11px]">
    <div className="flex items-center justify-between gap-2"><p className="font-bold text-[#8DC8FF]">{connected?'●':'○'} BACKTEST · {connected?job.state.toUpperCase():'RECONNECTING'}</p><button type="button" onClick={()=>onOpen(job.profileId)} className="shrink-0 rounded-lg bg-[#147D91] px-3 py-2 font-bold text-white">VIEW BACKTEST</button></div>
    <p className="mt-1 text-[#C8D6E3]">{job.progress.checked}/{job.progress.eligible} cards · {mine?'Current profile':profileNames?.[job.profileId]||job.profileId} · {job.from} → {job.to}</p>
    {job.current&&<p className="mt-1 break-words text-[10px] text-[#8DC8FF]">Current: {job.current}</p>}
    <p className="mt-1 text-[10px] text-[#8DA6C0]">{connected?(job.state==='running'?'Running on server · browser can be closed':job.error||'Paused · open controls to resume'):'Connection lost · saved server run is unchanged'}</p>
  </aside>;
}
