import { apiUrl } from '../utils/api';
import React, { useState } from 'react';
import { GameType, UserProfile } from '../types';
import { parseRawTextToMarketData } from '../utils/aiParser';
import { Brain, Sparkles, Upload, FileText, CheckCircle2 } from 'lucide-react';

interface SmartAIScannerProps {
  onBatchApplyData: (targetType: GameType, textRaw: string, geminiData?: any[]) => void;
  profiles: Record<string, UserProfile>;
}

export const SmartAIScanner: React.FC<SmartAIScannerProps> = ({
  onBatchApplyData,
}) => {
  const [inputText, setInputText] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [detectedCount, setDetectedCount] = useState<number | null>(null);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGeminiScan = async (targetType: GameType) => {
    if (!inputText.trim() && !imagePreview) {
      alert('Please paste raw text or upload a screenshot image!');
      return;
    }

    setIsAiLoading(true);
    try {
      const res = await fetch(apiUrl('/api/smart-scan'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: inputText,
          image: imagePreview,
          gameType: targetType
        })
      });

      const json = await res.json();
      if (json.status === 'success' && Array.isArray(json.data) && json.data.length > 0) {
        setDetectedCount(json.data.length);
        onBatchApplyData(targetType, inputText, json.data);
      } else {
        // Fallback to local regex parser
        const localResults = parseRawTextToMarketData(inputText, targetType);
        setDetectedCount(localResults.length);
        onBatchApplyData(targetType, inputText);
      }
    } catch (err) {
      console.error('AI Scan Error, using local parser:', err);
      const localResults = parseRawTextToMarketData(inputText, targetType);
      setDetectedCount(localResults.length);
      onBatchApplyData(targetType, inputText);
    } finally {
      setIsAiLoading(false);
    }
  };

  return (
    <div className="px-3 py-4">
      <div className="native-card bg-[#232E3C] border border-[rgba(42,171,238,0.25)] rounded-2xl p-4 shadow-xl" style={{ background: 'rgba(42,171,238,0.04)' }}>
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-[rgba(42,171,238,0.15)] flex items-center justify-center text-[#2AABEE] text-lg shrink-0">
            <Brain className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-[14px] font-black text-white flex items-center gap-2">
              Global AI Scanner <Sparkles className="w-4 h-4 text-[#FAC748]" />
            </h3>
            <p className="text-[9px] text-[#7A9CB8] uppercase tracking-wider mt-0.5">
              Extract predictions & auto-fill all VIP ledgers
            </p>
          </div>
        </div>

        {/* Text Area Input */}
        <textarea
          rows={6}
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Paste raw text or chart notes here (e.g. KALYAN OPEN 1, 2, 3, 4 | MILAN NIGHT 12, 34)..."
          className="w-full bg-[#2B3A4D] border border-[rgba(255,255,255,0.1)] text-[#FAC748] font-bold p-3.5 rounded-xl outline-none text-[13px] placeholder-[#7A9CB8] transition-colors focus:border-[#2AABEE] mb-3"
        />

        {/* Image Screenshot Upload Optional */}
        <div className="mb-4">
          <label className="flex items-center justify-center gap-2 bg-[#2B3A4D] border border-dashed border-[rgba(255,255,255,0.15)] rounded-xl p-3 cursor-pointer hover:border-[#2AABEE] transition-colors">
            <Upload className="w-4 h-4 text-[#7A9CB8]" />
            <span className="text-[11px] font-bold text-[#7A9CB8]">
              {imagePreview ? 'Screenshot Attached ✓' : 'Upload Prediction Image / Screenshot'}
            </span>
            <input type="file" accept="image/*" onChange={handleImageSelect} className="hidden" />
          </label>
          {imagePreview && (
            <div className="mt-2 relative inline-block">
              <img src={imagePreview} alt="Scan preview" className="max-h-28 rounded-lg border border-[rgba(255,255,255,0.1)]" />
              <button
                onClick={() => setImagePreview(null)}
                className="absolute -top-2 -right-2 bg-[#FF5D5D] text-white w-5 h-5 rounded-full text-xs font-bold"
              >
                ×
              </button>
            </div>
          )}
        </div>

        {/* Detected Info Badge */}
        {detectedCount !== null && (
          <div className="mb-3 bg-[rgba(0,194,111,0.15)] border border-[rgba(0,194,111,0.3)] text-[#00C26F] p-2.5 rounded-xl text-xs font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" /> Auto-populated {detectedCount} market predictions!
          </div>
        )}

        {/* Extraction Action Buttons */}
        <div className="grid grid-cols-3 gap-2.5">
          <button
            onClick={() => handleGeminiScan('ank')}
            disabled={isAiLoading}
            className="bg-[rgba(42,171,238,0.12)] text-[#2AABEE] py-3 rounded-xl font-black text-[11px] uppercase active:scale-95 border border-[rgba(42,171,238,0.25)] flex items-center justify-center gap-1 shadow-sm"
          >
            {isAiLoading ? 'Scanning...' : 'Ank (Single)'}
          </button>
          <button
            onClick={() => handleGeminiScan('jodi')}
            disabled={isAiLoading}
            className="bg-[rgba(184,92,255,0.12)] text-[#B85CFF] py-3 rounded-xl font-black text-[11px] uppercase active:scale-95 border border-[rgba(184,92,255,0.25)] flex items-center justify-center gap-1 shadow-sm"
          >
            {isAiLoading ? 'Scanning...' : 'Jodi (Pair)'}
          </button>
          <button
            onClick={() => handleGeminiScan('pannel')}
            disabled={isAiLoading}
            className="bg-[rgba(250,199,72,0.12)] text-[#FAC748] py-3 rounded-xl font-black text-[11px] uppercase active:scale-95 border border-[rgba(250,199,72,0.25)] flex items-center justify-center gap-1 shadow-sm"
          >
            {isAiLoading ? 'Scanning...' : 'Pan (Pannel)'}
          </button>
        </div>

        {/* Instructions */}
        <div className="mt-4 pt-3 border-t border-[rgba(255,255,255,0.07)] text-[10px] text-[#7A9CB8] space-y-1">
          <p className="flex items-center gap-1 font-bold">
            <FileText className="w-3 h-3 text-[#2AABEE]" /> Smart Pattern Extractor Tip:
          </p>
          <p>You can paste raw WhatsApp messages or prediction text. The AI scanner detects market names, open/close slots, and numbers automatically.</p>
        </div>
      </div>
    </div>
  );
};
