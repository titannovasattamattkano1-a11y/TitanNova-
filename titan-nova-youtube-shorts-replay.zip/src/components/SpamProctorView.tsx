import { apiUrl } from '../utils/api';
import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Link,
  Zap,
  Image,
  AlertTriangle,
  UserX,
  Trash2,
  RefreshCw,
  CheckCircle,
  XCircle,
  Plus,
  Lock,
  MessageSquare,
  Activity,
  Play,
  Pause
} from 'lucide-react';

export interface SpamConfig {
  enabled: boolean;
  antiLink: boolean;
  antiFlood: boolean;
  antiMediaFlood: boolean;
  maxWarnings: number;
  messageLimit: number;
  timeFrameMs: number;
  groupProtectionMode: 'all' | 'selected_only';
  protectedGroups: string[];
  whitelistedGroups: string[];
  whitelistedUsers: string[];
}

export interface SpamIncident {
  id: string;
  timestamp: string;
  chatId: string;
  chatName: string;
  sender: string;
  senderPhone: string;
  reason: 'Link Detected' | 'Message Flood' | 'Media Burst';
  action: 'Warning Issued' | 'User Kicked' | 'Message Deleted';
  messageText: string;
  warningCount: number;
}

interface SpamProctorViewProps {
  visible?: boolean;
  onShowToast: (title: string, body: string, type?: 'info' | 'success' | 'danger') => void;
}

export const SpamProctorView: React.FC<SpamProctorViewProps> = ({ onShowToast, visible=true }) => {
  const [loading, setLoading] = useState(false);
  const [config, setConfig] = useState<SpamConfig>({
    enabled: true,
    antiLink: true,
    antiFlood: true,
    antiMediaFlood: true,
    maxWarnings: 1,
    messageLimit: 5,
    timeFrameMs: 5000,
    groupProtectionMode: 'selected_only',
    protectedGroups: [],
    whitelistedGroups: [],
    whitelistedUsers: [],
  });

  const [incidents, setIncidents] = useState<SpamIncident[]>([]);
  const [syncedGroups, setSyncedGroups] = useState<Array<{ jid: string; name: string }>>([]);
  const [activeWarningsCount, setActiveWarningsCount] = useState<number>(0);
  const [botPhone, setBotPhone] = useState<string>('');
  const [botStatus, setBotStatus] = useState<string>('offline');
  const [groupSearch, setGroupSearch] = useState<string>('');

  const [newWhitelistedUser, setNewWhitelistedUser] = useState('');
  const [testText, setTestText] = useState('Join my channel: https://t.me/example');
  const [testResult, setTestResult] = useState<{ isSpam: boolean; reason?: string } | null>(null);

  // Fetch Spam Config & Logs
  const fetchSpamData = async () => {
    try {
      setLoading(true);
      const [cfgRes, incRes, groupsRes] = await Promise.all([
        fetch(apiUrl('/api/spam/config')).catch(() => null),
        fetch(apiUrl('/api/spam/incidents')).catch(() => null),
        fetch(apiUrl('/api/bot/synced_chats')).catch(() => null)
      ]);

      if (cfgRes && cfgRes.ok) {
        const contentType = cfgRes.headers.get('content-type') || '';
        if (contentType.includes('application/json')) {
          const cfgData = await cfgRes.json();
          if (cfgData?.config) {
            setConfig(cfgData.config);
          }
          if (cfgData?.activeWarningsCount !== undefined) {
            setActiveWarningsCount(cfgData.activeWarningsCount);
          }
          if (cfgData?.botPhone) setBotPhone(cfgData.botPhone);
          if (cfgData?.botStatus) setBotStatus(cfgData.botStatus);
        }
      }

      if (incRes && incRes.ok) {
        const contentType = incRes.headers.get('content-type') || '';
        if (contentType.includes('application/json')) {
          const incData = await incRes.json();
          if (Array.isArray(incData?.incidents)) {
            setIncidents(incData.incidents);
          }
        }
      }

      if (groupsRes && groupsRes.ok) {
        const contentType = groupsRes.headers.get('content-type') || '';
        if (contentType.includes('application/json')) {
          const gData = await groupsRes.json();
          const groupsList = gData?.groups || gData?.chats?.groups;
          if (Array.isArray(groupsList)) {
            setSyncedGroups(groupsList);
          }
        }
      }
    } catch (e) {
      console.error('Error fetching spam proctor data:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!visible) return;
    fetchSpamData();
    const interval = setInterval(() => { if(document.visibilityState !== 'hidden') void fetchSpamData(); }, 10000);
    return () => clearInterval(interval);
  }, [visible]);

  // Save Spam Config
  const handleSaveConfig = async (updated: SpamConfig) => {
    setConfig(updated);
    try {
      const res = await fetch(apiUrl('/api/spam/config'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated),
      });
      const data = await res.json();
      if (data.status === 'success') {
        onShowToast('Spam Settings Saved', 'WhatsApp Proctor settings updated successfully!', 'success');
      }
    } catch (e) {
      onShowToast('Save Error', 'Could not update spam settings', 'danger');
    }
  };

  // Reset Warnings
  const handleResetWarnings = async () => {
    try {
      const res = await fetch(apiUrl('/api/spam/reset_warnings'), { method: 'POST' });
      const data = await res.json();
      if (data.status === 'success') {
        setActiveWarningsCount(0);
        onShowToast('Warnings Reset', 'All user warning counts cleared!', 'success');
      }
    } catch (e) {
      onShowToast('Error', 'Failed to reset warnings', 'danger');
    }
  };

  // Clear Incidents Log
  const handleClearLogs = async () => {
    try {
      const res = await fetch(apiUrl('/api/spam/clear_logs'), { method: 'POST' });
      const data = await res.json();
      if (data.status === 'success') {
        setIncidents([]);
        onShowToast('Logs Cleared', 'Spam incidents history wiped clean.', 'info');
      }
    } catch (e) {
      onShowToast('Error', 'Failed to clear logs', 'danger');
    }
  };

  // Add Whitelisted User
  const handleAddWhitelistedUser = () => {
    if (!newWhitelistedUser.trim()) return;
    const cleanPhone = newWhitelistedUser.replace(/\D/g, '');
    if (!cleanPhone) {
      onShowToast('Invalid Phone', 'Please enter a valid phone number', 'danger');
      return;
    }
    if (config.whitelistedUsers.includes(cleanPhone)) {
      onShowToast('Already Exists', 'User is already in whitelist', 'info');
      return;
    }
    const updated = {
      ...config,
      whitelistedUsers: [...config.whitelistedUsers, cleanPhone]
    };
    handleSaveConfig(updated);
    setNewWhitelistedUser('');
  };

  // Remove Whitelisted User
  const handleRemoveWhitelistedUser = (phone: string) => {
    const updated = {
      ...config,
      whitelistedUsers: config.whitelistedUsers.filter(p => p !== phone)
    };
    handleSaveConfig(updated);
  };

  // Toggle Whitelisted Group
  const handleToggleGroupWhitelist = (jid: string) => {
    const isExempt = config.whitelistedGroups.includes(jid);
    const updated = {
      ...config,
      whitelistedGroups: isExempt
        ? config.whitelistedGroups.filter(g => g !== jid)
        : [...config.whitelistedGroups, jid]
    };
    handleSaveConfig(updated);
  };

  // Toggle Protected Group (for Selected Groups Mode)
  const handleToggleProtectedGroup = (jid: string) => {
    const currentList = config.protectedGroups || [];
    const isProtected = currentList.includes(jid);
    const updated = {
      ...config,
      protectedGroups: isProtected
        ? currentList.filter(g => g !== jid)
        : [...currentList, jid]
    };
    handleSaveConfig(updated);
  };

  const handleSelectAllProtected = () => {
    const allJids = syncedGroups.map(g => g.jid);
    handleSaveConfig({ ...config, protectedGroups: allJids });
  };

  const handleClearAllProtected = () => {
    handleSaveConfig({ ...config, protectedGroups: [] });
  };

  // Local Test
  const handleTestDetector = () => {
    const hasLink = /(https?:\/\/[^\s]+)|(www\.[^\s]+)|(t\.me\/[^\s]+)|(wa\.me\/[^\s]+)/gi.test(testText);
    if (hasLink && config.antiLink) {
      setTestResult({ isSpam: true, reason: 'Link / URL Detected (Blocked by Anti-Link)' });
    } else {
      setTestResult({ isSpam: false, reason: 'Message Passed Proctor Filters Cleanly!' });
    }
  };

  const totalKicks = incidents.filter(i => i.action === 'User Kicked').length;
  const totalWarnings = incidents.filter(i => i.action === 'Warning Issued').length;

  return (
    <div className="p-3 sm:p-4 space-y-4 max-w-4xl mx-auto">
      {/* Bot Connection Info Card */}
      <div className="bg-[#17212B] border border-[#2AABEE]/30 rounded-2xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
        <div className="flex items-center gap-2.5">
          <div className={`w-3 h-3 rounded-full ${botStatus === 'online' ? 'bg-[#00C26F] animate-ping' : 'bg-[#FF5252]'}`} />
          <div>
            <span className="text-xs font-black text-white block">
              Same WhatsApp Session: {botPhone ? `+${botPhone}` : 'Connected Device'}
            </span>
            <span className="text-[10px] text-[#7A9CB8]">
              ⚡ Spam Proctor active on your paired WhatsApp — No separate bot login required!
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className={`text-[10px] font-black px-2.5 py-1 rounded-lg uppercase tracking-wider ${
            botStatus === 'online' ? 'bg-[#00C26F]/20 text-[#00C26F] border border-[#00C26F]/30' : 'bg-[#FF5252]/20 text-[#FF5252] border border-[#FF5252]/30'
          }`}>
            {botStatus === 'online' ? '🟢 BOT ONLINE' : '🔴 BOT OFFLINE'}
          </span>
        </div>
      </div>

      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#1F2C3A] via-[#1C2733] to-[#17212B] border border-[#2AABEE]/30 rounded-2xl p-4 shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#2AABEE]/5 rounded-full blur-2xl pointer-events-none" />
        <div className="flex items-center gap-3">
          <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 shadow-md ${
            config.enabled ? 'bg-[#00C26F]/15 border border-[#00C26F]/40 text-[#00C26F]' : 'bg-[#FF5252]/15 border border-[#FF5252]/40 text-[#FF5252]'
          }`}>
            {config.enabled ? <ShieldCheck className="w-6 h-6 animate-pulse" /> : <ShieldAlert className="w-6 h-6" />}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black text-white tracking-tight">
                WhatsApp Spam Proctor & Group Shield
              </h2>
              <span className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider ${
                config.enabled ? 'bg-[#00C26F]/20 text-[#00C26F] border border-[#00C26F]/30' : 'bg-[#FF5252]/20 text-[#FF5252] border border-[#FF5252]/30'
              }`}>
                {config.enabled ? 'ACTIVE PROCTOR' : 'PAUSED'}
              </span>
            </div>
            <p className="text-xs text-[#7A9CB8] mt-0.5">
              Auto-deletes spam links, message floods & kicks repeat spammers automatically in WhatsApp groups.
            </p>
          </div>
        </div>

        <button
          onClick={() => handleSaveConfig({ ...config, enabled: !config.enabled })}
          className={`w-full sm:w-auto px-4 py-2.5 rounded-xl font-black text-xs uppercase flex items-center justify-center gap-2 transition-all shadow-md active:scale-95 shrink-0 ${
            config.enabled
              ? 'bg-[#FF5252]/20 text-[#FF5252] border border-[#FF5252]/40 hover:bg-[#FF5252]/30'
              : 'bg-[#00C26F] text-white hover:bg-[#00A85F]'
          }`}
        >
          {config.enabled ? (
            <>
              <Pause className="w-4 h-4 fill-current" /> Pause Proctor
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-current" /> Enable Proctor
            </>
          )}
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div className="bg-[#1C2733] border border-[rgba(255,255,255,0.08)] rounded-xl p-3 flex flex-col justify-between">
          <span className="text-[10px] font-bold text-[#7A9CB8] uppercase tracking-wider flex items-center gap-1">
            <Activity className="w-3.5 h-3.5 text-[#2AABEE]" /> Active Status
          </span>
          <span className={`text-sm font-black mt-2 ${config.enabled ? 'text-[#00C26F]' : 'text-[#FF5252]'}`}>
            {config.enabled ? 'ONLINE & GUARDING' : 'DISABLED'}
          </span>
        </div>

        <div className="bg-[#1C2733] border border-[rgba(255,255,255,0.08)] rounded-xl p-3 flex flex-col justify-between">
          <span className="text-[10px] font-bold text-[#7A9CB8] uppercase tracking-wider flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5 text-[#FAC748]" /> Active Warnings
          </span>
          <span className="text-lg font-black text-white mt-1">
            {activeWarningsCount} <span className="text-[10px] text-[#7A9CB8] font-medium">tracked</span>
          </span>
        </div>

        <div className="bg-[#1C2733] border border-[rgba(255,255,255,0.08)] rounded-xl p-3 flex flex-col justify-between">
          <span className="text-[10px] font-bold text-[#7A9CB8] uppercase tracking-wider flex items-center gap-1">
            <ShieldAlert className="w-3.5 h-3.5 text-[#2AABEE]" /> Total Warnings
          </span>
          <span className="text-lg font-black text-[#2AABEE] mt-1">
            {totalWarnings}
          </span>
        </div>

        <div className="bg-[#1C2733] border border-[rgba(255,255,255,0.08)] rounded-xl p-3 flex flex-col justify-between">
          <span className="text-[10px] font-bold text-[#7A9CB8] uppercase tracking-wider flex items-center gap-1">
            <UserX className="w-3.5 h-3.5 text-[#FF5252]" /> Auto-Kicks
          </span>
          <span className="text-lg font-black text-[#FF5252] mt-1">
            {totalKicks}
          </span>
        </div>
      </div>

      {/* Rules & Detection Settings */}
      <div className="bg-[#1C2733] border border-[rgba(255,255,255,0.08)] rounded-2xl p-4 space-y-4">
        <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.07)] pb-2.5">
          <span className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#2AABEE]" /> Protection Rules & Limits
          </span>
          <button
            onClick={() => fetchSpamData()}
            className="text-[#7A9CB8] hover:text-white p-1 rounded-lg transition-colors"
            title="Refresh Data"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {/* Anti-Link */}
          <div className="bg-[#17212B] border border-[rgba(255,255,255,0.06)] rounded-xl p-3.5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#2AABEE]/10 border border-[#2AABEE]/20 flex items-center justify-center text-[#2AABEE]">
                <Link className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-white block">Anti-Link Filter</span>
                <span className="text-[10px] text-[#7A9CB8]">Deletes http/https/t.me/wa.me links</span>
              </div>
            </div>
            <input
              type="checkbox"
              checked={config.antiLink}
              onChange={(e) => handleSaveConfig({ ...config, antiLink: e.target.checked })}
              className="w-5 h-5 accent-[#2AABEE] cursor-pointer"
            />
          </div>

          {/* Anti-Flood */}
          <div className="bg-[#17212B] border border-[rgba(255,255,255,0.06)] rounded-xl p-3.5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#FAC748]/10 border border-[#FAC748]/20 flex items-center justify-center text-[#FAC748]">
                <Zap className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-white block">Anti-Flood Rate Limiter</span>
                <span className="text-[10px] text-[#7A9CB8]">Detects rapid continuous messages</span>
              </div>
            </div>
            <input
              type="checkbox"
              checked={config.antiFlood}
              onChange={(e) => handleSaveConfig({ ...config, antiFlood: e.target.checked })}
              className="w-5 h-5 accent-[#FAC748] cursor-pointer"
            />
          </div>

          {/* Anti-Media Burst */}
          <div className="bg-[#17212B] border border-[rgba(255,255,255,0.06)] rounded-xl p-3.5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#B85CFF]/10 border border-[#B85CFF]/20 flex items-center justify-center text-[#B85CFF]">
                <Image className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-white block">Anti-Media Burst</span>
                <span className="text-[10px] text-[#7A9CB8]">Blocks &gt;= 3 photos/videos in 5 sec</span>
              </div>
            </div>
            <input
              type="checkbox"
              checked={config.antiMediaFlood}
              onChange={(e) => handleSaveConfig({ ...config, antiMediaFlood: e.target.checked })}
              className="w-5 h-5 accent-[#B85CFF] cursor-pointer"
            />
          </div>

          {/* Warning Limit */}
          <div className="bg-[#17212B] border border-[rgba(255,255,255,0.06)] rounded-xl p-3.5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#FF5252]/10 border border-[#FF5252]/20 flex items-center justify-center text-[#FF5252]">
                <AlertTriangle className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-white block">Max Warnings Before Kick</span>
                <span className="text-[10px] text-[#7A9CB8]">1 = Warning 1st, Kick 2nd time</span>
              </div>
            </div>
            <select
              value={config.maxWarnings}
              onChange={(e) => handleSaveConfig({ ...config, maxWarnings: parseInt(e.target.value) || 1 })}
              className="bg-[#1C2733] text-white text-xs border border-[rgba(255,255,255,0.1)] rounded-lg px-2.5 py-1.5 font-bold outline-none focus:border-[#2AABEE]"
            >
              <option value={0}>0 (Instant Kick)</option>
              <option value={1}>1 Warning (Kick on 2nd)</option>
              <option value={2}>2 Warnings (Kick on 3rd)</option>
              <option value={3}>3 Warnings (Kick on 4th)</option>
            </select>
          </div>
        </div>

        {/* Rate limit Fine-Tuning */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <div>
            <label className="text-[10px] font-bold text-[#7A9CB8] uppercase tracking-wider block mb-1">
              Flood Message Threshold
            </label>
            <div className="flex items-center gap-2 bg-[#17212B] border border-[rgba(255,255,255,0.08)] rounded-xl px-3 py-2">
              <MessageSquare className="w-4 h-4 text-[#2AABEE]" />
              <input
                type="number"
                min={2}
                max={20}
                value={config.messageLimit}
                onChange={(e) => setConfig({ ...config, messageLimit: parseInt(e.target.value) || 5 })}
                onBlur={() => handleSaveConfig(config)}
                className="w-full bg-transparent text-white text-xs font-bold outline-none"
              />
              <span className="text-[10px] text-[#7A9CB8] shrink-0 font-medium">messages</span>
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold text-[#7A9CB8] uppercase tracking-wider block mb-1">
              Time Window Frame
            </label>
            <div className="flex items-center gap-2 bg-[#17212B] border border-[rgba(255,255,255,0.08)] rounded-xl px-3 py-2">
              <Zap className="w-4 h-4 text-[#FAC748]" />
              <input
                type="number"
                step={1000}
                min={1000}
                max={30000}
                value={config.timeFrameMs}
                onChange={(e) => setConfig({ ...config, timeFrameMs: parseInt(e.target.value) || 5000 })}
                onBlur={() => handleSaveConfig(config)}
                className="w-full bg-transparent text-white text-xs font-bold outline-none"
              />
              <span className="text-[10px] text-[#7A9CB8] shrink-0 font-medium">milliseconds</span>
            </div>
          </div>
        </div>
      </div>

      {/* Exemptions & Whitelist */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Whitelisted Users */}
        <div className="bg-[#1C2733] border border-[rgba(255,255,255,0.08)] rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-[#00C26F]" /> Whitelisted Phones / Admins
            </span>
            <span className="text-[10px] text-[#7A9CB8]">{config.whitelistedUsers.length} exempted</span>
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Enter phone e.g. 91XXXXXXXXXX"
              value={newWhitelistedUser}
              onChange={(e) => setNewWhitelistedUser(e.target.value)}
              className="flex-1 bg-[#17212B] text-white text-xs border border-[rgba(255,255,255,0.08)] rounded-xl px-3 py-2 outline-none focus:border-[#00C26F]"
            />
            <button
              onClick={handleAddWhitelistedUser}
              className="bg-[#00C26F] text-white px-3 py-2 rounded-xl text-xs font-black uppercase flex items-center gap-1 shrink-0 active:scale-95 transition-all"
            >
              <Plus className="w-3.5 h-3.5" /> Add
            </button>
          </div>

          <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1 no-scrollbar">
            {config.whitelistedUsers.length === 0 ? (
              <p className="text-[11px] text-[#7A9CB8] italic py-2 text-center">No users whitelisted. All group members subject to proctor rules.</p>
            ) : (
              config.whitelistedUsers.map((phone) => (
                <div key={phone} className="bg-[#17212B] border border-[rgba(255,255,255,0.05)] rounded-lg px-3 py-1.5 flex items-center justify-between text-xs">
                  <span className="font-mono text-white font-bold">+{phone}</span>
                  <button
                    onClick={() => handleRemoveWhitelistedUser(phone)}
                    className="text-[#FF5252] hover:bg-[#FF5252]/10 p-1 rounded"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

      {/* Group Protection Mode & Group Selection */}
      <div className="bg-[#1C2733] border border-[rgba(255,255,255,0.08)] rounded-2xl p-4 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[rgba(255,255,255,0.07)] pb-3">
          <div>
            <span className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#2AABEE]" /> WhatsApp Group Protection Selection
            </span>
            <p className="text-[10px] text-[#7A9CB8] mt-0.5">
              Choose which WhatsApp groups to protect using your connected WhatsApp session.
            </p>
          </div>

          {/* Mode Switcher Pills */}
          <div className="flex bg-[#17212B] p-1 rounded-xl border border-[rgba(255,255,255,0.06)] shrink-0">
            <button
              onClick={() => handleSaveConfig({ ...config, groupProtectionMode: 'selected_only' })}
              className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all ${
                config.groupProtectionMode === 'selected_only'
                  ? 'bg-[#00C26F] text-white shadow-md'
                  : 'text-[#7A9CB8] hover:text-white'
              }`}
            >
              Protect Selected Groups Only
            </button>
            <button
              onClick={() => handleSaveConfig({ ...config, groupProtectionMode: 'all' })}
              className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all ${
                config.groupProtectionMode === 'all'
                  ? 'bg-[#2AABEE] text-white shadow-md'
                  : 'text-[#7A9CB8] hover:text-white'
              }`}
            >
              Protect All Groups
            </button>
          </div>
        </div>

        {/* Search & Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2">
          <input
            type="text"
            placeholder="Search WhatsApp groups by name..."
            value={groupSearch}
            onChange={(e) => setGroupSearch(e.target.value)}
            className="w-full sm:w-64 bg-[#17212B] text-white text-xs border border-[rgba(255,255,255,0.08)] rounded-xl px-3 py-1.5 outline-none focus:border-[#2AABEE]"
          />

          {config.groupProtectionMode === 'selected_only' && (
            <div className="flex items-center gap-2 self-end sm:self-auto">
              <button
                onClick={handleSelectAllProtected}
                className="text-[10px] font-bold bg-[#00C26F]/15 text-[#00C26F] border border-[#00C26F]/30 px-2.5 py-1 rounded-lg hover:bg-[#00C26F]/25 transition-all"
              >
                Select All ({syncedGroups.length})
              </button>
              <button
                onClick={handleClearAllProtected}
                className="text-[10px] font-bold bg-[#FF5252]/15 text-[#FF5252] border border-[#FF5252]/30 px-2.5 py-1 rounded-lg hover:bg-[#FF5252]/25 transition-all"
              >
                Deselect All
              </button>
            </div>
          )}
        </div>

        {/* Group Selection Grid */}
        <div className="max-h-56 overflow-y-auto space-y-1.5 pr-1 no-scrollbar">
          {syncedGroups.length === 0 ? (
            <div className="text-center py-6 text-[#7A9CB8] bg-[#17212B] rounded-xl border border-[rgba(255,255,255,0.05)]">
              <p className="text-xs font-bold text-white mb-1">No WhatsApp Groups Synced Yet</p>
              <p className="text-[10px]">Ensure your WhatsApp is paired in Setup/Termux and click Sync Chats.</p>
            </div>
          ) : (
            syncedGroups
              .filter(g => g.name.toLowerCase().includes(groupSearch.toLowerCase()))
              .map((g) => {
                if (config.groupProtectionMode === 'selected_only') {
                  const isProtected = (config.protectedGroups || []).includes(g.jid);
                  return (
                    <div
                      key={g.jid}
                      onClick={() => handleToggleProtectedGroup(g.jid)}
                      className={`cursor-pointer rounded-xl px-3 py-2.5 border transition-all flex items-center justify-between text-xs ${
                        isProtected
                          ? 'bg-[#00C26F]/15 border-[#00C26F]/40 text-white font-bold shadow-sm'
                          : 'bg-[#17212B] border-[rgba(255,255,255,0.05)] text-[#7A9CB8] hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <input
                          type="checkbox"
                          checked={isProtected}
                          onChange={() => {}}
                          className="w-4 h-4 accent-[#00C26F] cursor-pointer"
                        />
                        <span className="truncate max-w-[280px] sm:max-w-[400px]">{g.name}</span>
                      </div>
                      <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full ${
                        isProtected ? 'bg-[#00C26F] text-white' : 'bg-[#2B3A4D] text-[#7A9CB8]'
                      }`}>
                        {isProtected ? '🛡️ Protected' : 'Not Monitored'}
                      </span>
                    </div>
                  );
                } else {
                  const isExempt = (config.whitelistedGroups || []).includes(g.jid);
                  return (
                    <div
                      key={g.jid}
                      onClick={() => handleToggleGroupWhitelist(g.jid)}
                      className={`cursor-pointer rounded-xl px-3 py-2.5 border transition-all flex items-center justify-between text-xs ${
                        isExempt
                          ? 'bg-[#FAC748]/15 border-[#FAC748]/40 text-white font-bold'
                          : 'bg-[#17212B] border-[rgba(255,255,255,0.05)] text-[#7A9CB8] hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <input
                          type="checkbox"
                          checked={!isExempt}
                          onChange={() => {}}
                          className="w-4 h-4 accent-[#2AABEE] cursor-pointer"
                        />
                        <span className="truncate max-w-[280px] sm:max-w-[400px]">{g.name}</span>
                      </div>
                      <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full ${
                        isExempt ? 'bg-[#FAC748] text-black' : 'bg-[#00C26F] text-white'
                      }`}>
                        {isExempt ? 'Exempted' : '🛡️ Protected'}
                      </span>
                    </div>
                  );
                }
              })
          )}
        </div>
      </div>

      {/* Live Spam Detector Tester */}
      <div className="bg-[#1C2733] border border-[rgba(42,171,238,0.25)] rounded-2xl p-4 space-y-3">
        <span className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-2">
          <Zap className="w-4 h-4 text-[#2AABEE]" /> Test Spam Filter Simulator
        </span>
        <div className="flex gap-2">
          <input
            type="text"
            value={testText}
            onChange={(e) => setTestText(e.target.value)}
            placeholder="Type sample text with or without link..."
            className="flex-1 bg-[#17212B] text-white text-xs border border-[rgba(255,255,255,0.08)] rounded-xl px-3 py-2 outline-none focus:border-[#2AABEE]"
          />
          <button
            onClick={handleTestDetector}
            className="bg-[#2AABEE] text-white px-3.5 py-2 rounded-xl font-black text-xs uppercase active:scale-95 transition-all shadow-md shrink-0"
          >
            Check Text
          </button>
        </div>

        {testResult && (
          <div className={`p-3 rounded-xl border flex items-center gap-2.5 text-xs font-bold ${
            testResult.isSpam ? 'bg-[#FF5252]/10 border-[#FF5252]/30 text-[#FF5252]' : 'bg-[#00C26F]/10 border-[#00C26F]/30 text-[#00C26F]'
          }`}>
            {testResult.isSpam ? <XCircle className="w-4 h-4 shrink-0" /> : <CheckCircle className="w-4 h-4 shrink-0" />}
            <span>{testResult.reason}</span>
          </div>
        )}
      </div>

      {/* Incident Stream & History */}
      <div className="bg-[#1C2733] border border-[rgba(255,255,255,0.08)] rounded-2xl p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.07)] pb-2.5">
          <span className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#FF5252]" /> Live Spam Detection Incidents Log
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handleResetWarnings}
              className="text-[10px] font-bold bg-[#FAC748]/15 text-[#FAC748] border border-[#FAC748]/30 px-2.5 py-1 rounded-lg hover:bg-[#FAC748]/25 transition-all active:scale-95"
            >
              Reset Warning Map
            </button>
            <button
              onClick={handleClearLogs}
              className="text-[10px] font-bold bg-[#FF5252]/15 text-[#FF5252] border border-[#FF5252]/30 px-2.5 py-1 rounded-lg hover:bg-[#FF5252]/25 transition-all active:scale-95 flex items-center gap-1"
            >
              <Trash2 className="w-3 h-3" /> Clear History
            </button>
          </div>
        </div>

        <div className="max-h-72 overflow-y-auto space-y-2 pr-1 no-scrollbar">
          {incidents.length === 0 ? (
            <div className="text-center py-8 text-[#7A9CB8]">
              <ShieldCheck className="w-8 h-8 mx-auto mb-2 opacity-40 text-[#00C26F]" />
              <p className="text-xs font-bold">No spam incidents detected yet.</p>
              <p className="text-[10px] opacity-75">Your WhatsApp groups are protected and clean.</p>
            </div>
          ) : (
            incidents.map((inc) => (
              <div
                key={inc.id}
                className="bg-[#17212B] border border-[rgba(255,255,255,0.06)] rounded-xl p-3 space-y-1.5 transition-all hover:border-[rgba(42,171,238,0.2)]"
              >
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">{inc.chatName || inc.chatId}</span>
                    <span className="text-[10px] text-[#7A9CB8]">({inc.senderPhone})</span>
                  </div>
                  <span className="text-[9px] text-[#7A9CB8] font-mono">{inc.timestamp}</span>
                </div>

                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-[#94A3B8] truncate max-w-[280px]">
                    Message: "{inc.messageText}"
                  </span>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded bg-[#2B3A4D] text-[#2AABEE]">
                      {inc.reason}
                    </span>
                    <span className={`text-[9px] font-black px-2 py-0.5 rounded uppercase ${
                      inc.action === 'User Kicked'
                        ? 'bg-[#FF5252] text-white'
                        : 'bg-[#FAC748]/20 text-[#FAC748] border border-[#FAC748]/30'
                    }`}>
                      {inc.action}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
