import './GatewayView.css';
import { apiUrl } from '../utils/api';
import React, { useState, useEffect, useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import {
  Bot,
  Terminal,
  Copy,
  Check,
  RefreshCw,
  Power,
  Plus,
  Trash2,
  Clock,
  ShieldCheck,
  Activity,
  Code,
  Smartphone,
  MessageCircle,
  Send,
  Radio,
  ArrowDownLeft,
  ArrowUpRight
} from 'lucide-react';
import { UserProfile, GameType } from '../types';
import { MARKETS, BASE_MARKETS } from '../data/markets';
import { TargetSelectorModal } from './TargetSelectorModal';
import { SpamProctorView } from './SpamProctorView';
import { normalizeTargetJid } from '../utils/targetNormalization';
import { TelegramGatewayView } from './TelegramGatewayView';

interface TermuxBotViewProps {
  visible?: boolean;
  profile: UserProfile;
  currentDate: string;
  onShowToast: (title: string, body: string, type?: 'info' | 'success' | 'danger') => void;
}

interface BotLogEntry {
  id: string;
  time: string;
  msg: string;
  type: string;
  event?: string;
  deliveryStatus?: 'success' | 'failed';
  targetJid?: string;
  targetKind?: 'group' | 'channel' | 'private';
  targetName?: string;
  sourceKind?: string;
  sourceLabel?: string;
}

export const TermuxBotView: React.FC<TermuxBotViewProps> = ({
  visible = true,
  profile,
  currentDate,
  onShowToast,
}) => {
  const [copiedStep, setCopiedStep] = useState<number | null>(null);
  const [platform, setPlatform] = useState<'whatsapp' | 'telegram'>('whatsapp');
  const [activeTab, setActiveTab] = useState<'status' | 'setup' | 'schedules' | 'spam' | 'logs'>('status');

  // Bot configuration state
  const [botConfig, setBotConfig] = useState({
    autoSendEnabled: true,
    autoResultForwardEnabled: true,
    profitMilestoneNotificationsEnabled: false,
    loginMethod: 'pairing', // 'pairing' | 'qr'
    loginPhone: '',
    botPhone: '',
    status: 'offline', // 'online' | 'offline' | 'pairing' | 'reconnecting' | 'unresponsive'
    lastHeartbeat: null as string | null,
    targetGroups: [],
    resultReadGroups: [] as string[],
    prefix: '.',
    customHeader: '🚀 TITAN NOVA AUTOMATED INTEL',
    pairingCode: '',
    qrCodeData: '',
  });

  const [copiedPairingCode, setCopiedPairingCode] = useState(false);
  const [logs, setLogs] = useState<BotLogEntry[]>([]);
  const [newTargetJid, setNewTargetJid] = useState('');
  const [newReadGroupJid, setNewReadGroupJid] = useState('');
  const [isLoadingConfig, setIsLoadingConfig] = useState(false);
  const [isGeneratingLink, setIsGeneratingLink] = useState(false);
  const [logoutBusy, setLogoutBusy] = useState(false);
  const statusReadInFlightRef = useRef(false);
  const statusRefreshQueuedRef = useRef(false);
  const statusVersionRef = useRef(0);
  const [linkError, setLinkError] = useState('');
  const [isTargetModalOpen, setIsTargetModalOpen] = useState(false);
  const [isReadTargetModalOpen, setIsReadTargetModalOpen] = useState(false);
  const [isInlineLogsOpen, setIsInlineLogsOpen] = useState(false);
  const [removingLogTarget, setRemovingLogTarget] = useState('');
  // Local draft so 5s poll cannot overwrite what user is typing
  const [phoneDraft, setPhoneDraft] = useState('');
  const phoneDirtyRef = useRef(false);
  const phoneDraftRef = useRef(phoneDraft);
  phoneDraftRef.current = phoneDraft;

  const fetchBotLogs = async () => {
    try {
      const logRes = await fetch(apiUrl('/api/bot/logs'), { cache: 'no-store' });
      const logJson = await logRes.json();
      if (logJson.status === 'success' && Array.isArray(logJson.logs)) {
        setLogs(logJson.logs);
      }
    } catch (e) {
      console.error('Failed to fetch bot logs:', e);
    }
  };

  // Fetch bot status & logs from server
  const fetchBotStatus = async (showLoading = false, forceFresh = false) => {
    // Polls can overlap on slow mobile links. Only one request may update UI.
    if (statusReadInFlightRef.current) {
      if (forceFresh) statusRefreshQueuedRef.current = true;
      return;
    }
    statusReadInFlightRef.current = true;
    const version = statusVersionRef.current;
    try {
      if (showLoading) setIsLoadingConfig(true);
      const res = await fetch(apiUrl('/api/bot/config'), { cache: 'no-store' });
      const json = await res.json();
      if (version !== statusVersionRef.current) return;
      if (res.ok && json.status === 'success' && json.config) {
        const cfg = json.config;
        // Never clobber phone field while user is editing
        setBotConfig((prev) => ({
          ...prev,
          ...cfg,
          loginPhone: phoneDirtyRef.current ? prev.loginPhone : (cfg.loginPhone || prev.loginPhone),
        }));
        if (!phoneDirtyRef.current && cfg.loginPhone) {
          setPhoneDraft(String(cfg.loginPhone).replace(/\D/g, ''));
        }
      }

      const logRes = await fetch(apiUrl('/api/bot/logs'), { cache: 'no-store' });
      const logJson = await logRes.json();
      if (version === statusVersionRef.current && logRes.ok && logJson.status === 'success' && Array.isArray(logJson.logs)) {
        setLogs(logJson.logs);
      }
    } catch (e) {
      console.error('Failed to fetch bot config:', e);
    } finally {
      statusReadInFlightRef.current = false;
      if (showLoading) setIsLoadingConfig(false);
      if (statusRefreshQueuedRef.current) {
        statusRefreshQueuedRef.current = false;
        void fetchBotStatus(false);
      }
    }
  };

  useEffect(() => {
    void fetchBotStatus(false);
    // Poll every 30s (was 5s — too aggressive)
    const interval = visible ? setInterval(() => { if (document.visibilityState !== 'hidden') void fetchBotStatus(false); }, 30000) : undefined;
    return () => clearInterval(interval);
  }, [visible]);

  useEffect(() => {
    if (!visible || platform !== 'whatsapp') return;
    void fetchBotLogs();
    const interval = window.setInterval(() => { void fetchBotLogs(); }, 3000);
    return () => window.clearInterval(interval);
  }, [platform, visible]);

  // Pairing/QR generation needs fast temporary polling; normal dashboard
  // polling remains slow to avoid unnecessary requests.
  useEffect(() => {
    if (!isGeneratingLink) return;
    const startedAt = Date.now();
    const timer = window.setInterval(() => {
      void fetchBotStatus(false);
      if (Date.now() - startedAt > 60_000) {
        window.clearInterval(timer);
        setIsGeneratingLink(false);
        setLinkError('Code generate nahi hua. Bot logs check karke Retry karein.');
      }
    }, 1500);
    return () => window.clearInterval(timer);
  }, [isGeneratingLink]);

  useEffect(() => {
    const ready = botConfig.loginMethod === 'pairing'
      ? Boolean(botConfig.pairingCode)
      : Boolean(botConfig.qrCodeData);
    if (isGeneratingLink && (ready || botConfig.status === 'online')) {
      setIsGeneratingLink(false);
      setLinkError('');
    }
  }, [botConfig.pairingCode, botConfig.qrCodeData, botConfig.status, botConfig.loginMethod, isGeneratingLink]);

  const requestDeviceLink = async (method: 'pairing' | 'qr') => {
    const phone = phoneDraftRef.current.replace(/\D/g, '');
    if (method === 'pairing' && phone.length < 10) {
      setLinkError('Country code ke saath valid mobile number enter karein.');
      onShowToast('❌ Invalid Number', 'Country code ke saath kam se kam 10 digits chahiye.', 'danger');
      return;
    }
    try {
      // Any status poll started before the user requested a fresh link is obsolete.
      statusVersionRef.current++;
      setLinkError('');
      setIsGeneratingLink(true);
      phoneDirtyRef.current = false;
      setBotConfig((prev) => ({
        ...prev,
        loginMethod: method,
        loginPhone: method === 'pairing' ? phone : prev.loginPhone,
        pairingCode: '',
        qrCodeData: '',
        status: 'pairing',
      }));
      const res = await fetch(apiUrl('/api/bot/force_relogin'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          loginMethod: method,
          ...(method === 'pairing' ? { loginPhone: phone } : {}),
        }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || json.status !== 'success') {
        throw new Error(json.message || 'Link request reject hua');
      }
      onShowToast(
        method === 'pairing' ? '🔐 Generating Code' : '📷 Generating QR',
        method === 'pairing' ? `+${phone} ke liye secure code ban raha hai.` : 'Fresh WhatsApp QR ban raha hai.',
        'info'
      );
      void fetchBotStatus(false, true);
    } catch (error: any) {
      setIsGeneratingLink(false);
      const message = error?.message || 'Bot server se connection nahi hua.';
      setLinkError(message);
      onShowToast('❌ Generation Failed', message, 'danger');
    }
  };

  // Save Config to Server
  const saveConfig = async (newConfig: typeof botConfig & { forceRelogin?: boolean }) => {
    try {
      const phone = String(newConfig.loginPhone || phoneDraftRef.current || '').replace(/\D/g, '');
      const payload:Partial<typeof newConfig> = { ...newConfig, loginPhone: phone };
      // Profit has one authority in the ledger row; stale gateway saves must not overwrite it.
      delete payload.profitMilestoneNotificationsEnabled;
      statusVersionRef.current++;
      setBotConfig((prev) => ({ ...prev, ...payload, loginPhone: phone }));
      setPhoneDraft(phone);
      phoneDirtyRef.current = false;
      const res = await fetch(apiUrl('/api/bot/config'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const json = await res.json();
      if (json.status === 'success') {
        const saved = json.config?.loginPhone || phone;
        setPhoneDraft(String(saved).replace(/\D/g, ''));
        setBotConfig((prev) => ({ ...prev, loginPhone: String(saved).replace(/\D/g, '') }));
        onShowToast('💾 Config Saved', `Login number set to +${saved}`, 'success');
      } else {
        void fetchBotStatus(false, true);
        onShowToast('❌ Save Failed', json.message || 'Server rejected config', 'danger');
      }
    } catch (e) {
      void fetchBotStatus(false, true);
      onShowToast('❌ Save Failed', 'Unable to save bot config to server.', 'danger');
    }
  };

  // Copy helper
  const handleCopyText = (text: string, stepIdx: number) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedStep(stepIdx);
      setTimeout(() => setCopiedStep(null), 3000);
      onShowToast('📋 Copied!', 'Command copied to clipboard.', 'success');
    }
  };

  // Add Target JID
  const handleAddTarget = async () => {
    const trimmed = newTargetJid.trim();
    if (!trimmed) return;

    if (/^(?:https?:\/\/)?(?:www\.)?whatsapp\.com\/channel\//i.test(trimmed)) {
      try {
        const res = await fetch(apiUrl('/api/bot/resolve_channel'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ channelLink: trimmed }),
        });
        const json = await res.json();
        if (!res.ok || json.status !== 'success') throw new Error(json.message || 'Channel resolve request failed');
        setNewTargetJid('');
        onShowToast('⏳ Resolving Channel', 'WhatsApp Channel link submit ho gaya hai, thodi der me sync ho jayega.', 'info');
      } catch (err: any) {
        onShowToast('⚠️ Error', err.message || 'Channel resolve nahi ho saka.', 'danger');
      }
      return;
    }

    const formatted = normalizeTargetJid(trimmed);
    if (!formatted) {
      onShowToast('⚠️ Invalid Target', 'Enter a valid phone, Group JID, or Channel JID ending @newsletter.', 'danger');
      return;
    }

    if (botConfig.targetGroups.includes(formatted)) {
      onShowToast('⚠️ Duplicate Target', 'Target already exists in target list.', 'info');
      return;
    }

    const updated = {
      ...botConfig,
      targetGroups: [...botConfig.targetGroups, formatted],
    };

    saveConfig(updated);
    setNewTargetJid('');
  };

  // Remove Target JID
  const handleRemoveTarget = (targetToRemove: string) => {
    const updated = {
      ...botConfig,
      targetGroups: botConfig.targetGroups.filter((t) => t !== targetToRemove),
    };
    saveConfig(updated);
  };

  const handleRemoveLoggedTarget = async (targetJid: string) => {
    const normalized = normalizeTargetJid(targetJid);
    if (!normalized || (!normalized.endsWith('@g.us') && !normalized.endsWith('@newsletter'))) return;
    try {
      setRemovingLogTarget(normalized);
      const res = await fetch(apiUrl('/api/bot/remove_target'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetJid: normalized }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || json.status !== 'success') throw new Error(json.message || 'Target remove failed');
      const nextTargets = Array.isArray(json.targetGroups)
        ? json.targetGroups
        : botConfig.targetGroups.filter((t) => t !== normalized);
      setBotConfig((prev) => ({ ...prev, targetGroups: nextTargets }));
      if (json.removed) {
        onShowToast('🗑️ Target Removed', 'WhatsApp Sending Targets se group/channel unselected ho gaya. Income Source aur VIP destination unchanged hain.', 'success');
      } else {
        onShowToast('ℹ️ Not Saved', 'Ye destination global WhatsApp Sending Targets me selected nahi tha.', 'info');
      }
      await fetchBotLogs();
    } catch (e: any) {
      onShowToast('❌ Remove Failed', e?.message || 'WhatsApp target remove nahi hua.', 'danger');
    } finally {
      setRemovingLogTarget('');
    }
  };

  const isFailedGroupChannelLog = (log: BotLogEntry) =>
    log.event === 'whatsapp-delivery' &&
    log.deliveryStatus === 'failed' &&
    Boolean(log.targetJid) &&
    (log.targetKind === 'group' || log.targetKind === 'channel');

  // Add Source Result Read Group/Channel JID
  const handleAddReadGroup = () => {
    const trimmed = newReadGroupJid.trim();
    if (!trimmed) return;

    const formatted = normalizeTargetJid(trimmed);
    const isIncomeSource = formatted?.endsWith('@g.us') || formatted?.endsWith('@newsletter');
    if (!formatted || !isIncomeSource) {
      onShowToast('⚠️ Invalid Source', 'Enter a Group JID ending @g.us or Channel JID ending @newsletter.', 'danger');
      return;
    }

    if (botConfig.resultReadGroups.includes(formatted)) {
      onShowToast('⚠️ Duplicate Source', 'Group or Channel already exists in result read list.', 'info');
      return;
    }

    const updated = {
      ...botConfig,
      resultReadGroups: [...botConfig.resultReadGroups, formatted],
    };

    saveConfig(updated);
    setNewReadGroupJid('');
  };

  // Remove Result Read Group JID
  const handleRemoveReadGroup = (groupToRemove: string) => {
    const updated = {
      ...botConfig,
      resultReadGroups: botConfig.resultReadGroups.filter((g) => g !== groupToRemove),
    };
    saveConfig(updated);
  };

  // Extract current profile scheduled items across Ank, Jodi, Pannel
  const getScheduledItems = () => {
    const dayStore = profile.dayRecords[currentDate] || {};
    const items: {
      type: GameType;
      marketName: string;
      index: number;
      time: string;
      digits: string;
      rate: string;
      targets: string[];
    }[] = [];

    // Ank
    MARKETS.forEach((m, idx) => {
      const rec = dayStore.data?.[idx];
      if (rec && rec.schTime) {
        items.push({
          type: 'ank',
          marketName: m.n,
          index: idx,
          time: rec.schTime,
          digits: rec.d || '---',
          rate: rec.r || '0',
          targets: rec.schTargets || [],
        });
      }
    });

    // Jodi
    BASE_MARKETS.forEach((m, idx) => {
      const rec = dayStore.jodiData?.[idx];
      if (rec && rec.schTime) {
        items.push({
          type: 'jodi',
          marketName: m.n,
          index: idx,
          time: rec.schTime,
          digits: rec.d || '---',
          rate: rec.r || '0',
          targets: rec.schTargets || [],
        });
      }
    });

    // Pannel
    MARKETS.forEach((m, idx) => {
      const rec = dayStore.pannelData?.[idx];
      if (rec && rec.schTime) {
        items.push({
          type: 'pannel',
          marketName: m.n,
          index: idx,
          time: rec.schTime,
          digits: rec.d || '---',
          rate: rec.r || '0',
          targets: rec.schTargets || [],
        });
      }
    });

    return items;
  };

  const scheduledItems = getScheduledItems();

  const termuxSetupSteps = [
    {
      step: 1,
      title: 'Termux Environment & Node.js Setup',
      desc: 'Open Termux app on Android and run this command to update packages & install Node.js:',
      cmd: 'pkg update && pkg upgrade -y && pkg install nodejs git -y',
    },
    {
      step: 2,
      title: 'Create Bot Folder & Install Baileys',
      desc: 'Create project directory and install @whiskeysockets/baileys & dependencies:',
      cmd: 'mkdir titan-bot && cd titan-bot && npm init -y && npm install @whiskeysockets/baileys qrcode-terminal pino node-fetch',
    },
    {
      step: 3,
      title: 'Create Bot File (titan-bot.js)',
      desc: 'Create file `titan-bot.js` in Termux and paste the full script from button below:',
      cmd: 'nano titan-bot.js',
    },
    {
      step: 4,
      title: 'Run Bot & Pair WhatsApp QR',
      desc: 'Launch the bot and scan QR code or enter pairing code in WhatsApp:',
      cmd: 'node titan-bot.js',
    },
  ];

  const fullAppZipSteps = [
    {
      step: 1,
      title: 'Allow Termux Storage Access',
      desc: 'Grant storage permission in Termux to read the downloaded ZIP file from your Downloads folder:',
      cmd: 'termux-setup-storage',
    },
    {
      step: 2,
      title: 'Install Node.js & Unzip Tools',
      desc: 'Update Termux repositories and install Node.js, Git, and Unzip package:',
      cmd: 'pkg update && pkg upgrade -y && pkg install nodejs git unzip -y',
    },
    {
      step: 3,
      title: 'Extract Downloaded App ZIP in Downloads',
      desc: 'Go to Android Downloads directory and extract the project ZIP into `titan-app` folder:',
      cmd: 'cd /sdcard/Download && unzip *.zip -d titan-app && cd titan-app',
    },
    {
      step: 4,
      title: 'Install Project NPM Packages',
      desc: 'Install all required libraries (Express server, Vite, Baileys WA, React, etc.):',
      cmd: 'npm install',
    },
    {
      step: 5,
      title: 'Start Web App & WhatsApp Bot Together',
      desc: 'Launch both the Web Dashboard (Port 3000) and the WhatsApp Bot Gateway simultaneously in Termux:',
      cmd: 'npm run dev & node titan-bot.js',
    },
    {
      step: 6,
      title: 'Open Web App in Phone Browser',
      desc: 'Open Chrome or any browser on your Android phone and navigate to:',
      cmd: 'http://localhost:3000',
    },
  ];

  const [guideType, setGuideType] = useState<'zip' | 'standalone'>('zip');

  const platformTabs = <>
    <header className="gateway-page-heading">
      <div><span className="gateway-eyebrow">BUSINESS COMMUNICATIONS</span><h1>Messaging gateways</h1><p>Connect your accounts and manage your business messaging.</p></div>
      <span className="gateway-workspace-tag"><ShieldCheck size={14} /> Admin workspace</span>
    </header>
    <div className="gateway-platform-tabs" aria-label="Messaging platform">{(['whatsapp', 'telegram'] as const).map(value => <button type="button" key={value} onClick={() => setPlatform(value)} aria-pressed={platform === value} className={`gateway-platform-tab ${platform === value ? 'is-selected' : ''}`}>
      <span className={`gateway-platform-icon ${value}`}>{value === 'whatsapp' ? <MessageCircle size={20} /> : <Send size={20} />}</span>
      <span><strong>{value === 'whatsapp' ? 'WhatsApp' : 'Telegram'}</strong><small>{value === 'whatsapp' ? 'Device connection' : 'Account connection'}</small></span>
      <span className="gateway-platform-indicator" />
    </button>)}</div>
  </>;
  if (platform === 'telegram') return <div className="business-gateway">{platformTabs}<TelegramGatewayView visible={visible} /></div>;
  return (<div className="business-gateway">{platformTabs}
    <div className="gateway-whatsapp-body space-y-4">
      {/* Sleek Top Gateway Header */}
      <div className="bg-[#1C2733] border border-[rgba(255,255,255,0.08)] rounded-2xl p-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${botConfig.status === 'online' ? 'bg-[#00C26F]/20 text-[#00C26F] border border-[#00C26F]/30' : 'bg-[#2AABEE]/20 text-[#2AABEE] border border-[#2AABEE]/30'}`}>
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-white font-black text-sm tracking-wide uppercase">
                  WhatsApp connection
                </h2>
                <span className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase border ${
                  botConfig.status === 'online'
                    ? 'bg-[#00C26F]/20 text-[#00C26F] border-[#00C26F]/30'
                    : ['pairing', 'reconnecting', 'unresponsive'].includes(botConfig.status)
                    ? 'bg-[#FAC748]/20 text-[#FAC748] border-[#FAC748]/30'
                    : 'bg-[#FF4D4D]/20 text-[#FF4D4D] border-[#FF4D4D]/30'
                }`}>
                  {botConfig.status === 'online' ? 'Connected' : botConfig.status === 'pairing' ? 'Pairing' : botConfig.status === 'reconnecting' ? 'Reconnecting' : botConfig.status === 'unresponsive' ? 'Heartbeat delayed' : 'Offline'}
                </span>
              </div>
              <p className="text-[#7A9CB8] text-[10px] font-bold mt-0.5">
                {botConfig.botPhone
                  ? `Account +${botConfig.botPhone}`
                  : 'Connect an account to get started'}
                {(botConfig as any).secondsSinceHeartbeat != null && (
                  <span className="ml-1 text-[#5A7A94]">
                    · HB {(botConfig as any).secondsSinceHeartbeat}s ago
                    {(botConfig as any).groupsCount != null
                      ? ` · ${(botConfig as any).groupsCount} groups`
                      : ''}
                  </span>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {(botConfig.status === 'online' || botConfig.status === 'reconnecting' || botConfig.status === 'pairing' || botConfig.status === 'unresponsive') && (
              <button
                onClick={async () => {
                  if (logoutBusy || !window.confirm('Disconnect the active WhatsApp session? You may need to pair again.')) return;
                  setLogoutBusy(true);
                  try {
                    statusVersionRef.current++;
                    const response = await fetch(apiUrl('/api/bot/logout'), { method: 'POST' });
                    const reply = await response.json().catch(() => ({}));
                    if (!response.ok || reply.status !== 'success') throw new Error(reply.message || 'Server rejected logout');
                    onShowToast('🔌 Logout Requested', 'Waiting for bot to disconnect...', 'info');
                    void fetchBotStatus(false, true);
                  } catch (e) {
                    onShowToast('❌ Error', e instanceof Error ? e.message : 'Failed to request logout', 'danger');
                  } finally { setLogoutBusy(false); }
                }}
                disabled={logoutBusy}
                className="p-2 rounded-xl bg-[#FF4D4D]/10 text-[#FF4D4D] border border-[#FF4D4D]/30 hover:bg-[#FF4D4D]/20 active:scale-95 transition-all"
                title="Logout WhatsApp"
              >
                <Power className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={() => fetchBotStatus(true, true)}
              disabled={isLoadingConfig}
              className="p-2 rounded-xl bg-[#2B3A4D] text-[#2AABEE] border border-[rgba(255,255,255,0.08)] active:scale-95 transition-all"
              title="Refresh Gateway"
            >
              <RefreshCw className={`w-4 h-4 ${isLoadingConfig ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      <div className="gateway-summary-grid">
        <div className="gateway-summary"><span><Radio size={16} />Connection</span><strong className={botConfig.status === 'online' ? 'gateway-online' : ''}>{botConfig.status === 'online' ? 'Connected' : botConfig.status === 'pairing' ? 'Pairing' : botConfig.status === 'reconnecting' ? 'Reconnecting' : botConfig.status === 'unresponsive' ? 'Heartbeat delayed' : 'Offline'}</strong><small>{botConfig.botPhone ? `+${botConfig.botPhone}` : 'No connected account'}</small></div>
        <div className="gateway-summary"><span><ArrowDownLeft size={16} />Incoming sources</span><strong>{botConfig.resultReadGroups.length}</strong><small>Result monitoring</small></div>
        <div className="gateway-summary"><span><ArrowUpRight size={16} />Sending targets</span><strong>{botConfig.targetGroups.length}</strong><small>Configured destinations</small></div>
        <div className="gateway-summary"><span><Clock size={16} />Scheduled cards</span><strong>{scheduledItems.length}</strong><small>For {currentDate}</small></div>
      </div>
      {/* Gateway section navigation */}
      <div className="gateway-section-tabs grid grid-cols-5 bg-[#17212B] p-1 gap-1 rounded-xl border border-[rgba(255,255,255,0.06)] text-[9px] font-black uppercase">
        <button
          onClick={() => setActiveTab('status')}
          className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1 ${
            activeTab === 'status' ? 'bg-[#2AABEE] text-white shadow-md' : 'text-[#7A9CB8] hover:text-white'
          }`}
        >
          <Activity className="w-3.5 h-3.5" /> Gateway
        </button>
        <button
          onClick={() => setActiveTab('schedules')}
          className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1 ${
            activeTab === 'schedules' ? 'bg-[#2AABEE] text-white shadow-md' : 'text-[#7A9CB8] hover:text-white'
          }`}
        >
          <Clock className="w-3.5 h-3.5" /> Alarms ({scheduledItems.length})
        </button>
        <button
          onClick={() => setActiveTab('setup')}
          className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1 ${
            activeTab === 'setup' ? 'bg-[#2AABEE] text-white shadow-md' : 'text-[#7A9CB8] hover:text-white'
          }`}
        >
          <Terminal className="w-3.5 h-3.5" /> Termux
        </button>
        <button
          onClick={() => setActiveTab('spam')}
          className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1 ${
            activeTab === 'spam' ? 'bg-[#FF5252] text-white shadow-md' : 'text-[#7A9CB8] hover:text-white'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5 text-[#FF5252]" /> Spam
        </button>
        <button
          onClick={() => setActiveTab('logs')}
          className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1 ${
            activeTab === 'logs' ? 'bg-[#2AABEE] text-white shadow-md' : 'text-[#7A9CB8] hover:text-white'
          }`}
        >
          <Code className="w-3.5 h-3.5" /> Logs
        </button>
      </div>

      {/* TAB 1: GATEWAY CONTROLS & LINKING */}
      {activeTab === 'status' && (
        <div className="gateway-controls-grid space-y-4">
          {/* Pairing & Linking Section */}
          <div className="gateway-device-card bg-[#1C2733] border border-[rgba(255,255,255,0.08)] rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.07)] pb-2.5">
              <span className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-[#2AABEE]" /> Link your device
              </span>
              <div className="flex bg-[#17212B] p-0.5 rounded-lg border border-[rgba(255,255,255,0.08)] text-[10px] font-bold">
                <button
                  onClick={() => {
                    setLinkError('');
                    setBotConfig((prev) => ({ ...prev, loginMethod: 'pairing' }));
                  }}
                  className={`px-2.5 py-1 rounded-md transition-all ${
                    botConfig.loginMethod === 'pairing' ? 'bg-[#2AABEE] text-white font-black' : 'text-[#7A9CB8]'
                  }`}
                >
                  Pair Code
                </button>
                <button
                  onClick={() => {
                    setLinkError('');
                    setBotConfig((prev) => ({ ...prev, loginMethod: 'qr' }));
                  }}
                  className={`px-2.5 py-1 rounded-md transition-all ${
                    botConfig.loginMethod === 'qr' ? 'bg-[#2AABEE] text-white font-black' : 'text-[#7A9CB8]'
                  }`}
                >
                  QR Code
                </button>
              </div>
            </div>

            {botConfig.loginMethod === 'pairing' ? (
              <div className="space-y-3 pt-1">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-black uppercase tracking-wider text-[#8DA6C0]">
                    WhatsApp mobile number
                  </label>
                  <input
                    type="tel"
                    inputMode="numeric"
                    value={phoneDraft}
                    onChange={(e) => {
                      const v = e.target.value.replace(/\D/g, '');
                      phoneDirtyRef.current = true;
                      setPhoneDraft(v);
                      setBotConfig((prev) => ({ ...prev, loginPhone: v }));
                    }}
                    onFocus={() => {
                      phoneDirtyRef.current = true;
                    }}
                    placeholder="Mobile Number (e.g. 91XXXXXXXXXX)"
                    disabled={isGeneratingLink}
                    className="w-full bg-[#17212B] text-white text-sm font-mono font-bold border border-[rgba(255,255,255,0.08)] rounded-xl px-3 py-3 outline-none focus:border-[#2AABEE] disabled:opacity-60"
                  />
                  <p className="text-[9px] text-[#6C7D93]">Country code ke saath, bina + aur spaces. Example: 91XXXXXXXXXX</p>
                </div>
                <button
                  onClick={() => requestDeviceLink('pairing')}
                  disabled={isGeneratingLink}
                  className="w-full bg-gradient-to-r from-[#2AABEE] to-[#1688C7] disabled:from-[#304355] disabled:to-[#304355] text-white py-3 rounded-xl font-black text-xs uppercase active:scale-95 transition-all flex items-center justify-center gap-2 shadow-lg"
                >
                  {isGeneratingLink ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Smartphone className="w-4 h-4" />}
                  {isGeneratingLink ? 'Generating secure code…' : botConfig.botPhone ? 'Switch Account & Generate Code' : 'Generate Pairing Code'}
                </button>

                {linkError && (
                  <div className="rounded-xl border border-[#FF4D4D]/35 bg-[#FF4D4D]/10 px-3 py-2 text-[10px] font-bold text-[#FF7B7B]">
                    {linkError}
                  </div>
                )}

                {/* Pairing Code Box */}
                <div className="bg-[#17212B] border border-[rgba(42,171,238,0.3)] rounded-xl p-3 text-center space-y-1.5">
                  <span className="text-[9px] font-black text-[#7A9CB8] uppercase tracking-widest block">
                    WhatsApp Link Code (+{botConfig.loginPhone || '—'})
                  </span>
                  {botConfig.pairingCode ? (
                    <div className="flex items-center justify-center gap-2">
                      <span className="text-xl font-mono font-black text-[#FAC748] tracking-widest bg-[#2B3A4D] px-3 py-1 rounded-lg border border-[#FAC748]/30">
                        {botConfig.pairingCode}
                      </span>
                      <button
                        onClick={() => {
                          if (navigator.clipboard) {
                            navigator.clipboard.writeText(botConfig.pairingCode.replace('-', ''));
                            setCopiedPairingCode(true);
                            setTimeout(() => setCopiedPairingCode(false), 3000);
                            onShowToast('📋 Code Copied!', 'Pairing code copied to clipboard!', 'success');
                          }
                        }}
                        className="bg-[#00C26F] text-white p-2 rounded-lg text-xs font-bold active:scale-95"
                        title="Copy Code"
                      >
                        {copiedPairingCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  ) : (
                    <p className="text-[10px] text-[#7A9CB8] font-bold">
                      Number enter karke <b className="text-white">Generate Pairing Code</b> dabayein.
                    </p>
                  )}
                </div>
                {botConfig.pairingCode && (
                  <div className="rounded-xl bg-[#00C26F]/10 border border-[#00C26F]/25 px-3 py-2 text-[10px] text-[#9BE7C4]">
                    WhatsApp → Linked Devices → Link with phone number → upar ka code enter karein.
                  </div>
                )}
              </div>
            ) : (
              <div className="py-2 text-center space-y-3">
                {botConfig.qrCodeData ? (
                  <div className="bg-white p-3 rounded-2xl inline-block shadow-lg border-2 border-[#2AABEE]">
                    <QRCodeSVG value={botConfig.qrCodeData} size={150} level="M" />
                  </div>
                ) : (
                  <div className="w-44 h-44 mx-auto rounded-2xl bg-[#17212B] border border-dashed border-[#2AABEE]/40 flex flex-col items-center justify-center gap-2 text-[#7A9CB8]">
                    {isGeneratingLink ? <RefreshCw className="w-8 h-8 animate-spin text-[#2AABEE]" /> : <Smartphone className="w-8 h-8" />}
                    <span className="text-[10px] font-bold">{isGeneratingLink ? 'QR generate ho raha hai…' : 'Fresh QR required'}</span>
                  </div>
                )}
                <p className="text-[10px] text-[#7A9CB8] font-bold">
                  Scan QR code with WhatsApp &gt; Linked Devices &gt; Link a Device
                </p>
                <button
                  onClick={() => requestDeviceLink('qr')}
                  disabled={isGeneratingLink}
                  className="w-full bg-gradient-to-r from-[#2AABEE] to-[#1688C7] disabled:from-[#304355] disabled:to-[#304355] text-white py-3 rounded-xl font-black text-xs uppercase active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  {isGeneratingLink ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                  {isGeneratingLink ? 'Generating QR…' : botConfig.qrCodeData ? 'Generate New QR' : 'Generate QR Code'}
                </button>
                {linkError && <p className="text-[10px] font-bold text-[#FF7B7B]">{linkError}</p>}
              </div>
            )}
          </div>



          {/* AUTOMATED RESULT READ & FORWARDING ENGINE */}
          <div className="gateway-routing-card bg-[#1C2733] border border-[rgba(42,171,238,0.3)] rounded-2xl p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.07)] pb-2.5">
              <div>
                <p className="text-white font-black text-xs uppercase flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-[#2AABEE]" /> Result routing
                </p>
                <p className="text-[#7A9CB8] text-[10px] font-medium">
                  Reads incoming market results from selected Income Group/Channel & forwards automatically
                </p>
              </div>
              <label className="switch">
                <input
                  type="checkbox"
                  checked={botConfig.autoResultForwardEnabled}
                  onChange={(e) => saveConfig({ ...botConfig, autoResultForwardEnabled: e.target.checked })}
                />
                <span className="slider" />
              </label>
            </div>

            {/* 1. INCOME RESULT GROUP / CHANNEL (SOURCE) */}
            <div className="bg-[#17212B] p-3 rounded-xl border border-[rgba(255,255,255,0.08)] space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-black text-[#FAC748] uppercase tracking-wider flex items-center gap-1.5">
                    Incoming result sources
                  </span>
                  <p className="text-[9px] text-[#7A9CB8]">Selected Group ya Channel jaha result message post hota hai</p>
                </div>
                <button
                  onClick={() => setIsReadTargetModalOpen(true)}
                  className="bg-[#FAC748]/20 hover:bg-[#FAC748]/30 text-[#FAC748] px-2.5 py-1 rounded-lg font-bold text-[10px] uppercase flex items-center gap-1 border border-[#FAC748]/30 transition-all active:scale-95"
                >
                  <Plus className="w-3.5 h-3.5" /> Select sources ({botConfig.resultReadGroups.length})
                </button>
              </div>

              <TargetSelectorModal
                isOpen={isReadTargetModalOpen}
                onClose={() => setIsReadTargetModalOpen(false)}
                selectedTargets={botConfig.resultReadGroups}
                incomeSourceOnly
                onSaveTargets={(newReadGroups) => {
                  saveConfig({ ...botConfig, resultReadGroups: newReadGroups });
                  onShowToast('✅ Income Sources Saved', `${newReadGroups.length} Group/Channel source(s) set to read results.`, 'success');
                }}
              />

              <div className="flex gap-2">
                <input
                  type="text"
                  value={newReadGroupJid}
                  onChange={(e) => setNewReadGroupJid(e.target.value)}
                  placeholder="Group @g.us, Channel @newsletter, ya Channel link"
                  className="flex-1 bg-[#2B3A4D] text-white text-xs border border-[rgba(255,255,255,0.08)] rounded-xl px-3 py-2 outline-none font-mono focus:border-[#FAC748]"
                />
                <button
                  onClick={handleAddReadGroup}
                  className="bg-[#FAC748] text-black font-black px-3.5 py-2 rounded-xl text-xs uppercase active:scale-95 transition-all shadow-md"
                >
                  Add
                </button>
              </div>

              <div className="space-y-1.5 max-h-[110px] overflow-y-auto no-scrollbar pt-1">
                {botConfig.resultReadGroups.length === 0 ? (
                  <p className="text-center py-2 text-[#FAC748] text-[10px] font-bold bg-[#FAC748]/10 rounded-xl border border-[#FAC748]/20">
                    ⚠️ Monitoring paused. Select an Income Group or Channel.
                  </p>
                ) : (
                  botConfig.resultReadGroups.map((group, idx) => (
                    <div key={idx} className="flex items-center justify-between bg-[#2B3A4D] px-3 py-1.5 rounded-xl text-xs border border-[rgba(250,199,72,0.2)]">
                      <span className="font-mono font-bold text-white truncate max-w-[240px] text-[11px]">{group}</span>
                      <button
                        onClick={() => handleRemoveReadGroup(group)}
                        className="text-[#FF4D4D] hover:text-white p-1 rounded-lg"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* 2. SENDING RESULT GROUP (DESTINATION) */}
            <div className="bg-[#17212B] p-3 rounded-xl border border-[rgba(255,255,255,0.08)] space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-black text-[#00C26F] uppercase tracking-wider flex items-center gap-1.5">
                    Sending destinations
                  </span>
                  <p className="text-[9px] text-[#7A9CB8]">Admin cards/results selected WhatsApp Groups ya Channels par jayenge</p>
                </div>
                <button
                  onClick={() => setIsTargetModalOpen(true)}
                  className="bg-[#00C26F]/20 hover:bg-[#00C26F]/30 text-[#00C26F] px-2.5 py-1 rounded-lg font-bold text-[10px] uppercase flex items-center gap-1 border border-[#00C26F]/30 transition-all active:scale-95"
                >
                  <Plus className="w-3.5 h-3.5" /> Select targets ({botConfig.targetGroups.length})
                </button>
              </div>

              <TargetSelectorModal
                isOpen={isTargetModalOpen}
                onClose={() => setIsTargetModalOpen(false)}
                selectedTargets={botConfig.targetGroups}
                showChannels
                onSaveTargets={(newTargets) => {
                  saveConfig({ ...botConfig, targetGroups: newTargets });
                  onShowToast('✅ Sending Targets Saved', `${newTargets.length} destination(s) set to receive cards/results.`, 'success');
                }}
              />

              <div className="flex gap-2">
                <input
                  type="text"
                  value={newTargetJid}
                  onChange={(e) => setNewTargetJid(e.target.value)}
                  placeholder="Group @g.us, Channel @newsletter, ya Channel link"
                  className="flex-1 bg-[#2B3A4D] text-white text-xs border border-[rgba(255,255,255,0.08)] rounded-xl px-3 py-2 outline-none font-mono focus:border-[#00C26F]"
                />
                <button
                  onClick={handleAddTarget}
                  className="bg-[#00C26F] text-white font-black px-3.5 py-2 rounded-xl text-xs uppercase active:scale-95 transition-all shadow-md"
                >
                  Add
                </button>
              </div>

              <div className="space-y-1.5 max-h-[110px] overflow-y-auto no-scrollbar pt-1">
                {botConfig.targetGroups.length === 0 ? (
                  <p className="text-center py-2 text-[#FF5D5D] text-[10px] font-bold bg-[#FF5D5D]/10 rounded-xl border border-[#FF5D5D]/20">
                    ⚠️ No sending target set. Add a WhatsApp Group or Channel JID.
                  </p>
                ) : (
                  botConfig.targetGroups.map((target, idx) => (
                    <div key={idx} className="flex items-center justify-between bg-[#2B3A4D] px-3 py-1.5 rounded-xl text-xs border border-[rgba(0,194,111,0.2)]">
                      <div className="flex items-center gap-2 overflow-hidden">
                        {target.endsWith('@newsletter') || target.startsWith('tg:channel:') ? (
                          <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded bg-[#7B8FFF]/20 text-[#7B8FFF] border border-[#7B8FFF]/30 shrink-0">Channel</span>
                        ) : target.endsWith('@g.us') || target.startsWith('tg:group:') ? (
                          <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded bg-[#2AABEE]/20 text-[#2AABEE] border border-[#2AABEE]/30 shrink-0">Group</span>
                        ) : (
                          <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded bg-[#00C26F]/20 text-[#00C26F] border border-[#00C26F]/30 shrink-0">Contact</span>
                        )}
                        <span className="font-mono font-bold text-white truncate max-w-[200px] text-[11px]">{target}</span>
                      </div>
                      <button
                        onClick={() => handleRemoveTarget(target)}
                        className="text-[#FF4D4D] hover:text-white p-1 rounded-lg shrink-0"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* WhatsApp delivery / connection logs — mirrors Telegram visibility without changing delivery state. */}
          <div className="gateway-activity-card bg-[#1C2733] border border-[rgba(255,255,255,0.08)] rounded-2xl p-4 space-y-3">
            <div className="w-full flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => setIsInlineLogsOpen((open) => !open)}
                className="flex-1 text-left"
              >
                <p className="text-[#2AABEE] font-black text-xs">{isInlineLogsOpen ? '▼' : '▶'} WhatsApp delivery / connection logs</p>
                <p className="text-[9px] text-[#7A9CB8] mt-0.5">Actual send success/failure + gateway activity · latest 50</p>
              </button>
              <button
                type="button"
                onClick={() => { void fetchBotLogs(); }}
                className="text-[10px] text-[#2AABEE] font-bold hover:underline shrink-0"
              >
                Refresh
              </button>
            </div>

            {isInlineLogsOpen && (
              <div className="bg-[#17212B] border border-[rgba(255,255,255,0.08)] rounded-xl p-3 font-mono text-[10px] space-y-2 max-h-[330px] overflow-y-auto no-scrollbar">
                {logs.length === 0 ? (
                  <p className="text-center py-6 text-[#7A9CB8]">No log activity recorded yet.</p>
                ) : (
                  logs.map((log) => {
                    const target = log.targetJid ? normalizeTargetJid(log.targetJid) : null;
                    const saved = Boolean(target && botConfig.targetGroups.includes(target));
                    const failedRemovable = isFailedGroupChannelLog(log);
                    return (
                      <div key={log.id} className="border-b border-[rgba(255,255,255,0.04)] pb-2 space-y-1">
                        <div className="flex items-start gap-2">
                          <span className="text-[#7A9CB8] shrink-0">{log.time}</span>
                          <span className={log.type === 'success' ? 'text-[#00C26F]' : log.type === 'danger' ? 'text-[#FF6B6B]' : log.type === 'warning' ? 'text-[#FAC748]' : 'text-[#7A9CB8]'}>
                            {log.msg}
                          </span>
                        </div>
                        {log.sourceLabel && (
                          <div className="pl-[58px] text-[9px] text-[#5F7890]">Source: {log.sourceLabel}</div>
                        )}
                        {failedRemovable && (
                          <div className="pl-[58px] flex items-center gap-2">
                            {saved && target ? (
                              <button
                                type="button"
                                disabled={removingLogTarget === target}
                                onClick={() => void handleRemoveLoggedTarget(target)}
                                className="inline-flex items-center gap-1 rounded-lg border border-[#FF4D4D]/35 bg-[#FF4D4D]/10 px-2 py-1 text-[9px] font-bold text-[#FF7B7B] disabled:opacity-50"
                              >
                                <Trash2 className="w-3 h-3" /> {removingLogTarget === target ? 'Removing…' : 'Remove from Sending Targets'}
                              </button>
                            ) : (
                              <span className="text-[9px] text-[#5F7890]">Not saved in Sending Targets</span>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            )}
          </div>


        </div>
      )}

      {/* TAB 2: ACTIVE AUTO SCHEDULES */}
      {activeTab === 'schedules' && (
        <div className="bg-[#1C2733] border border-[rgba(255,255,255,0.08)] rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.07)] pb-2.5">
            <div>
              <h3 className="text-white font-black text-xs uppercase tracking-wider flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#2AABEE]" /> Active Auto-Schedules
              </h3>
              <p className="text-[#7A9CB8] text-[10px]">Alarms set across Ledger market cards for {currentDate}</p>
            </div>
            <span className="text-xs bg-[#2AABEE]/20 text-[#2AABEE] px-2.5 py-1 rounded-full font-black">
              {scheduledItems.length} Active
            </span>
          </div>

          {scheduledItems.length === 0 ? (
            <div className="text-center py-8 space-y-2 border border-dashed border-[rgba(255,255,255,0.1)] rounded-xl">
              <Clock className="w-8 h-8 text-[#7A9CB8] mx-auto opacity-40" />
              <p className="text-white font-bold text-xs">No Active Alarms Today</p>
              <p className="text-[#7A9CB8] text-[11px] max-w-sm mx-auto">
                Go to <strong className="text-white">Ledger</strong> tab and tap <strong className="text-[#2AABEE]">⏰ Alarm Clock</strong> on any market card to schedule!
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {scheduledItems.map((item, idx) => (
                <div key={idx} className="bg-[#2B3A4D] border border-[rgba(255,255,255,0.07)] p-3 rounded-xl flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-md bg-[#2AABEE]/20 text-[#2AABEE]">
                        {item.type}
                      </span>
                      <h4 className="text-white font-black text-xs">{item.marketName}</h4>
                    </div>
                    <p className="text-[11px] font-mono font-bold text-[#7A9CB8] mt-1">
                      Digits: [{item.digits}] | Rate: ₹{item.rate}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-black text-[#FAC748] flex items-center justify-end gap-1">
                      <Clock className="w-3.5 h-3.5" /> {item.time}
                    </span>
                    <span className="text-[9px] text-[#00C26F] font-bold block mt-0.5">
                      ⚡ Ready for Bot
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: TERMUX EXECUTION GUIDE */}
      {activeTab === 'setup' && (
        <div className="bg-[#1C2733] border border-[rgba(255,255,255,0.08)] rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.07)] pb-2.5">
            <h3 className="text-white font-black text-xs uppercase tracking-wider flex items-center gap-2">
              <Terminal className="w-4 h-4 text-[#2AABEE]" /> Termux Setup Commands
            </h3>
            <div className="flex bg-[#17212B] p-0.5 rounded-lg border border-[rgba(255,255,255,0.07)] text-[10px] font-bold">
              <button
                onClick={() => setGuideType('zip')}
                className={`px-2 py-1 rounded-md ${guideType === 'zip' ? 'bg-[#2AABEE] text-white' : 'text-[#7A9CB8]'}`}
              >
                App ZIP
              </button>
              <button
                onClick={() => setGuideType('standalone')}
                className={`px-2 py-1 rounded-md ${guideType === 'standalone' ? 'bg-[#2AABEE] text-white' : 'text-[#7A9CB8]'}`}
              >
                Bot Script
              </button>
            </div>
          </div>

          <div className="space-y-2.5">
            {(guideType === 'zip' ? fullAppZipSteps : termuxSetupSteps).map((s) => (
              <div key={s.step} className="bg-[#2B3A4D] border border-[rgba(255,255,255,0.07)] p-2.5 rounded-xl space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="w-4 h-4 rounded-full bg-[#2AABEE] text-white font-black text-[9px] flex items-center justify-center shrink-0">
                    {s.step}
                  </span>
                  <h4 className="text-white font-bold text-xs">{s.title}</h4>
                </div>
                <div className="bg-[#17212B] p-2 rounded-lg border border-[rgba(255,255,255,0.08)] flex items-center justify-between gap-2">
                  <code className="text-[#2AABEE] font-mono text-[11px] select-all break-all">{s.cmd}</code>
                  <button
                    onClick={() => handleCopyText(s.cmd, s.step)}
                    className="text-[#7A9CB8] hover:text-white p-1"
                  >
                    {copiedStep === s.step ? <Check className="w-3.5 h-3.5 text-[#00C26F]" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB SPAM: SPAM PROCTOR */}
      {activeTab === 'spam' && (
        <SpamProctorView visible={visible} onShowToast={onShowToast} />
      )}

      {/* TAB 4: LIVE LOGS */}
      {activeTab === 'logs' && (
        <div className="bg-[#1C2733] border border-[rgba(255,255,255,0.08)] rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.07)] pb-2.5">
            <h3 className="text-white font-black text-xs uppercase tracking-wider flex items-center gap-2">
              <Code className="w-4 h-4 text-[#2AABEE]" /> Bot Activity Logs
            </h3>
            <button onClick={() => fetchBotStatus(true, true)} className="text-[10px] text-[#2AABEE] font-bold hover:underline">
              Refresh
            </button>
          </div>

          <div className="bg-[#17212B] border border-[rgba(255,255,255,0.08)] rounded-xl p-3 font-mono text-[11px] space-y-1.5 max-h-[300px] overflow-y-auto no-scrollbar">
            {logs.length === 0 ? (
              <p className="text-center py-6 text-[#7A9CB8]">No log activity recorded yet.</p>
            ) : (
              logs.map((log) => {
                const target = log.targetJid ? normalizeTargetJid(log.targetJid) : null;
                const saved = Boolean(target && botConfig.targetGroups.includes(target));
                const failedRemovable = isFailedGroupChannelLog(log);
                return (
                  <div key={log.id} className="border-b border-[rgba(255,255,255,0.04)] pb-2 space-y-1">
                    <div className="flex items-start gap-2">
                      <span className="text-[#7A9CB8] shrink-0">[{log.time}]</span>
                      <span className={log.type === 'success' ? 'text-[#00C26F]' : log.type === 'danger' ? 'text-[#FF4D4D]' : log.type === 'warning' ? 'text-[#FAC748]' : 'text-[#2AABEE]'}>
                        {log.msg}
                      </span>
                    </div>
                    {log.sourceLabel && <div className="pl-[72px] text-[9px] text-[#5F7890]">Source: {log.sourceLabel}</div>}
                    {failedRemovable && (
                      <div className="pl-[72px]">
                        {saved && target ? (
                          <button
                            type="button"
                            disabled={removingLogTarget === target}
                            onClick={() => void handleRemoveLoggedTarget(target)}
                            className="inline-flex items-center gap-1 rounded-lg border border-[#FF4D4D]/35 bg-[#FF4D4D]/10 px-2 py-1 text-[9px] font-bold text-[#FF7B7B] disabled:opacity-50"
                          >
                            <Trash2 className="w-3 h-3" /> {removingLogTarget === target ? 'Removing…' : 'Remove from Sending Targets'}
                          </button>
                        ) : (
                          <span className="text-[9px] text-[#5F7890]">Not saved in Sending Targets</span>
                        )}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  </div>);
};
