import { noteAdminWorkspaceVersion } from '../utils/adminWorkspaceVersion';
import { useEffect, useState, useRef, useContext, useCallback, useMemo, type ReactNode } from 'react';
import { apiUrl } from '../utils/api';
import { startupRequest } from '../utils/startupRequest';
import { readStartupCache, verifiedCachedState } from '../utils/startupCache';
import { VerifiedStartupState } from '../utils/verifiedStartupState';
import { editorId } from '../utils/editorSession';

/** Only one Admin document edits; switching control always hydrates saved state. */
export function AdminWorkspaceGate({ children }: { children: ReactNode }) {
  const params = new URLSearchParams(location.search);
  const vip = params.has('vip') || params.has('token') || new URLSearchParams(location.hash.slice(1)).has('token');
  const verified = useContext(VerifiedStartupState);
  const initialLeaseReady = !vip && verified?.editorId === editorId;
  const [ready, setReady] = useState(vip || initialLeaseReady);
  const [error, setError] = useState('');
  const [conflict, setConflict] = useState(false);
  const [busy, setBusy] = useState(false);
  const [recoveredStartup, setRecoveredStartup] = useState<typeof verified>(null);

  const consumeSnapshot = useCallback(() => {
    verified?.consumeSnapshot?.();
    setRecoveredStartup((current) =>
      current && (current.state || current.stateJson)
        ? { ...current, state: null, stateJson: undefined }
        : current
    );
  }, [verified?.consumeSnapshot]);

  const startupValue = useMemo(() => {
    const snapshot = recoveredStartup || verified;
    return snapshot ? { ...snapshot, consumeSnapshot } : null;
  }, [recoveredStartup, verified, consumeSnapshot]);

  const unsavedBackup = useRef('');
  const command = useRef<(action?: string) => Promise<void>>(async () => {});

  useEffect(() => {
    if (vip) return;
    let disposed = false;
    let mounted = initialLeaseReady;
    let inFlight = false;
    let revision = 0;
    let acquireRequested = false;
    let send: (action?: string) => Promise<void>;

    const lose = () => {
      if (disposed) return;
      // CRITICAL FIX: Never call setReady(false) or rotateEditorId() once mounted!
      // Calling setReady(false) unmounts <App /> completely, destroying all active UI state
      // (including open Video Studio modals, Bulk Clear, Scrape, or Trick progress) and
      // making the app appear to crash/refresh back to the starting screen.
      // Instead, silently reclaim the editor lease in the background.
      acquireRequested = true;
      if (!inFlight) {
        acquireRequested = false;
        void send('takeover');
      }
    };

    send = async (action?: string) => {
      if (inFlight || disposed) return;
      inFlight = true;
      const current = revision;
      const hydrate = !mounted;
      setBusy(true);
      try {
        const cached = hydrate ? await readStartupCache('TITAN_NOVA_MASTER') : null;
        if (disposed || current !== revision) return;
        const { response, data } = await startupRequest(async (signal) => {
          const response = await fetch(apiUrl('/api/app/editor_lease'), {
            method: 'POST',
            signal,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              action: action || (mounted ? 'renew' : 'takeover'),
              ...(hydrate ? { hydrate: true, ...(cached ? { knownStateHash: cached.hash } : {}) } : {}),
            }),
          });
          return { response, data: hydrate && response.ok ? await response.json() : null };
        }, 25000);
        if (disposed || current !== revision) return;
        if (response.status === 409) {
          // Silently take over rather than unmounting the workspace
          inFlight = false;
          void send('takeover');
          return;
        }
        if (!response.ok) throw new Error('Connection unavailable');
        if (hydrate) {
          if (disposed || current !== revision) return;
          const state = verifiedCachedState(data, cached);
          if (data?.unchanged && !state) throw new Error('Workspace verification failed');
          noteAdminWorkspaceVersion(response.headers.get('X-Titan-Workspace-Version'));
          setRecoveredStartup({
            profileId: 'admin1',
            token: '',
            editorId,
            state,
            stateJson: data?.unchanged ? cached?.json : undefined,
          });
        }
        mounted = true;
        setReady(true);
        setConflict(false);
        setError('');
      } catch {
        // Never unmount <App /> on transient slow responses during heavy video renders or scrapes.
        if (!disposed && current === revision && !mounted) {
          setReady(true);
          mounted = true;
        }
      } finally {
        inFlight = false;
        if (!disposed) setBusy(false);
        if (acquireRequested && !disposed) {
          acquireRequested = false;
          void send('takeover');
        }
      }
    };

    command.current = send;
    if (!initialLeaseReady) void send('takeover');
    const timer = window.setInterval(() => void send('renew'), 15000);
    const resume = () => {
      if (document.visibilityState !== 'hidden') void send('renew');
    };
    const pageshow = (event: PageTransitionEvent) => {
      if (event.persisted) void send('renew');
    };
    // NOTE: Do NOT attach a `pagehide` release listener! On mobile Chrome/Android WebView,
    // clicking a video download link (<a download>) or opening a file picker (<input type="file">)
    // fires `pagehide`, which previously released the lease and caused the app to reset!
    window.addEventListener('titan-editor-lost', lose);
    window.addEventListener('pageshow', pageshow);
    window.addEventListener('online', resume);
    document.addEventListener('visibilitychange', resume);
    return () => {
      disposed = true;
      clearInterval(timer);
      command.current = async () => {};
      window.removeEventListener('titan-editor-lost', lose);
      window.removeEventListener('pageshow', pageshow);
      window.removeEventListener('online', resume);
      document.removeEventListener('visibilitychange', resume);
    };
  }, [vip, initialLeaseReady]);

  const download = () => {
    let cache = unsavedBackup.current;
    if (!cache) {
      try {
        cache = localStorage.getItem('TITAN_NOVA_MASTER') || '';
      } catch {
        /* unavailable */
      }
    }
    if (!cache) return;
    const url = URL.createObjectURL(new Blob([cache], { type: 'application/json' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = 'titan-local-backup.json';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  if (ready) {
    return (
      <VerifiedStartupState.Provider value={startupValue}>
        {error && (
          <div
            role="status"
            style={{
              position: 'fixed',
              top: 8,
              left: '50%',
              transform: 'translateX(-50%)',
              maxWidth: 'calc(100vw - 24px)',
              width: 'max-content',
              zIndex: 100,
              padding: '8px 12px',
              borderRadius: 12,
              background: '#713f12',
              color: '#fff',
              fontSize: 13,
              pointerEvents: 'none',
            }}
          >
            {error}
          </div>
        )}
        {children}
      </VerifiedStartupState.Provider>
    );
  }

  const button = {
    minHeight: 44,
    padding: '10px 16px',
    borderRadius: 12,
    border: '1px solid #334155',
    fontSize: 14,
    fontWeight: 600,
    cursor: 'pointer',
  };
  return (
    <main
      style={{
        minHeight: '100dvh',
        background: 'radial-gradient(ellipse at top,#20364f,#0b1220 65%)',
        color: '#e2e8f0',
        padding: 20,
        display: 'grid',
        placeItems: 'center',
      }}
    >
      <section
        style={{
          width: '100%',
          maxWidth: 420,
          padding: 24,
          border: '1px solid #334155',
          borderRadius: 20,
          background: '#111e30',
          boxShadow: '0 16px 60px #0005',
        }}
      >
        <p style={{ fontSize: 12, letterSpacing: 2, color: '#38bdf8', marginBottom: 16 }}>TITAN NOVA</p>
        <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 12 }}>
          {conflict ? 'One Admin · one active page' : 'Connecting workspace'}
        </h2>
        <p role="status" style={{ fontSize: 14, lineHeight: 1.6, marginBottom: 20 }}>
          {error || 'Opening your saved workspace…'}
        </p>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
          <button
            style={{ ...button, background: '#38bdf8', color: '#082f49' }}
            disabled={busy}
            onClick={() => void command.current('takeover')}
          >
            {busy ? 'Connecting…' : conflict ? 'Use this device' : 'Retry now'}
          </button>
          <button style={{ ...button, background: '#17263b', color: '#e2e8f0' }} onClick={download}>
            Local backup
          </button>
        </div>
      </section>
    </main>
  );
}
