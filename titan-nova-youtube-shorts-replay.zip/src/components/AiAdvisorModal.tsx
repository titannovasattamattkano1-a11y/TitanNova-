import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, Send, Bot, User, X, RefreshCw, Zap, ShieldAlert, CheckCircle2, ArrowRight } from 'lucide-react';
import type { AppState, DayMarketRecord, MarketScope } from '../types';
import { getEffectiveMarkets } from '../data/markets';
import {
  getStoredLearningState,
  parseTextExamplesAndTarget,
  discoverRuleAndPredictFromExamples,
  extractMarketExamplesFromHistory,
} from '../utils/selfLearningEngine';

interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
  recommendations?: Array<{
    marketName: string;
    digits: string;
    strategy: string;
  }>;
}

interface AiAdvisorModalProps {
  isOpen: boolean;
  onClose: () => void;
  appState: AppState;
  activeProfileId: string;
  currentDate: string;
  marketScope: MarketScope;
  onApplyDigitsToCard: (marketName: string, digits: string, strategy: string) => void;
  onShowToast: (title: string, desc: string, type?: 'success' | 'info' | 'warning' | 'danger') => void;
}

const parseRecommendations = (text: string) => {
  const recs: Array<{ marketName: string; digits: string; strategy: string }> = [];
  const regex = />>>\s*RECOMMENDATION:\s*Market:\s*["']([^"']+)["']\s*\|\s*Digits:\s*["']([^"']+)["']\s*(?:\|\s*Strategy:\s*["']([^"']+)["'])?\s*<<</gi;
  let match;
  while ((match = regex.exec(text)) !== null) {
    recs.push({
      marketName: match[1].trim(),
      digits: match[2].trim(),
      strategy: (match[3] || 'Gemini 3.8 AI Recommendation').trim(),
    });
  }
  return recs;
};

export const AiAdvisorModal: React.FC<AiAdvisorModalProps> = ({
  isOpen,
  onClose,
  appState,
  activeProfileId,
  currentDate,
  marketScope,
  onApplyDigitsToCard,
  onShowToast,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'model',
      text: `Namaste! Mai aapka **Titan Nova AI Assistant & Strategist** hoon.\n\nMai aapko **Examples se Rule nikal kar Naye Input pe Predict** karne, real-time chart analysis, balanced 4-Ank sets, aur double-loss recovery me help kar sakta hoon.\n\nAap direct examples bhi likh sakte hain (jaise: \`14 -> 5, 26 -> 8, 39 -> 2, naya input 58\`).`,
      timestamp: Date.now(),
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedMarket, setSelectedMarket] = useState<string>('ALL');
  const chatEndRef = useRef<HTMLDivElement>(null);

  const profile = appState.profiles[activeProfileId] || appState.profiles.admin1;
  const markets = profile?.config ? getEffectiveMarkets(profile.config) : [];
  const day = profile?.dayRecords?.[currentDate];

  useEffect(() => {
    if (isOpen) {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  if (!isOpen) return null;

  // Build live context summary for Gemini & Local Engine
  const buildCurrentContext = (promptText = '') => {
    const weights = getStoredLearningState();
    const marketSummaries: any[] = [];

    markets.forEach((m, idx) => {
      const card = day?.data?.[idx];
      if (!card) return;
      const cardAny = card as any;
      const resCandidate = card.manualResult || card.scrapeResultDigit || cardAny.backtestResult?.actual?.open || cardAny.backtestResult?.actual || (typeof cardAny.actualResult === 'string' ? cardAny.actualResult : undefined) || (card.r && card.r !== cardAny.sentRate && /^\d$/.test(String(card.r)) ? card.r : undefined);

      marketSummaries.push({
        market: m.n,
        status: card.s || 'PENDING',
        currentDigits: card.d || 'None',
        actualResult: resCandidate || (card.s === 'PASS' || card.s === 'FAIL' ? (card.manualResult || 'Declared') : 'Pending'),
        isShield: card.selfLearning?.shieldMode || false,
        isConservativeFallback: card.selfLearning?.isConservativeFallback || false,
        confidence: card.selfLearning?.confidence || null,
        failStreak: weights.marketFails?.[m.n] || 0,
      });
    });

    // Check if user provided examples in prompt or asked for example-based rule prediction
    const parsedEx = parseTextExamplesAndTarget(promptText);
    let discoveredRule = null;

    if (parsedEx.examples.length >= 2) {
      const targetInput = parsedEx.newInput || parsedEx.examples[parsedEx.examples.length - 1].input;
      discoveredRule = discoverRuleAndPredictFromExamples(parsedEx.examples, targetInput);
    } else if (/example|rule|naya\s+input|predict/i.test(promptText)) {
      const targetMkt = selectedMarket !== 'ALL' ? selectedMarket : (markets[0]?.n || 'KALYAN OPEN');
      const histEx = extractMarketExamplesFromHistory(appState, activeProfileId, targetMkt);
      discoveredRule = discoverRuleAndPredictFromExamples(
        histEx.examples,
        parsedEx.newInput || histEx.suggestedNewInput
      );
    }

    return {
      currentDate,
      scope: marketScope,
      totalMarketsCount: markets.length,
      selectedMarketFocus: selectedMarket,
      selfLearningWinRate: weights.winRate,
      digitWeights: weights.digitWeights,
      activeShieldCount: marketSummaries.filter(m => m.isShield).length,
      conservativeFallbackCount: marketSummaries.filter(m => m.isConservativeFallback).length,
      discoveredRule,
      marketCards: selectedMarket === 'ALL'
        ? marketSummaries // Send all active markets so queries like Sridevi Night are never truncated
        : marketSummaries.filter(m => m.market.toUpperCase().includes(selectedMarket.toUpperCase())),
    };
  };

  const handleSendMessage = async (textToSend?: string) => {
    const messageText = (textToSend || inputText).trim();
    if (!messageText || isLoading) return;

    const userMsg: Message = {
      id: `user_${Date.now()}`,
      role: 'user',
      text: messageText,
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) setInputText('');
    setIsLoading(true);

    try {
      const context = buildCurrentContext(messageText);
      const history = messages.slice(-5).map(m => ({
        role: m.role,
        text: m.text,
      }));

      const res = await fetch('/api/ai/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: messageText,
          context,
          history,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.status !== 'success') {
        throw new Error(data.message || 'AI request failed');
      }

      const recs = parseRecommendations(data.reply);
      const aiMsg: Message = {
        id: `ai_${Date.now()}`,
        role: 'model',
        text: data.reply,
        timestamp: Date.now(),
        recommendations: recs.length > 0 ? recs : undefined,
      };

      setMessages(prev => [...prev, aiMsg]);
    } catch (err: any) {
      console.error('[AiAdvisor] Error:', err);
      const errorMsg: Message = {
        id: `err_${Date.now()}`,
        role: 'model',
        text: `⚠️ **AI Response Error**: ${err.message || 'Server se connect nahi ho paya'}.\n\nAgar API Key configured nahi hai, kripya **Settings > Secrets** me \`GEMINI_API_KEY\` verify karein.`,
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, errorMsg]);
      onShowToast('AI Error', err.message || 'AI response failed', 'danger');
    } finally {
      setIsLoading(false);
    }
  };

  const handleApplyRec = (rec: { marketName: string; digits: string; strategy: string }) => {
    onApplyDigitsToCard(rec.marketName, rec.digits, rec.strategy);
    onShowToast('✅ Applied to Card', `${rec.marketName}: ${rec.digits} set!`, 'success');
  };

  const QUICK_PROMPTS = [
    { label: "🧬 Examples → Rule & Predict", prompt: "Examples: 14 -> 5, 26 -> 8, 39 -> 2, 47 -> 1. In examples se rule nikalo aur naye input 58 pe predict karo." },
    { label: "🔍 Analyze Today's Board", prompt: "Aaj ke sabhi markets ka review karke batao kaun se cards winning flow me hain aur kis me risk hai." },
    { label: "🛡️ Check Drawdown & Shield", prompt: "Current open-close markets me double-loss ya drawdown risk check karo aur safety steps batao." },
    { label: "👑 4-Ank Recommendation", prompt: selectedMarket !== 'ALL' ? `${selectedMarket} ke liye balanced Satta Tetrad 4-Ank recommend karo with mirror cut pairs.` : "Top high-probability markets ke liye balanced 4-Ank sets recommend karo." },
    { label: "📊 Explain AI Weights", prompt: "Aaj ke Date Root, Weekday Lord aur Self-learning weights ka summary batao." },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-2 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl rounded-2xl bg-[#0B1120] border border-amber-500/30 shadow-2xl shadow-amber-500/10 overflow-hidden flex flex-col h-[88vh] max-h-[850px]">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-amber-500/20 bg-gradient-to-r from-[#0F172A] via-[#1E1B4B] to-[#0F172A] px-4 py-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 via-orange-500 to-amber-600 text-slate-950 font-black shadow-lg shadow-amber-500/25">
              <Sparkles className="h-6 w-6 animate-spin text-slate-950" style={{ animationDuration: '8s' }} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-black text-white tracking-wide flex items-center gap-1.5">
                  Titan AI Assistant & Guru
                </h2>
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[9px] font-bold text-emerald-400 border border-emerald-500/30">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
                  Gemini 3.8 Flash
                </span>
              </div>
              <p className="text-[10px] text-slate-400">
                Real-time Matka intelligence, OTC shields, and balanced 4-Ank tetrad guidance
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedMarket}
              onChange={e => setSelectedMarket(e.target.value)}
              className="hidden sm:block text-[11px] rounded-lg bg-slate-900 border border-amber-500/30 text-amber-200 px-2 py-1 max-w-[170px] truncate"
              title="Filter context to a specific market"
            >
              <option value="ALL">🌐 All Markets</option>
              {markets.map(m => (
                <option key={m.n} value={m.n}>{m.n}</option>
              ))}
            </select>
            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-4 py-2 border-b border-slate-800/80 bg-slate-950/60 flex items-center gap-1.5 overflow-x-auto no-scrollbar shrink-0">
          <span className="text-[10px] uppercase font-bold text-amber-400/80 flex items-center gap-1 shrink-0 mr-1">
            <Zap className="h-3 w-3" /> Quick:
          </span>
          {QUICK_PROMPTS.map((qp, idx) => (
            <button
              key={idx}
              type="button"
              disabled={isLoading}
              onClick={() => handleSendMessage(qp.prompt)}
              className="shrink-0 text-[10px] font-bold px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-amber-950/40 border border-slate-700 hover:border-amber-500/40 text-slate-300 hover:text-amber-200 transition-all disabled:opacity-50"
            >
              {qp.label}
            </button>
          ))}
        </div>

        {/* Chat Messages Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-950/40">
          {messages.map(msg => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.role === 'model' && (
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 text-slate-950 shadow-md">
                  <Bot className="h-4 w-4" />
                </div>
              )}

              <div className={`max-w-[85%] rounded-2xl p-3.5 text-xs ${
                msg.role === 'user'
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-br-none shadow-md'
                  : 'bg-slate-900/90 border border-slate-800 text-slate-200 rounded-bl-none shadow-xl'
              }`}>
                {/* Formatted Text rendering */}
                <div className="space-y-1.5 whitespace-pre-wrap leading-relaxed">
                  {msg.text.split('\n\n').map((paragraph, pIdx) => {
                    // Check if it's recommendation block
                    if (paragraph.includes('>>> RECOMMENDATION:')) {
                      return null; // Rendered below as interactive widget
                    }
                    return (
                      <p key={pIdx} className="text-slate-200">
                        {paragraph}
                      </p>
                    );
                  })}
                </div>

                {/* 1-Click Interactive Recommendations Widget */}
                {msg.recommendations && msg.recommendations.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-2">
                    <span className="text-[10px] uppercase font-black tracking-wider text-amber-400 block flex items-center gap-1">
                      <Sparkles className="h-3 w-3" /> Actionable Recommendations:
                    </span>
                    {msg.recommendations.map((rec, rIdx) => (
                      <div
                        key={rIdx}
                        className="flex flex-col sm:flex-row sm:items-center justify-between p-2.5 rounded-xl bg-amber-950/20 border border-amber-500/30 gap-2"
                      >
                        <div>
                          <div className="font-bold text-amber-200 text-xs">{rec.marketName}</div>
                          <div className="text-[10px] text-slate-400">{rec.strategy}</div>
                          <div className="mt-1 flex items-center gap-1">
                            {rec.digits.split(/[,|\s]+/).map((d, dIdx) => (
                              <span
                                key={dIdx}
                                className="flex h-5 w-5 items-center justify-center rounded bg-amber-900/40 border border-amber-400/40 text-[11px] font-black text-amber-200"
                              >
                                {d}
                              </span>
                            ))}
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleApplyRec(rec)}
                          className="px-3 py-1.5 rounded-lg text-[10px] font-black uppercase bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 shadow-md active:scale-95 transition-all flex items-center gap-1 shrink-0"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          Apply to Card
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <div className={`text-[9px] mt-1.5 text-right ${msg.role === 'user' ? 'text-blue-200' : 'text-slate-500'}`}>
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>

              {msg.role === 'user' && (
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-blue-600 text-white shadow-md">
                  <User className="h-4 w-4" />
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-3 justify-start items-center">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 text-slate-950 shadow-md animate-pulse">
                <Bot className="h-4 w-4" />
              </div>
              <div className="rounded-2xl p-3 bg-slate-900 border border-slate-800 text-amber-300 text-xs flex items-center gap-2">
                <RefreshCw className="h-3.5 w-3.5 animate-spin text-amber-400" />
                <span>AI Guru thinking and analyzing portfolio data...</span>
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Bottom Input Area */}
        <div className="border-t border-slate-800 bg-slate-950 p-3 shrink-0">
          <form
            onSubmit={e => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputText}
              onChange={e => setInputText(e.target.value)}
              placeholder={selectedMarket === 'ALL' ? "Apna sawal puchein ya market analysis maangein..." : `${selectedMarket} ke baare me puchein...`}
              disabled={isLoading}
              className="flex-1 rounded-xl bg-slate-900 border border-slate-700 focus:border-amber-500 px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-500 transition-all disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={!inputText.trim() || isLoading}
              className="flex items-center justify-center h-10 w-10 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black shadow-lg shadow-amber-500/20 disabled:opacity-40 disabled:cursor-not-allowed active:scale-95 transition-all shrink-0"
              title="Send to AI Assistant"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
          <div className="mt-1 flex items-center justify-between text-[10px] text-slate-500 px-1">
            <span>Powered by Gemini 3.8 Flash</span>
            <span>Mathematical analysis only · Follow risk discipline</span>
          </div>
        </div>
      </div>
    </div>
  );
};
