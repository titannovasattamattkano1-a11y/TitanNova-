import {useEffect,useRef,useState} from 'react';
import {X,Download,Share2,ChevronLeft,ChevronRight} from 'lucide-react';
import {generateDailyAuditImages,auditGameLabel,type DailyAuditImageData,type AuditImagePage} from '../utils/dailyAuditImage';
import './DailyAuditImageModal.css';

export function DailyAuditImageModal({data,onClose}:{data:DailyAuditImageData;onClose:()=>void}){
  const [pages,setPages]=useState<AuditImagePage[]>([]),[index,setIndex]=useState(0),[error,setError]=useState(''),[notice,setNotice]=useState(''),[sharing,setSharing]=useState(false);
  const closeRef=useRef<HTMLButtonElement>(null);
  useEffect(()=>{
    let cancelled=false;let generated:AuditImagePage[]=[];const controller=new AbortController();
    setPages([]);setIndex(0);setError('');setNotice('');
    void generateDailyAuditImages(data,controller.signal).then(result=>{generated=result;if(cancelled)result.forEach(p=>URL.revokeObjectURL(p.url));else setPages(result);}).catch(e=>{if(!cancelled)setError(e instanceof Error?e.message:'Could not generate report image.');});
    return()=>{cancelled=true;controller.abort();generated.forEach(p=>URL.revokeObjectURL(p.url));};
  },[data]);
  useEffect(()=>{
    const previous=document.activeElement as HTMLElement|null,overflow=document.body.style.overflow;
    document.body.style.overflow='hidden';closeRef.current?.focus();
    return()=>{document.body.style.overflow=overflow;previous?.focus();};
  },[]);
  useEffect(()=>{setNotice('');setError('');},[index]);
  const current=pages[index];
  const download=()=>{
    if(!current)return;
    const a=document.createElement('a');a.href=current.url;a.download=current.filename;document.body.append(a);a.click();a.remove();setNotice('PNG downloaded. Attach it in WhatsApp if file sharing is unavailable.');
  };
  const share=async()=>{
    if(!current||sharing)return;setError('');setNotice('');
    try{
      const file=new File([current.blob],current.filename,{type:'image/png'});
      if(!navigator.share||!navigator.canShare?.({files:[file]})){download();setNotice('This browser cannot share image files directly. PNG downloaded; attach it in WhatsApp.');return;}
      // Invoke from the user's tap so Android retains its required user activation.
      setSharing(true);await navigator.share({files:[file]});
      setNotice('Share sheet completed.');
    }catch(e){if(!(e instanceof Error&&e.name==='AbortError'))setError('Image sharing failed. Use Download PNG, then attach it in WhatsApp.');}
    finally{setSharing(false);}
  };
  return <div className="audit-image-overlay" onKeyDown={e=>{
    if(e.key==='Escape'&&!sharing)onClose();
    if(e.key==='Tab'){
      const items=[...e.currentTarget.querySelectorAll<HTMLElement>('button:not(:disabled)')];
      if(e.shiftKey&&document.activeElement===items[0]){e.preventDefault();items.at(-1)?.focus();}
      else if(!e.shiftKey&&document.activeElement===items.at(-1)){e.preventDefault();items[0]?.focus();}
    }
  }}>
    <section role="dialog" aria-modal="true" aria-labelledby="audit-image-title" className="audit-image-dialog">
      <header><div><h2 id="audit-image-title">{auditGameLabel(data.game)} {data.period === 'custom' ? 'custom' : data.period === 'month' ? 'monthly' : data.period === 'week' ? 'weekly' : 'daily'} audit image</h2><p>{data.startDate && data.startDate !== data.date ? `${data.startDate} to ${data.date}` : data.date} · {data.profileName}</p></div><button ref={closeRef} type="button" aria-label="Close audit image" onClick={onClose} disabled={sharing}><X size={20}/></button></header>
      <div className="audit-image-preview" aria-busy={!pages.length&&!error}>
        {current?<img src={current.url} alt={`${auditGameLabel(data.game)} ${data.period || 'day'} audit ${data.date}, page ${index+1} of ${pages.length}`}/>:<p role="status">{error?'Preview unavailable':'Preparing report image…'}</p>}
      </div>
      <footer>
        {pages.length>1&&<div className="audit-image-pagination"><button type="button" aria-label="Previous audit image page" disabled={!index||sharing} onClick={()=>setIndex(i=>i-1)}><ChevronLeft size={18}/></button><span>Page {index+1} / {pages.length} · Download/share each page</span><button type="button" aria-label="Next audit image page" disabled={index===pages.length-1||sharing} onClick={()=>setIndex(i=>i+1)}><ChevronRight size={18}/></button></div>}
        <div className="audit-image-actions"><button type="button" onClick={download} disabled={!current||sharing}><Download size={17}/>Download PNG</button><button type="button" onClick={()=>void share()} disabled={!current||sharing} aria-busy={sharing}><Share2 size={17}/>{sharing?'Sharing…':'WhatsApp Share'}</button></div>
        <p className="audit-image-help">Choose WhatsApp in the share sheet. Digits and rates remain in the detailed text report.</p>
        {error&&<p className="audit-image-error" role="alert">{error}</p>}{notice&&<p role="status" className="audit-image-help">{notice}</p>}
      </footer>
    </section>
  </div>;
}
