import { noteAdminWorkspaceVersion } from '../utils/adminWorkspaceVersion';
import { useEffect, useState, useCallback, type ReactNode } from 'react';
import { ArrowRight, Eye, EyeOff, ShieldCheck, LockKeyhole, Fingerprint, LoaderCircle, KeyRound, CircleAlert, Sparkles } from 'lucide-react';
import './AccessGate.css';
import { VerifiedStartupState } from '../utils/verifiedStartupState';
import type { AppState } from '../types';
import { apiUrl } from '../utils/api';
import { editorId } from '../utils/editorSession';
import { apiDeadlineSignal } from '../utils/apiDeadline';
import { startupRequest } from '../utils/startupRequest';
import { readStartupCache, verifiedCachedState } from '../utils/startupCache';

const params = new URLSearchParams(window.location.search);
const fragmentParams = new URLSearchParams(window.location.hash.slice(1));
const vipMode = params.has('vip') || params.has('token') || fragmentParams.has('token');
const vipId = params.get('vip') || '';
// New invitation links keep credentials out of server-visible navigation URLs.
// The old ?token= form is accepted so previously shared/installed apps still work.
const vipToken = fragmentParams.get('token') || params.get('token') || '';
const keyName = 'TITAN_ADMIN_SESSION_KEY';
let adminKey = '';
try { adminKey = sessionStorage.getItem(keyName) || ''; } catch { /* Login can still work for this page. */ }
const originalFetch = window.fetch.bind(window);
// Attach credentials only to this app's API, including requests from child views.
const customFetch: typeof window.fetch = (input, init) => {
  const url = new URL(input instanceof Request ? input.url : String(input), window.location.href);
  const api = new URL(apiUrl('/api/'), window.location.href);
  if (url.origin === api.origin && url.pathname.startsWith(api.pathname)) {
    const headers = new Headers(init?.headers || (input instanceof Request ? input.headers : undefined));
    if (vipMode) {
      headers.delete('X-Titan-Admin-Key');
      if (vipToken) headers.set('X-Titan-Profile-Token', vipToken);
    } else {
      if (adminKey) headers.set('X-Titan-Admin-Key', adminKey);
      headers.set('X-Titan-Editor-Id', editorId);
    }
    return originalFetch(input, { ...init, headers, signal: apiDeadlineSignal(init?.signal || (input instanceof Request ? input.signal : undefined),
      url.pathname.includes('activity_video') ? 300000 : url.pathname.includes('scrape') ? 120000
      : ['/bot/ledger_set_card','/bot/ledger_clear_cards','/app/restore_backtest'].some(route=>url.pathname.endsWith(route)) ? 60000
      : url.pathname.endsWith('/app/state') && (init?.method || (input instanceof Request ? input.method : 'GET')).toUpperCase() === 'POST' ? 60000
      : 30000) }).then(response => {
      // A workspace conflict may contain the entire archive. Never clone and
      // parse it here just to detect the small editor-lease error.
      if (!vipMode && response.status === 409 && !url.pathname.endsWith('/editor_lease')) {
        if (response.headers.get('X-Titan-Error-Code') === 'EDITOR_LEASE_REQUIRED' && headers.get('X-Titan-Editor-Id') === editorId) window.dispatchEvent(new Event('titan-editor-lost'));
      }
      return response;
    });
  }
  return originalFetch(input, init);
};

try {
  Object.defineProperty(window, 'fetch', {
    value: customFetch,
    writable: true,
    configurable: true,
    enumerable: true,
  });
} catch {
  try {
    Object.defineProperty(globalThis, 'fetch', {
      value: customFetch,
      writable: true,
      configurable: true,
      enumerable: true,
    });
  } catch {
    try {
      (window as unknown as { fetch: typeof window.fetch }).fetch = customFetch;
    } catch {
      // In environments where fetch cannot be reassigned on window
    }
  }
}

export function AccessGate({ children }: { children: ReactNode }) {
  const [allowed, setAllowed] = useState(false);
  const [verifiedState, setVerifiedState] = useState<AppState | null>(null);
  const [verifiedJson, setVerifiedJson] = useState<string | undefined>();
  const [verifiedEditorId, setVerifiedEditorId] = useState('');
  const [checking, setChecking] = useState(true);
  const [key, setKey] = useState('');
  const [error, setError] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const consumeSnapshot=useCallback(()=>{setVerifiedState(null);setVerifiedJson(undefined);},[]);
  const verify = async () => {
    setChecking(true);
    setError('');
    try {
      if (vipMode && (!vipId || vipId === 'admin1' || !vipToken)) throw new Error('VIP link invalid hai. Admin se apna VIP link lein.');
      const cached = await readStartupCache(vipMode ? `TITAN_NOVA_VIP_${vipId}` : 'TITAN_NOVA_MASTER');
      const route = vipMode ? `/api/app/state?profileId=${encodeURIComponent(vipId)}${cached ? `&knownStateHash=${cached.hash}` : ''}` : '/api/app/editor_lease';
      const { response, data } = await startupRequest(async signal => {
        const response = await customFetch(apiUrl(route), vipMode ? { cache: 'no-store', signal } : {
          method: 'POST', cache: 'no-store', signal, headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'acquire', hydrate: true, ...(cached ? {knownStateHash:cached.hash} : {}) }),
        });
        if (!vipMode && response.status === 401) {
          adminKey = '';
          try { sessionStorage.removeItem(keyName); } catch { /* Storage may be restricted. */ }
        }
        const data = await response.json();
        return { response, data };
      });
      const leaseConflict = !vipMode && response.status === 409 && data?.code === 'EDITOR_LEASE_REQUIRED';
      const state = response.ok ? verifiedCachedState(data, cached) : null;
      if ((!response.ok && !leaseConflict) || (vipMode && !state?.profiles?.[vipId]) || (data?.unchanged && !state)) {
        throw new Error(vipMode ? 'VIP link invalid ya delete ho chuka hai. Admin se contact karein.' : response.status === 401 ? 'Access token sahi nahi hai. Check karke dobara try karein.' : 'Server se access verify nahi hua. Dobara try karein.');
      }
      if(!vipMode&&response.ok)noteAdminWorkspaceVersion(response.headers.get('X-Titan-Workspace-Version'));
      setVerifiedState(state);
      setVerifiedJson(state && data?.unchanged ? cached?.json : undefined);
      setVerifiedEditorId(!vipMode && response.ok ? editorId : '');
      setAllowed(true);
    } catch (err) {
      setAllowed(false);
      setError(err instanceof Error ? err.message : 'Access verify nahi hua.');

    } finally { setChecking(false); }
  };
  useEffect(() => {
    if (!vipMode && !adminKey) { setChecking(false); return; }
    void verify();
  }, []);
  if (allowed) return <VerifiedStartupState.Provider value={{ profileId: vipMode ? vipId : 'admin1', token: vipToken, state: verifiedState, stateJson: verifiedJson, editorId: verifiedEditorId || undefined,consumeSnapshot }}>{children}</VerifiedStartupState.Provider>;
  return (
    <main className="titan-access">
      <div className="titan-access-glow" aria-hidden="true" />
      <div className="titan-access-shell">
        <header className="titan-access-header">
          <a className="titan-access-brand" href={vipMode ? window.location.href : './'} aria-label="Titan Nova">
            <span className="titan-brand-mark"><Sparkles size={21} strokeWidth={1.6} /></span>
            <span>TITAN<span className="titan-brand-nova">NOVA</span></span>
          </a>
          <span className="titan-private-badge"><span />{vipMode ? 'VIP PORTAL' : 'PRIVATE WORKSPACE'}</span>
        </header>

        <section className="titan-access-layout">
          <div className="titan-access-story">
            <div className="titan-access-eyebrow"><span /> TITAN NOVA CONTROL CENTER</div>
            <h1>Your business.<br /> Your control.<br /><span>One workspace.</span></h1>
            <p className="titan-access-description">A dedicated space for your markets, members and daily operations.</p>
            <div className="titan-access-emblem" aria-hidden="true">
              <div className="titan-emblem-orbit titan-emblem-orbit-outer" />
              <div className="titan-emblem-orbit titan-emblem-orbit-inner" />
              <div className="titan-emblem-core"><ShieldCheck size={56} strokeWidth={1.2} /></div>
              <span className="titan-emblem-dot" />
              <span className="titan-emblem-caption">DESIGNED FOR YOUR WORKSPACE</span>
            </div>
            <div className="titan-access-features">
              <div><ShieldCheck size={18} /><span>Protected access</span></div>
              <div><Fingerprint size={18} /><span>Personal workspace</span></div>
            </div>
          </div>

          <div className="titan-access-card">
            <div className="titan-card-topline" />
            <div className="titan-login-icon"><LockKeyhole size={27} strokeWidth={1.5} /></div>
            <div className="titan-access-eyebrow titan-card-eyebrow">{vipMode ? 'MEMBER ACCESS' : 'ADMINISTRATOR ACCESS'}</div>
            <h2>{vipMode ? 'Your VIP workspace' : 'Welcome back.'}</h2>
            <p className="titan-login-description">{vipMode ? 'Your personal link opens only your own VIP view.' : 'Enter your admin access token to open your workspace.'}</p>

            {vipMode ? <div className="titan-vip-status">
              {checking ? <p className="titan-checking" role="status"><LoaderCircle className="titan-spin" size={18} /> Verifying your VIP link…</p> : <>
                <div className="titan-access-error" role="alert"><CircleAlert size={18} /><span>{error}</span></div>
                <button className="titan-login-button" onClick={() => void verify()}>Verify again <ArrowRight size={18} /></button>
              </>}
            </div> : <form className="titan-login-form" onSubmit={event => {
              event.preventDefault();
              if (checking || !key.trim()) return;
              setSubmitted(true);
              adminKey = key.trim();
              try { sessionStorage.setItem(keyName, adminKey); } catch { /* Session only. */ }
              void verify();
            }}>
              <label htmlFor="titan-admin-token">Admin access token</label>
              <div className={`titan-token-field${submitted && error ? ' titan-token-invalid' : ''}`}>
                <KeyRound size={19} className="titan-token-icon" />
                <input id="titan-admin-token" type={showKey ? 'text' : 'password'} value={key}
                  onChange={event => { setKey(event.target.value); setError(''); }}
                  placeholder="Enter your private token" autoComplete="current-password"
                  autoCapitalize="none" spellCheck={false} required disabled={checking}
                  aria-invalid={submitted && Boolean(error)} aria-describedby="titan-token-help" />
                <button className="titan-token-reveal" type="button" onClick={() => setShowKey(value => !value)}
                  aria-label={showKey ? 'Hide access token' : 'Show access token'} aria-pressed={showKey}>
                  {showKey ? <EyeOff size={19} /> : <Eye size={19} />}
                </button>
              </div>
              <p id="titan-token-help" className="titan-token-help"><LockKeyhole size={12} /> Your token is private. Keep it with you.</p>
              {error && (submitted || error !== 'Access token sahi nahi hai. Check karke dobara try karein.') &&
                <div className="titan-access-error" role="alert"><CircleAlert size={17} /><span>{error}</span></div>}
              <button className="titan-login-button" type="submit" disabled={checking || !key.trim()}>
                {checking ? <><LoaderCircle className="titan-spin" size={18} /> Verifying access…</> : <>Open admin workspace <ArrowRight size={18} /></>}
              </button>
              {error && adminKey && <button className="titan-login-button" type="button" disabled={checking}
                onClick={() => void verify()}>Retry saved login <ArrowRight size={18} /></button>}
            </form>}

            <div className="titan-login-divider" />
            <div className="titan-login-note"><ShieldCheck size={19} /><p>{vipMode ? 'Personal access only' : 'Reserved for administrators'}<span>{vipMode ? 'Admin tools and other member profiles remain private.' : 'VIP members use their personal invitation link.'}</span></p></div>
          </div>
        </section>
        <footer className="titan-access-footer"><span>TITAN NOVA <span className="titan-footer-dot">·</span> BUSINESS WORKSPACE</span><span><LockKeyhole size={12} /> {vipMode ? 'Personal member access' : 'Authorized access only'}</span></footer>
      </div>
    </main>
  );
}
