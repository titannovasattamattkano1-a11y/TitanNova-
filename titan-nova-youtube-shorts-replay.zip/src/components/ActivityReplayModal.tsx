import React, { useEffect, useRef, useState } from 'react';
import { X, Download, Share2, Send, Film, RefreshCw, Subtitles, Volume2, VolumeX, Sparkles, Sliders, Mic, Play, Copy, Check } from 'lucide-react';
import { apiUrl } from '../utils/api';

interface ActivityEventItem {
  id: string;
  cardSlot?: number;
  stepPhase?: 1 | 2 | 3;
  ts: number;
  timeIST: string;
  date: string;
  profileId: string;
  market: string;
  type: string;
  action: string;
  digits?: string;
  rate?: string;
  baseRate?: string;
  prevRate?: string;
  rateDiff?: number;
  prevStatus?: string;
  nextMarket?: string;
  nextRate?: string;
  invest?: number;
  status?: string;
  actual?: string;
  pl?: number;
  netDayPl?: number;
  trick?: string;
  sourceMode?: string;
  isSmartStakeOn?: boolean;
  strongDigits?: string;
  supportDigits?: string;
  strongRate?: number;
  supportRate?: number;
  isProfitCarryOn?: boolean;
  prevLoss?: number;
  carriedProfit?: number;
  baseTargetProfit?: number;
  isCloseZeroOn?: boolean;
  isCloseZeroSkip?: boolean;
  isFourWaveOn?: boolean;
  waveId?: string;
  subtitle: string;
}

interface VoiceCueItem {
  startSec: number;
  endSec: number;
  text: string;
}

interface ActivityReplayModalProps {
  isOpen: boolean;
  onClose: () => void;
  date: string;
  profileId: string;
  profileName: string;
  isMaster: boolean;
  onShowToast?: (title: string, desc: string, type?: 'success' | 'info' | 'warning' | 'danger') => void;
}

function drawRoundedRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number, fill?: string, stroke?: string, lw = 2) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw; ctx.stroke(); }
}

function wrapCanvasText(ctx: CanvasRenderingContext2D, text: string, maxW: number, maxLines = 3): string[] {
  const words = String(text || '').split(/\s+/).filter(Boolean);
  if (!words.length) return [''];
  const lines: string[] = [];
  let cur = words[0];
  for (let i = 1; i < words.length; i++) {
    const next = `${cur} ${words[i]}`;
    if (ctx.measureText(next).width <= maxW) {
      cur = next;
    } else {
      lines.push(cur);
      cur = words[i];
      if (lines.length >= maxLines - 1) {
        let rest = [cur, ...words.slice(i + 1)].join(' ');
        while (ctx.measureText(rest).width > maxW && rest.length > 4) rest = `${rest.slice(0, -4)}...`;
        lines.push(rest);
        return lines;
      }
    }
  }
  lines.push(cur);
  return lines;
}

async function base64ToBlobFast(b64: string, mimeType: string): Promise<Blob> {
  try {
    const res = await fetch(`data:${mimeType};base64,${b64}`);
    return await res.blob();
  } catch {
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new Blob([bytes], { type: mimeType });
  }
}

function easeOutBack3D(t: number): number {
  const c = Math.max(0, Math.min(1, t));
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(c - 1, 3) + c1 * Math.pow(c - 1, 2);
}

async function renderFallbackCanvasVideo(
  events: ActivityEventItem[],
  voiceCues: VoiceCueItem[],
  showSubtitles: boolean,
  profileName: string,
  style: "cyber_neon" | "gold_royal" | "emerald_matrix",
  period: "day" | "week",
  dateRangeLabel: string,
  customTitle?: string,
  pendingMarkets?: string[]
): Promise<{ blob: Blob; mimeType: string; ext: string }> {
  const canvas = document.createElement("canvas");
  canvas.width = 720;
  canvas.height = 1280;
  const ctx = canvas.getContext("2d")!;
  const fps = 15;
  const stream = canvas.captureStream(fps);
  const mimeType = MediaRecorder.isTypeSupported("video/mp4")
    ? "video/mp4"
    : MediaRecorder.isTypeSupported("video/webm;codecs=vp9")
    ? "video/webm;codecs=vp9"
    : "video/webm";
  const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 1_400_000 });
  const chunks: BlobPart[] = [];
  recorder.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };

  const done = new Promise<Blob>((resolve) => {
    recorder.onstop = () => resolve(new Blob(chunks, { type: mimeType }));
  });

  const theme = style === "gold_royal"
    ? { bgTop: "#161108", bgBot: "#0B0804", primary: "#FBBF24", hudBg: "#1F180C" }
    : style === "emerald_matrix"
    ? { bgTop: "#061912", bgBot: "#030C08", primary: "#00E676", hudBg: "#0B241B" }
    : { bgTop: "#091322", bgBot: "#050A12", primary: "#20DCE9", hudBg: "#101D2E" };

  recorder.start();
  const capped = events.slice(0, 75);
  const hasPending = Array.isArray(pendingMarkets) && pendingMarkets.length > 0;
  const introFrames = 54;
  const framesPerStep = 28;
  const pendingFrames = hasPending ? 48 : 0;
  const outroFrames = 42;
  const totalFrames = introFrames + capped.length * framesPerStep + pendingFrames + outroFrames;
  const brandStr = (customTitle || "TITAN NOVA").toUpperCase().slice(0, 14);

  const draw3DBg = (frameNum: number) => {
    const grad = ctx.createLinearGradient(0, 0, 0, 1280);
    grad.addColorStop(0, theme.bgTop);
    grad.addColorStop(1, theme.bgBot);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 720, 1280);

    // 3D Expanding Cyber Tunnel Rings + Radial Starfield
    ctx.strokeStyle = "rgba(32, 220, 233, 0.16)";
    ctx.lineWidth = 2;
    for (let r = 0; r < 6; r++) {
      const zp = ((frameNum * 0.04 + r / 6) % 1.0);
      const rw = 100 + zp * zp * 700;
      const rh = 160 + zp * zp * 1150;
      ctx.strokeRect(360 - rw / 2, 620 - rh / 2, rw, rh);
    }
    for (let s = 0; s < 32; s++) {
      const ang = (s * 2.39996) % (Math.PI * 2);
      const z = 1.0 - (((frameNum * 0.035 + s * 0.17) % 0.95));
      const proj = 1.0 / Math.max(0.08, z);
      const sx = 360 + Math.cos(ang) * 55 * proj;
      const sy = 620 + Math.sin(ang) * 85 * proj;
      const sz = z < 0.3 ? 7 : 4;
      ctx.fillStyle = s % 2 === 0 ? theme.primary : "#FFC107";
      ctx.fillRect(sx, sy, sz, sz);
    }
  };

  for (let f = 0; f < totalFrames; f++) {
    draw3DBg(f);

    if (f < introFrames) {
      // 3D SHIELD FLYING ASSEMBLY + KHATARNAK LASER NAME WRITING!
      const t = f / Math.max(1, introFrames - 1);
      const shieldShards = [
        { fx: -220, fy: -180, tx: 230, ty: 150, w: 260, h: 220, col: "#0A1626", stroke: theme.primary },
        { fx: 940, fy: -180, tx: 255, ty: 175, w: 210, h: 170, col: "#132842", stroke: "#FFC107" },
        { fx: 360, fy: -260, tx: 280, ty: 198, w: 160, h: 36, col: theme.primary, stroke: "#FFFFFF" },
        { fx: 360, fy: 1380, tx: 340, ty: 198, w: 40, h: 132, col: theme.primary, stroke: "#FFC107" },
        { fx: -260, fy: 250, tx: 292, ty: 245, w: 136, h: 68, col: "#FFC107", stroke: "#FFFFFF" },
      ];
      shieldShards.forEach((sh, idx) => {
        const p = Math.max(0, Math.min(1, (t - idx * 0.04) / 0.32));
        const e = easeOutBack3D(p);
        const cx = sh.fx + (sh.tx - sh.fx) * e;
        const cy = sh.fy + (sh.ty - sh.fy) * e;
        drawRoundedRect(ctx, cx, cy, sh.w, sh.h, 16, sh.col, sh.stroke, 4);
      });

      // Shockwave when shield locks together
      if (t >= 0.28 && t <= 0.52) {
        const sp = (t - 0.28) / 0.24;
        ctx.strokeStyle = "#FFC107";
        ctx.lineWidth = Math.max(2, (1 - sp) * 10);
        ctx.beginPath();
        ctx.arc(360, 260, sp * 280, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Khatarnak Laser & Fire Name Writing ("T I T A N   N O V A")
      const chars = brandStr.split("");
      const cw = Math.min(54, Math.floor(640 / Math.max(1, chars.length)));
      const startX = 360 - (chars.length * cw) / 2;
      chars.forEach((ch, idx) => {
        if (ch === " ") return;
        const cStart = 0.22 + (idx / chars.length) * 0.48;
        const p = Math.max(0, Math.min(1, (t - cStart) / 0.16));
        if (p <= 0) return;
        const e = easeOutBack3D(p);
        const tx = startX + idx * cw;
        const ty = 430;
        const curX = tx + (idx % 2 === 0 ? -180 : 180) * (1 - e);
        const curY = ty + 160 * (1 - e);
        const sc = 2.6 - 1.6 * Math.min(1, p);

        ctx.save();
        ctx.translate(curX + cw / 2, curY + 36);
        ctx.scale(sc, sc);
        drawRoundedRect(ctx, -cw / 2 + 2, -36, cw - 4, 72, 10, "#102338", "#FFC107", 3);
        ctx.fillStyle = "#FFFFFF";
        ctx.font = "bold 36px system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(ch, 0, 12);
        ctx.restore();

        if (p < 1) {
          // Dual Laser Welding Beams from 3D Shield to active letter!
          ctx.strokeStyle = "#FFC107";
          ctx.lineWidth = 5;
          ctx.beginPath();
          ctx.moveTo(330, 340);
          ctx.lineTo(curX + cw / 2, curY + 36);
          ctx.moveTo(390, 340);
          ctx.lineTo(curX + cw / 2, curY + 36);
          ctx.stroke();
        }
      });
      ctx.textAlign = "left";
    } else if (f < introFrames + capped.length * framesPerStep) {
      const bodyF = f - introFrames;
      const stepIdx = Math.min(capped.length - 1, Math.floor(bodyF / framesPerStep));
      const stepProg = (bodyF % framesPerStep) / framesPerStep;
      const ev = capped[stepIdx];
      const phase = ev.stepPhase || (ev.status === "PASS" || ev.status === "FAIL" ? 3 : ev.action === "CARD_SENT" ? 2 : 1);

      drawRoundedRect(ctx, 0, 0, 720, 165, 0, theme.hudBg);
      ctx.fillStyle = theme.primary;
      ctx.fillRect(0, 0, 720, 6);
      ctx.fillStyle = "#FFFFFF";
      ctx.font = "bold 26px system-ui, sans-serif";
      ctx.fillText(`TITAN NOVA · 3D PRO STUDIO`, 36, 48);
      ctx.fillStyle = "#9DB8CD";
      ctx.font = "bold 17px system-ui, sans-serif";
      ctx.fillText(`${profileName.toUpperCase()} · ${dateRangeLabel}`, 36, 78);

      const accent = ev.isCloseZeroSkip
        ? "#00E5FF"
        : phase === 3
        ? (ev.status === "PASS" ? "#00E676" : "#FF5252")
        : phase === 2
        ? "#FFC107"
        : "#20DCE9";

      drawRoundedRect(ctx, 32, 190, 656, 710, 24, "#101B29", accent, 4);
      ctx.fillStyle = "#FFFFFF";
      ctx.font = "bold 34px system-ui, sans-serif";
      ctx.fillText(ev.market || "MARKET", 60, 252);

      // Step 1 Box + Flying 3D Digits
      const trickTag = "TITAN NOVA GUESSING TRICK SE";
      drawRoundedRect(ctx, 56, 280, 608, 175, 16, "#0C1E30", "#20DCE9", 3);
      ctx.fillStyle = "#20DCE9";
      ctx.font = "bold 18px system-ui, sans-serif";
      ctx.fillText(`1. ${trickTag}`, 80, 316);

      const digs = String(ev.digits || "--").split(/[,|\s]+/).filter(Boolean).slice(0, 8);
      digs.forEach((d, idx) => {
        const dProg = phase === 1 ? Math.max(0, Math.min(1, (stepProg - idx * 0.08) / 0.35)) : 1.0;
        const e = easeOutBack3D(dProg);
        const targetX = 80 + idx * 72;
        const targetY = 338;
        const curX = (idx % 2 === 0 ? -160 : 880) + (targetX - (idx % 2 === 0 ? -160 : 880)) * e;
        const curY = (idx % 3 === 0 ? -120 : 1200) + (targetY - (idx % 3 === 0 ? -120 : 1200)) * e;
        drawRoundedRect(ctx, curX, curY, 62, 68, 12, "#152C44", "#20DCE9", 3);
        ctx.fillStyle = "#FFFFFF";
        ctx.font = "bold 28px monospace";
        ctx.textAlign = "center";
        ctx.fillText(d, curX + 31, curY + 45);
      });
      ctx.textAlign = "left";

      // Step 2 Flying Rate Logic Panel
      if (phase >= 2) {
        const s2Prog = phase === 2 ? Math.min(1, stepProg / 0.4) : 1.0;
        const e2 = easeOutBack3D(s2Prog);
        const s2X = 900 + (56 - 900) * e2;
        drawRoundedRect(ctx, s2X, 475, 608, 165, 16, "#1E190B", "#FFC107", 3);
        ctx.fillStyle = "#FFC107";
        ctx.font = "bold 20px system-ui, sans-serif";
        ctx.fillText(
          ev.isCloseZeroSkip
            ? "2. CLOSE ZERO RULE: OPEN WON ➔ CLOSE Rs 0 SKIP!"
            : ev.prevStatus === "FAIL" && Number(ev.rateDiff) > 0
            ? "2. PICHLA CARD FAIL -> RATE BADHA KAR PLAY!"
            : "2. SAFE RATE & SMART STAKE STRATEGY",
          s2X + 24,
          518
        );
        ctx.fillStyle = "#FFFFFF";
        ctx.font = "bold 26px system-ui, sans-serif";
        ctx.fillText(`Play Rate: Rs ${ev.rate} | Total Invest: Rs ${ev.invest}`, s2X + 24, 575);
      }

      // Step 3 Flying Result + 3D Stamp Slam!
      if (phase === 3) {
        const s3Prog = Math.min(1, stepProg / 0.45);
        const e3 = easeOutBack3D(s3Prog);
        const s3Y = 1320 + (660 - 1320) * e3;
        drawRoundedRect(ctx, 56, s3Y, 608, 210, 16, "#0B1522", accent, 4);
        ctx.fillStyle = accent;
        ctx.font = "bold 28px system-ui, sans-serif";
        ctx.fillText(
          ev.isCloseZeroSkip
            ? "3. CLOSE ZERO SAFE SKIP (Rs 0 LOSS)"
            : ev.status === "PASS"
            ? `3. ACTUAL [${ev.actual}] ➔ SHANDAAR PASS! (+Rs ${Math.abs(Math.round(Number(ev.pl || 0)))})`
            : `3. ACTUAL [${ev.actual}] ➔ CARD FAIL (-Rs ${Math.abs(Math.round(Number(ev.pl || 0)))})`,
          80,
          s3Y + 60
        );
      }

      if (showSubtitles) {
        const subText = voiceCues[stepIdx + 1]?.text || ev.subtitle || "";
        drawRoundedRect(ctx, 32, 930, 656, 230, 20, "#081018", accent, 2);
        ctx.fillStyle = accent;
        ctx.font = "bold 18px system-ui, sans-serif";
        ctx.fillText("🎙️ 3D STEP-BY-STEP HINGLISH EXPLANATION", 58, 970);
        ctx.fillStyle = "#FFFFFF";
        ctx.font = "bold 22px system-ui, sans-serif";
        const sLines = wrapCanvasText(ctx, subText, 600, 4);
        sLines.forEach((ln, idx) => ctx.fillText(ln, 58, 1015 + idx * 36));
      }
    } else if (hasPending && f < introFrames + capped.length * framesPerStep + pendingFrames) {
      // Running Day "Abhi Aage Ka Market Baki Hai" 3D Scene
      const t = (f - introFrames - capped.length * framesPerStep) / Math.max(1, pendingFrames - 1);
      const e = easeOutBack3D(Math.min(1, t / 0.4));
      drawRoundedRect(ctx, 48, -180 + 340 * e, 624, 110, 18, "#241907", "#FFC107", 4);
      ctx.fillStyle = "#FFC107";
      ctx.font = "bold 26px system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("⏳ RUNNING DAY LIVE UPDATE · PICTURE ABHI BAKI HAI!", 360, -115 + 340 * e);

      drawRoundedRect(ctx, 48, 310, 624, 210, 22, "#101E33", "#20DCE9", 4);
      ctx.fillStyle = "#FFFFFF";
      ctx.font = "bold 30px system-ui, sans-serif";
      ctx.fillText(`ABHI AAGE KE ${pendingMarkets!.length} MARKETS BAKI HAIN!`, 360, 385);
      ctx.fillStyle = "#FFC107";
      ctx.font = "bold 26px system-ui, sans-serif";
      ctx.fillText("DEKHTE HAIN AAGE KYA DHAMAKA HOGA!", 360, 445);
      ctx.fillStyle = "#20DCE9";
      ctx.font = "bold 20px system-ui, sans-serif";
      ctx.fillText((pendingMarkets || []).slice(0, 4).join(" · "), 360, 495);
      ctx.textAlign = "left";
    } else {
      // Outro Flying Social Media Cards
      const t = (f - introFrames - capped.length * framesPerStep - pendingFrames) / Math.max(1, outroFrames - 1);
      const e = easeOutBack3D(Math.min(1, t / 0.45));
      drawRoundedRect(ctx, 60, -200 + 380 * e, 600, 180, 20, "#0B2B1E", "#00E676", 4);
      ctx.fillStyle = "#FFFFFF";
      ctx.font = "bold 32px system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("LIKE · SUBSCRIBE · FOLLOW · JOIN TELEGRAM", 360, -100 + 380 * e);
      ctx.textAlign = "left";
    }

    await new Promise((r) => setTimeout(r, 1000 / fps));
  }

  recorder.stop();
  const blob = await done;
  return { blob, mimeType, ext: mimeType.includes("mp4") ? "mp4" : "webm" };
}

export const ActivityReplayModal: React.FC<ActivityReplayModalProps> = ({
  isOpen,
  onClose,
  date,
  profileId,
  profileName,
  isMaster,
  onShowToast,
}) => {
  const [selectedDate, setSelectedDate] = useState<string>(date);
  const [period, setPeriod] = useState<'day' | 'week'>('day');
  const [filter, setFilter] = useState<'all' | 'results' | 'sent'>('all');
  const [style, setStyle] = useState<'cyber_neon' | 'gold_royal' | 'emerald_matrix'>('cyber_neon');
  const [hookStyle, setHookStyle] = useState<'auto_viral' | 'hook_a' | 'hook_b' | 'hook_c' | 'hook_d' | 'hook_e'>('auto_viral');
  // Default to 60 (`0.85x Slow & Clear`) so the video is never rushed like 1.5x!
  const [videoMode, setVideoMode] = useState<'trailer_status' | 'full_breakdown' | 'unboxing_reveal'>('trailer_status');
  const [targetMarket, setTargetMarket] = useState<string>('ALL');
  const [availableMarkets, setAvailableMarkets] = useState<string[]>([]);
  const [socialPlatform, setSocialPlatform] = useState<'unboxing_demo' | 'whatsapp_status' | 'insta_story' | 'fb_story' | 'yt_shorts' | 'full_video'>('whatsapp_status');
  const [durationSec, setDurationSec] = useState<20 | 30 | 45 | 60 | 75>(20);
  const [previewPlaybackRate, setPreviewPlaybackRate] = useState<number>(1.0);
  const [voiceLang, setVoiceLang] = useState<'hinglish' | 'hindi' | 'english'>('hinglish');
  const [voiceGender, setVoiceGender] = useState<'male' | 'female'>('female');
  const [voicePack, setVoicePack] = useState<'swara_hi' | 'madhur_hi' | 'andrew_pro' | 'brian_hype' | 'ava_studio' | 'emma_reels'>('swara_hi');
  const [voiceEnabled, setVoiceEnabled] = useState<boolean>(true);
  const [voicePitchShift, setVoicePitchShift] = useState<number>(0.92);
  const [voiceSpeed, setVoiceSpeed] = useState<number>(1.02);
  const [voiceSampleName, setVoiceSampleName] = useState<string>('');
  const [musicStyle, setMusicStyle] = useState<'cinematic_bass' | 'lofi_chill' | 'upbeat_synth' | 'off'>('cinematic_bass');
  const [showSubtitles, setShowSubtitles] = useState<boolean>(true);
  const [showStudioCustomize, setShowStudioCustomize] = useState<boolean>(true);
  const [customTitle, setCustomTitle] = useState<string>('');
  const [customCta, setCustomCta] = useState<string>('');
  const [sendAsLoopingGif, setSendAsLoopingGif] = useState<boolean>(false);

  const [loading, setLoading] = useState<boolean>(false);
  const [sendingBot, setSendingBot] = useState<boolean>(false);
  const [settingsDirty, setSettingsDirty] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [videoBlob, setVideoBlob] = useState<Blob | null>(null);
  const [videoBase64, setVideoBase64] = useState<string>('');
  const [totalCardsCount, setTotalCardsCount] = useState<number>(0);
  const [pendingMarketsCount, setPendingMarketsCount] = useState<number>(0);
  const [hasFfmpeg, setHasFfmpeg] = useState<boolean>(true);
  const [hasEmbeddedVoice, setHasEmbeddedVoice] = useState<boolean>(false);
  const [isVideoMuted, setIsVideoMuted] = useState<boolean>(false);
  const [mimeType, setMimeType] = useState<string>('video/mp4');
  const [voiceScript, setVoiceScript] = useState<VoiceCueItem[]>([]);
  const [videoSummary, setVideoSummary] = useState<{
    totalCards: number;
    passCount: number;
    failCount: number;
    skipCount: number;
    totalInvest: number;
    netPL: number;
    markets: string[];
  } | null>(null);
  const [socialDescription, setSocialDescription] = useState<string>("");
  const [descCopied, setDescCopied] = useState<boolean>(false);

  const urlRef = useRef<string>('');
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fallbackAudioRef = useRef<HTMLAudioElement | null>(null);
  const lastSpokenCueRef = useRef<number>(-1);
  const abortControllerRef = useRef<AbortController | null>(null);
  const pendingVoiceSampleB64Ref = useRef<string>('');

  const generateSocialDescriptionText = (summary = videoSummary) => {
    const brand = (customTitle || "TITAN NOVA").trim();
    const cta = (customCta || "Daily Live Updates & VIP Guessing ke liye Pinned Link / Bio check karein!").trim();
    const dateLabel = period === "week" ? `Weekly Report (${selectedDate})` : `Date: ${selectedDate}`;
    const mktLabel = targetMarket !== "ALL" ? ` · ${targetMarket}` : "";
    const pass = summary?.passCount ?? 0;
    const fail = summary?.failCount ?? 0;
    const skip = summary?.skipCount ?? 0;
    const cards = summary?.totalCards ?? totalCardsCount;
    const pl = summary?.netPL ?? 0;
    const plStr = `${pl >= 0 ? "+" : "-"}₹${Math.abs(Math.round(pl)).toLocaleString("en-IN")}`;

    if (videoMode === "unboxing_reveal") {
      return [
        `🔥 ${brand} — AAJ KA LIVE GUESSING UNBOXING${mktLabel} (${dateLabel}) 🎯`,
        "",
        "📊 Live Market Digits & Smart Staking Rate Reveal!",
        `✅ Verified ${cards || 1} Market Card(s) · Zero Guesswork, Pure Discipline.`,
        "",
        `👉 ${cta}`,
        "",
        "#TitanNova #SattaMatka #MatkaGuessing #LiveGuessing #KalyanMatka #Reels #Shorts #Viral",
      ].join("\n");
    }

    const hookLine =
      socialPlatform === "fb_story"
        ? `🚀 ${brand} | ${dateLabel}${mktLabel} — ${pl >= 0 ? `${plStr} Profit Booked!` : "Full Transparency Report!"}`
        : socialPlatform === "yt_shorts" || socialPlatform === "full_video"
        ? `💥 ${brand} ${period === "week" ? "WEEKLY" : "DAILY"} RECORD${mktLabel} | ${pass} PASS · ${plStr} P/L (${selectedDate})`
        : `⚡ ${brand} LIVE UPDATE${mktLabel} (${dateLabel}) | ${pass} PASS · ${plStr}`;

    const statsLines = summary
      ? [
          `📌 Total Cards: ${cards} | ✅ PASS: ${pass} | ❌ FAIL: ${fail}${skip > 0 ? ` | ⏭️ SKIP: ${skip}` : ""}`,
          `💰 Total Invest: ₹${Math.round(summary.totalInvest).toLocaleString("en-IN")} | 📈 Net P/L: ${plStr}`,
        ]
      : [`📊 ${brand} Verified Daily Ledger & Recovery AI Breakdown`];

    const tags =
      socialPlatform === "yt_shorts" || socialPlatform === "full_video"
        ? "#TitanNova #SattaMatka #MatkaResult #KalyanMatka #MatkaAI #YouTubeShorts #Shorts #Profit"
        : socialPlatform === "fb_story"
        ? "#TitanNova #SattaMatka #FacebookReels #ReelsIndia #MatkaGuessing #DailyProfit #ViralReels"
        : "#TitanNova #SattaMatka #InstaReels #ReelsViral #KalyanMatka #LiveResult #SmartStaking";

    return [hookLine, "", ...statsLines, "", `👇 ${cta}`, "", tags].join("\n");
  };

  useEffect(() => {
    setSocialDescription(generateSocialDescriptionText(videoSummary));
  }, [videoSummary, socialPlatform, videoMode, selectedDate, period, targetMarket, customTitle, customCta, totalCardsCount]);

  const handleCopyDescription = async () => {
    const text = socialDescription.trim() || generateSocialDescriptionText(videoSummary);
    try {
      await navigator.clipboard.writeText(text);
      setDescCopied(true);
      onShowToast?.("📋 Social media description copied!", "success");
      setTimeout(() => setDescCopied(false), 2000);
    } catch {
      onShowToast?.("Copy failed — select text manually", "error");
    }
  };

  const stopSpeech = () => {
    try {
      if (fallbackAudioRef.current) {
        fallbackAudioRef.current.pause();
        fallbackAudioRef.current.currentTime = 0;
      }
    } catch (_) {}
    try {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    } catch (_) {}
    lastSpokenCueRef.current = -1;
  };

  const unlockMobileAudioSession = () => {
    try {
      const AudioCtx = (window as any).AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        const ctx = new AudioCtx();
        if (ctx.state === 'suspended') void ctx.resume().catch(() => {});
        const buf = ctx.createBuffer(1, 1, 22050);
        const src = ctx.createBufferSource();
        src.buffer = buf;
        src.connect(ctx.destination);
        src.start(0);
        setTimeout(() => void ctx.close().catch(() => {}), 300);
      }
    } catch (_) {}
    try {
      if (videoRef.current) {
        videoRef.current.muted = false;
        videoRef.current.volume = 1.0;
        const p = videoRef.current.play();
        if (p && typeof p.catch === 'function') p.catch(() => {});
        videoRef.current.pause();
      }
    } catch (_) {}
    try {
      if (!fallbackAudioRef.current && typeof Audio !== 'undefined') {
        fallbackAudioRef.current = new Audio();
      }
      if (fallbackAudioRef.current) {
        fallbackAudioRef.current.muted = false;
        fallbackAudioRef.current.volume = 1.0;
      }
    } catch (_) {}
    try {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const warm = new SpeechSynthesisUtterance(' ');
        warm.volume = 0.01;
        window.speechSynthesis.speak(warm);
      }
    } catch (_) {}
  };

  const speakCueText = (text: string) => {
    if (!voiceEnabled || hasEmbeddedVoice || typeof window === 'undefined') return;
    const clean = String(text || '').replace(/\s+/g, ' ').trim();
    if (!clean) return;

    const speakViaWebSpeech = () => {
      if (!('speechSynthesis' in window)) return;
      try {
        window.speechSynthesis.cancel();
        const utter = new SpeechSynthesisUtterance(clean);
        utter.lang = voiceLang === 'english' ? 'en-IN' : 'hi-IN';
        utter.rate = Math.max(0.75, Math.min(1.15, voiceSpeed * previewPlaybackRate));
        utter.pitch = voicePitchShift;
        const voices = window.speechSynthesis.getVoices?.() || [];
        const preferred = voices.find((v) => {
          const langMatch = voiceLang === 'english' ? v.lang.startsWith('en') : v.lang.startsWith('hi') || v.lang.startsWith('en-IN');
          const nameLower = v.name.toLowerCase();
          const genderMatch = voiceGender === 'female'
            ? nameLower.includes('female') || nameLower.includes('swara') || nameLower.includes('lekha') || nameLower.includes('heera')
            : nameLower.includes('male') || nameLower.includes('madhur') || nameLower.includes('ravi') || nameLower.includes('prabhat');
          return langMatch && genderMatch;
        }) || voices.find((v) => (voiceLang === 'english' ? v.lang.startsWith('en') : v.lang.startsWith('hi') || v.lang.startsWith('en-IN')));
        if (preferred) utter.voice = preferred;
        window.speechSynthesis.speak(utter);
      } catch (_) {}
    };

    try {
      const tl = voiceLang === 'english' ? 'en' : 'hi';
      const shortClause = clean.slice(0, 140);
      const ttsUrl = `https://translate.googleapis.com/translate_tts?ie=UTF-8&tl=${tl}&client=gtx&q=${encodeURIComponent(shortClause)}`;
      if (!fallbackAudioRef.current && typeof Audio !== 'undefined') {
        fallbackAudioRef.current = new Audio();
      }
      const aud = fallbackAudioRef.current;
      if (aud) {
        aud.pause();
        aud.src = ttsUrl;
        aud.playbackRate = Math.max(0.75, Math.min(1.2, voiceSpeed * previewPlaybackRate));
        aud.volume = 1.0;
        aud.play().catch(() => {
          speakViaWebSpeech();
        });
        return;
      }
    } catch (_) {}
    speakViaWebSpeech();
  };

  const handleVideoTimeUpdate = () => {
    const vid = videoRef.current;
    if (!vid || !voiceEnabled || hasEmbeddedVoice || !voiceScript.length) return;
    const cur = vid.currentTime;
    if (cur < 0.3 && lastSpokenCueRef.current > 0) {
      lastSpokenCueRef.current = -1;
    }
    const cueIdx = voiceScript.findIndex((c) => cur >= c.startSec && cur < c.endSec);
    if (cueIdx !== -1 && cueIdx !== lastSpokenCueRef.current) {
      lastSpokenCueRef.current = cueIdx;
      speakCueText(voiceScript[cueIdx].text);
    }
  };

  const forcePlayWithAudio = () => {
    const vid = videoRef.current;
    if (!vid) return;
    vid.playbackRate = previewPlaybackRate;
    vid.muted = false;
    vid.volume = 1.0;
    setIsVideoMuted(false);
    vid.play().catch(() => {
      vid.muted = true;
      setIsVideoMuted(true);
      vid.play().catch(() => {});
    });
  };

  const applyLivePreviewSpeed = (rate: number) => {
    setPreviewPlaybackRate(rate);
    if (videoRef.current) {
      videoRef.current.playbackRate = rate;
    }
    if (fallbackAudioRef.current) {
      fallbackAudioRef.current.playbackRate = Math.max(0.75, Math.min(1.25, voiceSpeed * rate));
    }
  };

  const handleVoiceSampleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    try {
      setVoiceSampleName(file.name);
      setSettingsDirty(true);
      try {
        const AudioCtx = (window as any).AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          const ctx = new AudioCtx();
          const sliceAb = await file.slice(0, 256 * 1024).arrayBuffer();
          const audioBuf = await ctx.decodeAudioData(sliceAb);
          const ch = audioBuf.getChannelData(0);
          let zc = 0;
          let active = 0;
          const limit = Math.min(ch.length, audioBuf.sampleRate * 3);
          for (let i = 1; i < limit; i++) {
            if (Math.abs(ch[i]) > 0.02) {
              active++;
              if ((ch[i - 1] >= 0 && ch[i] < 0) || (ch[i - 1] < 0 && ch[i] >= 0)) zc++;
            }
          }
          await ctx.close().catch(() => {});
          if (active > 1000) {
            const zcr = zc / active;
            const autoPitch = zcr < 0.055 ? 0.86 : zcr < 0.075 ? 0.92 : zcr < 0.095 ? 0.96 : 1.0;
            setVoicePitchShift(autoPitch);
            setVoiceGender(autoPitch <= 0.96 ? 'male' : 'female');
          }
        }
      } catch (_) {}

      const headSlice = file.slice(0, 96 * 1024);
      const reader = new FileReader();
      reader.onload = () => {
        pendingVoiceSampleB64Ref.current = String(reader.result || '');
        onShowToast?.('🎙️ Voice Tone Ready!', `${file.name} set ho gaya. Ab neeche "START VIDEO GENERATION" dabayein.`, 'success');
      };
      reader.readAsDataURL(headSlice);
    } catch {
      onShowToast?.('Voice Tone Ready', 'Voice tone profile set ho gaya. Ab "START VIDEO GENERATION" dabayein.', 'info');
    }
  };

  const buildVideo = async () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    const ctrl = new AbortController();
    abortControllerRef.current = ctrl;

    stopSpeech();
    unlockMobileAudioSession();
    setLoading(true);
    setSettingsDirty(false);
    setError('');
    if (urlRef.current) {
      URL.revokeObjectURL(urlRef.current);
      urlRef.current = '';
    }
    setVideoUrl('');
    setVideoBlob(null);
    setVideoBase64('');
    setVoiceScript([]);
    setHasEmbeddedVoice(false);

    const sampleToSend = pendingVoiceSampleB64Ref.current || undefined;
    pendingVoiceSampleB64Ref.current = '';

    try {
      const res = await fetch(apiUrl('/api/app/activity_video'), {
        method: 'POST',
        signal: ctrl.signal,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          date: selectedDate,
          period,
          profileId,
          filter,
          style,
          hookStyle,
          durationSec,
          videoMode,
          socialPlatform,
          targetMarket,
          voiceLang,
          voiceGender,
          voicePack,
          voiceEnabled,
          voicePitchShift,
          voiceSpeed,
          voiceSampleBase64: sampleToSend,
          musicStyle,
          showSubtitles,
          customTitle: customTitle.trim() || undefined,
          customCta: customCta.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (ctrl.signal.aborted) return;
      if (!res.ok) throw new Error(data?.message || 'Activity replay failed');

      if (data.empty || !data.events?.length) {
        setTotalCardsCount(0);
        setError('Is date/filter par koi activity record nahi mili. Doosri date ya Daily/Weekly mode select karein.');
        return;
      }

      const uniqueCards = new Set((data.events as ActivityEventItem[]).map((e, i) => e.cardSlot ?? `${e.date}_${e.market}_${i}`)).size;
      setTotalCardsCount(uniqueCards);
      try {
        const evs = data.events as ActivityEventItem[];
        const passCount = evs.filter((e) => e.type === "CARD_SETTLED" && e.status === "PASS").length;
        const failCount = evs.filter((e) => e.type === "CARD_SETTLED" && e.status === "FAIL").length;
        const skipCount = evs.filter((e) => e.type === "CARD_SKIPPED" || e.status === "SKIP").length;
        const settledEvs = evs.filter((e) => e.type === "CARD_SETTLED");
        const totalInvest = settledEvs.reduce((acc, e) => acc + (Number(e.invest) || 0), 0);
        const netPL = settledEvs.reduce((acc, e) => acc + (Number(e.net) || 0), 0);
        const markets = Array.from(new Set(evs.map((e) => String(e.market || "").trim()).filter(Boolean)));
        setVideoSummary({ totalCards: uniqueCards, passCount, failCount, skipCount, totalInvest, netPL, markets });
      } catch {}
      setPendingMarketsCount(Array.isArray(data.pendingMarkets) ? data.pendingMarkets.length : 0);
      if (Array.isArray(data.availableMarkets) && data.availableMarkets.length > 0) setAvailableMarkets(data.availableMarkets);
      setHasFfmpeg(Boolean(data.hasFfmpeg));
      setHasEmbeddedVoice(Boolean(data.hasEmbeddedVoice));
      const cues: VoiceCueItem[] = Array.isArray(data.voiceScript) ? data.voiceScript : [];
      setVoiceScript(cues);

      if (data.hasFfmpeg && data.videoBase64) {
        const mime = data.mimeType || 'video/mp4';
        const blob = await base64ToBlobFast(data.videoBase64, mime);
        if (ctrl.signal.aborted) return;
        const url = URL.createObjectURL(blob);
        urlRef.current = url;
        setVideoUrl(url);
        setVideoBlob(blob);
        setVideoBase64(data.videoBase64);
        setMimeType(mime);
      } else {
        const fb = await renderFallbackCanvasVideo(
          data.events,
          cues,
          showSubtitles,
          profileName,
          style,
          period,
          selectedDate,
          customTitle.trim() || undefined,
          Array.isArray(data.pendingMarkets) ? data.pendingMarkets : undefined
        );
        if (ctrl.signal.aborted) return;
        const url = URL.createObjectURL(fb.blob);
        urlRef.current = url;
        setVideoUrl(url);
        setVideoBlob(fb.blob);
        setMimeType(fb.mimeType);
      }
    } catch (e: any) {
      if (e?.name === 'AbortError' || ctrl.signal.aborted) return;
      setError(e?.message || 'Could not generate YouTube Shorts video');
    } finally {
      if (abortControllerRef.current === ctrl) {
        setLoading(false);
      }
    }
  };

  useEffect(() => {
    setSelectedDate(date);
  }, [date]);

  useEffect(() => {
    if (!isOpen) {
      if (abortControllerRef.current) abortControllerRef.current.abort();
      stopSpeech();
      setLoading(false);
    }
    return () => {
      if (abortControllerRef.current) abortControllerRef.current.abort();
      stopSpeech();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const sizeKb = videoBlob ? Math.round(videoBlob.size / 1024) : 0;
  const fileExt = mimeType.includes('mp4') ? 'mp4' : 'webm';
  const filename = `titan-shorts-${period}-${selectedDate}.${fileExt}`;

  const handleDownload = () => {
    if (!videoUrl) return;
    const a = document.createElement('a');
    a.href = videoUrl;
    a.download = filename;
    document.body.append(a);
    a.click();
    a.remove();
    onShowToast?.('MP4 Downloaded', `${filename} (${sizeKb} KB · All ${totalCardsCount} Cards + Real Human AI Voice) saved!`, 'success');
  };

  const handleNativeShare = async () => {
    if (!videoBlob) return;
    try {
      const file = new File([videoBlob], filename, { type: mimeType });
      if (!navigator.share || !navigator.canShare?.({ files: [file] })) {
        handleDownload();
        return;
      }
      await navigator.share({
        files: [file],
        title: `Titan Nova ${period === 'week' ? 'Weekly' : 'Daily'} Shorts (${selectedDate})`,
      });
    } catch (e: any) {
      if (e?.name !== 'AbortError') {
        handleDownload();
      }
    }
  };

  const handleSendViaBot = async () => {
    if (!videoBase64) {
      onShowToast?.('Termux FFmpeg Needed', 'Bot video share ke liye Termux me "pkg install ffmpeg" run karein.', 'warning');
      return;
    }
    setSendingBot(true);
    try {
      const res = await fetch(apiUrl('/api/bot/broadcast'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: `🎬 *TITAN NOVA · ${period === 'week' ? 'WEEKLY' : 'DAILY'} STEP-BY-STEP SHORTS (${selectedDate})*\n👤 ${profileName} · All ${totalCardsCount} Cards · Real Human AI Voice`,
          senderFormat: 'gif_video',
          broadcastVideo: videoBase64,
          gifPlayback: sendAsLoopingGif,
          broadcastKind: 'activity-replay',
          profileId,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.message || 'Broadcast failed');
      onShowToast?.(
        '🎬 Video Queued!',
        `WhatsApp / Telegram (${data.targets} targets) par ${sendAsLoopingGif ? 'Looping GIF' : 'HD Video + Real Human AI Voice'} bhej diya gaya hai.`,
        'success'
      );
    } catch (e: any) {
      onShowToast?.('Send Failed', e?.message || 'Could not queue video broadcast', 'danger');
    } finally {
      setSendingBot(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-1.5 sm:p-3">
      <div className="w-full max-w-lg rounded-2xl border border-cyan-500/35 bg-[#121B26] text-white shadow-2xl overflow-hidden flex flex-col h-[94dvh] max-h-[94dvh]">
        {/* 1. STICKY COMPACT HEADER (Never scrolls off) */}
        <div className="shrink-0 flex items-center justify-between px-3 py-2 border-b border-white/10 bg-gradient-to-r from-[#172434] to-[#1E2E42]">
          <div className="flex items-center gap-2 min-w-0">
            <div className="p-1.5 rounded-xl bg-cyan-500/15 border border-cyan-400/30 shrink-0">
              <Film className="w-4 h-4 text-[#20DCE9]" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <h2 className="text-xs font-black tracking-wide truncate">TITAN 3D VIDEO STUDIO</h2>
                <span className="px-1.5 py-0.5 text-[8px] font-black rounded bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 shrink-0">
                  {voicePack === 'swara_hi'
                    ? '👩 SWARA HINDI'
                    : voicePack === 'madhur_hi'
                    ? '👨 MADHUR HINDI'
                    : voicePack === 'andrew_pro'
                    ? '🎬 ANDREW STUDIO'
                    : voicePack === 'brian_hype'
                    ? '⚡ BRIAN HYPE'
                    : voicePack === 'ava_studio'
                    ? '✨ AVA STUDIO'
                    : '🔥 EMMA REELS'}
                </span>
              </div>
              <p className="text-[9px] text-[#8DA6C0] truncate">
                {selectedDate} · {profileName} {totalCardsCount > 0 ? `· ${totalCardsCount} Settled` : ''} {pendingMarketsCount > 0 ? `· ${pendingMarketsCount} Pending` : ''} {sizeKb > 0 ? `· ${sizeKb} KB` : ''}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              if (abortControllerRef.current) abortControllerRef.current.abort();
              stopSpeech();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-[#8DA6C0] shrink-0"
            aria-label="Close Video Studio"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 2. SINGLE SCROLLABLE ANDROID-FRIENDLY WORKSPACE (All editing buttons fit 100%) */}
        <div className="flex-1 overflow-y-auto overscroll-contain p-2.5 space-y-2.5">
          {/* LIVE VIDEO PREVIEW STAGE (Shown at the very top when video is ready or rendering!) */}
          {(videoUrl || loading || error) && (
            <div className="rounded-xl border border-cyan-400/30 bg-[#090E14] p-2.5 flex flex-col items-center justify-center">
              <div className={videoUrl && !loading && !error ? "relative flex flex-col items-center gap-2 w-full" : "hidden"}>
                {pendingMarketsCount > 0 && (
                  <div className="w-full px-2.5 py-1 rounded-lg bg-amber-500/15 border border-amber-400/40 text-amber-300 font-bold text-[9px] text-center">
                    ✅ {totalCardsCount} Settled Cards + ⏳ {pendingMarketsCount} Pending ("Abhi Aage Ka Market Baki Hai" Scene Added)
                  </div>
                )}
                <video
                  ref={videoRef}
                  src={videoUrl || undefined}
                  playsInline
                  controls
                  onLoadedData={forcePlayWithAudio}
                  onTimeUpdate={handleVideoTimeUpdate}
                  onPause={stopSpeech}
                  onEnded={stopSpeech}
                  onVolumeChange={() => {
                    if (videoRef.current) setIsVideoMuted(videoRef.current.muted);
                  }}
                  className="max-h-[34vh] rounded-xl border border-cyan-400/30 shadow-xl bg-black"
                />
                {/* 1-Tap Live Playback Speed Bar */}
                <div className="flex flex-wrap items-center justify-center gap-1 bg-[#14202E] px-2.5 py-1 rounded-full border border-white/10 text-[9px]">
                  <span className="text-[#8DA6C0] font-bold">Player Speed:</span>
                  {([
                    [0.6, '🐢 0.6x Slow'],
                    [0.8, '🚶 0.8x Calm'],
                    [1.0, '▶️ 1.0x Normal'],
                  ] as const).map(([spd, lbl]) => (
                    <button
                      key={spd}
                      type="button"
                      onClick={() => applyLivePreviewSpeed(spd)}
                      className={`px-2 py-0.5 rounded-full font-bold transition ${
                        previewPlaybackRate === spd ? 'bg-[#20DCE9] text-black' : 'text-[#8DA6C0] hover:text-white'
                      }`}
                    >
                      {lbl}
                    </button>
                  ))}
                </div>
                {isVideoMuted && (
                  <button
                    type="button"
                    onClick={() => {
                      if (videoRef.current) {
                        videoRef.current.muted = false;
                        videoRef.current.volume = 1.0;
                        videoRef.current.currentTime = 0;
                        void videoRef.current.play();
                        setIsVideoMuted(false);
                      }
                    }}
                    className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500 text-black font-black text-[10px] shadow-lg animate-pulse"
                  >
                    <Volume2 className="w-3.5 h-3.5" /> 🔊 TAP TO UNMUTE VOICE
                  </button>
                )}
              </div>

              {loading && (
                <div className="flex flex-col items-center gap-2 text-[#8DC8FF] text-xs py-5">
                  <RefreshCw className="w-7 h-7 animate-spin text-[#20DCE9]" />
                  <span className="font-black text-xs text-white text-center">
                    Rendering 3D Video + {voiceGender === 'male' ? 'Male' : 'Female'} AI Voice…
                  </span>
                  <span className="text-[9px] text-[#8DA6C0] text-center">
                    3D Quantum Vortex Intro · Titan Nova Guessing Trick · Live Scoreboard
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      if (abortControllerRef.current) abortControllerRef.current.abort();
                      setLoading(false);
                    }}
                    className="mt-1 px-3 py-1 rounded-lg bg-white/10 text-[10px] text-[#FF8A8A] font-bold"
                  >
                    Cancel Render
                  </button>
                </div>
              )}

              {error && !loading && (
                <div className="text-center px-3 py-3 space-y-2">
                  <p className="text-[11px] text-[#FF8A8A] font-semibold">{error}</p>
                </div>
              )}
            </div>
          )}

          {/* SECTION A: UNBOXING GUESSING REVEAL + STORY / STATUS / SHORTS FORMAT */}
          <div className={`rounded-xl border border-amber-400/25 bg-[#0D1520] p-2.5 space-y-2 ${loading ? 'pointer-events-none opacity-55' : ''}`}>
            <div className="flex items-center justify-between text-[10px]">
              <span className="font-black text-amber-400">🔥 1. CHOOSE VIDEO / UNBOXING / STATUS MODE:</span>
              <span className="text-[9px] text-emerald-300 font-bold">
                {videoMode === 'unboxing_reveal'
                  ? '🎁 Raw Card Unboxing ON'
                  : videoMode === 'trailer_status'
                  ? '⚡ 15–30s Fast Trailer ON'
                  : '🎬 Full 3-Step Video ON'}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {([
                ['unboxing_demo', '🎁 Raw Card Unboxing (Guessing Reveal Demo)', 'Aaj ke liye yeh number hai! Pre-Result Trust & Game Selling Quick Video', 'unboxing_reveal', 'VIP GAME & LIVE UNBOXING · JOIN NOW'],
                ['whatsapp_status', '📱 WhatsApp Status', '🎬 Custom Meme Intro (4.2s) + Matched Tone + All Cards', 'trailer_status', 'THANK YOU ALL · MILTE HE FER NEXT VIDEO ME!'],
                ['insta_story', '📸 Instagram Story', 'Intro + 6-Point Aaj Ka Review + Real Proof Outro', 'trailer_status', 'THANK YOU ALL · MILTE HE FER NEXT VIDEO ME!'],
                ['fb_story', '📘 Facebook Story', 'Intro + 6-Point Aaj Ka Review + Real Proof Outro', 'trailer_status', 'THANK YOU ALL · MILTE HE FER NEXT VIDEO ME!'],
                ['yt_shorts', '▶️ YouTube Shorts', 'Intro + 6-Point Aaj Ka Review + Real Proof Outro', 'trailer_status', 'THANK YOU ALL · MILTE HE FER NEXT VIDEO ME!'],
                ['full_video', '🎬 Full Step-by-Step Video (All Settled Cards)', 'Har Settled Card ka 3-Step Hisab + Pending Markets', 'full_breakdown', 'LIKE · COMMENT · SHARE · JOIN TELEGRAM'],
              ] as const).map(([platId, label, sub, modeType, defaultCta], idx) => {
                const isSelected = socialPlatform === platId;
                const isFullSpan = idx === 0 || idx === 5;
                return (
                  <button
                    key={platId}
                    type="button"
                    onClick={() => {
                      setSocialPlatform(platId);
                      setVideoMode(modeType);
                      if (modeType === 'unboxing_reveal') {
                        setDurationSec(20);
                        setVoiceSpeed(1.0);
                        setStyle('gold_royal');
                        setCustomCta(defaultCta);
                      } else if (modeType === 'trailer_status') {
                        setDurationSec(20);
                        setVoiceSpeed(1.02);
                        setCustomCta(defaultCta);
                      } else {
                        setDurationSec(60);
                        setVoiceSpeed(1.06);
                        setCustomCta('');
                      }
                      setSettingsDirty(true);
                    }}
                    className={`${isFullSpan ? 'col-span-2' : ''} px-2.5 py-2 rounded-xl border text-left transition flex flex-col justify-center ${
                      isSelected
                        ? idx === 0
                          ? 'bg-gradient-to-r from-yellow-400 via-amber-500 to-orange-500 text-slate-950 border-yellow-200 shadow-lg'
                          : 'bg-gradient-to-r from-amber-500 to-rose-500 text-slate-950 border-amber-200 shadow-md'
                        : 'bg-[#172231] border-white/10 text-[#9DB8CD] hover:text-white'
                    }`}
                  >
                    <span className="text-[10px] font-black leading-tight">{label}</span>
                    <span className={`text-[8px] font-bold mt-0.5 ${isSelected ? 'text-slate-900' : 'text-amber-300/85'}`}>{sub}</span>
                  </button>
                );
              })}
            </div>

            {/* Target Market Selector when Unboxing Reveal Mode is active */}
            {videoMode === 'unboxing_reveal' && (
              <div className="pt-1.5 border-t border-amber-400/20 flex items-center justify-between gap-2 text-[10px]">
                <span className="font-bold text-amber-300 shrink-0">🎁 Unbox Market:</span>
                <select
                  value={targetMarket}
                  onChange={(e) => {
                    setTargetMarket(e.target.value);
                    setSettingsDirty(true);
                  }}
                  className="flex-1 bg-[#1B2736] border border-amber-400/40 rounded-lg px-2 py-1 text-white font-bold outline-none"
                >
                  <option value="ALL">🌐 All Today&apos;s Guessing Cards (Quick Top 4)</option>
                  {(availableMarkets.length > 0
                    ? availableMarkets
                    : [
                        'SRIDEVI OPEN', 'SRIDEVI CLOSE',
                        'TIME BAZAR OPEN', 'TIME BAZAR CLOSE',
                        'MADHUR DAY OPEN', 'MADHUR DAY CLOSE',
                        'MILAN DAY OPEN', 'MILAN DAY CLOSE',
                        'RAJDHANI DAY OPEN', 'RAJDHANI DAY CLOSE',
                        'SUPREME DAY OPEN', 'SUPREME DAY CLOSE',
                        'KALYAN OPEN', 'KALYAN CLOSE',
                        'SRIDEVI NIGHT OPEN', 'SRIDEVI NIGHT CLOSE',
                        'MADHUR NIGHT OPEN', 'MADHUR NIGHT CLOSE',
                        'SUPREME NIGHT OPEN', 'SUPREME NIGHT CLOSE',
                        'MILAN NIGHT OPEN', 'MILAN NIGHT CLOSE',
                        'KALYAN NIGHT OPEN', 'KALYAN NIGHT CLOSE',
                        'RAJDHANI NIGHT OPEN', 'RAJDHANI NIGHT CLOSE',
                        'MAIN BAZAR OPEN', 'MAIN BAZAR CLOSE',
                      ]
                  ).map((mName) => (
                    <option key={mName} value={mName}>
                      🎯 {mName} Only (12s Fast Single Card Unboxing)
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {/* SECTION B: 5 AI VOICE ENGINE PACKS + MALE/FEMALE VOICE */}
          <div className={`rounded-xl border border-cyan-400/25 bg-[#0F1926] p-2.5 space-y-2 ${loading ? 'pointer-events-none opacity-55' : ''}`}>
            <div className="flex items-center justify-between gap-1 flex-wrap">
              <span className="text-[10px] font-black text-cyan-300">🎙️ 2. AI VOICE PACK &amp; SPEAKER:</span>
              <div className="flex items-center gap-1 bg-[#1A283B] p-0.5 rounded-lg border border-emerald-400/30">
                <button
                  type="button"
                  onClick={() => {
                    setVoiceEnabled(true);
                    setVoiceGender('male');
                    setVoicePitchShift(0.92);
                    setSettingsDirty(true);
                  }}
                  className={`px-2 py-1 rounded-md text-[10px] font-black transition ${
                    voiceEnabled && voiceGender === 'male' ? 'bg-[#00C26F] text-white' : 'text-[#8DA6C0]'
                  }`}
                >
                  👨 Male
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setVoiceEnabled(true);
                    setVoiceGender('female');
                    setVoicePitchShift(1.0);
                    setSettingsDirty(true);
                  }}
                  className={`px-2 py-1 rounded-md text-[10px] font-black transition ${
                    voiceEnabled && voiceGender === 'female' ? 'bg-pink-500 text-white' : 'text-[#8DA6C0]'
                  }`}
                >
                  👩 Female
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setVoiceEnabled((v) => !v);
                    setSettingsDirty(true);
                  }}
                  className={`px-2 py-1 rounded-md text-[10px] font-bold transition ${
                    !voiceEnabled ? 'bg-rose-500/80 text-white' : 'text-[#8DA6C0]'
                  }`}
                >
                  {voiceEnabled ? '🔊 ON' : '🔇 Mute'}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
              {([
                ['swara_hi', '👩 Swara (Hindi)', 'Original Female Voice', 'female'],
                ['madhur_hi', '👨 Madhur (Hindi)', 'Original Male Voice', 'male'],
                ['andrew_pro', '🎬 Andrew Studio', 'Deep Multilingual Male', 'male'],
                ['brian_hype', '⚡ Brian Hype', 'Energetic Fast Male', 'male'],
                ['ava_studio', '✨ Ava Studio', 'Smooth Studio Female', 'female'],
                ['emma_reels', '🔥 Emma Reels', 'Bright Reels Female', 'female'],
              ] as const).map(([packId, title, sub, spkGender]) => {
                const active = voicePack === packId;
                return (
                  <button
                    key={packId}
                    type="button"
                    onClick={() => {
                      setVoiceEnabled(true);
                      setVoicePack(packId);
                      setVoiceGender(spkGender);
                      setVoicePitchShift(spkGender === 'male' ? 0.92 : 1.0);
                      setSettingsDirty(true);
                    }}
                    className={`px-2.5 py-1.5 rounded-xl border text-left transition flex flex-col ${
                      active
                        ? 'bg-gradient-to-r from-[#00C26F]/30 to-[#20DCE9]/30 border-[#00E676] text-white shadow-md'
                        : 'bg-[#172332] border-white/10 text-[#9DB8CD] hover:text-white'
                    }`}
                  >
                    <span className="text-[10px] font-black leading-tight">{title}</span>
                    <span className="text-[8px] text-cyan-300/90 font-semibold">{sub}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* SECTION C: ALL EDITING & STUDIO CONTROLS (Clean 2-Column Android Grid — Nothing Hidden!) */}
          <div className={`rounded-xl border border-white/10 bg-[#0F1720] p-2.5 space-y-2 text-[10px] ${loading ? 'pointer-events-none opacity-55' : ''}`}>
            <div className="flex items-center justify-between">
              <span className="font-black text-white">⚙️ 3. VIDEO EDITING &amp; TIMING CONTROLS:</span>
              <button
                type="button"
                onClick={() => { setShowSubtitles((v) => !v); setSettingsDirty(true); }}
                className={`flex items-center gap-1 px-2 py-0.5 rounded-md font-bold border text-[9px] ${
                  showSubtitles ? 'bg-cyan-500/20 border-cyan-400/50 text-cyan-300' : 'bg-[#1E2C3D] border-white/10 text-[#8DA6C0]'
                }`}
              >
                <Subtitles className="w-3 h-3" /> {showSubtitles ? 'Subtitles ON' : 'Subtitles OFF'}
              </button>
            </div>

            {/* Row: Daily/Weekly + Filter */}
            <div className="grid grid-cols-2 gap-1.5">
              <div className="flex items-center bg-[#1B2736] p-0.5 rounded-lg border border-white/10">
                {([['day', 'Daily'], ['week', 'Weekly']] as const).map(([val, lbl]) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => { setPeriod(val); setSettingsDirty(true); }}
                    className={`flex-1 py-1 rounded-md font-bold text-center transition ${period === val ? 'bg-[#00C26F] text-white' : 'text-[#8DA6C0]'}`}
                  >
                    {lbl}
                  </button>
                ))}
              </div>

              <div className="flex items-center bg-[#1B2736] p-0.5 rounded-lg border border-white/10">
                {([['all', 'All'], ['results', 'Settled'], ['sent', 'Sent']] as const).map(([val, lbl]) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => { setFilter(val); setSettingsDirty(true); }}
                    className={`flex-1 py-1 rounded-md font-bold text-center transition ${filter === val ? 'bg-[#2AABEE] text-white' : 'text-[#8DA6C0]'}`}
                  >
                    {lbl}
                  </button>
                ))}
              </div>
            </div>

            {/* Row: Date + Video Speed */}
            <div className="grid grid-cols-2 gap-1.5">
              <div className="flex flex-col gap-0.5">
                <label className="text-[8px] text-[#8DA6C0] font-bold uppercase">Target Date</label>
                <input
                  type="date"
                  aria-label="Replay date"
                  value={selectedDate}
                  onChange={(e) => { setSelectedDate(e.target.value); setSettingsDirty(true); }}
                  className="w-full bg-[#1B2736] border border-white/15 rounded-lg px-2 py-1.5 text-white font-mono text-[10px] outline-none"
                />
              </div>

              <div className="flex flex-col gap-0.5">
                <label className="text-[8px] text-[#8DA6C0] font-bold uppercase">Video Pacing</label>
                <select
                  aria-label="Video Speed"
                  value={durationSec}
                  onChange={(e) => {
                    const mode = Number(e.target.value) as 20 | 30 | 45 | 60 | 75;
                    setDurationSec(mode);
                    if (videoMode !== 'unboxing_reveal') {
                      setVideoMode(mode === 20 ? 'trailer_status' : 'full_breakdown');
                    }
                    setVoiceSpeed(mode === 20 ? 1.02 : mode === 75 ? 0.88 : mode === 60 ? 1.0 : mode === 45 ? 1.04 : 1.10);
                    setSettingsDirty(true);
                  }}
                  className="w-full bg-[#1B2736] border border-cyan-400/40 rounded-lg px-2 py-1.5 text-cyan-200 font-bold outline-none"
                >
                  <option value={20}>🔥 15–30s Viral Trailer</option>
                  <option value={30}>⚡ 30s Fast Shorts</option>
                  <option value={45}>▶️ 1.0x Normal Speed</option>
                  <option value={60}>🚶 0.85x Slow &amp; Clear</option>
                  <option value={75}>🐢 0.7x Ultra Slow</option>
                </select>
              </div>
            </div>

            {/* Row: Voice Speed + Language */}
            <div className="grid grid-cols-2 gap-1.5">
              <div className="flex flex-col gap-0.5">
                <label className="text-[8px] text-[#8DA6C0] font-bold uppercase">Voice Energy / Speed</label>
                <select
                  value={voiceSpeed}
                  onChange={(e) => { setVoiceSpeed(Number(e.target.value)); setSettingsDirty(true); }}
                  className="w-full bg-[#1B2736] border border-white/15 rounded-lg px-2 py-1.5 text-white font-bold outline-none"
                >
                  <option value={1.18}>🔥 1.18x Ultra Aggressive</option>
                  <option value={1.14}>⚡ 1.14x Fast &amp; Confident</option>
                  <option value={1.02}>✅ 1.02x Balanced (Status)</option>
                  <option value={1.0}>▶️ 1.0x Normal</option>
                  <option value={0.92}>🚶 0.92x Calm Human</option>
                  <option value={0.84}>🐢 0.84x Very Slow</option>
                </select>
              </div>

              <div className="flex flex-col gap-0.5">
                <label className="text-[8px] text-[#8DA6C0] font-bold uppercase">Voice Language</label>
                <select
                  aria-label="Voice Language"
                  value={voiceLang}
                  onChange={(e) => { setVoiceLang(e.target.value as any); setSettingsDirty(true); }}
                  className="w-full bg-[#1B2736] border border-white/15 rounded-lg px-2 py-1.5 text-white font-bold outline-none"
                >
                  <option value="hinglish">Hindi Voice + Hinglish</option>
                  <option value="hindi">Pure Hindi</option>
                  <option value="english">English</option>
                </select>
              </div>
            </div>

            {/* Row: Viral Hook + Theme + Music */}
            <div className="grid grid-cols-3 gap-1.5">
              <div className="flex flex-col gap-0.5">
                <label className="text-[8px] text-[#8DA6C0] font-bold uppercase">Intro Hook</label>
                <select
                  aria-label="Viral Hook Style"
                  value={hookStyle}
                  onChange={(e) => { setHookStyle(e.target.value as any); setSettingsDirty(true); }}
                  className="w-full bg-[#1B2736] border border-amber-400/40 rounded-lg px-1.5 py-1.5 text-amber-300 font-bold outline-none"
                >
                  <option value="auto_viral">🔥 Auto Viral</option>
                  <option value="hook_e">🚨 Stop Scroll</option>
                  <option value="hook_a">⚡ Ek Minute</option>
                  <option value="hook_b">🎙️ YouTuber</option>
                  <option value="hook_c">📢 TG/WA Live</option>
                  <option value="hook_d">🎬 Cinematic</option>
                </select>
              </div>

              <div className="flex flex-col gap-0.5">
                <label className="text-[8px] text-[#8DA6C0] font-bold uppercase">3D Theme</label>
                <select
                  aria-label="Video Theme"
                  value={style}
                  onChange={(e) => { setStyle(e.target.value as any); setSettingsDirty(true); }}
                  className="w-full bg-[#1B2736] border border-white/15 rounded-lg px-1.5 py-1.5 text-white font-bold outline-none"
                >
                  <option value="cyber_neon">Cyber Neon</option>
                  <option value="gold_royal">Gold Royal</option>
                  <option value="emerald_matrix">Emerald</option>
                </select>
              </div>

              <div className="flex flex-col gap-0.5">
                <label className="text-[8px] text-[#8DA6C0] font-bold uppercase">BG Music</label>
                <select
                  aria-label="Background Music"
                  value={musicStyle}
                  onChange={(e) => { setMusicStyle(e.target.value as any); setSettingsDirty(true); }}
                  className="w-full bg-[#1B2736] border border-white/15 rounded-lg px-1.5 py-1.5 text-white font-bold outline-none"
                >
                  <option value="cinematic_bass">🎵 Bass</option>
                  <option value="lofi_chill">🎵 Lo-Fi</option>
                  <option value="upbeat_synth">🎵 Synth</option>
                  <option value="off">🔇 Off</option>
                </select>
              </div>
            </div>

            {/* Row: Upload Custom Voice Sample + Custom Brand Title & CTA */}
            <div className="pt-1 border-t border-white/10 space-y-1.5">
              <label className="w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-purple-500/20 border border-purple-400/40 text-purple-200 font-bold cursor-pointer hover:bg-purple-500/30 text-center">
                <Mic className="w-3.5 h-3.5 text-purple-300 shrink-0" />
                <span className="truncate">{voiceSampleName ? `🎙️ Matched Voice: ${voiceSampleName}` : '🎙️ Upload My Voice Recording (.mp3 / .wav / .m4a)'}</span>
                <input type="file" accept="audio/*,video/*" onChange={(e) => void handleVoiceSampleFile(e)} className="hidden" />
              </label>

              <div className="grid grid-cols-2 gap-1.5">
                <input
                  type="text"
                  placeholder="Custom Brand Name (TITAN NOVA)"
                  value={customTitle}
                  onChange={(e) => { setCustomTitle(e.target.value); setSettingsDirty(true); }}
                  className="w-full bg-[#1B2736] border border-white/15 rounded-lg px-2 py-1.5 text-white outline-none text-[10px]"
                />
                <input
                  type="text"
                  placeholder="Custom Outro CTA"
                  value={customCta}
                  onChange={(e) => { setCustomCta(e.target.value); setSettingsDirty(true); }}
                  className="w-full bg-[#1B2736] border border-white/15 rounded-lg px-2 py-1.5 text-white outline-none text-[10px]"
                />
              </div>
            </div>

            {/* Single Social Media Description Generator (FB / YT / IG / WA) */}
            <div className="pt-2 border-t border-white/10 space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] font-black uppercase tracking-wide text-sky-300">
                  📝 Social Media Description (FB / YT / IG / WA)
                </span>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setSocialDescription(generateSocialDescriptionText(videoSummary))}
                    className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-[10px] font-bold text-white/80"
                    title="Regenerate description"
                  >
                    ↻ Refresh
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleCopyDescription()}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-black transition ${
                      descCopied
                        ? "bg-emerald-500 text-slate-950"
                        : "bg-sky-500/25 border border-sky-400/40 text-sky-200 hover:bg-sky-500/35"
                    }`}
                  >
                    {descCopied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    {descCopied ? "Copied!" : "Copy Caption"}
                  </button>
                </div>
              </div>
              <textarea
                rows={4}
                value={socialDescription}
                onChange={(e) => setSocialDescription(e.target.value)}
                placeholder="Facebook Reels, YouTube Shorts, Instagram ya WhatsApp ke liye ready description..."
                className="w-full bg-[#1B2736] border border-white/15 rounded-xl px-2.5 py-2 text-white/95 outline-none text-[10px] leading-relaxed resize-y"
              />
            </div>
          </div>
        </div>

        {/* 3. STICKY BOTTOM ACTION FOOTER (Always pinned & visible on Android!) */}
        <div className="shrink-0 p-2.5 border-t border-white/10 bg-[#172230] space-y-2">
          <button
            type="button"
            disabled={loading}
            onClick={() => void buildVideo()}
            className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-xl font-black text-xs shadow-lg transition active:scale-98 disabled:opacity-50 ${
              settingsDirty && videoUrl
                ? 'bg-gradient-to-r from-amber-500 to-rose-500 text-slate-950'
                : 'bg-gradient-to-r from-[#00C26F] to-[#059669] text-white'
            }`}
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" /> Rendering 3D Video…
              </>
            ) : videoUrl ? (
              <>
                <RefreshCw className="w-4 h-4" />
                {settingsDirty ? '🔄 Apply Changes & Regenerate Video' : '🔄 Regenerate 3D Video'}
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" /> 🎬 START 3D VIDEO GENERATION (CREATE MP4)
              </>
            )}
          </button>

          {videoUrl && (
            <>
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  disabled={!videoUrl || loading}
                  onClick={handleDownload}
                  className="flex items-center justify-center gap-1.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-bold text-white disabled:opacity-40"
                >
                  <Download className="w-3.5 h-3.5" /> Download MP4
                </button>
                <button
                  type="button"
                  disabled={!videoBlob || loading}
                  onClick={() => void handleNativeShare()}
                  className="flex items-center justify-center gap-1.5 py-2 rounded-xl bg-[#2AABEE] hover:bg-[#229ED9] text-xs font-bold text-white disabled:opacity-40"
                >
                  <Share2 className="w-3.5 h-3.5" /> Share Story / Status
                </button>
              </div>

              {isMaster && (
                <div className="flex items-center gap-1.5">
                  <label className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-white/5 border border-white/10 text-[10px] font-bold text-[#8DA6C0] cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={sendAsLoopingGif}
                      onChange={(e) => setSendAsLoopingGif(e.target.checked)}
                      className="rounded accent-[#00C26F]"
                    />
                    Loop GIF
                  </label>
                  <button
                    type="button"
                    disabled={!videoBase64 || loading || sendingBot}
                    onClick={() => void handleSendViaBot()}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-gradient-to-r from-[#00C26F] to-[#059669] text-[11px] font-black text-white disabled:opacity-40 shadow-md"
                  >
                    <Send className="w-3.5 h-3.5" />
                    {sendingBot ? 'Sending…' : 'Send to WhatsApp / Telegram Bot'}
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
