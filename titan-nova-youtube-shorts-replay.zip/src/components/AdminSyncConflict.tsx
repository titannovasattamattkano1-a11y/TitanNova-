import {useEffect,useState,useRef} from 'react';
/** Display only a real save conflict; retain the local snapshot for explicit download. */
export function AdminSyncConflict(){
 const [conflict,setConflict]=useState<{backup:string;paths:string[];fingerprint?:string}|null>(null);
 const dismissed=useRef(new Set<string>());
 useEffect(()=>{const onConflict=(event:Event)=>{const detail=(event as CustomEvent).detail;if(detail?.backup&&!dismissed.current.has(detail.fingerprint||detail.backup))setConflict(previous=>previous||detail);};window.addEventListener('titan-admin-conflict',onConflict);return()=>window.removeEventListener('titan-admin-conflict',onConflict);},[]);
 if(!conflict)return null;
 const download=()=>{const url=URL.createObjectURL(new Blob([conflict.backup],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='titan-admin-conflict-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
 return <aside role="alert" style={{position:'fixed',bottom:80,left:12,right:12,zIndex:10000,background:'#422006',color:'#fff',padding:14,borderRadius:12,border:'1px solid #f59e0b'}}>
  <strong>Same data was updated elsewhere.</strong>
  <p>The saved server version was kept for conflicting items. Other edits continue syncing. Your local backup is available below.</p>
  <button onClick={download} style={{padding:8,textDecoration:'underline'}}>Download local backup</button>
  <button onClick={()=>{dismissed.current.add(conflict.fingerprint||conflict.backup);if(dismissed.current.size>64)dismissed.current.delete(dismissed.current.values().next().value!);setConflict(null);}} style={{padding:8}}>Dismiss</button>
 </aside>;
}
