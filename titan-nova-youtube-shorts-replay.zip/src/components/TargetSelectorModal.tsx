import { apiUrl } from '../utils/api';
import React, { useState, useEffect, useRef } from 'react';
import { Users, User, Plus, Check, X, RefreshCw, Smartphone, Trash2, Radio } from 'lucide-react';
import { normalizeTargetJid } from '../utils/targetNormalization';
import { isGroupTarget, isChannelTarget } from '../utils/targetNormalization';
import { telegramApi } from '../utils/telegramApi';

interface GroupChat {
  jid: string;
  name: string;
  size?: number;
}

interface ContactChat {
  jid: string;
  name: string;
  phone?: string;
}

interface ChannelChat {
  jid: string;
  name: string;
}

interface TargetSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedTargets: string[];
  onSaveTargets: (targets: string[]) => void;
  marketName?: string;
  incomeSourceOnly?: boolean;
  channelPickerOnly?: boolean;
  showChannels?: boolean;
  platformOnly?: 'whatsapp' | 'telegram';
  singleSelect?: boolean;
}

export const TargetSelectorModal: React.FC<TargetSelectorModalProps> = ({
  isOpen,
  onClose,
  selectedTargets,
  onSaveTargets,
  marketName,
  incomeSourceOnly = false,
  channelPickerOnly = false,
  showChannels = true,
  platformOnly,
  singleSelect = false,
}) => {
  const [platform, setPlatform] = useState<'whatsapp' | 'telegram'>(platformOnly || 'whatsapp');
  const [fetchError, setFetchError] = useState('');
  const platformLabel = platform === 'telegram' ? 'Telegram' : 'WhatsApp';
  const platformRef = useRef(platform);
  platformRef.current = platform;
  const fetchIdRef = useRef(0);
  const inFlightRef = useRef(0);
  const [activeTab, setActiveTab] = useState<'groups' | 'channels' | 'contacts' | 'manual'>('groups');
  const [syncedGroups, setSyncedGroups] = useState<GroupChat[]>([]);
  const [syncedChannels, setSyncedChannels] = useState<ChannelChat[]>([]);
  const [syncedContacts, setSyncedContacts] = useState<ContactChat[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(null);
  
  const [localTargets, setLocalTargets] = useState<string[]>([]);
  const [customInput, setCustomInput] = useState('');

  useEffect(() => {
    if (isOpen) {
      setLocalTargets([...selectedTargets]);
      setPlatform(platformOnly || (selectedTargets[0]?.startsWith('tg:') ? 'telegram' : 'whatsapp'));
    }
  }, [isOpen]);

  useEffect(() => {
    if (isOpen) void fetchSyncedChats(true);
    return () => {
      ++fetchIdRef.current;
      inFlightRef.current = 0;
    };
  }, [isOpen, platform]);

  useEffect(() => {
    if (!isOpen) return;
    setActiveTab(channelPickerOnly ? 'channels' : 'groups');
  }, [isOpen, channelPickerOnly]);

  useEffect(() => {
    if (!isOpen) return;
    const interval = window.setInterval(() => void fetchSyncedChats(), 3000);
    return () => window.clearInterval(interval);
  }, [isOpen, incomeSourceOnly, channelPickerOnly, showChannels, platform]);

  const fetchSyncedChats = async (showLoading = false) => {
    // Background refresh must keep the list mounted while the user selects or scrolls.
    if (!showLoading && inFlightRef.current) return;
    const fetchId = ++fetchIdRef.current;
    inFlightRef.current = fetchId;
    try {
      if (showLoading) { setIsLoading(true); setFetchError(''); }
      const json = platform === 'telegram' ? await telegramApi('chats') : await (await fetch(apiUrl('/api/bot/chats'))).json();
      if (platformRef.current !== platform || fetchId !== fetchIdRef.current) return;
      if (json.status !== 'success' || !json.chats) throw new Error(json.message || 'Chat sync failed');
      if (json.status === 'success' && json.chats) {
        setFetchError('');
        setSyncedGroups(json.chats.groups || []);
        setSyncedChannels(json.chats.channels || []);
        setSyncedContacts(json.chats.contacts || []);
        setLastSyncTime(json.chats.lastSync ? new Date(json.chats.lastSync).toLocaleTimeString() : null);
      }
    } catch (e: any) {
      if (platformRef.current !== platform || fetchId !== fetchIdRef.current) return;
      // A temporary refresh failure must not erase visible chats or selection.
      if (showLoading) { setSyncedGroups([]); setSyncedChannels([]); setSyncedContacts([]); }
      setFetchError(e.message || 'Chat sync failed');
    } finally {
      if (fetchId === fetchIdRef.current) { inFlightRef.current = 0; setIsLoading(false); }
    }
  };

  if (!isOpen) return null;

  const refreshList = async () => {
    try { if (platform === 'telegram') await telegramApi('sync', {}); await fetchSyncedChats(); }
    catch (e: any) { setFetchError(e.message); }
  };

  const toggleTarget = (targetJid: string) => {
    if (localTargets.includes(targetJid)) {
      setLocalTargets(localTargets.filter((t) => t !== targetJid));
    } else {
      setLocalTargets(singleSelect ? [targetJid] : [...localTargets, targetJid]);
    }
  };

  const handleAddCustom = async () => {
    const raw = customInput.trim();
    if (platform === 'telegram') {
      const known = [...syncedGroups, ...syncedChannels, ...syncedContacts].find(c => c.jid === raw);
      if (!known || (incomeSourceOnly && !isGroupTarget(raw) && !isChannelTarget(raw)) || (channelPickerOnly && !isChannelTarget(raw))) {
        setFetchError('Select a synced Telegram chat. Login and Sync in Telegram gateway first.'); return;
      }
      setLocalTargets(current => singleSelect ? [raw] : [...new Set([...current, raw])]); setCustomInput(''); return;
    }
    if (/^(?:https?:\/\/)?(?:www\.)?whatsapp\.com\/channel\//i.test(raw)) {
      try {
        const res = await fetch(apiUrl('/api/bot/resolve_channel'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ channelLink: raw }),
        });
        const json = await res.json();
        if (!res.ok || json.status !== 'success') throw new Error(json.message || 'Channel resolve request failed');
        setCustomInput('');
        window.setTimeout(() => void fetchSyncedChats(), 1500);
      } catch (error: any) {
        alert(error?.message || 'Channel link resolve nahi hua. Bot connection check karein.');
      }
      return;
    }
    const clean = normalizeTargetJid(customInput);
    if (!clean) return;
    if (channelPickerOnly && !isChannelTarget(clean)) return;
    if (incomeSourceOnly && !isGroupTarget(clean) && !isChannelTarget(clean)) return;
    if (!localTargets.includes(clean)) {
      setLocalTargets(singleSelect ? [clean] : [...localTargets, clean]);
    }
    if (clean.endsWith('@newsletter')) {
      fetch(apiUrl('/api/bot/resolve_channel'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ channelLink: clean }),
      }).then(() => {
        window.setTimeout(() => void fetchSyncedChats(), 1000);
      }).catch(() => null);
    }
    setCustomInput('');
  };

  const selectAllGroups = () => {
    const groupJids = syncedGroups.map((g) => g.jid);
    const merged = Array.from(new Set([...localTargets, ...groupJids]));
    setLocalTargets(merged);
  };

  const clearAll = () => {
    setLocalTargets([]);
  };

  const handleSave = () => {
    onSaveTargets(localTargets);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-[#1C2733] border border-[rgba(255,255,255,0.1)] rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[rgba(255,255,255,0.08)] bg-[#17212B]">
          <div>
            <h3 className="text-white font-black text-sm uppercase tracking-wider flex items-center gap-2">
              <Users className="w-4 h-4 text-[#2AABEE]" /> {platformLabel} Target Selector
            </h3>
            <p className="text-[11px] text-[#7A9CB8]">
              {channelPickerOnly
                ? `Select ${platformLabel} Channel destination`
                : incomeSourceOnly
                ? 'Select result source Groups or Channels'
                : marketName ? `Targets for ${marketName}` : 'Select Groups/numbers or add a Channel JID manually'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-[#7A9CB8] hover:text-white p-1 rounded-lg hover:bg-[rgba(255,255,255,0.05)] transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {!platformOnly && <div className="flex gap-2 p-3">
          {(['whatsapp', 'telegram'] as const).map(value => <button key={value} type="button" onClick={() => { setPlatform(value); setSyncedGroups([]); setSyncedChannels([]); setSyncedContacts([]); }} className={`flex-1 rounded-xl p-2 text-sm font-bold ${platform === value ? 'bg-[#2AABEE] text-white' : 'bg-[#2B3A4D] text-[#7A9CB8]'}`}>{value === 'whatsapp' ? 'WhatsApp' : 'Telegram'}</button>)}
        </div>}
        {fetchError && <p role="alert" className="text-xs text-red-400 px-4 py-2">{fetchError}</p>}
        {/* Selected Targets Summary Bar */}
        <div className="bg-[#2B3A4D] px-4 py-2.5 border-b border-[rgba(255,255,255,0.06)] flex items-center justify-between">
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar max-w-[70%]">
            <span className="text-[10px] font-black uppercase text-[#00C26F] shrink-0">
              Selected ({localTargets.length}):
            </span>
            {localTargets.length === 0 ? (
              <span className="text-[10px] text-[#7A9CB8] italic">No targets selected</span>
            ) : (
              localTargets.map((t, idx) => (
                <span
                  key={idx}
                  className="inline-flex items-center gap-1 text-[9px] font-mono font-bold bg-[#17212B] text-[#2AABEE] border border-[#2AABEE]/30 px-2 py-0.5 rounded-full shrink-0"
                >
                  {t.length > 18 ? `${t.substring(0, 15)}...` : t}
                  <X
                    className="w-3 h-3 text-[#FF5D5D] cursor-pointer hover:scale-125"
                    onClick={() => toggleTarget(t)}
                  />
                </span>
              ))
            )}
          </div>

          <div className="flex gap-2 shrink-0">
            {!singleSelect && syncedGroups.length > 0 && (
              <button
                onClick={selectAllGroups}
                className="text-[9px] font-bold text-[#2AABEE] bg-[rgba(42,171,238,0.12)] border border-[rgba(42,171,238,0.3)] px-2 py-1 rounded-lg hover:bg-[#2AABEE] hover:text-white transition-all"
              >
                + Select All Groups
              </button>
            )}
            {localTargets.length > 0 && (
              <button
                onClick={clearAll}
                className="text-[9px] font-bold text-[#FF5D5D] bg-[rgba(255,93,93,0.12)] border border-[rgba(255,93,93,0.3)] px-2 py-1 rounded-lg hover:bg-[#FF5D5D] hover:text-white transition-all"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Tabs */}
        {(() => {
          const showGroupsTab = !channelPickerOnly;
          const showChannelsTab = platform === 'telegram' || incomeSourceOnly || channelPickerOnly || showChannels;
          const showContactsTab = !incomeSourceOnly && !channelPickerOnly;
          const tabCount = (showGroupsTab ? 1 : 0) + (showChannelsTab ? 1 : 0) + (showContactsTab ? 1 : 0) + 1;
          const gridColsClass = tabCount === 4 ? 'grid-cols-4' : tabCount === 3 ? 'grid-cols-3' : 'grid-cols-2';
          return (
        <div className={`grid ${gridColsClass} bg-[#17212B] p-1.5 gap-1 border-b border-[rgba(255,255,255,0.06)]`}>
          {!channelPickerOnly && (
          <button
            onClick={() => setActiveTab('groups')}
            className={`py-2 text-xs font-black uppercase rounded-xl flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'groups'
                ? 'bg-[#2AABEE] text-white shadow-md'
                : 'text-[#7A9CB8] hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" /> Groups ({syncedGroups.length})
          </button>
          )}
          {(platform === 'telegram' || incomeSourceOnly || channelPickerOnly || showChannels) && (
            <button
              onClick={() => setActiveTab('channels')}
              className={`py-2 text-xs font-black uppercase rounded-xl flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'channels'
                  ? 'bg-[#7B8FFF] text-white shadow-md'
                  : 'text-[#7A9CB8] hover:text-white'
              }`}
            >
              <Radio className="w-3.5 h-3.5" /> Channels ({syncedChannels.length})
            </button>
          )}
          {!incomeSourceOnly && !channelPickerOnly && (
          <button
            onClick={() => setActiveTab('contacts')}
            className={`py-2 text-xs font-black uppercase rounded-xl flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'contacts'
                ? 'bg-[#2AABEE] text-white shadow-md'
                : 'text-[#7A9CB8] hover:text-white'
            }`}
          >
            <User className="w-3.5 h-3.5" /> Contacts ({syncedContacts.length})
          </button>
          )}
          <button
            onClick={() => setActiveTab('manual')}
            className={`py-2 text-xs font-black uppercase rounded-xl flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'manual'
                ? 'bg-[#2AABEE] text-white shadow-md'
                : 'text-[#7A9CB8] hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" /> {channelPickerOnly ? 'Channel JID' : incomeSourceOnly ? 'Group / Channel JID' : 'Phone / JID'}
          </button>
        </div>
          );
        })()}

        {/* Tab Content */}
        <div className="p-4 flex-1 overflow-y-auto min-h-[220px]">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-10 space-y-2 text-[#7A9CB8]">
              <RefreshCw className="w-6 h-6 animate-spin text-[#2AABEE]" />
              <p className="text-xs font-bold">Loading {platformLabel} Groups, Channels & Contacts...</p>
            </div>
          ) : activeTab === 'groups' ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[10px] text-[#7A9CB8] mb-1">
                <span>{platformLabel} Groups synced from account:</span>
                <button
                  onClick={() => void refreshList()}
                  className="flex items-center gap-1 text-[#2AABEE] hover:underline"
                >
                  <RefreshCw className="w-3 h-3" /> Refresh List
                </button>
              </div>

              {syncedGroups.length === 0 ? (
                <div className="text-center py-8 bg-[#2B3A4D]/50 border border-dashed border-[rgba(255,255,255,0.1)] rounded-xl space-y-2">
                  <p className="text-xs font-bold text-white">No {platformLabel} Groups Synced Yet</p>
                  <p className="text-[11px] text-[#7A9CB8] max-w-xs mx-auto">
                    Connect and sync your {platformLabel} account in Gateways.
                  </p>
                </div>
              ) : (
                syncedGroups.map((group) => {
                  const isSelected = localTargets.includes(group.jid);
                  return (
                    <div
                      key={group.jid}
                      onClick={() => toggleTarget(group.jid)}
                      className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-[#2AABEE]/20 border-[#2AABEE] text-white'
                          : 'bg-[#2B3A4D] border-[rgba(255,255,255,0.06)] text-[#7A9CB8] hover:border-[rgba(255,255,255,0.2)]'
                      }`}
                    >
                      <div className="flex items-center gap-3 overflow-hidden">
                        <div
                          className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 font-bold text-xs ${
                            isSelected ? 'bg-[#2AABEE] text-white' : 'bg-[#17212B] text-[#2AABEE]'
                          }`}
                        >
                          <Users className="w-4 h-4" />
                        </div>
                        <div className="overflow-hidden">
                          <p className="text-xs font-bold text-white truncate">{group.name}</p>
                          <p className="text-[10px] font-mono text-[#7A9CB8] truncate">
                            {group.jid} {group.size ? `• ${group.size} members` : ''}
                          </p>
                        </div>
                      </div>

                      <div
                        className={`w-5 h-5 rounded-md border flex items-center justify-center transition-all ${
                          isSelected
                            ? 'bg-[#00C26F] border-[#00C26F] text-white'
                            : 'border-[rgba(255,255,255,0.2)] bg-[#17212B]'
                        }`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          ) : activeTab === 'channels' ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[10px] text-[#7A9CB8] mb-1">
                <span>{platformLabel} Channels synced from account:</span>
                <button onClick={() => void refreshList()} className="flex items-center gap-1 text-[#7B8FFF] hover:underline">
                  <RefreshCw className="w-3 h-3" /> Refresh List
                </button>
              </div>

              {/* Quick Add Channel link / JID directly inside Channels tab */}
              <div className="flex gap-2 bg-[#17212B] p-2 rounded-xl border border-[rgba(255,255,255,0.06)]">
                <input
                  type="text"
                  value={customInput}
                  onChange={(e) => setCustomInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && void handleAddCustom()}
                  placeholder={platform === 'telegram' ? 'Paste tg:channel:... ID' : 'Channel link (whatsapp.com/channel/...) ya @newsletter'}
                  className="flex-1 bg-[#2B3A4D] text-white text-xs border border-[rgba(255,255,255,0.1)] rounded-lg px-3 py-1.5 font-mono outline-none focus:border-[#7B8FFF]"
                />
                <button
                  type="button"
                  onClick={() => void handleAddCustom()}
                  className="bg-[#7B8FFF] hover:bg-[#687CE6] text-white px-3 py-1.5 rounded-lg font-black text-xs uppercase flex items-center gap-1 active:scale-95 transition-all shadow-md shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" /> Add
                </button>
              </div>
              {syncedChannels.length === 0 ? (
                <div className="text-center py-8 bg-[#2B3A4D]/50 border border-dashed border-[rgba(255,255,255,0.1)] rounded-xl space-y-2">
                  <p className="text-xs font-bold text-white">No {platformLabel} Channels Synced Yet</p>
                  <p className="text-[11px] text-[#7A9CB8] max-w-xs mx-auto">
                    {platform === 'telegram' ? 'Telegram gateway mein login karke Sync dabayein.' : 'WhatsApp Channel link paste karke Channel sync karein.'}
                  </p>
                  <button
                    onClick={() => setActiveTab('manual')}
                    className="px-3 py-2 rounded-lg bg-[#7B8FFF] text-white text-[10px] font-black uppercase"
                  >
                    Add Channel Link
                  </button>
                </div>
              ) : (
                syncedChannels.map((channel) => {
                  const isSelected = localTargets.includes(channel.jid);
                  return (
                    <div
                      key={channel.jid}
                      onClick={() => toggleTarget(channel.jid)}
                      className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-[#7B8FFF]/20 border-[#7B8FFF] text-white'
                          : 'bg-[#2B3A4D] border-[rgba(255,255,255,0.06)] text-[#7A9CB8] hover:border-[rgba(255,255,255,0.2)]'
                      }`}
                    >
                      <div className="flex items-center gap-3 overflow-hidden">
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${isSelected ? 'bg-[#7B8FFF] text-white' : 'bg-[#17212B] text-[#7B8FFF]'}`}>
                          <Radio className="w-4 h-4" />
                        </div>
                        <div className="overflow-hidden">
                          <p className="text-xs font-bold text-white truncate">{channel.name}</p>
                          <p className="text-[10px] font-mono text-[#7A9CB8] truncate">{channel.jid}</p>
                        </div>
                      </div>
                      <div className={`w-5 h-5 rounded-md border flex items-center justify-center ${isSelected ? 'bg-[#00C26F] border-[#00C26F] text-white' : 'border-[rgba(255,255,255,0.2)] bg-[#17212B]'}`}>
                        {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          ) : activeTab === 'contacts' ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[10px] text-[#7A9CB8] mb-1">
                <span>{platformLabel} Chats / Contacts:</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={async () => {
                      if ('contacts' in navigator && 'select' in (navigator as any).contacts) {
                        try {
                          const contacts = await (navigator as any).contacts.select(['name', 'tel'], { multiple: true });
                          if (contacts && contacts.length > 0) {
                            for (const c of contacts) {
                              const tel = c.tel?.[0] || '';
                              const clean = tel.replace(/\D/g, '');
                              if (clean) toggleTarget(clean);
                            }
                          }
                        } catch (err) {
                          // cancelled or failed
                        }
                      } else {
                        alert('Device phonebook picker is not supported on this browser. You can type numbers in the "Phone / JID" tab!');
                      }
                    }}
                    className="flex items-center gap-1 text-[#FAC748] hover:underline font-bold"
                  >
                    <Smartphone className="w-3 h-3" /> Pick Phonebook Contact
                  </button>
                  <button
                    onClick={() => void refreshList()}
                    className="flex items-center gap-1 text-[#2AABEE] hover:underline"
                  >
                    <RefreshCw className="w-3 h-3" /> Refresh
                  </button>
                </div>
              </div>

              {syncedContacts.length === 0 ? (
                <div className="text-center py-8 bg-[#2B3A4D]/50 border border-dashed border-[rgba(255,255,255,0.1)] rounded-xl space-y-2">
                  <p className="text-xs font-bold text-white">No Contacts Synced Yet</p>
                  <p className="text-[11px] text-[#7A9CB8]">
                    Connect and sync your {platformLabel} account first.
                  </p>
                </div>
              ) : (
                syncedContacts.map((contact) => {
                  const isSelected = localTargets.includes(contact.jid);
                  return (
                    <div
                      key={contact.jid}
                      onClick={() => toggleTarget(contact.jid)}
                      className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-[#2AABEE]/20 border-[#2AABEE] text-white'
                          : 'bg-[#2B3A4D] border-[rgba(255,255,255,0.06)] text-[#7A9CB8] hover:border-[rgba(255,255,255,0.2)]'
                      }`}
                    >
                      <div className="flex items-center gap-3 overflow-hidden">
                        <div
                          className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 font-bold text-xs ${
                            isSelected ? 'bg-[#2AABEE] text-white' : 'bg-[#17212B] text-[#2AABEE]'
                          }`}
                        >
                          <User className="w-4 h-4" />
                        </div>
                        <div className="overflow-hidden">
                          <p className="text-xs font-bold text-white truncate">{contact.name}</p>
                          <p className="text-[10px] font-mono text-[#7A9CB8] truncate">
                            {contact.phone || contact.jid}
                          </p>
                        </div>
                      </div>

                      <div
                        className={`w-5 h-5 rounded-md border flex items-center justify-center transition-all ${
                          isSelected
                            ? 'bg-[#00C26F] border-[#00C26F] text-white'
                            : 'border-[rgba(255,255,255,0.2)] bg-[#17212B]'
                        }`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-[#2B3A4D] p-3.5 rounded-xl border border-[rgba(255,255,255,0.08)] space-y-3">
                <label className="text-xs font-bold text-white block">
                  {platform === 'telegram' ? 'Select a synced Telegram chat or paste its displayed ID' : channelPickerOnly ? 'Add WhatsApp Channel' : incomeSourceOnly ? 'Add Group or Channel JID' : 'Add Phone, Group, or Channel JID'}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customInput}
                    onChange={(e) => setCustomInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && void handleAddCustom()}
                    placeholder={channelPickerOnly ? 'Channel link / ...@newsletter' : incomeSourceOnly ? 'Channel link / ...@g.us / ...@newsletter' : '91... / ...@g.us / ...@newsletter'}
                    className="flex-1 bg-[#17212B] text-white text-xs border border-[rgba(255,255,255,0.1)] rounded-xl px-3 py-2.5 font-mono outline-none focus:border-[#2AABEE]"
                  />
                  <button
                    onClick={() => void handleAddCustom()}
                    className="bg-[#2AABEE] text-white px-4 rounded-xl font-black text-xs uppercase flex items-center gap-1 active:scale-95 transition-all shadow-md"
                  >
                    <Plus className="w-4 h-4" /> Add
                  </button>
                </div>
                <p className="text-[10px] text-[#7A9CB8]">
                  {platform === 'telegram' ? 'Telegram IDs phone numbers nahi hain. Synced list se destination select karein.' : channelPickerOnly ? <>Synced Channel select karein, ya WhatsApp Channel link / <code className="text-[#7B8FFF]">@newsletter</code> JID paste karein.</> : incomeSourceOnly ? <>WhatsApp Channel link, Group <code className="text-[#2AABEE]">@g.us</code>, ya Channel <code className="text-[#7B8FFF]">@newsletter</code> JID paste karein.</> : <>Phone ke liye country code use karein; Group <code className="text-[#2AABEE]">@g.us</code> aur Channel <code className="text-[#7B8FFF]">@newsletter</code> JID exact paste karein.</>}
                </p>
              </div>

              {/* Added Custom Items List */}
              <div className="space-y-2">
                <p className="text-[10px] font-bold text-[#7A9CB8] uppercase tracking-wider">
                  Currently Added Targets ({localTargets.length}):
                </p>
                {localTargets.length === 0 ? (
                  <p className="text-xs text-[#7A9CB8] italic">No targets selected yet.</p>
                ) : (
                  localTargets.map((t, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between bg-[#2B3A4D] p-2.5 rounded-xl border border-[rgba(255,255,255,0.06)]"
                    >
                      <span className="text-xs font-mono font-bold text-white">{t}</span>
                      <button
                        onClick={() => toggleTarget(t)}
                        className="text-[#FF5D5D] hover:text-white p-1 rounded-lg"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#17212B] border-t border-[rgba(255,255,255,0.08)] flex justify-between items-center">
          <div className="text-[10px] text-[#7A9CB8]">
            {lastSyncTime && `Synced: ${lastSyncTime}`}
          </div>
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-bold text-[#7A9CB8] hover:text-white uppercase transition-all"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="bg-[#00C26F] text-white px-5 py-2.5 rounded-xl text-xs font-black uppercase flex items-center gap-1.5 active:scale-95 transition-all shadow-lg shadow-[rgba(0,194,111,0.3)]"
            >
              <Check className="w-4 h-4" /> Save {localTargets.length} Target(s)
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
