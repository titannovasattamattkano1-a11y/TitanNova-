import React from 'react';
import { UserProfile } from '../types';
import { BASE_MARKETS } from '../data/markets';
import { Eye, ShieldAlert, Save } from 'lucide-react';

interface SettingsViewProps {
  profile: UserProfile;
  isMaster: boolean;
  vipCanEdit: boolean;
  currentDate: string;
  onToggleMarketVis: (trackDict: 'visAnk' | 'visJodi' | 'visPan', mName: string, checked: boolean) => void;
  onToggleAllOpenClose: (trackDict: 'visAnk' | 'visPan', checked: boolean) => void;
  onToggleAllJodi: (checked: boolean) => void;
  onSave: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  profile,
  isMaster,
  vipCanEdit,
  currentDate,
  onToggleMarketVis,
  onToggleAllOpenClose,
  onToggleAllJodi,
  onSave,
}) => {
  const dayRecord = profile?.dayRecords?.[currentDate] || {};
  const canEdit = isMaster || vipCanEdit;

  const renderOpenCloseMarketGroup = (title: string, colorClass: string, trackDict: 'visAnk' | 'visPan') => {
    const recordDict = dayRecord[trackDict] || {};
    const isAllChecked = BASE_MARKETS.every(bm => {
      return recordDict[bm.n + ' OPEN'] !== false && recordDict[bm.n + ' CLOSE'] !== false;
    });

    return (
      <div className="native-card bg-[#232E3C] border border-[rgba(255,255,255,0.07)] p-4 rounded-2xl mb-3 shadow-md">
        <div className="flex justify-between items-center mb-3">
          <h3 className={`text-[12px] font-black uppercase tracking-wider flex items-center gap-2 ${colorClass}`}>
            <Eye className="w-4 h-4" /> {title} Visibility
          </h3>
          <div className="flex items-center gap-2 bg-[#2B3A4D] px-2.5 py-1 rounded-xl border border-[rgba(255,255,255,0.07)]">
            <span className="text-[9px] font-bold text-[#7A9CB8] uppercase">ALL</span>
            <label className="switch transform scale-75 m-0 cursor-pointer">
              <input
                type="checkbox"
                disabled={!canEdit}
                checked={isAllChecked}
                onChange={(e) => onToggleAllOpenClose(trackDict, e.target.checked)}
              />
              <span className="slider"></span>
            </label>
          </div>
        </div>

        <div className="flex justify-end gap-5 mb-1.5 pr-1">
          <span className="text-[8px] font-black text-[#2AABEE] uppercase tracking-wider">OPEN</span>
          <span className="text-[8px] font-black text-[#FAC748] uppercase tracking-wider">CLOSE</span>
        </div>

        <div className="space-y-1.5">
          {BASE_MARKETS.map((bm) => {
            const openKey = bm.n + ' OPEN';
            const closeKey = bm.n + ' CLOSE';
            const openOn = recordDict[openKey] !== false;
            const closeOn = recordDict[closeKey] !== false;

            return (
              <div
                key={bm.n}
                className="flex items-center gap-2 bg-[#2B3A4D] px-3 py-2 rounded-xl border border-[rgba(255,255,255,0.07)]"
              >
                <span className="flex-1 text-[10px] font-bold text-[#7A9CB8] uppercase truncate">{bm.n}</span>
                <label className="switch transform scale-[0.6] m-0 cursor-pointer">
                  <input
                    type="checkbox"
                    disabled={!canEdit}
                    checked={openOn}
                    onChange={(e) => onToggleMarketVis(trackDict, openKey, e.target.checked)}
                  />
                  <span className="slider"></span>
                </label>
                <label className="switch transform scale-[0.6] m-0 cursor-pointer">
                  <input
                    type="checkbox"
                    disabled={!canEdit}
                    checked={closeOn}
                    onChange={(e) => onToggleMarketVis(trackDict, closeKey, e.target.checked)}
                  />
                  <span className="slider"></span>
                </label>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const renderJodiMarketGroup = () => {
    const recordDict = dayRecord.visJodi || {};
    const isAllChecked = BASE_MARKETS.every(bm => recordDict[bm.n] !== false);

    return (
      <div className="native-card bg-[#232E3C] border border-[rgba(255,255,255,0.07)] p-4 rounded-2xl mb-3 shadow-md">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-[12px] font-black text-[#B85CFF] uppercase tracking-wider flex items-center gap-2">
            <Eye className="w-4 h-4" /> Jodi Markets Visibility
          </h3>
          <div className="flex items-center gap-2 bg-[#2B3A4D] px-2.5 py-1 rounded-xl border border-[rgba(255,255,255,0.07)]">
            <span className="text-[9px] font-bold text-[#7A9CB8] uppercase">ALL</span>
            <label className="switch transform scale-75 m-0 cursor-pointer">
              <input
                type="checkbox"
                disabled={!canEdit}
                checked={isAllChecked}
                onChange={(e) => onToggleAllJodi(e.target.checked)}
              />
              <span className="slider"></span>
            </label>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {BASE_MARKETS.map((bm) => (
            <div
              key={bm.n}
              className="flex justify-between items-center bg-[#2B3A4D] p-2.5 rounded-xl border border-[rgba(255,255,255,0.07)]"
            >
              <span className="text-[9px] font-bold text-[#7A9CB8] uppercase truncate pr-2">{bm.n}</span>
              <label className="switch transform scale-[0.6] m-0 cursor-pointer">
                <input
                  type="checkbox"
                  disabled={!canEdit}
                  checked={recordDict[bm.n] !== false}
                  onChange={(e) => onToggleMarketVis('visJodi', bm.n, e.target.checked)}
                />
                <span className="slider"></span>
              </label>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="px-3 py-4 space-y-3">
      {!vipCanEdit && !isMaster && (
        <div className="bg-[rgba(255,93,93,0.1)] border border-[rgba(255,93,93,0.25)] rounded-2xl p-3 text-center mb-2">
          <p className="text-[#FF5D5D] text-xs font-black uppercase flex items-center justify-center gap-1">
            <ShieldAlert className="w-4 h-4" /> Read-Only Mode
          </p>
          <p className="text-[#7A9CB8] text-[10px] mt-0.5">Your settings are locked by admin.</p>
        </div>
      )}

      {/* Visibility Groups (Master Admin & Users) */}
      {renderOpenCloseMarketGroup('Ank Markets', 'text-[#2AABEE]', 'visAnk')}
      {renderJodiMarketGroup()}
      {renderOpenCloseMarketGroup('Pan Markets', 'text-[#FAC748]', 'visPan')}

      {(vipCanEdit || isMaster) && (
        <button
          onClick={onSave}
          className="w-full bg-[#00C26F] text-white py-3.5 rounded-2xl font-black text-[12px] uppercase tracking-wide active:scale-95 shadow-lg shadow-[rgba(0,194,111,0.2)] flex items-center justify-center gap-2"
        >
          <Save className="w-4 h-4" /> Save Configuration Settings
        </button>
      )}
    </div>
  );
};
