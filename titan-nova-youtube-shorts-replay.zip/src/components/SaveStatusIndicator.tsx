import { memo, useSyncExternalStore } from 'react';
import type { SaveStatusStore } from '../utils/saveStatusStore';

/** Small, isolated control: long state serialization never makes the whole UI redraw. */
export const SaveStatusIndicator = memo(function SaveStatusIndicator({store, onRetry}: {
  store: SaveStatusStore;
  onRetry: () => void;
}) {
  const {phase, message} = useSyncExternalStore(store.subscribe, store.getSnapshot, store.getSnapshot);
  if (phase === 'saved') return null;
  const failed = phase === 'error';
  return (
    <div role={failed ? 'alert' : 'status'} aria-live={failed ? 'assertive' : 'polite'}
      data-titan-save-status={phase}
      className={`fixed bottom-3 left-3 right-3 sm:left-auto sm:right-4 z-[110] sm:max-w-sm rounded-xl border px-3 py-2 shadow-lg text-xs flex items-center gap-3 ${failed ? 'bg-[#402628] text-white border-red-400/60' : 'bg-[#223446] text-white border-sky-400/40'}`}>
      <div className="min-w-0 flex-1">
        <strong className="block">{failed ? 'Changes not saved' : phase === 'saving' ? 'Saving changes…' : 'Changes waiting to save…'}</strong>
        {failed && <span className="block mt-1 break-words text-white/85">{message || 'Check connection, then retry.'}</span>}
      </div>
      {failed && <button type="button" onClick={onRetry} className="shrink-0 rounded-lg bg-white/15 px-3 py-2 font-bold hover:bg-white/25 focus:outline focus:outline-2 focus:outline-white">Retry</button>}
    </div>
  );
});
