import {PAYMENT_PLANS} from '../utils/manualPayments';
import React, { useState, useRef } from 'react';
import { PaymentRequest, PaymentMethod } from '../types';
import { QrCode, CheckCheck, ShieldAlert, Check, X } from 'lucide-react';

interface PaymentAdminProps {
  payments: PaymentRequest[];
  paymentMethods: PaymentMethod;
  onSavePaymentMethods: (methods: PaymentMethod) => Promise<void>;
  onApprovePayment: (paymentId: string, days: number) => Promise<void>;
  onRejectPayment: (paymentId: string) => Promise<void>;
  onApproveAllSafe: () => Promise<void>;
}

export const PaymentAdmin: React.FC<PaymentAdminProps> = ({
  payments,
  paymentMethods,
  onSavePaymentMethods,
  onApprovePayment,
  onRejectPayment,
  onApproveAllSafe,
}) => {
  const [reviewing,setReviewing]=useState(false);
  const reviewLock=useRef(false);
  const review=async(action:()=>Promise<void>)=>{if(reviewLock.current)return;reviewLock.current=true;setReviewing(true);try{await action();}catch{}finally{reviewLock.current=false;setReviewing(false);}};
  const [upi, setUpi] = useState(paymentMethods?.upi || '');
  const [phone, setPhone] = useState(paymentMethods?.phone || '');
  const [qr, setQr] = useState(paymentMethods?.qr || '');
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');

  const pendingPayments = payments.filter((p) => p.status === 'pending');

  const filteredPayments = payments.filter((p) => {
    if (filter === 'all') return true;
    return p.status === filter;
  });

  const [savingMethods,setSavingMethods]=useState(false);
  const settingsLock=useRef(false);
  const handleSaveMethods=async()=>{
    if(settingsLock.current)return;settingsLock.current=true;setSavingMethods(true);
    try{await onSavePaymentMethods({upi,phone,qr});}catch{}finally{settingsLock.current=false;setSavingMethods(false);}
  };

  const handleQrUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if(file.size>2*1024*1024||!['image/png','image/jpeg','image/webp'].includes(file.type)){alert('Use PNG, JPEG or WebP, maximum 2 MB');return;}
      const reader = new FileReader();
      reader.onload = () => {
        setQr(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="px-3 py-4 space-y-4">
      {/* Payment Method Configuration */}
      <div className="native-card bg-[#232E3C] border border-[rgba(0,194,111,0.25)] p-4 rounded-2xl shadow-xl" style={{ background: 'rgba(0,194,111,0.04)' }}>
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-[rgba(0,194,111,0.15)] text-[#00C26F] flex items-center justify-center shrink-0 border border-[rgba(0,194,111,0.2)]">
            <QrCode className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-white font-black text-[14px]">Payment Gateway Setup</h3>
            <p className="text-[9px] text-[#7A9CB8] uppercase tracking-wider mt-0.5">Configure UPI ID & QR Code shown to VIP users</p>
          </div>
        </div>

        <div className="space-y-2 mb-3">
          <label htmlFor="payment-upi" className="block text-[11px] text-[#A5B6C8]">UPI ID</label>
          <input id="payment-upi"
            type="text"
            value={upi}
            onChange={(e) => setUpi(e.target.value)}
            placeholder="name@bank"
            className="w-full bg-[#2B3A4D] border border-[rgba(255,255,255,0.07)] text-white text-sm py-2.5 px-3 rounded-xl font-bold outline-none focus:border-[#00C26F]"
          />
          <label htmlFor="payment-phone" className="block text-[11px] text-[#A5B6C8]">WhatsApp phone number</label>
          <input id="payment-phone"
            type="text"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="Country code + phone number"
            className="w-full bg-[#2B3A4D] border border-[rgba(255,255,255,0.07)] text-white text-sm py-2.5 px-3 rounded-xl font-bold outline-none focus:border-[#00C26F]"
          />

          <div>
            <label className="text-[9px] text-[#7A9CB8] font-bold uppercase block mb-1">UPI QR Code Image</label>
            <label className="block w-full bg-[#2B3A4D] border border-dashed border-[rgba(255,255,255,0.15)] rounded-xl p-3 text-center cursor-pointer">
              <QrCode className="w-6 h-6 text-[#7A9CB8] mx-auto mb-1" />
              <span className="text-[11px] text-[#7A9CB8] font-bold">
                {qr ? 'QR Code Image Uploaded ✓' : 'Tap to upload QR Code image'}
              </span>
              <input type="file" accept="image/png,image/jpeg,image/webp" onChange={handleQrUpload} className="hidden" />
            </label>
            {qr && (
              <img src={qr} alt="QR Code" className="mx-auto mt-2 max-h-32 rounded-xl border border-[rgba(255,255,255,0.1)]" />
            )}
          </div>
        </div>

        <button
          onClick={handleSaveMethods} disabled={savingMethods}
          className="w-full bg-[#00C26F] text-white py-3 rounded-xl font-black text-[11px] uppercase active:scale-95 shadow-md"
        >
          Save Payment Gateway Settings
        </button>
      </div>

      {/* Verification Dashboard */}
      <div className="native-card bg-[#232E3C] border border-[rgba(255,255,255,0.07)] p-4 rounded-2xl shadow-xl">
        <div className="flex justify-between items-center mb-3">
          <div>
            <h3 className="text-[14px] font-black text-white">Payment Requests</h3>
            <p className="text-[9px] text-[#7A9CB8] uppercase tracking-wider mt-0.5">
              {pendingPayments.length} pending requests
            </p>
          </div>

          <button
            disabled={reviewing} onClick={()=>void review(onApproveAllSafe)}
            className="bg-[rgba(0,194,111,0.15)] text-[#00C26F] border border-[rgba(0,194,111,0.25)] px-3 py-2 rounded-xl font-bold text-[10px] uppercase active:scale-95 flex items-center gap-1"
          >
            <CheckCheck className="w-3.5 h-3.5" /> Approve Verified
          </button>
        </div>

        {/* Filter Pills */}
        <div className="payment-filter-row grid grid-cols-4 gap-1 mb-3">
          {(['all', 'pending', 'approved', 'rejected'] as const).map((f) => (
            <button
              key={f}
              aria-label={f} aria-pressed={filter===f}
              onClick={() => setFilter(f)}
              className={`px-1 py-2 rounded-xl font-bold text-[10px] uppercase transition-all ${
                filter === f
                  ? 'bg-[#2AABEE] text-white shadow-md'
                  : 'bg-[#2B3A4D] text-[#7A9CB8] hover:text-white'
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Payments List */}
        <div className="space-y-2.5">
          {filteredPayments.length === 0 ? (
            <p className="text-[#7A9CB8] text-xs text-center py-6">No payments found in this filter.</p>
          ) : (
            filteredPayments.map((p) => {
              let flagColor = 'text-[#7A9CB8]';
              if (p.autoFlag === 'safe'||p.autoFlag === 'pending') flagColor = 'text-[#FAC748]';
              else if (p.autoFlag === 'duplicate') flagColor = 'text-[#FF5D5D]';
              else if (p.autoFlag === 'spam') flagColor = 'text-[#FAC748]';

              let statusColor = 'text-[#FAC748]';
              if (p.status === 'approved') statusColor = 'text-[#00C26F]';
              if (p.status === 'rejected') statusColor = 'text-[#FF5D5D]';

              return (
                <div key={p.id} className="bg-[#2B3A4D] p-3.5 rounded-2xl border border-[rgba(255,255,255,0.07)]">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-black text-white uppercase text-[13px]">{p.userName}</h4>
                      <p className="text-[10px] text-[#7A9CB8]">{p.time}</p>
                    </div>
                    <span className={`text-[10px] font-black uppercase ${statusColor}`}>{p.status}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mb-2">
                    <div className="bg-[#1C2733] p-2 rounded-xl border border-[rgba(255,255,255,0.05)]">
                      <p className="text-[8px] font-bold text-[#7A9CB8] uppercase mb-0.5">Amount</p>
                      <p className="font-black text-white text-[13px]">₹{p.amount}</p>
                    </div>
                    <div className="bg-[#1C2733] p-2 rounded-xl border border-[rgba(255,255,255,0.05)]">
                      <p className="text-[8px] font-bold text-[#7A9CB8] uppercase mb-0.5">UTR Number</p>
                      <p className="font-black text-white text-[11px] truncate">{p.utr || '-'}</p>
                    </div>
                  </div>

                  <div className="mb-2 flex items-center justify-between">
                    <span className={`text-[10px] font-black uppercase flex items-center gap-1 ${flagColor}`}>
                      <ShieldAlert className="w-3 h-3" /> Review: {p.autoFlag==='safe'||p.autoFlag==='pending'?'VERIFICATION PENDING':p.autoFlag.toUpperCase()}
                    </span>
                    <span className="text-[9px] text-[#7A9CB8] font-bold">{p.planLabel}</span>
                  </div>

                  {p.reviewedAt && <p className="text-[10px] text-[#7A9CB8] mb-2">Admin reviewed: {new Date(p.reviewedAt).toLocaleString()}</p>}
                  {p.image && (
                    <img src={p.image} alt="Payment proof" className="w-full rounded-xl mb-2 border border-[rgba(255,255,255,0.07)] max-h-40 object-contain" />
                  )}

                  {p.status === 'pending' && (
                    <div className="flex gap-2 mt-2">
                      <button
                        onClick={() => {
                          if(!window.confirm('Have you checked this payment in your bank account?'))return;
                          const daysStr = prompt('Days of access to grant:', String(PAYMENT_PLANS[p.planLabel as keyof typeof PAYMENT_PLANS]?.days||30));
                          if(daysStr){const days=Number(daysStr);if(!Number.isInteger(days)||days<1||days>3660){alert('Enter valid whole access days (1–3660)');return;}void review(()=>onApprovePayment(p.id,days));}
                        }}
                        disabled={reviewing} className="flex-1 bg-[#00C26F] text-white py-2 rounded-xl font-black text-[11px] uppercase active:scale-95 flex items-center justify-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" /> Approve
                      </button>
                      <button
                        onClick={() => void review(()=>onRejectPayment(p.id))}
                        disabled={reviewing} className="flex-1 bg-[#FF5D5D] text-white py-2 rounded-xl font-black text-[11px] uppercase active:scale-95 flex items-center justify-center gap-1"
                      >
                        <X className="w-3.5 h-3.5" /> Reject
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
