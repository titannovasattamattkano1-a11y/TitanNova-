import { Sparkles } from 'lucide-react';
import { adminChanges, applyAdminChanges, shareAdminSnapshot, sameAdminValue } from './utils/adminStatePatch';
import { adminWorkspaceVersion, noteAdminWorkspaceVersion } from './utils/adminWorkspaceVersion';
import {applyOpenToCloseCut,toggleOpenToCloseCut} from './utils/openToCloseCut';
import {cutBoxEnds} from './utils/cutBoxEnds';
import {holdBacktestDaySelections} from './utils/backtestSelectionHold';
import {shouldReplayHistoricalDay} from './utils/historicalDateView';
import {apiDeadlineSignal} from './utils/apiDeadline';
import {rebasePendingEdits} from './utils/rebasePendingEdits';
import {acknowledgedDay} from './utils/acknowledgedDay';
import {postBulkCommand,bulkOperationId,BulkCommandError} from './utils/bulkCommand';
import {canApplySourceWindowHistory,checkedSourceHistory,type SourceHistoryAnalysis} from './utils/sourceWindowHistory';
import {useTwoCardRecovery} from './utils/twoCardRecovery';
import {readStartupSnapshotJson} from './utils/startupSnapshotStore';
import {StateSerializer,SerializationSuperseded} from './utils/stateSerializer';
import {isFrequencySourceMode,type FrequencySourceMode} from './utils/sourceFrequencySmart';
import {applyDatedFinancialSetup} from './utils/datedFinancialSetup';
import {profileSourceIndexGuidance} from './utils/sourceIndexHistory';
import {pinRecoverySettings,archiveReplaySignature} from './utils/archiveRecoverySnapshot';
import {prepareTieHistory,tieHistoryFingerprint,TIE_HISTORY_START} from './utils/historyTie';
import {usePwaInstall} from './utils/pwaInstall';
import type {BroadcastPresentation} from './utils/broadcastImage';
import {PAYMENT_PLANS,validatePaymentProof} from './utils/manualPayments';
import { BulkActionIcon } from './components/BulkActionIcon';
import { PreparedView } from './components/PreparedView';
import {requestScrape} from './utils/scrapeRequest';
import {lookupBacktestActual} from './utils/backtestActualLookup';
import {resultTestNotice,resultTestErrorMessage} from './utils/resultTestFeedback';
import {createMarketHistoryRunGate} from './utils/marketHistoryRunGate';
import {canApplyMarketHistoryChoice,sourceHistoryIndices,canProjectMarketHistorySource,type MarketHistorySource} from './utils/marketHistoryLogic';
import {DailyAuditImageModal} from './components/DailyAuditImageModal';
import {buildDailyAuditImageData,auditGameLabel,type DailyAuditImageData} from './utils/dailyAuditImage';
import * as auditImageCompatExports from './utils/dailyAuditImage';
import {recentSixUniqueIndices,keepRecentSixIndices,recentUniqueSourceIndices,removeRecentFourIndices} from './utils/keepRecentSixIndices';
import {canReplaceLiveCombinedDecision,releaseLiveCombinedDecision} from './utils/liveCombinedDecision';
import {applyLiveCombinedCut,hasLiveCombinedCut} from './utils/liveCombinedCut';
import { businessDateIST } from './utils/businessDate';
import { createVipLiveStart, vipLiveMarketEligible } from './utils/vipLiveStart';
import { BackgroundBacktestStatus } from './components/BackgroundBacktestStatus';
import {rangeMarketChoices} from './utils/rangeBacktest';
import { RangeBacktestPanel } from './components/RangeBacktestPanel';
import { preserveRangeArchive } from './utils/rangeBacktest';
import { createNewVipConfig } from './utils/newVipConfig';
import { createCatalogInspector, updateProfileMarketCatalog, resolveMarketScrapeUrl } from './utils/marketCatalogMigration';
import { applyYesterdayLoopGroups } from './utils/yesterdayLoopGroups';
import { clearRestoredDelivery } from './utils/cardRestore';
import { applySourceSnapshot } from './utils/sourceSnapshot';
import { type AdminCopySnapshotPlan, adminSnapshotTargetUnchanged, isAdminSnapshotProtected, adminSnapshotMarketEnabled } from './utils/adminCopySnapshot';
import { selectionUndoSource, undoSelection } from './utils/undoSelection';
import { keepSupportStrongDigits, buildMssdFourClickPlan, getNextMssdStage } from './utils/digitSupport';
import { dayLoopConfig, assignedLoop, normalizeDualLoops, pinDayLoops, loopSettingsForDate, type DualLoopConfig } from './utils/dualLoops';
import { applyMarketModelSummary, isEditableSourceSkip, isStaleModelSnapshot, modelSourceVersion, type MarketModelSummary } from './utils/marketModelCard';
import { recentSourceIndices } from './utils/removeRecentSourceIndices';
import {removeRecentTwoNextIndices} from './utils/recentTwoNextCut';
import {applyBulkMirrorAdd} from './utils/mirrorAdd';
import {cutFirstDigit} from './utils/firstDigitMirrorCut';
import {carryControlMode,resultRemovalMode,datedResultRemovalSettings,toggleDatedResultControl,type ResultControl} from './utils/autoRemoveResult';
import {replayResultControlDay} from './utils/resultControlReplay';
import { actualForGame, cacheBacktestActual, evaluateBacktest, evaluateDatedBacktest, canAutoEvaluateBacktest, isFreshBacktestActual, BACKTEST_RESULT_RETRY_MS, type CachedBacktestActual, type DatedActual } from './utils/backtestResult';
import { calculateBacktestRecovery } from './utils/backtestRecovery';
import { restoreBacktestRecord,restoreBacktestDay } from './utils/backtestRestore';
import { removeFirstFourSourceIndices } from './utils/removeFirstFour';
import {removeLastFourSourceIndices} from './utils/lastFourCut';
import { applyOpenCloseMatch, describeOpenCloseMatch, applyOpenCloseUnion, describeOpenCloseUnion } from './utils/openCloseMatch';
import { normalizeManualResult, manualResultStatus } from './utils/manualResult';
import { clearedLedgerCard } from './utils/clearLedgerCard';
import { normalizeScrapeSource,getScrapeSource } from './utils/scrapeProvenance';
import { apiUrl } from './utils/api';
import { workspaceView } from './utils/workspaceView';
import {buildFinancialLedger} from './utils/financialHistory';
import { editorId } from './utils/editorSession';
import { VerifiedStartupState } from './utils/verifiedStartupState';
import { startupRequest } from './utils/startupRequest';
import { confirmSettlementAfterTransportError } from './utils/settlementSyncConfirmation';
import { ReliableStateSaver, StateSaveError } from './utils/reliableStateSaver';
import { SaveStatusStore } from './utils/saveStatusStore';
import { SaveStatusIndicator } from './components/SaveStatusIndicator';
import { scoreDigitProbabilities } from './utils/filterProbability';
import { useState, useEffect, useRef, useMemo, useContext } from 'react';
import {
  AppState,
  GameType,
  UserProfile,
  ProfileConfig,
  ToastMessage,
  DayRecordStore,
  DayMarketRecord,
  MarketItem,
  CardSourceMode,
  MarketScope,
} from './types';
import {
  BASE_MARKETS,
  getEffectiveMarkets,
  getEffectiveBaseMarkets,
  getDefaultConfig,
  HARDCODED_PAYMENTS,
  isDayMarket,
  isNightMarket,
} from './data/markets';
import {
  titanLocalDateISO,
  calculateGlobalStats,
  generateDailyAuditReport,
  generateNormalDailyReport,
  buildCardIntelMessage,
  getEffectiveCardRate,
  applyTrickFormula,
  applyAutoRatesToDayStore,
  getCardSameMarketRecoveryState,
} from './utils/calculator';
import { areSettlementTokensValid, calculateRecoveryRate, countSettlementTokens, normalizeTargetProfit } from './utils/settlement';
import { findHistoricalMarketRecord, findMarketIndexByName } from './utils/cardHistory';
import { buildJodisFromAnk, normalizeAnkDigits } from './utils/jodiFromAnk';
import { generateLifetimeJodi, generateLifetime32JodiOnly, calculateSrideviMasterFormula, calculateSrideviPattiHeadSum, calculateTimeBazarDigitalRoot, calculateMadhurJodiTotal4Ank, calculateMilanDayPyramid, calculateSupremeCenterTouch, calculateKalyanFarakForward4Ank, calculateMainBazarStepBackCut4Ank, calculateMilanNight23Pyramid4Ank, calculateUniversalLifetime4Ank, calculateOptimizedMarket4Ank, findReferenceJodiForMarket } from './utils/lifetimeJodiFormula';
import { applyProfileMarketToggle, isMarketEnabledForDate } from './utils/profileMarketToggle';
import { getDateWeekdayScheduleInfo } from './utils/sourceIndexDisplayDates';
import { applyProfileMessageFormat, applyProfileCardSenderFormat } from './utils/profileMessageFormat';
import { filterPanelsByAnkDigits } from './utils/panelAnk';
import { SerialMutationQueue } from './utils/serialMutationQueue';
import { runConcurrentTasks } from './utils/concurrentTasks';
import type { StrictPanel30Selection } from './utils/strictPanel30';
import { scrapeRecordVersion,scrapeRequestVersion,scrapeSelectionIntent,canKeepScrapeRequest,isSourceScrapeFrozen, type ScrapeCommitGuard } from './utils/scrapeCommitGuard';
import { normalizeTargetJid, normalizeTargetList, isGroupTarget, isChannelTarget, isTelegramTarget } from './utils/targetNormalization';
import { isMirrorProtected, projectAdminSource, vipCopiesAdmin } from './utils/adminMirror';
import { Header } from './components/Header';
import { BottomNav, MainNavTab } from './components/BottomNav';
import { Sidebar } from './components/Sidebar';
import { WalletHUD } from './components/WalletHUD';
import { LedgerCard } from './components/LedgerCard';
import { SmartAIScanner } from './components/SmartAIScanner';
import { WeeklyAudit } from './components/WeeklyAudit';
import { VipManagement } from './components/VipManagement';
import { PaymentAdmin } from './components/PaymentAdmin';
import { MembershipView } from './components/MembershipView';
import { SettingsView } from './components/SettingsView';
import { TermuxBotView } from './components/TermuxBotView';
import { ShareModal } from './components/ShareModal';
import { InstallModal } from './components/InstallModal';
import { ResultAuditorModal } from './components/ResultAuditorModal';
import { SelfLearningModal } from './components/SelfLearningModal';
import { AiAdvisorModal } from './components/AiAdvisorModal';
import { ActivityReplayModal } from './components/ActivityReplayModal';
import { recordMainActivity } from './utils/activityLogger';
import {
  applySelfLearningBulk,
  applySelfLearningToCard,
  buildUniqueMultiRule4Ank,
  extractActualDigit,
  getMarketUniqueSignature,
  getStoredLearningState,
  predictForMarket,
  seedRecentDatedDrawsIntoProfile,
} from './utils/selfLearningEngine';
import { AnkJodiPanelSetup } from './components/AnkJodiPanelSetup';
import { MarketManager } from './components/MarketManager';
import { ToastContainer } from './components/Toast';

const createVipAccessToken = (): string => {
  const bytes = new Uint8Array(24);
  window.crypto.getRandomValues(bytes);
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
};

type BulkScrapeMode='trend_break'|'panna_follow'|'digit_follow'|'scrape'|'weekday'|'combo'|'day_combo'|'smart'|'market_model'|'pair_combo'|'mssd'|'freq_10'|'freq_10_combo'|'dynamic_4ank'|'open_auto_close_day';
export default function App() {
  const verifiedStartup = useContext(VerifiedStartupState);
  // Check URL VIP parameter
  const searchParams = new URLSearchParams(window.location.search);
  const vipParam = searchParams.get('vip');
  const vipTokenParam = new URLSearchParams(window.location.hash.slice(1)).get('token') || searchParams.get('token') || '';
  const isMasterApp = !searchParams.has('vip') && !vipTokenParam;

  const [currentDate, setCurrentDate] = useState<string>(() => titanLocalDateISO());
  const [mainNav, setMainNav] = useState<MainNavTab>(workspaceView.mainNav);
  const [activeTab, setActiveTab] = useState<GameType | 'market_manager' | 'setup' | 'backtest'>(workspaceView.activeTab);
  useEffect(() => { workspaceView.mainNav = mainNav; workspaceView.activeTab = activeTab; }, [mainNav, activeTab]);


  const [marketSearchQuery, setMarketSearchQuery] = useState('');
  const [marketStatusFilter, setMarketStatusFilter] = useState<'ALL' | 'WAIT' | 'PASS' | 'FAIL'>('ALL');
  const [marketScopeFilter, setMarketScopeFilter] = useState<MarketScope>('ALL');
  const [bulkMarketScope, setBulkMarketScope] = useState<MarketScope>('ALL');
  const [isGridMode, setIsGridMode] = useState(false);
  const [bulkAction, setBulkAction] = useState<string | null>(null);
  const [bulkScrapeReport,setBulkScrapeReport]=useState<{profileId:string;date:string;mode:BulkScrapeMode;ok:number;total:number;changed:number;skipped:Array<{market:string;message:string}>;failures:Array<{market:string;message:string;guard:ScrapeCommitGuard}>}|null>(null);
  const [bulkScrapeProgress,setBulkScrapeProgress]=useState<{id:string;owner:string;date:string;done:number;total:number}|null>(null);
  const bulkScrapeRun=useRef<{owner:string;date:string;id:string;controller:AbortController;tab?:GameType}|null>(null);
  const [bulkTieReport,setBulkTieReport]=useState<{owner:string;date:string;entries:Array<{market:string;message:string}>}|null>(null);
  const [historyTieProgress,setHistoryTieProgress]=useState<{id:string;owner:string;date:string;index:number;text:string;cards?:Record<number,string>}|null>(null);
  const marketHistoryBulkRun=useRef<{owner:string;date:string;id:string;tie?:boolean}|null>(null);
  const marketHistoryRuns=useRef<ReturnType<typeof createMarketHistoryRunGate>|null>(null);
  if(!marketHistoryRuns.current)marketHistoryRuns.current=createMarketHistoryRunGate();
  const [selectedBulkScrape, setSelectedBulkScrape] = useState<string | null>(null);
  const [autoBacktestResult, setAutoBacktestResult] = useState(false);
  const backtestActualCache = useRef(new Map<string,CachedBacktestActual>());
  const backtestLookups = useRef(new Map<string,Promise<DatedActual | null | undefined>>());
  const [backtestRetry,setBacktestRetry]=useState(0);
  const [backtestChecking,setBacktestChecking]=useState(false);
  const [vipGameSaving, setVipGameSaving] = useState(false);
  const vipGameBusyRef=useRef(false);
  const [pendingVipGame,setPendingVipGame]=useState<{profileId:string;date:string;type:GameType;enabled:boolean}|null>(null);
  const [profitNotificationsSaving, setProfitNotificationsSaving] = useState(false);
  const [pendingProfitSetting, setPendingProfitSetting] = useState<{profileId:string;enabled:boolean}|null>(null);
  const bulkRestoreInFlightRef = useRef(false);

  // Sidebar & Modals
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const pwa=usePwaInstall();
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Share Modal State
  const [shareMessage, setShareMessage] = useState('');
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [auditImageData,setAuditImageData]=useState<DailyAuditImageData|null>(null);
  const [isResultAuditorOpen, setIsResultAuditorOpen] = useState(false);
  const [isSelfLearningModalOpen, setIsSelfLearningModalOpen] = useState(false);
  const [selfLearningScanProgress, setSelfLearningScanProgress] = useState<{ done: number; total: number; currentMarket: string } | null>(null);
  const [isAiAdvisorOpen, setIsAiAdvisorOpen] = useState(false);
  const [isActivityReplayOpen, setIsActivityReplayOpen] = useState(false);

  // Access/lease verification already returned the authoritative snapshot.
  // Use it on the first render, without a second default-state/loading render.
  const [initialWorkspace,setInitialWorkspace] = useState(() => {
    const authorized = verifiedStartup?.state?.profiles && (isMasterApp
      ? verifiedStartup.editorId === editorId
      : verifiedStartup.profileId === vipParam && verifiedStartup.token === vipTokenParam);
    return authorized ? { state: verifiedStartup!.state!, json: verifiedStartup!.stateJson || JSON.stringify(verifiedStartup!.state) } : null;
  });

  // App Master State
  const [appState, setAppState] = useState<AppState>(() => {
    if (initialWorkspace) return initialWorkspace.state;
    const activeId = vipParam || 'admin1';
    // Hydrate from the server before reading any potentially large stale archive.
    // Local storage is read only for the existing localhost first-migration path.

    return {
      activeId,
      paymentMethods: {
        upi: HARDCODED_PAYMENTS.phonepe,
        phone: '7077550644',
        qr: '',
      },
      payments: [],
      broadcasts: [],
      // Only genuine master profile — no dummy / test VIP seeds
      profiles: isMasterApp ? {
        admin1: {
          name: 'MASTER ADMIN 1',
          phone: '7077550644',
          config: getDefaultConfig(),
          dayRecords: {},
          vipAccessEnabled: true,
        },
      } : {},
    };
  });

  // Cross-origin hydration gate: localhost + Cloudflare share server-side app state.
  // localStorage remains only a fast cache/fallback.
  const [serverHydrated, setServerHydrated] = useState(Boolean(initialWorkspace));
  const [hydrationError, setHydrationError] = useState('');
  const [hydrationAttempt, setHydrationAttempt] = useState(0);
  const saveStatusStoreRef = useRef<SaveStatusStore>(new SaveStatusStore());
  const stateSaverRef = useRef<ReliableStateSaver | null>(null);
  const serializerRef=useRef<StateSerializer|null>(null);
  if(!serializerRef.current){
    serializerRef.current=new StateSerializer();
    if(initialWorkspace)serializerRef.current.seed(initialWorkspace.state,initialWorkspace.json);
  }
  const lastSerializedStateRef=useRef(appState);
  const lastServerStateJsonRef = useRef(initialWorkspace?.json || '');
  useEffect(()=>{
    if(!serverHydrated)return;
    setInitialWorkspace(null);
    verifiedStartup?.consumeSnapshot?.();
  },[serverHydrated,verifiedStartup?.consumeSnapshot]);

  const activeId = vipParam || appState.activeId || 'admin1';
  useEffect(()=>{setAutoBacktestResult(false);},[currentDate,activeId]);
  const activeProfile = appState.profiles[activeId] || (isMasterApp ? appState.profiles['admin1'] : undefined);
  // Prevent schedule sync from firing on every local UI state change.
  const scheduleSyncTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastScheduleSyncRef = useRef('');
  const lastLedgerSyncRef = useRef('');
  const manualRateSyncTimersRef = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());
  // Protect an in-progress manual edit from the polling snapshot until the
  // backend has acknowledged that exact value. The pending map is also the
  // authority when PASS/FAIL is pressed before the debounce has completed.
  const manualRateEditingRef = useRef<Set<string>>(new Set());
  const pendingManualRatesRef = useRef<Map<string, string>>(new Map());
  const marketToggleVersionRef = useRef<Map<string, number>>(new Map());
  const [cardSenderSaving,setCardSenderSaving]=useState(false);
  const [pendingSenderFormat,setPendingSenderFormat]=useState<{profileId:string;format:'text'|'png';platform:'whatsapp'|'telegram'}|null>(null);
  const cardSenderBusyRef=useRef(false);
  const messageFormatVersionRef = useRef<Map<string, number>>(new Map());
  const schedulePolicyVersionRef = useRef<Map<string, number>>(new Map());
  const adminMirrorBackfillSignatureRef = useRef('');
  const adminSnapshotRunningRef = useRef(false);
  // A Send Now click is a single delivery intent until its backend ACK arrives.
  const vipSendNowPendingRef = useRef(new Set<string>());
  const [adminSnapshotBusy, setAdminSnapshotBusy] = useState(false);
  const [adminSnapshotProgress,setAdminSnapshotProgress]=useState('');
  const profileMutationQueueRef = useRef(new SerialMutationQueue());
  /** Always-fresh refs so the audit poll never uses a stale closure */
  const appStateRef = useRef(appState);
  const activeIdRef = useRef(activeId);
  const currentDateRef = useRef(currentDate);
  const profileToken = (pid: string): string =>
    pid === 'admin1'
      ? ''
      : (vipParam === pid ? vipTokenParam : String(appStateRef.current.profiles?.[pid]?.vipAccessToken || ''));
  const profileAuthHeaders = (pid: string): Record<string, string> => {
    const token = profileToken(pid);
    return token ? { 'X-Titan-Profile-Token': token } : {};
  };
  // True while the date picker is following the live business day. Selecting
  // an older day is an explicit history view and must survive polling, focus
  // and visibility refreshes until the user selects today again.
  const followBusinessDayRef = useRef(true);
  const [todayBacktest, setTodayBacktest] = useState(false);
  const [resultParitySaving,setResultParitySaving]=useState(false);
  const resultParityInFlightRef=useRef(false);
  const [pendingParitySetting,setPendingParitySetting]=useState<{profileId:string;date:string;enabled:boolean}|null>(null);
  const [archiveRecoverySaving,setArchiveRecoverySaving]=useState(false);
  useEffect(() => {
    appStateRef.current = appState;
  }, [appState]);
  useEffect(() => {
    activeIdRef.current = activeId;
  }, [activeId]);
  useEffect(() => {
    currentDateRef.current = currentDate;
  }, [currentDate]);
  useEffect(() => () => {
    manualRateSyncTimersRef.current.forEach((timer) => clearTimeout(timer));
    manualRateSyncTimersRef.current.clear();
    manualRateEditingRef.current.clear();
    pendingManualRatesRef.current.clear();
  }, []);

  // Load the shared server state BEFORE any schedule/ledger push. This prevents a
  // fresh Cloudflare origin from overwriting the already-correct localhost state.
  useEffect(() => {
    let cancelled = false;
    const hydrate = async () => {
      if (initialWorkspace && hydrationAttempt === 0) return;
      setHydrationError('');
      try {
        if (hydrationAttempt === 0 && verifiedStartup?.state?.profiles && (isMasterApp
          ? verifiedStartup.editorId === editorId
          : verifiedStartup.profileId === vipParam && verifiedStartup.token === vipTokenParam)) {
          const remote = verifiedStartup.state;
          const remoteJson = verifiedStartup.stateJson || JSON.stringify(remote);
          lastServerStateJsonRef.current = remoteJson;
          confirmedSnapshotRef.current = { json: remoteJson, state: remote };
          serializerRef.current?.seed(remote, remoteJson);
          lastSerializedStateRef.current = remote;
          setAppState(remote);
          appStateRef.current = remote;
          if (!cancelled) setServerHydrated(true);
          return;
        }
        await startupRequest(async signal => {
        const query = isMasterApp ? '' : `?profileId=${encodeURIComponent(vipParam || '')}`;
        const res = await fetch(apiUrl(`/api/app/state${query}`), {
          signal, cache: 'no-store',
          headers: vipParam && vipTokenParam ? { 'X-Titan-Profile-Token': vipTokenParam } : {},
        });
        const data = await res.json();
        if (cancelled) return;
        if (!res.ok) throw new Error('Server state load nahi hua. Retry karein.');
        if (res.ok && data?.exists && data?.state?.profiles) {
          if(isMasterApp)noteAdminWorkspaceVersion(res.headers.get('X-Titan-Workspace-Version'));
          const remote = data.state as AppState;
          const remoteJson = JSON.stringify(remote);
          lastServerStateJsonRef.current = remoteJson;
          confirmedSnapshotRef.current = { json: remoteJson, state: remote };
          serializerRef.current?.seed(remote, remoteJson);
          lastSerializedStateRef.current = remote;
          setAppState(remote);
          appStateRef.current = remote;
        } else if (isMasterApp && data?.exists === false) {
          // First migration: ONLY localhost may seed the server from its existing
          // localStorage. A new trycloudflare.com origin must never seed defaults.
          const host = String(window.location.hostname || '').toLowerCase();
          const isLocalHost = host === 'localhost' || host === '127.0.0.1' || host === '::1';
          if (isLocalHost) {
            let seed = appStateRef.current;
            try {
              const cached = await readStartupSnapshotJson('TITAN_NOVA_MASTER');
              const parsed = cached ? JSON.parse(cached) : null;
              if (parsed && parsed.profiles) seed = parsed;
            } catch { /* Keep the existing fresh-install fallback for unavailable/invalid cache. */ }
            const seedJson = JSON.stringify(seed);
            const save = await fetch(apiUrl('/api/app/state'), {
              signal, method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ state: seed }),
            });
            if (!save.ok) throw new Error('Initial state save failed. Retry karein.');
            noteAdminWorkspaceVersion(save.headers.get('X-Titan-Workspace-Version'));
            lastServerStateJsonRef.current = seedJson;
            setAppState(seed);
            appStateRef.current = seed;
          } else throw new Error('Server data unavailable. Local server par setup check karein.');
        } else throw new Error('Server state invalid hai. Retry karein.');
        });
        if (!cancelled) setServerHydrated(true);
      } catch (e) {
        if (!cancelled) setHydrationError(e instanceof Error ? e.message : 'Server unavailable. Retry karein.');
      }
    };
    void hydrate();
    return () => { cancelled = true; };
    // one hydration per origin/page load
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrationAttempt]);

  // Existing VIPs receive a stable secret once the master state is hydrated.
  // It is persisted with the profile and embedded only in that VIP's share link.
  useEffect(() => {
    if (!serverHydrated || !isMasterApp) return;
    setAppState((prev) => {
      let changed = false;
      const profiles = { ...prev.profiles };
      Object.keys(profiles).forEach((pid) => {
        if (pid === 'admin1' || profiles[pid]?.vipAccessToken) return;
        profiles[pid] = { ...profiles[pid], vipAccessToken: createVipAccessToken() };
        changed = true;
      });
      return changed ? { ...prev, profiles } : prev;
    });
  }, [serverHydrated, isMasterApp]);

  /**
   * Business-day rollover (IST, 06:00 cutoff via titanLocalDateISO).
   * If the app stays open overnight, currentDate used to stay stuck on yesterday
   * and Monday's PASS/FAIL cards kept showing on Tuesday.
   * When the business day advances → switch date → empty dayRecords[new] = fresh ledger.
   */
  useEffect(() => {
    const tick = () => {
      const todayBiz = titanLocalDateISO();
      if (followBusinessDayRef.current && todayBiz && todayBiz !== currentDateRef.current) {
        setTodayBacktest(false);
        const prev = currentDateRef.current;
        setCurrentDate(todayBiz);
        currentDateRef.current = todayBiz;
        // Force ledger/schedule re-sync for the new day
        try {
          lastScheduleSyncRef.current = '';
          lastLedgerSyncRef.current = '';
        } catch (_) {}
        showToast(
          '📅 Naya din',
          `${prev || '—'} → ${todayBiz} · Fresh ledger`,
          'success'
        );
      }
    };
    tick();
    const id = window.setInterval(tick, 30_000); // every 30s
    const onVis = () => {
      if (document.visibilityState === 'visible') tick();
    };
    document.addEventListener('visibilitychange', onVis);
    window.addEventListener('focus', tick);
    return () => {
      window.clearInterval(id);
      document.removeEventListener('visibilitychange', onVis);
      window.removeEventListener('focus', tick);
    };
  }, []);

  // One-time cleanup: remove dummy / junk VIP stubs from master storage
  // (client_dummy, empty "VIP CLIENT", auto-stub "VIP MEMBER" without phone)
  useEffect(() => {
    if (!isMasterApp) return;
    setAppState((prev) => {
      const profiles = { ...(prev.profiles || {}) };
      let changed = false;
      const junkNames = new Set(['dummy test vip', 'vip member', 'vip client', '']);
      Object.keys(profiles).forEach((pid) => {
        if (pid === 'admin1') return;
        if (pid === 'client_dummy') {
          delete profiles[pid];
          changed = true;
          return;
        }
        const p = profiles[pid];
        if (!p) {
          delete profiles[pid];
          changed = true;
          return;
        }
        const name = String(p.name || '').trim().toLowerCase();
        const phone = String(p.phone || p.vipSchTarget || '').replace(/\D/g, '');
        // Junk = placeholder name + no real phone (never a real client)
        if (junkNames.has(name) && phone.length < 10 && ![p.phone, p.vipSchTarget, p.vipGroupJid, p.vipChannelJid].some(isTelegramTarget)) {
          delete profiles[pid];
          changed = true;
        }
      });
      if (!changed) return prev;
      // Ensure admin1 always exists
      if (!profiles.admin1) {
        profiles.admin1 = {
          name: 'MASTER ADMIN 1',
          phone: '7077550644',
          config: getDefaultConfig(),
          dayRecords: {},
          vipAccessEnabled: true,
        };
      }
      return { ...prev, profiles };
    });
    // run once on mount for master app
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isMasterApp]);


  const confirmedSnapshotRef=useRef<{json:string;state:AppState}|null>(initialWorkspace?{json:initialWorkspace.json,state:initialWorkspace.state}:null);
  const acceptAdminSnapshot = (remote: AppState, base: AppState, fromRefresh = false, serializedRemote?:string) => {
    // Reuse accepted archive branches before retaining the new baseline.
    // Otherwise one refresh pins a second, fully parsed copy beside the UI.
    remote=shareAdminSnapshot(base,remote) as AppState;
    const local=appStateRef.current;
    const rebased=rebasePendingEdits(remote,base,local);
    const localActive=rebased.state.profiles?.[local.activeId] ? local.activeId : 'admin1';
    const next=shareAdminSnapshot(local,{...rebased.state,activeId:localActive}) as AppState;
    const confirmed=serializedRemote?serializedRemote:JSON.stringify({...remote,activeId:localActive});
    lastServerStateJsonRef.current=confirmed;
    confirmedSnapshotRef.current={json:confirmed,state:{...remote,activeId:localActive}};
    if(next!==local){appStateRef.current=next;setAppState(next);}
    const pending=rebased.state===remote?confirmed:JSON.stringify(next);
    if(fromRefresh)stateSaverRef.current?.adoptRemote(confirmed,pending);
    else stateSaverRef.current?.update(pending);
    return confirmed;
  };

  useEffect(() => {
    if (!serverHydrated || !isMasterApp) return;
    const saver = new ReliableStateSaver(async json => {
      if(!lastServerStateJsonRef.current)throw new StateSaveError('Reload saved workspace before editing; baseline unavailable.',false);
      const baseline=lastServerStateJsonRef.current;
      const baseVersion=adminWorkspaceVersion;
      const base=confirmedSnapshotRef.current?.json===baseline?confirmedSnapshotRef.current.state:JSON.parse(baseline);
      const submitted=(serializerRef.current?.snapshotFor(json) as AppState|undefined)||JSON.parse(json);
      // These immutable snapshots already share unchanged archive branches.
      // Compare those references directly instead of cloning two full JSON
      // archives into another worker and parsing both again for every save.
      const patch=adminChanges(base,submitted);
      if(!patch.length)return acceptAdminSnapshot(base,submitted);
      return await profileMutationQueueRef.current.enqueue('app-state', () => startupRequest(async signal => {
        const payloadBody = JSON.stringify({adminPatch:patch,compact:true,baseVersion});
        let response: Response | undefined;
        for (let attempt = 0; attempt < 3; attempt++) {
          try {
            response = await fetch(apiUrl('/api/app/state'), {
              method: 'POST', signal, headers: {'Content-Type':'application/json'}, body: payloadBody,
            });
            break;
          } catch (err: any) {
            if (signal.aborted || attempt === 2) throw err;
            await new Promise(r => setTimeout(r, 250 * (attempt + 1)));
          }
        }
        if (!response) throw new StateSaveError('Failed to fetch', true);
        const result = await response.json().catch(() => null);
        if (!response.ok) throw new StateSaveError(response.status === 413
          ? 'Archive is too large to save. Download a backup and ask your administrator to increase the archive limit.'
          : result?.message || `Save failed (HTTP ${response.status})`, response.status >= 500 || response.status === 429);
        let saved=result?.state;
        if(result?.saved===true&&Array.isArray(result.statePatch)){
          const corrected=applyAdminChanges(submitted,result.statePatch);
          if(corrected.conflicts.length)throw new StateSaveError('Save response needs fresh workspace. Retry.',true);
          saved=corrected.state;
        }
        if (result?.saved !== true || !saved?.profiles) throw new StateSaveError('Server did not confirm the save. Retry.', true);
        const accepted=acceptAdminSnapshot(saved,submitted,false,saved===submitted?json:undefined);
        noteAdminWorkspaceVersion(response.headers.get('X-Titan-Workspace-Version'));
        return accepted;
      }, 55000));
    }, saveStatusStoreRef.current.set, 220, 5000, 1500);
    saver.seed(lastServerStateJsonRef.current);
    stateSaverRef.current = saver;
    const beforeUnload = (event: BeforeUnloadEvent) => { if (saver.dirty || lastSerializedStateRef.current !== appStateRef.current) { event.preventDefault(); event.returnValue = ''; } };
    const retry = () => saver.retry();
    window.addEventListener('beforeunload', beforeUnload);
    window.addEventListener('online', retry);
    return () => { saver.dispose(); stateSaverRef.current = null; window.removeEventListener('beforeunload', beforeUnload); window.removeEventListener('online', retry); };
  }, [serverHydrated, isMasterApp]);
  useEffect(() => {
    if (!serverHydrated) return;
    // Serialize/cache off the UI thread; only the still-current snapshot may enter the save queue.
    let cancelled=false;
    let timer:ReturnType<typeof setTimeout>|undefined;
    const serialize=async (allowHidden = false) => {
      if(cancelled||(!allowHidden&&document.visibilityState==='hidden'))return;
      const snapshot=appStateRef.current;
      const storageKey = isMasterApp ? 'TITAN_NOVA_MASTER' : `TITAN_NOVA_VIP_${activeId}`;
      try{
        const json=await serializerRef.current!.serialize(snapshot,storageKey);
        if(cancelled||bulkRestoreInFlightRef.current||snapshot!==appStateRef.current)return;
        lastSerializedStateRef.current=snapshot;
        if (isMasterApp) stateSaverRef.current?.update(json);
      }catch(error){if(!cancelled&&!(error instanceof SerializationSuperseded))saveStatusStoreRef.current.set({phase:'error',message:'Workspace serialization failed; retry save.'});}
    };
    const onVisibility=()=>{
      clearTimeout(timer);
      if(document.visibilityState==='hidden'){
        if(lastSerializedStateRef.current!==appStateRef.current){void serialize(true);}
        serializerRef.current?.suspend();
        return;
      }
      serializerRef.current?.resume();
      // Resume after the light revision/ledger reads, rather than copying the
      // whole archive alongside every foreground event.
      if(lastSerializedStateRef.current!==appStateRef.current)timer=setTimeout(serialize,250);
    };
    if(document.visibilityState!=='hidden')timer=setTimeout(serialize,180);
    const retrySerialization = () => { serializerRef.current?.resume(); void serialize(); };
    document.addEventListener('visibilitychange',onVisibility);
    window.addEventListener('titan-retry-serialize', retrySerialization);
    return () => {cancelled=true;clearTimeout(timer);document.removeEventListener('visibilitychange',onVisibility);window.removeEventListener('titan-retry-serialize',retrySerialization);};
  }, [appState, serverHydrated, isMasterApp, activeId]);
  useEffect(()=>{if(!serializerRef.current)serializerRef.current=new StateSerializer();return()=>{serializerRef.current?.dispose();serializerRef.current=null;};},[]);
  useEffect(() => {
    const backup = (event: Event) => {
      if (!isMasterApp || !serverHydrated) return;
      const json = JSON.stringify(appStateRef.current);
      if (event instanceof CustomEvent && event.detail) event.detail.json = json;
      try { localStorage.setItem('TITAN_NOVA_MASTER', json); } catch { /* In-memory download remains available. */ }
    };
    window.addEventListener('titan-editor-closing', backup);
    return () => window.removeEventListener('titan-editor-closing', backup);
  }, [isMasterApp, serverHydrated]);

  const persistCurrentState = async () => {
    const saver = stateSaverRef.current;
    if (!saver) throw new Error('Workspace is not ready to save');
    const started=Date.now();
    for(;;){
      if(Date.now()-started>60000)throw new Error('Workspace keeps changing while saving; confirmation did not finish. Retry after pending work completes.');
      const snapshot=appStateRef.current;
      let json:string;
      try{json=await serializerRef.current!.serialize(snapshot);}catch(error){if(error instanceof SerializationSuperseded)continue;throw error;}
      if(snapshot!==appStateRef.current)continue;
      lastSerializedStateRef.current=snapshot;saver.update(json);
      await saver.flush();
      if(snapshot===appStateRef.current)return;
      // A confirmed server correction can replace the object without leaving
      // unsaved edits. Do not force another save solely for that new identity.
      if(!saver.dirty&&lastServerStateJsonRef.current&&!adminChanges(confirmedSnapshotRef.current?.json===lastServerStateJsonRef.current?confirmedSnapshotRef.current.state:JSON.parse(lastServerStateJsonRef.current),appStateRef.current).length){lastSerializedStateRef.current=appStateRef.current;return;}
    }
  };

  // Refresh backend-owned archives on return or completion, without polling
  // for other Admin writers every five seconds.
  useEffect(()=>{
    if(!serverHydrated||!isMasterApp)return;
    let stopped=false,running=false,resumeNotBefore=0;
    let resumeTimer:ReturnType<typeof setTimeout>|undefined;
    const refresh=async()=>{
      if(stopped||running||Date.now()<resumeNotBefore||document.visibilityState==='hidden'||stateSaverRef.current?.dirty)return;
      const base=lastServerStateJsonRef.current;
      if(!base||lastSerializedStateRef.current!==appStateRef.current)return;
      running=true;
      try{
        // Network reads must not occupy the mutation queue while the server is slow.
        const check=await fetch(apiUrl('/api/app/workspace_revision'),{signal:AbortSignal.timeout(15000)});
        if(!check.ok)return;
        const version=await check.json();
        if(stopped||document.hidden)return;
        if(version.version===adminWorkspaceVersion)return;
        const response=await fetch(apiUrl('/api/app/state'),{cache:'no-store',signal:AbortSignal.timeout(30000)});
        const data=await response.json();
        await profileMutationQueueRef.current.enqueue('app-state',async()=>{
          if(stopped||document.visibilityState==='hidden'||stateSaverRef.current?.dirty||lastServerStateJsonRef.current!==base||lastSerializedStateRef.current!==appStateRef.current)return;
          if(response.ok&&data.state?.profiles){acceptAdminSnapshot(data.state,confirmedSnapshotRef.current?.json===base?confirmedSnapshotRef.current.state:JSON.parse(base),true);noteAdminWorkspaceVersion(response.headers.get('X-Titan-Workspace-Version'));}
        });
      }catch{/* Existing connection feedback/retry remains active. */}finally{running=false;}
    };
    const onResume=()=>{clearTimeout(resumeTimer);if(document.visibilityState==='hidden')return;resumeNotBefore=Date.now()+400;resumeTimer=setTimeout(()=>void refresh(),400);};
    window.addEventListener('titan-workspace-refresh',refresh);
    window.addEventListener('focus',onResume);document.addEventListener('visibilitychange',onResume);
    return()=>{stopped=true;clearTimeout(resumeTimer);window.removeEventListener('titan-workspace-refresh',refresh);window.removeEventListener('focus',onResume);document.removeEventListener('visibilitychange',onResume);};
  },[serverHydrated,isMasterApp]);

  // Event-driven ledger sync. The 8-second interval remains only as a recovery
  // fallback; card/target/status changes request an immediate debounced sync.
  useEffect(() => {
    if (!serverHydrated) return;
    if (scheduleSyncTimerRef.current) clearTimeout(scheduleSyncTimerRef.current);
    scheduleSyncTimerRef.current = setTimeout(() => {
      window.dispatchEvent(new Event('titan-ledger-dirty'));
    }, 350);
    return () => {
      if (scheduleSyncTimerRef.current) clearTimeout(scheduleSyncTimerRef.current);
    };
  }, [appState, currentDate, serverHydrated]);

  // Schedule + ledger sync: INTERVAL from refs (NOT on every appState change).
  // Depending on [appState] was rebuilding huge payloads on every keystroke → UI blink.
  useEffect(() => {
    let syncInFlight = false;
    let syncRequested = false;
    let disposed = false;
    let resumeNotBefore=0;
    const buildAndSync = async (allowHidden = false) => {
      if (!serverHydrated || disposed || adminSnapshotRunningRef.current || (!allowHidden && (Date.now()<resumeNotBefore || document.visibilityState === 'hidden'))) return;
      if (syncInFlight) {
        syncRequested = true;
        return;
      }
      syncInFlight = true;
      const requests: Promise<unknown>[] = [];
      try {
      if(currentDateRef.current!==titanLocalDateISO())return;
      if(isMasterApp){
        // Persist pending edits once; avoid re-serializing when the current snapshot is already queued in saver.
        if(lastSerializedStateRef.current!==appStateRef.current)await persistCurrentState();
        else if(stateSaverRef.current?.dirty)await stateSaverRef.current.flush();
        if(disposed||(!allowHidden&&document.hidden)||adminSnapshotRunningRef.current)return;
      }
      const state = appStateRef.current;
      const date = currentDateRef.current;
      if (!state?.profiles) return;
      // Browsing/backtesting history must never replace the live runtime ledger
      // or today's schedules. Historical cards persist through app-state save.
      if (date !== titanLocalDateISO() || adminSnapshotRunningRef.current) return;

      const schedulesList: any[] = [];
      const ledgerProfiles: Record<string, any> = {};

      Object.keys(state.profiles).forEach((pid) => {
        const prof = state.profiles[pid];
        if (!prof) return;
        // vipAccessEnabled controls portal editing only. Read-only VIPs must
        // remain in backend processing for result, recovery and auto-send.

        const dayStore = (prof.dayRecords && prof.dayRecords[date]) || {};
        const cfg = prof.config || ({} as ProfileConfig);
        const scheduleEnabled: Record<GameType, boolean> = pid === 'admin1'
          ? {
              ank: cfg.scheduleTypeEnabled?.ank !== false,
              jodi: cfg.scheduleTypeEnabled?.jodi !== false,
              pannel: cfg.scheduleTypeEnabled?.pannel !== false,
            }
          : {
              ank: prof.vipScheduleEnabled?.ank !== false,
              jodi: prof.vipScheduleEnabled?.jodi !== false,
              pannel: prof.vipScheduleEnabled?.pannel !== false,
            };
        const activeMarkets = getEffectiveMarkets(cfg);
        const activeBaseMarkets = getEffectiveBaseMarkets(cfg);
        const rawVipPhone = String(prof.vipSchTarget || prof.phone || '');
        const vipPhone = isTelegramTarget(rawVipPhone) ? rawVipPhone : rawVipPhone.replace(/\D/g, '');
        const vipGroupJid = String(prof.vipGroupJid || '').trim();
        const vipChannelJid = String(prof.vipChannelJid || '').trim();
        const vipDeliveryTargets = pid !== 'admin1' && prof.vipDeliveryMode === 'group' && isGroupTarget(vipGroupJid)
          ? [vipGroupJid]
          : pid !== 'admin1' && prof.vipDeliveryMode === 'channel' && isChannelTarget(vipChannelJid)
            ? [vipChannelJid]
            : pid !== 'admin1' && (prof.vipDeliveryMode || 'private') === 'private' && vipPhone.length >= 10
              ? [vipPhone]
              : [];
        const defaultTargets = vipPhone.length >= 10 ? [vipPhone] : [];

        const visAnk = (dayStore as any).visAnk || {};
        const visJodi = (dayStore as any).visJodi || {};
        const visPan = (dayStore as any).visPan || {};

        const gameGroups: Array<{ type: GameType; list: MarketItem[]; dictName: 'data' | 'jodiData' | 'pannelData' }> = [
          { type: 'ank', list: activeMarkets, dictName: 'data' },
          { type: 'jodi', list: activeBaseMarkets, dictName: 'jodiData' },
          { type: 'pannel', list: activeMarkets, dictName: 'pannelData' },
        ];

        gameGroups.forEach(({ type, list, dictName }) => {
          // VIP delivery is event-driven (digits + rate ready), never time-scheduled.
          if (pid !== 'admin1') return;
          if (!scheduleEnabled[type]) return;
          const dict = dayStore[dictName] || {};
          const visDict = type === 'ank' ? visAnk : type === 'jodi' ? visJodi : visPan;
          list.forEach((m, idx) => {
            if (!isMarketEnabledForDate(cfg, visDict, m?.n || '', date)) return;
            const rec = dict[idx];
            const marketKey = `${type}_${idx}`;
            const schTime = rec?.schTime || cfg.marketScheduleTimes?.[marketKey] || cfg.marketScheduleTimes?.[m.n];
            let schTargets: string[] = (
              rec?.schTargets ||
              cfg.marketScheduleTargets?.[marketKey] ||
              cfg.marketScheduleTargets?.[m.n] ||
              []
            ) as string[];
            schTargets = (schTargets || []).filter(Boolean);
            if (pid !== 'admin1') {
              // VIP delivery identity is immutable: private profile phone only.
              schTargets = defaultTargets.slice();
            } else if (schTargets.length === 0) {
              // Admin ledger: explicit marker → bot/server expands to WA Bot targetGroups
              schTargets = ['__USE_GLOBAL_TARGETS__'];
            }
            if (!m || !schTime) return;
            if (pid !== 'admin1' && schTargets.length === 0) return;
            const digitsStr = rec?.d ? String(rec.d).trim() : '';
            if (!digitsStr) return;
            if (!areSettlementTokensValid(type, digitsStr)) return;
            const schTimeNorm = String(schTime).trim().padStart(5, '0');
            const rateStr = getEffectiveCardRate(rec, type, cfg);
            const rateNum = parseFloat(rateStr) || 0;
            if (rateNum <= 0) return;
            const digitCount = countSettlementTokens(digitsStr, type);
            const investTotal = digitCount * rateNum;
            // sentRate is frozen ONLY on server mark_sent (actual WA delivery).
            // Do not overwrite here on WAIT — that caused schedule@70 vs PASS@270.
            schedulesList.push({
              key: `${pid}_${date}_${type}_${idx}_${schTimeNorm}${rec?.cardGeneration ? `_g${rec.cardGeneration}` : ''}`,
              cardGeneration: rec?.cardGeneration,
              marketName: m.n,
              type,
              index: idx,
              schTime: schTimeNorm,
              schTargets,
              message: buildCardIntelMessage({
                marketName: m.n,
                type,
                rec: rec || null,
                config: cfg,
                includeFooter: true,
                mode: 'customer',
                detailedMessage: cfg.detailedMessage !== false,
                cardDate: date,
              }),
              digits: digitsStr,
              sourceMode: rec?.sourceMode,
              scrapeSource: rec?.scrapeSource,
              trick: rec?.trick,
              invest: rateStr,
              rateNum,
              investTotal,
              date,
              profileId: pid,
            });
          });
        });

        // Ledger snapshot for offline PASS/FAIL.
        // Always materialize every card, even when its local day-record is still
        // absent. The UI renders missing records as WAIT, but the old sync code
        // omitted those cards from the server snapshot entirely; server-side
        // result matching then had no card to mark while schedule sync still worked.
        const markets: Array<{ n: string; type: string; index: number; enabled: boolean; hr?: number; min?: number }> = [];
        const cards: Record<string, any> = {};
        const snapshotCard = (
          type: GameType,
          idx: number,
          rec: DayMarketRecord | undefined,
          marketName: string,
        ) => {
          const safeRec = rec || ({ s: 'WAIT', d: '', r: '' } as DayMarketRecord);
          const mk = `${type}_${idx}`;
          const eff = getEffectiveCardRate(safeRec, type, cfg);
          cards[mk] = {
            s: safeRec.s || 'WAIT',
            d: safeRec.d || '',
            r: safeRec.r || eff,
            // Preserve Trick pipeline metadata across dashboard → server sync.
            od: safeRec.od || undefined,
            trick: safeRec.trick || undefined,
            positionRule: safeRec.positionRule || undefined,
            firstDigitMirrorCut: safeRec.firstDigitMirrorCut,
            triCut: safeRec.triCut,
            sniperOne: safeRec.sniperOne,
            tesla369: safeRec.tesla369,
            mssdState: safeRec.mssdState || undefined,
            weekdaySelectedDigits: safeRec.weekdaySelectedDigits || undefined,
            weekdayHitPosition: safeRec.weekdayHitPosition !== undefined ? safeRec.weekdayHitPosition : undefined,
            sourceMode: safeRec.sourceMode || undefined,
            strictPanel30: safeRec.strictPanel30 || undefined,
            smartSelection:safeRec.smartSelection||undefined,
            marketModel: safeRec.marketModel || undefined,
            loopId: assignedLoop(dayLoopConfig(prof,date),type,marketName,safeRec),
            sentLoopId: safeRec.sentLoopId,
            twoCardRecoveryShares: safeRec.twoCardRecoveryShares,
            twoCardRecoveryStrategy: safeRec.twoCardRecoveryStrategy,
            smartStaking: safeRec.smartStaking,
            sourceEditedAt: safeRec.sourceEditedAt || undefined,
            scrapeSource: safeRec.scrapeSource || undefined,
            sentScrapeSource: safeRec.sentScrapeSource || undefined,
            autoResultParity: safeRec.autoResultParity,
            autoRemovedResult: safeRec.autoRemovedResult,
            openCloseCut:safeRec.openCloseCut,
            carryResultSix: safeRec.carryResultSix,
            liveCombinedCut: safeRec.liveCombinedCut,
            scrapeResultDigit: safeRec.scrapeResultDigit || undefined,
            manualResult: safeRec.manualResult || undefined,
            manualPanelResult: safeRec.manualPanelResult || undefined,
            manualResultSources: safeRec.manualResultSources || undefined,
            mirroredFromAdmin: safeRec.mirroredFromAdmin || undefined,
            vipAutoStopSkipped: safeRec.vipAutoStopSkipped || undefined,
            vipAutoStopResumeEligible: safeRec.vipAutoStopResumeEligible || undefined,
            closeZeroAutoSkipped: (safeRec as any).closeZeroAutoSkipped || undefined,
            marketName: safeRec.marketName || String(marketName || '').trim().toUpperCase(),
            sentRate: safeRec.sentRate || undefined,
            sentInvest: safeRec.sentInvest || undefined,
            sentDigits: safeRec.sentDigits || undefined,
            cardGeneration: safeRec.cardGeneration,
            sentSourceMode: safeRec.sentSourceMode || undefined,
            sentTrick: safeRec.sentTrick || undefined,
            manualStatus: safeRec.manualStatus || undefined,
            backtestResult: safeRec.backtestResult || undefined,
            manualRate: safeRec.manualRate || undefined,
            manualOverrideAt: safeRec.manualOverrideAt || undefined,
            recRate: safeRec.recRate || undefined,
            // Omit absent recovery fields. Sending prevLoss:0 for every blank
            // card made the pull loop mistake an ordinary default r=10 for a
            // backend-finalized rate and overwrite the target calculation.
            prevLoss: safeRec.prevLoss !== undefined ? safeRec.prevLoss : undefined,
            targetProfitWithLoss: safeRec.targetProfitWithLoss !== undefined
              ? safeRec.targetProfitWithLoss
              : undefined,
            jodiOpenStatus: safeRec.jodiOpenStatus || undefined,
            jodiOpenResult: safeRec.jodiOpenResult || undefined,
            jodiOpenSettledAt: safeRec.jodiOpenSettledAt || undefined,
            // VIP is event-driven: schedule metadata must never leak from admin/default config.
            schTime: pid === 'admin1' ? (safeRec.schTime || cfg.marketScheduleTimes?.[mk] || '') : '',
            schTargets: pid === 'admin1'
              ? (safeRec.schTargets || cfg.marketScheduleTargets?.[mk] || []).filter(Boolean)
              : [],
          };
        };
        activeMarkets.forEach((m, idx) => {
          markets.push({ n: m.n, type: 'ank', index: idx, enabled: vipLiveMarketEligible(prof, date, 'ank', m.n) && isMarketEnabledForDate(cfg, visAnk, m.n, date), hr: m.hr, min: m.min });
          markets.push({ n: m.n, type: 'pannel', index: idx, enabled: vipLiveMarketEligible(prof, date, 'pannel', m.n) && isMarketEnabledForDate(cfg, visPan, m.n, date), hr: m.hr, min: m.min });
          snapshotCard('ank', idx, (dayStore.data || {})[idx], m.n);
          snapshotCard('pannel', idx, (dayStore.pannelData || {})[idx], m.n);
        });
        activeBaseMarkets.forEach((m, idx) => {
          const closeMarket = activeMarkets.find((candidate) => candidate.n === `${m.n} CLOSE`);
          markets.push({
            n: m.n,
            type: 'jodi',
            index: idx,
            enabled: vipLiveMarketEligible(prof, date, 'jodi', m.n) && isMarketEnabledForDate(cfg, visJodi, m.n, date),
            hr: closeMarket?.hr,
            min: closeMarket?.min,
          });
          snapshotCard('jodi', idx, (dayStore.jodiData || {})[idx], m.n);
        });
        const hiddenLedger=buildFinancialLedger(prof,date);
        for(const market of hiddenLedger.markets)if(market.index<0){
          const key=`${market.type}_${market.index}`;
          if(!cards[key]){markets.push(market);cards[key]=hiddenLedger.cards[key];}
        }
        ledgerProfiles[pid] = {
          name: prof.name,
          phone: vipPhone,
          deliveryMode: pid !== 'admin1' ? (prof.vipDeliveryMode || 'private') : 'private',
          deliveryTargets: pid !== 'admin1' ? vipDeliveryTargets : [],
          vipGroupJid: pid !== 'admin1' ? vipGroupJid : '',
          vipChannelJid: pid !== 'admin1' ? vipChannelJid : '',
          deliveryTargetName: pid !== 'admin1'
            ? String(prof.vipDeliveryMode === 'channel' ? prof.vipChannelName || '' : prof.vipGroupName || '')
            : '',
          vipAutoMode: pid !== 'admin1' ? prof.vipAutoMode !== false : false,
          schedulePolicy: scheduleEnabled,
          openToCloseCut: dayStore.openToCloseCut===true,
          autoResultParity: prof.config.autoResultParity === true,
          autoCarryResultSix: prof.config.autoCarryResultSix === true,
          autoRemoveResultDigit: prof.config.autoRemoveResultDigit === true,
          autoRemoveResultMirror: prof.config.autoRemoveResultMirror === true,
          autoRemoveResultUnique3: prof.config.autoRemoveResultUnique3===true,
          liveThreeFailReset: prof.config.liveThreeFailReset === true,
          detailedMessage: prof.config?.detailedMessage !== false,
          targetProfit: {
            ank: normalizeTargetProfit(prof.config?.ank?.tgt, 100),
            jodi: normalizeTargetProfit(prof.config?.jodi?.tgt, 100),
            pannel: normalizeTargetProfit(prof.config?.pannel?.tgt, 100),
          },
          // Share the replacement Split 2 policy and dated legacy seed with the backend.
          twoCardRecoveryVersion: 2,
          sameMarketRecovery: prof.config?.sameMarketRecovery !== false,
          fourWaveRelay: prof.config?.fourWaveRelay === true,
          profitCarry: Boolean(prof.config?.profitCarry || prof.profitCarry),
          openPassCloseZero: Boolean(prof.config?.openPassCloseZero || prof.openPassCloseZero),
          twoCardRecoveryLegacySplit:prof.config.twoCardRecoveryLegacySplit,
          splitMode: {
            ank: prof.config?.ankSplit !== false,
            pannel: prof.config?.panSplit !== false,
          },
          loopConfig: loopSettingsForDate(prof,date),
          markets,
          cards,
        };
      });

      // Signature includes rate so schedule WA text refreshes when rate changes
      const sigParts = schedulesList.map(
        (s) =>
          `${s.key}|${s.profileId || ''}|${s.marketName || ''}|${s.schTime || ''}|${s.digits || ''}|${s.rateNum || s.invest || ''}|${[...(s.schTargets || [])].sort().join(',')}`
      );
      const policySignature = Object.keys(state.profiles || {}).sort().map((pid) => {
        const prof = state.profiles[pid];
        const policy = pid === 'admin1' ? prof?.config?.scheduleTypeEnabled : prof?.vipScheduleEnabled;
        return `${pid}:${policy?.ank !== false ? 1 : 0}${policy?.jodi !== false ? 1 : 0}${policy?.pannel !== false ? 1 : 0}`;
      }).join('|');
      const messageFormatSignature = Object.keys(state.profiles || {}).sort().map((pid) =>
        `${pid}:${state.profiles[pid]?.config?.detailedMessage !== false ? 'detailed' : 'simple'}`
      ).join('|');
      const signature = `${date}|${messageFormatSignature}|${policySignature}|${sigParts.join(';')}`;
      const profileIds = Object.keys(state.profiles || {});
      const ledgerPayload = JSON.stringify({
        date,
        // Only the master owns the complete profile list. A scoped VIP page
        // must be a partial merge and can never imply that other VIPs were deleted.
        ...(isMasterApp ? { profileIds } : {}),
        profiles: ledgerProfiles,
      });
      const ledgerSig = ledgerPayload;

      if (adminSnapshotRunningRef.current) return;
      if (lastScheduleSyncRef.current !== signature) {
        requests.push(startupRequest(signal => fetch(apiUrl('/api/bot/sync_schedules'), {
          signal,
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...(vipParam ? profileAuthHeaders(vipParam) : {}) },
          body: JSON.stringify({
            schedules: schedulesList,
            ...(isMasterApp ? { profileIds } : {}),
            schedulePolicy: Object.fromEntries((Object.entries(state.profiles || {}) as Array<[string, UserProfile]>).map(([pid, prof]) => [
              pid,
              pid === 'admin1'
                ? (prof.config?.scheduleTypeEnabled || {})
                : (prof.vipScheduleEnabled || {}),
            ])),
          }),
        })).then((response) => {
          if (response.ok) lastScheduleSyncRef.current = signature;
        }).catch(() => null));
      }

      if (lastLedgerSyncRef.current !== ledgerSig) {
        requests.push(startupRequest(signal => fetch(apiUrl('/api/bot/sync_ledger'), {
          signal,
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...(vipParam ? profileAuthHeaders(vipParam) : {}) },
          body: ledgerPayload,
        })).then((response) => {
          if (response.ok) {
            lastLedgerSyncRef.current = ledgerSig;
            // Backend has finalized Admin/VIP target/recovery rates. Pull that
            // exact snapshot now instead of waiting for the polling interval.
            window.dispatchEvent(new Event('titan-ledger-synced'));
          }
        }).catch(() => null));
      }
      await Promise.allSettled(requests);
      } catch { /* Save/network failure: do not publish stale runtime data. */ } finally {
        syncInFlight = false;
        if (syncRequested && !disposed) {
          syncRequested = false;
          queueMicrotask(() => { void buildAndSync(); });
        }
      }
    };

    // Immediate once, then every 8s — independent of React render cycle
    buildAndSync();
    const t = setInterval(buildAndSync, 8000);
    let resumeTimer: ReturnType<typeof setTimeout> | undefined;
    const onResume = () => {
      clearTimeout(resumeTimer);
      if (document.visibilityState === 'hidden') {
        void buildAndSync(true);
        return;
      }
      resumeNotBefore=Date.now()+1400;
      resumeTimer = setTimeout(() => { void buildAndSync(); }, 1400);
    };
    const onLedgerDirty = () => { void buildAndSync(); };
    window.addEventListener('focus', onResume);
    window.addEventListener('pageshow', onResume);
    window.addEventListener('online', onResume);
    document.addEventListener('visibilitychange', onResume);
    window.addEventListener('titan-ledger-dirty', onLedgerDirty);
    return () => {
      disposed = true;
      clearTimeout(resumeTimer);
      clearInterval(t);
      window.removeEventListener('focus', onResume);
      window.removeEventListener('pageshow', onResume);
      window.removeEventListener('online', onResume);
      document.removeEventListener('visibilitychange', onResume);
      window.removeEventListener('titan-ledger-dirty', onLedgerDirty);
    };
  }, [serverHydrated]);

  // Toast Helper
  const showToast = (title: string, body: string, type: 'info' | 'success' | 'warning' | 'danger' = 'info') => {
    const id = Date.now().toString() + Math.random().toString().slice(2, 5);
    setToasts((prev) => [...prev, { id, title, body, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 5000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  /** Navigation is read-only: never materialize an empty archive day on a date click.
   *  Actual edits create that date's own record through ensureProfileStructure.
   *  Auto-creating blanks here could race the confirmed server archive and save
   *  empty digit-box records over previously saved history. */
  const handleDateChange = (date: string) => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date === currentDateRef.current) return;
    setTodayBacktest(false);
    followBusinessDayRef.current = date === titanLocalDateISO();
    currentDateRef.current = date;
    setCurrentDate(date);
    setAppState((prev) => {
      const prof = prev.profiles?.[activeId];
      if (!prof?.dayRecords?.[date]) return prev;
      let updatedProf = prof;
      if (date < titanLocalDateISO()) {
        updatedProf = calculateBacktestRecovery(prof, date);
      } else {
        const autoUpdated = applyAutoRatesToDayStore(prof, date, prev.profiles);
        if (autoUpdated) {
          updatedProf = { ...prof, dayRecords: { ...prof.dayRecords, [date]: autoUpdated } };
        }
      }
      if (updatedProf === prof) return prev;
      return { ...prev, profiles: { ...prev.profiles, [activeId]: updatedProf } };
    });
  };

  // Helper to ensure structure for profile.
  // This intentionally clones nested state: many handlers update a profile and
  // its day-store dictionaries in the same setState callback. Returning shared
  // nested objects here mutates the previous React state and can make schedule,
  // ledger, and localStorage updates race or disappear.
  const ensureProfileStructure = (prof: UserProfile | null | undefined, activeDayOnly = false): UserProfile => {
    const base: UserProfile =
      prof && typeof prof === 'object'
        ? prof
        : {
            name: 'MASTER ADMIN 1',
            phone: '7077550644',
            config: getDefaultConfig(),
            dayRecords: {},
            vipAccessEnabled: true,
          };
    const sourceConfig = base.config || getDefaultConfig();
    const defaultConfig = getDefaultConfig();

    const cloneRecordMap = (
      records?: Record<string, DayMarketRecord>,
    ): Record<string, DayMarketRecord> =>
      Object.fromEntries(
        Object.entries(records || {}).map(([key, record]) => [
          key,
          record
            ? {
                ...record,
                ...(Array.isArray(record.schTargets)
                  ? { schTargets: [...record.schTargets] }
                  : {}),
              }
            : record,
        ]),
      ) as Record<string, DayMarketRecord>;

    const cloneBooleanMap = (values?: Record<string, boolean>): Record<string, boolean> => ({
      ...(values || {}),
    });

    const clonedDayRecords: Record<string, DayRecordStore> = {};
    Object.entries(base.dayRecords || {}).forEach(([date, store]) => {
      // Read-only history needs no record copies for rendering/live snapshot merges.
      // General edit handlers retain the original full-copy behavior.
      if (activeDayOnly && date !== currentDate) { clonedDayRecords[date] = store; return; }
      clonedDayRecords[date] = {
        ...(store || {}),
        data: cloneRecordMap(store?.data),
        jodiData: cloneRecordMap(store?.jodiData),
        pannelData: cloneRecordMap(store?.pannelData),
        visAnk: cloneBooleanMap(store?.visAnk),
        visJodi: cloneBooleanMap(store?.visJodi),
        visPan: cloneBooleanMap(store?.visPan),
      };
    });

    const clonedConfig: ProfileConfig = {
      ...defaultConfig,
      ...sourceConfig,
      ank: { ...defaultConfig.ank, ...(sourceConfig.ank || {}) },
      jodi: { ...defaultConfig.jodi, ...(sourceConfig.jodi || {}) },
      pannel: { ...defaultConfig.pannel, ...(sourceConfig.pannel || {}) },
      customMarkets: sourceConfig.customMarkets?.map((market) => ({ ...market })),
      deletedMarketNames: sourceConfig.deletedMarketNames
        ? [...sourceConfig.deletedMarketNames]
        : undefined,
      marketScheduleTimes: sourceConfig.marketScheduleTimes
        ? { ...sourceConfig.marketScheduleTimes }
        : undefined,
      marketScheduleTargets: sourceConfig.marketScheduleTargets
        ? Object.fromEntries(
            Object.entries(sourceConfig.marketScheduleTargets).map(([key, targets]) => [
              key,
              Array.isArray(targets) ? [...targets] : [],
            ]),
          )
        : undefined,
      marketScrapeUrls: sourceConfig.marketScrapeUrls
        ? { ...sourceConfig.marketScrapeUrls }
        : undefined,
      marketAutoScheduleEnabled: sourceConfig.marketAutoScheduleEnabled
        ? { ...sourceConfig.marketAutoScheduleEnabled }
        : undefined,
      marketEnabled: sourceConfig.marketEnabled ? { ...sourceConfig.marketEnabled } : undefined,
      scheduleTypeEnabled: sourceConfig.scheduleTypeEnabled
        ? { ...sourceConfig.scheduleTypeEnabled }
        : { ...defaultConfig.scheduleTypeEnabled },
    };

    if (!clonedDayRecords[currentDate]) {
      clonedDayRecords[currentDate] = {
        data: {},
        jodiData: {},
        pannelData: {},
        visAnk: {},
        visJodi: {},
        visPan: {},
      };
    }

    return pinDayLoops({
      ...base,
      config: clonedConfig,
      dayRecords: clonedDayRecords,
    },currentDate);
  };

  // Repair missing admin1 ONCE only
  const adminRepairedRef = useRef(false);
  useEffect(() => {
    if (!isMasterApp || adminRepairedRef.current) return;
    if (appState.profiles?.admin1) {
      adminRepairedRef.current = true;
      return;
    }
    adminRepairedRef.current = true;
    setAppState((prev) => {
      if (prev.profiles?.admin1) return prev;
      return {
        ...prev,
        activeId: prev.activeId || 'admin1',
        profiles: {
          ...prev.profiles,
          admin1: {
            name: 'MASTER ADMIN 1',
            phone: '7077550644',
            config: getDefaultConfig(),
            dayRecords: {},
            vipAccessEnabled: true,
          },
        },
      };
    });
  }, []);

  // Ensure current profile has records for today
  // UI-only changes must not clone the entire historical archive again.
  // Keep update handlers' independent copies; only memoize this read-only render snapshot.
  const currentProfile = useMemo(() => ensureProfileStructure(
    activeProfile || appState.profiles?.admin1, true
  ), [activeProfile, appState.profiles?.admin1, currentDate]);

  const displayedCarryMode=carryControlMode(currentProfile,currentDate);
  const displayedResultRemoval=datedResultRemovalSettings(currentProfile,currentDate);

  const gameMarkets = useMemo(() => ({ank: getEffectiveMarkets(currentProfile.config), jodi: getEffectiveBaseMarkets(currentProfile.config), pannel: getEffectiveMarkets(currentProfile.config)}), [currentProfile.config]);

  const catalogInspectorRef=useRef<ReturnType<typeof createCatalogInspector>|null>(null);
  if(!catalogInspectorRef.current)catalogInspectorRef.current=createCatalogInspector();

  // Persist an activated day's setup once, including when the browser resumes after rollover.
  useEffect(() => {
    if (!serverHydrated) return;
    setAppState(prev => {
      let changed=false;const profiles={...prev.profiles};
      for(const [pid,prof] of Object.entries(profiles)) {
        const pinned=pinRecoverySettings(pinDayLoops(updateProfileMarketCatalog(prof,prof.config,catalogInspectorRef.current!),currentDate),currentDate);
        if(pinned!==prof){profiles[pid]=pinned;changed=true;}
      }
      return changed?{...prev,profiles}:prev;
    });
  },[serverHydrated,currentDate,appState.profiles]);

  // Financial formulas stay unchanged; recalculate only when their inputs change.
  const globalStats = useMemo(() => {
    try { return calculateGlobalStats(currentProfile, currentDate); }
    catch (error) {
      console.error('calculateGlobalStats error', error);
      return {
        ank: { spent: 0, win: 0, pl: 0, port: 0, maxLoss: 0 },
        jodi: { spent: 0, win: 0, pl: 0, port: 0, maxLoss: 0 },
        pannel: { spent: 0, win: 0, pl: 0, port: 0, maxLoss: 0 },
      };
    }
  }, [currentProfile, currentDate]);

  // Rate/recovery calculation is backend-only for Admin and VIP. Running a
  // second browser calculator here caused an A→B→A sync feedback loop: the UI
  // wrote one suggestion, the backend returned its authoritative value, and
  // every difference triggered another ledger push (visible blink/crash).

  // Check Notifications Permission
  const requestNotificationPermission = () => {
    if (!('Notification' in window)) {
      showToast('⚠️ Not Supported', 'Push notifications are not supported on this browser.', 'danger');
      return;
    }
    if (Notification.permission === 'granted') {
      showToast('🔔 Notifications Active', 'Push alerts are active for Titan Nova.', 'success');
    } else {
      Notification.requestPermission().then((permission) => {
        if (permission === 'granted') {
          showToast('✅ Notifications Enabled!', 'You will receive real-time alerts.', 'success');
        } else {
          showToast('❌ Permission Denied', 'Notifications were blocked.', 'danger');
        }
      });
    }
  };

  // Update market record field. Business settlement and replies are backend-only.
  useEffect(()=>{
    const progress=historyTieProgress,gate=marketHistoryRuns.current!;
    if(progress&&activeTab!=='ank'){
      gate.cancelAll();
      setHistoryTieProgress(null);setBulkAction(action=>action==='positions:market-history'?null:action);
    }
  },[activeTab,historyTieProgress]);

  const scrapeIntents=useRef({next:0,ids:new Map<string,number>()});
  useEffect(()=>{scrapeIntents.current.ids.clear();},[activeId,currentDate]);
  const captureScrapeGuard = (type: GameType, idx: number, market: string): ScrapeCommitGuard => {
    const day = appStateRef.current.profiles[activeId]?.dayRecords?.[currentDate];
    const dict = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
    const record=day?.[dict]?.[idx],requestId=++scrapeIntents.current.next;
    scrapeIntents.current.ids.set(`${activeId}|${currentDate}|${type}|${idx}`,requestId);
    return { profileId: activeId, date: currentDate, market: market.trim().toUpperCase(),requestId,selectionIntent:scrapeSelectionIntent(record),generation:Number(record?.cardGeneration||0),
      version: scrapeRequestVersion(record), revision: Number(day?.backtestRevision || 0) };
  };

  const canCommitScrape = (state: AppState, guard: ScrapeCommitGuard, type: GameType, idx: number): boolean => {
        const profile = state.profiles[guard.profileId];
        const day = profile?.dayRecords?.[guard.date];
        const markets = type === 'jodi' ? getEffectiveBaseMarkets(profile?.config) : getEffectiveMarkets(profile?.config);
        const visible = type === 'ank' ? day?.visAnk : type === 'jodi' ? day?.visJodi : day?.visPan;
        const record = day?.[type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData']?.[idx];
        if(guard.requestId!==undefined&&scrapeIntents.current.ids.get(`${guard.profileId}|${guard.date}|${type}|${idx}`)!==guard.requestId)return false;
        if(guard.generation!==undefined&&Number(record?.cardGeneration||0)!==guard.generation)return false;
        const ank = findHistoricalMarketRecord(day?.data || {}, idx, guard.market);
        if(guard.sourceMode!==undefined){const source=getScrapeSource(record);if(source?.mode!==guard.sourceMode||source.digits!==guard.sourceDigits)return false;}
        if (guard.ankDigits !== undefined && normalizeAnkDigits(ank?.d).join(',') !== guard.ankDigits) return false;
        if (activeIdRef.current !== guard.profileId || currentDateRef.current !== guard.date ||
            String(markets[idx]?.n || '').trim().toUpperCase() !== guard.market ||
            !canKeepScrapeRequest(record,guard.version,guard.selectionIntent) ||
            isSourceScrapeFrozen(record,guard.date<titanLocalDateISO()) ||
            !isMarketEnabledForDate(profile?.config || getDefaultConfig(), visible, markets[idx]?.n || '', guard.date) ||
            record?.sentRate || record?.sentDigits || ['QUEUED', 'SENDING', 'SENT', 'SETTLED'].includes(String(record?.dispatchState))) return false;
    return true;
  };

  useEffect(()=>{
    const run=bulkScrapeRun.current;
    if(run&&(activeId!==run.owner||currentDate!==run.date||activeTab!==(run.tab||'ank'))){
      bulkScrapeRun.current=null;run.controller.abort();
      setBulkAction(action=>action?.startsWith('scrape:')||action==='positions:live-combined-cut'||action?.startsWith('panel:')?null:action);
    }
  },[activeId,currentDate,activeTab]);
  useEffect(()=>()=>{const run=bulkScrapeRun.current;bulkScrapeRun.current=null;run?.controller.abort();},[]);

  useEffect(()=>{
    const gate=marketHistoryRuns.current!;
    const bulk=marketHistoryBulkRun.current;
    if(bulk&&(activeIdRef.current!==bulk.owner||currentDateRef.current!==bulk.date||activeTab!=='ank')){
      marketHistoryBulkRun.current=null;
      gate.cancelAll();
      if(bulk.tie)setHistoryTieProgress(null);
      setBulkAction(action=>action==='positions:market-history'?null:action);
    }
    for(const run of gate.all())if(((!isMasterApp&&currentProfile.vipAccessEnabled===false)||!canApplyMarketHistoryChoice(appState.profiles[run.guard.profileId]?.dayRecords?.[run.guard.date]?.data?.[run.index],run.guard.market)||!canCommitScrape(appState,run.guard,'ank',run.index))&&gate.cancel(run)){
      if(!marketHistoryBulkRun.current)setBulkAction(action=>action==='positions:market-history'?null:action);
    }
  },[appState,activeId,currentDate,activeTab,isMasterApp,currentProfile.vipAccessEnabled]);
  useEffect(()=>()=>{marketHistoryBulkRun.current=null;const gate=marketHistoryRuns.current!;gate.cancelAll();},[]);

  const handleUpdateRecord = (
    type: GameType,
    idx: number,
    field: 'd' | 'r' | 's' | 'schTime' | 'sourceMode',
    value: any,
    options?: { smartSelection?: DayMarketRecord['smartSelection']; mssdState?: DayMarketRecord['mssdState']; masterFlow?: DayMarketRecord['masterFlow']; positionRule?: DayMarketRecord['positionRule']; sourceMode?: CardSourceMode; mirrorAdmin?: boolean; sourceDigits?: string; marketModel?: MarketModelSummary; scrapeGuard?: ScrapeCommitGuard; scrapedSourceMode?: CardSourceMode; strictPanel30?: StrictPanel30Selection },
  ) => {
    if (bulkRestoreInFlightRef.current) return false;
    if (options?.scrapeGuard && !canCommitScrape(appStateRef.current, options.scrapeGuard, type, idx)) {
      if(!bulkScrapeRun.current)showToast('Source unchanged','Card, date or source changed during scraping. Retry on the current editable card.','warning');
      return false;
    }
    if(!options?.scrapeGuard&&['d','r','s','sourceMode'].includes(field))scrapeIntents.current.ids.delete(`${activeId}|${currentDate}|${type}|${idx}`);
    const actualResult = field === 's' && typeof value === 'object' ? normalizeManualResult(type, value?.actualResult) : undefined;
    const actualPanel = field === 's' && typeof value === 'object' ? normalizeManualResult('pannel', value?.actualPanel) : undefined;
    if (field === 's' && typeof value === 'object') value = value?.status;
    const dictName = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
    const sourceProfile = appStateRef.current.profiles?.[activeId] || appStateRef.current.profiles?.admin1;
    const sourceMarkets = type === 'jodi' ? getEffectiveBaseMarkets(sourceProfile?.config) : getEffectiveMarkets(sourceProfile?.config);
    const stableMarketName = String(sourceMarkets[idx]?.n || '').trim().toUpperCase();
    if (field === 'd' && String(value || '').trim()) {
      const mLabel = stableMarketName || `CARD #${idx}`;
      const modeLabel = options?.positionRule || options?.sourceMode || options?.scrapedSourceMode || 'MANUAL';
      recordMainActivity({
        date: currentDate,
        profileId: activeId,
        market: mLabel,
        type,
        action: 'DIGITS_APPLIED',
        digits: String(value),
        sourceMode: String(modeLabel),
        subtitle: `Step: ${mLabel} (${type.toUpperCase()}) me ${modeLabel} logic se digits [${String(value)}] select kiye gaye.`,
      });
    } else if (field === 'r' && Number(value) > 0) {
      const mLabel = stableMarketName || `CARD #${idx}`;
      recordMainActivity({
        date: currentDate,
        profileId: activeId,
        market: mLabel,
        type,
        action: 'RATE_LOCKED',
        rate: String(value),
        subtitle: `${mLabel} (${type.toUpperCase()}) ka rate Rs ${value} fix kiya gaya — ab card play ke liye ready hai.`,
      });
    } else if (field === 's' && (value === 'PASS' || value === 'FAIL')) {
      const mLabel = stableMarketName || `CARD #${idx}`;
      recordMainActivity({
        date: currentDate,
        profileId: activeId,
        market: mLabel,
        type,
        action: 'RESULT_SETTLED',
        status: value,
        actual: actualResult || undefined,
        subtitle: value === 'PASS'
          ? `Badhai ho! ${mLabel} (${type.toUpperCase()}) ka result ${actualResult || ''} aaya aur apna game PASS ho gaya!`
          : `${mLabel} (${type.toUpperCase()}) ka result ${actualResult || ''} aaya (FAIL). Agle card par smart recovery adjust hogi.`,
      });
    }

    setAppState((prev) => {
      if (options?.scrapeGuard && !canCommitScrape(prev, options.scrapeGuard, type, idx)) return prev;
      const updatedProfiles = { ...prev.profiles };

      // Update current profile
      const prof = ensureProfileStructure(updatedProfiles[activeId] || updatedProfiles['admin1'], true);
      const dayStore = prof.dayRecords[currentDate] || {};
      const dict = { ...(dayStore[dictName] || {}) };
      let rec = { ...(dict[idx] || { s: 'WAIT', d: '', r: '' }) };
      const sourceIsFrozen = Boolean(rec.sentRate || rec.sentDigits || rec.dispatchState === 'SENT' || rec.dispatchState === 'SETTLED');
      if ((field === 'd' || field === 'sourceMode') && sourceIsFrozen) return prev;

      let priorCheckedBt: DayMarketRecord['backtestResult'] | undefined;
      // Any explicit digit replacement (manual or scraper-fed) starts a new
      // source pipeline. Never retain the previous Trick source/tag.
      if (field === 'd') {
        if (isEditableSourceSkip(rec)) rec.s = 'WAIT';
        rec.sourceEditedAt = Math.max(Date.now(), (rec.marketModel?.updatedAt || 0) + 1, (rec.sourceEditedAt || 0) + 1);
        delete rec.marketModel;
        // A new source selection owns the complete pipeline. Old AUTO cuts
        // must not be revived by ledger polling or by a later save response.
        delete rec.scrapeSource;
        delete rec.autoResultParity;
        delete rec.autoRemovedResult;
        delete rec.openCloseCut;
        delete rec.carryResultSix;
        delete rec.firstDigitMirrorCut;
        delete rec.triCut;
        delete rec.sniperOne;
        delete rec.tesla369;
        delete rec.mssdState;
        delete rec.liveCombinedCut;
        delete rec.strictPanel30;
        if (currentDate < titanLocalDateISO() && rec.backtestResult?.checked && !rec.manualStatus) {
          priorCheckedBt = { ...rec.backtestResult };
        }
        if (currentDate < titanLocalDateISO() && (autoBacktestResult || rec.backtestResult&&!rec.manualStatus)) {
          rec.s='WAIT'; delete rec.manualStatus; delete rec.backtestResult; delete rec.manualResultSources;
        }
        delete rec.mirroredFromAdmin;
        delete rec.od;
        delete rec.trick;
        delete rec.positionRule;
        delete rec.weekdaySelectedDigits;
        delete rec.weekdayHitPosition;
        // Direct digit edits are manual. Scrape handlers overwrite this with
        // their exact source mode in the immediately following state update.
        rec.sourceMode = 'MANUAL';
        // A backend-finalized automatic rate belongs to the previous digit
        // set. Release only that suggestion so the server recalculates from
        // the new digits + current recovery debt. A genuine manual override
        // remains authoritative for this unsent card.
        if (!rec.manualRate && !rec.sentRate && rec.dispatchState !== 'SENT') {
          delete rec.recRate;
          delete rec.prevLoss;
          delete rec.targetProfitWithLoss;
          delete rec.smartStaking;
          delete rec.rateFinalizedFrom;
          delete rec.rateFinalizedAt;
        }
      }
      (rec as any)[field] = value;
      if (field === 'd') {if(options?.smartSelection)rec.smartSelection={...options.smartSelection,sourceVersion:Number(rec.sourceEditedAt||0)};else delete rec.smartSelection; if(options?.mssdState)rec.mssdState={...options.mssdState,outputVersion:Number(rec.sourceEditedAt||0)};else delete rec.mssdState; if(options?.masterFlow)rec.masterFlow=options.masterFlow;else delete rec.masterFlow; if(options?.positionRule)rec.positionRule=options.positionRule; if(options?.sourceMode)rec.sourceMode=options.sourceMode;}
      if (field === 'd' && options?.scrapedSourceMode) rec.sourceMode = options.scrapedSourceMode;
      if (field === 'd' && options?.scrapedSourceMode === 'FLOW_3_1' && priorCheckedBt?.actual && !autoBacktestResult) {
        rec = evaluateBacktest(rec as DayMarketRecord, type, priorCheckedBt.actual, priorCheckedBt.openActual);
        if (rec.backtestResult) {
          rec.backtestResult = { ...rec.backtestResult, updatedAt: Math.max(Date.now(), Number(priorCheckedBt.updatedAt || 0) + 1) };
        }
      }
      if (field === 'd' && options?.strictPanel30) { rec.strictPanel30 = options.strictPanel30; rec.s = options.strictPanel30.decision === 'SKIP' ? 'SKIP' : 'WAIT'; delete rec.manualStatus; delete rec.backtestResult; delete rec.manualResultSources; }
      if (type === 'ank' && (field === 'sourceMode' || options?.scrapedSourceMode)) {
        rec.scrapeSource = normalizeScrapeSource({ mode: options?.scrapedSourceMode || value, digits: options?.sourceDigits || rec.d });
        if (options?.marketModel) applyMarketModelSummary(rec, options.marketModel, options.sourceDigits);
        delete rec.scrapeResultDigit;
      }
      if (field === 'd' || field === 's') { delete rec.scrapeResultDigit; delete rec.manualResult; }
      if (field === 's' && (value === 'PASS' || value === 'FAIL')) rec.manualResult = actualResult;
      if (field === 's') { delete rec.manualResultSources; delete rec.manualPanelResult; }
      if (actualPanel) rec.manualPanelResult = actualPanel;
      if (stableMarketName) rec.marketName = stableMarketName;
      if (field === 's') {
        rec.manualStatus = true;
        delete rec.backtestResult;
        if ((value === 'PASS' || value === 'FAIL') && !rec.sentRate) {
          const freezeRate = String(rec.r || rec.recRate || '').trim();
          if (freezeRate && Number(freezeRate) > 0) {
            rec.sentRate = freezeRate;
            const tokCnt = String(rec.sentDigits || rec.d || '').split(/[,|\s]+/).filter(Boolean).length;
            rec.sentInvest = rec.smartStaking?.isSmartStaking && Number(rec.smartStaking.totalInvest) > 0
              ? Number(rec.smartStaking.totalInvest)
              : tokCnt * Number(freezeRate);
          }
          rec.settledAt = rec.settledAt || Date.now();
        }
      }
      if (field === 'r') rec.manualRate = true;
      if (field === 's' || field === 'r') rec.manualOverrideAt = Date.now();
      if (field === 's' && value === 'WAIT') {
        if (rec.sentRate || rec.sentDigits || rec.sentAt) rec.deliveryRestoredAt = Date.now();
        delete rec.manualRate;
        delete rec.rateFinalizedAt;
        delete rec.rateFinalizedFrom;
        delete rec.sentRate;
        delete rec.sentInvest;
        delete rec.sentDigits;
        delete rec.sentSourceMode;
        delete rec.sentTrick;
        delete rec.sentScrapeSource;
        delete rec.dispatchState;
        delete rec.dispatchKey;
        delete rec.queuedAt;
        delete rec.sentAt;
        delete rec.settledAt;
        delete rec.jodiOpenStatus;
        delete rec.jodiOpenResult;
        delete rec.jodiOpenSettledAt;
        if (currentDate < titanLocalDateISO()) rec = { ...restoreBacktestRecord(rec as DayMarketRecord), manualStatus: true, manualOverrideAt: Date.now() };
      }
      dict[idx] = rec as DayMarketRecord;

      prof.dayRecords[currentDate] = {
        ...(prof.dayRecords[currentDate] || {}),
        [dictName]: dict,
      };

      if (currentDate < titanLocalDateISO() && !bulkScrapeRun.current) {
        updatedProfiles[activeId] = calculateBacktestRecovery(prof, currentDate);
      } else {
        const autoUpdated = applyAutoRatesToDayStore(prof, currentDate, updatedProfiles);
        if (autoUpdated) prof.dayRecords[currentDate] = autoUpdated;
        updatedProfiles[activeId] = prof;
      }

      // If Master Admin 1, sync status to all VIP profiles (each VIP keeps own rates/wallet)
      // and queue individual Congrats/Bad luck to each VIP's phone
      if (isMasterApp && activeId === 'admin1' && options?.mirrorAdmin !== false) {
        Object.keys(updatedProfiles).forEach((pid) => {
          if (pid === 'admin1') return;
          if (!vipCopiesAdmin(updatedProfiles[pid])) return;
          // VIP rates are backend-owned per profile. Admin digit/status may be
          // mirrored, but typing an Admin rate must never overwrite VIP rates.
          if (field === 'r') return;
          const p = ensureProfileStructure(updatedProfiles[pid], true);
          if (!vipLiveMarketEligible(p, currentDate, type, stableMarketName)) return;
          const vipMarkets = type === 'jodi' ? getEffectiveBaseMarkets(p.config) : getEffectiveMarkets(p.config);
          const vipIdx = findMarketIndexByName(vipMarkets, stableMarketName);
          if (vipIdx < 0) return;
          // Read-only is a UI permission, not a processing/settlement switch.
          const pStore = p.dayRecords[currentDate] || {};
          const pDict = { ...(pStore[dictName] || {}) };
          let pRec = { ...(pDict[vipIdx] || { s: 'WAIT', d: '', r: '' }) };
          const vipSourceIsFrozen = Boolean(pRec.sentRate || pRec.sentDigits || pRec.dispatchState === 'SENT' || pRec.dispatchState === 'SETTLED');
          if ((field === 'd' || field === 'sourceMode') && (vipSourceIsFrozen || (options?.scrapeGuard && pRec.dispatchState === 'QUEUED'))) return;

          // Keep VIP mirrors independent from the previous Trick pipeline when
          // a fresh digit value is pushed from manual input or scraping.
          if (field === 'd') {
            if (isEditableSourceSkip(pRec)) pRec.s = 'WAIT';
            // Admin's new COMBO / manual source replaces every previous cut
            // and provenance tag; VIP copies must not reintroduce stale AUTO.
            delete pRec.scrapeSource;
            delete pRec.autoResultParity;
            delete pRec.autoRemovedResult;
            delete pRec.openCloseCut;
            delete pRec.carryResultSix;
            delete pRec.firstDigitMirrorCut;
            delete pRec.triCut;
            delete pRec.sniperOne;
            delete pRec.tesla369;
            delete pRec.mssdState;
            delete pRec.liveCombinedCut;
            pRec.sourceEditedAt = Math.max(Date.now(), (pRec.marketModel?.updatedAt || 0) + 1, (pRec.sourceEditedAt || 0) + 1);
            delete pRec.marketModel;
            delete pRec.strictPanel30;
            if (currentDate < titanLocalDateISO() && (autoBacktestResult || pRec.backtestResult&&!pRec.manualStatus)) {
              pRec.s='WAIT'; delete pRec.manualStatus; delete pRec.backtestResult; delete pRec.manualResultSources;
            }
            delete pRec.od;
            delete pRec.trick;
            delete pRec.positionRule;
            delete pRec.weekdaySelectedDigits;
            delete pRec.weekdayHitPosition;
            pRec.mirroredFromAdmin = true;
            pRec.sourceMode = 'MANUAL';
            if (!pRec.manualRate && !pRec.sentRate && pRec.dispatchState !== 'SENT') {
              delete pRec.recRate;
              delete pRec.prevLoss;
              delete pRec.targetProfitWithLoss;
              delete pRec.rateFinalizedFrom;
              delete pRec.rateFinalizedAt;
            }
          }
          (pRec as any)[field] = field === 's' && actualResult
            ? manualResultStatus(type, pRec.sentDigits || pRec.d, actualResult) : value;
          if (field === 'd') {if(options?.smartSelection)pRec.smartSelection={...options.smartSelection,sourceVersion:Number(pRec.sourceEditedAt||0)};else delete pRec.smartSelection; if(options?.mssdState)pRec.mssdState={...options.mssdState,outputVersion:Number(pRec.sourceEditedAt||0)};else delete pRec.mssdState; if(options?.masterFlow)pRec.masterFlow=options.masterFlow;else delete pRec.masterFlow; if(options?.positionRule)pRec.positionRule=options.positionRule; if(options?.sourceMode)pRec.sourceMode=options.sourceMode;}
          if (field === 'd' && options?.scrapedSourceMode) pRec.sourceMode = options.scrapedSourceMode;
          if (field === 'd' && options?.strictPanel30) { pRec.strictPanel30 = options.strictPanel30; pRec.s = options.strictPanel30.decision === 'SKIP' ? 'SKIP' : 'WAIT'; delete pRec.manualStatus; delete pRec.backtestResult; delete pRec.manualResultSources; }
          if (type === 'ank' && (field === 'sourceMode' || options?.scrapedSourceMode)) {
            pRec.scrapeSource = normalizeScrapeSource({ mode: options?.scrapedSourceMode || value, digits: options?.sourceDigits || pRec.d });
            if (options?.marketModel) applyMarketModelSummary(pRec, options.marketModel, options.sourceDigits);
            delete pRec.scrapeResultDigit;
          }
          if (field === 'd' || field === 's') { delete pRec.scrapeResultDigit; delete pRec.manualResult; }
          if (field === 's' && (value === 'PASS' || value === 'FAIL')) pRec.manualResult = actualResult;
          if (field === 's') { delete pRec.manualResultSources; delete pRec.manualPanelResult; }
          if (actualPanel) pRec.manualPanelResult = actualPanel;
          if (field === 'sourceMode') pRec.mirroredFromAdmin = true;
          if (stableMarketName) pRec.marketName = stableMarketName;
          if (field === 's') { pRec.manualStatus = true; delete pRec.backtestResult; }
          if (field === 's') pRec.manualOverrideAt = Date.now();
          if (field === 's' && value === 'WAIT') {
            if (pRec.sentRate || pRec.sentDigits || pRec.sentAt) pRec.deliveryRestoredAt = Date.now();
            delete pRec.manualRate;
            delete pRec.rateFinalizedAt;
            delete pRec.rateFinalizedFrom;
            delete pRec.sentRate;
            delete pRec.sentInvest;
            delete pRec.sentDigits;
            delete pRec.sentSourceMode;
            delete pRec.sentTrick;
            delete pRec.sentScrapeSource;
            delete pRec.dispatchState;
            delete pRec.dispatchKey;
            delete pRec.queuedAt;
            delete pRec.sentAt;
            delete pRec.settledAt;
            delete pRec.jodiOpenStatus;
            delete pRec.jodiOpenResult;
            delete pRec.jodiOpenSettledAt;
            if (currentDate < titanLocalDateISO()) pRec = { ...restoreBacktestRecord(pRec as DayMarketRecord), manualStatus: true, manualOverrideAt: Date.now() };
          }
          // Admin status mirroring must never freeze the Admin/UI cached rate
          // onto a VIP card. VIP settlement uses its own backend r/sentRate.
          pDict[vipIdx] = pRec as DayMarketRecord;

          p.dayRecords[currentDate][dictName] = pDict;
          if (currentDate < titanLocalDateISO() && !bulkScrapeRun.current) {
            updatedProfiles[pid] = calculateBacktestRecovery(p, currentDate);
          } else {
            const vipAuto = applyAutoRatesToDayStore(p, currentDate, updatedProfiles);
            if (vipAuto) p.dayRecords[currentDate] = vipAuto;
            updatedProfiles[pid] = p;
          }
        });
      }

      return { ...prev, profiles: updatedProfiles };
    });

    if (field === 'r') {
      const pid = activeId || 'admin1';
      const syncKey = `${pid}_${currentDate}_${type}_${idx}`;
      const pendingRate = String(value ?? '');
      manualRateEditingRef.current.add(syncKey);
      pendingManualRatesRef.current.set(syncKey, pendingRate);
      const previousTimer = manualRateSyncTimersRef.current.get(syncKey);
      if (previousTimer) clearTimeout(previousTimer);
      const timer = setTimeout(async () => {
        manualRateSyncTimersRef.current.delete(syncKey);
        try {
          const response = await profileMutationQueueRef.current.enqueue(`card:${syncKey}`, () => fetch(apiUrl('/api/bot/ledger_set_card'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...profileAuthHeaders(pid) },
            body: JSON.stringify({
              profileId: pid,
              type,
              index: idx,
              date: currentDate,
              rate: pendingRate,
            }),
          }));
          const result = await response.json().catch(() => null);
          if (!response.ok || result?.status !== 'success') {
            throw new Error(result?.message || `HTTP ${response.status}`);
          }
          // A newer keystroke may already be pending. Never let this older
          // acknowledgement release its edit lock or pull over the newer text.
          if (pendingManualRatesRef.current.get(syncKey) !== pendingRate) return;
          pendingManualRatesRef.current.delete(syncKey);
          manualRateEditingRef.current.delete(syncKey);
          lastLedgerSyncRef.current = '';
          window.dispatchEvent(new Event('titan-ledger-synced'));
        } catch (error: any) {
          if (pendingManualRatesRef.current.get(syncKey) === pendingRate) {
            pendingManualRatesRef.current.delete(syncKey);
            manualRateEditingRef.current.delete(syncKey);
          }
          showToast('❌ Rate Sync Failed', error?.message || 'Backend rate update failed', 'danger');
          window.dispatchEvent(new Event('titan-ledger-synced'));
        }
      }, 350);
      manualRateSyncTimersRef.current.set(syncKey, timer);
    } else if (field === 's') {
      const pids = isMasterApp && activeId === 'admin1'
        ? Object.keys(appStateRef.current.profiles || {}).filter(pid => pid === activeId || (options?.mirrorAdmin !== false && vipCopiesAdmin(appStateRef.current.profiles[pid])))
        : [activeId];
      pids.forEach((pid) => {
        const p = appStateRef.current.profiles?.[pid];
        if (p && !vipLiveMarketEligible(p, currentDate, type, stableMarketName)) return;
        const settlementMarkets = type === 'jodi' ? getEffectiveBaseMarkets(p?.config) : getEffectiveMarkets(p?.config);
        const profileIdx = pid === activeId ? idx : findMarketIndexByName(settlementMarkets, stableMarketName);
        if (profileIdx < 0) return;
        const pRec = p?.dayRecords?.[currentDate]?.[dictName]?.[profileIdx];
        const settlementMarketName = String(pRec?.marketName || settlementMarkets[profileIdx]?.n || stableMarketName).trim().toUpperCase();
        const cardSyncKey = `${pid}_${currentDate}_${type}_${profileIdx}`;
        const pendingRate = pendingManualRatesRef.current.get(cardSyncKey);
        const settlementRate = pendingRate ?? String(pRec?.r || pRec?.recRate || '');
        const settlementDigits = String(pRec?.d || '');
        // Cancel the delayed rate-only command. This status command carries
        // the newest manual rate atomically, avoiding stale settlement.
        const pendingTimer = manualRateSyncTimersRef.current.get(cardSyncKey);
        if (pendingTimer) {
          clearTimeout(pendingTimer);
          manualRateSyncTimersRef.current.delete(cardSyncKey);
        }
        let issuedAt = 0;
        let transportUncertain = false;
        profileMutationQueueRef.current.enqueue(`card:${cardSyncKey}`, async () => {
          issuedAt = Date.now();
          try {
            return await fetch(apiUrl('/api/bot/ledger_set_card'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...profileAuthHeaders(pid) },
          body: JSON.stringify({
            profileId: pid,
            type,
            index: profileIdx,
            date: currentDate,
            ...(field === 's' ? {
              status: String(value).toUpperCase(),
              actualResult,
              actualPanel,
              linkRelatedResults: true,
              rate: settlementRate,
              digits: settlementDigits,
              sourceMode: pRec?.sourceMode,
              trick: pRec?.trick,
              positionRule: pRec?.positionRule,
              marketName: settlementMarketName,
              manualSettlement: value === 'PASS' || value === 'FAIL',
              mirrorFromAdmin: isMasterApp && activeId === 'admin1' && pid !== 'admin1',
            } : {}),
          }),
            });
          } catch (error) {
            transportUncertain = true;
            throw error;
          }
        }).then(async (response) => {
          const result = await response.json().catch(() => null);
          if (!response.ok || result?.status !== 'success') {
            if (response.ok && !result) transportUncertain = true;
            throw new Error(result?.message || `HTTP ${response.status}`);
          }
          pendingManualRatesRef.current.delete(cardSyncKey);
          manualRateEditingRef.current.delete(cardSyncKey);
          lastLedgerSyncRef.current = '';
          window.dispatchEvent(new Event('titan-ledger-synced'));
        }).catch(async (error: any) => {
          if (transportUncertain && issuedAt && currentDate === titanLocalDateISO()) {
            const confirmation = await confirmSettlementAfterTransportError({
              profileId: pid, type, index: profileIdx, date: currentDate,
              status: String(value).toUpperCase(), issuedAt,
              snapshotUrl: apiUrl(`/api/bot/ledger_snapshot?profileId=${encodeURIComponent(pid)}`),
              headers: profileAuthHeaders(pid),
            });
            if (confirmation === 'confirmed') {
              pendingManualRatesRef.current.delete(cardSyncKey);
              manualRateEditingRef.current.delete(cardSyncKey);
              lastLedgerSyncRef.current = '';
              window.dispatchEvent(new Event('titan-ledger-synced'));
              return;
            }
          }
          pendingManualRatesRef.current.delete(cardSyncKey);
          manualRateEditingRef.current.delete(cardSyncKey);
          showToast('❌ Status Sync Failed', transportUncertain
            ? 'Server confirmation nahi mila. Status verify karke hi retry karein; duplicate settlement avoid karein.'
            : error?.message || 'Backend settlement failed', 'danger');
          window.dispatchEvent(new Event('titan-ledger-synced'));
        });
      });
      lastLedgerSyncRef.current = '';
    }

    // PASS/FAIL follow-up is queued by ledger_set_card on the backend. The
    // browser only issues the command and later renders the server snapshot.
    return true;
  };

  // Release a genuine UI manual override and ask the backend SSOT to restore
  // the current calculated loss-recovery rate. This is deliberately separate
  // from typing in the rate box, which remains an authoritative manual edit.
  const handleApplyRecoveryRate = async (type: GameType, idx: number) => {
    const pid = activeId || 'admin1';
    const dictName = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
    const syncKey = `${pid}_${currentDate}_${type}_${idx}`;
    const pendingTimer = manualRateSyncTimersRef.current.get(syncKey);
    if (pendingTimer) clearTimeout(pendingTimer);
    manualRateSyncTimersRef.current.delete(syncKey);
    pendingManualRatesRef.current.delete(syncKey);
    manualRateEditingRef.current.delete(syncKey);

    if (currentDate < titanLocalDateISO()) {
      setAppState(prev => {
        const profile=prev.profiles[pid], store=profile?.dayRecords[currentDate], original=store?.[dictName]?.[idx];
        if (!original || original.sentDigits || original.sentRate || original.dispatchState==='SENT' || original.dispatchState==='SETTLED') return prev;
        const rec={...original}; delete rec.manualRate; delete rec.manualOverrideAt;
        const prepared={...profile,dayRecords:{...profile.dayRecords,[currentDate]:{...store,[dictName]:{...store[dictName],[idx]:rec}}}};
        return {...prev,profiles:{...prev.profiles,[pid]:calculateBacktestRecovery(prepared,currentDate)}};
      });
      return;
    }

    setAppState((prev) => {
      const updatedProfiles = { ...prev.profiles };
      const prof = ensureProfileStructure(updatedProfiles[pid] || updatedProfiles.admin1, true);
      const dayStore = prof.dayRecords[currentDate] || {};
      const dict = { ...(dayStore[dictName] || {}) };
      const rec: any = { ...(dict[idx] || { s: 'WAIT', d: '', r: '' }) };
      rec.r = String(rec.recRate || '');
      delete rec.manualRate;
      delete rec.manualOverrideAt;
      dict[idx] = rec;
      prof.dayRecords[currentDate] = { ...dayStore, [dictName]: dict };
      updatedProfiles[pid] = prof;
      return { ...prev, profiles: updatedProfiles };
    });

    try {
      const response = await fetch(apiUrl('/api/bot/ledger_set_card'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...profileAuthHeaders(pid) },
        body: JSON.stringify({
          profileId: pid,
          type,
          index: idx,
          date: currentDate,
          clearManualRate: true,
        }),
      });
      const result = await response.json().catch(() => null);
      if (!response.ok || result?.status !== 'success') {
        throw new Error(result?.message || `HTTP ${response.status}`);
      }
      lastLedgerSyncRef.current = '';
      window.dispatchEvent(new Event('titan-ledger-synced'));
    } catch (error: any) {
      showToast('❌ Recovery Rate Sync Failed', error?.message || 'Backend recovery rate restore failed', 'danger');
      window.dispatchEvent(new Event('titan-ledger-synced'));
    }
  };

  // Apply Trick Formula
  const handleApplyTrick = (type: GameType, idx: number, formattedDigits: string, trickTag: 'T1' | 'T2' | 'T3') => {
    const dictName = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
    const sourceProfile = appStateRef.current.profiles?.[activeId] || appStateRef.current.profiles?.admin1;
    const sourceMarkets = type === 'jodi' ? getEffectiveBaseMarkets(sourceProfile?.config) : getEffectiveMarkets(sourceProfile?.config);
    const stableMarketName = String(sourceMarkets[idx]?.n || '').trim().toUpperCase();

    setAppState((prev) => {
      const updatedProfiles = { ...prev.profiles };
      const prof = ensureProfileStructure(updatedProfiles[activeId] || updatedProfiles['admin1'], true);
      const dict = { ...(prof.dayRecords[currentDate][dictName] || {}) };
      const rec = { ...(dict[idx] || { s: 'WAIT', d: '', r: '' }) };
      if (!canReplaceLiveCombinedDecision(rec) || rec.sentRate || rec.sentDigits || rec.dispatchState === 'QUEUED' || String(rec.dispatchState) === 'SENDING' || rec.dispatchState === 'SENT' || rec.dispatchState === 'SETTLED') return prev;

      if (autoBacktestResult && currentDate < titanLocalDateISO()) {
        rec.s='WAIT'; delete rec.manualStatus; delete rec.backtestResult; delete rec.manualResult; delete rec.manualResultSources;
      }
      scrapeIntents.current.ids.delete(`${activeId}|${currentDate}|${type}|${idx}`);
      if (!rec.od) rec.od = (type === 'ank' ? getScrapeSource(rec)?.digits : undefined) || rec.d || '';
      releaseLiveCombinedDecision(rec);
      rec.d = formattedDigits;
      rec.trick = trickTag;
      rec.sourceEditedAt = Math.max(Date.now(), Number(rec.sourceEditedAt || 0) + 1, Number(rec.cardGeneration || 0) + 1);
      delete rec.positionRule;
      if (stableMarketName) rec.marketName = stableMarketName;

      dict[idx] = rec as DayMarketRecord;
      prof.dayRecords[currentDate][dictName] = dict;
      if (currentDate < titanLocalDateISO()) {
        updatedProfiles[activeId] = calculateBacktestRecovery(prof, currentDate);
      } else {
        const auto = applyAutoRatesToDayStore(prof, currentDate, updatedProfiles);
        if (auto) prof.dayRecords[currentDate] = auto;
        updatedProfiles[activeId] = prof;
      }

      if (isMasterApp && activeId === 'admin1') {
        Object.keys(updatedProfiles).forEach((pid) => {
          if (pid === 'admin1') return;
          if (trickTag === 'T3') return;
          if (!vipCopiesAdmin(updatedProfiles[pid])) return;
          const p = ensureProfileStructure(updatedProfiles[pid], true);
          if (!vipLiveMarketEligible(p, currentDate, type, stableMarketName)) return;
          const vipMarkets = type === 'jodi' ? getEffectiveBaseMarkets(p.config) : getEffectiveMarkets(p.config);
          const vipIdx = findMarketIndexByName(vipMarkets, stableMarketName);
          if (vipIdx < 0) return;
          const pDict = { ...(p.dayRecords[currentDate][dictName] || {}) };
          const pRec = { ...(pDict[vipIdx] || { s: 'WAIT', d: '', r: '' }) };
          if (!canReplaceLiveCombinedDecision(pRec) || pRec.sentRate || pRec.sentDigits || pRec.dispatchState === 'QUEUED' || String(pRec.dispatchState) === 'SENDING' || pRec.dispatchState === 'SENT' || pRec.dispatchState === 'SETTLED') return;

          if (!pRec.od) pRec.od = rec.od || pRec.d || '';
          releaseLiveCombinedDecision(pRec);
          pRec.d = formattedDigits;
          pRec.trick = trickTag;
          pRec.sourceEditedAt = Math.max(Date.now(), Number(pRec.sourceEditedAt || 0) + 1, Number(pRec.cardGeneration || 0) + 1);
          delete pRec.positionRule;
          pRec.mirroredFromAdmin = true;
          if (stableMarketName) pRec.marketName = stableMarketName;

          pDict[vipIdx] = pRec as DayMarketRecord;
          p.dayRecords[currentDate][dictName] = pDict;
          if (currentDate < titanLocalDateISO()) {
            updatedProfiles[pid] = calculateBacktestRecovery(p, currentDate);
          } else {
            const vipAuto = applyAutoRatesToDayStore(p, currentDate, updatedProfiles);
            if (vipAuto) p.dayRecords[currentDate] = vipAuto;
            updatedProfiles[pid] = p;
          }
        });
      }

      return { ...prev, profiles: updatedProfiles };
    });

    showToast('✨ Trick Applied', `${trickTag} formula applied successfully!`, 'success');
  };

  // Undo Trick
  const handleUndoTrick = (type: GameType, idx: number, silent = false) => {
    if(currentDate<titanLocalDateISO()){setAutoBacktestResult(false);backtestActualCache.current.clear();backtestLookups.current.clear();}
    const dictName = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
    const sourceProfile = appStateRef.current.profiles?.[activeId] || appStateRef.current.profiles?.admin1;
    const sourceMarkets = type === 'jodi' ? getEffectiveBaseMarkets(sourceProfile?.config) : getEffectiveMarkets(sourceProfile?.config);
    const stableMarketName = String(sourceMarkets[idx]?.n || '').trim().toUpperCase();

    setAppState((prev) => {
      const updatedProfiles = { ...prev.profiles };
      const prof = ensureProfileStructure(updatedProfiles[activeId] || updatedProfiles['admin1'], true);
      const dict = { ...(prof.dayRecords[currentDate][dictName] || {}) };
      const trickBeingUndone = dict[idx]?.trick;
      const rec = undoSelection(dict[idx],currentDate);
      if (!rec) return prev;
      if (stableMarketName) rec.marketName = stableMarketName;

      dict[idx] = rec as DayMarketRecord;
      prof.dayRecords[currentDate][dictName] = dict;
      updatedProfiles[activeId] = holdBacktestDaySelections(prof,currentDate);

      // Admin Trick application is mirrored to VIP cards, so Undo must mirror
      // the same original-digit restoration or profiles permanently diverge.
      if (isMasterApp && activeId === 'admin1') {
        Object.keys(updatedProfiles).forEach((pid) => {
          if (pid === 'admin1') return;
          if (trickBeingUndone === 'T3') return;
          if (!vipCopiesAdmin(updatedProfiles[pid])) return;
          const vip = ensureProfileStructure(updatedProfiles[pid], true);
          if (!vipLiveMarketEligible(vip, currentDate, type, stableMarketName)) return;
          const vipMarkets = type === 'jodi' ? getEffectiveBaseMarkets(vip.config) : getEffectiveMarkets(vip.config);
          const vipIdx = findMarketIndexByName(vipMarkets, stableMarketName);
          if (vipIdx < 0) return;
          const vipDict = { ...(vip.dayRecords[currentDate]?.[dictName] || {}) };
          const vipRec = undoSelection(vipDict[vipIdx],currentDate);
          if (!vipRec) return;
          vipRec.mirroredFromAdmin = true;
          if (stableMarketName) vipRec.marketName = stableMarketName;
          vipDict[vipIdx] = vipRec as DayMarketRecord;
          vip.dayRecords[currentDate][dictName] = vipDict;
          updatedProfiles[pid] = holdBacktestDaySelections(vip,currentDate);
        });
      }

      return { ...prev, profiles: updatedProfiles };
    });

    if (!silent) showToast('🔙 Undo Trick', currentDate<titanLocalDateISO()?'Original digits restored · Test OFF; turn Test ON for a fresh check.':'Restored original target digits.', 'info');
  };

  // Reset Card
  const resetCardFinancially = async (pid: string, date: string, type: GameType, idx: number, copyAdmin = false) => {
    const dictName = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
    const profile = appStateRef.current.profiles[pid];
    const old = profile?.dayRecords?.[date]?.[dictName]?.[idx];
    const markets = type === 'jodi' ? getEffectiveBaseMarkets(profile?.config) : getEffectiveMarkets(profile?.config);
    const revision = Math.max(Date.now(), Number(old?.sourceEditedAt || 0) + 1, Number(old?.cardGeneration || 0) + 1);
    const syncKey = `${pid}_${date}_${type}_${idx}`;
    const pendingTimer = manualRateSyncTimersRef.current.get(syncKey);
    if (pendingTimer) clearTimeout(pendingTimer);
    manualRateSyncTimersRef.current.delete(syncKey); pendingManualRatesRef.current.delete(syncKey); manualRateEditingRef.current.delete(syncKey);
    scrapeIntents.current.ids.delete(`${pid}|${date}|${type}|${idx}`);
    const optimisticCleared = clearedLedgerCard(old, old?.marketName || markets[idx]?.n || '', revision);
    setAppState(prev => {
      const prof = prev.profiles[pid]; if (!prof) return prev;
      const day = prof.dayRecords[date] || {}; const dict = { ...(day[dictName] || {}), [idx]: optimisticCleared };
      let nextProf = { ...prof, dayRecords: { ...prof.dayRecords, [date]: { ...day, [dictName]: dict } } };
      if (date < titanLocalDateISO()) {
        nextProf = calculateBacktestRecovery(nextProf, date);
      } else {
        const auto = applyAutoRatesToDayStore(nextProf, date, prev.profiles);
        if (auto) nextProf.dayRecords[date] = auto;
      }
      return { ...prev, profiles: { ...prev.profiles, [pid]: nextProf } };
    });
    const response = await profileMutationQueueRef.current.enqueue(`card:${syncKey}`, () => fetch(apiUrl('/api/bot/ledger_set_card'), {
      method: 'POST', headers: { 'Content-Type': 'application/json', ...profileAuthHeaders(pid) },
      body: JSON.stringify({ profileId: pid, date, type, index: idx, status: 'WAIT', clearCard: true, copyAdmin,
        sourceEditedAt: revision, marketName: old?.marketName || markets[idx]?.n }),
    }));
    const result = await response.json();
    if (!response.ok || result.status !== 'success' || !result.card) throw new Error(result.message || `HTTP ${response.status}`);
    setAppState(prev => {
      const prof = ensureProfileStructure(prev.profiles[pid], true);
      const day = prof.dayRecords[date] || {};
      const dict = { ...(day[dictName] || {}), [idx]: result.card };
      prof.dayRecords[date] = { ...day, [dictName]: dict };
      if (date < titanLocalDateISO()) {
        const nextProf = calculateBacktestRecovery(prof, date);
        return { ...prev, profiles: { ...prev.profiles, [pid]: nextProf } };
      }
      const auto = applyAutoRatesToDayStore(prof, date, prev.profiles);
      if (auto) prof.dayRecords[date] = auto;
      return { ...prev, profiles: { ...prev.profiles, [pid]: prof } };
    });
    lastLedgerSyncRef.current = ''; lastScheduleSyncRef.current = '';
    window.dispatchEvent(new Event('titan-ledger-synced'));
  };
  const handleResetCard = async (type: GameType, idx: number, silent = false) => {
    try {
      await resetCardFinancially(activeId, currentDate, type, idx);
      if (!silent) showToast('🧹 Card Reset', 'Card cleared; old investment and result reversed.', 'info');
      return true;
    } catch (error: any) {
      showToast('❌ Clear Failed', error?.message || 'Card reset failed', 'danger');
      return false;
    }
  };

  // Cards user manually unlocked — snapshot must NOT re-apply server PASS/FAIL
  const unlockedCardsRef = useRef<Set<string>>(new Set());

  // Unlock Card — restore WAIT locally + clear sticky server mark (undo must stick)
  const handleUnlockCard = (type: GameType, idx: number) => {
    const unlockKey = `${activeId}_${currentDate}_${type}_${idx}`;
    unlockedCardsRef.current.add(unlockKey);

    // Local WAIT (digits + rate keep — only status resets)
    handleUpdateRecord(type, idx, 's', 'WAIT');

    // handleUpdateRecord already sends the single authoritative WAIT command
    // for Admin and mirrored VIP profiles. Do not dispatch it a second time.

    // Force next ledger push to send WAIT
    lastLedgerSyncRef.current = '';

    showToast('🔓 Restored', 'PASS/FAIL hata — card phir WAIT. Wallet se bhi hisab hatega.', 'success');
  };

  const handleBulkRestoreBacktest = async () => {
    if (!isMasterApp || bulkAction || bulkRestoreInFlightRef.current || currentDate >= titanLocalDateISO()) return;
    const pid=activeId||'admin1',date=currentDate,original=appStateRef.current;
    const affected=Object.keys(original.profiles).filter(id=>id===pid||(pid==='admin1'&&vipCopiesAdmin(original.profiles[id])));
    const sourceDays:Record<string,DayRecordStore>={},optimisticDays:Record<string,DayRecordStore>={},settings:Record<string,any>={};
    const profiles={...original.profiles};
    const revision=Math.max(Date.now(),...affected.map(id=>Number(profiles[id].dayRecords[date]?.backtestRevision||0)+1));
    for(const id of affected){
      if(!profiles[id].dayRecords[date])continue;
      sourceDays[id]=profiles[id].dayRecords[date];
      const confirmed=confirmedSnapshotRef.current?.state.profiles[id]?.dayRecords[date];
      const visibility:Array<{trackDict:string;marketName:string;enabled:boolean}>=[];
      for(const track of ['visAnk','visJodi','visPan'] as const)for(const [marketName,enabled] of Object.entries(sourceDays[id][track]||{}))if(enabled!==confirmed?.[track]?.[marketName])visibility.push({trackDict:track,marketName,enabled});
      settings[id]={visibility,...(Boolean(sourceDays[id].openToCloseCut)!==Boolean(confirmed?.openToCloseCut)?{openToCloseCut:sourceDays[id].openToCloseCut===true}:{})};
      const restored=restoreBacktestDay(profiles[id],date);
      const day={...restored.dayRecords[date],backtestRevision:revision};optimisticDays[id]=day;
      profiles[id]={...restored,dayRecords:{...restored.dayRecords,[date]:day}};
    }
    // The visible Undo completes with the optimistic reset. Keep the mutation
    // fence until persistence finishes, without a foreground Saving/Working state.
    bulkRestoreInFlightRef.current=true;setBulkAction('cards:restore');setAutoBacktestResult(false);
    backtestActualCache.current.clear();backtestLookups.current.clear();setBacktestChecking(false);
    archiveWorkerRef.current?.terminate();archiveWorkerRef.current=null;
    const optimistic={...original,profiles};appStateRef.current=optimistic;setAppState(optimistic);
    try {
      for(const [key,timer] of manualRateSyncTimersRef.current){
        if(!affected.some(id=>key.startsWith(`${id}_${date}_`)))continue;
        clearTimeout(timer);manualRateSyncTimersRef.current.delete(key);pendingManualRatesRef.current.delete(key);manualRateEditingRef.current.delete(key);
      }
      // Earlier financial commands finish first; no full-archive serialization or
      // whole-workspace save stands between this click and selected-day Undo.
      await profileMutationQueueRef.current.drain();
      const operationId=bulkOperationId();
      const result=await profileMutationQueueRef.current.enqueue('app-state',()=>postBulkCommand({url:apiUrl('/api/app/restore_backtest'),
        headers:{'Content-Type':'application/json'},body:{operationId,profileId:pid,date,mirrorAdmin:pid==='admin1',sourceDays,settings,revision},
        receiptUrl:apiUrl(`/api/app/bulk_operation?kind=undo&profileId=${encodeURIComponent(pid)}&date=${encodeURIComponent(date)}&operationId=${encodeURIComponent(operationId)}`),
      }));
      if(result.status!=='success'||result.date!==date||!result.days?.[pid])throw new Error(result.message||'Undo could not be saved.');
      setAppState(prev=>{
        const next={...prev.profiles};
        for(const [id,day] of Object.entries(result.days) as [string,DayRecordStore][]){
          if(!next[id])continue;
          const local=next[id].dayRecords[date],merged={...day};
          for(const key of ['visAnk','visJodi','visPan','openToCloseCut'] as const)if(!sameAdminValue(local?.[key],optimisticDays[id]?.[key]))(merged as any)[key]=local?.[key];
          for(const key of ['data','jodiData','pannelData'] as const)for(const [i,rec] of Object.entries(local?.[key]||{})){
            const atClick=optimisticDays[id]?.[key]?.[i];
            if(atClick&&(modelSourceVersion(rec)>modelSourceVersion(atClick)||Number(rec.manualOverrideAt||0)>Number(atClick.manualOverrideAt||0)))merged[key]={...merged[key],[i]:rec};
          }
          next[id]={...next[id],dayRecords:{...next[id].dayRecords,[date]:merged}};
        }
        return {...prev,profiles:next};
      });
      showToast('Undo saved',`${date}: ${result.cards} cards normal · Test OFF`,'success');
    } catch(error:any) {
      if(error instanceof BulkCommandError&&error.outcomeUnknown){
        showToast('Undo · confirmation pending',error.message,'warning');
        return;
      }
      setAppState(prev=>{
        const next={...prev.profiles};
        for(const id of affected){
          const local=next[id]?.dayRecords[date],atClick=optimisticDays[id],before=sourceDays[id];
          if(!local||!atClick||!before)continue;
          const day={...local,backtestRevision:Number(local.backtestRevision)===revision?before.backtestRevision:local.backtestRevision};
          for(const key of ['data','jodiData','pannelData'] as const)for(const [i,record] of Object.entries(local[key]||{})){
            const expected=atClick[key]?.[i];
            if(expected&&record.s==='WAIT'&&modelSourceVersion(record)===modelSourceVersion(expected)&&Number(record.manualOverrideAt||0)<=Number(expected.manualOverrideAt||0))day[key]={...day[key],[i]:before[key]?.[i]||record};
          }
          next[id]={...next[id],dayRecords:{...next[id].dayRecords,[date]:day}};
        }
        return {...prev,profiles:next};
      });
      showToast('Undo save failed',error?.message||'Please retry.','danger');
    } finally {bulkRestoreInFlightRef.current=false;setBulkAction(action=>action==='cards:restore'?null:action);lastLedgerSyncRef.current='';lastScheduleSyncRef.current='';}
  };

  // Server snapshot sync only. All background business processing stays on the backend.
  useEffect(() => {
    if (!serverHydrated) return;
    let inFlight = false;
    let pullRequested = false;
    let disposed = false;
    let requestVersion = 0;
    let controller: AbortController | null = null;
    let snapshotETag = '';

    const pull = async () => {
      if (disposed || adminSnapshotRunningRef.current || document.visibilityState === 'hidden') return;
      if (inFlight) {
        pullRequested = true;
        return;
      }
      inFlight = true;
      const version = ++requestVersion;
      controller = new AbortController();
      const requestController = controller;
      const timeout = setTimeout(() => requestController.abort(), 15000);
      try {
        const snapshotQuery = isMasterApp ? '' : `?profileId=${encodeURIComponent(vipParam || activeIdRef.current || '')}`;
        const res = await fetch(apiUrl(`/api/bot/ledger_snapshot${snapshotQuery}`), {
          cache: 'no-store',
          headers: { ...(vipParam ? profileAuthHeaders(vipParam) : {}), ...(snapshotETag ? { 'If-None-Match': snapshotETag } : {}) },
          signal: controller.signal,
        });
        if (res.status === 304) return;
        if (!res.ok) return;
        const data = await res.json();
        if (disposed || document.hidden || adminSnapshotRunningRef.current || version !== requestVersion || bulkRestoreInFlightRef.current) return;
        snapshotETag = res.headers.get('ETag') || '';
        const ledger = data?.ledger;
        if (!ledger?.profiles || ledger.date !== currentDateRef.current) return;

        const notifyLines: string[] = [];
        setAppState((prev) => {
          // React may defer this updater until after a date-picker change.
          // Never apply the previous date's snapshot to the newly selected date.
          if (document.visibilityState==='hidden'||adminSnapshotRunningRef.current||ledger.date !== currentDateRef.current) return prev;
          const updatedProfiles = { ...prev.profiles };
          let changed = false;
          Object.keys(ledger.profiles).forEach((pid) => {
            const remote = ledger.profiles[pid];
            const local = updatedProfiles[pid];
            if (!local || !remote?.cards) return;
            const prof = ensureProfileStructure(local, true);
            const day = ledger.date;
            const dayStore = { ...(prof.dayRecords[day] || {}) };
            let profChanged = false;
            const profitAlerts = pid === vipParam ? data.profitMilestoneNotificationsEnabled : remote.profitMilestoneNotificationsEnabled;
            if (typeof profitAlerts === 'boolean' && prof.profitMilestoneNotificationsEnabled !== profitAlerts) {
              prof.profitMilestoneNotificationsEnabled = profitAlerts; profChanged = true; changed = true;
            }
            const runs = pid === vipParam ? data.vipGameRuns : remote.vipGameRuns;
            if (pid !== 'admin1' && runs && JSON.stringify(prof.vipGameRuns || {}) !== JSON.stringify(runs)) {
              prof.vipGameRuns = runs; profChanged = true; changed = true;
            }
            if(remote.loopAccountStops&&JSON.stringify(dayStore.loopAccountStops)!==JSON.stringify(remote.loopAccountStops)){dayStore.loopAccountStops=remote.loopAccountStops;profChanged=true;changed=true;}
            const remoteLoops=normalizeDualLoops(remote.loopConfig,prof.config);
            if(remoteLoops && Number(remoteLoops.revision||0)>Number(dayStore.loopConfig?.revision||0)) {dayStore.loopConfig=remoteLoops;profChanged=true;}
            Object.entries(remote.cards).forEach(([cardKey, card]: any) => {
              const isTerminal = card?.s === 'PASS' || card?.s === 'FAIL' || card?.vipAutoStopSkipped || card?.loopAccountSkipped || card?.closeZeroAutoSkipped;
              const hasBackendRate = Boolean(
                card?.rateFinalizedAt || card?.sentRate || card?.dispatchState
              );
              if (!card) return;
              const [type, idxStr] = cardKey.split('_');
              const remoteName=String(card.marketName || remote.markets?.find((m:any)=>m.type===type&&Number(m.index)===Number(idxStr))?.n || '');
              const localMarkets=type==='jodi'?getEffectiveBaseMarkets(prof.config):getEffectiveMarkets(prof.config);
              const idx = remoteName ? findMarketIndexByName(localMarkets,remoteName) : Number(idxStr);
              if (!type || Number.isNaN(idx) || idx<0) return;
              const unlockKey = `${pid}_${day}_${type}_${idx}`;
              const rateIsBeingEdited = manualRateEditingRef.current.has(unlockKey);
              const dictName = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
              const dict = { ...(dayStore[dictName] || {}) };
              const rec = { ...(dict[idx] || { s: 'WAIT', d: '', r: '' }) };
              if (!isTerminal && !rec.vipAutoStopSkipped && !(rec as any).closeZeroAutoSkipped && !isEditableSourceSkip(card) && !card.sourceEditedAt && !card.manualStatus && !card.manualRate && !hasBackendRate && !card.jodiOpenStatus) return;
              if (isStaleModelSnapshot(rec, card)) return;
              const modelSourceIsNewer = Boolean((rec.marketModel || card.marketModel || rec.strictPanel30 || card.strictPanel30 || rec.liveCombinedCut || card.liveCombinedCut || rec.autoResultParity || card.autoResultParity || rec.carryResultSix || card.carryResultSix) && modelSourceVersion(card) >= modelSourceVersion(rec));
              // Undo remains protected from the same stale audit forever. The
              // server releases it only when a newer audit creates a settlement
              // timestamp after the Undo request.
              const remoteSettlementIsNewer = isTerminal
                && Number(card.settledAt || 0) > Number(rec.manualOverrideAt || 0);
              if (remoteSettlementIsNewer) unlockedCardsRef.current.delete(unlockKey);
              const locallyUnlocked = unlockedCardsRef.current.has(unlockKey);
              // Local Undo/manual status may keep status, but must not block a
              // newer backend-finalized recovery rate from reaching the box.
              const localCloseZeroWaitReleased = (rec as any).closeZeroAutoSkipped !== true && rec.s === 'WAIT' && card.closeZeroAutoSkipped && !(prof.config?.openPassCloseZero || prof.openPassCloseZero);
              const keepLocalStatus = (locallyUnlocked && !card.vipAutoStopSkipped && !rec.vipAutoStopSkipped && !card.loopAccountSkipped && !rec.loopAccountSkipped) || localCloseZeroWaitReleased;
              const nextStatus = keepLocalStatus
                ? rec.s
                : (card.manualStatus ? String(card.s || 'WAIT') : (isTerminal || modelSourceIsNewer || rec.vipAutoStopSkipped || rec.loopAccountSkipped || (rec as any).closeZeroAutoSkipped ? card.s : rec.s));
              const nextRate = rateIsBeingEdited
                ? String(rec.r ?? '')
                : (card.manualRate || hasBackendRate)
                ? String(card.sentRate ?? card.r ?? card.recRate ?? rec.r ?? '')
                : String(rec.r ?? '');
              const nextRec = {
                ...rec,
                s: nextStatus as any,
                vipAutoStopSkipped: card.vipAutoStopSkipped || undefined,
                vipAutoStopResumeEligible: card.vipAutoStopResumeEligible || undefined,
                closeZeroAutoSkipped: localCloseZeroWaitReleased ? undefined : (card.closeZeroAutoSkipped || (nextStatus === 'SKIP' ? (rec as any).closeZeroAutoSkipped : undefined)),
                ...(isEditableSourceSkip(card) ? { d: '' } : card.d || (card.sourceEditedAt && card.d !== undefined) ? { d: String(card.d) } : {}),
                ...(card.od ? { od: String(card.od) } : {}),
                ...(card.trick ? { trick: card.trick } : {}),
                ...(['FCUT','LCUT','CENTER','FIRST_CUT','CUT2','WEEKDAY','RECENT2','RECENT6','RECENT4','LAST_ACTUAL_MIRROR','FIRST_DIGIT_MIRROR','SSD','FLOW_3_1','TRI_CUT','SNIPER_1','TESLA_369'].includes(card.positionRule) ? { positionRule: card.positionRule as any } : {}),
                ...(card.weekdaySelectedDigits ? { weekdaySelectedDigits: String(card.weekdaySelectedDigits) } : {}),
                ...(card.weekdayHitPosition !== undefined ? { weekdayHitPosition: Number(card.weekdayHitPosition) } : {}),
                ...(card.sourceMode ? { sourceMode: card.sourceMode } : {}),
                ...(Number(card.sourceEditedAt || 0) >= Number(rec.sourceEditedAt || 0) ? { strictPanel30: card.strictPanel30 || undefined, smartSelection:card.smartSelection||undefined } : {}),
                ...(modelSourceIsNewer ? { marketModel: card.marketModel } : {}),
                ...(Number(card.sourceEditedAt || 0) >= Number(rec.sourceEditedAt || 0) && card.sourceEditedAt ? { sourceEditedAt: card.sourceEditedAt } : {}),
                ...(card.scrapeSource ? { scrapeSource: card.scrapeSource } : {}),
                ...(card.sentScrapeSource ? { sentScrapeSource: card.sentScrapeSource } : {}),
                ...(Number(card.sourceEditedAt||0)>=Number(rec.sourceEditedAt||0)?{firstDigitMirrorCut:card.firstDigitMirrorCut,triCut:card.triCut,sniperOne:card.sniperOne,tesla369:card.tesla369,mssdState:card.mssdState,masterFlow:card.masterFlow}:{}),
                autoResultParity: card.autoResultParity,
                autoRemovedResult: card.autoRemovedResult,
                openCloseCut:card.openCloseCut,
                carryResultSix: card.carryResultSix,
                loopAccountSkipped:card.loopAccountSkipped,loopAccountReason:card.loopAccountReason,loopAccountReservation:card.loopAccountReservation,
                ...((card.carryResultSix||rec.carryResultSix)&&modelSourceIsNewer?{trick:card.trick,positionRule:card.positionRule,scrapeSource:card.scrapeSource,od:card.od,sourceMode:card.sourceMode}:{}),
                ...(Number(card.sourceEditedAt||0)>=Number(rec.sourceEditedAt||0)?{liveCombinedCut:card.liveCombinedCut}:{}),
                scrapeResultDigit: card.scrapeResultDigit || undefined,
                manualResult: card.manualResult || undefined,
                manualPanelResult: card.manualPanelResult || undefined,
                manualResultSources: card.manualResultSources || undefined,
                ...(card.marketName ? { marketName: String(card.marketName) } : {}),
                r: nextRate,
                ...(card.recRate !== undefined ? { recRate: String(card.recRate) } : {}),
                ...(card.prevLoss !== undefined ? { prevLoss: Number(card.prevLoss) || 0 } : {}),
                ...(card.targetProfitWithLoss !== undefined ? { targetProfitWithLoss: Number(card.targetProfitWithLoss) || 0 } : {}),
                ...(card.sentRate ? { sentRate: String(card.sentRate) } : {}),
                ...(card.sentInvest !== undefined ? { sentInvest: Number(card.sentInvest) || 0 } : {}),
                ...(card.sentDigits ? { sentDigits: String(card.sentDigits) } : {}),
                ...(card.loopId ? { loopId: card.loopId } : {}),
                ...(card.sentLoopId ? { sentLoopId: card.sentLoopId } : {}),
                ...(card.sentSourceMode ? { sentSourceMode: card.sentSourceMode } : {}),
                ...(card.sentTrick ? { sentTrick: card.sentTrick } : {}),
                ...(card.dispatchState ? { dispatchState: card.dispatchState } : {}),
                ...(card.dispatchKey ? { dispatchKey: String(card.dispatchKey) } : {}),
                ...(card.queuedAt ? { queuedAt: Number(card.queuedAt) } : {}),
                ...(card.sentAt ? { sentAt: Number(card.sentAt) } : {}),
                ...(card.settledAt ? { settledAt: Number(card.settledAt) } : {}),
                jodiOpenStatus: card.jodiOpenStatus || undefined,
                jodiOpenResult: card.jodiOpenResult !== undefined ? String(card.jodiOpenResult) : undefined,
                jodiOpenSettledAt: card.jodiOpenSettledAt ? Number(card.jodiOpenSettledAt) : undefined,
                ...(card.rateFinalizedFrom ? { rateFinalizedFrom: String(card.rateFinalizedFrom) } : {}),
                ...(card.twoCardRecoveryShares ? {twoCardRecoveryShares:card.twoCardRecoveryShares,twoCardRecoveryStrategy:card.twoCardRecoveryStrategy} : {}),
                smartStaking: (prof.config.fourWaveRelay !== true && ((type === 'ank' && prof.config.ankSplit !== false) || (type === 'pannel' && prof.config.panSplit !== false))) ? (card.smartStaking || rec.smartStaking || undefined) : undefined,
                ...(card.rateFinalizedAt ? { rateFinalizedAt: Number(card.rateFinalizedAt) } : {}),
                ...(card.manualStatus ? { manualStatus: true } : {}),
                ...(card.manualRate ? { manualRate: true } : {}),
                ...(card.manualOverrideAt ? { manualOverrideAt: Number(card.manualOverrideAt) } : {}),
              } as DayMarketRecord;
              applySourceSnapshot(nextRec, card, rec);
              if(card.loopAccountSkipped){delete nextRec.dispatchState;delete nextRec.dispatchKey;delete nextRec.queuedAt;}
              if (card.deliveryRestoredAt) { nextRec.deliveryRestoredAt = card.deliveryRestoredAt; nextRec.s = card.s; clearRestoredDelivery(nextRec); }
              if (!rateIsBeingEdited && card.rateFinalizedAt && !card.manualRate) {
                delete nextRec.manualRate;
                delete nextRec.manualOverrideAt;
              }
              if (!sameAdminValue(rec, nextRec)) {
                dict[idx] = nextRec;
                dayStore[dictName] = dict;
                profChanged = true;
              }
            });
            if (profChanged) {
              prof.dayRecords = { ...prof.dayRecords, [day]: dayStore };
              const autoUpdated = applyAutoRatesToDayStore(prof, day, updatedProfiles);
              if (autoUpdated) {
                prof.dayRecords = { ...prof.dayRecords, [day]: autoUpdated };
              }
              // CRITICAL FIX: Compare the final dayStore AFTER applyAutoRatesToDayStore against local.dayRecords[day]
              // so we never trigger an A -> B -> A infinite 2-second sync & re-render loop!
              if (
                !sameAdminValue(local.dayRecords?.[day], prof.dayRecords[day]) ||
                prof.profitMilestoneNotificationsEnabled !== local.profitMilestoneNotificationsEnabled ||
                !sameAdminValue(prof.vipGameRuns, local.vipGameRuns)
              ) {
                updatedProfiles[pid] = prof;
                changed = true;
              }
            }
          });
          return changed ? { ...prev, profiles: updatedProfiles } : prev;
        });

        if (
          notifyLines.length > 0 &&
          typeof Notification !== 'undefined' &&
          Notification.permission === 'granted'
        ) {
          try {
            new Notification('Titan Nova — PASS/FAIL', {
              body: notifyLines.slice(0, 4).join('\\n') + (notifyLines.length > 4 ? '\\n…' : ''),
              tag: 'titan-passfail',
            });
          } catch (_) {}
        }
      } catch (err: any) {
        if (err?.name !== 'AbortError') {
          // Server may be temporarily offline; the next safe poll retries.
        }
      } finally {
        clearTimeout(timeout);
        if (version === requestVersion) inFlight = false;
        if (pullRequested && !disposed) {
          pullRequested = false;
          queueMicrotask(() => { void pull(); });
        }
      }
    };

    let resumeTimer: ReturnType<typeof setTimeout> | undefined;
    const onResume = () => {
      clearTimeout(resumeTimer);
      if (document.visibilityState === 'hidden') {pullRequested=false;controller?.abort();return;}
      resumeTimer = setTimeout(() => { void pull(); }, 700);
    };
    const onLedgerSynced = () => { snapshotETag = ''; void pull(); };
    const startTimer = setTimeout(() => { void pull(); }, 0);
    const interval = setInterval(() => {
      if (document.visibilityState !== 'hidden') void pull();
    }, 2000);
    document.addEventListener('visibilitychange', onResume);
    window.addEventListener('focus', onResume);
    window.addEventListener('pageshow', onResume);
    window.addEventListener('online', onResume);
    window.addEventListener('titan-ledger-synced', onLedgerSynced);

    return () => {
      disposed = true;
      requestVersion += 1;
      controller?.abort();
      clearTimeout(startTimer);
      clearTimeout(resumeTimer);
      clearInterval(interval);
      document.removeEventListener('visibilitychange', onResume);
      window.removeEventListener('focus', onResume);
      window.removeEventListener('pageshow', onResume);
      window.removeEventListener('online', onResume);
      window.removeEventListener('titan-ledger-synced', onLedgerSynced);
    };
  }, [currentDate, serverHydrated]);

  // Auto Schedule Update
  // VIP profile: if targets empty → auto-use that VIP's WhatsApp number (phone / vipSchTarget)
  const handleScheduleUpdate = (type: GameType, idx: number, time: string, targets: string[]) => {
    // VIP profiles never use time/target schedules. Their fixed phone + digits/rate readiness drives delivery.
    if ((activeId || 'admin1') !== 'admin1') {
      console.log('⏭️ VIP schedule update ignored: event-driven mode', activeId, type, idx);
      return;
    }
    const dictName = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';

    setAppState((prev) => {
      const updatedProfiles = { ...prev.profiles };
      const pid = activeId || 'admin1';
      const prof = ensureProfileStructure(updatedProfiles[pid] || updatedProfiles['admin1'], true);
      const dict = { ...(prof.dayRecords[currentDate][dictName] || {}) };
      const rec = { ...(dict[idx] || { s: 'WAIT', d: '', r: '' }) };

      let finalTargets = (targets || []).filter(Boolean);
      // Individual VIP: schedule must go to their WhatsApp number
      if (pid !== 'admin1' && finalTargets.length === 0) {
        const vipPhone = String(prof.vipSchTarget || prof.phone || '').replace(/\D/g, '');
        if (vipPhone.length >= 10) finalTargets = [vipPhone];
      }

      rec.schTime = time;
      rec.schTargets = finalTargets;

      dict[idx] = rec as DayMarketRecord;
      prof.dayRecords[currentDate][dictName] = dict;

      // Save permanently in profile config so it automatically applies to ALL days
      const cfg = { ...(prof.config || {}) };
      const marketKey = `${type}_${idx}`;
      cfg.marketScheduleTimes = { ...(cfg.marketScheduleTimes || {}), [marketKey]: time };
      cfg.marketScheduleTargets = { ...(cfg.marketScheduleTargets || {}), [marketKey]: finalTargets };

      prof.config = cfg as ProfileConfig;
      updatedProfiles[pid] = prof;

      return { ...prev, profiles: updatedProfiles };
    });

    // The central post-commit state effect sends the fresh schedule snapshot.
    // An immediate dispatch here would still read the previous schedule.
    lastScheduleSyncRef.current = '';
    lastLedgerSyncRef.current = '';
    showToast(
      '⏰ Schedule Saved',
      `Permanent schedule ${time || 'cleared'} · ${targets?.length || 0} target(s)${activeId !== 'admin1' ? ' (VIP phone auto if empty)' : ''}`,
      'success'
    );
  };

  // Live Scrape Market (sequential unique from chart)
  const getMarketScrapeUrl = (marketName: string): string | undefined => resolveMarketScrapeUrl(currentProfile?.config,marketName);

  const scrapeErrorMessage = (json: any, fallback: string): string => {
    const attempts = Array.isArray(json?.sourceAttempts) ? json.sourceAttempts : [];
    const last = attempts.length ? attempts[attempts.length - 1] : null;
    return String(last?.detail ? `${json?.message || fallback} · ${last.detail}` : (json?.message || fallback));
  };

  useEffect(()=>{
    // Passive history navigation cannot reapply an old OPEN→CLOSE result cut;
    // the user must explicitly toggle the control for that selected date.
    if(!isMasterApp||!serverHydrated||currentDate<titanLocalDateISO()||!appState.profiles[activeId]?.dayRecords[currentDate]?.openToCloseCut)return;
    setAppState(prev=>{const p=prev.profiles[activeId];if(!p)return prev;const next=applyOpenToCloseCut(p,currentDate);return next===p?prev:{...prev,profiles:{...prev.profiles,[activeId]:next}};});
  },[isMasterApp,serverHydrated,activeId,currentDate,appState.profiles]);

  const historicalScrapeCutoff = (): Record<string, unknown> =>
    (currentDate < titanLocalDateISO() || (todayBacktest && currentDate === titanLocalDateISO()))
      ? { selectionMode: 'pre_target_recent', targetDate: currentDate, backtest: true, todayBacktest: Boolean(todayBacktest) }
      : {};

  const postScrape = async (body: Record<string, unknown>,preserveTargetDate=false,abortSignal?:AbortSignal) => {
    if (!preserveTargetDate && (currentDate < titanLocalDateISO() || (todayBacktest && currentDate === titanLocalDateISO()))) body = {
      ...body,
      backtest: true,
      targetDate: currentDate,
      todayBacktest: Boolean(todayBacktest),
      ...(body.type === 'ank' && !body.selectionMode ? { selectionMode: 'pre_target_recent' } : {}),
    };
    // Ordinary source buttons consume source digits, never prediction aliases.
    if(body.type==='ank'&&body.smartMode!==true&&!body.resultOnly&&!body.historyTie&&
      (!body.selectionMode||['pre_target_recent','same_weekday_vertical','same_weekday_vertical_combo'].includes(String(body.selectionMode))))body={...body,sourceOnly:true};
    const json=await requestScrape({url:apiUrl('/api/scrape_market'),body,signal:abortSignal,
      // An explicit Result Test should never wait for a second slow chart fetch.
      // The user can retry the button; all other scraping retains normal retries.
      ...(body.fastResult===true?{timeoutMs:21_000,maxAttempts:1 as const}:{} )});
    if(json.staleCache){
      showToast('⚠️ Cached Chart Rejected',`Live chart unavailable · ${Number(json.cacheAgeMinutes||0)} min purana saved chart hai; source/result card unchanged`,'warning');
      // Return an error for every edit/apply caller (not just Result Test).
      // Cached HTML can be displayed in diagnostics but must not write digits.
      return {...json,status:'error',message:json.message||'Fresh source unavailable; cached chart cannot update cards'};
    }
    return json;
  };

  const archiveReplayObserved=useRef<{key:string;signature:string;carryMode?:string}|null>(null);
  const archiveWorkerRef=useRef<Worker|null>(null);
  const archiveWorkerCleanup=useRef<(()=>void)|null>(null);
  const archiveCarryPending=useRef(false);
  const [archiveWake,setArchiveWake]=useState(0);
  useEffect(()=>{
    let timer:ReturnType<typeof setTimeout>|undefined;
    const visibility=()=>{
      clearTimeout(timer);
      if(document.visibilityState==='hidden'){
        const worker=archiveWorkerRef.current;
        if(worker){archiveWorkerCleanup.current?.();
          // Do not force a replay on resume merely because an old worker was cancelled.
        }
      }else timer=setTimeout(()=>setArchiveWake(value=>value+1),1200);
    };
    document.addEventListener('visibilitychange',visibility);
    return()=>{clearTimeout(timer);document.removeEventListener('visibilitychange',visibility);};
  },[]);
  useEffect(()=>()=>{archiveWorkerCleanup.current?.();},[]);
  useEffect(() => {
    if(document.visibilityState==='hidden')return;
    if(!isMasterApp||!serverHydrated||bulkRestoreInFlightRef.current||currentDate>=titanLocalDateISO()){
      archiveCarryPending.current=false;archiveReplayObserved.current=null;archiveWorkerCleanup.current?.();return;
    }
    const key=`${activeId}|${currentDate}`,profile=appState.profiles[activeId];
    const signature=archiveReplaySignature(profile?.dayRecords[currentDate])+(profile?.customLoopChanges?JSON.stringify(loopSettingsForDate(profile,currentDate)):'');
    const previous=archiveReplayObserved.current;
    if(previous?.key!==key)archiveCarryPending.current=false;
    const carryMode=profile?carryControlMode(profile,currentDate):'OFF';
    const carryModeChanged=archiveCarryPending.current||!!previous&&previous.key===key&&previous.carryMode!==carryMode;
    archiveReplayObserved.current={key,signature,carryMode};
    // Opening a previous date is a READ, even for profiles with custom loops.
    // Replay only after an actual change while already viewing that date.
    // Previously first navigation could run automatic source/cut replays and
    // replace a stored digit selection with an empty computed value.
    if(!profile||!shouldReplayHistoricalDay(previous,{key,signature,carryMode},carryModeChanged)){
      archiveWorkerCleanup.current?.();return;
    }
    archiveWorkerCleanup.current?.();
    const day=profile.dayRecords[currentDate],owner=activeId,date=currentDate;
    let worker:Worker;
    try{worker=new Worker(new URL('./workers/archiveRecovery.worker.ts',import.meta.url),{type:'module'});}
    catch{showToast('Archive calculation unavailable','Background worker could not start. Reload and retry the edit.','warning');return;}
    archiveWorkerRef.current=worker;
    archiveCarryPending.current=carryModeChanged;
    const timer=setTimeout(()=>{if(archiveWorkerRef.current===worker){finish();showToast('Archive calculation delayed','Background calculation timed out. Reload and retry.','warning');}},30000);
    const finish=()=>{clearTimeout(timer);worker.onmessage=null;worker.onerror=null;worker.terminate();if(archiveWorkerRef.current===worker){archiveWorkerRef.current=null;archiveWorkerCleanup.current=null;}};
    archiveWorkerCleanup.current=finish;
    worker.onmessage=event=>{
      if(archiveWorkerRef.current!==worker){finish();return;}
      const result=event.data;finish();
      if(result.error){showToast('Archive calculation failed',result.error,'warning');return;}
      archiveCarryPending.current=false;
      if(!result.changed||!result.day)return;
      setAppState(prev=>{
        const p=prev.profiles[owner];
        if(activeIdRef.current!==owner||currentDateRef.current!==date||bulkRestoreInFlightRef.current||!p||p.dayRecords[date]!==day||p.config!==profile.config||p.customLoopChanges!==profile.customLoopChanges)return prev;
        return {...prev,profiles:{...prev.profiles,[owner]:{...p,dayRecords:{...p.dayRecords,[date]:result.day}}}};
      });
    };
    worker.onerror=event=>{event.preventDefault();finish();showToast('Archive calculation failed','Background calculation failed; reload and retry.','warning');};
    worker.postMessage({profile,date,carryModeChanged});
  },[appState.profiles,activeId,currentDate,serverHydrated,isMasterApp,archiveWake]);

  useEffect(() => {
    if (!autoBacktestResult || !isMasterApp || !serverHydrated || currentDate >= titanLocalDateISO()) return;
    let resumeTimer:ReturnType<typeof setTimeout>|undefined;
    const retry = () => { if (document.visibilityState !== 'hidden') setBacktestRetry(value => value + 1); };
    const onResume=()=>{clearTimeout(resumeTimer);if(document.visibilityState!=='hidden')resumeTimer=setTimeout(retry,1700);};
    const timer = window.setInterval(retry, BACKTEST_RESULT_RETRY_MS);
    document.addEventListener('visibilitychange', onResume);
    return () => { window.clearInterval(timer); clearTimeout(resumeTimer); document.removeEventListener('visibilitychange', onResume); };
  }, [autoBacktestResult, isMasterApp, serverHydrated, currentDate]);

  useEffect(() => {
    if (!autoBacktestResult || bulkRestoreInFlightRef.current || !isMasterApp || !serverHydrated || currentDate >= titanLocalDateISO()) return;
    const profile=appState.profiles[activeId], day=profile?.dayRecords[currentDate];
    if (!day) return;
    const revision=day.backtestRevision;
    let cancelled=false;
    const timer=window.setTimeout(async () => {
      if(document.visibilityState==='hidden')return;
      const jobs:Array<{type:GameType;index:number;dictName:'data'|'jodiData'|'pannelData';digits:string;name:string;cacheKey:string;url:string;recordSnapshot:string}>=[];
      for (const type of ['ank','jodi','pannel'] as GameType[]) {
        const dictName=type==='ank' ? 'data' : type==='jodi' ? 'jodiData' : 'pannelData';
        const markets=type==='jodi' ? getEffectiveBaseMarkets(profile.config) : getEffectiveMarkets(profile.config);
        for (const [key,rec] of Object.entries(day[dictName] || {})) {
          if (!canAutoEvaluateBacktest(rec,type) || String(rec.dispatchState)==='SENDING') continue;
          const index=Number(key), name=String(rec.marketName || markets[index]?.n || '');
          if (!name || index<0 || !markets[index]) continue;
          const base=name.replace(/\s+(OPEN|CLOSE)$/i,'').trim();
          const url=resolveMarketScrapeUrl(profile.config,name)||'';
          const cacheKey=`${currentDate}|${base}|${url}`;
          const cached = backtestActualCache.current.get(cacheKey);
          if (isFreshBacktestActual(cached) && (cached?.actual === undefined || (rec.backtestResult?.checked && rec.backtestResult.digits===rec.d && rec.backtestResult.actual===actualForGame(cached?.actual || undefined,type,name)&&(type!=='jodi'||rec.backtestResult.openActual===actualForGame(cached?.actual || undefined,'ank',`${base} OPEN`))))) continue;
          jobs.push({type,index,dictName,digits:rec.d,name,cacheKey,url,recordSnapshot:JSON.stringify(rec)});
        }
      }
      const lookup=(job:typeof jobs[number]) => lookupBacktestActual({
        key:job.cacheKey,date:currentDate,cache:backtestActualCache.current,pending:backtestLookups.current,
        fetcher:()=>postScrape({market:job.name,type:'ank',targetDate:currentDate,resultOnly:true,scrapeUrl:job.url || undefined}),
      }).catch(error=>{
        if(!cancelled)showToast('⚠️ Backtest Result Unavailable',`${job.name}: ${error.message || 'Result fetch failed; retrying automatically'}`,'warning');
        return undefined;
      });
      if (jobs.length) setBacktestChecking(true);
      const applyResults=(results:Array<{job:typeof jobs[number];actual:DatedActual | null | undefined}>)=>{
        if(cancelled||document.visibilityState==='hidden'||bulkRestoreInFlightRef.current||activeIdRef.current!==activeId||currentDateRef.current!==currentDate)return;
        setAppState(prev=>{
          const p=prev.profiles[activeId], original=p?.dayRecords[currentDate];
          if (!original || cancelled || original.backtestRevision!==revision || activeIdRef.current!==activeId || currentDateRef.current!==currentDate) return prev;
          let store={...original},changed=false;
          for (const {job,actual} of results) {
            if (actual===undefined) continue;
            const rec=store[job.dictName]?.[job.index];
            if (!rec || rec.d!==job.digits || JSON.stringify(rec)!==job.recordSnapshot || !canAutoEvaluateBacktest(rec,job.type) || String(rec.dispatchState)==='SENDING') continue;
            const evaluated=evaluateDatedBacktest(rec,job.type,actual || undefined,job.name);
            if (evaluated===rec) continue;
            // Result revisions are independent of source edits and range-job versions.
            // They let a fresh exact-date check survive archive reconciliation.
            const next={...evaluated,backtestResult:evaluated.backtestResult?{
              ...evaluated.backtestResult,updatedAt:Math.max(Date.now(),Number(rec.backtestResult?.updatedAt||0)+1)
            }:undefined};
            store={...store,[job.dictName]:{...store[job.dictName],[job.index]:next}};changed=true;
          }
          if (!changed) return prev;
          const nextProfiles = { ...prev.profiles, [activeId]: calculateBacktestRecovery({ ...p, dayRecords: { ...p.dayRecords, [currentDate]: store } }, currentDate) };
          if (activeId === 'admin1') {
            for (const pid of Object.keys(nextProfiles)) {
              if (pid === 'admin1' || !vipCopiesAdmin(nextProfiles[pid])) continue;
              const vip = nextProfiles[pid];
              const vipStore = { ...(vip.dayRecords?.[currentDate] || {}) };
              let vipChanged = false;
              for (const { job, actual } of results) {
                if (actual === undefined) continue;
                const vipMarkets = job.type === 'jodi' ? getEffectiveBaseMarkets(vip.config) : getEffectiveMarkets(vip.config);
                const vi = findMarketIndexByName(vipMarkets, job.name);
                if (vi < 0) continue;
                const vRec = vipStore[job.dictName]?.[vi];
                if (!vRec || !canAutoEvaluateBacktest(vRec, job.type)) continue;
                const vEval = evaluateDatedBacktest(vRec, job.type, actual || undefined, job.name);
                if (vEval !== vRec) {
                  vipStore[job.dictName] = { ...(vipStore[job.dictName] || {}), [vi]: { ...vEval, backtestResult: vEval.backtestResult ? { ...vEval.backtestResult, updatedAt: Date.now() } : undefined } };
                  vipChanged = true;
                }
              }
              if (vipChanged) {
                nextProfiles[pid] = calculateBacktestRecovery({ ...vip, dayRecords: { ...vip.dayRecords, [currentDate]: vipStore } }, currentDate);
              }
            }
          }
          return { ...prev, profiles: nextProfiles };
        });
      };
      // One worker slot per chart, instead of queuing ANK/JODI/PANEL copies.
      const groups=new Map<string,typeof jobs>();
      for(const job of jobs){const group=groups.get(job.cacheKey)||[];group.push(job);groups.set(job.cacheKey,group);}
      const tasks=[...groups.values()];let cursor=0;
      const worker=async()=>{
        while(!cancelled&&cursor<tasks.length){
          const group=tasks[cursor++],actual=await lookup(group[0]);
          applyResults(group.map(job=>({job,actual})));
        }
      };
      await Promise.all(Array.from({length:Math.min(6,tasks.length)},worker));
      if(!cancelled)setBacktestChecking(false);
    },0);
    return ()=>{cancelled=true;window.clearTimeout(timer);setBacktestChecking(false);};
  },[autoBacktestResult,appState,activeId,currentDate,serverHydrated,isMasterApp,backtestRetry]);

  const individualTestRuns = useRef(new Set<string>());
  const handleIndividualTestResult = async (type: GameType, idx: number) => {
    const owner=activeId, date=currentDate;
    if (!isMasterApp || !serverHydrated || bulkRestoreInFlightRef.current || date>=titanLocalDateISO()) return;
    const profile=appStateRef.current.profiles[owner];
    const markets=type==='jodi'?getEffectiveBaseMarkets(profile?.config):getEffectiveMarkets(profile?.config);
    const name=markets[idx]?.n;
    const dict=type==='ank'?'data':type==='jodi'?'jodiData':'pannelData';
    const day=profile?.dayRecords[date], record=day?.[dict]?.[idx];
    if (!name || !canAutoEvaluateBacktest(record,type) || String(record?.dispatchState)==='SENDING') return;
    const key=`${owner}|${date}|${type}|${idx}`;
    if(individualTestRuns.current.has(key))return;
    individualTestRuns.current.add(key);
    const snapshot=JSON.stringify(record), revision=day?.backtestRevision;
    try {
      const url=resolveMarketScrapeUrl(profile.config,name)||'';
      const base=name.replace(/\s+(OPEN|CLOSE)$/i,'').trim();
      const actual=await lookupBacktestActual({key:`${date}|${base}|${url}`,date,explicit:true,
        cache:backtestActualCache.current,pending:backtestLookups.current,
        fetcher:()=>postScrape({market:name,type:'ank',targetDate:date,resultOnly:true,fastResult:true,scrapeUrl:url||undefined},true)});
      if(actual===undefined)throw new Error('Exact-date result unavailable; retry');
      if(activeIdRef.current!==owner||currentDateRef.current!==date||bulkRestoreInFlightRef.current){
        showToast('Result not applied', 'Profile/date changed while checking. Select the original date and retry.','warning');
        return;
      }
      // A save/sync/update may have edited this card during the network wait.
      // Surface that conflict instead of announcing a misleading successful test.
      const latestProfile=appStateRef.current.profiles[owner];
      const latestDay=latestProfile?.dayRecords[date];
      const latestRecord=latestDay?.[dict]?.[idx];
      const latestMarkets=type==='jodi'?getEffectiveBaseMarkets(latestProfile?.config):getEffectiveMarkets(latestProfile?.config);
      if(!latestRecord||JSON.stringify(latestRecord)!==snapshot||latestDay?.backtestRevision!==revision||latestMarkets[idx]?.n!==name||String(latestRecord.dispatchState)==='SENDING'){
        showToast('Result not applied',`${name}: Card changed during result lookup. Reload/check card, then retry.`,'warning');
        return;
      }
      setAppState(prev=>{
        const p=prev.profiles[owner], original=p?.dayRecords[date], rec=original?.[dict]?.[idx];
        const currentMarkets=type==='jodi'?getEffectiveBaseMarkets(p?.config):getEffectiveMarkets(p?.config);
        if(activeIdRef.current!==owner||currentDateRef.current!==date||bulkRestoreInFlightRef.current||!rec||currentMarkets[idx]?.n!==name||original.backtestRevision!==revision||JSON.stringify(rec)!==snapshot||String(rec.dispatchState)==='SENDING')return prev;
        const evaluated=evaluateDatedBacktest(rec,type,actual||undefined,name);
        if(evaluated===rec)return prev;
        const next={...evaluated,backtestResult:evaluated.backtestResult?{...evaluated.backtestResult,updatedAt:Math.max(Date.now(),Number(rec.backtestResult?.updatedAt||0)+1)}:undefined};
        const updatedProf = calculateBacktestRecovery({...p,dayRecords:{...p.dayRecords,[date]:{...original,[dict]:{...original[dict],[idx]:next}}}}, date);
        const nextProfiles = { ...prev.profiles, [owner]: updatedProf };
        if (owner === 'admin1') {
          for (const pid of Object.keys(nextProfiles)) {
            if (pid === 'admin1' || !vipCopiesAdmin(nextProfiles[pid])) continue;
            const vip = nextProfiles[pid];
            const vipMarkets = type === 'jodi' ? getEffectiveBaseMarkets(vip?.config) : getEffectiveMarkets(vip?.config);
            const vi = findMarketIndexByName(vipMarkets, name);
            const vOrig = vip?.dayRecords?.[date];
            const vRec = vi >= 0 ? vOrig?.[dict]?.[vi] : undefined;
            if (vOrig && vRec && canAutoEvaluateBacktest(vRec, type)) {
              const vEval = evaluateDatedBacktest(vRec, type, actual || undefined, name);
              if (vEval !== vRec) {
                const vNext = { ...vEval, backtestResult: vEval.backtestResult ? { ...vEval.backtestResult, updatedAt: Date.now() } : undefined };
                nextProfiles[pid] = calculateBacktestRecovery({ ...vip, dayRecords: { ...vip.dayRecords, [date]: { ...vOrig, [dict]: { ...vOrig[dict], [vi]: vNext } } } }, date);
              }
            }
          }
        }
        return { ...prev, profiles: nextProfiles };
      });
      const notice=resultTestNotice(actual,type,name,date);
      showToast(notice.title,notice.message,notice.kind);
    } catch(error) {
      showToast('Test Result unavailable',resultTestErrorMessage(error),'warning');
    } finally { individualTestRuns.current.delete(key); }
  };

  const handleScrapeMarket = async (type: GameType, idx: number, marketName: string) => {
    if (type !== 'ank') return;
    const scrapeGuard = captureScrapeGuard(type, idx, marketName);
    try {
      const json = await postScrape({ market: marketName, type, isCombo: false, ...historicalScrapeCutoff(), scrapeUrl: getMarketScrapeUrl(marketName) });

      if (json.status === 'success') {
        const val = json.digits || json.open;
        if(!val)throw new Error('Chart returned no digits');
        if (val) {
          if (!handleUpdateRecord(type, idx, 'd', val, { sourceDigits: json.sourceDigits?.AUTO, scrapeGuard, scrapedSourceMode: 'AUTO' })) return;
          const count = String(val).split(/[, ]+/).filter((digit: string) => /^\d$/.test(digit)).length;
          showToast('📡 Auto Scraped', `${marketName}: ${count} recent unique digits`, 'success');
        }
      } else {
        showToast('❌ Scrape Failed', scrapeErrorMessage(json, 'No data'), 'danger');
      }
    } catch (e) {
      showToast('❌ Scrape Failed', 'Unable to fetch chart data.', 'danger');
    }
  };

  const handleWeekdayScrapeMarket = async (type: GameType, idx: number, marketName: string) => {
    if (type !== 'ank') return;
    const scrapeGuard = captureScrapeGuard(type, idx, marketName);
    try {
      const json = await postScrape({
        market: marketName,
        type,
        isCombo: false,
        selectionMode: 'same_weekday_vertical',
        targetDate: currentDate,
        scrapeUrl: getMarketScrapeUrl(marketName),
      });
      if (json.status !== 'success') {
        showToast('❌ Day Scrape Failed', scrapeErrorMessage(json, 'Same-weekday history unavailable'), 'danger');
        return;
      }
      const val = json.digits;
      if (!val)throw new Error('Chart returned no weekday digits');
      if (!handleUpdateRecord(type, idx, 'd', val, { sourceDigits: json.sourceDigits?.WEEKDAY, scrapeGuard, scrapedSourceMode: 'WEEKDAY' })) return;
      const meta = json.weekdayVertical || {};
      showToast(
        '↥ Day Column Scraped',
        `${marketName}: ${String(meta.weekdayName || 'weekday')} ${String(meta.side || '').toUpperCase()} · ${String(json.digits||'').split(/[,|\s]+/).filter(Boolean).length} unique`,
        'success',
      );
    } catch (_) {
      showToast('❌ Day Scrape Failed', 'Unable to fetch same-weekday chart data.', 'danger');
    }
  };

  const handleDayComboScrape = async (type: GameType, idx: number, marketName: string) => {
    if (type !== 'ank') return;
    const scrapeGuard = captureScrapeGuard(type, idx, marketName);
    try {
      const json = await postScrape({
        market: marketName, type, isCombo: true,
        selectionMode: 'same_weekday_vertical_combo', targetDate: currentDate,
        scrapeUrl: getMarketScrapeUrl(marketName),
      });
      if (json.status !== 'success') {
        showToast('❌ Day Combo Failed', scrapeErrorMessage(json, 'Same-weekday combined history unavailable'), 'danger');
        return;
      }
      if (!json.digits)throw new Error('Chart returned no day-combo digits');
      if (!handleUpdateRecord(type, idx, 'd', json.digits, { sourceDigits: json.sourceDigits?.DAY_COMBO, scrapeGuard, scrapedSourceMode: 'DAY_COMBO' })) return;
      showToast('↥ Day Combo Scraped', `${marketName}: ${json.weekdayVertical?.weekdayName || 'weekday'} · CLOSE → OPEN · ${String(json.digits || '').split(/[,|\s]+/).filter(Boolean).length} unique`, 'success');
    } catch (_) {
      showToast('❌ Day Combo Failed', 'Unable to fetch same-weekday chart data.', 'danger');
    }
  };

  // Combo Scrape
  const handleComboScrape = async (type: GameType, idx: number, marketName: string) => {
    if (type !== 'ank') return;
    const scrapeGuard = captureScrapeGuard(type, idx, marketName);
    try {
      const json = await postScrape({ market: marketName, type, isCombo: true, ...historicalScrapeCutoff(), scrapeUrl: getMarketScrapeUrl(marketName) });

      if (json.status === 'success') {
        const combined = json.digits || json.combined || json.open;
        if(!combined)throw new Error('Chart returned no combined digits');
        if (combined) {
          if (!handleUpdateRecord(type, idx, 'd', combined, { sourceDigits: json.sourceDigits?.COMBO, scrapeGuard, scrapedSourceMode: 'COMBO' })) return;
          showToast('⚡ Combo Scraped!', `Combined digits for ${marketName}`, 'success');
        }
      } else {
        showToast('❌ Combo Failed', scrapeErrorMessage(json, 'Chart fetch failed'), 'danger');
      }
    } catch (e) {
      showToast('❌ Combo Failed', 'Server error.', 'danger');
    }
  };

  const smartSourceForCard=(idx:number,marketName:string):{mode:FrequencySourceMode;digits?:string}=>{
    const record=appStateRef.current.profiles[activeIdRef.current]?.dayRecords?.[currentDateRef.current]?.data?.[idx];
    if(record?.marketName&&record.marketName.trim().toUpperCase()!==marketName.trim().toUpperCase())throw new Error('Smart: market/source identity mismatch; card unchanged');
    const source=getScrapeSource(record);
    if(record?.sourceMode&&((record.scrapeSource&&record.scrapeSource.mode!==record.sourceMode)||(source&&source.mode!==record.sourceMode)))throw new Error('Smart: selected mode aur saved source mismatch; chosen source dobara scrape karein. Card unchanged');
    const mode=source?.mode||record?.sourceMode;
    if(!isFrequencySourceMode(mode))throw new Error('Smart: pehle Auto, Day, Combo, Day Mix, Pair Follow, Digit Follow ya Panna Follow source scrape karein; card unchanged');
    return {mode,digits:source?.digits};
  };
  /** Smart transforms its card's selected source; it never substitutes Auto. */
  const handleSmartAutoDigits = async (type: GameType, idx: number, marketName: string) => {
    if(type!=='ank')return;
    const scrapeGuard=captureScrapeGuard(type,idx,marketName);
    try{
      const source=smartSourceForCard(idx,marketName);
      if(source.digits){scrapeGuard.sourceMode=source.mode;scrapeGuard.sourceDigits=source.digits;}
      const json=await postScrape({market:marketName,type,isCombo:false,selectionMode:'source_frequency',frequencySourceMode:source.mode,expectedSourceDigits:source.digits,targetDate:scrapeGuard.date,scrapeUrl:getMarketScrapeUrl(marketName)});
      if(json.status==='unchanged'){showToast('Smart · unchanged',json.message||'Comparison tied or insufficient history','info');return;}
      if(json.status!=='success'||!json.smartDigits)throw new Error(scrapeErrorMessage(json,'Source frequency unavailable'));
      if(!handleUpdateRecord(type,idx,'d',json.smartDigits,{sourceDigits:json.sourceDigits?.[source.mode],scrapeGuard,scrapedSourceMode:source.mode,smartSelection:json.smartSelection}))return;
      showToast(`Smart · ${json.smartSelection?.digitCount ? `${json.smartSelection.digitCount}D` : '5D'}${json.smartSelection?.decision==='REVERSE' ? ' (Cut)' : ''}`, `${marketName} · ${source.mode}${json.smartSelection?.recommendedFilter ? ` · ${json.smartSelection.recommendedFilter}` : ''} · ${json.smartDigits}`, 'success');
    }catch(error:any){showToast('Smart unavailable',error?.message||'Card unchanged','warning');}
  };

  const handleTrendBreak = async (type:GameType,idx:number,marketName:string) => {
    if(type!=='ank')return;
    const scrapeGuard=captureScrapeGuard(type,idx,marketName);
    try{
      const source=smartSourceForCard(idx,marketName);
      const currentDigits=appStateRef.current.profiles[activeIdRef.current]?.dayRecords?.[scrapeGuard.date]?.data?.[idx]?.d||'';
      if(!source.digits||!currentDigits.trim())throw new Error('Trend Break: saved source and current digits required; card unchanged');
      scrapeGuard.sourceMode=source.mode;scrapeGuard.sourceDigits=source.digits;
      const json=await postScrape({market:marketName,type,selectionMode:'trend_break',frequencySourceMode:source.mode,expectedSourceDigits:source.digits,currentDigits,targetDate:scrapeGuard.date,scrapeUrl:getMarketScrapeUrl(marketName)});
      if(json.status==='unchanged' || !json.digits){
        const prob = scoreDigitProbabilities(currentDigits, [], 5);
        if (prob.digits && prob.digits !== currentDigits) {
          if (handleUpdateRecord(type, idx, 'd', prob.digits, { sourceDigits: source.digits, scrapeGuard, scrapedSourceMode: source.mode })) {
            showToast(`Trend Filter · ${prob.rankedDigits.length}D`, `${marketName} · High-probability momentum: ${prob.digits}`, 'success');
            return;
          }
        }
        showToast('Trend · unchanged', json.message || 'Already optimal size (4–5 digits); card unchanged', 'info');
        return;
      }
      if(json.status!=='success'||!json.digits)throw new Error(scrapeErrorMessage(json,'Trend unavailable'));
      if(!handleUpdateRecord(type,idx,'d',json.digits,{sourceDigits:json.sourceDigits?.[source.mode],scrapeGuard,scrapedSourceMode:source.mode,...(json.smartSelection?{smartSelection:json.smartSelection}:{})}))return;
      const count = String(json.digits).split(/[,|\s]+/).filter(Boolean).length;
      showToast(`Trend ${json.trendBreak?.decision==='FOLLOW' ? 'Follow' : 'Break'} · ${count}D`, `${marketName} · High-probability: ${json.digits}`, 'success');
    }catch(error:any){
      const prob = scoreDigitProbabilities(appStateRef.current.profiles[activeIdRef.current]?.dayRecords?.[scrapeGuard.date]?.data?.[idx]?.d || '', [], 5);
      if (prob.digits) {
        handleUpdateRecord(type, idx, 'd', prob.digits, { scrapeGuard });
        showToast(`Trend Filter · ${prob.rankedDigits.length}D`, `${marketName} · Momentum fallback: ${prob.digits}`, 'success');
      } else {
        showToast('Trend Break · unchanged', error?.message || 'Card unchanged', 'info');
      }
    }
  };

  /**
   * Read the Ank digits entered for the same market/index as the Panel card.
   * A Patti is valid only when its three-digit sum reduced modulo 10 matches
   * one of these Ank digits.
   */
  const getAnkDigitsForPanel = (idx: number, marketName?: string): string[] => {
    const markets = getEffectiveMarkets(currentProfile.config || getDefaultConfig());
    const stableName = String(marketName || markets[idx]?.n || '').trim().toUpperCase();
    const stableIndex = stableName ? findMarketIndexByName(markets, stableName) : idx;
    const records = currentProfile?.dayRecords?.[currentDate]?.data || {};
    const record = stableIndex >= 0
      ? findHistoricalMarketRecord(records, stableIndex, stableName)
      : undefined;
    return normalizeAnkDigits(record?.d);
  };

  /**
   * Jodi has one deterministic source: same market OPEN ANK × CLOSE ANK.
   * Market names are used instead of indexes so custom/reordered VIP markets
   * cannot borrow digits from a different Admin/VIP card.
   */
  const getJodiFromSameMarketAnk = (baseMarketName: string) => {
    const baseName = String(baseMarketName || '').replace(/\s+(OPEN|CLOSE)$/i, '').trim();
    const ankMarkets = getEffectiveMarkets(currentProfile.config || getDefaultConfig());
    const ankRecords = currentProfile.dayRecords[currentDate]?.data || {};
    const openName = `${baseName} OPEN`;
    const closeName = `${baseName} CLOSE`;
    const openIdx = findMarketIndexByName(ankMarkets, openName);
    const closeIdx = findMarketIndexByName(ankMarkets, closeName);
    const openRecord = openIdx >= 0
      ? findHistoricalMarketRecord(ankRecords, openIdx, openName)
      : undefined;
    const closeRecord = closeIdx >= 0
      ? findHistoricalMarketRecord(ankRecords, closeIdx, closeName)
      : undefined;
    const openDigits = normalizeAnkDigits(openRecord?.d);
    const closeDigits = normalizeAnkDigits(closeRecord?.d);

    return {
      openDigits,
      closeDigits,
      jodis: buildJodisFromAnk(openDigits.join(','), closeDigits.join(',')),
    };
  };

  const handleBuildJodiFromAnk = (idx: number, marketName: string) => {
    const { openDigits, closeDigits, jodis } = getJodiFromSameMarketAnk(marketName);
    if (!openDigits.length || !closeDigits.length) {
      const missing = !openDigits.length && !closeDigits.length
        ? 'OPEN aur CLOSE'
        : !openDigits.length ? 'OPEN' : 'CLOSE';
      showToast('ℹ️ ANK Required', `${marketName}: pehle same market ka ${missing} ANK digit bharo`, 'info');
      return false;
    }
    handleUpdateRecord('jodi', idx, 'd', jodis.join(', '));
    handleUpdateRecord('jodi', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
    showToast('🔗 Jodi Ready', `${marketName}: ${openDigits.length} × ${closeDigits.length} = ${jodis.length} Jodi`, 'success');
    return true;
  };

  const handleBulkJodiFromAnk = () => {
    if (!isMasterApp || bulkAction) return;
    const cfg = currentProfile.config || getDefaultConfig();
    const markets = getEffectiveBaseMarkets(cfg);
    const dayStore = currentProfile.dayRecords[currentDate] || {};
    const jodiRecords = dayStore.jodiData || {};
    const visible = dayStore.visJodi;
    let updated = 0;
    let missing = 0;

    setBulkAction('jodi:ank-combine');
    for (let idx = 0; idx < markets.length; idx++) {
      const market = markets[idx];
      const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(market.n, market.hr) : isNightMarket(market.n, market.hr);
      if (!inScope) continue;
      const record = jodiRecords[idx];
      const frozen = Boolean(
        record?.sentRate || record?.sentDigits || record?.dispatchState === 'SENT' ||
        record?.dispatchState === 'SETTLED' || record?.s === 'PASS' || record?.s === 'FAIL'
      );
      if (frozen || !isMarketEnabledForDate(cfg, visible, market.n, currentDate)) continue;
      const { openDigits, closeDigits, jodis } = getJodiFromSameMarketAnk(market.n);
      if (!openDigits.length || !closeDigits.length || !jodis.length) {
        missing++;
        continue;
      }
      handleUpdateRecord('jodi', idx, 'd', jodis.join(', '));
      handleUpdateRecord('jodi', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      updated++;
    }
    setBulkAction(null);
    showToast(
      updated ? '✅ Jodi Bulk Ready' : 'ℹ️ ANK Required',
      `${updated} cards updated${missing ? ` · ${missing} me OPEN/CLOSE ANK missing` : ''}`,
      updated ? 'success' : 'info',
    );
  };

  const handleApplyUniversalLifetime4Ank = async (idx: number, marketName: string) => {
    const isJodi = activeTab === 'jodi';
    const isPast = currentDate < titanLocalDateISO();
    const baseName = marketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim();

    let refJodi = findReferenceJodiForMarket({
      profile: currentProfile,
      currentDate,
      baseMarketName: baseName,
      fallbackIndex: idx,
    })?.refJodi;

    // Check jodiData
    if (!refJodi) {
      const day = currentProfile?.dayRecords?.[currentDate];
      const jRec = day?.jodiData?.[idx];
      const cand = jRec?.manualResult || jRec?.scrapeResultDigit || (jRec?.backtestResult as any)?.actual?.jodi || (jRec?.backtestResult as any)?.actual;
      if (cand && /^\d{2}$/.test(String(cand).replace(/\D/g, ''))) {
        refJodi = String(cand).replace(/\D/g, '').slice(0, 2);
      }
    }

    // Fetch chart from server with strict date cutoff
    if (!refJodi) {
      try {
        const json = await postScrape({
          market: baseName,
          type: 'ank',
          isCombo: false,
          targetDate: currentDate,
          backtest: isPast,
          scrapeUrl: getMarketScrapeUrl(baseName),
        }, true);

        const cand = json?.lastJodi || json?.markovMeta?.lastJodi || json?.ranked?.jodi?.[0];
        if (cand && /^\d{2}$/.test(String(cand).replace(/\D/g, ''))) {
          refJodi = String(cand).replace(/\D/g, '').slice(0, 2);
        }
      } catch (_) {}
    }

    // If CLOSE card, detect today's open result digit and if Open failed
    let todayOpenDigit: string | undefined;
    let isOpenFailed = false;
    if (marketName.trim().toUpperCase().endsWith('CLOSE')) {
      const openName = `${baseName} OPEN`;
      const allMarkets = getEffectiveMarkets(currentProfile?.config || getDefaultConfig());
      const openIdx = findMarketIndexByName(allMarkets, openName);
      if (openIdx >= 0) {
        const openRec = currentProfile?.dayRecords?.[currentDate]?.data?.[openIdx];
        const cand = openRec?.manualResult || openRec?.scrapeResultDigit || (openRec?.backtestResult as any)?.actual?.open || (openRec?.backtestResult as any)?.actual;
        const clean = String(cand ?? '').replace(/\D/g, '');
        if (clean.length >= 1) todayOpenDigit = clean[0];
        if (openRec?.s === 'FAIL') isOpenFailed = true;
      }
    }

    if (!refJodi) {
      refJodi = '24';
    }

    const res = calculateOptimizedMarket4Ank({
      marketName,
      refJodi,
      todayOpenDigit,
      isOpenFailed,
    });
    if (!res) {
      showToast('⚠️ Calculation Error', 'Valid 2-digit Jodi chahiye (e.g. 24)', 'danger');
      return false;
    }

    if (isJodi) {
      handleUpdateRecord('jodi', idx, 'd', res.jodis16.join(', '), { positionRule: 'FLOW_3_1' as any });
      handleUpdateRecord('jodi', idx, 'sourceMode', 'FLOW_3_1' satisfies CardSourceMode);
      showToast('👑 16-JODI LIFETIME', `${marketName}: ${res.formulaName} ➔ 16 Jodis!`, 'success');
    } else {
      handleUpdateRecord('ank', idx, 'd', res.ank4.join(', '), {
        positionRule: 'FLOW_3_1' as any,
        masterFlow: {
          anchor: String(res.ank4[0]),
          shield: String(res.ank4[1]),
          neighbor: String(res.ank4[2]),
          parity: String(res.ank4[3]),
          digits: res.ank4.join(', '),
          reason: `${res.formulaName} · ${res.sourceDesc}`,
          winningLogics: [res.summary],
        },
      });
      handleUpdateRecord('ank', idx, 'sourceMode', 'FLOW_3_1' satisfies CardSourceMode);
      showToast('👑 4-ANK LIFETIME', `${marketName}: ${res.summary}`, 'success');
    }
    return true;
  };


  const handleApplyKalyanFarak = async (idx: number, marketName: string) => {
    const isJodi = activeTab === 'jodi';
    const isPast = currentDate < titanLocalDateISO();
    const baseName = marketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim();

    let refJodi = findReferenceJodiForMarket({
      profile: currentProfile,
      currentDate,
      baseMarketName: baseName,
      fallbackIndex: idx,
    })?.refJodi;

    // Fetch chart from server with strict date cutoff
    if (!refJodi) {
      try {
        const json = await postScrape({
          market: baseName,
          type: 'ank',
          isCombo: false,
          targetDate: currentDate,
          backtest: isPast,
          scrapeUrl: getMarketScrapeUrl(baseName),
        }, true);

        const cand = json?.lastJodi || json?.markovMeta?.lastJodi || json?.ranked?.jodi?.[0];
        if (cand && /^\d{2}$/.test(cand)) {
          refJodi = cand;
        }
      } catch (_) {}
    }

    if (!refJodi) {
      const input = window.prompt(`${marketName}: Pichli Jodi darj karein (e.g. 68 ya 27):`, '68');
      if (!input) return false;
      refJodi = input.trim();
    }

    const res = calculateKalyanFarakForward4Ank(refJodi);
    if (!res) {
      showToast('⚠️ Calculation Error', 'Valid 2-digit Jodi chahiye', 'danger');
      return false;
    }

    if (isJodi) {
      handleUpdateRecord('jodi', idx, 'd', res.jodis16.join(', '));
      handleUpdateRecord('jodi', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 KALYAN 16 JODI', `${marketName}: Last ${res.refJodi} (Farak ${res.diff}) ➔ 16 Jodis!`, 'success');
    } else {
      handleUpdateRecord('ank', idx, 'd', res.ank4.join(', '));
      handleUpdateRecord('ank', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 KALYAN 4-ANK', `${marketName}: Last ${res.refJodi} (Farak ${res.diff}) ➔ 4 Ank: ${res.ank4.join(', ')}`, 'success');
    }
    return true;
  };

  const handleApplyMilanNight = async (idx: number, marketName: string) => {
    const isJodi = activeTab === 'jodi';
    const isPast = currentDate < titanLocalDateISO();
    const baseName = marketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim();

    let refJodi = findReferenceJodiForMarket({
      profile: currentProfile,
      currentDate,
      baseMarketName: baseName,
      fallbackIndex: idx,
    })?.refJodi;

    // Fetch chart from server with strict date cutoff
    if (!refJodi) {
      try {
        const json = await postScrape({
          market: baseName,
          type: 'ank',
          isCombo: false,
          targetDate: currentDate,
          backtest: isPast,
          scrapeUrl: getMarketScrapeUrl(baseName),
        }, true);

        const cand = json?.lastJodi || json?.markovMeta?.lastJodi || json?.ranked?.jodi?.[0];
        if (cand && /^\d{2}$/.test(cand)) {
          refJodi = cand;
        }
      } catch (_) {}
    }

    if (!refJodi) {
      const input = window.prompt(`${marketName}: Pichli settled Jodi darj karein (e.g. 62 ya 89):`, '62');
      if (!input) return false;
      refJodi = input.trim();
    }

    const res = calculateMilanNight23Pyramid4Ank(refJodi);
    if (!res) {
      showToast('⚠️ Calculation Error', 'Valid 2-digit Jodi chahiye', 'danger');
      return false;
    }

    if (isJodi) {
      handleUpdateRecord('jodi', idx, 'd', res.jodis16.join(', '));
      handleUpdateRecord('jodi', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 MILAN NIGHT 16 JODI', `${marketName}: Last ${res.refJodi} (Apex ${res.apex}) ➔ 16 Jodis!`, 'success');
    } else {
      handleUpdateRecord('ank', idx, 'd', res.ank4.join(', '));
      handleUpdateRecord('ank', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 MILAN NIGHT 4-ANK', `${marketName}: Last ${res.refJodi} (Apex ${res.apex}) ➔ 4 Ank: ${res.ank4.join(', ')}`, 'success');
    }
    return true;
  };

  const handleApplyMainBazar = async (idx: number, marketName: string) => {
    const isJodi = activeTab === 'jodi';
    const isPast = currentDate < titanLocalDateISO();
    const baseName = marketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim();

    let refJodi = findReferenceJodiForMarket({
      profile: currentProfile,
      currentDate,
      baseMarketName: baseName,
      fallbackIndex: idx,
    })?.refJodi;

    // Fetch chart from server with strict date cutoff
    if (!refJodi) {
      try {
        const json = await postScrape({
          market: baseName,
          type: 'ank',
          isCombo: false,
          targetDate: currentDate,
          backtest: isPast,
          scrapeUrl: getMarketScrapeUrl(baseName),
        }, true);

        const cand = json?.lastJodi || json?.markovMeta?.lastJodi || json?.ranked?.jodi?.[0];
        if (cand && /^\d{2}$/.test(cand)) {
          refJodi = cand;
        }
      } catch (_) {}
    }

    if (!refJodi) {
      const input = window.prompt(`${marketName}: Pichli settled Jodi darj karein (e.g. 16 ya 77):`, '16');
      if (!input) return false;
      refJodi = input.trim();
    }

    const res = calculateMainBazarStepBackCut4Ank(refJodi);
    if (!res) {
      showToast('⚠️ Calculation Error', 'Valid 2-digit Jodi chahiye', 'danger');
      return false;
    }

    if (isJodi) {
      handleUpdateRecord('jodi', idx, 'd', res.jodis16.join(', '));
      handleUpdateRecord('jodi', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 MAIN BAZAR 16 JODI', `${marketName}: Last ${res.refJodi} (Total ${res.total}) ➔ 16 Jodis!`, 'success');
    } else {
      handleUpdateRecord('ank', idx, 'd', res.ank4.join(', '));
      handleUpdateRecord('ank', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 MAIN BAZAR 4-ANK', `${marketName}: Last ${res.refJodi} (Total ${res.total}) ➔ 4 Ank: ${res.ank4.join(', ')}`, 'success');
    }
    return true;
  };

  const handleApplySupremeCenter = async (idx: number, marketName: string) => {
    const isJodi = activeTab === 'jodi';
    const isPast = currentDate < titanLocalDateISO();
    const baseName = marketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim();

    let openPatti: string | undefined;
    let closePatti: string | undefined;

    // 1. Try local profile memory from prior dates
    const sortedDates = Object.keys(currentProfile?.dayRecords || {})
      .filter((d) => d < currentDate && /^\d{4}-\d{2}-\d{2}$/.test(d))
      .sort((a, b) => b.localeCompare(a));

    const pannelMarkets = getEffectiveMarkets(currentProfile?.config || getDefaultConfig());
    const openPName = `${baseName} OPEN`;
    const closePName = `${baseName} CLOSE`;
    const openPIdx = findMarketIndexByName(pannelMarkets, openPName);
    const closePIdx = findMarketIndexByName(pannelMarkets, closePName);

    for (const d of sortedDates) {
      const pStore = currentProfile?.dayRecords?.[d]?.pannelData;
      const op = pStore?.[openPIdx]?.manualResult || pStore?.[openPIdx]?.backtestResult?.actual?.open;
      const cp = pStore?.[closePIdx]?.manualResult || pStore?.[closePIdx]?.backtestResult?.actual?.close;
      if (op && cp && /^\d{3}$/.test(op) && /^\d{3}$/.test(cp)) {
        openPatti = op;
        closePatti = cp;
        break;
      }
    }

    // 2. Fetch chart from server with strict date cutoff
    if (!openPatti || !closePatti) {
      try {
        const json = await postScrape({
          market: baseName,
          type: 'ank',
          isCombo: false,
          targetDate: currentDate,
          backtest: isPast,
          scrapeUrl: getMarketScrapeUrl(baseName),
        }, true);

        if (json?.lastOpenPanel && json?.lastClosePanel) {
          openPatti = String(json.lastOpenPanel);
          closePatti = String(json.lastClosePanel);
        }
      } catch (_) {}
    }

    // 3. Fallback to prompt if chart has missing fields
    if (!openPatti || !closePatti) {
      const input = window.prompt(`${marketName}: Pichle Open Panna aur Close Panna darj karein (e.g. 680, 267):`, '680, 267');
      if (!input) return false;
      const parts = input.split(/[,|\s]+/).map(t => t.trim()).filter(Boolean);
      if (parts.length >= 2) {
        openPatti = parts[0];
        closePatti = parts[1];
      }
    }

    if (!openPatti || !closePatti) {
      showToast('⚠️ Data Required', `${marketName}: Open Panna aur Close Panna nahi mile`, 'warning');
      return false;
    }

    const res = calculateSupremeCenterTouch(openPatti, closePatti);
    if (!res) {
      showToast('⚠️ Calculation Error', 'Valid Panna (3-digit) chahiye', 'danger');
      return false;
    }

    if (isJodi) {
      handleUpdateRecord('jodi', idx, 'd', res.jodis16.join(', '));
      handleUpdateRecord('jodi', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 SUPREME 16 JODI', `${marketName}: Centers (${res.p1Center} + ${res.p2Center} = ${res.sum}) ➔ 16 Jodis!`, 'success');
    } else {
      handleUpdateRecord('ank', idx, 'd', res.ank4.join(', '));
      handleUpdateRecord('ank', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 SUPREME 4-ANK', `${marketName}: Centers (${res.p1Center} + ${res.p2Center} = ${res.sum}) ➔ 4 Ank: ${res.ank4.join(', ')}`, 'success');
    }
    return true;
  };

  const handleApplyMilanPyramid = async (idx: number, marketName: string) => {
    const isJodi = activeTab === 'jodi';
    const isPast = currentDate < titanLocalDateISO();
    const baseName = marketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim();

    let openPatti: string | undefined;
    let closePatti: string | undefined;
    let jodiVal: string | undefined;

    // 1. Try local profile memory from prior dates
    const sortedDates = Object.keys(currentProfile?.dayRecords || {})
      .filter((d) => d < currentDate && /^\d{4}-\d{2}-\d{2}$/.test(d))
      .sort((a, b) => b.localeCompare(a));

    const pannelMarkets = getEffectiveMarkets(currentProfile?.config || getDefaultConfig());
    const openPName = `${baseName} OPEN`;
    const closePName = `${baseName} CLOSE`;
    const openPIdx = findMarketIndexByName(pannelMarkets, openPName);
    const closePIdx = findMarketIndexByName(pannelMarkets, closePName);

    for (const d of sortedDates) {
      const pStore = currentProfile?.dayRecords?.[d]?.pannelData;
      const jStore = currentProfile?.dayRecords?.[d]?.jodiData;
      const op = pStore?.[openPIdx]?.manualResult || pStore?.[openPIdx]?.backtestResult?.actual?.open;
      const cp = pStore?.[closePIdx]?.manualResult || pStore?.[closePIdx]?.backtestResult?.actual?.close;
      const jd = jStore?.[idx]?.manualResult || jStore?.[idx]?.backtestResult?.actual?.jodi;
      if (op && cp && jd && /^\d{3}$/.test(op) && /^\d{3}$/.test(cp) && /^\d{2}$/.test(jd)) {
        openPatti = op;
        closePatti = cp;
        jodiVal = jd;
        break;
      }
    }

    // 2. Fetch chart from server with strict date cutoff
    if (!openPatti || !closePatti || !jodiVal) {
      try {
        const json = await postScrape({
          market: baseName,
          type: 'ank',
          isCombo: false,
          targetDate: currentDate,
          backtest: isPast,
          scrapeUrl: getMarketScrapeUrl(baseName),
        }, true);

        if (json?.lastOpenPanel && json?.lastClosePanel && json?.lastJodi) {
          openPatti = String(json.lastOpenPanel);
          closePatti = String(json.lastClosePanel);
          jodiVal = String(json.lastJodi);
        }
      } catch (_) {}
    }

    // 3. Fallback to reference Jodi or prompt if chart has missing fields
    if (!openPatti || !closePatti || !jodiVal) {
      const refJodi = findReferenceJodiForMarket({
        profile: currentProfile,
        currentDate,
        baseMarketName: baseName,
        fallbackIndex: idx,
      })?.refJodi;

      if (refJodi && /^\d{2}$/.test(refJodi)) {
        jodiVal = refJodi;
      } else {
        const input = window.prompt(`${marketName}: Pichle Open Panna, Jodi aur Close Panna darj karein (ya sirf Jodi jaise 15):`, '245, 15, 357');
        if (!input) return false;
        const parts = input.split(/[,|\s]+/).map(t => t.trim()).filter(Boolean);
        if (parts.length >= 3) {
          openPatti = parts[0];
          jodiVal = parts[1];
          closePatti = parts[2];
        } else if (parts.length === 1 && /^\d{2}$/.test(parts[0])) {
          jodiVal = parts[0];
        }
      }
    }

    if (!jodiVal && (!openPatti || !closePatti)) {
      showToast('⚠️ Data Required', `${marketName}: Open Panna, Jodi aur Close Panna nahi mile`, 'warning');
      return false;
    }

    const res = (openPatti && closePatti && jodiVal)
      ? calculateMilanDayPyramid(openPatti, jodiVal, closePatti)
      : calculateMilanDayPyramid(jodiVal);
    if (!res) {
      showToast('⚠️ Calculation Error', 'Valid Panna (3-digit) aur Jodi (2-digit) chahiye', 'danger');
      return false;
    }

    if (isJodi) {
      handleUpdateRecord('jodi', idx, 'd', res.jodis8.join(', '));
      handleUpdateRecord('jodi', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 MILAN 8-JODI', `${marketName}: Pyramid ➔ 8 Jodis: ${res.jodis8.join(', ')}`, 'success');
    } else {
      handleUpdateRecord('ank', idx, 'd', res.ank4.join(', '));
      handleUpdateRecord('ank', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 MILAN 4-ANK', `${marketName}: Pyramid Apex (${res.openApex}, ${res.closeApex}) ➔ 4 Ank: ${res.ank4.join(', ')}`, 'success');
    }
    return true;
  };

  const handleApplyMadhurTotal = async (idx: number, marketName: string) => {
    const isJodi = activeTab === 'jodi';
    const isPast = currentDate < titanLocalDateISO();
    const baseName = marketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim();

    let refJodi = findReferenceJodiForMarket({
      profile: currentProfile,
      currentDate,
      baseMarketName: baseName,
      fallbackIndex: idx,
    })?.refJodi;

    // Fetch chart from server with strict date cutoff
    if (!refJodi) {
      try {
        const json = await postScrape({
          market: baseName,
          type: 'ank',
          isCombo: false,
          targetDate: currentDate,
          backtest: isPast,
          scrapeUrl: getMarketScrapeUrl(baseName),
        }, true);

        const cand = json?.lastJodi || json?.markovMeta?.lastJodi || json?.ranked?.jodi?.[0];
        if (cand && /^\d{2}$/.test(cand)) {
          refJodi = cand;
        }
      } catch (_) {}
    }

    if (!refJodi) {
      const input = window.prompt(`${marketName}: Pichli Jodi darj karein (e.g. 58 ya 83):`, '58');
      if (!input) return false;
      refJodi = input.trim();
    }

    const res = calculateMadhurJodiTotal4Ank(refJodi);
    if (!res) {
      showToast('⚠️ Calculation Error', 'Valid 2-digit Jodi chahiye', 'danger');
      return false;
    }

    if (isJodi) {
      handleUpdateRecord('jodi', idx, 'd', res.jodis16.join(', '));
      handleUpdateRecord('jodi', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 MADHUR 16 JODI', `${marketName}: Last ${res.refJodi} (Total ${res.total}) ➔ 16 Jodis!`, 'success');
    } else {
      handleUpdateRecord('ank', idx, 'd', res.ank4.join(', '));
      handleUpdateRecord('ank', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 MADHUR 4-ANK', `${marketName}: Last ${res.refJodi} (Total ${res.total}) ➔ 4 Ank: ${res.ank4.join(', ')}`, 'success');
    }
    return true;
  };

  const handleApplyTimeBazarRoot = async (idx: number, marketName: string) => {
    const isJodi = activeTab === 'jodi';
    const isPast = currentDate < titanLocalDateISO();
    const baseName = marketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim();

    let openPatti: string | undefined;
    let closePatti: string | undefined;
    let jodiVal: string | undefined;

    // 1. Try local profile memory from prior dates
    const sortedDates = Object.keys(currentProfile?.dayRecords || {})
      .filter((d) => d < currentDate && /^\d{4}-\d{2}-\d{2}$/.test(d))
      .sort((a, b) => b.localeCompare(a));

    const pannelMarkets = getEffectiveMarkets(currentProfile?.config || getDefaultConfig());
    const openPName = `${baseName} OPEN`;
    const closePName = `${baseName} CLOSE`;
    const openPIdx = findMarketIndexByName(pannelMarkets, openPName);
    const closePIdx = findMarketIndexByName(pannelMarkets, closePName);

    for (const d of sortedDates) {
      const pStore = currentProfile?.dayRecords?.[d]?.pannelData;
      const jStore = currentProfile?.dayRecords?.[d]?.jodiData;
      const op = pStore?.[openPIdx]?.manualResult || pStore?.[openPIdx]?.backtestResult?.actual?.open;
      const cp = pStore?.[closePIdx]?.manualResult || pStore?.[closePIdx]?.backtestResult?.actual?.close;
      const jd = jStore?.[idx]?.manualResult || jStore?.[idx]?.backtestResult?.actual?.jodi;
      if (op && cp && jd && /^\d{3}$/.test(op) && /^\d{3}$/.test(cp) && /^\d{2}$/.test(jd)) {
        openPatti = op;
        closePatti = cp;
        jodiVal = jd;
        break;
      }
    }

    // 2. Fetch chart from server with strict date cutoff
    if (!openPatti || !closePatti || !jodiVal) {
      try {
        const json = await postScrape({
          market: baseName,
          type: 'ank',
          isCombo: false,
          targetDate: currentDate,
          backtest: isPast,
          scrapeUrl: getMarketScrapeUrl(baseName),
        }, true);

        if (json?.lastOpenPanel && json?.lastClosePanel && json?.lastJodi) {
          openPatti = String(json.lastOpenPanel);
          closePatti = String(json.lastClosePanel);
          jodiVal = String(json.lastJodi);
        }
      } catch (_) {}
    }

    // 3. Fallback to reference Jodi or prompt if chart has missing fields
    if (!openPatti || !closePatti || !jodiVal) {
      const refJodi = findReferenceJodiForMarket({
        profile: currentProfile,
        currentDate,
        baseMarketName: baseName,
        fallbackIndex: idx,
      })?.refJodi;

      if (refJodi && /^\d{2}$/.test(refJodi)) {
        jodiVal = refJodi;
      } else {
        const input = window.prompt(`${marketName}: Pichle Open Panna, Jodi aur Close Panna darj karein (ya sirf Jodi jaise 96):`, '374, 96, 259');
        if (!input) return false;
        const parts = input.split(/[,|\s]+/).map(t => t.trim()).filter(Boolean);
        if (parts.length >= 3) {
          openPatti = parts[0];
          jodiVal = parts[1];
          closePatti = parts[2];
        } else if (parts.length === 1 && /^\d{2}$/.test(parts[0])) {
          jodiVal = parts[0];
        }
      }
    }

    if (!jodiVal && (!openPatti || !closePatti)) {
      showToast('⚠️ Data Required', `${marketName}: Open Panna, Jodi aur Close Panna nahi mile`, 'warning');
      return false;
    }

    const res = (openPatti && closePatti && jodiVal)
      ? calculateTimeBazarDigitalRoot(openPatti, jodiVal, closePatti)
      : calculateTimeBazarDigitalRoot(jodiVal);
    if (!res) {
      showToast('⚠️ Calculation Error', 'Valid Panna (3-digit) aur Jodi (2-digit) chahiye', 'danger');
      return false;
    }

    if (isJodi) {
      handleUpdateRecord('jodi', idx, 'd', res.jodis16.join(', '));
      handleUpdateRecord('jodi', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 TIME BAZAR 16 JODI', `${marketName}: |${res.openPatti}-${res.closePatti}|+${res.jodi} (Root ${res.root}) ➔ 16 Jodis!`, 'success');
    } else {
      handleUpdateRecord('ank', idx, 'd', res.ank4.join(', '));
      handleUpdateRecord('ank', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 TIME BAZAR 4-ANK', `${marketName}: Root ${res.root} ➔ 4 Ank: ${res.ank4.join(', ')}`, 'success');
    }
    return true;
  };

  const handleApplySrideviMasterFormula = async (idx: number, marketName: string) => {
    const isJodi = activeTab === 'jodi';
    const isClose = /CLOSE/i.test(marketName);
    const isPast = currentDate < titanLocalDateISO();
    const baseName = marketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim();

    // 1. If CLOSE side: Check today's OPEN result first!
    if (!isJodi && isClose) {
      let todayOpenDigit: string | undefined = undefined;
      const dayStore = currentProfile.dayRecords[currentDate] || {};
      const ankMarkets = getEffectiveMarkets(currentProfile.config || getDefaultConfig());
      const openMName = `${baseName} OPEN`;
      const openIdx = findMarketIndexByName(ankMarkets, openMName);
      if (openIdx >= 0) {
        const openRec = dayStore.data?.[openIdx];
        const winDigit = openRec?.manualResult || openRec?.scrapeResultDigit || openRec?.backtestResult?.actual?.open || (openRec?.backtestResult?.actual && /^\d$/.test(openRec.backtestResult.actual) ? openRec.backtestResult.actual : undefined);
        if (winDigit && /^\d$/.test(winDigit)) {
          todayOpenDigit = winDigit;
        } else if (openRec?.d && /^\d/.test(openRec.d.trim())) {
          todayOpenDigit = openRec.d.trim()[0];
        }
      }

      if (!todayOpenDigit) {
        try {
          const json = await postScrape({
            market: `${baseName} OPEN`,
            type: 'ank',
            isCombo: false,
            targetDate: currentDate,
            backtest: isPast,
            scrapeUrl: getMarketScrapeUrl(`${baseName} OPEN`),
          }, true);
          const act = json?.actual?.open || json?.open;
          if (act && /^\d$/.test(String(act).trim())) todayOpenDigit = String(act).trim();
        } catch (_) {}
      }

      if (!todayOpenDigit) {
        const input = window.prompt(`${marketName}: Aaj ka khula hua SRIDEVI OPEN digit darj karein (e.g. 7 ya 5):`, '7');
        if (!input) return false;
        todayOpenDigit = input.trim().slice(0, 1);
      }

      const res = calculateSrideviMasterFormula({
        isClose: true,
        todayOpenDigit,
      });

      handleUpdateRecord('ank', idx, 'd', res.ank6.join(', '));
      handleUpdateRecord('ank', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 SRIDEVI MASTER CLOSE', `${marketName}: Open ${todayOpenDigit} Lock ➔ 6-Ank: ${res.ank6.join(', ')} (63.7% Pass Rate)`, 'success');
      return true;
    }

    // 2. If OPEN side: Find previous draw's Close Panna
    let prevClosePanna: string | undefined = undefined;
    let refJodi: string | undefined = undefined;

    const sortedDates = Object.keys(currentProfile?.dayRecords || {})
      .filter((d) => d < currentDate && /^\d{4}-\d{2}-\d{2}$/.test(d))
      .sort((a, b) => b.localeCompare(a));

    const pannelMarkets = getEffectiveMarkets(currentProfile?.config || getDefaultConfig());
    const closePName = `${baseName} CLOSE`;
    const closePIdx = findMarketIndexByName(pannelMarkets, closePName);

    for (const d of sortedDates) {
      const pStore = currentProfile?.dayRecords?.[d]?.pannelData;
      if (pStore && closePIdx >= 0) {
        const cp = pStore[closePIdx]?.manualResult || pStore[closePIdx]?.backtestResult?.actual?.close;
        if (cp && /^\d{3}$/.test(cp)) {
          prevClosePanna = cp;
          break;
        }
      }
    }

    if (!prevClosePanna) {
      try {
        const json = await postScrape({
          market: baseName,
          type: 'ank',
          isCombo: false,
          targetDate: currentDate,
          backtest: isPast,
          scrapeUrl: getMarketScrapeUrl(baseName),
        }, true);

        if (json?.lastClosePanel && /^\d{3}$/.test(String(json.lastClosePanel))) {
          prevClosePanna = String(json.lastClosePanel);
        }
        if (json?.lastJodi && /^\d{2}$/.test(String(json.lastJodi))) {
          refJodi = String(json.lastJodi);
        }
      } catch (_) {}
    }

    if (!prevClosePanna && !refJodi) {
      const input = window.prompt(`${marketName}: Pichle draw ka Close Panna darj karein (e.g. 667, 489, ya 157):`, '667');
      if (!input) return false;
      const clean = input.replace(/\D/g, '');
      if (clean.length >= 3) prevClosePanna = clean.slice(0, 3);
      else if (clean.length === 2) refJodi = clean;
    }

    const res = calculateSrideviMasterFormula({
      isClose: false,
      prevClosePanna,
      refJodi,
    });

    if (isJodi) {
      handleUpdateRecord('jodi', idx, 'd', res.jodis16.join(', '));
      handleUpdateRecord('jodi', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 SRIDEVI MASTER 16 JODI', `${marketName}: 16 Master Jodis applied!`, 'success');
    } else {
      handleUpdateRecord('ank', idx, 'd', res.ank6.join(', '));
      handleUpdateRecord('ank', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('🎯 SRIDEVI MASTER OPEN', `${marketName}: ${res.sourceDescription} ➔ 6-Ank: ${res.ank6.join(', ')} (65.9% Pass Rate)`, 'success');
    }
    return true;
  };


  const handleApplySrideviHeadSum = async (idx: number, marketName: string) => {
    const isJodi = activeTab === 'jodi';
    const isPast = currentDate < titanLocalDateISO();
    const baseName = marketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim();

    let openPatti: string | undefined;
    let closePatti: string | undefined;

    // 1. Try local profile memory from prior dates
    const sortedDates = Object.keys(currentProfile?.dayRecords || {})
      .filter((d) => d < currentDate && /^\d{4}-\d{2}-\d{2}$/.test(d))
      .sort((a, b) => b.localeCompare(a));

    const pannelMarkets = getEffectiveMarkets(currentProfile?.config || getDefaultConfig());
    const openPName = `${baseName} OPEN`;
    const closePName = `${baseName} CLOSE`;
    const openPIdx = findMarketIndexByName(pannelMarkets, openPName);
    const closePIdx = findMarketIndexByName(pannelMarkets, closePName);

    for (const d of sortedDates) {
      const pStore = currentProfile?.dayRecords?.[d]?.pannelData;
      if (!pStore) continue;
      const op = pStore[openPIdx]?.manualResult || pStore[openPIdx]?.backtestResult?.actual?.open;
      const cp = pStore[closePIdx]?.manualResult || pStore[closePIdx]?.backtestResult?.actual?.close;
      if (op && cp && /^\d{3}$/.test(op) && /^\d{3}$/.test(cp)) {
        openPatti = op;
        closePatti = cp;
        break;
      }
    }

    // 2. Fetch chart from server with strict date cutoff
    if (!openPatti || !closePatti) {
      try {
        const json = await postScrape({
          market: baseName,
          type: 'ank',
          isCombo: false,
          targetDate: currentDate,
          backtest: isPast,
          scrapeUrl: getMarketScrapeUrl(baseName),
        }, true);

        if (json?.lastOpenPanel && json?.lastClosePanel) {
          openPatti = String(json.lastOpenPanel);
          closePatti = String(json.lastClosePanel);
        }
      } catch (_) {}
    }

    // 3. Fallback to prompt if chart has no panna data
    if (!openPatti || !closePatti) {
      const input = window.prompt(`${marketName}: Pichle Open & Close Panna ke 1st digits darj karein (e.g. 3, 2):`, '3, 2');
      if (!input) return false;
      const parts = input.split(/[,|\s]+/).map(t => t.trim()).filter(Boolean);
      if (parts.length >= 2) {
        openPatti = parts[0];
        closePatti = parts[1];
      }
    }

    if (!openPatti || !closePatti) {
      showToast('⚠️ Panna Required', `${marketName}: Open aur Close Panna ke digits nahi mile`, 'warning');
      return false;
    }

    const res = calculateSrideviPattiHeadSum(openPatti, closePatti);
    if (!res) {
      showToast('⚠️ Calculation Error', 'Valid Panna digits chahiye (0-9)', 'danger');
      return false;
    }

    if (isJodi) {
      handleUpdateRecord('jodi', idx, 'd', res.jodis16.join(', '));
      handleUpdateRecord('jodi', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('👑 SRIDEVI 16 JODI', `${marketName}: Heads (${res.p1} + ${res.p2} = ${res.sum}) ➔ 16 Jodis applied!`, 'success');
    } else {
      handleUpdateRecord('ank', idx, 'd', res.ank4.join(', '));
      handleUpdateRecord('ank', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      showToast('👑 SRIDEVI HEAD SUM', `${marketName}: Heads (${res.p1} + ${res.p2} = ${res.sum}) ➔ 4 Ank: ${res.ank4.join(', ')}`, 'success');
    }
    return true;
  };

  const handleApply32JodiOnly = async (idx: number, marketName: string) => {
    let ref = findReferenceJodiForMarket({
      profile: currentProfile,
      currentDate,
      baseMarketName: marketName,
      fallbackIndex: idx,
    });
    let refJodi = ref?.refJodi;
    const isPast = currentDate < titanLocalDateISO();

    if (!refJodi) {
      try {
        const json = await postScrape({
          market: marketName,
          type: 'jodi',
          isCombo: false,
          targetDate: currentDate,
          backtest: isPast,
          scrapeUrl: getMarketScrapeUrl(marketName),
        }, true);
        const cand = json?.lastJodi || json?.markovMeta?.lastJodi || json?.ranked?.jodi?.[0];
        if (cand && /^\d{2}$/.test(cand)) refJodi = cand;
      } catch (_) {}
    }

    if (!refJodi) {
      try {
        const json = await postScrape({
          market: `${marketName} OPEN`,
          type: 'ank',
          isCombo: false,
          targetDate: currentDate,
          backtest: isPast,
          scrapeUrl: getMarketScrapeUrl(`${marketName} OPEN`),
        }, true);
        const cand = json?.lastJodi || json?.markovMeta?.lastJodi;
        if (cand && /^\d{2}$/.test(cand)) refJodi = cand;
      } catch (_) {}
    }

    if (!refJodi) {
      const input = window.prompt(`${marketName}: Pichli Jodi (reference Jodi) darj karein (e.g. 87, 85, 11):`, '87');
      if (!input) return false;
      refJodi = input.trim();
    }

    const result = generateLifetime32JodiOnly(refJodi);
    if (!result) {
      showToast('⚠️ Invalid Jodi', 'Kripya valid 2-digit Jodi darj karein (e.g. 87, 85, 11)', 'warning');
      return false;
    }

    handleUpdateRecord('jodi', idx, 'd', result.jodis.join(', '));
    handleUpdateRecord('jodi', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
    showToast(
      '🎯 32 Jodi Ready',
      `${marketName}: Last ${refJodi} ➔ 32 Jodis (6 digits cross)`,
      'success'
    );
    return true;
  };

  const handleBulk32JodiOnly = async () => {
    if (!isMasterApp || bulkAction) return;
    const cfg = currentProfile.config || getDefaultConfig();
    const markets = getEffectiveBaseMarkets(cfg);
    const dayStore = currentProfile.dayRecords[currentDate] || {};
    const jodiRecords = dayStore.jodiData || {};
    const visible = dayStore.visJodi;
    const isPast = currentDate < titanLocalDateISO();
    let updated = 0;
    let missing = 0;

    setBulkAction('jodi:32-only');
    for (let idx = 0; idx < markets.length; idx++) {
      const market = markets[idx];
      const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(market.n, market.hr) : isNightMarket(market.n, market.hr);
      if (!inScope) continue;
      const record = jodiRecords[idx];
      const frozen = Boolean(
        record?.sentRate || record?.sentDigits || record?.dispatchState === 'SENT' ||
        record?.dispatchState === 'SETTLED' || record?.s === 'PASS' || record?.s === 'FAIL'
      );
      if (frozen || !isMarketEnabledForDate(cfg, visible, market.n, currentDate)) continue;

      let refJodi = findReferenceJodiForMarket({
        profile: currentProfile,
        currentDate,
        baseMarketName: market.n,
        fallbackIndex: idx,
      })?.refJodi;

      if (!refJodi) {
        try {
          const json = await postScrape({
            market: market.n,
            type: 'jodi',
            isCombo: false,
            targetDate: currentDate,
            backtest: isPast,
            scrapeUrl: getMarketScrapeUrl(market.n),
          }, true);
          const cand = json?.lastJodi || json?.markovMeta?.lastJodi || json?.ranked?.jodi?.[0];
          if (cand && /^\d{2}$/.test(cand)) refJodi = cand;
        } catch (_) {}
      }

      if (!refJodi) {
        try {
          const json = await postScrape({
            market: `${market.n} OPEN`,
            type: 'ank',
            isCombo: false,
            targetDate: currentDate,
            backtest: isPast,
            scrapeUrl: getMarketScrapeUrl(`${market.n} OPEN`),
          }, true);
          const cand = json?.lastJodi || json?.markovMeta?.lastJodi;
          if (cand && /^\d{2}$/.test(cand)) refJodi = cand;
        } catch (_) {}
      }

      if (!refJodi) {
        missing++;
        continue;
      }

      const res = generateLifetime32JodiOnly(refJodi);
      if (!res) {
        missing++;
        continue;
      }

      handleUpdateRecord('jodi', idx, 'd', res.jodis.join(', '));
      handleUpdateRecord('jodi', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      updated++;
    }
    setBulkAction(null);
    showToast(
      updated ? '🎯 32 Jodi Bulk Ready' : 'ℹ️ Reference Missing',
      `${updated} markets me exactly 32 Jodis set ho gayi${missing ? ` · ${missing} skipped` : ''}`,
      updated ? 'success' : 'info'
    );
  };

  const handleApplyLifetimeJodiFormula = async (idx: number, marketName: string) => {
    let ref = findReferenceJodiForMarket({
      profile: currentProfile,
      currentDate,
      baseMarketName: marketName,
      fallbackIndex: idx,
    });
    let refJodi = ref?.refJodi;

    const isPast = currentDate < titanLocalDateISO();

    // 1. Try scraping base market with strict date cutoff
    if (!refJodi) {
      try {
        const json = await postScrape({
          market: marketName,
          type: 'jodi',
          isCombo: false,
          targetDate: currentDate,
          backtest: isPast,
          scrapeUrl: getMarketScrapeUrl(marketName),
        }, true);
        const cand = json?.lastJodi || json?.markovMeta?.lastJodi || json?.ranked?.jodi?.[0];
        if (cand && /^\d{2}$/.test(cand)) {
          refJodi = cand;
        }
      } catch (_) {}
    }

    // 2. Fallback: try OPEN side chart with strict date cutoff
    if (!refJodi) {
      try {
        const json = await postScrape({
          market: `${marketName} OPEN`,
          type: 'ank',
          isCombo: false,
          targetDate: currentDate,
          backtest: isPast,
          scrapeUrl: getMarketScrapeUrl(`${marketName} OPEN`),
        }, true);
        const cand = json?.lastJodi || json?.markovMeta?.lastJodi;
        if (cand && /^\d{2}$/.test(cand)) {
          refJodi = cand;
        }
      } catch (_) {}
    }

    // 3. Fallback: ask user only if no chart history exists at all
    if (!refJodi) {
      const input = window.prompt(`${marketName}: Pichli Jodi (reference Jodi) darj karein (e.g. 87, 85, 11):`, '87');
      if (!input) return false;
      refJodi = input.trim();
    }

    const result = generateLifetimeJodi(refJodi);
    if (!result) {
      showToast('⚠️ Invalid Jodi', 'Kripya valid 2-digit Jodi darj karein (e.g. 87, 85, 11)', 'warning');
      return false;
    }

    handleUpdateRecord('jodi', idx, 'd', result.jodis.join(', '));
    handleUpdateRecord('jodi', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
    showToast(
      '⚡ 16/24/32 Formula Applied',
      `${marketName}: Last ${refJodi} (Farak ${result.farak}) ➔ ${result.group} Jodis!`,
      'success'
    );
    return true;
  };

  const handleBulkLifetimeJodiFormula = async () => {
    if (!isMasterApp || bulkAction) return;
    const cfg = currentProfile.config || getDefaultConfig();
    const markets = getEffectiveBaseMarkets(cfg);
    const dayStore = currentProfile.dayRecords[currentDate] || {};
    const jodiRecords = dayStore.jodiData || {};
    const visible = dayStore.visJodi;
    const isPast = currentDate < titanLocalDateISO();
    let updated = 0;
    let missing = 0;

    setBulkAction('jodi:lifetime-formula');
    for (let idx = 0; idx < markets.length; idx++) {
      const market = markets[idx];
      const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(market.n, market.hr) : isNightMarket(market.n, market.hr);
      if (!inScope) continue;
      const record = jodiRecords[idx];
      const frozen = Boolean(
        record?.sentRate || record?.sentDigits || record?.dispatchState === 'SENT' ||
        record?.dispatchState === 'SETTLED' || record?.s === 'PASS' || record?.s === 'FAIL'
      );
      if (frozen || !isMarketEnabledForDate(cfg, visible, market.n, currentDate)) continue;

      let refJodi = findReferenceJodiForMarket({
        profile: currentProfile,
        currentDate,
        baseMarketName: market.n,
        fallbackIndex: idx,
      })?.refJodi;

      if (!refJodi) {
        try {
          const json = await postScrape({
            market: market.n,
            type: 'jodi',
            isCombo: false,
            targetDate: currentDate,
            backtest: isPast,
            scrapeUrl: getMarketScrapeUrl(market.n),
          }, true);
          const cand = json?.lastJodi || json?.markovMeta?.lastJodi || json?.ranked?.jodi?.[0];
          if (cand && /^\d{2}$/.test(cand)) {
            refJodi = cand;
          }
        } catch (_) {}
      }

      if (!refJodi) {
        try {
          const json = await postScrape({
            market: `${market.n} OPEN`,
            type: 'ank',
            isCombo: false,
            targetDate: currentDate,
            backtest: isPast,
            scrapeUrl: getMarketScrapeUrl(`${market.n} OPEN`),
          }, true);
          const cand = json?.lastJodi || json?.markovMeta?.lastJodi;
          if (cand && /^\d{2}$/.test(cand)) {
            refJodi = cand;
          }
        } catch (_) {}
      }

      if (!refJodi) {
        missing++;
        continue;
      }

      const res = generateLifetimeJodi(refJodi);
      if (!res) {
        missing++;
        continue;
      }

      handleUpdateRecord('jodi', idx, 'd', res.jodis.join(', '));
      handleUpdateRecord('jodi', idx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
      updated++;
    }
    setBulkAction(null);
    showToast(
      updated ? '⚡ 16/24/32 Bulk Ready' : 'ℹ️ Reference Missing',
      `${updated} Jodi cards updated${missing ? ` · ${missing} skipped (no prior record)` : ''}`,
      updated ? 'success' : 'info'
    );
  };

  const handleTransferJodiToAnk = (idx: number, marketName: string) => {
    const dayStore = currentProfile.dayRecords[currentDate] || {};
    const jodiRecord = dayStore.jodiData?.[idx];
    const rawDigits = String(jodiRecord?.d || '').trim();
    const jodis = rawDigits.split(/[,|\s]+/).map(t => t.trim()).filter(t => /^\d{2}$/.test(t));

    if (!jodis.length) {
      showToast('ℹ️ Jodi Khali Hai', `${marketName}: Pehle is card me Jodis enter karein ya 16/24/32 formula lagayein`, 'info');
      return false;
    }

    const openDigits = Array.from(new Set(jodis.map(j => j[0]))).sort((a, b) => Number(a) - Number(b));
    const closeDigits = Array.from(new Set(jodis.map(j => j[1]))).sort((a, b) => Number(a) - Number(b));

    const baseName = String(marketName || '').replace(/\s+(OPEN|CLOSE)$/i, '').trim();
    const ankMarkets = getEffectiveMarkets(currentProfile.config || getDefaultConfig());
    const openName = `${baseName} OPEN`;
    const closeName = `${baseName} CLOSE`;
    const openIdx = findMarketIndexByName(ankMarkets, openName);
    const closeIdx = findMarketIndexByName(ankMarkets, closeName);

    let count = 0;
    if (openIdx >= 0) {
      const openRec = dayStore.data?.[openIdx];
      const openFrozen = Boolean(openRec?.sentRate || openRec?.sentDigits || openRec?.dispatchState === 'SENT' || openRec?.dispatchState === 'SETTLED' || openRec?.s === 'PASS' || openRec?.s === 'FAIL');
      if (!openFrozen) {
        handleUpdateRecord('ank', openIdx, 'd', openDigits.join(', '));
        handleUpdateRecord('ank', openIdx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
        count++;
      }
    }

    if (closeIdx >= 0) {
      const closeRec = dayStore.data?.[closeIdx];
      const closeFrozen = Boolean(closeRec?.sentRate || closeRec?.sentDigits || closeRec?.dispatchState === 'SENT' || closeRec?.dispatchState === 'SETTLED' || closeRec?.s === 'PASS' || closeRec?.s === 'FAIL');
      if (!closeFrozen) {
        handleUpdateRecord('ank', closeIdx, 'd', closeDigits.join(', '));
        handleUpdateRecord('ank', closeIdx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
        count++;
      }
    }

    if (count > 0) {
      showToast(
        '📤 ANK Me Transfer Done',
        `${baseName}: OPEN [${openDigits.join(',')}] (${openDigits.length}D) aur CLOSE [${closeDigits.join(',')}] (${closeDigits.length}D) bhej diye gaye!`,
        'success'
      );
      return true;
    } else {
      showToast('⚠️ Cards Frozen', `${baseName}: OPEN aur CLOSE dono cards already sent ya settled hain`, 'warning');
      return false;
    }
  };

  const handleBulkJodiToAnk = () => {
    if (!isMasterApp || bulkAction) return;
    const cfg = currentProfile.config || getDefaultConfig();
    const markets = getEffectiveBaseMarkets(cfg);
    const dayStore = currentProfile.dayRecords[currentDate] || {};
    const jodiRecords = dayStore.jodiData || {};
    const visible = dayStore.visJodi;
    const ankMarkets = getEffectiveMarkets(cfg);
    let updatedMarkets = 0;
    let skipped = 0;

    setBulkAction('jodi:to-ank');
    for (let idx = 0; idx < markets.length; idx++) {
      const market = markets[idx];
      const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(market.n, market.hr) : isNightMarket(market.n, market.hr);
      if (!inScope) continue;
      const record = jodiRecords[idx];
      if (!isMarketEnabledForDate(cfg, visible, market.n, currentDate)) continue;

      const rawDigits = String(record?.d || '').trim();
      const jodis = rawDigits.split(/[,|\s]+/).map(t => t.trim()).filter(t => /^\d{2}$/.test(t));
      if (!jodis.length) {
        skipped++;
        continue;
      }

      const openDigits = Array.from(new Set(jodis.map(j => j[0]))).sort((a, b) => Number(a) - Number(b));
      const closeDigits = Array.from(new Set(jodis.map(j => j[1]))).sort((a, b) => Number(a) - Number(b));

      const baseName = String(market.n || '').replace(/\s+(OPEN|CLOSE)$/i, '').trim();
      const openName = `${baseName} OPEN`;
      const closeName = `${baseName} CLOSE`;
      const openIdx = findMarketIndexByName(ankMarkets, openName);
      const closeIdx = findMarketIndexByName(ankMarkets, closeName);

      let didUpdate = false;
      if (openIdx >= 0) {
        const openRec = dayStore.data?.[openIdx];
        const openFrozen = Boolean(openRec?.sentRate || openRec?.sentDigits || openRec?.dispatchState === 'SENT' || openRec?.dispatchState === 'SETTLED' || openRec?.s === 'PASS' || openRec?.s === 'FAIL');
        if (!openFrozen) {
          handleUpdateRecord('ank', openIdx, 'd', openDigits.join(', '));
          handleUpdateRecord('ank', openIdx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
          didUpdate = true;
        }
      }

      if (closeIdx >= 0) {
        const closeRec = dayStore.data?.[closeIdx];
        const closeFrozen = Boolean(closeRec?.sentRate || closeRec?.sentDigits || closeRec?.dispatchState === 'SENT' || closeRec?.dispatchState === 'SETTLED' || closeRec?.s === 'PASS' || closeRec?.s === 'FAIL');
        if (!closeFrozen) {
          handleUpdateRecord('ank', closeIdx, 'd', closeDigits.join(', '));
          handleUpdateRecord('ank', closeIdx, 'sourceMode', 'COMBO' satisfies CardSourceMode);
          didUpdate = true;
        }
      }

      if (didUpdate) {
        updatedMarkets++;
      }
    }
    setBulkAction(null);
    showToast(
      updatedMarkets ? '📤 Jodi → Ank Bulk Done' : 'ℹ️ Jodi Empty',
      `${updatedMarkets} markets ke Open & Close Ank update ho gaye${skipped ? ` · ${skipped} skipped (empty jodi)` : ''}`,
      updatedMarkets ? 'success' : 'info'
    );
  };

  /** One Panel authority: same-session ANK → overdue chart-derived Single Pattis. */
  const applyPanelFromAnk = async (idx: number, marketName: string, notify = true, signal?:AbortSignal, batchId?:string): Promise<boolean> => {
    if (activeIdRef.current !== activeId || currentDateRef.current !== currentDate || bulkRestoreInFlightRef.current) return false;
    const ankDigits = getAnkDigitsForPanel(idx, marketName);
    const scrapeGuard = { ...captureScrapeGuard('pannel', idx, marketName), ankDigits: ankDigits.join(',') };
    if (!ankDigits.length) {
      if (notify) showToast('ℹ️ ANK Required', `${marketName}: pehle same market ka ANK digit bharo`, 'info');
      return false;
    }
    try {
      const json = await postScrape({
        scrapeBatchId:batchId,
        market: marketName,
        type: 'pannel',
        ankDigits,
        isCombo: false,
        selectionMode: 'ank_sum',
        scrapeUrl: getMarketScrapeUrl(marketName),
      },false,signal);
      if(signal?.aborted)return false;
      if (json.status !== 'success') {
        if (notify) showToast('❌ Panel Failed', scrapeErrorMessage(json, 'Chart fetch failed'), 'danger');
        return false;
      }
      // Defense in depth: backend already filters, but the UI revalidates the
      // exact sum rule before any Panel reaches Admin/VIP ledger state.
      const panels = filterPanelsByAnkDigits(json.digits || json.pannel || '', ankDigits);
      if (!panels) {
        if (notify) showToast('⚠️ No Matching Patti', `${marketName}: ANK ${ankDigits.join(',')} sum wali Patti chart me nahi mili`, 'warning');
        return false;
      }
      if (!handleUpdateRecord('pannel', idx, 'd', panels, { scrapeGuard, scrapedSourceMode: 'ANK_SUM' })) return false;
      if (notify) {
        const count = panels.split(/[, ]+/).filter(Boolean).length;
        const strategy = String(json?.panelStrategy?.mode || 'gap').replace('_', ' ').toUpperCase();
        const tested = Number(json?.panelStrategy?.samples || 0);
        const score = Number(json?.panelStrategy?.passPercent || 0);
        showToast(
          '🎯 Adaptive Panel Ready',
          `${marketName}: ${count} Single Pattis · ${strategy}${tested ? ` · backtest ${score}%/${tested}` : ''}`,
          'success',
        );
      }
      return true;
    } catch (_) {
      if (notify) showToast('❌ Panel Failed', 'Server error during ANK-sum Panel selection', 'danger');
      return false;
    }
  };

  const handleBuildPanelFromAnk = async (idx: number, marketName: string) => {
    await applyPanelFromAnk(idx, marketName, true);
  };

  /** Unseen-first, lowest-frequency-only Panel selection from the same ANK card. */
  const applyLowPanelFromAnk = async (idx: number, marketName: string, notify = true, signal?:AbortSignal, batchId?:string): Promise<boolean> => {
    if (activeIdRef.current !== activeId || currentDateRef.current !== currentDate || bulkRestoreInFlightRef.current) return false;
    const ankDigits = getAnkDigitsForPanel(idx, marketName);
    const scrapeGuard = { ...captureScrapeGuard('pannel', idx, marketName), ankDigits: ankDigits.join(',') };
    if (ankDigits.length < 3) {
      if (notify) showToast('ℹ️ Minimum 3 ANK Required', `${marketName}: exact 30 unique Patti ke liye kam se kam 3 ANK digits chahiye`, 'info');
      return false;
    }
    try {
      const json = await postScrape({
        scrapeBatchId:batchId,
        market: marketName,
        type: 'pannel',
        ankDigits,
        isCombo: false,
        selectionMode: 'low_frequency_30',
        scrapeUrl: getMarketScrapeUrl(marketName),
      },false,signal);
      if(signal?.aborted)return false;
      if (json.status !== 'success') {
        if (notify) showToast('❌ Low Panel Failed', scrapeErrorMessage(json, 'Chart fetch failed'), 'danger');
        return false;
      }
      const panels = filterPanelsByAnkDigits(json.digits || json.pannel || '', ankDigits);
      const values = panels.split(/[, ]+/).filter(Boolean);
      if (values.length !== 30 || new Set(values).size !== 30) {
        if (notify) showToast('⚠️ Exact 30 Not Available', `${marketName}: duplicate/wrong-sum Patti fill nahi ki jayegi`, 'warning');
        return false;
      }
      if (!handleUpdateRecord('pannel', idx, 'd', panels, { scrapeGuard, scrapedSourceMode: 'SP_RARE' })) return false;
      if (notify) {
        const meta = json.lowPanelSelection || {};
        showToast(
          '📉 Low Panel 30 Ready',
          `${marketName}: 30 unique · unseen ${Number(meta.unseenSelected || 0)} · weekday ${Number(meta.weekdaySamples || 0)} · jodi-after ${Number(meta.successorSamples || 0)}`,
          'success',
        );
      }
      return true;
    } catch (_) {
      if (notify) showToast('❌ Low Panel Failed', 'Server error during low-frequency Panel selection', 'danger');
      return false;
    }
  };

  const handleBuildLowPanelFromAnk = async (idx: number, marketName: string) => {
    await applyLowPanelFromAnk(idx, marketName, true);
  };

  const applyStrictPanel30 = async (idx: number, marketName: string, notify = true, signal?:AbortSignal, batchId?:string): Promise<'RETAIN' | 'SKIP' | 'ERROR'> => {
    if (activeIdRef.current !== activeId || currentDateRef.current !== currentDate || bulkRestoreInFlightRef.current) return 'ERROR';
    const ankDigits = getAnkDigitsForPanel(idx, marketName);
    if (ankDigits.length !== 6) {
      if (notify) showToast('6 ANK required', `${marketName}: exactly 6 distinct ANK select karein`, 'info');
      return 'ERROR';
    }
    const scrapeGuard = { ...captureScrapeGuard('pannel', idx, marketName), ankDigits: ankDigits.join(',') };
    try {
      const json = await postScrape({scrapeBatchId:batchId,market:marketName,type:'pannel',ankDigits,isCombo:false,
        selectionMode:'recent30_ank5',targetDate:currentDate,scrapeUrl:getMarketScrapeUrl(marketName)},false,signal);
      if(signal?.aborted)return 'ERROR';
      if (json.status !== 'success' || !json.strictPanel30) {
        if (notify) showToast('Strict SP30 failed', scrapeErrorMessage(json, 'Chart unavailable; card unchanged'), 'danger');
        return 'ERROR';
      }
      const meta: StrictPanel30Selection = json.strictPanel30;
      const panels = filterPanelsByAnkDigits(json.digits || '', ankDigits).split(/[, ]+/).filter(Boolean);
      const valid = meta.mode === 'RECENT30_ANK5' && meta.targetDate === currentDate &&
        meta.side === (/CLOSE$/i.test(marketName) ? 'close' : 'open') &&
        JSON.stringify(meta.anks) === JSON.stringify(ankDigits) &&
        (meta.decision === 'SKIP' ? panels.length === 0 && meta.panels.length === 0 :
          meta.decision === 'RETAIN' && panels.length === 30 && new Set(panels).size === 30 &&
          meta.excluded.length === 30 && panels.every(p => !meta.excluded.includes(p)) &&
          ankDigits.every(a => panels.filter(p => String([...p].reduce((sum,d)=>sum+Number(d),0)%10) === a).length === 5));
      if (!valid) throw new Error('Strict 6 × 5 validation failed');
      if (!handleUpdateRecord('pannel', idx, 'd', panels.join(', '), {scrapeGuard,scrapedSourceMode:'SP_SKIP30',strictPanel30:meta})) return 'ERROR';
      if (notify) showToast(meta.decision === 'SKIP' ? 'Strict SP30 · SKIP' : 'Strict SP30 ready', `${marketName}: ${meta.reason}`, meta.decision === 'SKIP' ? 'warning' : 'success');
      return meta.decision;
    } catch (error: any) {
      if (notify) showToast('Strict SP30 failed', error?.message || 'Chart fetch failed; retry', 'danger');
      return 'ERROR';
    }
  };

  const handleBuildStrictPanel30 = async (idx: number, marketName: string) => { await applyStrictPanel30(idx, marketName); };

  const runPanelBulk=async(targets:Array<{market:{n:string};idx:number}>,action:string,task:(target:{market:{n:string};idx:number},signal:AbortSignal,batchId:string)=>Promise<void>)=>{
    if(bulkScrapeRun.current||bulkAction||bulkRestoreInFlightRef.current)return false;
    if(!targets.length){showToast('No eligible Panel cards','Protected, disabled or unavailable cards were skipped.','info');return false;}
    const run={owner:activeId,date:currentDate,id:`panel_${Date.now()}_${Math.random().toString(36).slice(2)}`,controller:new AbortController(),tab:'pannel' as GameType};
    bulkScrapeRun.current=run;setBulkAction(action);
    const ownsRun=()=>bulkScrapeRun.current===run&&!run.controller.signal.aborted&&activeIdRef.current===run.owner&&currentDateRef.current===run.date;
    try{await runConcurrentTasks(targets,3,async target=>{if(ownsRun())await task(target,run.controller.signal,run.id);});return ownsRun();}
    catch(error){if(ownsRun())showToast('Panel bulk failed',error instanceof Error?error.message:'Please retry','warning');return false;}
    finally{if(bulkScrapeRun.current===run){bulkScrapeRun.current=null;setBulkAction(current=>current===action?null:current);}}
  };

  const handleBulkStrictPanel30 = async () => {
    if (!isMasterApp || bulkAction || bulkRestoreInFlightRef.current) return;
    const cfg = currentProfile.config || getDefaultConfig(), day = currentProfile.dayRecords[currentDate] || {};
    const targets = getEffectiveMarkets(cfg).map((market,idx)=>({market,idx,record:day.pannelData?.[idx]})).filter(({market,record})=>{
      const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(market.n, market.hr) : isNightMarket(market.n, market.hr);
      if (!inScope) return false;
      return isMarketEnabledForDate(cfg,day.visPan,market.n,currentDate) && !record?.sentRate && !record?.sentDigits && !record?.dispatchState && record?.s !== 'PASS' && record?.s !== 'FAIL';
    });
    let ready=0,skip=0,error=0;
    const completed=await runPanelBulk(targets,'panel:strict-30',async({market,idx},signal,batchId)=>{
      const result=await applyStrictPanel30(idx,market.n,false,signal,batchId); if(result==='RETAIN')ready++;else if(result==='SKIP')skip++;else error++;
    });
    if(!completed)return;
    showToast('Strict SP30 bulk', `${ready} ready · ${skip} SKIP · ${error} missing ANK/error/stale response`, error ? 'warning' : 'success');
  };

  const handleBulkPanelFromAnk = async () => {
    if (!isMasterApp || bulkAction) return;
    const cfg = currentProfile.config || getDefaultConfig();
    const markets = getEffectiveMarkets(cfg);
    const dayStore = currentProfile.dayRecords[currentDate] || {};
    const records = dayStore.pannelData || {};
    const visible = dayStore.visPan;
    const targets = markets.map((market, idx) => ({ market, idx, record: records[idx] })).filter(({ market, record }) => {
      const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(market.n, market.hr) : isNightMarket(market.n, market.hr);
      if (!inScope) return false;
      const frozen = Boolean(
        record?.sentRate || record?.sentDigits || record?.dispatchState === 'SENT' ||
        record?.dispatchState === 'SETTLED' || record?.dispatchState === 'QUEUED' || String(record?.dispatchState)==='SENDING' || record?.s === 'PASS' || record?.s === 'FAIL'
      );
      return !frozen && isMarketEnabledForDate(cfg, visible, market.n, currentDate);
    });
    let updated = 0;
    let missingOrFailed = 0;
    const completed=await runPanelBulk(targets,'panel:ank-sum',async({market,idx},signal,batchId)=>{
      if(await applyPanelFromAnk(idx,market.n,false,signal,batchId))updated++;else missingOrFailed++;
    });
    if(!completed)return;
    showToast(
      updated ? '✅ Panel Bulk Ready' : 'ℹ️ No Panel Updated',
      `${updated}/${targets.length} cards · ANK missing/no chart match ${missingOrFailed}`,
      updated ? 'success' : 'info',
    );
  };

  const handleBulkLowPanelFromAnk = async () => {
    if (!isMasterApp || bulkAction) return;
    const cfg = currentProfile.config || getDefaultConfig();
    const markets = getEffectiveMarkets(cfg);
    const dayStore = currentProfile.dayRecords[currentDate] || {};
    const records = dayStore.pannelData || {};
    const visible = dayStore.visPan;
    const targets = markets.map((market, idx) => ({ market, idx, record: records[idx] })).filter(({ market, record }) => {
      const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(market.n, market.hr) : isNightMarket(market.n, market.hr);
      if (!inScope) return false;
      const frozen = Boolean(
        record?.sentRate || record?.sentDigits || record?.dispatchState === 'SENT' ||
        record?.dispatchState === 'SETTLED' || record?.dispatchState === 'QUEUED' || String(record?.dispatchState)==='SENDING' || record?.s === 'PASS' || record?.s === 'FAIL'
      );
      return !frozen && isMarketEnabledForDate(cfg, visible, market.n, currentDate);
    });
    let updated = 0;
    let missingOrFailed = 0;
    const completed=await runPanelBulk(targets,'panel:low-30',async({market,idx},signal,batchId)=>{
      if(await applyLowPanelFromAnk(idx,market.n,false,signal,batchId))updated++;else missingOrFailed++;
    });
    if(!completed)return;
    showToast(
      updated ? '✅ Low Panel Bulk Ready' : 'ℹ️ No Low Panel Updated',
      `${updated}/${targets.length} cards · ANK missing/chart failed ${missingOrFailed}`,
      updated ? 'success' : 'info',
    );
  };

  /**
   * Apply one scraper mode to every enabled card on the current tab.
   * Six distinct charts can scrape together; preserve each card's own
   * request mode/date and commit through the existing functional state updates.
   */
  const handleBulkScrape = async (
    mode: BulkScrapeMode,
    type: GameType,
    retryGuards?:ScrapeCommitGuard[],
  ) => {
    if (!isMasterApp || bulkAction || bulkScrapeRun.current || bulkRestoreInFlightRef.current || type !== 'ank') return;

    const profile=appStateRef.current.profiles[activeId];if(!profile)return;
    const cfg = profile.config || getDefaultConfig();
    const list = getEffectiveMarkets(cfg);
    const dictName = 'data';
    const dayStore = profile.dayRecords?.[currentDate] || {};
    const dict = (dayStore[dictName] || {}) as Record<number, DayMarketRecord>;
    const visDict = dayStore.visAnk;
    const targets = list
      .map((m, idx) => ({ m, idx, rec: dict[idx] }))
      .filter(({ m, idx, rec }) => {
        const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(m.n, m.hr) : isNightMarket(m.n, m.hr);
        if (!inScope) return false;
        const frozen = isSourceScrapeFrozen(rec,currentDate<titanLocalDateISO());
        return !frozen && isMarketEnabledForDate(cfg, visDict, m.n, currentDate)&&(!retryGuards||retryGuards.some(guard=>guard.market===m.n.trim().toUpperCase()&&canCommitScrape(appStateRef.current,guard,type,idx)));
      })
      .map(target => {
        let sourceError:string|undefined;
        const smartSource=(mode==='smart'||mode==='trend_break')?(()=>{try{
          const source=smartSourceForCard(target.idx,target.m.n);
          if(!source.digits)throw new Error('Saved original source missing; pehle chosen source dobara scrape karein. Card unchanged');
          if(mode==='trend_break'&&!target.rec?.d?.trim())throw new Error('Digit box empty; pehle source scrape karein. Card unchanged');
          return source;
        }catch(error:any){sourceError=error?.message||'Source unavailable; card unchanged';return undefined}})():undefined;
        const scrapeGuard=captureScrapeGuard(type,target.idx,target.m.n);
        if(smartSource?.digits){scrapeGuard.sourceMode=smartSource.mode;scrapeGuard.sourceDigits=smartSource.digits;}
        const mssdNextStage = mode === 'mssd' ? getNextMssdStage(target.rec) : 1;
        return {...target,scrapeGuard,smartSource,sourceError,currentDigits:target.rec?.d||'',mssdNextStage};
      });

    if (!targets.length) {
      showToast(
        'ℹ️ No cards',
        'Is tab par koi enabled card nahi mila',
        'info',
      );
      return;
    }

    const modeLabel = mode === 'market_model' ? 'Pair Follow' : mode === 'pair_combo' ? 'Pair Combo' : mode === 'mssd' ? 'MSSD' : mode === 'freq_10' ? '10-Draw Freq (Skip Recent)' : mode === 'freq_10_combo' ? 'Week O+C Freq (7D/6D/5D)' : mode === 'dynamic_4ank' ? '👑 4-Ank Dynamic Brain' : mode === 'open_auto_close_day' ? 'OPEN Auto / CLOSE Day' : mode.replaceAll('_', ' ').toUpperCase();
    const actionKey = `scrape:${mode}`;
    const run={owner:activeId,date:currentDate,id:`batch_${Date.now()}_${Math.random().toString(36).slice(2)}`,controller:new AbortController()};
    bulkScrapeRun.current=run;
    const ownsRun=()=>bulkScrapeRun.current===run&&!run.controller.signal.aborted&&activeIdRef.current===run.owner&&currentDateRef.current===run.date;
    let unchanged=0,trendBreaks=0,trendFollows=0,done=0;
    setBulkScrapeProgress({id:run.id,owner:run.owner,date:run.date,done,total:targets.length});
    let completed=false;
    setBulkScrapeReport(null);
    setBulkAction(actionKey);
    showToast('📡 Bulk Scrape', `${modeLabel} ${targets.length} cards par apply ho raha hai…`, 'info');
    let ok = 0;
    let failed = 0;
    let changed = 0;
    const failureDetails: string[] = [];
    const skipped:Array<{market:string;message:string}>=[];
    const failures:Array<{market:string;message:string;guard:ScrapeCommitGuard}>=[];
    const addFailure=(market:string,message:string,guard:ScrapeCommitGuard)=>{failureDetails.push(`${market}: ${message}`);failures.push({market,message,guard});};
    try {
      const scrapeTarget=async ({ m, idx, rec, scrapeGuard, smartSource, sourceError, currentDigits, mssdNextStage }:typeof targets[number]) => {
        if (!ownsRun()) return;
        try {
          if (!canCommitScrape(appStateRef.current, scrapeGuard, type, idx)) { changed++; return; }
          const isClose = /CLOSE/i.test(m.n);
          const isOpen = /OPEN/i.test(m.n);
          const effectiveMode = mode === 'open_auto_close_day' ? (isClose ? 'weekday' : 'scrape') : mode;
          if((effectiveMode==='smart'||effectiveMode==='trend_break')&&!smartSource){
            skipped.push({market:m.n,message:sourceError||'Saved source unavailable; chosen source dobara scrape karein. Card unchanged'});
            return;
          }
          if (effectiveMode === 'mssd') {
            const nextStage = mssdNextStage || 1;
            const cachedSources = rec?.mssdState?.sources;
            const hasAllCached = Boolean(
              nextStage > 1 &&
              cachedSources?.AUTO &&
              cachedSources?.WEEKDAY &&
              cachedSources?.COMBO &&
              cachedSources?.DAY_COMBO
            );
            const currentProf = appStateRef.current.profiles[run.owner] || appStateRef.current.profiles.admin1;
            let plan: ReturnType<typeof buildMssdFourClickPlan>;
            if (hasAllCached && rec?.mssdState) {
              plan = buildMssdFourClickPlan(cachedSources!, currentProf, run.date, m.n, appStateRef.current.profiles.admin1, rec.mssdState.ssdByMode);
            } else {
              const json = await postScrape({
                scrapeBatchId: run.id,
                market: m.n,
                type,
                isCombo: false,
                selectionMode: 'mssd',
                mssdStage: nextStage,
                targetDate: run.date,
                scrapeUrl: getMarketScrapeUrl(m.n),
              }, false, run.controller.signal);
              if (!ownsRun()) return;
              if (json.status !== 'success' || !json.digits) {
                failed++;
                addFailure(m.n, scrapeErrorMessage(json, 'MSSD chart unavailable'), scrapeGuard);
                return;
              }
              plan = buildMssdFourClickPlan(
                {
                  AUTO: json.sourceDigits?.AUTO || '',
                  WEEKDAY: json.sourceDigits?.WEEKDAY || '',
                  COMBO: json.sourceDigits?.COMBO || '',
                  DAY_COMBO: json.sourceDigits?.DAY_COMBO || '',
                },
                currentProf,
                run.date,
                m.n,
                appStateRef.current.profiles.admin1,
                json.mssd?.ssdByMode,
              );
            }
            const stageDigits = plan.stageDigits[nextStage];
            if (!stageDigits) {
              failed++;
              addFailure(m.n, 'No MSSD digits returned', scrapeGuard);
              return;
            }
            const primarySourceDigits =
              nextStage === 1
                ? plan.sources.AUTO
                : nextStage === 2
                  ? plan.sources.WEEKDAY
                  : nextStage === 3
                    ? plan.sources.COMBO
                    : plan.sources.DAY_COMBO;
            if (!handleUpdateRecord(type, idx, 'd', stageDigits, {
              scrapeGuard,
              scrapedSourceMode: 'MSSD',
              sourceDigits: primarySourceDigits || stageDigits,
              mssdState: {
                stage: nextStage,
                output: stageDigits,
                sources: plan.sources,
                ssdByMode: plan.ssdByMode,
                stageDigits: plan.stageDigits,
              },
            })) {
              changed++;
              return;
            }
            ok++;
            return;
          }
          const body: Record<string, unknown> = {
            scrapeBatchId:run.id,
            market: m.n,
            type,
            isCombo: effectiveMode === 'combo' || effectiveMode === 'day_combo' || (type === 'ank' && !isClose && !isOpen),
            ...(effectiveMode==='trend_break'?{selectionMode:'trend_break',frequencySourceMode:smartSource!.mode,expectedSourceDigits:smartSource!.digits,currentDigits,targetDate:run.date}:{}),
            ...(effectiveMode==='smart'?{selectionMode:'source_frequency',frequencySourceMode:smartSource!.mode,expectedSourceDigits:smartSource!.digits,targetDate:run.date}:{}),
            ...((effectiveMode === 'digit_follow' || effectiveMode === 'panna_follow')
              ? { selectionMode: effectiveMode, targetDate: run.date, isCombo: false }
              : effectiveMode === 'market_model'
              ? { selectionMode: 'pair_follow', targetDate: run.date, isCombo: false }
              : effectiveMode === 'pair_combo'
              ? { selectionMode: 'pair_combo', targetDate: run.date, isCombo: false }
              : effectiveMode === 'freq_10'
              ? { selectionMode: 'freq_10_skip_recent', targetDate: run.date, isCombo: false }
              : effectiveMode === 'freq_10_combo'
              ? { selectionMode: 'freq_10_combo_skip_recent', targetDate: run.date, isCombo: true }
              : effectiveMode === 'dynamic_4ank'
              ? {
                  selectionMode: 'dynamic_4ank',
                  targetDate: run.date,
                  isCombo: false,
                  sameDayOpenDigit: isClose ? (() => {
                    const bName = m.n.replace(/\s+CLOSE$/i, '').trim().toUpperCase();
                    const dMap = appStateRef.current.profiles[run.owner]?.dayRecords?.[run.date]?.data || {};
                    for (const r of Object.values(dMap)) {
                      if (!r) continue;
                      if ((r.marketName || '').trim().toUpperCase() === `${bName} OPEN`) {
                        const act = r.manualStatus ? r.manualResult : (r.backtestResult?.actual || r.scrapeResultDigit);
                        if (act && /^\d$/.test(act)) return act;
                      }
                    }
                    return undefined;
                  })() : undefined,
                }
              : effectiveMode === 'day_combo'
              ? { selectionMode: 'same_weekday_vertical_combo', targetDate: currentDate }
              : effectiveMode === 'weekday'
              ? { selectionMode: 'same_weekday_vertical', targetDate: currentDate }
              : (effectiveMode === 'scrape' || effectiveMode === 'combo') ? historicalScrapeCutoff() : {}),
            scrapeUrl: getMarketScrapeUrl(m.n),
          };
          const json=await postScrape(body,false,run.controller.signal);
          if(!ownsRun())return;
          if (json.status === 'success') {
            const val = effectiveMode === 'weekday'
              ? json.digits
              : effectiveMode === 'combo'
              ? json.digits || json.combined || json.open
              : effectiveMode === 'smart'
                ? json.smartDigits
                : effectiveMode === 'market_model'
                  ? json.digits
                  : json.digits || json.open;
            if (val) {
              const sourceMode: CardSourceMode = (effectiveMode === 'smart'||effectiveMode === 'trend_break') ? smartSource!.mode : effectiveMode === 'market_model' ? 'PAIR_FOLLOW' : effectiveMode === 'pair_combo' ? 'PAIR_COMBO' : effectiveMode === 'freq_10' ? 'FREQ_10' : effectiveMode === 'freq_10_combo' ? 'FREQ_10_COMBO' : effectiveMode === 'dynamic_4ank' ? 'FLOW_3_1' : effectiveMode === 'scrape'
                ? 'AUTO'
                : effectiveMode === 'weekday'
                  ? 'WEEKDAY'
                  : effectiveMode.toUpperCase() as CardSourceMode;
              if ((effectiveMode === 'dynamic_4ank' || effectiveMode === 'freq_10' || effectiveMode === 'freq_10_combo') && json.actual !== undefined && run.date < titanLocalDateISO()) {
                const base = m.n.replace(/\s+(OPEN|CLOSE)$/i, '').trim();
                const url = resolveMarketScrapeUrl(appStateRef.current.profiles[run.owner]?.config, m.n) || '';
                backtestActualCache.current.set(`${run.date}|${base}|${url}`, cacheBacktestActual(json.actual, Date.now(), run.date));
              }
              if (!handleUpdateRecord(type, idx, 'd', String(val || ''), {smartSelection:(effectiveMode==='smart'||effectiveMode==='trend_break')?json.smartSelection:undefined, masterFlow: effectiveMode === 'dynamic_4ank' ? json.masterFlow : undefined, positionRule: effectiveMode === 'dynamic_4ank' ? 'FLOW_3_1' : undefined, scrapeGuard, scrapedSourceMode: sourceMode, sourceDigits: json.sourceDigits?.[sourceMode] || String(val || '') })) { changed++; return; }
              if(effectiveMode==='trend_break'){if(json.trendBreak?.decision==='BREAK')trendBreaks++;if(json.trendBreak?.decision==='FOLLOW')trendFollows++;}
              ok++;
            } else {
              failed++;
              addFailure(m.n,'No digits returned',scrapeGuard);
            }
          } else if((effectiveMode==='trend_break'||effectiveMode==='smart')&&json.status==='unchanged'){
            unchanged++;
            skipped.push({market:m.n,message:json.message||'Analysis unclear; card unchanged'});
          } else {
            failed++;
            addFailure(m.n,scrapeErrorMessage(json,'Chart unavailable'),scrapeGuard);
          }
        } catch (error: any) {
          failed++;
          addFailure(m.n,error?.message||'Request failed',scrapeGuard);
        }finally{
          done++;
          if(ownsRun())setBulkScrapeProgress({id:run.id,owner:run.owner,date:run.date,done,total:targets.length});
        }
      };
      // OPEN/CLOSE share one upstream chart. Spend slots on distinct charts.
      const chartGroups=new Map<string,typeof targets>();
      for(const target of targets){
        const key=JSON.stringify([target.m.n.replace(/\s+(OPEN|CLOSE)$/i,'').trim().toUpperCase(),getMarketScrapeUrl(target.m.n)||'']);
        const group=chartGroups.get(key)||[];group.push(target);chartGroups.set(key,group);
      }
      await runConcurrentTasks([...chartGroups.values()],6,group=>runConcurrentTasks(group,2,scrapeTarget));
      completed=ownsRun();
    } finally {
      setBulkScrapeProgress(progress=>progress?.id===run.id?null:progress);
      if(bulkScrapeRun.current===run){bulkScrapeRun.current=null;setBulkAction(action=>action===actionKey?null:action);}
    }
    if(!completed)return;
    if (ok > 0) {
      try {
        setAppState(prev => {
          const profiles = { ...prev.profiles };
          const prof = profiles[run.owner];
          if (!prof) return prev;
          if (run.date < titanLocalDateISO()) {
            profiles[run.owner] = calculateBacktestRecovery(prof, run.date);
            if (run.owner === 'admin1') {
              for (const pid of Object.keys(profiles)) {
                if (pid !== 'admin1' && vipCopiesAdmin(profiles[pid])) {
                  profiles[pid] = calculateBacktestRecovery(profiles[pid], run.date);
                }
              }
            }
          } else {
            const auto = applyAutoRatesToDayStore(prof, run.date, profiles);
            if (auto) profiles[run.owner] = { ...prof, dayRecords: { ...prof.dayRecords, [run.date]: auto } };
            if (run.owner === 'admin1') {
              for (const pid of Object.keys(profiles)) {
                if (pid !== 'admin1' && vipCopiesAdmin(profiles[pid])) {
                  const vAuto = applyAutoRatesToDayStore(profiles[pid], run.date, profiles);
                  if (vAuto) profiles[pid] = { ...profiles[pid], dayRecords: { ...profiles[pid].dayRecords, [run.date]: vAuto } };
                }
              }
            }
          }
          return { ...prev, profiles };
        });
      } catch (e) {
        console.warn('Recovery calculation warning:', e);
      }
    }
    setBulkScrapeReport({profileId:run.owner,date:run.date,mode,ok,total:targets.length,changed,skipped,failures});
    showToast(
      failed ? ok?'⚠️ Bulk partially completed':'⚠️ Bulk Failed' : ok ? '✅ Bulk Done' : changed ? 'Bulk · cards changed/protected' : mode==='smart'?'Smart · unchanged':'Trend · unchanged',
      `${modeLabel}: ${ok}/${targets.length} cards updated${mode==='trend_break'?` · Follow ${trendFollows} / Break ${trendBreaks}`:''}${failed ? ` · ${failed} failed` : ''}${skipped.length ? ` · ${skipped.length} skipped/unchanged` : ''}${changed ? ` · ${changed} edited/protected during scrape` : ''}${failureDetails.length ? ` · ${failureDetails.slice(0, 3).join(' · ')}` : ''}${skipped.length ? ` · ${skipped[0].message}` : ''}`,
      failed ? 'warning' : ok ? 'success' : 'info',
    );
  };

  const handleBulkOpenCloseMatch = () => {
    if (!isMasterApp || bulkAction || activeTab !== 'ank' || bulkRestoreInFlightRef.current) return;
    const preview = applyOpenCloseMatch(appStateRef.current, activeId, currentDate, bulkMarketScope);
    if (!preview.changedCards) {
      showToast(preview.alreadyCommonPairs ? 'ℹ️ Already Unmatched / Skipped' : 'ℹ️ Unmatched Not Applied', describeOpenCloseMatch(preview), 'info');
      return;
    }
    appStateRef.current = preview.state;
    setAppState(preview.state);
    lastLedgerSyncRef.current = '';
    showToast('✅ OPEN/CLOSE Unmatched', `${preview.changedCards} cards updated (${bulkMarketScope}) · ${preview.emptyPairs} pairs with an empty side after common cuts · protected/unavailable pairs skipped`, 'success');
  };

  const handleBulkOpenCloseUnion = () => {
    if (!isMasterApp || bulkAction || activeTab !== 'ank' || bulkRestoreInFlightRef.current) return;
    const preview = applyOpenCloseUnion(appStateRef.current, activeId, currentDate, bulkMarketScope);
    if (!preview.changedCards) {
      showToast(preview.alreadyMergedPairs ? 'ℹ️ Already Mixed' : 'ℹ️ Mix Not Applied', describeOpenCloseUnion(preview), 'info');
      return;
    }
    appStateRef.current = preview.state;
    setAppState(preview.state);
    lastLedgerSyncRef.current = '';
    showToast('✅ OPEN + CLOSE Mixed', `${preview.changedCards} cards updated (${bulkMarketScope}) · ${preview.mergedPairs} market pairs mixed · e.g. [1,2,3,4] + [3,4,5,6] -> [1,2,3,4,5,6]`, 'success');
  };

  const handleBulkSelfLearning = async () => {
    if (!isMasterApp || bulkAction || selfLearningScanProgress || activeTab !== 'ank' || bulkRestoreInFlightRef.current) return;
    const owner = activeId;
    const date = currentDate;
    const scope = bulkMarketScope;

    // Step 1: Instant baseline pass with market-specific history & tokens + mark eligible cards as SCANNING
    const initialResult = applySelfLearningBulk(appStateRef.current, owner, date, scope);
    if (!initialResult.appliedCount) {
      showToast('ℹ️ No Cards Changed', 'Koi eligible cards nahi mile ya cards already sent/locked hain.', 'info');
      return;
    }

    const profileAfterInit = initialResult.state.profiles[owner] || initialResult.state.profiles.admin1;
    const markets = getEffectiveMarkets(profileAfterInit.config);
    const dayAfterInit = profileAfterInit.dayRecords?.[date] || { data: {} };
    const scanningData = { ...(dayAfterInit.data || {}) };
    const eligibleTargets: Array<{ idx: number; marketName: string }> = [];

    markets.forEach((m, idx) => {
      if (!initialResult.markets.includes(m.n)) return;
      const card = scanningData[idx];
      if (card && card.selfLearning) {
        scanningData[idx] = {
          ...card,
          selfLearning: {
            ...card.selfLearning,
            analysisState: 'SCANNING',
          },
        };
        eligibleTargets.push({ idx, marketName: m.n });
      }
    });

    setAppState({
      ...initialResult.state,
      profiles: {
        ...initialResult.state.profiles,
        [owner]: {
          ...profileAfterInit,
          dayRecords: {
            ...(profileAfterInit.dayRecords || {}),
            [date]: { ...dayAfterInit, data: scanningData },
          },
        },
      },
    });

    setSelfLearningScanProgress({
      done: 0,
      total: eligibleTargets.length,
      currentMarket: eligibleTargets[0]?.marketName || 'Initializing...',
    });
    showToast(
      '🔍 Self-Learning Live Chart Scan',
      `${eligibleTargets.length} markets ke live charts scan ho rahe hain — har market ka alag Rule & 4-Ank nikala ja raha hai…`,
      'info'
    );

    // Step 2: Live per-market chart scrape + Real 10-Digit Source auto-load + 12-Trick Tournament & Live Session Line
    const liveBatchSet = new Set<string>();
    const weights = getStoredLearningState();
    let completedCount = 0;
    let liveChartSuccessCount = 0;
    let cursor = 0;
    const isPastDate = date < titanLocalDateISO();
    const scrapedActualByIdx = new Map<number, string>();

    const scanOneMarket = async (target: { idx: number; marketName: string }) => {
      const { idx, marketName } = target;
      const isClose = /\s+CLOSE$/i.test(marketName);
      const marketBase = marketName.replace(/\s+(OPEN|CLOSE)$/i, '').trim().toUpperCase();

      // Check if today's Open is already declared for Close market
      let sameDayOpenActual: string | null = null;
      if (isClose) {
        const latestProf = appStateRef.current.profiles[owner] || appStateRef.current.profiles.admin1;
        const latestDay = latestProf?.dayRecords?.[date];
        const openIdx = markets.findIndex(mk => mk.n.trim().toUpperCase() === `${marketBase} OPEN`);
        if (openIdx >= 0 && latestDay?.data?.[openIdx]) {
          const actO = extractActualDigit(latestDay.data[openIdx], `${marketBase} OPEN`);
          if (actO && /^\d$/.test(actO)) sameDayOpenActual = actO;
        }
      }

      let scrapedAuto10 = '';
      let recentDatedDraws: Array<{ date: string; jodi: string }> | undefined;
      try {
        const scrapeUrl = getMarketScrapeUrl(marketName);
        const json = await postScrape({
          market: marketName,
          type: 'ank',
          selectionMode: 'self_learning_inductive',
          targetDate: date,
          backtest: isPastDate,
          scrapeUrl,
          sameDayOpenActual,
          usedBatchTetrads: Array.from(liveBatchSet),
        });
        if (json && json.status === 'success') {
          const raw10 = String(json.sourceDigits?.AUTO || json.sourceDigits?.SELF_LEARNING || json.digits || '')
            .split(/[,|\s]+/)
            .filter(t => /^\d$/.test(t));
          if (new Set(raw10).size === 10) {
            scrapedAuto10 = Array.from(new Set(raw10)).join(', ');
          }
          if (Array.isArray(json.recentDatedDraws) && json.recentDatedDraws.length > 0) {
            recentDatedDraws = json.recentDatedDraws;
          }
          if (isPastDate && json.actual) {
            const actSide = actualForGame(json.actual, 'ank', marketName);
            if (actSide && /^\d$/.test(actSide)) {
              scrapedActualByIdx.set(idx, actSide);
            }
          }
          liveChartSuccessCount++;
        }
      } catch {
        // Fallback cleanly to local market-specific rule already on card
      }

      completedCount++;
      setSelfLearningScanProgress({
        done: completedCount,
        total: eligibleTargets.length,
        currentMarket: marketName,
      });

      setAppState(prev => {
        const p = prev.profiles[owner];
        const dStore = p?.dayRecords?.[date];
        const curCard = dStore?.data?.[idx];
        if (!p || !dStore || !curCard || isMirrorProtected(curCard) || curCard.dispatchState === 'SENT' || curCard.dispatchState === 'QUEUED') {
          return prev;
        }

        const seededProfile = seedRecentDatedDrawsIntoProfile(p, marketName, recentDatedDraws, date);
        const cardWithRealSource: DayMarketRecord = scrapedAuto10
          ? {
              ...curCard,
              od: scrapedAuto10,
              scrapeSource: {
                mode: 'SELF_LEARNING',
                digits: scrapedAuto10,
              },
            }
          : curCard;

        const nextDayDataForPredict: Record<number, DayMarketRecord> = {
          ...(dStore.data || {}),
          [idx]: cardWithRealSource,
        };
        const stateForPredict = {
          ...prev,
          profiles: {
            ...prev.profiles,
            [owner]: {
              ...seededProfile,
              dayRecords: {
                ...(seededProfile.dayRecords || {}),
                [date]: { ...dStore, data: nextDayDataForPredict },
              },
            },
          },
        };

        const prediction = predictForMarket(marketName, stateForPredict, owner, date, weights, liveBatchSet);
        const updatedCard = applySelfLearningToCard(cardWithRealSource, prediction, marketName, weights.totalSamples);

        const nextData = { ...(dStore.data || {}), [idx]: updatedCard };
        const nextProfiles: typeof prev.profiles = {
          ...prev.profiles,
          [owner]: {
            ...seededProfile,
            dayRecords: {
              ...(seededProfile.dayRecords || {}),
              [date]: { ...dStore, data: nextData },
            },
          },
        };

        if (owner === 'admin1') {
          for (const [pid, vip] of Object.entries(nextProfiles)) {
            if (pid === 'admin1' || !vipCopiesAdmin(vip)) continue;
            const vipMarkets = getEffectiveMarkets(vip.config);
            const vipIdx = vipMarkets.findIndex(vm => vm.n === marketName);
            if (vipIdx < 0) continue;
            const vipDay = vip.dayRecords?.[date] || {};
            const vipData = { ...(vipDay.data || {}) };
            const oldVipCard = vipData[vipIdx] || { s: 'WAIT' as const, d: '', r: '' };
            if (isMirrorProtected(oldVipCard) || oldVipCard.dispatchState === 'SENT' || oldVipCard.dispatchState === 'QUEUED') continue;
            vipData[vipIdx] = {
              ...oldVipCard,
              d: updatedCard.d,
              od: updatedCard.od,
              scrapeSource: updatedCard.scrapeSource ? { ...updatedCard.scrapeSource } : oldVipCard.scrapeSource,
              sourceMode: 'SELF_LEARNING',
              positionRule: 'SELF_LEARN',
              selfLearning: updatedCard.selfLearning ? { ...updatedCard.selfLearning } : undefined,
              mirroredFromAdmin: true,
              sourceEditedAt: Math.max(Number(updatedCard.sourceEditedAt || 0), Number(oldVipCard.sourceEditedAt || 0) + 1),
            };
            nextProfiles[pid] = {
              ...vip,
              dayRecords: { ...(vip.dayRecords || {}), [date]: { ...vipDay, data: vipData } },
            };
          }
        }

        return { ...prev, profiles: nextProfiles };
      });
    };

    const workerCount = Math.min(4, eligibleTargets.length);
    await Promise.all(
      Array.from({ length: workerCount }, async () => {
        while (cursor < eligibleTargets.length) {
          const target = eligibleTargets[cursor++];
          await scanOneMarket(target);
        }
      })
    );

    // Final chronological pass (`0 .. markets.length - 1`) so that on past dates or live sessions,
    // each card strictly incorporates earlier settled markets (`0 .. idx - 1`) with zero lookahead.
    setAppState(prev => {
      const p = prev.profiles[owner];
      const dStore = p?.dayRecords?.[date];
      if (!p || !dStore?.data) return prev;
      if (isPastDate && scrapedActualByIdx.size > 0) {
        const enrichedData: Record<number, DayMarketRecord> = { ...dStore.data };
        for (const [mIdx, actDig] of scrapedActualByIdx.entries()) {
          if (enrichedData[mIdx]) {
            enrichedData[mIdx] = {
              ...enrichedData[mIdx],
              scrapeResultDigit: actDig,
            };
          }
        }
        const stateWithPriorActuals = {
          ...prev,
          profiles: {
            ...prev.profiles,
            [owner]: {
              ...p,
              dayRecords: {
                ...(p.dayRecords || {}),
                [date]: { ...dStore, data: enrichedData },
              },
            },
          },
        };
        return applySelfLearningBulk(stateWithPriorActuals, owner, date, scope).state;
      }
      return applySelfLearningBulk(prev, owner, date, scope).state;
    });

    setSelfLearningScanProgress(null);
    showToast(
      '🧠 Self-Learning Rules Locked',
      `${eligibleTargets.length} markets analyzed (${liveChartSuccessCount} live chart rules + unique 4-Ank per market locked)!`,
      'success'
    );
  };

  const handleApplyAiDigitsToCard = (marketName: string, digits: string, strategy: string) => {
    const profile = appStateRef.current.profiles[activeId] || appStateRef.current.profiles.admin1;
    const markets = getEffectiveMarkets(profile.config);
    const day = profile.dayRecords?.[currentDate];
    if (!day?.data) return;

    const idx = markets.findIndex(m => m.n.trim().toUpperCase() === marketName.trim().toUpperCase());
    if (idx < 0) return;

    const existingCard = day.data[idx];
    const card: DayMarketRecord = existingCard
      ? { ...existingCard }
      : { s: 'WAIT' as const, d: '', r: '', marketName };

    const updatedCard: DayMarketRecord = {
      ...card,
      d: digits,
      od: card.od || card.d,
      marketName,
      sourceMode: 'SELF_LEARNING',
      positionRule: 'SELF_LEARN',
      s: 'WAIT',
      sourceEditedAt: Date.now(),
      selfLearning: {
        confidence: 85,
        digits,
        strategy: `✨ AI Guru: ${strategy}`,
        sampleCount: 100,
        updatedAt: Date.now(),
      },
    };

    const nextData = { ...day.data, [idx]: updatedCard };
    setAppState(prev => ({
      ...prev,
      profiles: {
        ...prev.profiles,
        [activeId]: {
          ...profile,
          dayRecords: {
            ...profile.dayRecords,
            [currentDate]: { ...day, data: nextData },
          },
        },
      },
    }));
  };

  const handleBulkRemoveFirstFour = (lastFour = false) => {
    const cutSource = lastFour ? removeLastFourSourceIndices : removeFirstFourSourceIndices;
    if (!isMasterApp || bulkAction || activeTab !== 'ank') return;
    const sourceProfile = appStateRef.current.profiles[activeId] || appStateRef.current.profiles.admin1;
    const day = sourceProfile.dayRecords[currentDate] || {};
    const markets = getEffectiveMarkets(sourceProfile.config);
    const eligible = markets.flatMap((market, idx) => {
      const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(market.n, market.hr) : isNightMarket(market.n, market.hr);
      if (!inScope) return [];
      if (!isMarketEnabledForDate(sourceProfile.config, day.visAnk, market.n, currentDate)) return [];
      const next = cutSource(day.data?.[idx]);
      return next ? [{ idx, name: market.n }] : [];
    });
    if (!eligible.length) {
      showToast('ℹ️ No Cards Changed', 'No available source-index targets in editable current digit boxes; protected/empty cards unchanged', 'info');
      return;
    }
    setBulkAction(lastFour ? 'positions:lcut' : 'positions:remove-first-four');
    setAppState(prev => {
      const profiles = { ...prev.profiles };
      const profile = ensureProfileStructure(profiles[activeId] || profiles.admin1, true);
      const profileDay = profile.dayRecords[currentDate] || {};
      const data = { ...(profileDay.data || {}) };
      eligible.forEach(({ idx, name }) => {
        const next = cutSource(data[idx]);
        if (!next) return;
        next.marketName = name.trim().toUpperCase();
        data[idx] = next;
      });
      profile.dayRecords[currentDate] = { ...profileDay, data };
      profiles[activeId] = profile;
      if (activeId === 'admin1') {
        Object.keys(profiles).forEach(pid => {
          if (pid === 'admin1' || !vipCopiesAdmin(profiles[pid])) return;
          const vip = ensureProfileStructure(profiles[pid], true);
          const vipMarkets = getEffectiveMarkets(vip.config);
          const vipDay = vip.dayRecords[currentDate] || {};
          const vipData = { ...(vipDay.data || {}) };
          eligible.forEach(({ idx, name }) => {
            const vipIdx = findMarketIndexByName(vipMarkets, name);
            if (vipIdx < 0) return;
            if (!vipLiveMarketEligible(vip, currentDate, 'ank', name)) return;
            const next = projectAdminSource(vipData[vipIdx], data[idx], name);
            if (next && next !== vipData[vipIdx]) {
              delete next.positionRule;
              delete next.weekdaySelectedDigits;
              delete next.weekdayHitPosition;
              vipData[vipIdx] = next;
            }
          });
          vip.dayRecords[currentDate] = { ...vipDay, data: vipData };
          if (currentDate < titanLocalDateISO()) {
            profiles[pid] = calculateBacktestRecovery(vip, currentDate);
          } else {
            const vipAuto = applyAutoRatesToDayStore(vip, currentDate, profiles);
            if (vipAuto) vip.dayRecords[currentDate] = vipAuto;
            profiles[pid] = vip;
          }
        });
      }
      if (currentDate < titanLocalDateISO()) {
        profiles[activeId] = calculateBacktestRecovery(profiles[activeId], currentDate);
      } else {
        const ownerAuto = applyAutoRatesToDayStore(profiles[activeId], currentDate, profiles);
        if (ownerAuto) profiles[activeId].dayRecords[currentDate] = ownerAuto;
      }
      return { ...prev, profiles };
    });
    lastLedgerSyncRef.current = '';
    setBulkAction(null);
    showToast(lastFour ? 'Lcut applied' : 'Fcut applied', lastFour ? `${eligible.length} cards · source positions 7–10 cut from current box` : `${eligible.length} cards · source positions 1–4 cut from current box`, 'success');
  };

  const handleBulkLiveCombinedCut = async (position: 'first' | 'last' = 'first') => {
    if(!isMasterApp||bulkAction||bulkScrapeRun.current||activeTab!=='ank'||bulkRestoreInFlightRef.current)return;
    const owner=activeId,date=currentDate,profile=appStateRef.current.profiles[owner];
    if(!profile)return;
    const markets=getEffectiveMarkets(profile.config),day=profile.dayRecords[date]||{};
    const tasks=markets.flatMap((market,index)=>{
      const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(market.n, market.hr) : isNightMarket(market.n, market.hr);
      if (!inScope) return [];
      const rec=day.data?.[index];
      if(!isMarketEnabledForDate(profile.config,day.visAnk,market.n,date)||!vipLiveMarketEligible(profile,date,'ank',market.n)||!rec||rec.s!=='WAIT'||rec.manualStatus||rec.sentRate||rec.sentDigits||rec.dispatchState||rec.deliveryRestoredAt||!rec.d)return [];
      if(hasLiveCombinedCut(rec, position))return [];
      return [{market,index,guard:captureScrapeGuard('ank',index,market.n)}];
    });
    if(!tasks.length){showToast('No eligible cards','Scrape editable ANK cards first; sent, settled, SKIP and already-applied cards are protected.','info');return;}
    const actionKey = position === 'last' ? 'positions:live-combined-cut-last' : 'positions:live-combined-cut';
    const run={owner,date,id:`combined_${position}_${Date.now()}_${Math.random().toString(36).slice(2)}`,controller:new AbortController()};
    bulkScrapeRun.current=run;
    const ownsRun=()=>bulkScrapeRun.current===run&&!run.controller.signal.aborted&&activeIdRef.current===owner&&currentDateRef.current===date;
    setBulkAction(actionKey);
    let changed=0,skipped=0,failed=0;
    try{
      await runConcurrentTasks(tasks,3,async task=>{
        if(!ownsRun())return;
        try{
          const common={scrapeBatchId:run.id,market:task.market.n,type:'ank',isCombo:false,targetDate:date,scrapeUrl:getMarketScrapeUrl(task.market.n)};
          const responses=await Promise.allSettled([
            postScrape({...common,selectionMode:'pre_target_recent'},false,run.controller.signal),
            postScrape({...common,selectionMode:'same_weekday_vertical'},false,run.controller.signal),
          ]);
          if(responses.some(r=>r.status==='rejected')){failed++;return;}
          const [auto,daySource]=responses.map(r=>(r as PromiseFulfilledResult<any>).value);
          if([auto,daySource].some(r=>r.status!=='success'||r.staleCache||(r.targetDate&&r.targetDate!==date)||(r.actual?.date&&r.actual.date!==date))){failed++;return;}
          if(!ownsRun()||!canCommitScrape(appStateRef.current,task.guard,'ank',task.index))return;
          const selectTwo=(value:string|undefined)=> {
            const arr = String(value||'').split(/[,|\s]+/).filter(Boolean);
            return position === 'last' ? arr.slice(-2) : arr.slice(0,2);
          };
          const apply=(state:AppState):AppState=>{
            if(run.controller.signal.aborted||activeIdRef.current!==owner||currentDateRef.current!==date||!canCommitScrape(state,task.guard,'ank',task.index))return state;
            const profiles={...state.profiles},p=ensureProfileStructure(profiles[owner], true),store=p.dayRecords[date]||{},data={...store.data};
            const next=applyLiveCombinedCut(data[task.index],{
              auto:selectTwo(auto.sourceDigits?.AUTO||auto.digits),
              day:selectTwo(daySource.sourceDigits?.WEEKDAY||daySource.digits),
              position,
            });
            if(!next||next===data[task.index])return state;
            next.marketName=task.market.n;data[task.index]=next;
            p.dayRecords[date]={...store,data};profiles[owner]=p;
            if(owner==='admin1')for(const pid of Object.keys(profiles)){
              if(pid===owner||!vipCopiesAdmin(profiles[pid]))continue;
              const vip=ensureProfileStructure(profiles[pid], true),vi=findMarketIndexByName(getEffectiveMarkets(vip.config),task.market.n),vd=vip.dayRecords[date]||{};
              if(vi<0||!isMarketEnabledForDate(vip.config,vd.visAnk,task.market.n,date)||!vipLiveMarketEligible(vip,date,'ank',task.market.n)||vd.data?.[vi]?.dispatchState||vd.data?.[vi]?.manualStatus||vd.data?.[vi]?.deliveryRestoredAt)continue;
              const projected=projectAdminSource(vd.data?.[vi],next,task.market.n);
              if(projected&&projected!==vd.data?.[vi]){vip.dayRecords[date]={...vd,data:{...vd.data,[vi]:projected}};profiles[pid]=vip;}
            }
            return {...state,profiles};
          };
          const preview=apply(appStateRef.current);
          if(preview!==appStateRef.current){changed++;if(preview.profiles[owner].dayRecords[date]?.data?.[task.index]?.s==='SKIP')skipped++;setAppState(apply);}
        }catch{failed++;}
      });
      const posLabel = position === 'last' ? 'Last 2 Cut' : 'First 2 Cut';
      if(ownsRun())showToast(`AUTO 2 + DAY 2 (${posLabel}) applied`,`${changed} cards · ${skipped} direct SKIP · ${failed} source requests failed (unchanged)`,failed?'warning':'success');
    }finally{if(bulkScrapeRun.current===run){bulkScrapeRun.current=null;setBulkAction(action=>action===actionKey?null:action);}}
  };

  const handleCardRecentIndices = (idx:number,mode:'keep6'|'remove4'|'lcut'|'fcut'|'ssd',expectedMarketName?:string,historySeed?:UserProfile['dayRecords'],expectedSourceMode?:CardSourceMode,expectedGuard?:ScrapeCommitGuard,quiet=false,historyStart?:string,sourceAnalysis?:SourceHistoryAnalysis) => {
    if ((!isMasterApp && !vipCanEdit) || (bulkAction && !(expectedMarketName && bulkAction==='positions:market-history')) || activeTab !== 'ank') return;
    const owner=activeId,date=currentDate;
    const select=(profile:UserProfile,state:AppState) => {
      if(expectedMarketName&&!isMasterApp&&profile.vipAccessEnabled===false)return undefined;
      if(expectedGuard&&!canCommitScrape(state,expectedGuard,'ank',idx))return undefined;
      const day=profile.dayRecords?.[date]||{},name=getEffectiveMarkets(profile.config)[idx]?.n;
      if(!name||!isMarketEnabledForDate(profile.config,day.visAnk,name,date)||!vipLiveMarketEligible(profile,date,'ank',name))return undefined;
      if(expectedMarketName && (name!==expectedMarketName || !(sourceAnalysis?canApplySourceWindowHistory(day.data?.[idx],name):canApplyMarketHistoryChoice(day.data?.[idx],name)) || getScrapeSource(day.data?.[idx])?.mode!==expectedSourceMode))return undefined;
      if(mode==='ssd'){
        const next=keepSupportStrongDigits(day.data?.[idx],profile,date,name,state.profiles?.admin1);
        return next?{next,name}:undefined;
      }
      const count=mode==='keep6'?6:4;
      const indices=(mode==='lcut'||mode==='fcut')?[]:sourceAnalysis?checkedSourceHistory({status:'success',sourceHistory:sourceAnalysis},date,name,expectedSourceMode!,getScrapeSource(day.data?.[idx])!.digits).indices.slice(0,count):expectedSourceMode?sourceHistoryIndices(profile.dayRecords||{},date,idx,name,expectedSourceMode,count,historySeed,historyStart):recentUniqueSourceIndices(profile.dayRecords||{},date,idx,name,count,profileSourceIndexGuidance(state,owner));
      const next=mode==='fcut'?removeFirstFourSourceIndices(day.data?.[idx]):mode==='lcut'?removeLastFourSourceIndices(day.data?.[idx]):mode==='keep6'?keepRecentSixIndices(day.data?.[idx],indices):removeRecentFourIndices(day.data?.[idx],indices);
      return next?{next,name}:undefined;
    };
    const profile=appStateRef.current.profiles[owner];
    if(!profile||!select(profile,appStateRef.current)){if(!quiet)showToast('No card changed',mode==='ssd'?'Current box digits and Strong/Support source ranking required; protected or already-SSD cards unchanged.':mode==='fcut'?'Saved original source required; positions 1–4 absent/already cut, or card protected.':mode==='lcut'?'Saved original source required; positions 7–10 absent/already cut, or card protected.':'Saved source and matching prior indices required; absent positions skipped, sent/settled cards protected.','info');return;}
    setAppState(prev=>{
      const original=prev.profiles[owner];if(!original)return prev;
      const selected=select(original,prev);if(!selected)return prev;
      const profiles={...prev.profiles},p=ensureProfileStructure(original,true),day=p.dayRecords[date]||{};
      selected.next.marketName=selected.name;
      p.dayRecords[date]={...day,data:{...day.data,[idx]:selected.next}};profiles[owner]=p;
      if(owner==='admin1')for(const pid of Object.keys(profiles)){
        if(pid===owner||!vipCopiesAdmin(profiles[pid]))continue;
        const vip=ensureProfileStructure(profiles[pid],true),vi=findMarketIndexByName(getEffectiveMarkets(vip.config),selected.name),vd=vip.dayRecords[date]||{};
        if(vi<0||!isMarketEnabledForDate(vip.config,vd.visAnk,selected.name,date)||!vipLiveMarketEligible(vip,date,'ank',selected.name)||vd.data?.[vi]?.dispatchState||vd.data?.[vi]?.deliveryRestoredAt)continue;
        if(expectedMarketName&&!canProjectMarketHistorySource(vd.data?.[vi],selected.name))continue;
        const projected=projectAdminSource(vd.data?.[vi],selected.next,selected.name);
        if(projected&&projected!==vd.data?.[vi]){vip.dayRecords[date]={...vd,data:{...vd.data,[vi]:projected}};profiles[pid]=vip;}
      }
      return {...prev,profiles};
    });
    if(!quiet)showToast(mode==='ssd'?'SSD applied':mode==='fcut'?'Fcut applied':mode==='lcut'?'Lcut applied':mode==='keep6'?'Keep6 applied':'Remove4 applied',mode==='ssd'?'Current box me se sirf Strong aur Support digits rakhe gaye; pehle se cut digits wapas nahi aaye.':mode==='fcut'?'Original source positions 1–4 cut from current box; earlier cuts preserved.':mode==='lcut'?'Original source positions 7–10 cut from current box; earlier cuts preserved.':mode==='keep6'?'Original source positions selected; AUTO REMOVE RESULT still applies when ON.':'Current box filtered at original-source indices; no removed digits restored.','success');
    return true;
  };





  const handleBulkRemoveRecentPass = (count: 2 | 4 | 6) => {
    if (!isMasterApp || bulkAction || activeTab !== 'ank') return;
    const sourceProfile = appStateRef.current.profiles[activeId] || appStateRef.current.profiles.admin1;
    const day = sourceProfile.dayRecords[currentDate] || {};
    const markets = getEffectiveMarkets(sourceProfile.config);
    const sharedIndices=count===2?undefined:profileSourceIndexGuidance(appStateRef.current,activeId);
    const eligible = markets.flatMap((market, idx) => {
      const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(market.n, market.hr) : isNightMarket(market.n, market.hr);
      if (!inScope) return [];
      if (!isMarketEnabledForDate(sourceProfile.config, day.visAnk, market.n, currentDate)) return [];
      const indices = count === 6 ? recentSixUniqueIndices(sourceProfile.dayRecords,currentDate,idx,market.n,sharedIndices) : count === 4 ? recentUniqueSourceIndices(sourceProfile.dayRecords,currentDate,idx,market.n,4,sharedIndices) : [];
      const next = count === 6 ? keepRecentSixIndices(day.data?.[idx],indices) : count === 2 ? cutBoxEnds(day.data?.[idx]) : removeRecentFourIndices(day.data?.[idx], indices);
      return next ? [{ idx, name: market.n, indices }] : [];
    });
    if (!eligible.length) {
      showToast('ℹ️ No Cards Changed', count === 6 ? '6 unique prior PASS/FAIL indices aur saved original source required; repeats/missing history skipped, protected cards unchanged' : count === 2 ? 'Current source digits required; empty/protected cards skipped' : '4 unique prior PASS/FAIL source indices aur saved original source required; duplicates/absent cut targets skipped; protected cards unchanged', 'info');
      return;
    }
    setBulkAction(`positions:remove-recent-${count}`);
    setAppState(prev => {
      const profiles = { ...prev.profiles };
      const profile = ensureProfileStructure(profiles[activeId] || profiles.admin1, true);
      const profileDay = profile.dayRecords[currentDate] || {};
      const data = { ...(profileDay.data || {}) };
      eligible.forEach(({ idx, name, indices }) => {
        const next = count === 6 ? keepRecentSixIndices(data[idx],indices) : count === 2 ? cutBoxEnds(data[idx]) : removeRecentFourIndices(data[idx], indices);
        if (!next) return;
        next.marketName = name.trim().toUpperCase();
        data[idx] = next;
      });
      profile.dayRecords[currentDate] = { ...profileDay, data };
      profiles[activeId] = profile;
      if (activeId === 'admin1') {
        Object.keys(profiles).forEach(pid => {
          if (pid === 'admin1' || !vipCopiesAdmin(profiles[pid])) return;
          const vip = ensureProfileStructure(profiles[pid], true);
          const vipMarkets = getEffectiveMarkets(vip.config);
          const vipDay = vip.dayRecords[currentDate] || {};
          const vipData = { ...(vipDay.data || {}) };
          eligible.forEach(({ idx, name }) => {
            const vipIdx = findMarketIndexByName(vipMarkets, name);
            if (vipIdx < 0) return;
            if (!vipLiveMarketEligible(vip, currentDate, 'ank', name)) return;
            const next = projectAdminSource(vipData[vipIdx], data[idx], name);
            if (next && next !== vipData[vipIdx]) {
              delete next.weekdaySelectedDigits;
              delete next.weekdayHitPosition;
              vipData[vipIdx] = next;
            }
          });
          vip.dayRecords[currentDate] = { ...vipDay, data: vipData };
          if (currentDate < titanLocalDateISO()) {
            profiles[pid] = calculateBacktestRecovery(vip, currentDate);
          } else {
            const vipAuto = applyAutoRatesToDayStore(vip, currentDate, profiles);
            if (vipAuto) vip.dayRecords[currentDate] = vipAuto;
            profiles[pid] = vip;
          }
        });
      }
      if (currentDate < titanLocalDateISO()) {
        profiles[activeId] = calculateBacktestRecovery(profiles[activeId], currentDate);
      } else {
        const ownerAuto = applyAutoRatesToDayStore(profiles[activeId], currentDate, profiles);
        if (ownerAuto) profiles[activeId].dayRecords[currentDate] = ownerAuto;
      }
      return { ...prev, profiles };
    });
    lastLedgerSyncRef.current = '';
    setBulkAction(null);
    showToast(count === 6 ? 'KEEP RECENT 6 UNIQUE INDICES✅' : count === 2 ? 'Cut 2 · First + Last' : '✅ Recent 4 Unique Indices Removed', count === 6 ? `${eligible.length} cards · latest 6 unique source positions kept · repeats skipped · auto-remove applies when ON` : count === 2 ? `${eligible.length} cards · first and last current-box digits removed · no source refill` : `${eligible.length} cards · recent 4 unique PASS/FAIL source positions removed · duplicates skipped · auto-remove applies when ON`, 'success');
  };

  /**
   * Commit a bulk Trick in ONE React update. A previous bulk called the single-
   * card handler for every market; each call deep-cloned every historical day
   * across Admin and mirrored VIP profiles, and emitted an individual toast.
   * This performs the identical record and VIP rules, cloning each affected
   * profile only once. A card is never considered applied before its source
   * formula has been calculated from the same pre-click snapshot.
   */
  const commitBulkTricks = (type: GameType, tasks: Array<{idx:number;formatted:string;trick:'T1'|'T2'|'T3'}>) => {
    if (!tasks.length) return;
    const owner = activeId, date = currentDate;
    const dictName = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
    setAppState(prev => {
      const original = prev.profiles[owner] || prev.profiles.admin1;
      if (!original) return prev;
      const profiles = { ...prev.profiles };
      const source = ensureProfileStructure(original, true);
      const markets = type === 'jodi' ? getEffectiveBaseMarkets(source.config) : getEffectiveMarkets(source.config);
      const sourceDict = { ...(source.dayRecords[date]?.[dictName] || {}) } as Record<number, DayMarketRecord>;
      const mirrors = new Map<string,{profile:UserProfile;dict:Record<number,DayMarketRecord>;markets:ReturnType<typeof getEffectiveMarkets>}>();
      let changed = false;
      for (const task of tasks) {
        const name = String(markets[task.idx]?.n || '').trim().toUpperCase();
        const visibility=type==='ank'?source.dayRecords[date]?.visAnk:source.dayRecords[date]?.visPan;
        if(!isMarketEnabledForDate(source.config,visibility,name,date))continue;
        const record = { ...(sourceDict[task.idx] || { s:'WAIT', d:'', r:'' }) } as DayMarketRecord;
        if (!canReplaceLiveCombinedDecision(record) || record.sentRate || record.sentDigits || record.dispatchState === 'QUEUED' || String(record.dispatchState) === 'SENDING' || record.dispatchState === 'SENT' || record.dispatchState === 'SETTLED') continue;
        if (autoBacktestResult && date < titanLocalDateISO()) {
          record.s = 'WAIT'; delete record.manualStatus; delete record.backtestResult; delete record.manualResult; delete record.manualResultSources;
        }
        scrapeIntents.current.ids.delete(`${owner}|${date}|${type}|${task.idx}`);
        if (!record.od) record.od = (type === 'ank' ? getScrapeSource(record)?.digits : undefined) || record.d || '';
        releaseLiveCombinedDecision(record);
        record.d = task.formatted; record.trick = task.trick;
        record.sourceEditedAt = Math.max(Date.now(), Number(record.sourceEditedAt || 0) + 1, Number(record.cardGeneration || 0) + 1);
        delete record.positionRule;
        if (name) record.marketName = name;
        sourceDict[task.idx] = record;
        changed = true;
        if (!isMasterApp || owner !== 'admin1' || task.trick === 'T3') continue;
        for (const pid of Object.keys(profiles)) {
          if (pid === 'admin1' || !vipCopiesAdmin(profiles[pid])) continue;
          let mirror = mirrors.get(pid);
          if (!mirror) {
            const profile = ensureProfileStructure(profiles[pid], true);
            mirror = { profile, dict: { ...(profile.dayRecords[date]?.[dictName] || {}) } as Record<number, DayMarketRecord>, markets: type === 'jodi' ? getEffectiveBaseMarkets(profile.config) : getEffectiveMarkets(profile.config) };
            mirrors.set(pid, mirror);
          }
          if (!vipLiveMarketEligible(mirror.profile,date,type,name)) continue;
          const vipIdx = findMarketIndexByName(mirror.markets,name);
          if (vipIdx < 0 || !isMarketEnabledForDate(mirror.profile.config,type==='ank'?mirror.profile.dayRecords[date]?.visAnk:mirror.profile.dayRecords[date]?.visPan,name,date)) continue;
          const vip = { ...(mirror.dict[vipIdx] || { s:'WAIT', d:'', r:'' }) } as DayMarketRecord;
          if (!canReplaceLiveCombinedDecision(vip) || vip.sentRate || vip.sentDigits || vip.dispatchState === 'QUEUED' || String(vip.dispatchState) === 'SENDING' || vip.dispatchState === 'SENT' || vip.dispatchState === 'SETTLED') continue;
          if (!vip.od) vip.od = record.od || vip.d || '';
          releaseLiveCombinedDecision(vip);
          vip.d = task.formatted; vip.trick = task.trick;
          vip.sourceEditedAt = Math.max(Date.now(), Number(vip.sourceEditedAt || 0) + 1, Number(vip.cardGeneration || 0) + 1);
          delete vip.positionRule;
          vip.mirroredFromAdmin = true;
          if (name) vip.marketName = name;
          mirror.dict[vipIdx] = vip;
        }
      }
      if (!changed) return prev;
      source.dayRecords[date] = { ...(source.dayRecords[date] || {}), [dictName]: sourceDict };
      if (date < titanLocalDateISO()) {
        profiles[owner] = calculateBacktestRecovery(source, date);
      } else {
        const auto = applyAutoRatesToDayStore(source, date, profiles);
        if (auto) source.dayRecords[date] = auto;
        profiles[owner] = source;
      }
      for (const [pid, mirror] of mirrors) {
        mirror.profile.dayRecords[date] = { ...(mirror.profile.dayRecords[date] || {}), [dictName]:mirror.dict };
        if (date < titanLocalDateISO()) {
          profiles[pid] = calculateBacktestRecovery(mirror.profile, date);
        } else {
          const vipAuto = applyAutoRatesToDayStore(mirror.profile, date, profiles);
          if (vipAuto) mirror.profile.dayRecords[date] = vipAuto;
          profiles[pid] = mirror.profile;
        }
      }
      return { ...prev, profiles };
    });
  };

  /** Same per-card Undo rules, but a single state commit and a single save. */
  const commitBulkUndo = (type:GameType, indices:number[]) => {
    if (!indices.length) return;
    const owner = activeId, date = currentDate;
    const dictName = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
    setAppState(prev => {
      const original = prev.profiles[owner] || prev.profiles.admin1;
      if (!original) return prev;
      const profiles = { ...prev.profiles };
      const source = ensureProfileStructure(original, true);
      const markets = type === 'jodi' ? getEffectiveBaseMarkets(source.config) : getEffectiveMarkets(source.config);
      const sourceDict = { ...(source.dayRecords[date]?.[dictName] || {}) } as Record<number,DayMarketRecord>;
      const mirrors = new Map<string,{profile:UserProfile;dict:Record<number,DayMarketRecord>;markets:ReturnType<typeof getEffectiveMarkets>}>();
      let changed = false;
      for (const idx of indices) {
        const name = String(markets[idx]?.n || '').trim().toUpperCase();
        const originalRec = sourceDict[idx], trick = originalRec?.trick;
        const restored = undoSelection(originalRec,date);
        if (!restored) continue;
        if (name) restored.marketName = name;
        sourceDict[idx] = restored;
        changed = true;
        if (!isMasterApp || owner !== 'admin1' || trick === 'T3') continue;
        for (const pid of Object.keys(profiles)) {
          if (pid === 'admin1' || !vipCopiesAdmin(profiles[pid])) continue;
          let mirror = mirrors.get(pid);
          if (!mirror) {
            const profile = ensureProfileStructure(profiles[pid], true);
            mirror = {profile,dict:{ ...(profile.dayRecords[date]?.[dictName] || {}) } as Record<number,DayMarketRecord>,markets:type === 'jodi' ? getEffectiveBaseMarkets(profile.config) : getEffectiveMarkets(profile.config)};
            mirrors.set(pid,mirror);
          }
          if (!vipLiveMarketEligible(mirror.profile,date,type,name)) continue;
          const vipIdx = findMarketIndexByName(mirror.markets,name);
          if (vipIdx < 0 || !isMarketEnabledForDate(mirror.profile.config,type==='ank'?mirror.profile.dayRecords[date]?.visAnk:mirror.profile.dayRecords[date]?.visPan,name,date)) continue;
          const vip = undoSelection(mirror.dict[vipIdx],date);
          if (!vip) continue;
          vip.mirroredFromAdmin = true;
          if (name) vip.marketName = name;
          mirror.dict[vipIdx] = vip;
        }
      }
      if (!changed) return prev;
      source.dayRecords[date] = { ...(source.dayRecords[date] || {}), [dictName]:sourceDict };
      profiles[owner] = holdBacktestDaySelections(source,date);
      for (const [pid,mirror] of mirrors) {
        mirror.profile.dayRecords[date] = { ...(mirror.profile.dayRecords[date] || {}), [dictName]:mirror.dict };
        profiles[pid] = holdBacktestDaySelections(mirror.profile,date);
      }
      return { ...prev, profiles };
    });
  };

  /** Apply T1/T2/T3 from each card's original source digits. */
  const handleBulkTrick = (trickNum: 1 | 2 | 3, type: GameType) => {
    if (!isMasterApp || bulkAction || type === 'jodi') return;
    const cfg = currentProfile.config || getDefaultConfig();
    const list = getEffectiveMarkets(cfg);
    const dayStore = currentProfile.dayRecords[currentDate] || {};
    const dictName = type === 'ank' ? 'data' : 'pannelData';
    const dict = (dayStore[dictName] || {}) as Record<number, DayMarketRecord>;
    const visDict = type === 'ank' ? dayStore.visAnk : dayStore.visPan;
    const targets = list
      .map((m, idx) => ({ m, idx, rec: dict[idx] }))
      .filter(({ m, rec }) => {
        const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(m.n, m.hr) : isNightMarket(m.n, m.hr);
        if (!inScope) return false;
        if (!isMarketEnabledForDate(cfg,visDict,m.n,currentDate)) return false;
        if (rec?.sentRate || rec?.sentDigits || rec?.dispatchState === 'QUEUED' || String(rec?.dispatchState) === 'SENDING' || rec?.dispatchState === 'SENT' || rec?.dispatchState === 'SETTLED' || rec?.s === 'PASS' || rec?.s === 'FAIL') return false;
        const source = String(rec?.od || (type==='ank'?getScrapeSource(rec)?.digits:undefined) || rec?.d || '').trim();
        return /\d/.test(source);
      });

    if (!targets.length) {
      showToast('ℹ️ No Trick Source', 'Bulk Trick ke liye source digits nahi mile', 'info');
      return;
    }

    const actionKey = `trick:${trickNum}`;
    const tasks = targets.flatMap(({rec,idx}) => {
      const source = String(rec?.od || (type==='ank'?getScrapeSource(rec)?.digits:undefined) || rec?.d || '').trim();
      const result = applyTrickFormula(source,trickNum);
      return result ? [{idx,formatted:result.formatted,trick:result.trick}] : [];
    });
    setBulkAction(actionKey);
    commitBulkTricks(type,tasks);
    setBulkAction(null);
    const ok = tasks.length;
    showToast(
      ok ? '✅ Bulk Trick Done' : '⚠️ Bulk Trick Failed',
      `T${trickNum}: ${ok}/${targets.length} cards updated`,
      ok ? 'success' : 'warning',
    );
  };

  const handleBulkUndoTricks = (type: GameType) => {
    if (!isMasterApp || bulkAction || type !== 'ank') return;
    const cfg = currentProfile.config || getDefaultConfig();
    const list = getEffectiveMarkets(cfg);
    const dayStore = currentProfile.dayRecords[currentDate] || {};
    const dict = (dayStore.data || {}) as Record<number, DayMarketRecord>;
    const visDict = dayStore.visAnk;
    const targets = list
      .map((m, idx) => ({ m, idx, rec: dict[idx] }))
      .filter(({ m, rec }) => {
        const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(m.n, m.hr) : isNightMarket(m.n, m.hr);
        if (!inScope) return false;
        if (!isMarketEnabledForDate(cfg, visDict, m.n, currentDate)) return false;
        return Boolean(selectionUndoSource(rec));
      });
    if (!targets.length) {
      showToast('ℹ️ Nothing to Undo', 'Koi editable applied trick nahi mila', 'info');
      return;
    }
    if(currentDate<titanLocalDateISO()){setAutoBacktestResult(false);backtestActualCache.current.clear();backtestLookups.current.clear();}
    setBulkAction('trick:undo');
    commitBulkUndo(type,targets.map(({idx})=>idx));
    setBulkAction(null);
    showToast('🔙 Bulk Undo Done', `${targets.length} cards original digits par restore hue${currentDate<titanLocalDateISO()?' · Test OFF':''}`, 'success');
  };










  const handleBulkUniversalLifetime4Ank = (type: GameType) => {
    if (!isMasterApp || bulkAction || (type !== 'ank' && type !== 'jodi')) return;
    const owner = activeId, date = currentDate;
    const profile = appStateRef.current.profiles[owner];
    if (!profile) return;
    const cfg = profile.config || getDefaultConfig();
    const list = type === 'jodi' ? getEffectiveBaseMarkets(cfg) : getEffectiveMarkets(cfg);
    const dayStore = profile.dayRecords[date] || {};
    const dict = (type === 'jodi' ? dayStore.jodiData || {} : dayStore.data || {}) as Record<number, DayMarketRecord>;
    const visDict = type === 'jodi' ? dayStore.visJodi : dayStore.visAnk;

    const targets = list
      .map((m, idx) => ({ m, idx, rec: dict[idx] }))
      .filter(({ m, rec }) => {
        const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(m.n, m.hr) : isNightMarket(m.n, m.hr);
        if (!inScope) return false;
        if (!isMarketEnabledForDate(cfg, visDict, m.n, date)) return false;
        if (rec && (rec.sentRate || rec.sentDigits || rec.dispatchState === 'QUEUED' || String(rec.dispatchState) === 'SENDING' || rec.dispatchState === 'SENT' || rec.dispatchState === 'SETTLED' || rec.s === 'PASS' || rec.s === 'FAIL')) return false;
        return true;
      });

    if (!targets.length) {
      showToast('ℹ️ No Eligible Cards', '4-ANK Lifetime lagane ke liye koi eligible card nahi mila.', 'info');
      return;
    }

    setBulkAction('trick:lifetime-4ank');
    setAppState((prev) => {
      const profiles = { ...prev.profiles };
      const p = ensureProfileStructure(profiles[owner] || profiles.admin1, true);
      const dStore = p.dayRecords[date] || {};
      const nextData = { ...(type === 'jodi' ? (dStore.jodiData || {}) : (dStore.data || {})) };

      for (const { m, idx, rec } of targets) {
        const existing: DayMarketRecord = rec || { s: 'WAIT', d: '', r: '', marketName: m.n };
        const baseName = m.n.replace(/\s+(OPEN|CLOSE)$/i, '').trim();
        let refJodi = findReferenceJodiForMarket({
          profile: p,
          currentDate: date,
          baseMarketName: baseName,
          fallbackIndex: idx,
        })?.refJodi;

        if (!refJodi) {
          const cand = dStore.jodiData?.[idx]?.manualResult || dStore.jodiData?.[idx]?.scrapeResultDigit;
          if (cand && /^\d{2}$/.test(String(cand).replace(/\D/g, ''))) {
            refJodi = String(cand).replace(/\D/g, '').slice(0, 2);
          }
        }

        // If CLOSE card, detect today's open result digit and if Open failed
        let todayOpenDigit: string | undefined;
        let isOpenFailed = false;
        if (m.n.trim().toUpperCase().endsWith('CLOSE')) {
          const openName = `${baseName} OPEN`;
          const allMarkets = getEffectiveMarkets(p.config || getDefaultConfig());
          const openIdx = findMarketIndexByName(allMarkets, openName);
          if (openIdx >= 0) {
            const openRec = dStore.data?.[openIdx];
            const cand = openRec?.manualResult || openRec?.scrapeResultDigit || (openRec?.backtestResult as any)?.actual?.open || (openRec?.backtestResult as any)?.actual;
            const clean = String(cand ?? '').replace(/\D/g, '');
            if (clean.length >= 1) todayOpenDigit = clean[0];
            if (openRec?.s === 'FAIL') isOpenFailed = true;
          }
        }

        if (!refJodi) {
          refJodi = '24';
        }

        const res = calculateOptimizedMarket4Ank({
          marketName: m.n,
          refJodi,
          todayOpenDigit,
          isOpenFailed,
        });
        if (res) {
          const version = Math.max(Date.now(), modelSourceVersion(existing) + 1);
          const next: DayMarketRecord = {
            ...existing,
            marketName: m.n,
            d: type === 'jodi' ? res.jodis16.join(', ') : res.ank4.join(', '),
            od: existing.od || existing.d || (type === 'jodi' ? res.jodis16.join(', ') : res.ank4.join(', ')),
            positionRule: 'FLOW_3_1',
            sourceMode: 'FLOW_3_1',
            masterFlow: {
              anchor: String(res.ank4[0]),
              shield: String(res.ank4[1]),
              neighbor: String(res.ank4[2]),
              parity: String(res.ank4[3]),
              digits: res.ank4.join(', '),
              reason: `${res.formulaName} · ${res.sourceDesc}`,
              winningLogics: [res.summary],
            },
            sourceEditedAt: version,
          };
          nextData[idx] = next;
        }
      }

      if (type === 'jodi') {
        p.dayRecords[date] = { ...dStore, jodiData: nextData };
      } else {
        p.dayRecords[date] = { ...dStore, data: nextData };
      }
      profiles[owner] = p;

      if (owner === 'admin1') {
        for (const pid of Object.keys(profiles)) {
          if (pid === owner || !vipCopiesAdmin(profiles[pid])) continue;
          const vip = ensureProfileStructure(profiles[pid], true);
          const vd = vip.dayRecords[date] || {};
          const vipData = { ...(type === 'jodi' ? (vd.jodiData || {}) : (vd.data || {})) };
          let changed = false;
          for (const { m, idx } of targets) {
            const vi = findMarketIndexByName(type === 'jodi' ? getEffectiveBaseMarkets(vip.config) : getEffectiveMarkets(vip.config), m.n);
            if (vi < 0 || !isMarketEnabledForDate(vip.config, type === 'jodi' ? vd.visJodi : vd.visAnk, m.n, date) || !vipLiveMarketEligible(vip, date, type, m.n) || (type === 'jodi' ? vd.jodiData?.[vi]?.dispatchState : vd.data?.[vi]?.dispatchState) || (type === 'jodi' ? vd.jodiData?.[vi]?.deliveryRestoredAt : vd.data?.[vi]?.deliveryRestoredAt)) continue;
            const updatedAdminCard = nextData[idx];
            if (!updatedAdminCard) continue;
            const projected = projectAdminSource(type === 'jodi' ? vd.jodiData?.[vi] : vd.data?.[vi], updatedAdminCard, m.n);
            if (projected && projected !== (type === 'jodi' ? vd.jodiData?.[vi] : vd.data?.[vi])) {
              vipData[vi] = projected;
              changed = true;
            }
          }
          if (changed) {
            if (type === 'jodi') {
              vip.dayRecords[date] = { ...vd, jodiData: vipData };
            } else {
              vip.dayRecords[date] = { ...vd, data: vipData };
            }
            profiles[pid] = vip;
          }
        }
      }

      if (date < titanLocalDateISO()) {
        profiles[owner] = calculateBacktestRecovery(profiles[owner], date);
      } else {
        const auto = applyAutoRatesToDayStore(profiles[owner], date, profiles);
        if (auto) profiles[owner].dayRecords[date] = auto;
      }
      return { ...prev, profiles };
    });

    setBulkAction(null);
    showToast(
      '👑 Bulk 4-ANK Done',
      `4-ANK Lifetime: ${targets.length} cards updated with verified Jodi Total + Double Family Cut formula`,
      'success',
    );
  };


  const handleBulkResetCards = async (type: GameType) => {
    if (!isMasterApp || bulkAction || bulkRestoreInFlightRef.current) return;
    const pid=activeId,date=currentDate,profile=appStateRef.current.profiles[pid];
    if(!profile)return;
    const dictField = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
    const list = type === 'jodi' ? getEffectiveBaseMarkets(profile.config) : getEffectiveMarkets(profile.config);
    const dict = profile.dayRecords?.[date]?.[dictField] || {};
    const targets=list.flatMap((market,index)=>{
      const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(market.n, market.hr) : isNightMarket(market.n, market.hr);
      if (!inScope) return [];
      const rec=dict[index];
      if(!rec||(!rec.d&&!rec.r&&!rec.trick&&!rec.positionRule&&!rec.od&&(!rec.s||rec.s==='WAIT')&&!rec.backtestResult&&!rec.sentDigits&&!rec.sentRate&&!rec.sentInvest&&!rec.dispatchState))return [];
      return [{index,marketName:rec.marketName||market.n,sourceEditedAt:Math.max(Date.now(),Number(rec.sourceEditedAt||0)+1,Number(rec.cardGeneration||0)+1)}];
    });
    if(!targets.length){showToast('ℹ️ Nothing to Clear','Koi card data nahi mila','info');return;}
    if(!window.confirm(`${date} ke ${targets.length} ${type.toUpperCase()} cards clear aur purana investment/result reverse karne hain?`))return;
    bulkRestoreInFlightRef.current=true;
    setBulkAction('cards:reset');
    try{
      for(const item of targets){
        scrapeIntents.current.ids.delete(`${pid}|${date}|${type}|${item.index}`);
        const key=`${pid}_${date}_${type}_${item.index}`,timer=manualRateSyncTimersRef.current.get(key);
        if(timer)clearTimeout(timer);
        manualRateSyncTimersRef.current.delete(key);pendingManualRatesRef.current.delete(key);manualRateEditingRef.current.delete(key);
      }
      // Optimistically clear cards immediately in UI so background state syncs never push old digits
      setAppState(prev=>{
        const p=prev.profiles[pid];if(!p)return prev;
        const day=p.dayRecords?.[date]||{},data={...(day[dictField]||{})};
        for(const item of targets)data[item.index]=clearedLedgerCard(data[item.index],item.marketName,item.sourceEditedAt);
        let nextProf = {...p,dayRecords:{...p.dayRecords,[date]:{...day,[dictField]:data}}};
        if (date < titanLocalDateISO()) {
          nextProf = calculateBacktestRecovery(nextProf, date);
        } else {
          const auto = applyAutoRatesToDayStore(nextProf, date, prev.profiles);
          if (auto) nextProf.dayRecords[date] = auto;
        }
        return {...prev,profiles:{...prev.profiles,[pid]:nextProf}};
      });
      await profileMutationQueueRef.current.drain();
      const operationId=bulkOperationId();
      const result=await profileMutationQueueRef.current.enqueue(`bulk-clear:${pid}:${date}`,()=>postBulkCommand({url:apiUrl('/api/bot/ledger_clear_cards'),
        headers:{'Content-Type':'application/json',...profileAuthHeaders(pid)},body:{operationId,profileId:pid,date,type,cards:targets},
        receiptUrl:apiUrl(`/api/app/bulk_operation?kind=clear&profileId=${encodeURIComponent(pid)}&date=${encodeURIComponent(date)}&operationId=${encodeURIComponent(operationId)}`),
      }));
      if(result.status!=='success'||result.profileId!==pid||result.date!==date||!result.cards||!Array.isArray(result.results))throw new Error(result.message||'Bulk Clear failed');
      // One state commit replaces every confirmed cleared card at once.
      setAppState(prev=>{
        const p=prev.profiles[pid];if(!p)return prev;
        const day=p.dayRecords?.[date]||{},data={...(day[dictField]||{})};
        for(const item of targets)if(result.cards[item.index])data[item.index]=result.cards[item.index];
        let nextProf = {...p,dayRecords:{...p.dayRecords,[date]:{...day,[dictField]:data}}};
        if (date < titanLocalDateISO()) {
          nextProf = calculateBacktestRecovery(nextProf, date);
        } else {
          const auto = applyAutoRatesToDayStore(nextProf, date, prev.profiles);
          if (auto) nextProf.dayRecords[date] = auto;
        }
        return {...prev,profiles:{...prev.profiles,[pid]:nextProf}};
      });
      lastLedgerSyncRef.current='';lastScheduleSyncRef.current='';
      window.dispatchEvent(new Event('titan-ledger-synced'));
      const cleared=targets.filter(item=>Boolean(result.cards[item.index])).length,failed=targets.length-cleared;
      const reasons=[...new Set(result.results.filter((item:any)=>!item.ok&&item.message).map((item:any)=>String(item.message)))].slice(0,2).join(' · ');
      showToast(failed?cleared?'Clear partially completed':'❌ Bulk Clear Failed':'🗑️ Bulk Delete Done',`${cleared}/${targets.length} cards cleared together; old investment/results reversed${failed?`; ${failed} failed${reasons?`: ${reasons}`:''}—retry Clear`:''}`,failed?'warning':'success');
    }catch(error:any){showToast(error instanceof BulkCommandError&&error.outcomeUnknown?'Clear · confirmation pending':'❌ Bulk Clear Failed',error?.message||'Card reset failed',error instanceof BulkCommandError&&error.outcomeUnknown?'warning':'danger');}
    finally{bulkRestoreInFlightRef.current=false;setBulkAction(action=>action==='cards:reset'?null:action);}
  };

  /** Bulk7: cut only the first digit from each current selection on every click. */
  const handleBulkFirstDigitMirrorCut = (type: GameType) => {
    if (!isMasterApp || bulkAction || type !== 'ank') return;
    const owner = activeId, date = currentDate;
    const snapshot = appStateRef.current.profiles[owner];
    if (!snapshot) return;
    const eligible = getEffectiveMarkets(snapshot.config).flatMap((market, idx) => {
      const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(market.n, market.hr) : isNightMarket(market.n, market.hr);
      if (!inScope) return [];
      const day = snapshot.dayRecords[date] || {}, rec = day.data?.[idx];
      if (!isMarketEnabledForDate(snapshot.config, day.visAnk, market.n, date) || !vipLiveMarketEligible(snapshot,date,'ank',market.n)) return [];
      if (rec?.marketName && rec.marketName.trim().toUpperCase() !== market.n.trim().toUpperCase()) return [];
      return cutFirstDigit(rec) ? [{idx,name:market.n,version:scrapeRecordVersion(rec)}] : [];
    });
    if (!eligible.length) {
      showToast('First Digit Cut · unchanged','Each click cuts only the first current digit. Protected/settled/empty cards unchanged.','info');
      return;
    }
    setBulkAction('first:digit-cut');
    setAppState(prev => {
      if (!prev.profiles[owner]) return prev;
      const profiles = {...prev.profiles}, profile = ensureProfileStructure(profiles[owner], true);
      const day = profile.dayRecords[date] || {}, data = {...day.data}, markets = getEffectiveMarkets(profile.config);
      const committed:Array<{idx:number;name:string}> = [];
      for (const {idx,name,version} of eligible) {
        if (markets[idx]?.n !== name || scrapeRecordVersion(data[idx]) !== version ||
          !isMarketEnabledForDate(profile.config,day.visAnk,name,date) || !vipLiveMarketEligible(profile,date,'ank',name)) continue;
        const next = cutFirstDigit(data[idx]);
        if (!next) continue;
        next.marketName = name.trim().toUpperCase();data[idx] = next;committed.push({idx,name});
      }
      if (!committed.length) return prev;
      profile.dayRecords[date] = {...day,data};profiles[owner] = profile;
      if (owner === 'admin1') {
        for (const pid of Object.keys(profiles)) {
          if (pid === owner || !vipCopiesAdmin(profiles[pid])) continue;
          const vip = ensureProfileStructure(profiles[pid], true), vipMarkets = getEffectiveMarkets(vip.config);
          const vipDay = vip.dayRecords[date] || {}, vipData = {...vipDay.data};
          for (const {idx,name} of committed) {
            const vi = findMarketIndexByName(vipMarkets,name);
            if (vi < 0 || !isMarketEnabledForDate(vip.config,vipDay.visAnk,name,date) || !vipLiveMarketEligible(vip,date,'ank',name)) continue;
            const target=vipData[vi];
            if (target?.manualStatus || target?.deliveryRestoredAt || target?.s === 'SKIP' || target?.s === 'PASS' || target?.s === 'FAIL') continue;
            const next = projectAdminSource(target,data[idx],name);
            if (next && next !== target) vipData[vi] = next;
          }
          vip.dayRecords[date] = {...vipDay,data:vipData};
          if (date < titanLocalDateISO()) {
            profiles[pid] = calculateBacktestRecovery(vip, date);
          } else {
            const vipAuto = applyAutoRatesToDayStore(vip, date, profiles);
            if (vipAuto) vip.dayRecords[date] = vipAuto;
            profiles[pid] = vip;
          }
        }
      }
      if (date < titanLocalDateISO()) {
        profiles[owner] = calculateBacktestRecovery(profiles[owner], date);
      } else {
        const ownerAuto = applyAutoRatesToDayStore(profiles[owner], date, profiles);
        if (ownerAuto) profiles[owner].dayRecords[date] = ownerAuto;
      }
      return {...prev,profiles};
    });
    lastLedgerSyncRef.current = '';
    // Existing state effect syncs after React commits, never the pre-click snapshot.
    setBulkAction(null);
    showToast('First Digit Cut',`${eligible.length} eligible cards · first current digit only · previous cuts retained`,'success');
  };

  /** SSD (Support Strong Digit): filter only current-box digits to keep Strong & Support digits; never restore already-cut digits. */
  const handleBulkSupportStrongDigits = () => {
    if (!isMasterApp || bulkAction || activeTab !== 'ank') return;
    const owner = activeId, date = currentDate;
    const snapshot = appStateRef.current.profiles[owner] || appStateRef.current.profiles.admin1;
    const adminProfile = appStateRef.current.profiles.admin1;
    if (!snapshot) return;
    const eligible = getEffectiveMarkets(snapshot.config).flatMap((market, idx) => {
      const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(market.n, market.hr) : isNightMarket(market.n, market.hr);
      if (!inScope) return [];
      const day = snapshot.dayRecords[date] || {}, rec = day.data?.[idx];
      if (!isMarketEnabledForDate(snapshot.config, day.visAnk, market.n, date) || !vipLiveMarketEligible(snapshot, date, 'ank', market.n)) return [];
      if (rec?.marketName && rec.marketName.trim().toUpperCase() !== market.n.trim().toUpperCase()) return [];
      const computed = keepSupportStrongDigits(rec, snapshot, date, market.n, adminProfile);
      return computed
        ? [{ idx, name: market.n, version: scrapeRecordVersion(rec), computed }]
        : [];
    });
    if (!eligible.length) {
      showToast('SSD · unchanged', 'Current box digits aur Strong/Support ranking required; protected ya already-SSD cards unchanged.', 'info');
      return;
    }
    setBulkAction('positions:ssd');
    setAppState(prev => {
      if (!prev.profiles[owner]) return prev;
      const profiles = { ...prev.profiles }, profile = ensureProfileStructure(profiles[owner], true);
      const day = profile.dayRecords[date] || {}, data = { ...day.data }, markets = getEffectiveMarkets(profile.config);
      const committed: Array<{ idx: number; name: string }> = [];
      for (const { idx, name, version, computed } of eligible) {
        if (markets[idx]?.n !== name || scrapeRecordVersion(data[idx]) !== version ||
          !isMarketEnabledForDate(profile.config, day.visAnk, name, date) || !vipLiveMarketEligible(profile, date, 'ank', name)) continue;
        const next = computed;
        if (!next) continue;
        next.marketName = name.trim().toUpperCase();
        data[idx] = next;
        committed.push({ idx, name });
      }
      if (!committed.length) return prev;
      profile.dayRecords[date] = { ...day, data };
      profiles[owner] = profile;
      if (owner === 'admin1') {
        for (const pid of Object.keys(profiles)) {
          if (pid === owner || !vipCopiesAdmin(profiles[pid])) continue;
          const vip = ensureProfileStructure(profiles[pid], true), vipMarkets = getEffectiveMarkets(vip.config);
          const vipDay = vip.dayRecords[date] || {}, vipData = { ...vipDay.data };
          for (const { idx, name } of committed) {
            const vi = findMarketIndexByName(vipMarkets, name);
            if (vi < 0 || !isMarketEnabledForDate(vip.config, vipDay.visAnk, name, date) || !vipLiveMarketEligible(vip, date, 'ank', name)) continue;
            const target = vipData[vi];
            if (target?.manualStatus || target?.deliveryRestoredAt || target?.s === 'SKIP' || target?.s === 'PASS' || target?.s === 'FAIL') continue;
            const next = projectAdminSource(target, data[idx], name);
            if (next && next !== target) vipData[vi] = next;
          }
          vip.dayRecords[date] = { ...vipDay, data: vipData };
          if (date < titanLocalDateISO()) {
            profiles[pid] = calculateBacktestRecovery(vip, date);
          } else {
            const vipAuto = applyAutoRatesToDayStore(vip, date, profiles);
            if (vipAuto) vip.dayRecords[date] = vipAuto;
            profiles[pid] = vip;
          }
        }
      }
      if (date < titanLocalDateISO()) {
        profiles[owner] = calculateBacktestRecovery(profiles[owner], date);
      } else {
        const ownerAuto = applyAutoRatesToDayStore(profiles[owner], date, profiles);
        if (ownerAuto) profiles[owner].dayRecords[date] = ownerAuto;
      }
      return { ...prev, profiles };
    });
    lastLedgerSyncRef.current = '';
    setBulkAction(null);
    showToast('SSD · Support Strong Digit', `${eligible.length} cards · current box me se sirf Strong & Support digits rakhe gaye; pehle se cut digits untouched`, 'success');
  };

  const handleBulkMirrorAdd = () => {
    if(!isMasterApp||bulkAction||activeTab!=='ank')return;
    const owner=activeId,date=currentDate,preview=applyBulkMirrorAdd(appStateRef.current,owner,date,bulkMarketScope);
    if(!preview.changedCards){showToast('Mirror Add · unchanged','Empty, already mirrored, disabled or protected cards unchanged.','info');return;}
    setAppState(prev=>applyBulkMirrorAdd(prev,owner,date).state);
    lastLedgerSyncRef.current='';
    showToast('Mirror Add',`${preview.changedCards} cards · current digits + mirrors · duplicates removed · OPEN/CLOSE overlap may return`,'success');
  };

  /** Recent2 +1: each market uses its own latest two result positions. */
  const handleBulkRecentTwoNextCut = (type: GameType) => {
    if (!isMasterApp || bulkAction || type !== 'ank') return;
    const owner = activeId, date = currentDate;
    const snapshot = appStateRef.current.profiles[owner];
    if (!snapshot) return;
    const eligible = getEffectiveMarkets(snapshot.config).flatMap((market, idx) => {
      const inScope = bulkMarketScope === 'ALL' ? true : bulkMarketScope === 'DAY' ? isDayMarket(market.n, market.hr) : isNightMarket(market.n, market.hr);
      if (!inScope) return [];
      const day = snapshot.dayRecords[date] || {}, rec = day.data?.[idx];
      if (!isMarketEnabledForDate(snapshot.config, day.visAnk, market.n, date) || !vipLiveMarketEligible(snapshot,date,'ank',market.n)) return [];
      if (rec?.marketName && rec.marketName.trim().toUpperCase() !== market.n.trim().toUpperCase()) return [];
      const indices = recentSourceIndices(snapshot.dayRecords,date,idx,market.n,2,true);
      return removeRecentTwoNextIndices(rec,indices) ? [{idx,name:market.n,version:scrapeRecordVersion(rec)}] : [];
    });
    if (!eligible.length) {
      showToast('Recent2 +1 Cut · unchanged','Recent 2 PASS/FAIL indices aur saved original source required; protected/already-applied cards skipped.','info');
      return;
    }
    setBulkAction('positions:recent2-next');
    setAppState(prev => {
      if (!prev.profiles[owner]) return prev;
      const profiles = {...prev.profiles}, profile = ensureProfileStructure(profiles[owner], true);
      const day = profile.dayRecords[date] || {}, data = {...day.data}, markets = getEffectiveMarkets(profile.config);
      const committed:Array<{idx:number;name:string}> = [];
      for (const {idx,name,version} of eligible) {
        if (markets[idx]?.n !== name || scrapeRecordVersion(data[idx]) !== version ||
          !isMarketEnabledForDate(profile.config,day.visAnk,name,date) || !vipLiveMarketEligible(profile,date,'ank',name)) continue;
        const indices = recentSourceIndices(profile.dayRecords,date,idx,name,2,true);
        const next = removeRecentTwoNextIndices(data[idx],indices);
        if (!next) continue;
        next.marketName = name.trim().toUpperCase();data[idx] = next;committed.push({idx,name});
      }
      if (!committed.length) return prev;
      profile.dayRecords[date] = {...day,data};profiles[owner] = profile;
      if (owner === 'admin1') {
        for (const pid of Object.keys(profiles)) {
          if (pid === owner || !vipCopiesAdmin(profiles[pid])) continue;
          const vip = ensureProfileStructure(profiles[pid], true), vipMarkets = getEffectiveMarkets(vip.config);
          const vipDay = vip.dayRecords[date] || {}, vipData = {...vipDay.data};
          for (const {idx,name} of committed) {
            const vi = findMarketIndexByName(vipMarkets,name);
            if (vi < 0 || !isMarketEnabledForDate(vip.config,vipDay.visAnk,name,date) || !vipLiveMarketEligible(vip,date,'ank',name)) continue;
            const target=vipData[vi];
            if (target?.manualStatus || target?.deliveryRestoredAt || target?.s === 'SKIP' || target?.s === 'PASS' || target?.s === 'FAIL') continue;
            const next = projectAdminSource(target,data[idx],name);
            if (next && next !== target) vipData[vi] = next;
          }
          vip.dayRecords[date] = {...vipDay,data:vipData};
          if (date < titanLocalDateISO()) {
            profiles[pid] = calculateBacktestRecovery(vip, date);
          } else {
            const vipAuto = applyAutoRatesToDayStore(vip, date, profiles);
            if (vipAuto) vip.dayRecords[date] = vipAuto;
            profiles[pid] = vip;
          }
        }
      }
      if (date < titanLocalDateISO()) {
        profiles[owner] = calculateBacktestRecovery(profiles[owner], date);
      } else {
        const ownerAuto = applyAutoRatesToDayStore(profiles[owner], date, profiles);
        if (ownerAuto) profiles[owner].dayRecords[date] = ownerAuto;
      }
      return {...prev,profiles};
    });
    lastLedgerSyncRef.current = '';
    // Existing state effect syncs after React commits, never the pre-click snapshot.
    setBulkAction(null);
    showToast('Recent2 +1 Cut',`${eligible.length} eligible cards · previous cuts retained · indices +1 · 10→1 · repeat digit + mirror cut`,'success');
  };

  // Send the selected card as a display copy; never reserve a financial play.
  const handleVipSendNow = async (type: GameType, idx: number) => {
    const pid = activeIdRef.current, date = currentDateRef.current;
    if (!isMasterApp || !pid || pid === 'admin1' || adminSnapshotRunningRef.current) return;
    const clickKey = `${pid}:${date}:${type}:${idx}`;
    if (vipSendNowPendingRef.current.has(clickKey)) return;
    vipSendNowPendingRef.current.add(clickKey);
    try {
      // Never send an unsaved browser-only card or an old state after switching VIP/date.
      await profileMutationQueueRef.current.drain();
      await persistCurrentState();
      if (activeIdRef.current !== pid || currentDateRef.current !== date) throw new Error('VIP/date changed; select the card again');
      const profile = appStateRef.current.profiles[pid];
      const dict = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
      const rec = profile?.dayRecords?.[date]?.[dict]?.[idx];
      const markets = type === 'jodi' ? getEffectiveBaseMarkets(profile.config) : getEffectiveMarkets(profile.config);
      if (!rec || !markets[idx]) throw new Error('VIP card unavailable');
      const recoveryState = getCardSameMarketRecoveryState(profile, date, type, idx, markets[idx].n);
      const isSmart = (type === 'ank' || type === 'pannel') && useTwoCardRecovery(profile.config, date, type);
      const isProfitCarry = Boolean(profile.profitCarry || profile.config?.profitCarry);
      const carriedProfit = isProfitCarry ? (recoveryState.pendingProfit || 0) : 0;
      const effectiveSendRate = rec.sentRate || rec.r || rec.recRate || calculateRecoveryRate(
        type,
        rec.sentDigits || rec.d,
        recoveryState.debt,
        Number(profile.config?.[type]?.tgt || 100) + carriedProfit,
      );
      const response = await fetch(apiUrl('/api/bot/vip_send_now'), {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        signal: apiDeadlineSignal(undefined, 20000),
        body: JSON.stringify({ profileId: pid, date, type, index: idx, marketName: markets[idx].n,
          digits: rec.sentDigits || rec.d, rate: effectiveSendRate, cardGeneration: rec.cardGeneration || 0 }),
      });
      const result = await response.json();
      if (!response.ok || result.status !== 'success') throw new Error(result.message || 'Unable to send VIP card');
      showToast(result.alreadyQueued ? 'Copy already queued / recently sent' : 'Card copy queued',
        `${profile.name}: ${markets[idx].n} · gateway will deliver using saved TXT/PNG settings.`, 'success');
    } catch (error: any) {
      showToast('Send now failed', error?.name === 'TimeoutError' ? 'Request timed out; check delivery queue before retrying' : (error?.message || 'Unable to send VIP card'), 'danger');
    } finally {
      vipSendNowPendingRef.current.delete(clickKey);
    }
  };

  // AI Smart Extractor Batch Apply
  const handleBatchApplyData = (targetType: GameType, _textRaw: string, geminiData?: any[]) => {
    if (geminiData && geminiData.length > 0) {
      setAppState((prev) => {
        const updatedProfiles = { ...prev.profiles };
        const dictName = targetType === 'ank' ? 'data' : targetType === 'jodi' ? 'jodiData' : 'pannelData';
        const sourceProf = updatedProfiles[activeId] || updatedProfiles.admin1;
        const targetArr = targetType === 'jodi' ? getEffectiveBaseMarkets(sourceProf?.config) : getEffectiveMarkets(sourceProf?.config);

        geminiData.forEach((item: any) => {
          const mName = String(item.market || '').toUpperCase();
          const phase = String(item.phase || 'OPEN').toUpperCase();
          const fullName = targetType === 'jodi' ? mName : `${mName} ${phase}`;

          const idx = targetArr.findIndex((m) => m.n === fullName || m.n.includes(mName));
          if (idx !== -1) {
            const stableMarketName = String(targetArr[idx]?.n || fullName).trim().toUpperCase();
            Object.keys(updatedProfiles).forEach((pid) => {
              const prof = ensureProfileStructure(updatedProfiles[pid], true);
              const profileMarkets = targetType === 'jodi' ? getEffectiveBaseMarkets(prof.config) : getEffectiveMarkets(prof.config);
              const profileIdx = findMarketIndexByName(profileMarkets, stableMarketName);
              if (profileIdx < 0) return;
              const dict = { ...(prof.dayRecords[currentDate][dictName] || {}) };
              const rec = { ...(dict[profileIdx] || { s: 'WAIT', d: '', r: '' }) };
              if (!canReplaceLiveCombinedDecision(rec) || rec.sentRate || rec.sentDigits || rec.dispatchState === 'SENT' || rec.dispatchState === 'SETTLED') return;

              const newDigits = Array.isArray(item.digits) ? item.digits.join(', ') : String(item.digits || '');
              releaseLiveCombinedDecision(rec);
              rec.d = rec.d ? `${rec.d}, ${newDigits}` : newDigits;
              rec.sourceMode = 'AI_SCAN';
              rec.scrapeSource = targetType === 'ank' ? normalizeScrapeSource({ mode: 'AI_SCAN', digits: rec.d }) : undefined;
              delete rec.sentScrapeSource;
              delete rec.scrapeResultDigit;
              rec.marketName = stableMarketName;
              // AI digits may mirror, but each VIP rate stays backend-owned.
              if (item.rate && pid === activeId) rec.r = String(item.rate);

              dict[profileIdx] = rec as DayMarketRecord;
              prof.dayRecords[currentDate][dictName] = dict;
              updatedProfiles[pid] = prof;
            });
          }
        });

        return { ...prev, profiles: updatedProfiles };
      });

      showToast('🧠 AI Populated!', `Successfully parsed ${geminiData.length} market predictions with Gemini AI!`, 'success');
      setMainNav('ledger');
    }
  };

  // Broadcast Notification
  const handleSendBroadcast = async (title: string, msg: string, selectedTargets: string[], presentation?:BroadcastPresentation) => {
    // Live Push is fail-closed: only explicitly picked WhatsApp / Telegram targets may be queued.
    const uniqueTargets = normalizeTargetList(selectedTargets);
    if (uniqueTargets.length === 0) {
      showToast(`❌ ${title}`, 'Select at least one WhatsApp / Telegram target', 'danger');
      return false;
    }

    const fullMsg = `📢 *${title}*\n\n${msg}\n\n— Titan Nova VIP`;
    try {
      const response = await fetch(apiUrl('/api/bot/broadcast'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: fullMsg, targets: uniqueTargets, broadcastKind: 'vip-live-push',broadcastLink:presentation?.link||'',senderFormat:presentation?.format==='png'?'png':'text',...(presentation?.format==='png'?{broadcastPng:presentation.png,broadcastDesign:presentation.design}:{}) }),
      });
      const result = await response.json();
      if (!response.ok || result?.status !== 'success') throw new Error(result?.message || `HTTP ${response.status}`);
      if (result.targets !== uniqueTargets.length || result.duplicate) throw new Error('Selected targets were not all queued');
      const bcast = { id: Date.now(), title, msg, time: new Date().toLocaleTimeString() };
      setAppState((prev) => ({ ...prev, broadcasts: [bcast, ...(prev.broadcasts || [])] }));
      showToast(`📢 ${title}`, `Queued to ${uniqueTargets.length} selected destination(s)`, 'success');
      return true;
    } catch(error:any) {
      showToast(`📢 ${title}`, error.message||'Notification not queued. Check both gateways and retry.', 'danger');
      return false;
    }
  };

  /** Project Admin source fields into one VIP by stable market name; never copy rate/recovery. */
  const backfillVipAdminMirror = (vipInput: UserProfile, adminInput: UserProfile, date: string, forceSourceCopy = false): UserProfile => {
    const vip = ensureProfileStructure(vipInput);
    const admin = ensureProfileStructure(adminInput);
    const groups: Array<{ dictName: 'data' | 'jodiData' | 'pannelData'; type: GameType }> = [
      { dictName: 'data', type: 'ank' },
      { dictName: 'jodiData', type: 'jodi' },
      { dictName: 'pannelData', type: 'pannel' },
    ];
    const vipDay = { ...(vip.dayRecords[date] || {}) };
    const adminDay = admin.dayRecords[date] || {};
    groups.forEach(({ dictName, type }) => {
      const adminMarkets = type === 'jodi' ? getEffectiveBaseMarkets(admin.config) : getEffectiveMarkets(admin.config);
      const vipMarkets = type === 'jodi' ? getEffectiveBaseMarkets(vip.config) : getEffectiveMarkets(vip.config);
      const adminDict = (adminDay[dictName] || {}) as Record<number, DayMarketRecord>;
      const vipDict = { ...((vipDay[dictName] || {}) as Record<number, DayMarketRecord>) };
      adminMarkets.forEach((adminMarket, adminIdx) => {
        const adminRec = adminDict[adminIdx];
        if (!adminRec?.d && !isEditableSourceSkip(adminRec)&&!adminRec?.carryResultSix) return;
        const vipIdx = findMarketIndexByName(vipMarkets, adminMarket.n);
        if (vipIdx < 0) return;
        if (!vipLiveMarketEligible(vip, date, type, adminMarket.n)) return;
        const projected = projectAdminSource(vipDict[vipIdx], adminRec, adminMarket.n, true, forceSourceCopy);
        if (projected) vipDict[vipIdx] = projected;
      });
      vipDay[dictName] = vipDict;
    });
    vip.dayRecords[date] = vipDay;
    if (date < titanLocalDateISO()) {
      return calculateBacktestRecovery(vip, date);
    }
    const autoUpdated = applyAutoRatesToDayStore(vip, date, { [vip.name || "vip"]: vip });
    if (autoUpdated) vip.dayRecords[date] = autoUpdated;
    return vip;
  };

  // Existing VIPs need the same current-day Admin backfill that a newly-created
  // VIP receives. Future edit mirroring alone cannot populate cards that were
  // already ready before an older profile/browser loaded.
  useEffect(() => {
    if (!serverHydrated || !isMasterApp) return;
    const state = appStateRef.current;
    const admin = state.profiles?.admin1;
    if (!admin) return;
    const copyVipIds = Object.keys(state.profiles || {})
      .filter((pid) => pid !== 'admin1' && vipCopiesAdmin(state.profiles[pid]))
      .sort();
    const signature = JSON.stringify({
      date: currentDate,
      copyVipIds,
      adminDay: admin.dayRecords?.[currentDate] || {},
    });
    if (adminMirrorBackfillSignatureRef.current === signature) return;
    adminMirrorBackfillSignatureRef.current = signature;

    setAppState((prev) => {
      const liveAdmin = prev.profiles?.admin1;
      if (!liveAdmin) return prev;
      let changed = false;
      const profiles = { ...prev.profiles };
      for (const pid of copyVipIds) {
        const existing = profiles[pid];
        if (!existing || !vipCopiesAdmin(existing)) continue;
        const before = JSON.stringify(existing.dayRecords?.[currentDate] || {});
        const backfilled = backfillVipAdminMirror(existing, liveAdmin, currentDate);
        const after = JSON.stringify(backfilled.dayRecords?.[currentDate] || {});
        if (before === after) continue;
        profiles[pid] = backfilled;
        changed = true;
      }
      if (!changed) return prev;
      lastScheduleSyncRef.current = '';
      lastLedgerSyncRef.current = '';
      return { ...prev, profiles };
    });
  }, [serverHydrated, isMasterApp, currentDate, appState.profiles]);

  const handleToggleVipCopyAdmin = async (enabled: boolean) => {
    if (adminSnapshotRunningRef.current) return;
    adminSnapshotRunningRef.current = true;
    setAdminSnapshotBusy(true);
    try {
      const pid = activeIdRef.current;
      if (!pid || pid === 'admin1') return;
      setAppState((prev) => {
        const existing = prev.profiles[pid];
        const admin = prev.profiles.admin1;
        if (!existing || !admin) return prev;
        let vip: UserProfile = { ...existing, vipCopyAdmin: enabled };

        return { ...prev, profiles: { ...prev.profiles, [pid]: vip } };
      });
      lastScheduleSyncRef.current = '';
      lastLedgerSyncRef.current = '';
      if (enabled) {
        const date = currentDateRef.current;
        const vip = appStateRef.current.profiles[pid]; const admin = appStateRef.current.profiles.admin1;
        let copied = 0, failed = 0;
        for (const type of ['ank', 'jodi', 'pannel'] as GameType[]) {
          const vm = type === 'jodi' ? getEffectiveBaseMarkets(vip.config) : getEffectiveMarkets(vip.config);
          const am = type === 'jodi' ? getEffectiveBaseMarkets(admin.config) : getEffectiveMarkets(admin.config);
          for (let idx = 0; idx < vm.length; idx++) {
            if (!vipLiveMarketEligible(vip, date, type, vm[idx].n)) continue;
            const ai = am.findIndex(m => m.n === vm[idx].n);
            if (ai < 0) continue;
            try { await resetCardFinancially(pid, date, type, idx, true); copied++; } catch { failed++; }
          }
        }
        showToast('🔗 Copy Admin ON', `${copied} cards copied fresh; old VIP investment/results reversed${failed ? `; ${failed} failed—retry Copy OFF/ON` : ''}.`, failed ? 'danger' : 'success');
      } else showToast('⛓️ Copy Admin OFF', 'Future Admin digits/trick is VIP me copy nahi hoga.', 'info');
    } finally {
      adminSnapshotRunningRef.current = false;
      setAdminSnapshotBusy(false);
    }
  };

  /**
   * Manual one-shot source snapshot. This intentionally does NOT flip vipCopyAdmin:
   * OFF remains OFF (no continuous mirroring), and ON continues its old behavior.
   * Eligible unsent Admin source copies use the existing server API; settled cards are excluded.
   */
  const handleTakeVipAdminSnapshot = async () => {
    if (!isMasterApp || !serverHydrated || adminSnapshotRunningRef.current) return;
    const pid = activeIdRef.current;
    const date = currentDateRef.current;
    if (!pid || pid === 'admin1') return;
    setAdminSnapshotBusy(true);
    try {
      setAdminSnapshotProgress('Syncing latest Admin cards…');
      await persistCurrentState();
    } catch { /* Continue to authoritative server preview */ }
    adminSnapshotRunningRef.current = true;
    try {
      setAdminSnapshotProgress('Checking eligible cards…');
      const response=await fetch(apiUrl(`/api/bot/ledger_copy_admin_snapshot_preview?profileId=${encodeURIComponent(pid)}&date=${encodeURIComponent(date)}`),{cache:'no-store',headers:profileAuthHeaders(pid),signal:apiDeadlineSignal(undefined,20000)});
      if(!response.ok){
        const errBody=await response.json().catch(()=>null);
        throw new Error(errBody?.message||`Snapshot preview unavailable (HTTP ${response.status})`);
      }
      const payload=await response.json();
      if(payload.status!=='success'||payload.profileId!==pid||payload.date!==date||!Array.isArray(payload.plan?.targets))throw new Error('Snapshot preview mismatch; retry');
      if(activeIdRef.current!==pid||currentDateRef.current!==date)return;
      const localVip=appStateRef.current.profiles[pid];
      if(!localVip)throw new Error('VIP profile changed; reopen it before snapshot');
      const normSnapName=(v:unknown)=>String(v||'').trim().replace(/\s+/g,' ').toUpperCase().replace(/^(?:SHRIDEVI|SRIDEVI|SRIDEV) DAY\b/,'SRIDEVI').replace(/^(?:SHRIDEVI|SRIDEV)\b/,'SRIDEVI');
      const nameList=(profile:UserProfile,type:GameType)=>(type==='jodi'?getEffectiveBaseMarkets(profile.config):getEffectiveMarkets(profile.config)).map(m=>normSnapName(m.n)).join('|');
      if(nameList(localVip,'ank')!==payload.marketNames?.ank?.join('|')||nameList(localVip,'jodi')!==payload.marketNames?.jodi?.join('|'))throw new Error('VIP market order changed on server; refresh before snapshot');
      const plan=payload.plan as AdminCopySnapshotPlan;
      // A local unsaved market-name conflict also blocks that individual card.
      const safeTargets = plan.targets.filter(({ type, index, marketName }) => {
        const dict = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
        const localCard = localVip.dayRecords?.[date]?.[dict]?.[index];
        const localName = localCard?.marketName;
        return !pendingManualRatesRef.current.has(`${pid}_${date}_${type}_${index}`) && !manualRateEditingRef.current.has(`${pid}_${date}_${type}_${index}`) && !isAdminSnapshotProtected(localCard) && adminSnapshotMarketEnabled(localVip,date,type,marketName) && (!localName || localName.trim().toUpperCase() === marketName);
      });
      const skipped = plan.noSource + plan.outsideVipLiveEntry + plan.nameConflict + plan.marketOff + plan.settledOrSent + plan.targets.length - safeTargets.length;
      if (!safeTargets.length) {
        showToast('📸 Admin Snapshot', `No eligible Admin cards for ${date}; ${skipped} skipped. Nothing changed.`, 'info');
        return;
      }
      const requested = safeTargets.length;
      const confirmed = window.confirm(
        `TAKE ADMIN SNAPSHOT — ${payload.name} (${date})\n\n` +
        `${requested} enabled, unsent VIP Ank/Jodi/Panel cards will receive an Admin source snapshot.\n` +
        `Settled, sent, protected and OFF cards will remain untouched.\n` +
        `${skipped} missing/blocked cards will remain unchanged.\n\n` +
        `VIP rates stay independent; settled stakes/results will not be reversed.\n` +
        `Copy Admin ON/OFF setting will NOT change. Continue?`
      );
      if (!confirmed) return;
      // 16-card transport batches; every card still goes through the existing
      // server ledger_set_card reset and Admin-source projection, after snapshot guards.
      // No new settlement formula or client-generated mirror is involved.
      let done = 0;
      let failed = 0;
      let serverSkipped = 0;
      let interrupted = false;
      let uncertain = false;
      const acceptedCards: Array<{ type: GameType; index: number; card: DayMarketRecord }> = [];
      const revisionTargets = safeTargets.map(target => {
        const dict = target.type === 'ank' ? 'data' : target.type === 'jodi' ? 'jodiData' : 'pannelData';
        const old = localVip.dayRecords?.[date]?.[dict]?.[target.index];
        const revision = Math.max(Date.now(), Number(old?.sourceEditedAt || 0) + 1, Number(old?.cardGeneration || 0) + 1);
        return { ...target, sourceEditedAt: revision };
      });
      for (let offset = 0; offset < revisionTargets.length; offset += 16) {
        if (activeIdRef.current !== pid || currentDateRef.current !== date) { interrupted = true; break; }
        const chunk = revisionTargets.slice(offset, offset + 16).filter(target=>{
          const live=appStateRef.current.profiles[pid],key=`${pid}_${date}_${target.type}_${target.index}`;
          return adminSnapshotTargetUnchanged(live,localVip,date,target)&&!pendingManualRatesRef.current.has(key)&&!manualRateEditingRef.current.has(key)&&adminSnapshotMarketEnabled(live,date,target.type,target.marketName);
        });
        serverSkipped+=Math.min(16,revisionTargets.length-offset)-chunk.length;
        if(!chunk.length)continue;
        setAdminSnapshotProgress(`Copying ${Math.min(offset+16,requested)}/${requested} cards…`);
        let requestStarted=false;
        try {
          const response = await profileMutationQueueRef.current.enqueue(`snapshot:${pid}:${date}`, () => {
            if(activeIdRef.current!==pid||currentDateRef.current!==date||chunk.some(target=>{
              const key=`${pid}_${date}_${target.type}_${target.index}`;
              return !adminSnapshotTargetUnchanged(appStateRef.current.profiles[pid],localVip,date,target)||pendingManualRatesRef.current.has(key)||manualRateEditingRef.current.has(key);
            }))throw new Error('Snapshot selection changed while waiting');
            requestStarted=true;
            return fetch(apiUrl('/api/bot/ledger_copy_admin_snapshot_batch'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...profileAuthHeaders(pid) },
            body: JSON.stringify({ profileId: pid, date, cards: chunk }),
            signal:apiDeadlineSignal(undefined,45000),
          });});
          const outcome = await response.json();
          requestStarted = false;
          if (!response.ok || outcome.status !== 'success' || outcome.profileId!==pid || outcome.date!==date || !Array.isArray(outcome.results)) {
            throw new Error(outcome.message || `Snapshot batch HTTP ${response.status}`);
          }
          const seen=new Set<string>();
          for (const entry of outcome.results) {
            const key=`${entry.type}_${entry.index}`;
            if(seen.has(key)||!chunk.some(target=>target.type===entry.type&&target.index===entry.index))throw new Error('Snapshot acknowledgement mismatch');
            seen.add(key);
            if (entry.ok && entry.card && (entry.type === 'ank' || entry.type === 'jodi' || entry.type === 'pannel') && Number.isInteger(entry.index)) {
              acceptedCards.push({ type: entry.type, index: entry.index, card: entry.card });
              done++;
            } else if (entry.skipped) serverSkipped++;
            else failed++;
          }
          // No false success if server did not acknowledge every requested card.
          failed += Math.max(0, chunk.length - outcome.results.length);
        } catch {
          // Network error can occur AFTER a server batch was saved. Never replay
          // it automatically: refresh the ledger before a manual retry.
          uncertain = requestStarted;
          interrupted = true;
          break;
        }
      }
      if (acceptedCards.length) {
        setAppState(prev => {
          const original = prev.profiles[pid];
          if (!original) return prev;
          const day = { ...(original.dayRecords?.[date] || {}) };
          const data = { ...(day.data || {}) };
          const jodiData = { ...(day.jodiData || {}) };
          const pannelData = { ...(day.pannelData || {}) };
          for (const item of acceptedCards) {
            const key=`${pid}_${date}_${item.type}_${item.index}`;
            if(!adminSnapshotTargetUnchanged(original,localVip,date,{...item,marketName:safeTargets.find(target=>target.type===item.type&&target.index===item.index)!.marketName})||pendingManualRatesRef.current.has(key)||manualRateEditingRef.current.has(key))continue;
            if (item.type === 'ank') data[item.index] = item.card;
            else if (item.type === 'jodi') jodiData[item.index] = item.card;
            else pannelData[item.index] = item.card;
          }
          let nextVip: UserProfile = { ...original, dayRecords: {
            ...original.dayRecords, [date]: { ...day, data, jodiData, pannelData },
          } };
          if (date < titanLocalDateISO()) {
            nextVip = calculateBacktestRecovery(nextVip, date);
          } else {
            const vipAuto = applyAutoRatesToDayStore(nextVip, date, prev.profiles);
            if (vipAuto) nextVip.dayRecords[date] = vipAuto;
          }
          return { ...prev, profiles: { ...prev.profiles, [pid]: nextVip } };
        });
      }
      lastLedgerSyncRef.current = '';
      lastScheduleSyncRef.current = '';
      window.dispatchEvent(new Event('titan-ledger-synced'));
      if (uncertain) {
        showToast('⚠️ Snapshot Confirmation Needed', `${done} cards acknowledged; one batch lost its response. Some more may have saved. Refresh once before retrying.`, 'danger');
        return;
      }
      showToast(
        failed || interrupted ? '⚠️ Snapshot Partially Applied' : '📸 Admin Snapshot Saved',
        `${done}/${requested} eligible Admin source cards copied; settled/sent/OFF cards untouched. ` +
          `${failed} failed, ${skipped + serverSkipped} skipped${interrupted ? '; stopped after selection changed' : ''}. Copy Admin ON/OFF unchanged.`,
        failed || interrupted ? 'danger' : 'success'
      );
    } catch (error: any) {
      showToast('❌ Admin Snapshot Failed', error?.message || 'No card changed; retry after syncing.', 'danger');
    } finally {
      adminSnapshotRunningRef.current = false;
      setAdminSnapshotBusy(false);
      setAdminSnapshotProgress('');
      // React must commit the accepted snapshot before the next ledger sync.
      setTimeout(() => {
        window.dispatchEvent(new Event('titan-ledger-dirty'));
        window.dispatchEvent(new Event('titan-ledger-synced'));
      }, 0);
    }
  };

  const handleClearVipAdminMirror = async () => {
    if (adminSnapshotRunningRef.current) return;
    adminSnapshotRunningRef.current = true;
    setAdminSnapshotBusy(true);
    try {
      const pid = activeIdRef.current; if (!pid || pid === 'admin1') return;
      const date = currentDateRef.current; const vip = appStateRef.current.profiles[pid];
      let cleared = 0, failed = 0;
      for (const type of ['ank', 'jodi', 'pannel'] as GameType[]) {
        const dict = type === 'ank' ? 'data' : type === 'jodi' ? 'jodiData' : 'pannelData';
        for (const [idx, rec] of Object.entries(vip.dayRecords?.[date]?.[dict] || {})) {
          if (!rec?.mirroredFromAdmin) continue;
          try { await resetCardFinancially(pid, date, type, Number(idx)); cleared++; } catch { failed++; }
        }
      }
      showToast('🧹 Admin Copy Cleared', `${cleared} cards cleared; old investment/results reversed${failed ? `; ${failed} failed` : ''}.`, failed ? 'danger' : 'success');
    } finally {
      adminSnapshotRunningRef.current = false;
      setAdminSnapshotBusy(false);
    }
  };

  const openBacktestRunProfile=async(pid:string)=>{
    if(!appStateRef.current.profiles[pid]){
      try{const response=await fetch(apiUrl('/api/app/state'));const saved=await response.json();
        if(!response.ok||!saved.state?.profiles?.[pid])throw new Error('Run profile unavailable');
        setAppState(prev=>{const merged=preserveRangeArchive(prev,saved.state);return {...merged,profiles:{...merged.profiles,[pid]:saved.state.profiles[pid]},activeId:pid};});
      }catch{showToast('Run profile unavailable','Refresh profiles to open this saved backtest.','warning');return;}
    }else setAppState(prev=>({...prev,activeId:pid}));
    setMainNav('ledger');setActiveTab('backtest');
  };

  // Add VIP Client — phone set at create time becomes default schedule + result-reply target
  const handleAddVIP = (name: string, phone: string) => {
    const pid = `client_${Date.now()}`;
    const destination = normalizeTargetJid(phone);
    if (!destination) {
      showToast('Invalid destination', 'Select a WhatsApp number, Group or Channel.', 'danger');
      return;
    }
    const deliveryMode = isGroupTarget(destination) ? 'group' : isChannelTarget(destination) ? 'channel' : 'private';
    const cleanPhone = deliveryMode === 'private' ? destination.split('@')[0] : '';
    // Default expiry = +30 days
    const exp = new Date();
    exp.setDate(exp.getDate() + 30);
    const expiryDate = exp.toISOString().slice(0, 10);

    // VIP cards are event-driven: no schedule time and no target selector.
    // The profile phone is the permanent WhatsApp destination.
    const adminCfg = appState.profiles['admin1']?.config || getDefaultConfig();

    const vipConfig = createNewVipConfig(adminCfg);

    const newProf: UserProfile = {
      name: name || 'VIP Client',
      phone: cleanPhone,
      config: vipConfig,
      vipLiveStart: createVipLiveStart(vipConfig, appState.profiles.admin1),
      dayRecords: {},
      vipAccessEnabled: false,
      expiryDate,
      vipSchTarget: cleanPhone,
      vipAutoMode: false,
      vipCopyAdmin: false,
      profitMilestoneNotificationsEnabled: false,
      vipDeliveryMode: deliveryMode,
      vipGroupJid: deliveryMode === 'group' ? destination : undefined,
      vipGroupName: deliveryMode === 'group' ? name : undefined,
      vipChannelJid: deliveryMode === 'channel' ? destination : undefined,
      vipChannelName: deliveryMode === 'channel' ? name : undefined,
      vipScheduleEnabled: {
        ank: false,
        jodi: false,
        pannel: false,
      },
      vipAccessToken: createVipAccessToken(),
    };

    setAppState((prev) => {
      const profiles = { ...(prev.profiles || {}) };
      // Ensure admin1 always exists
      if (!profiles.admin1) {
        profiles.admin1 = {
          name: 'MASTER ADMIN 1',
          phone: '7077550644',
          config: getDefaultConfig(),
          dayRecords: {},
          vipAccessEnabled: true,
        };
      }
      profiles[pid] = newProf;
      return { ...prev, profiles };
    });

    showToast(
      '✅ VIP Added',
      `${name} · ${deliveryMode}: ${destination} · admin settings copied · access/auto/copy OFF · expiry ${expiryDate}`,
      'success'
    );
  };

  // Delete VIP Profile
  const handleDeleteProfile = (pid: string) => {
    if (pid === 'admin1') return;
    if (confirm(`Are you sure you want to delete profile: ${appState.profiles[pid]?.name}?`)) {
      fetch(apiUrl('/api/bot/delete_profile'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...profileAuthHeaders(pid) },
        body: JSON.stringify({ profileId: pid }),
      }).catch(() => null);
      setAppState((prev) => {
        const updated = { ...prev.profiles };
        delete updated[pid];
        return { ...prev, profiles: updated, activeId: prev.activeId === pid ? 'admin1' : prev.activeId };
      });
      showToast('🗑️ Deleted', 'VIP profile and all scheduled activity permanently removed.', 'info');
    }
  };

  // Set VIP Expiry
  const handleSetExpiry = (pid: string, expiryDate: string) => {
    setAppState((prev) => ({
      ...prev,
      profiles: {
        ...prev.profiles,
        [pid]: { ...prev.profiles[pid], expiryDate },
      },
    }));
    showToast('📅 Expiry Updated', `Set expiry for ${appState.profiles[pid]?.name} to ${expiryDate}`, 'success');
  };

  // UI FIX: Store Demo/Member classification per VIP without changing delivery or access behavior.
  const handleSetVipMemberType = (pid: string, vipMemberType: 'regular' | 'demo') => {
    setAppState((prev) => {
      const profile = prev.profiles[pid];
      if (!profile) return prev;
      return { ...prev, profiles: { ...prev.profiles, [pid]: { ...profile, vipMemberType } } };
    });
    showToast(vipMemberType === 'demo' ? '🟡 Demo Member' : '🟢 Regular Member', `${appState.profiles[pid]?.name || 'VIP'} category updated`, 'info');
  };

  // Toggle VIP Access
  const handleToggleVipAccess = (pid: string, enabled: boolean) => {
    setAppState((prev) => ({
      ...prev,
      profiles: {
        ...prev.profiles,
        [pid]: { ...prev.profiles[pid], vipAccessEnabled: enabled },
      },
    }));
    showToast(enabled ? '✅ Access Unlocked' : '🔒 Read-Only Set', `Permission updated for ${appState.profiles[pid]?.name}`, 'info');
  };

  // Event-driven VIP auto mode. No time/target scheduling is used for VIP cards.
  const handleToggleVipAutoMode = (pid: string, enabled: boolean) => {
    setAppState((prev) => {
      const p = prev.profiles[pid];
      if (!p) return prev;
      return {
        ...prev,
        profiles: {
          ...prev.profiles,
          [pid]: { ...p, vipAutoMode: enabled, vipSchTime: undefined, vipSchTarget: isTelegramTarget(p.phone) ? p.phone : String(p.phone || '').replace(/\D/g, '') },
        },
      };
    });
    showToast(enabled ? '🟢 VIP Auto Mode ON' : '🔴 VIP Auto Mode OFF', `${appState.profiles[pid]?.name || 'VIP'} · digits + rate ready → selected destination`, enabled ? 'success' : 'info');
  };

  const handleUpdateVipDestination = (pid: string, mode: 'private' | 'group' | 'channel', destinationJid?: string, destinationName?: string) => {
    const normalizedDestination = normalizeTargetJid(destinationJid, mode === 'channel' ? 'channel' : mode === 'group' ? 'group' : 'phone') || '';
    const normalizedGroup = mode === 'group' ? normalizedDestination : '';
    const normalizedChannel = mode === 'channel' ? normalizedDestination : '';
    if (mode === 'group' && !isGroupTarget(normalizedGroup)) {
      showToast('❌ Invalid Group', 'Paired WhatsApp se valid group select karein.', 'danger');
      return;
    }
    if (mode === 'channel' && !isChannelTarget(normalizedChannel)) {
      showToast('❌ Invalid Channel', 'Valid Channel JID paste karein, jaise 120363...@newsletter.', 'danger');
      return;
    }
    setAppState((prev) => {
      const p = prev.profiles[pid];
      if (!p) return prev;
      return {
        ...prev,
        profiles: {
          ...prev.profiles,
          [pid]: {
            ...p,
            vipDeliveryMode: mode,
            ...(mode === 'private' && normalizedDestination ? { phone: normalizedDestination, vipSchTarget: normalizedDestination } : {}),
            vipGroupJid: mode === 'group' ? normalizedGroup : undefined,
            vipGroupName: mode === 'group' ? String(destinationName || normalizedGroup) : undefined,
            vipChannelJid: mode === 'channel' ? normalizedChannel : undefined,
            vipChannelName: mode === 'channel' ? String(destinationName || normalizedChannel) : undefined,
          },
        },
      };
    });
    lastLedgerSyncRef.current = '';
    const label = mode === 'group'
      ? `Group: ${destinationName || normalizedGroup}`
      : mode === 'channel'
        ? `Channel: ${destinationName || normalizedChannel}`
        : `Private destination: ${normalizedDestination || appState.profiles[pid]?.phone || ''}`;
    void (async () => {
      try {
        const response = await fetch(apiUrl('/api/app/profile_delivery_destination'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            profileId: pid,
            mode,
            destinationJid: normalizedDestination,
            destinationName: String(destinationName || ''),
          }),
        });
        const result = await response.json();
        if (!response.ok || result?.status !== 'success') throw new Error(result?.message || `HTTP ${response.status}`);
        showToast('✅ VIP Destination Saved', `${label} · Server confirmed`, 'success');
      } catch (error: any) {
        showToast('❌ VIP Destination Not Saved', error?.message || 'Server sync failed. Please retry.', 'danger');
      }
    })();
  };


  const handleUpdateVipScheduleEnabled = (pid: string, type: GameType, enabled: boolean) => {
    const policyKey = `${pid}|${type}`;
    const version = (schedulePolicyVersionRef.current.get(policyKey) || 0) + 1;
    schedulePolicyVersionRef.current.set(policyKey, version);
    setAppState((prev) => {
      const p = prev.profiles[pid];
      if (!p) return prev;
      const next = {
        ank: p.vipScheduleEnabled?.ank !== false,
        jodi: p.vipScheduleEnabled?.jodi !== false,
        pannel: p.vipScheduleEnabled?.pannel !== false,
        [type]: enabled,
      };
      return { ...prev, profiles: { ...prev.profiles, [pid]: { ...p, vipScheduleEnabled: next } } };
    });
    lastScheduleSyncRef.current = '';
    lastLedgerSyncRef.current = '';
    void profileMutationQueueRef.current.enqueue(`schedule-policy:${policyKey}`, () => fetch(apiUrl('/api/app/profile_schedule_policy'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...profileAuthHeaders(pid) },
      body: JSON.stringify({ profileId: pid, cardType: type, enabled }),
    })).then(async (response) => {
      const result = await response.json().catch(() => null);
      if (!response.ok || result?.status !== 'success') throw new Error(result?.message || `HTTP ${response.status}`);
    }).catch((error: any) => {
      if (schedulePolicyVersionRef.current.get(policyKey) !== version) return;
      setAppState((prev) => {
        const p = prev.profiles[pid];
        if (!p) return prev;
        const rollbackPolicy: Record<GameType, boolean> = {
          ank: p.vipScheduleEnabled?.ank !== false,
          jodi: p.vipScheduleEnabled?.jodi !== false,
          pannel: p.vipScheduleEnabled?.pannel !== false,
          [type]: !enabled,
        };
        return {
          ...prev,
          profiles: {
            ...prev.profiles,
            [pid]: { ...p, vipScheduleEnabled: rollbackPolicy },
          },
        };
      });
      lastScheduleSyncRef.current = '';
      lastLedgerSyncRef.current = '';
      showToast('❌ VIP Toggle Sync Failed', error?.message || 'Backend policy save nahi hua', 'danger');
    });
    showToast(enabled ? '🟢 VIP Broadcast ON' : '🔴 VIP Broadcast OFF', `${type.toUpperCase()} updated for ${appState.profiles[pid]?.name}`, enabled ? 'success' : 'info');
  };

  const mergePaymentSnapshot = (result:any) => setAppState(prev=>{
    const profiles={...prev.profiles};
    for(const [id,expiryDate] of Object.entries(result.expiries||{})){
      if(profiles[id])profiles[id]={...profiles[id],expiryDate:String(expiryDate)};
    }
    return {...prev,profiles,payments:result.payments||prev.payments,...(!isMasterApp&&result.paymentMethods?{paymentMethods:result.paymentMethods}:{})};
  });
  useEffect(()=>{
    if(!serverHydrated||!['payments','membership'].includes(mainNav))return;
    let disposed=false,busy=false;
    const pull=async()=>{
      if(busy||document.visibilityState==='hidden')return;
      busy=true;
      try{
        await profileMutationQueueRef.current.enqueue('payments-read',async()=>{
          const pid=activeIdRef.current;
          const response=await fetch(apiUrl('/api/app/payments'+(isMasterApp?'':'?profileId='+encodeURIComponent(pid))),{cache:'no-store',headers:isMasterApp?{}:profileAuthHeaders(pid),signal:AbortSignal.timeout(15000)});
          const result=await response.json();
          if(!disposed&&response.ok&&result.status==='success')mergePaymentSnapshot(result);
        });
      }catch{}finally{busy=false;}
    };
    void pull();const timer=setInterval(pull,10000);
    return()=>{disposed=true;clearInterval(timer);};
  },[serverHydrated,mainNav,activeId,isMasterApp]);
  const reviewPayments = async(action:'approve'|'reject',items:{id:string;days?:number}[])=>{
    if(!isMasterApp)return;
    try{
      await persistCurrentState();
      await profileMutationQueueRef.current.enqueue('payment-review',async()=>{
        const response=await fetch(apiUrl('/api/app/payments/review'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,items}),signal:AbortSignal.timeout(15000)});
        const result=await response.json();
        if(!response.ok||result.status!=='success')throw Error(result.message||'Review save failed');
        mergePaymentSnapshot(result);
      });
      showToast(action==='approve'?'✅ Approved':'Payment rejected','Admin review saved on server.',action==='approve'?'success':'info');
    }catch(error:any){showToast('Payment review failed',error.message,'danger');throw error;}
  };
  const handleApprovePayment=(paymentId:string,days:number)=>reviewPayments('approve',[{id:paymentId,days}]);
  const handleRejectPayment=(paymentId:string)=>reviewPayments('reject',[{id:paymentId}]);
  const handleApproveAllSafe=async()=>{
    const payments=appStateRef.current.payments.filter(p=>p.status==='pending'&&!['duplicate','low_amount','spam'].includes(p.autoFlag));
    if(!payments.length)return;
    if(!window.confirm('Have you manually verified bank receipt for ALL '+payments.length+' payments? UTR and screenshots alone do not confirm receipt.'))return;
    await reviewPayments('approve',payments.map(p=>({id:p.id,days:PAYMENT_PLANS[p.planLabel as keyof typeof PAYMENT_PLANS]?.days||30})));
  };
  const handleSubmitPayment=async(amount:number,utr:string,image:string,planLabel:string)=>{
    const pid=activeIdRef.current;
    try{
      const proof=validatePaymentProof({amount,utr,image,planLabel});
      await profileMutationQueueRef.current.enqueue('payment-submit:'+pid,async()=>{
        const response=await fetch(apiUrl('/api/app/payments/submit'),{method:'POST',headers:{'Content-Type':'application/json',...profileAuthHeaders(pid)},body:JSON.stringify({...proof,profileId:pid}),signal:AbortSignal.timeout(15000)});
        const result=await response.json();if(!response.ok||result.status!=='success')throw Error(result.message||'Proof save failed');
        if(activeIdRef.current===pid)setAppState(prev=>({...prev,payments:[result.payment,...prev.payments.filter(p=>p.id!==result.payment.id)]}));
      });
      showToast('✅ Proof submitted','Saved on server. Admin bank verification pending.','success');
    }catch(error:any){showToast('Payment not submitted',error.message,'danger');throw error;}
  };

  // Save Settings
  const handleSaveSettings = () => {
    lastLedgerSyncRef.current = '';
    window.dispatchEvent(new Event('titan-ledger-dirty'));
    showToast('💾 Synced', 'Visibility settings backend me auto-save hoti hain.', 'success');
  };

  const syncProfileVisibility = (
    updates: Array<{ trackDict: 'visAnk' | 'visJodi' | 'visPan'; marketName: string; enabled: boolean }>,
  ) => {
    const profileId = activeId || 'admin1';
    lastLedgerSyncRef.current = '';
    // Admin settings already update appState. Its optimistic save and runtime
    // publisher own persistence; a second endpoint races that same edit.
    if(isMasterApp)return;
    void profileMutationQueueRef.current.enqueue(`visibility:${profileId}`, () => fetch(apiUrl('/api/app/profile_visibility'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...profileAuthHeaders(profileId) },
      body: JSON.stringify({ profileId, date: currentDate, updates }),
    })).then(async (response) => {
      const result = await response.json().catch(() => null);
      if (!response.ok || result?.status !== 'success') {
        throw new Error(result?.message || `HTTP ${response.status}`);
      }
    }).catch((error: any) => {
      showToast('❌ Visibility Sync Failed', error?.message || 'Backend setting save nahi hui', 'danger');
    });
  };

  const handleResultControlToggle=(control:ResultControl)=>{
    if(!isMasterApp||!serverHydrated||bulkRestoreInFlightRef.current||currentDate>titanLocalDateISO())return;
    const state=appStateRef.current,profile=state.profiles[activeId];
    if(!profile)return;
    if((control==='CARRY6'||control==='CUT3')&&activeId!=='admin1'&&vipCopiesAdmin(profile)&&state.profiles.admin1&&carryControlMode(state.profiles.admin1,currentDate)==='CARRY6')return;
    const updated=toggleDatedResultControl(profile,currentDate,control);
    const replayed=(control==='CARRY6'||control==='CUT3')?replayResultControlDay(updated,currentDate,true):updated;
    const next={...state,profiles:{...state.profiles,[activeId]:replayed}};
    // Keep rapid taps on the latest intent. Normal autosave owns the only write.
    appStateRef.current=next;setAppState(next);
    lastLedgerSyncRef.current='';
  };

  const handleToggleResultParity=async(enabled:boolean)=>{
    if(resultParitySaving||resultParityInFlightRef.current||bulkRestoreInFlightRef.current)return;
    const profileId=activeId,date=currentDate;
    const atRequest=appStateRef.current.profiles[profileId];if(!atRequest)return;
    const historical=date<titanLocalDateISO();
    // Snapshot only this date and its settings, never the full archive.
    const baseline=historical?structuredClone({day:atRequest.dayRecords[date]||{},config:atRequest.config,changes:atRequest.customLoopChanges}):undefined;
    resultParityInFlightRef.current=true;
    setResultParitySaving(true);
    setPendingParitySetting({profileId,date,enabled});
    try{
      const result=await profileMutationQueueRef.current.enqueue(`parity:${profileId}:${date}`,async()=>{
        const response=await fetch(apiUrl('/api/app/profile_result_parity'),{method:'POST',headers:{'Content-Type':'application/json',...profileAuthHeaders(profileId)},body:JSON.stringify({profileId,date,enabled}),signal:apiDeadlineSignal(undefined,30000)});
        const result=await response.json();
        if(!response.ok||result.status!=='success'||result.profileId!==profileId||result.date!==date)throw new Error(result.message||'F/C/L-cut save acknowledgement mismatch');
        return result;
      });
      setAppState(prev=>{
        const p=prev.profiles[profileId];if(!p)return prev;
        // This response owns only the O/D setting. Another pending setup save
        // may already have changed the rest of today's configuration.
        const config=historical?p.config:{...p.config,autoResultParity:enabled};
        let dayRecords=p.dayRecords;
        if(historical&&result.day){
          const current=p.dayRecords[date]||{},restoring=bulkRestoreInFlightRef.current;
          const changed=restoring||!sameAdminValue(current,baseline!.day)||!sameAdminValue(p.config,baseline!.config)||!sameAdminValue(p.customLoopChanges,baseline!.changes);
          // Derived cards from an older input cannot overwrite an edit, result
          // correction or Undo. The normal replay uses the current inputs.
          const day=changed?{...current,backtestRecoveryPolicy:{...current.backtestRecoveryPolicy,autoResultParity:enabled},...(!restoring?{backtestRevision:Math.max(Number(current.backtestRevision||0),Number(result.day.backtestRevision||0))}:{})}:result.day;
          dayRecords={...dayRecords,[date]:day};
        }
        return {...prev,profiles:{...prev.profiles,[profileId]:{...p,config,dayRecords}}};
      });
      lastLedgerSyncRef.current='';window.dispatchEvent(new Event('titan-ledger-synced'));

    }catch(error:any){showToast('F/C/L-cut save failed',error.message,'danger');}
    finally{resultParityInFlightRef.current=false;setPendingParitySetting(null);setResultParitySaving(false);}
  };

  const handleToggleProfitNotifications = async (enabled:boolean) => {
  const profileId = activeId;
  if (!profileId || profitNotificationsSaving) return;
  setProfitNotificationsSaving(true);
  setPendingProfitSetting({profileId,enabled});
  try {
    const response = await fetch(apiUrl('/api/app/profile_profit_notifications'), {
      method: 'POST', headers: { 'Content-Type': 'application/json', ...profileAuthHeaders(profileId) },
      body: JSON.stringify({ profileId, enabled }),
    });
    const result = await response.json();
    if (!response.ok || result.status !== 'success') throw new Error(result.message || 'Save failed');
    setAppState(prev => ({ ...prev, profiles: { ...prev.profiles, [profileId]: { ...prev.profiles[profileId], profitMilestoneNotificationsEnabled: result.enabled } } }));
    showToast(enabled ? '💰 Profit Alerts ON' : '🔕 Profit Alerts OFF', 'Sirf is profile ki setting save hui.', 'success');
  } catch (error: any) { showToast('Profit Alerts Save Failed', error.message, 'danger'); }
  finally { setPendingProfitSetting(null);setProfitNotificationsSaving(false); }
  };

  const handleSaveDatedSetup = (newConfig:ProfileConfig) => {
    const owner=activeId,date=currentDate;
    if(date>titanLocalDateISO())return;
    setAppState(prev=>{
      const p=prev.profiles[owner];if(!p)return prev;
      let next=applyDatedFinancialSetup(p,date,newConfig);
      // Delivery switches remain profile-wide; never copy archive targets into live config.
      if(JSON.stringify(newConfig.scheduleTypeEnabled)!==JSON.stringify(p.config.scheduleTypeEnabled))
        next={...next,config:{...next.config,scheduleTypeEnabled:newConfig.scheduleTypeEnabled}};
      return {...prev,profiles:{...prev.profiles,[owner]:next}};
    });
    lastLedgerSyncRef.current='';
  };

  // Handle Update Profile Config
  const handleUpdateConfig = (newConfig: ProfileConfig) => {
    setAppState((prev) => ({
      ...prev,
      profiles: {
        ...prev.profiles,
        [activeId]: updateProfileMarketCatalog(prev.profiles[activeId],newConfig),
      },
    }));
  };

  const saveCustomLoops = async (body: {config?:DualLoopConfig;action?:'toggle';enabled?:boolean}):Promise<string|undefined> => {
    if(bulkRestoreInFlightRef.current)return 'Wait for Bulk Restore to finish.';
    const profileId=activeId||'admin1',date=currentDate;
    const beforeDays=appStateRef.current.profiles[profileId]?.dayRecords||{};
    try {
      const response=await profileMutationQueueRef.current.enqueue(`custom-loops:${profileId}`,()=>fetch(apiUrl('/api/app/profile_custom_loops'),{
        method:'POST',headers:{'Content-Type':'application/json',...profileAuthHeaders(profileId)},
        body:JSON.stringify({profileId,date,...body}),signal:AbortSignal.timeout(30000),
      }));
      const result=await response.json();
      if(!response.ok||result.status!=='success'||!result.profile)throw new Error(result.message||'Custom loop save failed.');
      setAppState(prev=>{
        const local=prev.profiles[profileId];if(!local)return prev;
        const saved=result.profile as UserProfile;
        return {...prev,profiles:{...prev.profiles,[profileId]:{...local,
          customLoopChanges:saved.customLoopChanges,
          config:{...local.config,dualLoops:saved.config.dualLoops},
          dayRecords:{...local.dayRecords,[date]:acknowledgedDay(beforeDays[date],saved.dayRecords[date],local.dayRecords[date]),
            ...(date!==titanLocalDateISO()&&saved.dayRecords[titanLocalDateISO()]?{[titanLocalDateISO()]:acknowledgedDay(beforeDays[titanLocalDateISO()],saved.dayRecords[titanLocalDateISO()],local.dayRecords[titanLocalDateISO()])}:{})},
        }}};
      });
      lastLedgerSyncRef.current='';lastScheduleSyncRef.current='';
      return undefined;
    } catch(error) {return error instanceof Error?error.message:'Save failed. Please retry.';}
  };
  const handleSaveDualLoops = (draft:DualLoopConfig):Promise<string|undefined> => saveCustomLoops({config:draft});

  const handleApplyYesterdayLoops = (draft: DualLoopConfig): string | undefined => {
    if(bulkRestoreInFlightRef.current)return 'Bulk Restore is running; wait for it to finish.';
    const pid=activeId||'admin1',profile=appStateRef.current.profiles[pid];
    if(!profile)return 'Profile unavailable.';
    if(!isMasterApp && profile.vipAccessEnabled===false)return 'Settings are read-only.';
    try {applyYesterdayLoopGroups(profile,currentDate,draft,false);}catch(error){return error instanceof Error?error.message:'Unable to apply yesterday groups.';}
    setAppState(prev=>{
      const current=prev.profiles[pid];if(!current)return prev;
      try {return {...prev,profiles:{...prev.profiles,[pid]:applyYesterdayLoopGroups(current,currentDate,draft,currentDate<titanLocalDateISO())}};}catch{return prev;}
    });
    lastLedgerSyncRef.current='';lastScheduleSyncRef.current='';
    showToast('Yesterday groups applied',`Latest 7-day PASS/FAIL mixed chronologically into L1/L2/L3 · no result OFF. Only ${currentDate} changed.`,'success');
    return undefined;
  };

  // Apply Protocol Targets To Today's Cards
  const handleApplyProtocolTargetsToToday = (targetType: 'all' | 'ank' | 'jodi' | 'pannel') => {
    const cfg: ProfileConfig = currentProfile.config || ({} as ProfileConfig);
    setAppState((prev) => {
      const updatedProfiles = { ...prev.profiles };
      const prof = ensureProfileStructure(updatedProfiles[activeId] || updatedProfiles['admin1'], true);
      const dayStore = { ...(prof.dayRecords[currentDate] || {}) };

      const activeMarketsList = getEffectiveMarkets(cfg);
      const activeBaseMarketsList = getEffectiveBaseMarkets(cfg);

      if (targetType === 'all' || targetType === 'ank') {
        const ankDict = { ...(dayStore.data || {}) };
        activeMarketsList.forEach((_, idx) => {
          const cur = ankDict[idx] || { s: 'WAIT', d: '', r: '' };
          if (!cur.d || cur.d.trim() === '') {
            ankDict[idx] = { ...cur, d: cfg.ankDefaultDigits || '8, 7, 6, 3, 5, 0', r: cfg.ankDefaultRate || '10' };
          }
        });
        dayStore.data = ankDict;
      }

      if (targetType === 'all' || targetType === 'jodi') {
        const jodiDict = { ...(dayStore.jodiData || {}) };
        activeBaseMarketsList.forEach((_, idx) => {
          const cur = jodiDict[idx] || { s: 'WAIT', d: '', r: '' };
          if (!cur.d || cur.d.trim() === '') {
            jodiDict[idx] = { ...cur, d: cfg.jodiDefaultDigits || '12, 34, 56, 78, 90', r: cfg.jodiDefaultRate || '10' };
          }
        });
        dayStore.jodiData = jodiDict;
      }

      if (targetType === 'all' || targetType === 'pannel') {
        const panDict = { ...(dayStore.pannelData || {}) };
        activeMarketsList.forEach((_, idx) => {
          const cur = panDict[idx] || { s: 'WAIT', d: '', r: '' };
          if (!cur.d || cur.d.trim() === '') {
            panDict[idx] = { ...cur, d: cfg.pannelDefaultDigits || '123, 456, 789, 147', r: cfg.pannelDefaultRate || '10' };
          }
        });
        dayStore.pannelData = panDict;
      }

      prof.dayRecords[currentDate] = dayStore;
      updatedProfiles[activeId] = prof;
      return { ...prev, profiles: updatedProfiles };
    });

    showToast('⚡ Targets Applied', `Default protocol digits and rates applied to today's cards!`, 'success');
  };

  const vipCanEdit = currentProfile.vipAccessEnabled !== false;
  const handleToggleVipGame = async (enabled: boolean) => {
    if (activeId === 'admin1' || vipGameBusyRef.current || !['ank', 'jodi', 'pannel'].includes(activeTab)) return;
    const pid = activeId;
    vipGameBusyRef.current=true;
    setPendingVipGame({profileId:pid,date:currentDate,type:activeTab as GameType,enabled});
    setVipGameSaving(true);
    try {
      const response = await fetch(apiUrl('/api/app/vip_game_run'), {
        method: 'POST', signal:AbortSignal.timeout(15000), headers: { 'Content-Type': 'application/json', ...profileAuthHeaders(pid) },
        body: JSON.stringify({ profileId: pid, cardType: activeTab, date: currentDate, enabled }),
      });
      const json = await response.json();
      if (!response.ok || json.status !== 'success' || !json.profile) throw new Error(json.message || 'Game control failed');
      setAppState(prev => ({ ...prev, profiles: { ...prev.profiles, [pid]: json.profile } }));
      lastLedgerSyncRef.current = '';
      window.dispatchEvent(new Event('titan-ledger-synced'));
      showToast(enabled ? '▶ VIP game ON' : '⏸ VIP game OFF', enabled ? `New limit cycle started · ${json.resumedCards||0} cards restored · ${json.missedCards||0} past/disabled cards kept SKIP. Financial history preserved.` : 'Unsent cards paused.', 'success');
    } catch (error: any) { showToast('Game control failed', error?.message || 'Retry', 'danger'); }
    finally { vipGameBusyRef.current=false;setPendingVipGame(null);setVipGameSaving(false); }
  };

  // Pending preference feedback is view-only. The model changes after server ACK.
  const displayedProfitSetting = pendingProfitSetting?.profileId === activeId
    ? pendingProfitSetting.enabled : currentProfile.profitMilestoneNotificationsEnabled === true;
  const inheritedCarrySetting=activeId!=='admin1'&&vipCopiesAdmin(currentProfile)&&!!appState.profiles.admin1&&carryControlMode(appState.profiles.admin1,currentDate)==='CARRY6';
  const confirmedParitySetting = ((currentDate < titanLocalDateISO() ? currentProfile.dayRecords[currentDate]?.backtestRecoveryPolicy?.autoResultParity : undefined) ?? (currentDate<titanLocalDateISO()?currentProfile.dayRecords[currentDate]?.recoveryConfigSnapshot||currentProfile.config:currentProfile.config).autoResultParity === true);
  const displayedParitySetting = pendingParitySetting?.profileId === activeId && pendingParitySetting.date === currentDate
    ? pendingParitySetting.enabled : confirmedParitySetting;

  if (!serverHydrated) return <main style={{ padding: 32, color: 'white', background: '#17212B', minHeight: '100vh' }}>
    <h2>TITAN NOVA</h2>
    <p role={hydrationError ? 'alert' : 'status'}>{hydrationError || 'Workspace data loading…'}</p>
    {hydrationError && <button type="button" onClick={() => setHydrationAttempt(n => n + 1)}>Retry loading</button>}
  </main>;

  return (
    <div className="app-shell min-h-screen bg-[#17212B] text-white font-sans antialiased pb-[80px]">
      {/* Toast Stack */}
      <ToastContainer toasts={toasts} onClose={removeToast} />
      {isMasterApp && <SaveStatusIndicator store={saveStatusStoreRef.current} onRetry={() => {
        saveStatusStoreRef.current.set({phase:'pending'});
        stateSaverRef.current?.retry();
        window.dispatchEvent(new Event('titan-retry-serialize'));
      }} />}

      {/* Branding and ledger tabs stay together while the page scrolls. */}
      <div className="app-ledger-topbar">
      <Header
        isMaster={isMasterApp}
        activeId={activeId}
        activeProfile={currentProfile}
        currentDate={currentDate}
        onDateChange={handleDateChange}
        todayBacktest={todayBacktest}
        onToggleTodayBacktest={() => setTodayBacktest((enabled) => !enabled)}
        showTodayBacktest={currentDate === titanLocalDateISO()}
        onToggleSidebar={() => setIsSidebarOpen(true)}
        onBackToMaster={() => {
          setAppState((prev) => ({ ...prev, activeId: 'admin1' }));
          setMainNav('clients');
        }}
        onRequestNotificationPermission={requestNotificationPermission}
        onShowInstallModal={() => setIsInstallModalOpen(true)}
        showSplitToggle={mainNav === 'ledger' && (activeTab === 'ank' || activeTab === 'pannel')}
        splitChecked={useTwoCardRecovery(currentDate<titanLocalDateISO()?currentProfile.dayRecords[currentDate]?.recoveryConfigSnapshot||currentProfile.config:currentProfile.config,currentDate,activeTab)}
        onToggleSplit={(checked) => {
          setAppState((prev) => {
            const original=prev.profiles[activeId];
            if (!original) return prev;
            const day=original.dayRecords[currentDate]||{};
            const baseline=currentDate<titanLocalDateISO()?day.recoveryConfigSnapshot||original.config:original.config;
            const patch = activeTab==='ank'
              ? { ankSplit: checked, ...(checked ? { fourWaveRelay: false } : {}) }
              : { panSplit: checked, ...(checked ? { fourWaveRelay: false } : {}) };
            const config={...baseline,
              sameMarketRecovery: true,
              twoCardRecoveryFrom:currentDate,
              twoCardRecoveryLegacySplit:baseline.twoCardRecoveryLegacySplit||{ank:baseline.ankSplit!==false,pannel:baseline.panSplit!==false},
              ...patch};
            const updatedDayRecords: typeof original.dayRecords = { ...original.dayRecords };
            for (const [dKey, dVal] of Object.entries(updatedDayRecords)) {
              if (dKey >= currentDate && dVal?.recoveryConfigSnapshot) {
                updatedDayRecords[dKey] = {
                  ...dVal,
                  recoveryConfigSnapshot: { ...dVal.recoveryConfigSnapshot, sameMarketRecovery: true, ...patch },
                };
              }
            }
            updatedDayRecords[currentDate] = {
              ...(updatedDayRecords[currentDate] || day),
              recoveryConfigSnapshot: config,
              backtestRevision: Math.max(Date.now(), Number(day.backtestRevision || 0) + 1),
            };
            let prof: UserProfile = {
              ...original,
              config: { ...original.config, sameMarketRecovery: true, ...patch },
              dayRecords: updatedDayRecords,
            };
            if (currentDate < titanLocalDateISO()) {
              prof = calculateBacktestRecovery(prof, currentDate);
            } else {
              const autoUpdated = applyAutoRatesToDayStore(prof, currentDate, prev.profiles);
              if (autoUpdated) prof.dayRecords[currentDate] = autoUpdated;
            }
            return {...prev,profiles:{...prev.profiles,[activeId]:prof}};
          });
          lastLedgerSyncRef.current = '';
        }}
        profitCarryChecked={Boolean((currentDate<titanLocalDateISO()?currentProfile.dayRecords[currentDate]?.backtestRecoveryPolicy?.profitCarry??(currentProfile.dayRecords[currentDate]?.recoveryConfigSnapshot||currentProfile.config)?.profitCarry:currentProfile.config?.profitCarry??currentProfile?.profitCarry))}
        onToggleProfitCarry={(checked) => {
          setAppState((prev) => {
            const original=prev.profiles[activeId];
            if (!original) return prev;
            const day=original.dayRecords[currentDate]||{};
            const patch = { profitCarry: checked };
            const updatedDayRecords: typeof original.dayRecords = { ...original.dayRecords };
            for (const [dKey, dVal] of Object.entries(updatedDayRecords)) {
              if (dKey >= currentDate && dVal?.recoveryConfigSnapshot) {
                updatedDayRecords[dKey] = {
                  ...dVal,
                  recoveryConfigSnapshot: { ...dVal.recoveryConfigSnapshot, ...patch },
                };
              }
            }
            if (currentDate < titanLocalDateISO()) {
              const currentPolicy = day.backtestRecoveryPolicy || { resetAfterThreeFails: false, maxStake: 0 };
              updatedDayRecords[currentDate] = {
                ...day,
                backtestRecoveryPolicy: { ...currentPolicy, ...patch },
                recoveryConfigSnapshot: { ...(day.recoveryConfigSnapshot || original.config), ...patch },
              };
            }
            let prof: UserProfile = {
              ...original,
              config: { ...original.config, ...patch },
              profitCarry: checked,
              dayRecords: updatedDayRecords,
            };
            if (currentDate < titanLocalDateISO()) {
              prof = calculateBacktestRecovery(prof, currentDate);
            } else {
              const autoUpdated = applyAutoRatesToDayStore(prof, currentDate, prev.profiles);
              if (autoUpdated) prof.dayRecords[currentDate] = autoUpdated;
            }
            return {...prev,profiles:{...prev.profiles,[activeId]:prof}};
          });
          lastLedgerSyncRef.current = '';
        }}
        openPassCloseZeroChecked={Boolean((currentDate<titanLocalDateISO()?currentProfile.dayRecords[currentDate]?.backtestRecoveryPolicy?.openPassCloseZero??(currentProfile.dayRecords[currentDate]?.recoveryConfigSnapshot||currentProfile.config)?.openPassCloseZero:currentProfile.config?.openPassCloseZero??currentProfile?.openPassCloseZero))}
        onToggleOpenPassCloseZero={(checked) => {
          setAppState((prev) => {
            const original=prev.profiles[activeId];
            if (!original) return prev;
            const day=original.dayRecords[currentDate]||{};
            const patch = { openPassCloseZero: checked };
            const updatedDayRecords: typeof original.dayRecords = { ...original.dayRecords };
            for (const [dKey, dVal] of Object.entries(updatedDayRecords)) {
              if (dKey >= currentDate && dVal?.recoveryConfigSnapshot) {
                updatedDayRecords[dKey] = {
                  ...dVal,
                  recoveryConfigSnapshot: { ...dVal.recoveryConfigSnapshot, ...patch },
                };
              }
            }
            if (currentDate < titanLocalDateISO()) {
              const currentPolicy = day.backtestRecoveryPolicy || { resetAfterThreeFails: false, maxStake: 0 };
              updatedDayRecords[currentDate] = {
                ...day,
                backtestRecoveryPolicy: { ...currentPolicy, ...patch },
                recoveryConfigSnapshot: { ...(day.recoveryConfigSnapshot || original.config), ...patch },
              };
            }
            let prof: UserProfile = {
              ...original,
              config: { ...original.config, ...patch },
              openPassCloseZero: checked,
              dayRecords: updatedDayRecords,
            };
            if (currentDate < titanLocalDateISO()) {
              prof = calculateBacktestRecovery(prof, currentDate);
            } else {
              const autoUpdated = applyAutoRatesToDayStore(prof, currentDate, prev.profiles);
              if (autoUpdated) prof.dayRecords[currentDate] = autoUpdated;
            }
            return {...prev,profiles:{...prev.profiles,[activeId]:prof}};
          });
          lastLedgerSyncRef.current = '';
        }}
        fourWaveChecked={Boolean((currentDate<titanLocalDateISO()?currentProfile.dayRecords[currentDate]?.recoveryConfigSnapshot||currentProfile.config:currentProfile.config)?.fourWaveRelay)}
        onToggleFourWave={(checked) => {
          setAppState((prev) => {
            const original=prev.profiles[activeId];
            if (!original) return prev;
            const day=original.dayRecords[currentDate]||{};
            const baseline=currentDate<titanLocalDateISO()?day.recoveryConfigSnapshot||original.config:original.config;
            const patch = checked
              ? { fourWaveRelay: true, ankSplit: false, panSplit: false }
              : { fourWaveRelay: false };
            const config={...baseline, ...patch};
            const updatedDayRecords: typeof original.dayRecords = { ...original.dayRecords };
            for (const [dKey, dVal] of Object.entries(updatedDayRecords)) {
              if (dKey >= currentDate && dVal?.recoveryConfigSnapshot) {
                updatedDayRecords[dKey] = {
                  ...dVal,
                  recoveryConfigSnapshot: { ...dVal.recoveryConfigSnapshot, ...patch },
                };
              }
            }
            updatedDayRecords[currentDate] = {
              ...(updatedDayRecords[currentDate] || day),
              recoveryConfigSnapshot: config,
              backtestRevision: Math.max(Date.now(), Number(day.backtestRevision || 0) + 1),
            };
            let prof: UserProfile = {
              ...original,
              config: { ...original.config, ...patch },
              dayRecords: updatedDayRecords,
            };
            if (currentDate < titanLocalDateISO()) {
              prof = calculateBacktestRecovery(prof, currentDate);
            } else {
              const autoUpdated = applyAutoRatesToDayStore(prof, currentDate, prev.profiles);
              if (autoUpdated) prof.dayRecords[currentDate] = autoUpdated;
            }
            return {...prev,profiles:{...prev.profiles,[activeId]:prof}};
          });
          lastLedgerSyncRef.current = '';
        }}
      />

      {mainNav === 'ledger' && <div className="w-full max-w-2xl mx-auto">
            {/* Protocol Tabs */}
            <div className="pill-tabs flex bg-[#232E3C] p-2 gap-1.5 border-b border-[rgba(255,255,255,0.07)] overflow-x-auto no-scrollbar">
              <button type="button"
                onClick={() => setActiveTab('ank')}
                className={`pill-tab flex-1 text-center py-2 text-[11px] font-bold uppercase rounded-lg transition-all ${
                  activeTab === 'ank' ? 'active bg-[rgba(42,171,238,0.15)] text-[#2AABEE] border-b-2 border-[#2AABEE]' : 'text-[#7A9CB8]'
                }`}
              >
                Ank <span className="text-[9px] opacity-60 ml-1">x9.5</span>
              </button>
              <button type="button"
                onClick={() => setActiveTab('jodi')}
                className={`pill-tab flex-1 text-center py-2 text-[11px] font-bold uppercase rounded-lg transition-all ${
                  activeTab === 'jodi' ? 'active bg-[rgba(184,92,255,0.15)] text-[#B85CFF] border-b-2 border-[#B85CFF]' : 'text-[#7A9CB8]'
                }`}
              >
                Jodi <span className="text-[9px] opacity-60 ml-1">x95</span>
              </button>
              <button type="button"
                onClick={() => setActiveTab('pannel')}
                className={`pill-tab flex-1 text-center py-2 text-[11px] font-bold uppercase rounded-lg transition-all ${
                  activeTab === 'pannel' ? 'active bg-[rgba(250,199,72,0.15)] text-[#FAC748] border-b-2 border-[#FAC748]' : 'text-[#7A9CB8]'
                }`}
              >
                Pannel <span className="text-[9px] opacity-60 ml-1">x150</span>
              </button>
              <button type="button"
                onClick={() => setActiveTab('market_manager')}
                className={`pill-tab flex-1 text-center py-2 text-[11px] font-bold uppercase rounded-lg transition-all ${
                  activeTab === 'market_manager' ? 'active bg-[rgba(42,171,238,0.15)] text-[#2AABEE] border-b-2 border-[#2AABEE]' : 'text-[#7A9CB8]'
                }`}
              >
                🌐 Market
              </button>
              <button type="button"
                onClick={() => setActiveTab('setup')}
                className={`pill-tab flex-1 text-center py-2 text-[11px] font-bold uppercase rounded-lg transition-all ${
                  activeTab === 'setup' ? 'active bg-[rgba(0,194,111,0.15)] text-[#00C26F] border-b-2 border-[#00C26F]' : 'text-[#7A9CB8]'
                }`}
              >
                ⚙️ Setup
              </button>
              {isMasterApp&&<button type="button" onClick={()=>setActiveTab('backtest')} className={`pill-tab flex-1 shrink-0 text-center px-2 py-2 text-[11px] font-bold uppercase rounded-lg ${activeTab==='backtest'?'bg-[#147D91] text-white':'text-[#7A9CB8]'}`}>BACKTEST</button>}
            </div>

      </div>}
      </div>

      {isMasterApp&&serverHydrated&&<BackgroundBacktestStatus profileId={activeId} profileNames={Object.fromEntries(Object.entries(appState.profiles).map(([id,p])=>[id,p.name]))} onOpen={pid=>void openBacktestRunProfile(pid)}/>}

      {/* Sliding Sidebar */}
      <Sidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        onShowInstallModal={() => setIsInstallModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className={`w-full ${mainNav === 'bot' ? 'max-w-[1200px]' : 'max-w-2xl'} mx-auto`}>
        {/* Ledger View */}
        {(
          <div hidden={mainNav !== 'ledger'}>
            {/* Content Based on Selected Tab */}
            {isMasterApp && <PreparedView key={`backtest-${activeId}`} active={mainNav === 'ledger' && activeTab === 'backtest'} freeze={false}>{() => (<div className="p-3 space-y-3"><h1 className="text-lg font-bold text-white">Backtest Lab</h1><p className="text-xs text-[#8DA6C0]">Choose a logic, run a fresh test, and compare saved results. Stop before clearing a trial.</p>                  {isMasterApp && <RangeBacktestPanel visible={mainNav === 'ledger' && activeTab === 'backtest'} marketChoices={rangeMarketChoices(currentProfile.config)} onOpenRunProfile={pid=>void openBacktestRunProfile(pid)} key={activeId} autoRemoveResultDigit={appState.profiles[activeId]?.config.autoRemoveResultDigit===true} autoRemoveResultMirror={appState.profiles[activeId]?.config.autoRemoveResultMirror===true} autoRemoveResultUnique3={appState.profiles[activeId]?.config.autoRemoveResultUnique3===true}
                    onAutoRemoveChange={enabled=>setAppState(prev=>{const p=prev.profiles[activeId];return {...prev,profiles:{...prev.profiles,[activeId]:{...p,config:{...p.config,autoRemoveResultDigit:enabled,autoRemoveResultMirror:false,autoRemoveResultUnique3:false}}}};})}
                    profileId={activeId} disabled={Boolean(bulkAction)||!serverHydrated}
                    beforeRun={async () => {
                      await persistCurrentState();
                    }}
                    onArchive={state=>setAppState(prev=>preserveRangeArchive(prev,state))}
                    onOpenDate={date=>{setAutoBacktestResult(false);handleDateChange(date);setActiveTab('ank');}}
                  />}
</div>)}</PreparedView>}
            <PreparedView key={`market-${activeId}`} active={mainNav === 'ledger' && activeTab === 'market_manager'}>{() => (
              <MarketManager
                profile={currentProfile}
                currentDate={currentDate}
                onUpdateConfig={handleUpdateConfig}
                onToggleMasterMarket={(baseMarketName, enabled) => {
                  const profileId = activeId || 'admin1';
                  const toggleKey = `${profileId}|${currentDate}|${String(baseMarketName).trim().toUpperCase()}`;
                  const toggleVersion = (marketToggleVersionRef.current.get(toggleKey) || 0) + 1;
                  marketToggleVersionRef.current.set(toggleKey, toggleVersion);
                  setAppState((prev) => applyProfileMarketToggle(prev, profileId, baseMarketName, enabled, currentDate));
                  lastLedgerSyncRef.current = '';

                  // Admin optimistic workspace save already persists this exact
                  // switch. A parallel endpoint is a second writer and can
                  // revert a newer setting through its acknowledgement/error.
                  if(isMasterApp)return;

                  void profileMutationQueueRef.current.enqueue(`market:${toggleKey}`, () => fetch(apiUrl('/api/app/profile_market_toggle'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', ...profileAuthHeaders(profileId) },
                    body: JSON.stringify({ profileId, baseMarketName, enabled, date: currentDate }),
                  })).then(async (response) => {
                    const result = await response.json().catch(() => null);
                    if (!response.ok || result?.status !== 'success' || !result?.profile) {
                      throw new Error(result?.message || (response.ok?'Invalid market API response; reload app and verify server version':`HTTP ${response.status}`));
                    }
                    if (marketToggleVersionRef.current.get(toggleKey) !== toggleVersion) return;
                    // Re-apply only this acknowledged key. Replacing the whole
                    // profile could roll back another fast toggle.
                    setAppState((prev) => applyProfileMarketToggle(prev, profileId, baseMarketName, enabled, currentDate));
                  }).catch((error: any) => {
                    if (marketToggleVersionRef.current.get(toggleKey) !== toggleVersion) return;
                    // Never leave a misleading UI-only toggle after rejection.
                    setAppState((prev) => applyProfileMarketToggle(prev, profileId, baseMarketName, !enabled, currentDate));
                    showToast('❌ Market Sync Failed', error?.message || 'Backend market setting save nahi hua', 'danger');
                  });
                }}
                onShowToast={showToast}
              />
            )}</PreparedView>
            <PreparedView key={`setup-${activeId}-${currentDate}`} active={mainNav === 'ledger' && activeTab === 'setup'}>{() => (
              <AnkJodiPanelSetup
                key={`setup-${activeId}-${currentDate}`}
                profile={currentProfile}
                archiveRecoverySaving={archiveRecoverySaving}
                onToggleArchiveRecovery={async(enabled)=>{
                  if(archiveRecoverySaving)return;
                  const profileId=activeId,date=currentDate;
                  const beforeDay=appStateRef.current.profiles[profileId]?.dayRecords?.[date];
                  setArchiveRecoverySaving(true);
                  try{
                    const response=await profileMutationQueueRef.current.enqueue(`archive-reset:${profileId}:${date}`,()=>fetch(apiUrl('/api/app/archive_recovery_reset'),{method:'POST',headers:{'Content-Type':'application/json',...profileAuthHeaders(profileId)},body:JSON.stringify({profileId,date,enabled})}));
                    const result=await response.json();
                    if(!response.ok||result.status!=='success')throw new Error(result.message||'Save failed');
                    setAppState(prev=>{const profile=prev.profiles[profileId];if(!profile)return prev;return {...prev,profiles:{...prev.profiles,[profileId]:{...profile,dayRecords:{...profile.dayRecords,[date]:acknowledgedDay(beforeDay,result.day,profile.dayRecords[date])}}}};});
                    showToast('Historical reset saved',`${date} · ${enabled?'ON':'OFF'} · settled stakes unchanged`,'success');
                  }catch(error:any){showToast('Historical reset save failed',error.message,'danger');}
                  finally{setArchiveRecoverySaving(false);}
                }}
                // BUG FIX: ANK/JODI/PANEL schedule toggles belong to Admin Setup only;
                // every VIP keeps its sole toggle authority on the VIP profile card.
                showAdminScheduleControls={isMasterApp && (activeId || 'admin1') === 'admin1'}
                currentDate={currentDate}
                globalStats={globalStats}
                onUpdateConfig={handleSaveDatedSetup}
                onSaveDualLoops={handleSaveDualLoops}
                onToggleCustomLoops={enabled=>saveCustomLoops({action:'toggle',enabled})}
                onApplyYesterdayLoops={handleApplyYesterdayLoops}
                canEditLoops={isMasterApp || currentProfile.vipAccessEnabled !== false}
                onApplyProtocolTargetsToToday={handleApplyProtocolTargetsToToday}
                onShowToast={showToast}
                cardSenderSaving={cardSenderSaving}
                pendingCardSenderFormat={pendingSenderFormat?.profileId===activeId ? pendingSenderFormat : undefined}
                onChangeCardSenderFormat={async (format,platform)=>{
                  if(cardSenderBusyRef.current)return;
                  const profileId=activeId||'admin1';cardSenderBusyRef.current=true;setCardSenderSaving(true);setPendingSenderFormat({profileId,format,platform});
                  try{
                    const response=await profileMutationQueueRef.current.enqueue(`sender:${profileId}`,()=>fetch(apiUrl('/api/app/profile_card_sender_format'),{method:'POST',headers:{'Content-Type':'application/json',...profileAuthHeaders(profileId)},body:JSON.stringify({profileId,cardSenderFormat:format,platform})}));
                    const result=await response.json();if(!response.ok||result.status!=='success')throw new Error(result.message||'Save failed');
                    setAppState(prev=>applyProfileCardSenderFormat(prev,profileId,format,platform));
                    lastScheduleSyncRef.current='';lastLedgerSyncRef.current='';
                    showToast('Card Sender Saved',`${platform==='whatsapp'?'WhatsApp':'Telegram'} · ${format==='text'?'TXT':'PNG'} · Sirf is profile ke cards`, 'success');
                  }catch(error:any){showToast('Sender Save Failed',error.message,'danger');}
                  finally{setPendingSenderFormat(null);cardSenderBusyRef.current=false;setCardSenderSaving(false);}
                }}
                detailedMessage={currentProfile.config?.detailedMessage !== false}
                copyAdminEnabled={activeId !== 'admin1' ? currentProfile.vipCopyAdmin !== false : undefined}
                onToggleCopyAdmin={activeId !== 'admin1' ? handleToggleVipCopyAdmin : undefined}
                onClearAdminCopy={activeId !== 'admin1' ? handleClearVipAdminMirror : undefined}
                onTakeAdminSnapshot={activeId !== 'admin1' && isMasterApp ? handleTakeVipAdminSnapshot : undefined}
                adminSnapshotBusy={adminSnapshotBusy}
                adminSnapshotProgress={adminSnapshotProgress}
                onToggleDetailedMessage={(enabled) => {
                  const profileId = activeId || 'admin1';
                  const version = (messageFormatVersionRef.current.get(profileId) || 0) + 1;
                  messageFormatVersionRef.current.set(profileId, version);
                  setAppState((prev) => applyProfileMessageFormat(prev, profileId, enabled));
                  lastScheduleSyncRef.current = '';
                  lastLedgerSyncRef.current = '';

                  void profileMutationQueueRef.current.enqueue(`format:${profileId}`, () => fetch(apiUrl('/api/app/profile_message_format'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', ...profileAuthHeaders(profileId) },
                    body: JSON.stringify({ profileId, detailedMessage: enabled }),
                  })).then(async (response) => {
                    const result = await response.json().catch(() => null);
                    if (!response.ok || result?.status !== 'success') {
                      throw new Error(result?.message || `HTTP ${response.status}`);
                    }
                    if (messageFormatVersionRef.current.get(profileId) !== version) return;
                    setAppState((prev) => applyProfileMessageFormat(prev, profileId, enabled));
                  }).catch((error: any) => {
                    if (messageFormatVersionRef.current.get(profileId) !== version) return;
                    setAppState((prev) => applyProfileMessageFormat(prev, profileId, !enabled));
                    showToast('❌ Format Sync Failed', error?.message || 'Backend message format save nahi hua', 'danger');
                  });
                  showToast(
                    enabled ? '✅ Detailed Message ON' : '✅ Simple Message ON',
                    enabled ? 'WhatsApp/Telegram par Rate, Total aur detailed result premium box me dikhega.' : 'WhatsApp/Telegram par sirf Market, Digits aur simple PASS/FAIL premium box me dikhega.',
                    'success',
                  );
                }}
              />
            )}</PreparedView>
            {(['ank','jodi','pannel'] as GameType[]).map(gameTab => <PreparedView key={`${activeId}-${gameTab}`} active={mainNav === 'ledger' && activeTab === gameTab}>{() => (
            <div data-ledger-game-view={gameTab}>
              <>
                {/* Wallet HUD */}
                <WalletHUD
                  activeTab={gameTab as GameType}
                  stats={
                    gameTab === 'ank'
                      ? globalStats.ank
                      : gameTab === 'jodi'
                        ? globalStats.jodi
                        : globalStats.pannel
                  }
                  profile={currentProfile}
                  currentDate={currentDate}
                  vipGameOn={pendingVipGame?.profileId===activeId&&pendingVipGame.date===currentDate&&pendingVipGame.type===gameTab?pendingVipGame.enabled:(currentProfile.vipGameRuns?.[gameTab as GameType]?.on !== false || (dayLoopConfig(currentProfile,currentDate)?.independentAccounts===true&&['TARGET_REACHED','CAPITAL_LIMIT'].includes(currentProfile.vipGameRuns?.[gameTab as GameType]?.reason||'')))}
                  vipGamePending={pendingVipGame?.profileId===activeId&&pendingVipGame.date===currentDate&&pendingVipGame.type===gameTab}
                  vipStopReason={currentProfile.vipGameRuns?.[gameTab as GameType]?.reason}
                  onToggleVipGame={activeId !== 'admin1' ? handleToggleVipGame : undefined}
                  vipGameDisabled={vipGameSaving || currentDate !== titanLocalDateISO() || (!isMasterApp && !vipCanEdit)}
                />

                {/* Search, Status Filter & Grid Toggle Bar */}
                <div className="px-3 pt-2 space-y-2">
                  <div className="result-control-row" aria-label="Result controls" data-profile-view={isMasterApp?'admin':'vip'}>
                  {isMasterApp && gameTab === 'ank' && (['CARRY6','CUT3'] as const).map(mode=>(
                    <button key={mode} type="button" aria-label={mode==='CARRY6'?'Carry 5':'Cut 5'}
                      aria-pressed={mode==='CARRY6'?inheritedCarrySetting||displayedCarryMode==='CARRY6':displayedCarryMode==='CUT3'}
                      disabled={inheritedCarrySetting||bulkRestoreInFlightRef.current}
                      title={mode==='CARRY6'?'Toggle Carry 5 adaptive actual digits directly (50% probability).':'Toggle Cut 5 unique actual digits directly (50% probability).'}
                      onClick={()=>handleResultControlToggle(mode)}>
                      <span>{mode==='CARRY6'?'Carry 5':'Cut 5'}</span>
                      <span className="result-control-state">{inheritedCarrySetting?(mode==='CARRY6'?'ADMIN ON':'OFF'):displayedCarryMode===mode?'ON':'OFF'}</span>
                    </button>
                  ))}
                  {isMasterApp && gameTab === 'ank' && (['RESULT','RESULT + MIRROR'] as const).map(mode=>(
                    <button key={mode} type="button" aria-label={mode==='RESULT'?'Cut Result':'Cut Result + Mirror'}
                      aria-pressed={resultRemovalMode(displayedResultRemoval)===mode}
                      disabled={bulkRestoreInFlightRef.current}
                      title={mode==='RESULT'?'Toggle previous confirmed result digit cut directly.':'Toggle previous confirmed result digit and mirror cut directly.'}
                      onClick={()=>handleResultControlToggle(mode)}>
                      <span>{mode==='RESULT'?'Cut Result':'Result + Mirror'}</span>
                      <span className="result-control-state">{resultRemovalMode(displayedResultRemoval)===mode?'ON':'OFF'}</span>
                    </button>
                  ))}
                  {isMasterApp&&gameTab==='ank'&&<button type="button" aria-label="Open result cut from same market Close" aria-pressed={currentProfile.dayRecords[currentDate]?.openToCloseCut===true}
                    disabled={bulkRestoreInFlightRef.current}
                    title="Same date and market: actual OPEN digit cuts from editable CLOSE only. No mirror. OFF restores this cut’s saved input and recalculates."
                    onClick={()=>setAppState(prev=>{const p=prev.profiles[activeId];return p?{...prev,profiles:{...prev.profiles,[activeId]:toggleOpenToCloseCut(p,currentDate)}}:prev;})}>
                    <span>Open → Close Cut</span><span className="result-control-state">{currentProfile.dayRecords[currentDate]?.openToCloseCut?'ON':'OFF'}</span>
                  </button>}
                  {gameTab==='ank'&&(isMasterApp||currentProfile.vipAccessEnabled!==false)&&<button type="button" disabled={resultParitySaving||bulkRestoreInFlightRef.current} aria-busy={resultParitySaving}
                    aria-label="F/C/L-cut" title="FAIL keeps the cut; PASS switches it. OPEN and loop disagree: cut first 2 + last 2."
                    aria-pressed={displayedParitySetting}
                    onClick={()=>void handleToggleResultParity(!displayedParitySetting)}>
                    <span>2 · F/C/L-cut</span><span className="result-control-state">{displayedParitySetting?'ON':'OFF'}</span>
                  </button>}
                  {isMasterApp && <button type="button" aria-label="Auto backtest result" aria-pressed={currentDate<titanLocalDateISO()&&autoBacktestResult} aria-busy={backtestChecking}
                    disabled={currentDate >= titanLocalDateISO() || bulkAction === 'cards:restore'}
                    onClick={() => {
                      if(!autoBacktestResult)setAppState(prev=>{const profile=prev.profiles[activeId];if(!profile)return prev;const next=holdBacktestDaySelections(profile,currentDate,true);return next===profile?prev:{...prev,profiles:{...prev.profiles,[activeId]:next}};});
                      setAutoBacktestResult(v=>!v); }}
                    title="Past date only: automatically check selected digits against actual results">
                    <span>3 · Test</span><span className="result-control-state">{backtestChecking&&<i className="result-control-spinner"/>}{currentDate<titanLocalDateISO()&&autoBacktestResult?'ON':'OFF'}</span>
                  </button>}
                  {isMasterApp && <button type="button" aria-label="Bulk restore all cards" aria-busy={false}
                    disabled={Boolean(bulkAction&&bulkAction!=='cards:restore')||currentDate>=titanLocalDateISO()} onClick={handleBulkRestoreBacktest}
                    title="Past date: restore all ANK/JODI/PANEL cards; keep digits/settings; Auto Result OFF">
                    <span>4 · Undo</span><span className="result-control-state">All cards</span>
                  </button>}
                  {isMasterApp && <button type="button" aria-label="Recheck results" aria-busy={backtestChecking}
                    disabled={!autoBacktestResult||currentDate>=titanLocalDateISO()||backtestChecking||bulkAction==='cards:restore'}
                    title="Fetch selected date results again; enable Auto test on a past date"
                    onClick={()=>{backtestActualCache.current.clear();backtestLookups.current.clear();setBacktestRetry(v=>v+1);}}>
                    <span>5 · Check</span><span className="result-control-state">{backtestChecking?<><i className="result-control-spinner"/>Wait</>:'Results'}</span>
                  </button>}
                  <button type="button" aria-label="Profit Milestone Notifications" aria-pressed={currentDate===titanLocalDateISO()&&displayedProfitSetting} aria-busy={profitNotificationsSaving}
                    disabled={currentDate!==titanLocalDateISO()||profitNotificationsSaving||(!isMasterApp&&currentProfile.vipAccessEnabled===false)} title="Live profile alerts: edit from today only · Alerts for new ₹1,000 profit milestones" onClick={()=>void handleToggleProfitNotifications(currentProfile.profitMilestoneNotificationsEnabled!==true)}>
                    <span>6 · Profit</span><span className="result-control-state">{profitNotificationsSaving&&<i className="result-control-spinner"/>}{currentDate!==titanLocalDateISO()?'LIVE ONLY':displayedProfitSetting?'ON':'OFF'}</span>
                  </button>
                  <button type="button" aria-label="Live 3 fail recovery reset" aria-pressed={currentDate===titanLocalDateISO()&&currentProfile.config.liveThreeFailReset===true}
                    disabled={currentDate!==titanLocalDateISO()||(!isMasterApp&&currentProfile.vipAccessEnabled===false)} title="LIVE 3 FAIL RESET · This profile's live recovery only; historical reset stays separate"
                    onClick={()=>{const enabled=currentProfile.config.liveThreeFailReset!==true;handleUpdateConfig({...currentProfile.config,liveThreeFailReset:enabled});showToast('Live recovery updated',enabled?'Third FAIL closes this track’s recovery cycle. Next eligible unsent card uses base rate; old loss remains.':'Existing recovery continues without the 3 FAIL reset.','success');}}>
                    <span>7 · Reset</span><span className="result-control-state">{currentDate!==titanLocalDateISO()?'LIVE ONLY':currentProfile.config.liveThreeFailReset?'ON':'OFF'}</span>
                  </button>
                  </div>
                  {isMasterApp && autoBacktestResult && currentDate < titanLocalDateISO() && <p className="text-[9px] text-[#8DA6C0]">Missing or partial results retry every 30 seconds while this page is visible.</p>}
                  {backtestChecking && <div className="text-[9px] text-[#8DC8FF]">Checking selected date results…</div>}
                  <div className="flex gap-2 items-center">
                    <div className="flex-1 bg-[#17212B] border border-[rgba(255,255,255,0.08)] rounded-xl px-3 py-1.5 flex items-center gap-2">
                      <span className="text-xs">🔍</span>
                      <input
                        type="text"
                        value={marketSearchQuery}
                        onChange={(e) => setMarketSearchQuery(e.target.value)}
                        placeholder="Search market (e.g. Kalyan, Main)..."
                        className="bg-transparent text-white text-xs w-full outline-none font-bold placeholder-[#7A9CB8]"
                      />
                      {marketSearchQuery && (
                        <button type="button"
                          onClick={() => setMarketSearchQuery('')}
                          className="text-[#7A9CB8] text-xs font-bold hover:text-white"
                        >
                          ✕
                        </button>
                      )}
                    </div>

                    <button type="button"
                      onClick={() => setIsGridMode(!isGridMode)}
                      className={`px-3 py-1.5 rounded-xl font-black text-xs uppercase flex items-center gap-1 border transition-all ${
                        isGridMode
                          ? 'bg-[#2AABEE] text-white border-[#2AABEE]'
                          : 'bg-[#17212B] text-[#7A9CB8] border-[rgba(255,255,255,0.08)]'
                      }`}
                    >
                      {isGridMode ? '📊 Grid' : '📄 List'}
                    </button>
                  </div>

                  {/* Status & Market View Filter Tabs */}
                  <div className="flex flex-wrap gap-1.5 pb-1 items-center justify-between">
                    <div className="flex gap-1.5 overflow-x-auto no-scrollbar items-center">
                      {(['ALL', 'WAIT', 'PASS', 'FAIL'] as const).map((st) => (
                        <button type="button"
                          key={st}
                          onClick={() => setMarketStatusFilter(st)}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase transition-all border ${
                            marketStatusFilter === st
                              ? st === 'PASS'
                                ? 'bg-[#00C26F] text-white border-[#00C26F]'
                                : st === 'FAIL'
                                ? 'bg-[#FF5D5D] text-white border-[#FF5D5D]'
                                : 'bg-[#2AABEE] text-white border-[#2AABEE]'
                              : 'bg-[#17212B] text-[#7A9CB8] border-[rgba(255,255,255,0.08)]'
                          }`}
                        >
                          {st === 'ALL' ? 'ALL STATUS' : st}
                        </button>
                      ))}
                    </div>
                    {/* View Filter by Day / Night */}
                    <div className="flex gap-1 items-center bg-[#0E1621] p-0.5 rounded-lg border border-[rgba(255,255,255,0.08)]">
                      <button
                        type="button"
                        onClick={() => setMarketScopeFilter('ALL')}
                        className={`px-2 py-0.5 rounded text-[9px] font-black uppercase transition-all ${
                          marketScopeFilter === 'ALL' ? 'bg-[#2AABEE] text-white' : 'text-[#7A9CB8] hover:text-white'
                        }`}
                        title="Show all cards"
                      >
                        🌐 ALL
                      </button>
                      <button
                        type="button"
                        onClick={() => setMarketScopeFilter('DAY')}
                        className={`px-2 py-0.5 rounded text-[9px] font-black uppercase transition-all ${
                          marketScopeFilter === 'DAY' ? 'bg-[#E5A93C] text-black font-extrabold' : 'text-[#7A9CB8] hover:text-white'
                        }`}
                        title="Show Day cards only"
                      >
                        ☀️ DAY
                      </button>
                      <button
                        type="button"
                        onClick={() => setMarketScopeFilter('NIGHT')}
                        className={`px-2 py-0.5 rounded text-[9px] font-black uppercase transition-all ${
                          marketScopeFilter === 'NIGHT' ? 'bg-[#6C5CE7] text-white font-extrabold' : 'text-[#7A9CB8] hover:text-white'
                        }`}
                        title="Show Night cards only"
                      >
                        🌙 NIGHT
                      </button>
                    </div>
                  </div>

                  {isMasterApp && (
                    <details className="bulk-control-panel rounded-xl border border-[rgba(255,255,255,0.08)] bg-[#17212B] p-2 space-y-2">
                      <summary className="bulk-control-summary flex items-center justify-between gap-2">
                        <span className="bulk-section-logo"><BulkActionIcon kind="section" /></span>
                        <span className="bulk-section-label flex items-center gap-1.5">
                          <span>
                            {gameTab === 'jodi'
                              ? 'Jodi From Ank'
                              : gameTab === 'pannel'
                                ? 'Panel From Ank Sum'
                                : 'Bulk Scraping & Tricks'}
                          </span>
                          {bulkMarketScope !== 'ALL' && (
                            <span className={`px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${
                              bulkMarketScope === 'DAY'
                                ? 'bg-[#E5A93C] text-black font-extrabold shadow-sm'
                                : 'bg-[#6C5CE7] text-white font-extrabold shadow-sm'
                            }`}>
                              {bulkMarketScope === 'DAY' ? '☀️ DAY ONLY' : '🌙 NIGHT ONLY'}
                            </span>
                          )}
                        </span>
                        {bulkAction && bulkAction!=='cards:restore' && (
                          <span className="text-[9px] font-black text-[#FAC748] animate-pulse uppercase">
                            {bulkAction==='cards:reset'?'Clearing all…':'Working…'}
                          </span>
                        )}
                      </summary>

                      {/* Day / Night 2-Part System Scope Selector for Bulk Actions */}
                      <div className="flex items-center gap-1.5 p-1.5 bg-[#0E1621] rounded-xl border border-[#242F3D]">
                        <span className="text-[9px] font-black uppercase text-[#8DA6C0] px-1 shrink-0 flex items-center gap-1">
                          <span>Apply To:</span>
                        </span>
                        <button
                          type="button"
                          onClick={() => setBulkMarketScope('ALL')}
                          className={`flex-1 py-1.5 px-2 rounded-lg text-[9px] font-black uppercase transition-all flex items-center justify-center gap-1 ${
                            bulkMarketScope === 'ALL'
                              ? 'bg-[#2AABEE] text-white shadow-md ring-1 ring-white/30'
                              : 'text-[#8DA6C0] hover:text-white hover:bg-[#17212B]'
                          }`}
                          title="Bulk actions apply to ALL enabled markets on this tab"
                        >
                          <span>🌐 ALL MARKETS</span>
                          <span className="text-[8px] opacity-80">({gameTab === 'jodi' ? 14 : 28})</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setBulkMarketScope('DAY')}
                          className={`flex-1 py-1.5 px-2 rounded-lg text-[9px] font-black uppercase transition-all flex items-center justify-center gap-1 ${
                            bulkMarketScope === 'DAY'
                              ? 'bg-gradient-to-r from-[#F39C12] to-[#E67E22] text-black font-extrabold shadow-md ring-2 ring-[#F39C12]/50'
                              : 'text-[#8DA6C0] hover:text-white hover:bg-[#17212B]'
                          }`}
                          title="Bulk actions apply to DAY markets only"
                        >
                          <span>☀️ DAY ONLY</span>
                          <span className="text-[8px] opacity-90">({gameTab === 'jodi' ? 7 : 14})</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setBulkMarketScope('NIGHT')}
                          className={`flex-1 py-1.5 px-2 rounded-lg text-[9px] font-black uppercase transition-all flex items-center justify-center gap-1 ${
                            bulkMarketScope === 'NIGHT'
                              ? 'bg-gradient-to-r from-[#6C5CE7] to-[#8E44AD] text-white font-extrabold shadow-md ring-2 ring-[#6C5CE7]/50'
                              : 'text-[#8DA6C0] hover:text-white hover:bg-[#17212B]'
                          }`}
                          title="Bulk actions apply to NIGHT markets only"
                        >
                          <span>🌙 NIGHT ONLY</span>
                          <span className="text-[8px] opacity-90">({gameTab === 'jodi' ? 7 : 14})</span>
                        </button>
                      </div>
                      {gameTab === 'jodi' ? (
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                          <button
                            type="button"
                            disabled={Boolean(bulkAction)}
                            onClick={handleBulkJodiFromAnk}
                            className="w-full bg-gradient-to-r from-[#2AABEE] to-[#087FB8] text-white px-2 py-2 rounded-lg text-[9px] font-black uppercase active:scale-[0.99] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                            title="Har enabled market me OPEN ANK × CLOSE ANK se Jodi banao"
                          >
                            {bulkAction === 'jodi:ank-combine' ? '⏳ ' : '🔗 '}ANK → JODI
                          </button>
                          <button
                            type="button"
                            disabled={Boolean(bulkAction)}
                            onClick={handleBulk32JodiOnly}
                            className="w-full bg-gradient-to-r from-[#FF5722] via-[#F43F5E] to-[#E11D48] text-white px-2 py-2 rounded-lg text-[9px] font-black uppercase active:scale-[0.99] transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
                            title="Har enabled market me strictly 32 JODIS generate karo"
                          >
                            {bulkAction === 'jodi:32-only' ? '⏳ ' : '🎯 '}32 JODI BULK
                          </button>
                          <button
                            type="button"
                            disabled={Boolean(bulkAction)}
                            onClick={handleBulkLifetimeJodiFormula}
                            className="w-full bg-gradient-to-r from-[#8B3DFF] via-[#B85CFF] to-[#D35400] text-white px-2 py-2 rounded-lg text-[9px] font-black uppercase active:scale-[0.99] transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
                            title="Pichli Jodi ke Farak (Difference) ke hisab se 16, 24 ya 32 Jodis bulk me lagao"
                          >
                            {bulkAction === 'jodi:lifetime-formula' ? '⏳ ' : '⚡ '}16/24/32
                          </button>
                          <button
                            type="button"
                            disabled={Boolean(bulkAction)}
                            onClick={handleBulkJodiToAnk}
                            className="w-full bg-gradient-to-r from-[#00C26F] to-[#059669] text-white px-2 py-2 rounded-lg text-[9px] font-black uppercase active:scale-[0.99] transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
                            title="Har Jodi card se OPEN aur CLOSE ank nikal kar ANK tab me transfer karo"
                          >
                            {bulkAction === 'jodi:to-ank' ? '⏳ ' : '📤 '}JODI → ANK
                          </button>
                        </div>
                      ) : gameTab === 'pannel' ? (
                        <div className="grid grid-cols-2 gap-1.5">
                          <button
                            type="button"
                            disabled={Boolean(bulkAction)}
                            onClick={handleBulkPanelFromAnk}
                            className="w-full bg-gradient-to-r from-[#20B2AA] to-[#087F78] text-white px-2 py-2 rounded-lg text-[9px] font-black uppercase active:scale-[0.99] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                            title="Har enabled Panel card me same-market ANK sum wali Pattis select karo"
                          >
                            {bulkAction === 'panel:ank-sum' ? '⏳ ' : '🎯 '}ANK → PANEL
                          </button>
                          <button
                            type="button"
                            disabled={Boolean(bulkAction)}
                            onClick={handleBulkLowPanelFromAnk}
                            className="w-full bg-gradient-to-r from-[#B04A7A] to-[#75305D] text-white px-2 py-2 rounded-lg text-[9px] font-black uppercase active:scale-[0.99] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                            title="Har enabled Panel card me unseen/lowest-frequency 30 Pattis select karo"
                          >
                            {bulkAction === 'panel:low-30' ? '⏳ ' : '📉 '}LOW PANEL 30
                          </button>
                          <button type="button" disabled={Boolean(bulkAction)} onClick={handleBulkStrictPanel30}
                            className="w-full bg-[#25635E] text-white px-2 py-2 rounded-lg text-[9px] font-black uppercase disabled:opacity-50"
                            title="Recent 30 unique SP skip; exactly 6 ANK × 5 each; shortage means SKIP">
                            {bulkAction === 'panel:strict-30' ? '⏳ ' : '✂ '}RECENT 30 SKIP · 6×5 BULK
                          </button>
                        </div>
                      ) : (
                      <div className="bulk-source-buttons">
                        {([
                          ['scrape', 'Auto Scrape', 'bg-[#2AABEE]'],
                          ['weekday', 'Day ↥ Bulk', 'bg-[#168F68]'],
                          ['open_auto_close_day', 'OPEN Auto / CLOSE Day', 'bg-[#087F91]'],
                          ['combo', 'Combo', 'bg-[#00A05E]'],
                          ['day_combo', 'Day Combo ↥ Bulk', 'bg-[#237D74]'],
                          ['smart', 'Smart', 'bg-[#8B3DFF]'],
                          ['market_model', 'Pair Follow', 'bg-[#E65C00]'],
                          ['pair_combo', 'Pair Combo', 'bg-[#D35400]'],
                          ['mssd', 'MSSD', 'bg-[#8E44AD]'],
                          ['freq_10', '10-Draw Freq (Skip Recent)', 'bg-[#0E7490]'],
                          ['freq_10_combo', 'Week O+C Freq (7D/6D/5D)', 'bg-[#0F766E]'],
                        ] as Array<['scrape' | 'weekday' | 'combo' | 'day_combo' | 'smart' | 'market_model' | 'pair_combo' | 'mssd' | 'freq_10' | 'freq_10_combo' | 'open_auto_close_day', string, string]>).map(([mode, label, color], buttonIndex) => (
                          <button
                            key={mode}
                            data-bulk-mode={mode}
                            aria-label={label} aria-busy={bulkAction === `scrape:${mode}`}
                            type="button"
                            disabled={Boolean(bulkAction)}
                            onClick={() => { setSelectedBulkScrape(`${gameTab}:${mode}`); handleBulkScrape(mode, gameTab as GameType); }}
                            className={`${color} text-white w-14 h-14 shrink-0 p-1 rounded-lg text-[8px] leading-tight font-black uppercase break-words flex items-center justify-center text-center shadow-sm active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed ${selectedBulkScrape === `${gameTab}:${mode}` ? 'ring-2 ring-white/90 ring-offset-2 ring-offset-[#17212B] brightness-125 shadow-[0_0_18px_rgba(255,255,255,0.65)]' : ''}`}
                            title={mode === 'freq_10' ? '10-Draw Frequency (Separate): Sabse recent draw chhod kar pichle 10 draws me highest frequency wale digits suggest karo' : mode === 'freq_10_combo' ? 'Market Weekdays O+C Frequency (Sridevi 7D, Time Bazar 6D, Main Bazar 5D): Sabse recent din chhod kar har market ke apne week days (7/6/5 din) ke Open+Close sath me mila kar highest frequency wale digits suggest karo' : `Apply ${label} to every enabled card on this tab`}
                          >
                            <span className="bulk-button-number"><BulkActionIcon kind={mode} />{bulkAction === `scrape:${mode}`?<i className="result-control-spinner"/>:buttonIndex+1}</span>
                            <span>{({scrape:'Auto',weekday:'Day',open_auto_close_day:'O / C',combo:'Combo',day_combo:'Day Mix',smart:'Smart',market_model:'Pair Follow',pair_combo:'Pair Combo',mssd:'MSSD',freq_10:'10D Freq',freq_10_combo:'Wk O+C'} as const)[mode]}</span>
                          </button>
                        ))}
                        <button
                          type="button"
                          disabled={Boolean(bulkAction)}
                          data-bulk-mode="positions" aria-label="Digit Follow bulk" aria-busy={bulkAction==='scrape:digit_follow'}
                          onClick={() => { setSelectedBulkScrape(`${gameTab}:positions`); handleBulkScrape('digit_follow', gameTab as GameType); }}
                          className={`bg-[#B24CC8] text-white w-14 h-14 shrink-0 p-1 rounded-lg text-[8px] leading-tight font-black uppercase break-words flex items-center justify-center text-center shadow-sm active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed ${selectedBulkScrape === `${gameTab}:positions` ? 'ring-2 ring-white/90 ring-offset-2 ring-offset-[#17212B] brightness-125 shadow-[0_0_18px_rgba(255,255,255,0.65)]' : ''}`}
                          title="Digit Follow: latest OPEN digit for OPEN, latest CLOSE digit for CLOSE; collect each reference digit’s next actual across both sides; stop at ten unique"
                        >
                          <span className="bulk-button-number"><BulkActionIcon kind="positions" />{bulkAction==='scrape:digit_follow'?<i className="result-control-spinner"/>:12}</span><span>Digit Follow</span>
                        </button>
                        <button type="button"
                          disabled={!!bulkAction}
                          data-bulk-mode="panna_follow" aria-label="Panna Follow bulk" aria-busy={bulkAction==='scrape:panna_follow'}
                          onClick={() => { setSelectedBulkScrape(`${gameTab}:panna_follow`); handleBulkScrape('panna_follow', gameTab as GameType); }}
                          className={`bg-[#168C86] text-white w-14 h-14 shrink-0 p-1 rounded-lg text-[8px] leading-tight font-black uppercase break-words flex items-center justify-center text-center shadow-sm active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed ${selectedBulkScrape === `${gameTab}:panna_follow` ? 'ring-2 ring-white/90 ring-offset-2 ring-offset-[#17212B]' : ''}`}
                          title="Panna Follow: own-side latest panna; match either historical side and collect the immediately next ank, up to ten unique"
                        >
                          <span className="bulk-button-number"><BulkActionIcon kind="positions" />{bulkAction==='scrape:panna_follow'?<i className="result-control-spinner"/>:13}</span><span>Panna Follow</span>
                        </button>
                      </div>
                      )}

                      {gameTab === 'ank' && (
                        <>
                          {bulkScrapeProgress?.owner===activeId&&bulkScrapeProgress.date===currentDate&&<div className="flex items-center gap-2 rounded-lg border border-sky-500/30 p-2 text-xs text-sky-200">
                            <span role="status" aria-live="polite" className="flex-1">Scraping {bulkScrapeProgress.done}/{bulkScrapeProgress.total} cards…</span>
                            <button type="button" className="min-h-10 rounded border border-sky-400/50 px-3" onClick={()=>{
                              const run=bulkScrapeRun.current;
                              if(run?.id===bulkScrapeProgress.id){run.controller.abort();showToast('Scrape cancelled','Finished cards are kept. Pending responses will not change cards.','info');}
                            }}>Cancel scrape</button>
                          </div>}
                          {bulkScrapeReport&&bulkScrapeReport.profileId===activeId&&bulkScrapeReport.date===currentDate&&(
                            <details className="rounded-lg border border-[#FAC748]/20 p-2 text-[10px] text-[#8DA6C0]" open={bulkScrapeReport.failures.length>0||bulkScrapeReport.skipped.length>0}>
                              <summary className="min-h-8 cursor-pointer">Last scrape: {bulkScrapeReport.ok}/{bulkScrapeReport.total} ready · {bulkScrapeReport.failures.length} failed · {bulkScrapeReport.skipped.length} skipped/unchanged{bulkScrapeReport.changed?` · ${bulkScrapeReport.changed} changed/protected`:''}</summary>
                              {bulkScrapeReport.skipped.length>0&&<ul className="space-y-1 my-2">{bulkScrapeReport.skipped.map(item=><li key={item.market}><strong>{item.market}</strong>: {item.message.replace(/https?:\/\/\S+/g,'chart source').slice(0,400)}</li>)}</ul>}
                              {bulkScrapeReport.failures.length>0&&<>
                                <ul className="space-y-1 my-2">{bulkScrapeReport.failures.map(failure=><li key={failure.market}><strong>{failure.market}</strong>: {failure.message.replace(/https?:\/\/\S+/g,'chart source').slice(0,400)}</li>)}</ul>
                                <button type="button" disabled={Boolean(bulkAction)} onClick={()=>handleBulkScrape(bulkScrapeReport.mode,'ank',bulkScrapeReport.failures.map(failure=>failure.guard))}
                                  className="min-h-10 rounded-lg bg-[#2AABEE]/20 px-3 font-bold text-[#8DC8FF] disabled:opacity-50">Retry failed only</button>
                              </>}
                            </details>
                          )}
                          <div className="bulk-tricks-heading flex items-center justify-between">
                            <div className="flex items-center gap-1.5"><BulkActionIcon kind="trick" /><span>Bulk Tricks</span><span className="bulk-section-hint">Select an action</span></div>
                            <div className="flex items-center gap-2">
                              <button type="button" onClick={() => setIsAiAdvisorOpen(true)} className="text-[10px] text-amber-300 hover:text-amber-100 font-bold flex items-center gap-1 bg-amber-500/15 hover:bg-amber-500/25 px-2 py-0.5 rounded-lg border border-amber-500/40 shadow-sm transition-all active:scale-95" title="Open Titan AI Assistant & Guru Advisor (Gemini 3.8 Flash)">
                                ✨ AI Helper
                              </button>
                              <button type="button" onClick={() => setIsSelfLearningModalOpen(true)} className="text-[10px] text-cyan-400 hover:text-cyan-200 underline font-bold flex items-center gap-1">
                                🧠 AI Brain & Weights
                              </button>
                            </div>
                          </div>
                          {selfLearningScanProgress && (
                            <div role="status" aria-live="polite" className="mb-2 flex items-center justify-between gap-2 rounded-lg border border-cyan-500/40 bg-cyan-950/30 px-3 py-2 text-xs text-cyan-200 font-mono tabular-nums">
                              <span className="truncate">
                                🔍 Scanning Chart &amp; Extracting Rule ({selfLearningScanProgress.done}/{selfLearningScanProgress.total}) · <strong>{selfLearningScanProgress.currentMarket}</strong>
                              </span>
                              <span className="text-[10px] font-bold text-emerald-300 shrink-0">
                                {Math.round((selfLearningScanProgress.done / Math.max(1, selfLearningScanProgress.total)) * 100)}%
                              </span>
                            </div>
                          )}
                          <div className="bulk-trick-buttons" aria-label="Bulk tricks">
                          <button type="button" disabled={Boolean(bulkAction) || Boolean(selfLearningScanProgress)} onClick={() => void handleBulkSelfLearning()}
                            aria-label="Self-Learning AI 4-Digits 1-Click Apply" title="🧠 1-Click Live Chart Analysis: Har market ka live chart scan karke alag Rule aur unique 4-Ank apply karein"
                            className="w-full py-1.5 rounded-lg text-[9px] font-black uppercase bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 hover:from-cyan-500 hover:to-blue-500 border border-cyan-400/40 text-cyan-100 disabled:opacity-50 shadow-md shadow-cyan-500/10 active:scale-[0.99] transition-all">
                            <span className="bulk-button-number"><BulkActionIcon kind="smart" />AI</span><span className="bulk-button-caption">{selfLearningScanProgress ? `Scanning ${selfLearningScanProgress.done}/${selfLearningScanProgress.total}…` : 'Self-Learning'}</span>
                          </button>
                          <button type="button" disabled={Boolean(bulkAction)} onClick={()=>handleBulkScrape('trend_break','ank')}
                            aria-label="Trend Filter bulk" title="Trend Filter: Keep Top 4–5 High-Probability digits from current box based on momentum and decay"
                            className="w-full py-1.5 rounded-lg text-[9px] font-black uppercase bg-gradient-to-r from-[#B45309] to-[#78350F] hover:from-[#D97706] hover:to-[#92400E] border border-amber-500/30 text-amber-100 disabled:opacity-50 shadow-sm active:scale-[0.99] transition-all">
                            <span className="bulk-button-number"><BulkActionIcon kind="smart" /></span><span className="bulk-button-caption">Trend Filter (4–5D)</span>
                          </button>
                          <button aria-label="🔗 OPEN ↔ CLOSE · KEEP UNMATCHED BULK" type="button" disabled={Boolean(bulkAction)} onClick={handleBulkOpenCloseMatch}
                            className="w-full py-1.5 rounded-lg text-[9px] font-black uppercase bg-[#246D67] text-white disabled:opacity-50"
                            title="Same market ke OPEN aur CLOSE selected digits compare; common digits dono se hatao; har side par sirf unmatched digits rakho; all common = empty; sent/manual-settled pairs protected">
                            <span className="bulk-button-number"><BulkActionIcon kind="match" />1</span><span className="bulk-button-caption">Unmatched</span>
                          </button>
                          <button aria-label="🔗 OPEN + CLOSE · MIX DIGITS BULK" type="button" disabled={Boolean(bulkAction)} onClick={handleBulkOpenCloseUnion}
                            className="w-full py-1.5 rounded-lg text-[9px] font-black uppercase bg-[#1B6CA8] hover:bg-[#2080C4] text-white disabled:opacity-50 border border-sky-400/30 shadow-sm active:scale-[0.99] transition-all"
                            title="Same market ke OPEN aur CLOSE digits mix (union) karo: e.g. Open [1,2,3,4] + Close [3,4,5,6] -> Dono me [1,2,3,4,5,6] unique sorted">
                            <span className="bulk-button-number"><BulkActionIcon kind="mix" />Mix</span><span className="bulk-button-caption">Open+Close Mix</span>
                          </button>
                          <button aria-label="Fcut bulk: cut original source positions 1–4" type="button" disabled={Boolean(bulkAction)} onClick={() => handleBulkRemoveFirstFour()}
                            className="w-full py-1.5 rounded-lg text-[9px] font-black uppercase bg-[#147D91] text-white disabled:opacity-50"
                            title="Source positions 1–4 identify cut digits; remove only those still in current box. Never restore the full source.">
                            <span className="bulk-button-number"><BulkActionIcon kind="cut" />2</span><span className="bulk-button-caption">Fcut</span>
                          </button>
                          <button type="button" disabled={Boolean(bulkAction)} onClick={() => handleBulkRemoveFirstFour(true)}
                            aria-label="Lcut bulk: cut original source last four digits"
                            className="w-full py-1.5 rounded-lg text-[9px] font-black uppercase bg-[#147D91] text-white disabled:opacity-50"
                            title="Cut source positions 7–10 from current box; keep available first-six digits without restoring earlier cuts.">
                            <span className="bulk-button-number"><BulkActionIcon kind="cut" /></span><span className="bulk-button-caption">Lcut</span>
                          </button>
                          <button type="button" disabled={Boolean(bulkAction)} onClick={() => handleBulkLiveCombinedCut('first')}
                            aria-label="Apply live AUTO 2 + DAY 2 first cut"
                            className="w-full py-1.5 rounded-lg text-[9px] font-black uppercase bg-[#153F59] text-[#8DC8FF] disabled:opacity-50"
                            title="A+D First: AUTO first 2 + DAY first 2 digits cut; duplicate = direct SKIP. Same market and side only.">
                            <span className="bulk-button-number"><BulkActionIcon kind="mix" />3</span><span className="bulk-button-caption">A+D</span>
                          </button>
                          <button type="button" disabled={Boolean(bulkAction)} onClick={() => handleBulkLiveCombinedCut('last')}
                            aria-label="Apply live AUTO 2 + DAY 2 last cut"
                            className="w-full py-1.5 rounded-lg text-[9px] font-black uppercase bg-[#184E6E] text-[#8DC8FF] border border-[#2AABEE]/30 disabled:opacity-50"
                            title="A+D Last: AUTO last 2 + DAY last 2 digits cut; duplicate = direct SKIP. Same market and side only.">
                            <span className="bulk-button-number"><BulkActionIcon kind="mix" />3L</span><span className="bulk-button-caption">A+D Last</span>
                          </button>
                          
                          <button aria-label="Cut 2 first and last digits" type="button" disabled={Boolean(bulkAction)} onClick={() => handleBulkRemoveRecentPass(2)}
                            className="w-full py-1.5 rounded-lg text-[9px] font-black uppercase bg-[#8A4B32] text-white disabled:opacity-50"
                            title="Cut first and last available digits from each current box; no history lookup, mirror or original-source refill">
                            <span className="bulk-button-number"><BulkActionIcon kind="cut" />4</span><span className="bulk-button-caption">Cut 2</span>
                          </button>
                          <button aria-label="KEEP RECENT 6 UNIQUE INDICES✅" type="button" disabled={Boolean(bulkAction)} onClick={() => handleBulkRemoveRecentPass(6)}
                            className="w-full py-1.5 rounded-lg text-[9px] font-black uppercase bg-[#246D67] text-white disabled:opacity-50"
                            title="Keep latest 6 distinct prior PASS/FAIL source indices; skip duplicates and search older saved history; keep 6 digits first; AUTO REMOVE RESULT DIGIT applies when ON; parity cuts bypassed">
                            <span className="bulk-button-number"><BulkActionIcon kind="positions" />5</span><span className="bulk-button-caption">Keep6</span>
                          </button>
                          <button aria-label="✂ RECENT 4 UNIQUE INDICES REMOVE BULK" type="button" disabled={Boolean(bulkAction)} onClick={() => handleBulkRemoveRecentPass(4)}
                            className="w-full py-1.5 rounded-lg text-[9px] font-black uppercase bg-[#754F8A] text-white disabled:opacity-50"
                            title="Recent 4 unique source indices: cut only target digits still in the current box; never refill missing digits">
                            <span className="bulk-button-number"><BulkActionIcon kind="cut" />6</span><span className="bulk-button-caption">Cut 4</span>
                          </button>
                          <button aria-label="First Digit Cut bulk"
                            type="button"
                            disabled={Boolean(bulkAction)}
                            onClick={() => handleBulkFirstDigitMirrorCut(gameTab as GameType)}
                            className="w-full py-1.5 rounded-lg text-[9px] font-black uppercase active:scale-[0.99] transition-all disabled:opacity-50 disabled:cursor-not-allowed bg-gradient-to-r from-[#2357C6] to-[#7B3DCC] border border-[rgba(142,161,255,0.45)] text-white"
                            title="Each click removes only the first digit currently in the box. No mirror, history lookup or source refill."
                          >
                            <span className="bulk-button-number"><BulkActionIcon kind="yday" />7</span><span className="bulk-button-caption">First Cut</span>
                          </button>
                          <button aria-label="Recent2 +1 Cut bulk"
                            type="button"
                            disabled={Boolean(bulkAction)}
                            onClick={() => handleBulkRecentTwoNextCut(gameTab as GameType)}
                            className="w-full py-1.5 rounded-lg text-[9px] font-black uppercase active:scale-[0.99] transition-all disabled:opacity-50 disabled:cursor-not-allowed bg-[rgba(36,181,212,0.16)] border border-[rgba(36,181,212,0.4)] text-[#55D8F2]"
                            title="Cut current remaining digits at original-source Recent2 +1 positions; retain previous cuts; 10→1; repeat digit + mirror"
                          >
                            <span className="bulk-button-number"><BulkActionIcon kind="cut" />8</span><span className="bulk-button-caption">Recent2 +1 Cut</span>
                          </button>
                          <button aria-label="Mirror Add bulk" type="button" disabled={Boolean(bulkAction)} onClick={handleBulkMirrorAdd}
                            className="w-full py-1.5 rounded-lg text-[9px] font-black uppercase bg-[#5A4A96] text-white disabled:opacity-50"
                            title="Current selected digits + mirrors; 1,2,3 → 1,6,2,7,3,8. No original-source rebuild; no duplicates. May reintroduce OPEN/CLOSE overlap.">
                            <span className="bulk-button-number"><BulkActionIcon kind="trick" />9</span><span className="bulk-button-caption">Mirror Add</span>
                          </button>
                          <button aria-label="SSD Support Strong Digit bulk" type="button" disabled={Boolean(bulkAction)} onClick={handleBulkSupportStrongDigits}
                            className="w-full py-1.5 rounded-lg text-[9px] font-black uppercase bg-gradient-to-r from-[#00884f] to-[#126b45] border border-[#79ce9d]/50 text-white disabled:opacity-50"
                            title="Support Strong Digit (SSD): har card ke current box me bache digits me se sirf Strong aur Support digits rakho, baki cut karo; pehle se cut digits wapas nahi aayenge">
                            <span className="bulk-button-number"><BulkActionIcon kind="smart" />SSD</span><span className="bulk-button-caption">SSD</span>
                          </button>
                            {([1, 2, 3] as const).map((trickNum) => (
                              <button
                                key={trickNum}
                                aria-label={trickNum===1?'T1 ODD · 1 3 5 7 9 BULK':trickNum===2?'T2 EVEN · 2 4 6 8 0 BULK':'T3 TRICK BULK'}
                                type="button"
                                disabled={Boolean(bulkAction)}
                                onClick={() => handleBulkTrick(trickNum, gameTab as GameType)}
                                className={`py-1.5 rounded-lg text-[9px] font-black uppercase active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
                                  trickNum === 1
                                    ? 'bg-[rgba(123,143,255,0.2)] border border-[rgba(123,143,255,0.4)] text-[#8EA1FF]'
                                    : trickNum === 2
                                      ? 'bg-[rgba(250,199,72,0.2)] border border-[rgba(250,199,72,0.4)] text-[#FAC748]'
                                      : 'bg-[rgba(0,194,111,0.2)] border border-[rgba(0,194,111,0.4)] text-[#20E093]'
                                }`}
                                title={`Apply T${trickNum} to every card with source digits`}
                              >
                                <span className="bulk-button-number"><BulkActionIcon kind="trick" />{trickNum+8}</span><span className="bulk-button-caption">T{trickNum}</span>
                              </button>
                            ))}
                          <button
                            aria-label="Bulk Universal 4-Ank Lifetime Formula"
                            type="button"
                            disabled={Boolean(bulkAction)}
                            onClick={() => handleBulkUniversalLifetime4Ank(gameTab as GameType)}
                            className="w-full py-2 rounded-lg text-[9px] font-black uppercase bg-gradient-to-r from-[#D4AF37] via-[#F39C12] to-[#E67E22] border border-[#F59E0B]/50 text-black font-extrabold disabled:opacity-50 active:scale-95 transition-all shadow-md"
                            title="Universal Lifetime 4-Ank Formula: Pichli Jodi Total + Double Family Cut (All Markets)"
                          >
                            <span className="bulk-button-number"><BulkActionIcon kind="trick" />4A</span><span className="bulk-button-caption">👑 4-Ank Lifetime Formula</span>
                          </button>
                            <button aria-label="↩ UNDO TRICKS"
                              type="button"
                              disabled={Boolean(bulkAction)}
                              onClick={() => handleBulkUndoTricks(gameTab as GameType)}
                              className="py-1.5 rounded-lg text-[9px] font-black uppercase active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed bg-[rgba(42,171,238,0.16)] border border-[rgba(42,171,238,0.4)] text-[#56C5FF]"
                              title="Har editable ANK card ka applied trick undo karke original digits restore karo"
                            >
                              <span className="bulk-button-number"><BulkActionIcon kind="undo" />12</span><span className="bulk-button-caption">Undo</span>
                            </button>
                            <button aria-label="🗑️ DELETE CARDS"
                              aria-busy={bulkAction==='cards:reset'}
                              type="button"
                              disabled={Boolean(bulkAction)}
                              onClick={() => handleBulkResetCards(gameTab as GameType)}
                              className="py-1.5 rounded-lg text-[9px] font-black uppercase active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed bg-[rgba(255,93,93,0.14)] border border-[rgba(255,93,93,0.4)] text-[#FF7777]"
                              title="Selected date ke ANK cards ek batch mein clear; confirmation ke baad old investment/results reverse honge"
                            >
                              <span className="bulk-button-number"><BulkActionIcon kind="clear" />{bulkAction==='cards:reset'?<i className="result-control-spinner"/>:13}</span><span className="bulk-button-caption">Clear</span>
                            </button>
                          </div>
                          <details className="text-[9px] text-[#8DA6C0]"><summary className="min-h-10 cursor-pointer flex items-center">Auto + Day cut rules</summary><p className="text-[9px] text-[#8DA6C0]">Scrape first → apply 4 unique cuts. Same side only · duplicate: recent index 1 → index 2 → mirror. Missing history or impossible cuts = SKIP. Fresh source request failure leaves the card unchanged.</p></details>
                        </>
                      )}
                    </details>
                  )}
                </div>

                {currentProfile.vipLiveStart?.date === currentDate && currentDate === businessDateIST() && (
                  <div className="mx-3 mb-2 rounded-xl border border-[#2AABEE]/30 bg-[#2AABEE]/10 p-3 text-xs text-[#9CD9F5]">
                    Live entry · {new Date(currentProfile.vipLiveStart.createdAt).toLocaleTimeString('en-IN', {timeZone:'Asia/Kolkata',hour:'2-digit',minute:'2-digit'})} IST. Earlier completed markets are excluded; this VIP starts at the next eligible card.
                  </div>
                )}
                {currentDate < titanLocalDateISO() && !currentProfile.dayRecords[currentDate] && (
                  <div role="status" className="mx-3 mb-2 rounded-lg border border-[#4B6177]/50 bg-[#1B2937] px-3 py-2 text-[11px] text-[#A9BDCF]">
                    Is date ka saved card record nahi mila. Purani date dekhne se current date ke digits change nahi honge. History se card apply karna ho to is date par source choose karo.
                  </div>
                )}
                {/* Weekday Operating Schedule Banner (5D / 6D / 7D Filter) */}
                {(() => {
                  const sched = getDateWeekdayScheduleInfo(currentDate);
                  const visDict = gameTab === 'ank' ? currentProfile.dayRecords[currentDate]?.visAnk : gameTab === 'jodi' ? currentProfile.dayRecords[currentDate]?.visJodi : currentProfile.dayRecords[currentDate]?.visPan;
                  const activeCount = gameMarkets[gameTab].filter(m => isMarketEnabledForDate(currentProfile.config, visDict, m.n, currentDate)).length;
                  const totalCount = gameMarkets[gameTab].length;
                  return (
                    <div className="mx-3 mb-2 rounded-xl border border-cyan-500/25 bg-[#162230] px-3 py-2 flex flex-wrap items-center justify-between gap-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-[10px] font-black px-2 py-0.5 rounded-md bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 uppercase tracking-wider">
                          📅 {sched.dayName} ({currentDate})
                        </span>
                        <span className="text-[10px] font-extrabold text-emerald-300 uppercase">
                          {sched.activeScheduleLabel}
                        </span>
                        {sched.closedScheduleNote && (
                          <span className="text-[9px] font-bold text-amber-300/90 bg-amber-500/10 border border-amber-500/25 px-2 py-0.5 rounded-md">
                            🔒 {sched.closedScheduleNote}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] font-black text-[#8DC8FF] bg-[#2AABEE]/10 border border-[#2AABEE]/25 px-2 py-0.5 rounded-md">
                        {activeCount}/{totalCount} Cards Open
                      </span>
                    </div>
                  );
                })()}
                {/* Market Cards List (Compact Grid or List) */}
                <div inert={bulkAction === 'cards:restore'} aria-busy={bulkAction === 'cards:restore'} className={`p-3 ${isGridMode ? 'grid grid-cols-1 sm:grid-cols-2 gap-2' : ''}`}>
                  {gameMarkets[gameTab].map((m, idx) => {
                    const dictName = gameTab === 'ank' ? 'data' : gameTab === 'jodi' ? 'jodiData' : 'pannelData';
                    const visDict = gameTab === 'ank' ? currentProfile.dayRecords[currentDate]?.visAnk : gameTab === 'jodi' ? currentProfile.dayRecords[currentDate]?.visJodi : currentProfile.dayRecords[currentDate]?.visPan;

                    if (!isMarketEnabledForDate(currentProfile.config, visDict, m.n, currentDate) || !vipLiveMarketEligible(currentProfile, currentDate, gameTab as GameType, m.n)) return null;

                    const record = currentProfile.dayRecords[currentDate]?.[dictName]?.[idx] || { s: 'WAIT', d: '', r: '' };

                    // Apply Search Query Filter
                    if (marketSearchQuery.trim() !== '') {
                      const q = marketSearchQuery.toLowerCase().trim();
                      if (!m.n.toLowerCase().includes(q) && !(record.d || '').toLowerCase().includes(q)) {
                        return null;
                      }
                    }

                    // Apply Day / Night Scope Filter
                    if (marketScopeFilter !== 'ALL') {
                      const isNight = isNightMarket(m.n, m.hr);
                      if (marketScopeFilter === 'DAY' && isNight) return null;
                      if (marketScopeFilter === 'NIGHT' && !isNight) return null;
                    }

                    // Apply Status Filter
                    if (marketStatusFilter !== 'ALL' && record.s !== marketStatusFilter) {
                      return null;
                    }

                    return (
                      <LedgerCard
                        key={`${gameTab}-${m.n}-${idx}`}
                        type={gameTab}
                        index={idx}
                        market={m}
                        record={record}
                        isMaster={isMasterApp}
                        vipCanEdit={vipCanEdit}
                        profiles={appState.profiles}
                        sourceIndexHistory={appState.sourceIndexHistory}
                        activeId={activeId}
                        currentDate={currentDate}
                        onUpdateRecord={handleUpdateRecord}
                        onApplyRecoveryRate={handleApplyRecoveryRate}
                        onApplyTrick={handleApplyTrick}
                        onRecentIndices={handleCardRecentIndices}
                        onUndoTrick={handleUndoTrick}
                        onScrapeMarket={handleScrapeMarket}
                        onWeekdayScrapeMarket={handleWeekdayScrapeMarket}
                        onComboScrape={handleComboScrape}
                        onDayComboScrape={handleDayComboScrape}
                        onSmartAutoDigits={handleSmartAutoDigits}
                        onTrendBreak={handleTrendBreak}
                        onBuildJodiFromAnk={handleBuildJodiFromAnk}
                        onApply32JodiOnly={handleApply32JodiOnly}
                        onApplySrideviMasterFormula={handleApplySrideviMasterFormula}
                        onApplySrideviHeadSum={handleApplySrideviHeadSum}
                        onApplyTimeBazarRoot={handleApplyTimeBazarRoot}
                        onApplyMadhurTotal={handleApplyMadhurTotal}
                        onApplyMilanPyramid={handleApplyMilanPyramid}
                        onApplySupremeCenter={handleApplySupremeCenter}
                        onApplyKalyanFarak={handleApplyKalyanFarak}
                        onApplyMainBazar={handleApplyMainBazar}
                        onApplyMilanNight={handleApplyMilanNight}
                        onApplyUniversalLifetime4Ank={handleApplyUniversalLifetime4Ank}
                        onApplyLifetimeJodiFormula={handleApplyLifetimeJodiFormula}
                        onTransferJodiToAnk={handleTransferJodiToAnk}
                        onBuildPanelFromAnk={handleBuildPanelFromAnk}
                        onBuildLowPanelFromAnk={handleBuildLowPanelFromAnk}
                        onBuildStrictPanel30={handleBuildStrictPanel30}
                        onTestResult={handleIndividualTestResult}
                        onSendNow={handleVipSendNow}
                        onScheduleUpdate={handleScheduleUpdate}
                        onResetCard={handleResetCard}
                        onUnlockCard={handleUnlockCard}
                        disabled={!isMarketEnabledForDate(currentProfile.config, visDict, m.n, currentDate)}
                      />
                    );
                  })}
                </div>

                {/* Daily Audit Hisab-Kitab WhatsApp Share Banner */}
                <div className="mx-3 my-5 p-4 bg-gradient-to-r from-[#1C2733] to-[#17212B] border border-[rgba(0,194,111,0.3)] rounded-2xl shadow-xl space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-xl bg-[rgba(0,194,111,0.15)] border border-[rgba(0,194,111,0.3)] text-[#00C26F] flex items-center justify-center font-black text-xl shrink-0 shadow-sm">
                        📲
                      </div>
                      <div>
                        <h4 className="text-white text-xs font-black uppercase tracking-wider flex items-center gap-1.5">
                          Daily Audit Hisab-Kitab
                        </h4>
                        <p className="text-[#7A9CB8] text-[10px] font-semibold">
                          Cards Pass/Fail count, Peak Loss (-₹), Final Net P/L & details
                        </p>
                      </div>
                    </div>
                    <span className="text-[9px] bg-[rgba(0,194,111,0.2)] text-[#00C26F] border border-[rgba(0,194,111,0.3)] px-2 py-1 rounded-lg font-extrabold uppercase shrink-0">
                      {currentDate}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button type="button" onClick={()=>setAuditImageData(buildDailyAuditImageData(currentProfile,currentDate,gameTab))}
                      className="col-span-2 py-2.5 px-2 rounded-xl border border-[#53deee]/40 bg-[#16475c] text-[#bceeff] text-[11px] font-bold">
                      🖼️ {auditGameLabel(gameTab)} Daily Image · Preview / Share
                    </button>
                    <button type="button"
                      onClick={() => {
                        const msg = generateNormalDailyReport(currentProfile, currentDate, gameTab);
                        setShareMessage(msg);
                        setIsShareModalOpen(true);
                      }}
                      className="py-2.5 px-2 bg-[#FAC748] hover:bg-[#FFD766] text-[#17212B] text-[10px] font-black uppercase rounded-xl shadow-md flex items-center justify-center gap-1 active:scale-95 transition-all"
                    >
                      <span>📝 Normal {gameTab.toUpperCase()}</span>
                    </button>

                    <button type="button"
                      onClick={() => {
                        const msg = generateDailyAuditReport(currentProfile, currentDate, gameTab, appState.profiles);
                        setShareMessage(msg);
                        setIsShareModalOpen(true);
                      }}
                      className="py-2.5 px-2 bg-[#00C26F] hover:bg-[#00D077] text-white text-[10px] font-black uppercase rounded-xl shadow-md flex items-center justify-center gap-1 active:scale-95 transition-all"
                    >
                      <span>📲 Share {gameTab.toUpperCase()} Hisab</span>
                    </button>

                    <button type="button"
                      onClick={() => {
                        const msg = generateDailyAuditReport(currentProfile, currentDate, 'all', appState.profiles);
                        setShareMessage(msg);
                        setIsShareModalOpen(true);
                      }}
                      className="py-2.5 px-2 bg-[#2AABEE] hover:bg-[#38B5F8] text-white text-[10px] font-black uppercase rounded-xl shadow-md flex items-center justify-center gap-1 active:scale-95 transition-all"
                    >
                      <span>🌐 Full Day Audit</span>
                    </button>

                    <button type="button"
                      onClick={() => {
                        const msg = generateDailyAuditReport(currentProfile, currentDate, gameTab, appState.profiles);
                        navigator.clipboard.writeText(msg);
                        showToast('📋 Report Copied', 'Daily audit report copied to clipboard!', 'success');
                      }}
                      className="py-2.5 px-2 bg-[#2B3A4D] hover:bg-[#34465D] text-[#2AABEE] border border-[rgba(42,171,238,0.3)] text-[10px] font-black uppercase rounded-xl flex items-center justify-center gap-1 active:scale-95 transition-all"
                    >
                      <span>📋 Copy Hisab</span>
                    </button>
                  </div>
                </div>
              </>
            </div>)}</PreparedView>)}
          </div>
        )}

        {/* Audit Report View */}
        {<PreparedView key={`audit-${activeId}`} active={mainNav === 'audit'}>{() => (
          <WeeklyAudit
            profile={currentProfile}
            currentDate={currentDate}
            isMaster={isMasterApp}
            {...{
              // Original daily Audit component uses this callback.
              onPreviewDailyImage: (game: GameType) => setAuditImageData(buildDailyAuditImageData(currentProfile, currentDate, game)),
              // Monthly Audit component uses this one when its matching module is installed.
              onOpenActivityReplay: () => setIsActivityReplayOpen(true),
              onPreviewAuditImage: (game: GameType, period: 'day' | 'week' | 'month' | 'custom') => {
                const periodBuilder = (auditImageCompatExports as unknown as {
                  buildAuditImageData?: (profile: UserProfile, date: string, kind: GameType, view: 'day' | 'week' | 'month' | 'custom') => DailyAuditImageData;
                }).buildAuditImageData;
                if (typeof periodBuilder === 'function') {
                  setAuditImageData(periodBuilder(currentProfile, currentDate, game, period));
                } else if (period === 'day') {
                  setAuditImageData(buildDailyAuditImageData(currentProfile, currentDate, game));
                } else {
                  showToast('Audit PNG unavailable', 'Weekly/Monthly PNG requires its matching Audit update. No ledger data was changed.', 'warning');
                }
              },
            }}
            onSendReport={(msg) => {
              setShareMessage(msg);
              setIsShareModalOpen(true);
            }}
          />
        )}</PreparedView>}

        {/* AI Scan View */}
        {mainNav === 'smart' && isMasterApp && (
          <SmartAIScanner
            onBatchApplyData={handleBatchApplyData}
            profiles={appState.profiles}
          />
        )}

        {/* VIP Management View */}
        {isMasterApp && <PreparedView key={`clients-${activeId}`} active={mainNav === 'clients'}>{() => (
          <VipManagement
            profiles={appState.profiles}
            onSelectClient={(pid) => {
              setAppState((prev) => ({ ...prev, activeId: pid }));
              setMainNav('ledger');
            }}
            onAddVIP={handleAddVIP}
            onDeleteProfile={handleDeleteProfile}
            onSetExpiry={handleSetExpiry}
            onSetMemberType={handleSetVipMemberType}
            onToggleVipAccess={handleToggleVipAccess}
            onSendBroadcast={handleSendBroadcast}
            onToggleVipAutoMode={handleToggleVipAutoMode}
            onUpdateVipDestination={handleUpdateVipDestination}
            onUpdateVipScheduleEnabled={handleUpdateVipScheduleEnabled}
            broadcasts={appState.broadcasts}
          />
        )}</PreparedView>}

        {/* Payments Admin Dashboard */}
        {isMasterApp && <PreparedView key={`payments-${activeId}`} active={mainNav === 'payments'}>{() => (
          <PaymentAdmin
            payments={appState.payments}
            paymentMethods={appState.paymentMethods}
            onSavePaymentMethods={async(methods) => {
              try{
                await profileMutationQueueRef.current.enqueue('payment-settings',async()=>{
                  const response=await fetch(apiUrl('/api/app/payments/settings'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(methods),signal:AbortSignal.timeout(15000)});
                  const result=await response.json();if(!response.ok||result.status!=='success')throw Error(result.message||'Settings save failed');
                  setAppState(prev=>({...prev,paymentMethods:result.paymentMethods}));
                });
                showToast('Payment details saved','UPI and QR saved on server.','success');
              }catch(error:any){showToast('Payment settings not saved',error.message,'danger');throw error;}
            }}
            onApprovePayment={handleApprovePayment}
            onRejectPayment={handleRejectPayment}
            onApproveAllSafe={handleApproveAllSafe}
          />
        )}</PreparedView>}

        {/* Settings View */}
        {<PreparedView key={`settings-${activeId}`} active={mainNav === 'settings'}>{() => (
          <SettingsView
            profile={currentProfile}
            isMaster={isMasterApp}
            vipCanEdit={vipCanEdit}
            currentDate={currentDate}
            onToggleMarketVis={(trackDict, mName, checked) => {
              setAppState((prev) => {
                const updated = { ...prev.profiles };
                const prof = ensureProfileStructure(updated[activeId], true);
                if (!prof.dayRecords[currentDate][trackDict]) {
                  prof.dayRecords[currentDate][trackDict] = {};
                }
                prof.dayRecords[currentDate][trackDict]![mName] = checked;
                updated[activeId] = prof;
                return { ...prev, profiles: updated };
              });
              syncProfileVisibility([{ trackDict, marketName: mName, enabled: checked }]);
            }}
            onToggleAllOpenClose={(trackDict, checked) => {
              setAppState((prev) => {
                const updated = { ...prev.profiles };
                const prof = ensureProfileStructure(updated[activeId], true);
                if (!prof.dayRecords[currentDate][trackDict]) {
                  prof.dayRecords[currentDate][trackDict] = {};
                }
                BASE_MARKETS.forEach((bm) => {
                  prof.dayRecords[currentDate][trackDict]![bm.n + ' OPEN'] = checked;
                  prof.dayRecords[currentDate][trackDict]![bm.n + ' CLOSE'] = checked;
                });
                updated[activeId] = prof;
                return { ...prev, profiles: updated };
              });
              syncProfileVisibility(BASE_MARKETS.flatMap((bm) => [
                { trackDict, marketName: `${bm.n} OPEN`, enabled: checked },
                { trackDict, marketName: `${bm.n} CLOSE`, enabled: checked },
              ]));
            }}
            onToggleAllJodi={(checked) => {
              setAppState((prev) => {
                const updated = { ...prev.profiles };
                const prof = ensureProfileStructure(updated[activeId], true);
                if (!prof.dayRecords[currentDate].visJodi) {
                  prof.dayRecords[currentDate].visJodi = {};
                }
                BASE_MARKETS.forEach((bm) => {
                  prof.dayRecords[currentDate].visJodi![bm.n] = checked;
                });
                updated[activeId] = prof;
                return { ...prev, profiles: updated };
              });
              syncProfileVisibility(BASE_MARKETS.map((bm) => ({
                trackDict: 'visJodi' as const,
                marketName: bm.n,
                enabled: checked,
              })));
            }}
            onSave={handleSaveSettings}
          />
        )}</PreparedView>}

        {/* WA Bot View */}
        {<PreparedView key={`bot-${activeId}`} active={mainNav === 'bot'} freeze={false}>{() => (
          <TermuxBotView
            visible={mainNav === 'bot'}
            profile={currentProfile}
            currentDate={currentDate}
            onShowToast={showToast}
          />
        )}</PreparedView>}

        {/* Membership View */}
        {!isMasterApp && <PreparedView key={`membership-${activeId}`} active={mainNav === 'membership'}>{() => (
          <MembershipView
            profile={currentProfile}
            paymentMethods={appState.paymentMethods}
            userPayments={appState.payments.filter((p) => p.userId === activeId)}
            onSubmitPayment={handleSubmitPayment}
            onShowToast={showToast}
          />
        )}</PreparedView>}
      </main>

      {auditImageData&&<DailyAuditImageModal data={auditImageData} onClose={()=>setAuditImageData(null)}/>}

      {/* Share Modal */}
      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        message={shareMessage}
        profiles={appState.profiles}
      />

      {/* Install Modal */}
      <InstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        pwa={pwa}
      />

      {/* Result Auditor Modal */}
      <ResultAuditorModal
        isOpen={isResultAuditorOpen}
        onClose={() => setIsResultAuditorOpen(false)}
        dayStore={currentProfile.dayRecords[currentDate] || {}}
        profile={currentProfile}
        onShowToast={showToast}
      />

      {/* Self-Learning AI Prediction Modal */}
      <SelfLearningModal
        isOpen={isSelfLearningModalOpen}
        onClose={() => setIsSelfLearningModalOpen(false)}
        appState={appState}
        activeProfileId={activeId}
        currentDate={currentDate}
        marketScope={bulkMarketScope}
        onApplyBulk={(nextState, message) => {
          setAppState(nextState);
          showToast('✅ Self-Learned Applied', message, 'success');
        }}
        onRunLiveChartScan={() => void handleBulkSelfLearning()}
        scanProgress={selfLearningScanProgress}
        onShowToast={showToast}
      />

      {/* AI Assistant & Strategic Helper Modal (Gemini 3.8 Flash) */}
      <AiAdvisorModal
        isOpen={isAiAdvisorOpen}
        onClose={() => setIsAiAdvisorOpen(false)}
        appState={appState}
        activeProfileId={activeId}
        currentDate={currentDate}
        marketScope={bulkMarketScope}
        onApplyDigitsToCard={handleApplyAiDigitsToCard}
        onShowToast={showToast}
      />

      {/* Activity GIF-Video Replay Modal */}
      <ActivityReplayModal
        isOpen={isActivityReplayOpen}
        onClose={() => setIsActivityReplayOpen(false)}
        date={currentDate}
        profileId={activeId}
        profileName={currentProfile?.name || activeId}
        isMaster={isMasterApp}
        onShowToast={showToast}
      />

      {/* Floating AI Helper Trigger */}
      <button
        type="button"
        onClick={() => setIsAiAdvisorOpen(true)}
        className="fixed bottom-20 right-4 z-40 flex items-center gap-2 px-3.5 py-2.5 rounded-full bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs shadow-xl shadow-amber-500/25 border border-amber-300/40 active:scale-95 transition-all group"
        title="Open Titan AI Assistant & Guru Advisor"
        aria-label="Open Titan AI Assistant"
      >
        <Sparkles className="h-4 w-4 animate-spin text-slate-950 group-hover:scale-110 transition-transform" style={{ animationDuration: '6s' }} />
        <span className="hidden sm:inline font-extrabold">AI Help</span>
      </button>

      {/* Bottom Nav */}
      <BottomNav
        currentTab={mainNav}
        onSelectTab={(tab) => {
          {
            setMainNav(tab);
            if(tab!==mainNav) window.scrollTo({top:0,left:0,behavior:'instant'});
            if (isMasterApp && (tab === 'clients' || tab === 'bot' || tab === 'payments' || tab === 'smart')) {
              setAppState((prev) =>
                prev.activeId === 'admin1' ? prev : { ...prev, activeId: 'admin1' }
              );
            }
          }
        }}
        isMaster={isMasterApp}
      />
    </div>
  );
}
