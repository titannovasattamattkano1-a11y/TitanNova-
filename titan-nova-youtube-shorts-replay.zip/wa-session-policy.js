/** WhatsApp LIDs identify users but are not phone numbers. */
export function whatsappSessionPhone(creds){
  const jid=String(creds?.me?.id||'');
  if(jid.endsWith('@lid'))return '';
  if(jid.includes('@')&&!/@(?:s\.whatsapp\.net|c\.us)$/.test(jid))return '';
  return jid.split('@')[0].split(':')[0].replace(/\D/g,'');
}
export function sameWhatsAppPhone(a,b){
  const left=String(a||'').replace(/\D/g,''),right=String(b||'').replace(/\D/g,'');
  return Boolean(left&&right&&(left===right||(left.length>=10&&right.length>=10&&left.slice(-10)===right.slice(-10))));
}
