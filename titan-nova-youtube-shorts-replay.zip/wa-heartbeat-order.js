/** Reject status messages from superseded or already-closed WhatsApp socket sessions.
 * Keep status accurate; never use this to fabricate connectivity.
 */
export function isStaleWhatsAppHeartbeat(current, incoming) {
  const currentId = String(current?.sessionId || '');
  const nextId = String(incoming?.runtimeId || '');
  const currentStarted = Number(current?.startedAt || 0);
  const incomingStarted = Number(incoming?.sessionStartedAt || 0);
  if (!currentId || !nextId) return false;
  if (nextId === currentId) {
    // Socket close/offline has already retired this exact session. Its delayed
    // in-flight pulse cannot revive the same socket.
    return incoming?.status === 'online' && current?.online === false;
  }
  return currentStarted > 0 && incomingStarted > 0 && incomingStarted < currentStarted;
}
