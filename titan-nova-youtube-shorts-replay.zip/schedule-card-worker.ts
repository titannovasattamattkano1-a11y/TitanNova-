import {parentPort} from 'node:worker_threads';
import {renderScheduledCardPng} from './schedule-card-png';
parentPort?.on('message',async({id,data})=>{
  try{const png=await renderScheduledCardPng(data);parentPort?.postMessage({id,png});}
  catch{parentPort?.postMessage({id,error:'Card PNG rendering failed'});}
});
